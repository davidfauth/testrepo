define({ "api": [
  {
    "type": "post",
    "url": "/api/admin/:dataSource/alerts",
    "title": "Create an alert",
    "name": "CreateAlert",
    "group": "Alerts",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.alerts"
      }
    ],
    "description": "<p>Create a new alert. If <code>matchTTL</code> is set to 0, unconfirmed matches will disappear when they stop matching the alert query.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "title",
            "description": "<p>Title of the alert</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "query",
            "description": "<p>Graph query that will run periodically</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dialect",
            "description": "<p>Dialect of the graph query</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": false,
            "field": "enabled",
            "description": "<p>Whether the query will run periodically or not</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": true,
            "field": "folder",
            "description": "<p>ID of the alert folder (-1 for root folder)</p>"
          },
          {
            "group": "Parameter",
            "type": "object[]",
            "optional": true,
            "field": "columns",
            "description": "<p>Columns among the returned values of the query to save in a match as scalar values (<strong>maximum 5</strong>)</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"number\"",
              "\"string\""
            ],
            "optional": false,
            "field": "columns.type",
            "description": "<p>Type of the column</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "columns.columnName",
            "description": "<p>Name of the column in the query</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "columns.columnTitle",
            "description": "<p>Name of the column for the UI</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "cron",
            "description": "<p>CRON expression representing the frequency with which the query runs</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": true,
            "field": "matchTTL",
            "description": "<p>Number of days after which the matches of this alert are going to be deleted</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": true,
            "field": "maxMatches",
            "description": "<p>Maximum number of matches after which matches with lower scores are discarded</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/alert.ts",
    "groupTitle": "Alerts",
    "success": {
      "fields": {
        "Success 201": [
          {
            "group": "Success 201",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the alert</p>"
          },
          {
            "group": "Success 201",
            "type": "number",
            "optional": false,
            "field": "folder",
            "description": "<p>ID of the alert folder (-1 for root folder)</p>"
          },
          {
            "group": "Success 201",
            "type": "string",
            "optional": false,
            "field": "title",
            "description": "<p>Title of the alert</p>"
          },
          {
            "group": "Success 201",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Success 201",
            "type": "string",
            "optional": false,
            "field": "query",
            "description": "<p>Graph query that will run periodically</p>"
          },
          {
            "group": "Success 201",
            "type": "string",
            "optional": false,
            "field": "dialect",
            "description": "<p>Dialect of the graph query</p>"
          },
          {
            "group": "Success 201",
            "type": "boolean",
            "optional": false,
            "field": "enabled",
            "description": "<p>Whether the query will run periodically or not</p>"
          },
          {
            "group": "Success 201",
            "type": "object[]",
            "optional": false,
            "field": "columns",
            "description": "<p>Columns among the returned values of the query to save in a match as scalar values</p>"
          },
          {
            "group": "Success 201",
            "type": "string",
            "allowedValues": [
              "\"number\"",
              "\"string\""
            ],
            "optional": false,
            "field": "columns.type",
            "description": "<p>Type of the column</p>"
          },
          {
            "group": "Success 201",
            "type": "string",
            "optional": false,
            "field": "columns.columnName",
            "description": "<p>Name of the column in the query</p>"
          },
          {
            "group": "Success 201",
            "type": "string",
            "optional": false,
            "field": "columns.columnTitle",
            "description": "<p>Name of the column for the UI</p>"
          },
          {
            "group": "Success 201",
            "type": "string",
            "optional": false,
            "field": "cron",
            "description": "<p>CRON expression representing the frequency with which the query runs</p>"
          },
          {
            "group": "Success 201",
            "type": "number",
            "optional": false,
            "field": "matchTTL",
            "description": "<p>Number of days after which the matches of this alert are going to be deleted</p>"
          },
          {
            "group": "Success 201",
            "type": "number",
            "optional": false,
            "field": "maxMatches",
            "description": "<p>Maximum number of matches after which matches with lower scores are discarded</p>"
          },
          {
            "group": "Success 201",
            "type": "number",
            "optional": false,
            "field": "userId",
            "description": "<p>ID of the user that created the alert</p>"
          },
          {
            "group": "Success 201",
            "type": "string",
            "optional": false,
            "field": "lastRun",
            "description": "<p>Last time the query was executed in ISO-8601 format (<code>null</code> it was never executed)</p>"
          },
          {
            "group": "Success 201",
            "type": "object",
            "optional": false,
            "field": "lastRunProblem",
            "description": "<p>Object representing the problem in the last run (<code>null</code> if there wasn't a problem in the last run)</p>"
          },
          {
            "group": "Success 201",
            "type": "string",
            "optional": false,
            "field": "lastRunProblem.error",
            "description": "<p>Error that identifies the last run problem</p>"
          },
          {
            "group": "Success 201",
            "type": "boolean",
            "optional": false,
            "field": "lastRunProblem.partial",
            "description": "<p>Whether the last run was at least partially executed</p>"
          },
          {
            "group": "Success 201",
            "type": "string",
            "optional": false,
            "field": "createdAt",
            "description": "<p>Creation date in ISO-8601 format</p>"
          },
          {
            "group": "Success 201",
            "type": "string",
            "optional": false,
            "field": "updatedAt",
            "description": "<p>Last update date in ISO-8601 format</p>"
          },
          {
            "group": "Success 201",
            "type": "string",
            "optional": false,
            "field": "nextRun",
            "description": "<p>Date when the alert will be executed next in ISO-8601 format (<code>null</code> if it isn't scheduled)</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 201 OK\n{\n  \"id\": 8,\n  \"folder\": 4,\n  \"title\": \"alert_title\",\n  \"sourceKey\": \"584f2569\",\n  \"query\": \"MATCH (n1)-[r:DIRECTED]-(n2) RETURN n1, n1.score\",\n  \"dialect\": \"cypher\",\n  \"enabled\": true,\n  \"columns\": [\n    {\"type\": \"number\", \"columnName\": \"n1.score\", \"columnTitle\": \"Score\"}\n  ],\n  \"cron\": \"0 0 * * *\",\n  \"matchTTL\": 30,\n  \"maxMatches\": 20,\n  \"userId\": 1,\n  \"lastRun\": null,\n  \"lastRunProblem\": null,\n  \"updatedAt\": \"2016-05-16T08:23:35.730Z\",\n  \"createdAt\": \"2016-05-16T08:23:35.730Z\",\n  \"nextRun\": \"2016-08-15T00:00:00.000Z\"\n}",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "post",
    "url": "/api/admin/:sourceKey/alerts/folder",
    "title": "Create an alert folder",
    "name": "CreateAlertFolder",
    "group": "Alerts",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.alerts"
      }
    ],
    "description": "<p>Create an alert folder.</p>",
    "success": {
      "fields": {
        "Success 201": [
          {
            "group": "Success 201",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the alert folder</p>"
          },
          {
            "group": "Success 201",
            "type": "string",
            "optional": false,
            "field": "createdAt",
            "description": "<p>Creation date in ISO-8601 format</p>"
          },
          {
            "group": "Success 201",
            "type": "string",
            "optional": false,
            "field": "updatedAt",
            "description": "<p>Last update date in ISO-8601 format</p>"
          },
          {
            "group": "Success 201",
            "type": "string",
            "optional": false,
            "field": "title",
            "description": "<p>Title of the alert folder</p>"
          },
          {
            "group": "Success 201",
            "type": "-1",
            "optional": false,
            "field": "parent",
            "description": "<p>ID of the parent alert folder</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 201 OK\n{\n  \"id\": 1,\n  \"createdAt\": \"2019-06-14T15:41:26.995Z\",\n  \"updatedAt\": \"2019-06-14T15:41:26.995Z\",\n  \"title\": \"My alert folder\",\n  \"parent\": -1\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/alert.ts",
    "groupTitle": "Alerts",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "-1",
            "optional": true,
            "field": "parent",
            "defaultValue": "-1",
            "description": "<p>ID of the parent alert folder</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "title",
            "description": "<p>Title</p>"
          }
        ]
      }
    }
  },
  {
    "type": "delete",
    "url": "/api/admin/:dataSource/alerts/:alertId",
    "title": "Delete an alert",
    "name": "DeleteAlert",
    "group": "Alerts",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.alerts"
      }
    ],
    "description": "<p>Delete the alert selected by id and all its matches.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "alertId",
            "description": "<p>ID of the alert</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 204 No Content",
          "type": "none"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/alert.ts",
    "groupTitle": "Alerts"
  },
  {
    "type": "delete",
    "url": "/api/admin/:sourceKey/alerts/folder/:id",
    "title": "Delete an alert folder",
    "name": "DeleteAlertFolder",
    "group": "Alerts",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.alerts"
      }
    ],
    "description": "<p>Delete an alert folder.</p>",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 204 No Content",
          "type": "none"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/alert.ts",
    "groupTitle": "Alerts",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the alert folder to delete</p>"
          }
        ]
      }
    }
  },
  {
    "type": "post",
    "url": "/api/:dataSource/alerts/:alertId/matches/:matchId/action",
    "title": "Do an action on a match",
    "name": "DoMatchAction",
    "group": "Alerts",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "apiright:alert.doAction"
      }
    ],
    "description": "<p>Do an action (open, dismiss, confirm, unconfirm) on a match.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "alertId",
            "description": "<p>ID of the alert</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "matchId",
            "description": "<p>ID of the match</p>"
          }
        ],
        "body": [
          {
            "group": "body",
            "type": "string",
            "allowedValues": [
              "\"confirm\"",
              "\"dismiss\"",
              "\"unconfirm\"",
              "\"open\""
            ],
            "optional": false,
            "field": "action",
            "description": "<p>The action to perform</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 204 No Content",
          "type": "none"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/alert.ts",
    "groupTitle": "Alerts"
  },
  {
    "type": "get",
    "url": "/api/:sourceKey/alerts/:alertId",
    "title": "Get an alert",
    "name": "GetAlert",
    "group": "Alerts",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "apiright:alert.read"
      }
    ],
    "description": "<p>Get an alert by id.</p>",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the alert</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "folder",
            "description": "<p>ID of the alert folder (-1 for root folder)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "title",
            "description": "<p>Title of the alert</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "query",
            "description": "<p>Graph query that will run periodically</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "dialect",
            "description": "<p>Dialect of the graph query</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "enabled",
            "description": "<p>Whether the query will run periodically or not</p>"
          },
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "columns",
            "description": "<p>Columns among the returned values of the query to save in a match as scalar values</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"number\"",
              "\"string\""
            ],
            "optional": false,
            "field": "columns.type",
            "description": "<p>Type of the column</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "columns.columnName",
            "description": "<p>Name of the column in the query</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "columns.columnTitle",
            "description": "<p>Name of the column for the UI</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "cron",
            "description": "<p>CRON expression representing the frequency with which the query runs</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "lastRun",
            "description": "<p>Last time the query was executed in ISO-8601 format (<code>null</code> it was never executed)</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "lastRunProblem",
            "description": "<p>Object representing the problem in the last run (<code>null</code> if there wasn't a problem in the last run)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "lastRunProblem.error",
            "description": "<p>Error that identifies the last run problem</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "lastRunProblem.partial",
            "description": "<p>Whether the last run was at least partially executed</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "createdAt",
            "description": "<p>Creation date in ISO-8601 format</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "updatedAt",
            "description": "<p>Last update date in ISO-8601 format</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "nextRun",
            "description": "<p>Date when the alert will be executed next in ISO-8601 format (<code>null</code> if it isn't scheduled)</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"id\": 8,\n  \"folder\": 4,\n  \"title\": \"alert_title\",\n  \"sourceKey\": \"584f2569\",\n  \"query\": \"MATCH (n1)-[r:DIRECTED]-(n2) RETURN n1, n1.score\",\n  \"dialect\": \"cypher\",\n  \"enabled\": true,\n  \"columns\": [\n    {\"type\": \"number\", \"columnName\": \"n1.score\", \"columnTitle\": \"Score\"}\n  ],\n  \"cron\": \"0 0 * * *\",\n  \"lastRun\": null,\n  \"lastRunProblem\": null,\n  \"updatedAt\": \"2016-05-16T08:23:35.730Z\",\n  \"createdAt\": \"2016-05-16T08:23:35.730Z\",\n  \"nextRun\": \"2016-08-15T00:00:00.000Z\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/alert.ts",
    "groupTitle": "Alerts",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the alert to get</p>"
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/:sourceKey/alerts/tree",
    "title": "Get the alert tree",
    "name": "GetAlertTree",
    "group": "Alerts",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "apiright:alert.read"
      }
    ],
    "description": "<p>Get the alerts and the alert folders in a tree structure.</p>",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the root alert folder (always <code>-1</code>)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"folder\""
            ],
            "optional": false,
            "field": "type",
            "description": "<p>Type of the item</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "title",
            "description": "<p>Title of the root alert folder</p>"
          },
          {
            "group": "Success 200",
            "type": "type:children[]",
            "optional": false,
            "field": "children",
            "description": "<p>An array of alert folders or alerts</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"id\": -1,\n  \"title\": \"root\",\n  \"type\": \"folder\",\n  \"children\": [\n    {\n      \"id\": 1,\n      \"title\": \"my 1st alert folder\",\n      \"type\": \"folder\",\n      \"children\": []\n    },\n    {\n      \"id\": 2,\n      \"title\": \"my 2nd alert folder\",\n      \"type\": \"folder\",\n      \"children\": [\n        {\n          \"id\": 2,\n          \"title\": \"another alert\",\n          \"type\": \"alert\"\n        },\n        {\n          \"id\": 3,\n          \"title\": \"yet another alert\",\n          \"type\": \"alert\"\n        }\n      ]\n    },\n    {\n      \"id\": 1,\n      \"title\": \"my alert\",\n      \"type\": \"alert\"\n    }\n  ]\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/alert.ts",
    "groupTitle": "Alerts",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/:dataSource/alerts/:alertId/matches/:matchId",
    "title": "Get a match",
    "name": "GetMatch",
    "group": "Alerts",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "apiright:alert.read"
      }
    ],
    "description": "<p>Get the match selected by id.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "alertId",
            "description": "<p>ID of the alert</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "matchId",
            "description": "<p>ID of the match</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/alert.ts",
    "groupTitle": "Alerts",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the match</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "alertId",
            "description": "<p>ID of the alert</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "hash",
            "description": "<p>Hash of the match</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"unconfirmed\"",
              "\"confirmed\"",
              "\"dismissed\""
            ],
            "optional": false,
            "field": "status",
            "description": "<p>Status of the match</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "user",
            "description": "<p>Last user that changed the status (<code>null</code> if it was never changed)</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "user.id",
            "description": "<p>ID of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "user.username",
            "description": "<p>Username of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "user.email",
            "description": "<p>E-mail of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "viewers",
            "description": "<p>Users that viewed the match (ordered by date in decreasing order)</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "viewers.id",
            "description": "<p>ID of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "viewers.username",
            "description": "<p>Username of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "viewers.email",
            "description": "<p>E-mail of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "viewers.date",
            "description": "<p>Date of the view in ISO-8601 format</p>"
          },
          {
            "group": "Success 200",
            "type": "string[]",
            "optional": false,
            "field": "nodes",
            "description": "<p>IDs of the nodes of the match</p>"
          },
          {
            "group": "Success 200",
            "type": "string[]",
            "optional": false,
            "field": "edges",
            "description": "<p>IDs of the edges of the match</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "columns",
            "description": "<p>Scalar value for a given column by index defined in the alert</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "expirationDate",
            "description": "<p>Date in ISO-8601 format after which the match is deleted</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "createdAt",
            "description": "<p>Creation date in ISO-8601 format</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "updatedAt",
            "description": "<p>Last update date in ISO-8601 format</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"id\": 1,\n  \"sourceKey\": \"584f2569\",\n  \"alertId\": 2,\n  \"hash\": \"897f54ff366922a4077c78955c77bcdd\",\n  \"status\": \"unconfirmed\",\n  \"user\": null,\n  \"viewers\": [],\n  \"nodes\": [5971, 5974],\n  \"edges\": [523],\n  \"columns\": [\n    1999\n  ],\n  \"expirationDate\": \"2016-05-26T08:23:35.730Z\",\n  \"createdAt\": \"2016-05-16T08:23:35.730Z\",\n  \"updatedAt\": \"2016-05-16T08:23:35.730Z\"\n}",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "get",
    "url": "/api/:dataSource/alerts/:alertId/matches/:matchId/actions",
    "title": "Get all the actions of a match",
    "name": "GetMatchActions",
    "group": "Alerts",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "apiright:alert.read"
      }
    ],
    "description": "<p>Get all the actions of a match ordered by creation date.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "alertId",
            "description": "<p>ID of the alert</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "matchId",
            "description": "<p>ID of the match</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "matchActions",
            "description": "<p>Actions</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "matchActions.id",
            "description": "<p>ID of the action</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "matchActions.matchId",
            "description": "<p>ID of the match</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "matchActions.user",
            "description": "<p>User that did the action</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "matchActions.user.id",
            "description": "<p>ID of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "matchActions.user.username",
            "description": "<p>Username of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "matchActions.user.email",
            "description": "<p>E-mail of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"open\"",
              "\"confirm\"",
              "\"dismiss\"",
              "\"unconfirm\""
            ],
            "optional": false,
            "field": "matchActions.action",
            "description": "<p>The action performed</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "matchActions.createdAt",
            "description": "<p>Creation date in ISO-8601 format</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "matchActions.updatedAt",
            "description": "<p>Last update date in ISO-8601 format</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n[\n  {\n    \"id\": 9,\n    \"matchId\": 3,\n    \"user\": {\n      \"id\": 1,\n      \"username\": \"alice\",\n      \"email\": \"alice@example.com\"\n    },\n    \"action\": \"dismiss\",\n    \"createdAt\": \"2016-06-16T08:22:35.730Z\",\n    \"updatedAt\": \"2016-06-16T08:22:35.730Z\"\n  },\n  {\n    \"id\": 8,\n    \"matchId\": 4,\n    \"user\": {\n      \"id\": 2,\n      \"username\": \"bob\",\n      \"email\": \"bob@example.com\"\n    },\n    \"action\": \"open\",\n    \"createdAt\": \"2016-05-16T08:23:35.730Z\",\n    \"updatedAt\": \"2016-05-16T08:23:35.730Z\"\n  }\n]",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/alert.ts",
    "groupTitle": "Alerts"
  },
  {
    "type": "get",
    "url": "/api/:dataSource/alerts/:alertId/matches",
    "title": "Get all the matches of an alert",
    "name": "GetMatches",
    "group": "Alerts",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "apiright:alert.read"
      }
    ],
    "description": "<p>Get all the matches of an alert.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "alertId",
            "description": "<p>ID the alert</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "offset",
            "defaultValue": "0",
            "description": "<p>Offset from the first result</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "limit",
            "defaultValue": "20",
            "description": "<p>Page size (maximum number of returned matches)</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"asc\"",
              "\"desc\""
            ],
            "optional": true,
            "field": "sort_direction",
            "defaultValue": "desc",
            "description": "<p>Direction used to sort</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"date\"",
              "\"0\"",
              "\"1\"",
              "\"2\"",
              "\"3\"",
              "\"4\""
            ],
            "optional": true,
            "field": "sort_by",
            "defaultValue": "date",
            "description": "<p>Sort by date or a given column</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"unconfirmed\"",
              "\"confirmed\"",
              "\"dismissed\""
            ],
            "optional": true,
            "field": "status",
            "description": "<p>Filter on match status</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/alert.ts",
    "groupTitle": "Alerts",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "counts",
            "description": "<p>Match counts</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "counts.unconfirmed",
            "description": "<p>Count of unconfirmed matches</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "counts.confirmed",
            "description": "<p>Count of confirmed matches</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "counts.dismissed",
            "description": "<p>Count of dismissed matches</p>"
          },
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "matches",
            "description": "<p>Matches</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "matches.id",
            "description": "<p>ID of the match</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "matches.sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "matches.alertId",
            "description": "<p>ID of the alert</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "matches.hash",
            "description": "<p>Hash of the match</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"unconfirmed\"",
              "\"confirmed\""
            ],
            "optional": false,
            "field": "matches.status",
            "description": "<p>Status of the match</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "matches.user",
            "description": "<p>Last user that changed the status (<code>null</code> if it was never changed)</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "matches.user.id",
            "description": "<p>ID of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "matches.user.username",
            "description": "<p>Username of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "matches.user.email",
            "description": "<p>E-mail of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "matches.viewers",
            "description": "<p>Users that viewed the match (ordered by date in decreasing order)</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "matches.viewers.id",
            "description": "<p>ID of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "matches.viewers.username",
            "description": "<p>Username of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "matches.viewers.email",
            "description": "<p>E-mail of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "matches.viewers.date",
            "description": "<p>Date of the view in ISO-8601 format</p>"
          },
          {
            "group": "Success 200",
            "type": "string[]",
            "optional": false,
            "field": "matches.nodes",
            "description": "<p>IDs of the nodes of the match</p>"
          },
          {
            "group": "Success 200",
            "type": "string[]",
            "optional": false,
            "field": "matches.edges",
            "description": "<p>IDs of the edges of the match</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "matches.columns",
            "description": "<p>Scalar value for a given column by index defined in the alert</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "matches.expirationDate",
            "description": "<p>Date in ISO-8601 format after which the match is deleted</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "matches.createdAt",
            "description": "<p>Creation date in ISO-8601 format</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "matches.updatedAt",
            "description": "<p>Last update date in ISO-8601 format</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"counts\": {\n    \"unconfirmed\": 1,\n    \"confirmed\": 1,\n    \"dismissed\": 0\n  },\n  \"matches\": [\n    {\n      \"id\": 1,\n      \"sourceKey\": \"584f2569\",\n      \"alertId\": 2,\n      \"hash\": \"897f54ff366922a4077c78955c77bcdd\",\n      \"status\": \"confirmed\",\n      \"user\": {\n        \"id\": 1,\n        \"username\": \"alice\",\n        \"email\": \"alice@example.com\"\n      },\n      \"viewers\": [\n        {\n          \"id\": 1,\n          \"username\": \"alice\",\n          \"email\": \"alice@example.com\",\n          \"date\": \"2016-05-16T08:13:35.030Z\"\n        }\n      ],\n      \"nodes\": [5971],\n      \"edges\": [],\n      \"columns\": [\n        1999\n      ],\n      \"expirationDate\": \"2016-05-26T08:23:35.730Z\",\n      \"createdAt\": \"2016-05-16T08:23:35.730Z\",\n      \"updatedAt\": \"2016-05-16T08:23:35.730Z\"\n    },\n    {\n      \"id\": 2,\n      \"sourceKey\": \"584f2569\",\n      \"alertId\": 2,\n      \"hash\": \"5f221db1e438f2d9b7cdd284364e379b\",\n      \"status\": \"unconfirmed\",\n      \"user\": null,\n      \"viewers\": [],\n      \"nodes\": [5976],\n      \"edges\": [],\n      \"columns\": [\n        1998\n      ],\n      \"expirationDate\": \"2016-05-26T08:23:35.730Z\",\n      \"createdAt\": \"2016-05-16T08:23:35.730Z\",\n      \"updatedAt\": \"2016-05-16T08:23:35.730Z\"\n    }\n  ]\n}",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "patch",
    "url": "/api/admin/:dataSource/alerts/:alertId",
    "title": "Update an alert",
    "name": "UpdateAlert",
    "group": "Alerts",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.alerts"
      }
    ],
    "description": "<p>Update the alert selected by id. Updating an alert will results in all the previous detected matches deleted.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "alertId",
            "description": "<p>ID of the alert</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "title",
            "description": "<p>New title of the alert</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "query",
            "description": "<p>New graph query that will run periodically</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "dialect",
            "description": "<p>Dialect of the graph query</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "enabled",
            "description": "<p>Whether the query will run periodically or not</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": true,
            "field": "folder",
            "description": "<p>ID of the alert folder (-1 for root folder)</p>"
          },
          {
            "group": "Parameter",
            "type": "object[]",
            "optional": true,
            "field": "columns",
            "description": "<p>Columns among the returned values of the query to save in a match as scalar values</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"number\"",
              "\"string\""
            ],
            "optional": false,
            "field": "columns.type",
            "description": "<p>Type of the column</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "columns.columnName",
            "description": "<p>Name of the column in the query</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "columns.columnTitle",
            "description": "<p>Name of the column for the UI</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "cron",
            "description": "<p>CRON expression representing the frequency with which the query runs</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": true,
            "field": "matchTTL",
            "description": "<p>Number of days after which the matches of this alert are going to be deleted</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": true,
            "field": "maxMatches",
            "description": "<p>Maximum number of matches after which matches with lower scores are discarded</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the alert</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "folder",
            "description": "<p>ID of the alert folder (-1 for root folder)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "title",
            "description": "<p>Title of the alert</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "query",
            "description": "<p>Graph query that will run periodically</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "dialect",
            "description": "<p>Dialect of the graph query</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "enabled",
            "description": "<p>Whether the query will run periodically or not</p>"
          },
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "columns",
            "description": "<p>Columns among the returned values of the query to save in a match as scalar values</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"number\"",
              "\"string\""
            ],
            "optional": false,
            "field": "columns.type",
            "description": "<p>Type of the column</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "columns.columnName",
            "description": "<p>Name of the column in the query</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "columns.columnTitle",
            "description": "<p>Name of the column for the UI</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "cron",
            "description": "<p>CRON expression representing the frequency with which the query runs</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "matchTTL",
            "description": "<p>Number of days after which the matches of this alert are going to be deleted</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "maxMatches",
            "description": "<p>Maximum number of matches after which matches with lower scores are discarded</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "userId",
            "description": "<p>ID of the user that created the alert</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "lastRun",
            "description": "<p>Last time the query was executed in ISO-8601 format (<code>null</code> it was never executed)</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "lastRunProblem",
            "description": "<p>Object representing the problem in the last run (<code>null</code> if there wasn't a problem in the last run)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "lastRunProblem.error",
            "description": "<p>Error that identifies the last run problem</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "lastRunProblem.partial",
            "description": "<p>Whether the last run was at least partially executed</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "createdAt",
            "description": "<p>Creation date in ISO-8601 format</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "updatedAt",
            "description": "<p>Last update date in ISO-8601 format</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "nextRun",
            "description": "<p>Date when the alert will be executed next in ISO-8601 format (<code>null</code> if it isn't scheduled)</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"id\": 8,\n  \"folder\": 4,\n  \"title\": \"alert_title\",\n  \"sourceKey\": \"584f2569\",\n  \"query\": \"MATCH (n1)-[r:DIRECTED]-(n2) RETURN n1, n1.score\",\n  \"dialect\": \"cypher\",\n  \"enabled\": true,\n  \"columns\": [\n    {\"type\": \"number\", \"columnName\": \"n1.score\", \"columnTitle\": \"Score\"}\n  ],\n  \"cron\": \"0 0 * * *\",\n  \"matchTTL\": 30,\n  \"maxMatches\": 20,\n  \"userId\": 1,\n  \"lastRun\": null,\n  \"lastRunProblem\": null,\n  \"updatedAt\": \"2016-05-16T08:23:35.730Z\",\n  \"createdAt\": \"2016-05-16T08:23:35.730Z\",\n  \"nextRun\": \"2016-08-15T00:00:00.000Z\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/alert.ts",
    "groupTitle": "Alerts"
  },
  {
    "type": "patch",
    "url": "/api/admin/:sourceKey/alerts/folder/:id",
    "title": "Update an alert folder",
    "name": "UpdateAlertFolder",
    "group": "Alerts",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.alerts"
      }
    ],
    "description": "<p>Update an alert folder.</p>",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 204 No Content",
          "type": "none"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/alert.ts",
    "groupTitle": "Alerts",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the alert folder to modify</p>"
          },
          {
            "group": "Parameter",
            "type": "-1",
            "optional": true,
            "field": "parent",
            "description": "<p>ID of the parent alert folder</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "title",
            "description": "<p>Title</p>"
          }
        ]
      }
    }
  },
  {
    "type": "post",
    "url": "/api/admin/applications",
    "title": "Create an application",
    "name": "CreateApplication",
    "group": "Applications",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.app"
      }
    ],
    "description": "<p>Add a new API application.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the application</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "enabled",
            "defaultValue": "true",
            "description": "<p>Whether the application is enabled</p>"
          },
          {
            "group": "Parameter",
            "type": "number[]",
            "optional": false,
            "field": "groups",
            "description": "<p>IDs of the groups the application can act on behalf of</p>"
          },
          {
            "group": "Parameter",
            "type": "string[]",
            "allowedValues": [
              "\"visualization.read\"",
              "\"visualization.create\"",
              "\"visualization.edit\"",
              "\"visualization.delete\"",
              "\"visualization.list\"",
              "\"visualizationFolder.create\"",
              "\"visualizationFolder.edit\"",
              "\"visualizationFolder.delete\"",
              "\"visualizationShare.read\"",
              "\"visualizationShare.create\"",
              "\"visualizationShare.delete\"",
              "\"sandbox\"",
              "\"widget.read\"",
              "\"widget.create\"",
              "\"widget.edit\"",
              "\"widget.delete\"",
              "\"graphItem.read\"",
              "\"graphItem.create\"",
              "\"graphItem.edit\"",
              "\"graphItem.delete\"",
              "\"graphItem.search\"",
              "\"savedGraphQuery.read\"",
              "\"savedGraphQuery.create\"",
              "\"savedGraphQuery.edit\"",
              "\"savedGraphQuery.delete\"",
              "\"graph.rawRead\"",
              "\"graph.rawWrite\"",
              "\"alert.read\"",
              "\"alert.doAction\"",
              "\"schema\"",
              "\"admin.index\""
            ],
            "optional": false,
            "field": "rights",
            "description": "<p>Enabled actions for the application</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/applications.js",
    "groupTitle": "Applications",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the application</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the application</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "apiKey",
            "description": "<p>Generated key (32 hexadecimal characters)</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "enabled",
            "description": "<p>Whether the application is enabled</p>"
          },
          {
            "group": "Success 200",
            "type": "string[]",
            "optional": false,
            "field": "rights",
            "description": "<p>Enabled actions for the application</p>"
          },
          {
            "group": "Success 200",
            "type": "type:group[]",
            "optional": false,
            "field": "groups",
            "description": "<p>Groups the application can act on behalf of</p>"
          },
          {
            "group": "Success 200",
            "type": "string[]",
            "optional": false,
            "field": "createdAt",
            "description": "<p>Creation date in ISO-8601 format</p>"
          },
          {
            "group": "Success 200",
            "type": "string[]",
            "optional": false,
            "field": "updatedAt",
            "description": "<p>Last update date in ISO-8601 format</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"id\": 1,\n  \"enabled\": true,\n  \"apiKey\": \"76554081e5b0a2d7852deec4990ebc58\",\n  \"name\": \"test_app\",\n  \"rights\": [\n    \"visualization.create\",\n    \"visualization.edit\",\n    \"visualization.read\",\n    \"visualization.delete\"\n  ],\n  \"groups\": [\n    {\n      \"id\": 3,\n      \"name\": \"read and edit\",\n      \"builtin\": true,\n      \"sourceKey\": \"584f2569\"\n    }\n  ],\n  \"createdAt\": \"2017-01-24T11:16:03.445Z\",\n  \"updatedAt\": \"2017-01-24T11:16:03.445Z\"\n}",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "get",
    "url": "/api/admin/applications",
    "title": "Get all the applications",
    "name": "GetApplications",
    "group": "Applications",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.app"
      }
    ],
    "description": "<p>Get all the API applications.</p>",
    "version": "0.0.0",
    "filename": "server/routes/admin/applications.js",
    "groupTitle": "Applications",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "applications",
            "description": "<p>Applications</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "applications.id",
            "description": "<p>ID of the application</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "applications.name",
            "description": "<p>Name of the application</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "applications.apiKey",
            "description": "<p>Generated key (32 hexadecimal characters)</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "applications.enabled",
            "description": "<p>Whether the application is enabled</p>"
          },
          {
            "group": "Success 200",
            "type": "string[]",
            "optional": false,
            "field": "applications.rights",
            "description": "<p>Enabled actions for the application</p>"
          },
          {
            "group": "Success 200",
            "type": "type:group[]",
            "optional": false,
            "field": "applications.groups",
            "description": "<p>Groups the application can act on behalf of</p>"
          },
          {
            "group": "Success 200",
            "type": "string[]",
            "optional": false,
            "field": "applications.createdAt",
            "description": "<p>Creation date in ISO-8601 format</p>"
          },
          {
            "group": "Success 200",
            "type": "string[]",
            "optional": false,
            "field": "applications.updatedAt",
            "description": "<p>Last update date in ISO-8601 format</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n[\n  {\n    \"id\": 1,\n    \"enabled\": true,\n    \"apiKey\": \"e3fadcbd39ddb21fe8ecb206dadff36d\",\n    \"name\": \"test_app\",\n    \"rights\": [\n      \"visualization.create\",\n      \"visualization.edit\",\n      \"visualization.read\",\n      \"visualization.delete\"\n    ],\n    \"groups\": [\n      {\n        \"id\": 3,\n        \"name\": \"read and edit\",\n        \"builtin\": true,\n        \"sourceKey\": \"584f2569\"\n      }\n    ],\n    \"createdAt\": \"2017-01-24T11:14:51.337Z\",\n    \"updatedAt\": \"2017-01-24T11:31:13.769Z\"\n  },\n  {\n    \"id\": 2,\n    \"enabled\": true,\n    \"apiKey\": \"738c9f3b66aad7218c69843a78905ccd\",\n    \"name\": \"test_app_2\",\n    \"rights\": [\n      \"visualization.read\"\n    ],\n    \"groups\": [\n      {\n        \"id\": 2,\n        \"name\": \"read\",\n        \"builtin\": true,\n        \"sourceKey\": \"584f2569\"\n      }\n    ],\n    \"createdAt\": \"2017-01-24T11:16:02.417Z\",\n    \"updatedAt\": \"2017-01-24T11:16:02.417Z\"\n  }\n]",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "patch",
    "url": "/api/admin/applications/:id",
    "title": "Update an application",
    "name": "UpdateApplication",
    "group": "Applications",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.app"
      }
    ],
    "description": "<p>Update an API application.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "name",
            "description": "<p>Name of the application</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "enabled",
            "defaultValue": "true",
            "description": "<p>Whether the application is enabled</p>"
          },
          {
            "group": "Parameter",
            "type": "number[]",
            "optional": true,
            "field": "groups",
            "description": "<p>IDs of the groups the application can act on behalf of</p>"
          },
          {
            "group": "Parameter",
            "type": "string[]",
            "allowedValues": [
              "\"visualization.read\"",
              "\"visualization.create\"",
              "\"visualization.edit\"",
              "\"visualization.delete\"",
              "\"visualization.list\"",
              "\"visualizationFolder.create\"",
              "\"visualizationFolder.edit\"",
              "\"visualizationFolder.delete\"",
              "\"visualizationShare.read\"",
              "\"visualizationShare.create\"",
              "\"visualizationShare.delete\"",
              "\"sandbox\"",
              "\"widget.read\"",
              "\"widget.create\"",
              "\"widget.edit\"",
              "\"widget.delete\"",
              "\"graphItem.read\"",
              "\"graphItem.create\"",
              "\"graphItem.edit\"",
              "\"graphItem.delete\"",
              "\"graphItem.search\"",
              "\"savedGraphQuery.read\"",
              "\"savedGraphQuery.create\"",
              "\"savedGraphQuery.edit\"",
              "\"savedGraphQuery.delete\"",
              "\"graph.rawRead\"",
              "\"graph.rawWrite\"",
              "\"alert.read\"",
              "\"alert.doAction\"",
              "\"schema\""
            ],
            "optional": true,
            "field": "rights",
            "description": "<p>Enabled actions for the application</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/applications.js",
    "groupTitle": "Applications",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the application</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the application</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "apiKey",
            "description": "<p>Generated key (32 hexadecimal characters)</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "enabled",
            "description": "<p>Whether the application is enabled</p>"
          },
          {
            "group": "Success 200",
            "type": "string[]",
            "optional": false,
            "field": "rights",
            "description": "<p>Enabled actions for the application</p>"
          },
          {
            "group": "Success 200",
            "type": "type:group[]",
            "optional": false,
            "field": "groups",
            "description": "<p>Groups the application can act on behalf of</p>"
          },
          {
            "group": "Success 200",
            "type": "string[]",
            "optional": false,
            "field": "createdAt",
            "description": "<p>Creation date in ISO-8601 format</p>"
          },
          {
            "group": "Success 200",
            "type": "string[]",
            "optional": false,
            "field": "updatedAt",
            "description": "<p>Last update date in ISO-8601 format</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"id\": 1,\n  \"enabled\": true,\n  \"apiKey\": \"76554081e5b0a2d7852deec4990ebc58\",\n  \"name\": \"test_app\",\n  \"rights\": [\n    \"visualization.create\",\n    \"visualization.edit\",\n    \"visualization.read\",\n    \"visualization.delete\"\n  ],\n  \"groups\": [\n    {\n      \"id\": 3,\n      \"name\": \"read and edit\",\n      \"builtin\": true,\n      \"sourceKey\": \"584f2569\"\n    }\n  ],\n  \"createdAt\": \"2017-01-24T11:16:03.445Z\",\n  \"updatedAt\": \"2017-01-24T11:16:03.445Z\"\n}",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "get",
    "url": "/api/auth/me",
    "title": "Get current user",
    "name": "GetCurrentUser",
    "group": "Auth",
    "permission": [
      {
        "name": "guest_user",
        "title": "Guest user",
        "description": "<p>The guest user can use this API if guest mode is allowed.</p>"
      }
    ],
    "description": "<p>Get the profile of the current user.</p>",
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 401 Unauthorized\n{\n  \"key\": \"unauthorized\",\n  \"message\": \"Unauthorized.\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/auth.js",
    "groupTitle": "Auth",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "username",
            "description": "<p>Username of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "email",
            "description": "<p>E-mail of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "source",
            "description": "<p>Source of the user (<code>&quot;local&quot;</code>, <code>&quot;ldap&quot;</code>, <code>&quot;oauth2&quot;</code>, etc.)</p>"
          },
          {
            "group": "Success 200",
            "type": "type:group[]",
            "optional": false,
            "field": "groups",
            "description": "<p>Groups the user belongs to</p>"
          },
          {
            "group": "Success 200",
            "type": "type:preferences",
            "optional": false,
            "field": "preferences",
            "description": "<p>Preferences of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "actions",
            "description": "<p>Arrays of authorized actions indexed by data-source key The special key <code>&quot;*&quot;</code> lists actions authorized on all the data-sources</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "accessRights",
            "description": "<p>Arrays of authorized node categories and edge types indexed by data-source key, by type and by right The special key <code>&quot;*&quot;</code> lists access rights authorized on all the data-sources</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "createdAt",
            "description": "<p>Creation date in ISO-8601 format</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "updatedAt",
            "description": "<p>Last update date in ISO-8601 format</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"id\": 1,\n  \"username\": \"Unique user\",\n  \"email\": \"user@linkurio.us\",\n  \"source\": \"local\",\n  \"groups\": [\n    {\n      \"id\": 1,\n      \"name\": \"admin\",\n      \"builtin\": true,\n      \"sourceKey\": \"*\"\n    }\n  ],\n  \"preferences\": {\n    \"pinOnDrag\": false,\n    \"locale\": \"en-US\",\n    \"incrementalLayout\": false\n  },\n  \"actions\": {\n    \"*\": [\n      \"admin.users\",\n      \"admin.alerts\",\n      \"admin.connect\",\n      \"admin.index\",\n      \"admin.app\",\n      \"admin.report\",\n      \"admin.schema\",\n      \"admin.users.delete\",\n      \"admin.config\",\n      \"rawReadQuery\",\n      \"rawWriteQuery\"\n    ]\n  },\n  \"accessRights\": {\n    \"*\": {\n      \"nodes\": {\n        \"edit\": [],\n        \"write\": [\"*\"]\n      },\n      \"edges\": {\n        \"edit\": [],\n        \"write\": [\"*\"]\n      },\n      \"alerts\": {\n        \"read\": [\"*\"]\n      }\n    }\n  },\n  \"createdAt\": \"2016-05-16T08:23:35.730Z\",\n  \"updatedAt\": \"2016-05-16T08:23:45.730Z\"\n}",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "get",
    "url": "/api/auth/authenticated",
    "title": "Check if authenticated",
    "name": "IsAuthenticated",
    "group": "Auth",
    "description": "<p>Check if a user is authenticated.</p>",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 204 No Content",
          "type": "none"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 401 Unauthorized\n{\n  \"key\": \"unauthorized\",\n  \"message\": \"Unauthorized.\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/auth.js",
    "groupTitle": "Auth"
  },
  {
    "type": "post",
    "url": "/api/auth/login",
    "title": "Login",
    "name": "Login",
    "group": "Auth",
    "description": "<p>Log a user in by e-mail or username and password and return it.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "usernameOrEmail",
            "description": "<p>User e-mail or username</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "password",
            "description": "<p>User password</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/auth.js",
    "groupTitle": "Auth",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "username",
            "description": "<p>Username of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "email",
            "description": "<p>E-mail of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "source",
            "description": "<p>Source of the user (<code>&quot;local&quot;</code>, <code>&quot;ldap&quot;</code>, <code>&quot;oauth2&quot;</code>, etc.)</p>"
          },
          {
            "group": "Success 200",
            "type": "type:group[]",
            "optional": false,
            "field": "groups",
            "description": "<p>Groups the user belongs to</p>"
          },
          {
            "group": "Success 200",
            "type": "type:preferences",
            "optional": false,
            "field": "preferences",
            "description": "<p>Preferences of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "actions",
            "description": "<p>Arrays of authorized actions indexed by data-source key The special key <code>&quot;*&quot;</code> lists actions authorized on all the data-sources</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "accessRights",
            "description": "<p>Arrays of authorized node categories and edge types indexed by data-source key, by type and by right The special key <code>&quot;*&quot;</code> lists access rights authorized on all the data-sources</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "createdAt",
            "description": "<p>Creation date in ISO-8601 format</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "updatedAt",
            "description": "<p>Last update date in ISO-8601 format</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"id\": 1,\n  \"username\": \"Unique user\",\n  \"email\": \"user@linkurio.us\",\n  \"source\": \"local\",\n  \"groups\": [\n    {\n      \"id\": 1,\n      \"name\": \"admin\",\n      \"builtin\": true,\n      \"sourceKey\": \"*\"\n    }\n  ],\n  \"preferences\": {\n    \"pinOnDrag\": false,\n    \"locale\": \"en-US\",\n    \"incrementalLayout\": false\n  },\n  \"actions\": {\n    \"*\": [\n      \"admin.users\",\n      \"admin.alerts\",\n      \"admin.connect\",\n      \"admin.index\",\n      \"admin.app\",\n      \"admin.report\",\n      \"admin.schema\",\n      \"admin.users.delete\",\n      \"admin.config\",\n      \"rawReadQuery\",\n      \"rawWriteQuery\"\n    ]\n  },\n  \"accessRights\": {\n    \"*\": {\n      \"nodes\": {\n        \"edit\": [],\n        \"write\": [\"*\"]\n      },\n      \"edges\": {\n        \"edit\": [],\n        \"write\": [\"*\"]\n      },\n      \"alerts\": {\n        \"read\": [\"*\"]\n      }\n    }\n  },\n  \"createdAt\": \"2016-05-16T08:23:35.730Z\",\n  \"updatedAt\": \"2016-05-16T08:23:45.730Z\"\n}",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "post",
    "url": "/api/auth/loginRedirect",
    "title": "Login and redirect",
    "name": "LoginRedirect",
    "group": "Auth",
    "description": "<p>Log a user in by e-mail or username and password and redirect it to a given path.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "usernameOrEmail",
            "description": "<p>User e-mail or username</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "password",
            "description": "<p>User password</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "path",
            "defaultValue": "/",
            "description": "<p>Path to redirect to</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "errorPath",
            "defaultValue": "path",
            "description": "<p>Path to redirect to in case of error</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 302 Redirect\nLocation: /",
          "type": "none"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/auth.js",
    "groupTitle": "Auth"
  },
  {
    "type": "get",
    "url": "/api/auth/sso/login",
    "title": "Login via OAuth2 or SAML2",
    "name": "LoginSSO",
    "group": "Auth",
    "description": "<p>Redirect the user to the OAuth2 or SAML2 provider for authorization.</p>",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 302 Redirect",
          "type": "none"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/auth.js",
    "groupTitle": "Auth"
  },
  {
    "type": "get",
    "url": "/api/auth/logout",
    "title": "Logout",
    "name": "Logout",
    "group": "Auth",
    "description": "<p>Log the current user out.</p>",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 204 No Content",
          "type": "none"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/auth.js",
    "groupTitle": "Auth"
  },
  {
    "type": "patch",
    "url": "/api/auth/me",
    "title": "Update current user",
    "name": "UpdateCurrentUser",
    "group": "Auth",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      }
    ],
    "description": "<p>Update the current user.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "username",
            "description": "<p>New username</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "email",
            "description": "<p>New e-mail</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "password",
            "description": "<p>New password</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": true,
            "field": "preferences",
            "description": "<p>New user preferences</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/auth.js",
    "groupTitle": "Auth",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "username",
            "description": "<p>Username of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "email",
            "description": "<p>E-mail of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "source",
            "description": "<p>Source of the user (<code>&quot;local&quot;</code>, <code>&quot;ldap&quot;</code>, <code>&quot;oauth2&quot;</code>, etc.)</p>"
          },
          {
            "group": "Success 200",
            "type": "type:group[]",
            "optional": false,
            "field": "groups",
            "description": "<p>Groups the user belongs to</p>"
          },
          {
            "group": "Success 200",
            "type": "type:preferences",
            "optional": false,
            "field": "preferences",
            "description": "<p>Preferences of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "actions",
            "description": "<p>Arrays of authorized actions indexed by data-source key The special key <code>&quot;*&quot;</code> lists actions authorized on all the data-sources</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "accessRights",
            "description": "<p>Arrays of authorized node categories and edge types indexed by data-source key, by type and by right The special key <code>&quot;*&quot;</code> lists access rights authorized on all the data-sources</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "createdAt",
            "description": "<p>Creation date in ISO-8601 format</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "updatedAt",
            "description": "<p>Last update date in ISO-8601 format</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"id\": 1,\n  \"username\": \"Unique user\",\n  \"email\": \"user@linkurio.us\",\n  \"source\": \"local\",\n  \"groups\": [\n    {\n      \"id\": 1,\n      \"name\": \"admin\",\n      \"builtin\": true,\n      \"sourceKey\": \"*\"\n    }\n  ],\n  \"preferences\": {\n    \"pinOnDrag\": false,\n    \"locale\": \"en-US\",\n    \"incrementalLayout\": false\n  },\n  \"actions\": {\n    \"*\": [\n      \"admin.users\",\n      \"admin.alerts\",\n      \"admin.connect\",\n      \"admin.index\",\n      \"admin.app\",\n      \"admin.report\",\n      \"admin.schema\",\n      \"admin.users.delete\",\n      \"admin.config\",\n      \"rawReadQuery\",\n      \"rawWriteQuery\"\n    ]\n  },\n  \"accessRights\": {\n    \"*\": {\n      \"nodes\": {\n        \"edit\": [],\n        \"write\": [\"*\"]\n      },\n      \"edges\": {\n        \"edit\": [],\n        \"write\": [\"*\"]\n      },\n      \"alerts\": {\n        \"read\": [\"*\"]\n      }\n    }\n  },\n  \"createdAt\": \"2016-05-16T08:23:35.730Z\",\n  \"updatedAt\": \"2016-05-16T08:23:45.730Z\"\n}",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "post",
    "url": "/api/admin/source/:dataSourceIndex/connect",
    "title": "Connect a disconnected data-source",
    "name": "ReconnectSource",
    "group": "DataSources",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.connect"
      }
    ],
    "description": "<p>Connect a disconnected data-source</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSourceIndex",
            "description": "<p>config-index of a data-source</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/source.js",
    "groupTitle": "DataSources"
  },
  {
    "type": "post",
    "url": "/api/admin/source/:dataSource/resetDefaults",
    "title": "Reset settings for new visualizations",
    "name": "ResetSourceStyles",
    "group": "DataSources",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.styles"
      }
    ],
    "description": "<p>Reset design and/or captions of all sandboxes of the given data-source to default values. If <code>design</code> is true, set <code>design.palette</code> and <code>design.styles</code> to default <code>palette</code> and <code>defaultStyles</code> of the data-source. If <code>captions</code> is true, set <code>nodeFields.captions</code> and <code>edgeFields.captions</code> to current <code>defaultCaptions.nodes</code> and <code>defaultCaptions.edges</code> of the data-source.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": false,
            "field": "design",
            "description": "<p>Whether to reset default design to default values</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": false,
            "field": "captions",
            "description": "<p>Whether to reset default captions to default values</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/source.js",
    "groupTitle": "DataSources"
  },
  {
    "type": "post",
    "url": "/api/admin/source/:dataSource/setDefaults",
    "title": "Set default styles and captions",
    "name": "SetDefaultSourceStyles",
    "group": "DataSources",
    "permission": [
      {
        "name": "action:admin.styles"
      }
    ],
    "description": "<p>Set default design styles and/or captions for the given data-source.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": true,
            "field": "styles",
            "description": "<p>New default styles for the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "type:NodeStyle[]",
            "optional": false,
            "field": "styles.node",
            "description": "<p>Node styles</p>"
          },
          {
            "group": "Parameter",
            "type": "type:EdgeStyle[]",
            "optional": false,
            "field": "styles.edge",
            "description": "<p>Edge styles</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": true,
            "field": "captions",
            "description": "<p>New default captions for the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "type:NodeCaption",
            "optional": false,
            "field": "captions.nodes",
            "description": "<p>Nodes captions</p>"
          },
          {
            "group": "Parameter",
            "type": "type:EdgeCaption",
            "optional": false,
            "field": "captions.edges",
            "description": "<p>Edges captions</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/source.js",
    "groupTitle": "DataSources"
  },
  {
    "type": "post",
    "url": "/api/admin/sources/config",
    "title": "Create a new data-source configuration",
    "name": "createSourceConfig",
    "group": "DataSources",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.config"
      }
    ],
    "description": "<p>Create a new data-source configuration (contains a graph database configuration and an index configuration).</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": false,
            "field": "graphDb",
            "description": "<p>The configuration options of the graph database</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "graphDb.vendor",
            "description": "<p>The vendor of the graph database (<code>&quot;neo4j&quot;</code>, ...)</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": false,
            "field": "index",
            "description": "<p>The configuration options of the index</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": false,
            "field": "index.vendor",
            "description": "<p>The vendor of the index (<code>&quot;elasticSearch&quot;</code>)</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "index.host",
            "description": "<p>Host of the index server</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "index.port",
            "description": "<p>Port of the index server</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": false,
            "field": "index.forceReindex",
            "description": "<p>Whether to re-index this graph database at each start of Linkurious</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": false,
            "field": "index.dynamicMapping",
            "description": "<p>Whether to enable automatic property-types detection for enhanced search</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/source.js",
    "groupTitle": "DataSources"
  },
  {
    "type": "delete",
    "url": "/api/admin/sources/config/:configIndex",
    "title": "Delete a data-source configuration",
    "name": "deleteSourceConfig",
    "group": "DataSources",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.config"
      }
    ],
    "description": "<p>Delete a data-source configuration that has currently no connected data-source.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "configIndex",
            "description": "<p>Index of a data-source configuration</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/source.js",
    "groupTitle": "DataSources"
  },
  {
    "type": "delete",
    "url": "/api/admin/sources/data/:sourceKey",
    "title": "Delete all data-source data",
    "name": "deleteSourceData",
    "group": "DataSources",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.config"
      }
    ],
    "description": "<p>Delete all data of data-source (visualizations, access rights, widgets, full-text indexes). Optionally merge visualizations and widgets into another data-source instead of deleting them. Warning: when merging into another data-source, visualizations may break if node and edge IDs are not the same in to target data-source.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of a disconnected data-source which data must be deleted</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "merge_into",
            "description": "<p>Key of the data-source to merge visualizations and widgets into</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "migrated",
            "description": "<p>True if the affected items have been migrated to another data-source, false if they have been deleted</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "affected",
            "description": "<p>Affected object counts</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "affected.visualizations",
            "description": "<p>Number of migrated/deleted visualizations (with their widgets)</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "affected.folders",
            "description": "<p>Number of migrated/deleted visualization folders</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "affected.alerts",
            "description": "<p>Number of migrated/deleted alerts</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "affected.matches",
            "description": "<p>Number of migrated/deleted matches</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "affected.graphQueries",
            "description": "<p>Number of migrated/deleted graph queries</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/source.js",
    "groupTitle": "DataSources"
  },
  {
    "type": "get",
    "url": "/api/admin/sources",
    "title": "Get all data-sources information",
    "name": "getAllSourceInfo",
    "group": "DataSources",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.config"
      }
    ],
    "description": "<p>Get information for all data-source, including data-sources that do not exist online.</p>",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "sources",
            "description": "<p>Data-source information</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "sources.lastSeen",
            "description": "<p>Last time this data-source was seen online (ISO-8601 date)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "sources.lastIndexed",
            "description": "<p>Last time this data-source was indexed (ISO-8601 date)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "sources.lastSampled",
            "description": "<p>Last time this data-source was sampled (ISO-8601 date)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "sources.key",
            "description": "<p>Key of the data-source (when is has been connected before, <code>null</code> otherwise)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "sources.host",
            "description": "<p>Host of the data-source</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "sources.port",
            "description": "<p>Port of the data-source</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "sources.storeId",
            "description": "<p>Unique store identifier of the graph database (when it has been connected before, <code>null</code> otherwise)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "sources.state",
            "description": "<p>State code if the data-source (<code>&quot;ready&quot;</code> , <code>&quot;offline&quot;</code> ...)</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "sources.visualizationCount",
            "description": "<p>Number of visualizations that exist for this data-source</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "sources.configIndex",
            "description": "<p>The index of the data-source's config (if the config still exists, <code>null</code> otherwise)</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/source.js",
    "groupTitle": "DataSources"
  },
  {
    "type": "get",
    "url": "/api/admin/source/:dataSource/noIndex/edgeProperties",
    "title": "Get non-indexed edge-properties",
    "name": "getNoIndexEdgeProperties",
    "group": "DataSources",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.config"
      }
    ],
    "description": "<p>Get the list of edge-properties that re not indexed for the given data-source.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/source.js",
    "groupTitle": "DataSources"
  },
  {
    "type": "get",
    "url": "/api/admin/source/:dataSource/noIndex/nodeProperties",
    "title": "Get non-indexed node-properties",
    "name": "getNoIndexNodeProperties",
    "group": "DataSources",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.config"
      }
    ],
    "description": "<p>Get the list of node-properties that are not indexed for the given data-source.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/source.js",
    "groupTitle": "DataSources"
  },
  {
    "type": "put",
    "url": "/api/admin/source/:dataSource/noIndex/edgeProperties",
    "title": "Set non-indexed edge-properties",
    "name": "setNoIndexEdgeProperties",
    "group": "DataSources",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.config"
      }
    ],
    "description": "<p>Set the list of edge-properties that are not indexed for the given data-source.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "string[]",
            "optional": false,
            "field": "properties",
            "description": "<p>List of property names</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/source.js",
    "groupTitle": "DataSources"
  },
  {
    "type": "put",
    "url": "/api/admin/source/:dataSource/noIndex/nodeProperties",
    "title": "Set non-indexed node-properties",
    "name": "setNoIndexNodeProperties",
    "group": "DataSources",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.config"
      }
    ],
    "description": "<p>Set the list of node-properties that are not indexed for the given data-source.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "string[]",
            "optional": false,
            "field": "properties",
            "description": "<p>List of property names</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/source.js",
    "groupTitle": "DataSources"
  },
  {
    "type": "post",
    "url": "/api/:sourceKey/graph/edges",
    "title": "Create an edge",
    "name": "CreateEdge",
    "group": "Edges",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "apiright:graphItem.create"
      }
    ],
    "description": "<p>Add an edge to the graph.</p>",
    "success": {
      "fields": {
        "Success 201": [
          {
            "group": "Success 201",
            "type": "string",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the edge</p>"
          },
          {
            "group": "Success 201",
            "type": "string",
            "optional": false,
            "field": "source",
            "description": "<p>ID of the source node</p>"
          },
          {
            "group": "Success 201",
            "type": "string",
            "optional": false,
            "field": "target",
            "description": "<p>ID of the target node</p>"
          },
          {
            "group": "Success 201",
            "type": "string",
            "optional": false,
            "field": "type",
            "description": "<p>Type of the edge</p>"
          },
          {
            "group": "Success 201",
            "type": "object",
            "optional": false,
            "field": "data",
            "description": "<p>Properties of the edge</p>"
          },
          {
            "group": "Success 201",
            "type": "number",
            "optional": false,
            "field": "readAt",
            "description": "<p>Read timestamp in epoch time</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 201 Created\n{\n  \"id\": \"1\",\n  \"source\": \"1\",\n  \"target\": \"2\",\n  \"type\": \"my_link\",\n  \"data\": {\n    \"direction\": \"north\"\n  },\n  \"readAt\": 692362800000\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/graphEdge.ts",
    "groupTitle": "Edges",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "source",
            "description": "<p>ID of the source node</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "target",
            "description": "<p>ID of the target node</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "type",
            "description": "<p>Type of the edge</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": false,
            "field": "properties",
            "description": "<p>Properties of the edge</p>"
          }
        ]
      }
    }
  },
  {
    "type": "delete",
    "url": "/api/:dataSource/graph/edges/:id",
    "title": "Delete an edge",
    "name": "DeleteEdge",
    "group": "Edges",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "apiright:graphItem.delete"
      }
    ],
    "description": "<p>Delete an edge from the graph.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the edge to delete</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 204 No Content",
          "type": "none"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/graphEdge.ts",
    "groupTitle": "Edges"
  },
  {
    "type": "get|post",
    "url": "/api/:dataSource/graph/edges/:id",
    "title": "Get an edge",
    "name": "GetEdge",
    "group": "Edges",
    "permission": [
      {
        "name": "guest_user",
        "title": "Guest user",
        "description": "<p>The guest user can use this API if guest mode is allowed.</p>"
      },
      {
        "name": "apiright:graphItem.read"
      }
    ],
    "description": "<p>Get an edge of the graph. A subgraph made of the edge and its extremities is returned.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the edge</p>"
          },
          {
            "group": "Parameter",
            "type": "string[]",
            "optional": true,
            "field": "edgesTo",
            "description": "<p>IDs of nodes that are already visible (they won't be included in the result, but their adjacent edges will be included in the <code>edges</code> field if the other nodes are in <code>nodes</code>)</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "withDigest",
            "defaultValue": "false",
            "description": "<p>Whether to include the adjacency digest in the returned nodes</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "withDegree",
            "defaultValue": "false",
            "description": "<p>Whether to include the degree in the returned nodes</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/graphEdge.ts",
    "groupTitle": "Edges",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "nodes",
            "description": "<p>Nodes</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "nodes.id",
            "description": "<p>ID of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "nodes.data",
            "description": "<p>Properties of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "string[]",
            "optional": false,
            "field": "nodes.categories",
            "description": "<p>Categories of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "nodes.readAt",
            "description": "<p>Read timestamp in epoch time</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": true,
            "field": "nodes.statistics",
            "description": "<p>Statistics of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "type:LkDigestItem[]",
            "optional": true,
            "field": "nodes.statistics.digest",
            "description": "<p>Statistics of the neighborhood of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": true,
            "field": "nodes.statistics.degree",
            "description": "<p>Number of neighbors of the node readable by the current user</p>"
          },
          {
            "group": "Success 200",
            "type": "type:LkEdgeDigestItem[]",
            "optional": true,
            "field": "nodes.statistics.supernodeDigest",
            "description": "<p>Simplified statistics of the neighborhood of the node (alternative to <code>digest</code> for supernodes)</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": true,
            "field": "nodes.statistics.supernodeDegree",
            "description": "<p>Number of adjacent edges of the node (alternative to <code>degree</code> for supernodes)</p>"
          },
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "edges",
            "description": "<p>Edges</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "edges.id",
            "description": "<p>ID of the edge</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "edges.data",
            "description": "<p>Properties of the edge</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "edges.type",
            "description": "<p>Type of the edge</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "edges.source",
            "description": "<p>ID of the source node</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "edges.target",
            "description": "<p>ID of the target node</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "edges.readAt",
            "description": "<p>Read timestamp in epoch time</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"nodes\": [\n    {\n      \"id\": 1,\n      \"data\": {\n        \"name\": \"Keanu Reeves\",\n        \"born\": {\n          \"type\": \"date\",\n          \"value\": \"1964-09-02T00:00:00.000Z\"\n        }\n      },\n      \"categories\": [\n        \"Person\"\n      ],\n      \"statistics\": {\n        \"digest\": [\n          {\n            \"nodeCategories\": [\n              \"Movie\",\n              \"TheMatrix\",\n              \"TheMatrixReloaded\"\n            ],\n            \"edgeType\": \"ACTED_IN\",\n            \"nodes\": 3,\n            \"edges\": 3\n          }\n        ]\n      },\n      \"readAt\": 692362800000\n    },\n    {\n      \"id\": 2,\n      \"data\": {\n        \"title\": \"The Matrix\",\n        \"release\": 1999\n      },\n      \"categories\": [\n        \"Movie\"\n      ],\n      \"statistics\": {\n        \"digest\": [\n          {\n            \"nodeCategories\": [\n              \"Person\"\n            ],\n            \"edgeType\": \"ACTED_IN\",\n            \"nodes\": 2,\n            \"edges\": 2\n          }\n        ]\n      },\n      \"readAt\": 692362800000\n    }\n  ],\n  \"edges\": [\n    {\n      \"id\": 100,\n      \"type\": \"ACTED_IN\",\n      \"source\": 1,\n      \"target\": 2,\n      \"data\": {\n        \"role\": \"Neo\"\n      },\n      \"readAt\": 692362800000\n    }\n  ]\n}",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "get",
    "url": "/api/:dataSource/graph/edges/count",
    "title": "Get edges count",
    "name": "GetEdgesCount",
    "group": "Edges",
    "permission": [
      {
        "name": "guest_user",
        "title": "Guest user",
        "description": "<p>The guest user can use this API if guest mode is allowed.</p>"
      },
      {
        "name": "apiright:graphItem.read"
      }
    ],
    "description": "<p>Get the number of edges in the graph.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "count",
            "description": "<p>The number of edges</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"count\": 42\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/graphEdge.ts",
    "groupTitle": "Edges"
  },
  {
    "type": "patch",
    "url": "/api/:sourceKey/graph/edges/:id",
    "title": "Update an edge",
    "name": "UpdateEdge",
    "group": "Edges",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "apiright:graphItem.edit"
      }
    ],
    "description": "<p>Update a subset of properties of an edge. Keep every other property of the edge unchanged. It's not possible to update the type of an edge.</p>",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the edge</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "source",
            "description": "<p>ID of the source node</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "target",
            "description": "<p>ID of the target node</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "type",
            "description": "<p>Type of the edge</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "data",
            "description": "<p>Properties of the edge</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "readAt",
            "description": "<p>Read timestamp in epoch time</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"id\": \"1\",\n  \"source\": \"1\",\n  \"target\": \"2\",\n  \"type\": \"my_link\",\n  \"data\": {\n    \"direction\": \"north\"\n  },\n  \"readAt\": 692362800000\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/graphEdge.ts",
    "groupTitle": "Edges",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the edge to update</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": true,
            "field": "properties",
            "description": "<p>Properties to update or create</p>"
          },
          {
            "group": "Parameter",
            "type": "string[]",
            "optional": true,
            "field": "deletedProperties",
            "description": "<p>Properties to delete</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": true,
            "field": "readAt",
            "description": "<p>Read timestamp in epoch time</p>"
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/guest",
    "title": "Open a guest sandbox",
    "name": "OpenGuestSandbox",
    "group": "Frontend",
    "description": "<p>Open the guest user's workspace for a given data-source.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "key",
            "description": "<p>Key of the data-source (default to the first connected data-source)</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"visualizationId\"",
              "\"expandNodeId\"",
              "\"nodeId\"",
              "\"edgeId\"",
              "\"queryId\"",
              "\"searchNodes\"",
              "\"searchEdges\"",
              "\"pattern\""
            ],
            "optional": true,
            "field": "populate",
            "description": "<p>Describes how the guest workspace should be populated</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "item_id",
            "description": "<p>ID of the node, edge, query/pattern or visualization to load (required when <code>populate</code> is one of  <code>[&quot;visualizationId&quot;, &quot;queryId&quot;, &quot;nodeId&quot;, &quot;edgeId&quot;, &quot;expandNodeId&quot;]</code>)</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "search_query",
            "description": "<p>Search query to search for nodes or edges (required when <code>populate</code> is one of  <code>[&quot;searchNodes&quot;, &quot;searchEdges&quot;]</code>)</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "size": "0-1",
            "optional": true,
            "field": "search_fuzziness",
            "defaultValue": "0.1",
            "description": "<p>Search query fuzziness (when <code>populate</code> is one of  <code>[&quot;searchNodes&quot;, &quot;searchEdges&quot;]</code>)</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "pattern_query",
            "description": "<p>Pattern query to match nodes and/or edges (required when <code>populate</code> is <code>&quot;pattern&quot;</code>)</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "pattern_dialect",
            "description": "<p>Query dialect to use (e.g. &quot;cypher&quot; or &quot;gremlin&quot;, required when <code>populate</code> is <code>&quot;pattern&quot;</code>)</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "query_parameters",
            "description": "<p>Template query parameters in JSON format (e.g. <code>{&quot;param1&quot;: &quot;abc&quot;, &quot;param2&quot;: 123}</code>, to use when <code>populate</code> is <code>&quot;queryId&quot;</code> and the query is a template)</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK",
          "type": "html"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/frontend.js",
    "groupTitle": "Frontend"
  },
  {
    "type": "get",
    "url": "/guest/:id",
    "title": "Open a visualization as a guest",
    "name": "OpenGuestVisualization",
    "group": "Frontend",
    "description": "<p>Open a visualization shared with the guest user.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the visualization</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK",
          "type": "html"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/frontend.js",
    "groupTitle": "Frontend"
  },
  {
    "type": "get",
    "url": "/workspace/new",
    "title": "Open a sandbox",
    "name": "OpenSandbox",
    "group": "Frontend",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      }
    ],
    "description": "<p>Open the visualization sandbox of the current user for a given data-source.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "key",
            "description": "<p>Key of the data-source (default to the first connected data-source)</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"visualizationId\"",
              "\"expandNodeId\"",
              "\"nodeId\"",
              "\"edgeId\"",
              "\"queryId\"",
              "\"searchNodes\"",
              "\"searchEdges\"",
              "\"pattern\"",
              "\"matchId\""
            ],
            "optional": true,
            "field": "populate",
            "description": "<p>Describes how the sandbox should be populated</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "item_id",
            "description": "<p>ID of the node, edge, query/pattern or visualization to load (required when <code>populate</code> is one of  <code>[&quot;visualizationId&quot;, &quot;queryId&quot;, &quot;nodeId&quot;, &quot;edgeId&quot;, &quot;expandNodeId&quot;]</code>)</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": true,
            "field": "match_id",
            "description": "<p>ID of alert match to load (required when <code>populate</code> is <code>&quot;matchId&quot;</code>)</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "search_query",
            "description": "<p>Search query to search for nodes or edges (required when <code>populate</code> is one of  <code>[&quot;searchNodes&quot;, &quot;searchEdges&quot;]</code>)</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "size": "0-1",
            "optional": true,
            "field": "search_fuzziness",
            "defaultValue": "0.1",
            "description": "<p>Search query fuzziness (when <code>populate</code> is one of  <code>[&quot;searchNodes&quot;, &quot;searchEdges&quot;]</code>)</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "pattern_query",
            "description": "<p>Pattern query to match nodes and/or edges (required when <code>populate</code> is <code>&quot;pattern&quot;</code>)</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "pattern_dialect",
            "description": "<p>Query dialect to use (e.g. &quot;cypher&quot; or &quot;gremlin&quot;, required when <code>populate</code> is <code>&quot;pattern&quot;</code>)</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "query_parameters",
            "description": "<p>Template query parameters in JSON format (e.g. <code>{&quot;param1&quot;: &quot;abc&quot;, &quot;param2&quot;: 123}</code>, to use when <code>populate</code> is <code>&quot;queryId&quot;</code> and the query is a template)</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/frontend.js",
    "groupTitle": "Frontend"
  },
  {
    "type": "get",
    "url": "/workspace/:id",
    "title": "Open a visualization",
    "name": "OpenVisualization",
    "group": "Frontend",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      }
    ],
    "description": "<p>Open a visualization. The current user must have at least read access on the visualization.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the visualization</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK",
          "type": "html"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/frontend.js",
    "groupTitle": "Frontend"
  },
  {
    "type": "get",
    "url": "/widget/:key",
    "title": "Open a widget",
    "name": "OpenWidget",
    "group": "Frontend",
    "description": "<p>Open a widget. A widget can be protected by a password. If the widget is password-protected, use HTTP Basic Authentication to provide the password (the username field is ignored).</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "key",
            "description": "<p>ID of the widget</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK",
          "type": "html"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/frontend.js",
    "groupTitle": "Frontend"
  },
  {
    "type": "post",
    "url": "/api/:sourceKey/graph/alertPreview",
    "title": "Preview an alert",
    "name": "AlertPreview",
    "group": "Graph",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.alerts"
      },
      {
        "name": "apiright:admin.alerts"
      }
    ],
    "description": "<p>Get all the nodes and edges matching the given graph query. An array of subgraphs, one for each subgraph matching the graph query, is returned.</p>",
    "version": "0.0.0",
    "filename": "server/routes/graph.ts",
    "groupTitle": "Graph",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "query",
            "description": "<p>The graph query</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"cypher\"",
              "\"gremlin\""
            ],
            "optional": true,
            "field": "dialect",
            "description": "<p>Dialect of the graph query (defaults to the first supported dialect of the data-source)</p>"
          },
          {
            "group": "Parameter",
            "type": "object[]",
            "optional": true,
            "field": "columns",
            "description": "<p>Columns among the returned values of the query to return as scalar values</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"number\"",
              "\"string\""
            ],
            "optional": false,
            "field": "columns.type",
            "description": "<p>Type of the column</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "columns.columnName",
            "description": "<p>Name of the column in the query</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "columns.columnTitle",
            "description": "<p>Tolerated for homogeneity with other alert APIs</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": true,
            "field": "limit",
            "description": "<p>Maximum number of matched subgraphs</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": true,
            "field": "timeout",
            "description": "<p>Maximum execution time in milliseconds</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n\n}",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "post",
    "url": "/api/:sourceKey/graph/check/query",
    "title": "Check a graph query",
    "name": "CheckGraphQuery",
    "group": "Graph",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:rawReadQuery"
      },
      {
        "name": "apiright:graph.rawRead"
      }
    ],
    "description": "<p>Check that the given graph query is syntactically correct. Parse the query if it's a template.</p>",
    "version": "0.0.0",
    "filename": "server/routes/graph.ts",
    "groupTitle": "Graph",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "query",
            "description": "<p>The graph query</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"cypher\"",
              "\"gremlin\""
            ],
            "optional": true,
            "field": "dialect",
            "description": "<p>Dialect of the graph query (defaults to the first supported dialect of the data-source)</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"static\"",
              "\"template\""
            ],
            "optional": false,
            "field": "type",
            "description": "<p>Type of the graph query</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "write",
            "description": "<p>Whether the query may write the database</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"none\"",
              "\"1-node\"",
              "\"2-nodes\"",
              "\"nodeset\""
            ],
            "optional": true,
            "field": "graphInput",
            "description": "<p>Type of inputs to the template query (if <code>type=&quot;template&quot;</code>)</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": true,
            "field": "templateFields",
            "description": "<p>Parsed template fields (if <code>type=&quot;template&quot;</code>)</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"write\": false,\n  \"graphInput\": \"2-nodes\",\n  \"templateFields\": [\n    {\n      \"key\": \"src\",\n      \"type\": \"node\"\n    },\n    {\n      \"key\": \"dst\",\n      \"type\": \"node\"\n    }\n  ],\n  \"type\": \"template\"\n}",
          "type": "none"
        }
      ]
    }
  },
  {
    "type": "post",
    "url": "/api/:sourceKey/graph/query",
    "title": "Create a graph query",
    "name": "CreateGraphQuery",
    "group": "Graph",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:raw(Read|Write)Query"
      },
      {
        "name": "apiright:savedGraphQuery.create"
      }
    ],
    "description": "<p>Create a graph query for the current user.</p>",
    "version": "0.0.0",
    "filename": "server/routes/graphQuery.ts",
    "groupTitle": "Graph",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the graph query</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "content",
            "description": "<p>Content of the graph query</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"cypher\"",
              "\"gremlin\""
            ],
            "optional": true,
            "field": "dialect",
            "description": "<p>Dialect of the graph query</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "description",
            "description": "<p>Description of the graph query</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"private\"",
              "\"source\"",
              "\"groups\""
            ],
            "optional": false,
            "field": "sharing",
            "description": "<p>Sharing policy of the graph query</p>"
          },
          {
            "group": "Parameter",
            "type": "number[]",
            "optional": true,
            "field": "sharedWithGroups",
            "description": "<p>IDs of the groups the graph query is shared with (if <code>sharing=&quot;groups&quot;</code>)</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the graph query</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the graph query</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "content",
            "description": "<p>Content of the graph query</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"cypher\"",
              "\"gremlin\""
            ],
            "optional": false,
            "field": "dialect",
            "description": "<p>Dialect of the graph query</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "description",
            "description": "<p>Description of the graph query</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"private\"",
              "\"source\"",
              "\"groups\""
            ],
            "optional": false,
            "field": "sharing",
            "description": "<p>Sharing policy of the graph query</p>"
          },
          {
            "group": "Success 200",
            "type": "number[]",
            "optional": true,
            "field": "sharedWithGroups",
            "description": "<p>IDs of the groups the graph query is shared with (if <code>sharing=&quot;groups&quot;</code>)</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "write",
            "description": "<p>Whether the query may write the database</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"none\"",
              "\"1-node\"",
              "\"2-nodes\"",
              "\"nodeset\""
            ],
            "optional": true,
            "field": "graphInput",
            "description": "<p>Type of inputs to the template query (if <code>type=&quot;template&quot;</code>)</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "builtin",
            "description": "<p>Whether the query is builtin</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": true,
            "field": "templateFields",
            "description": "<p>Parsed template fields (if <code>type=&quot;template&quot;</code>)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"static\"",
              "\"template\""
            ],
            "optional": false,
            "field": "type",
            "description": "<p>Type of the graph query</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"owner\"",
              "\"read\""
            ],
            "optional": false,
            "field": "right",
            "description": "<p>Current user's right on the query</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "createdAt",
            "description": "<p>Creation date in ISO-8601 format</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "updatedAt",
            "description": "<p>Last update date in ISO-8601 format</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n\n}",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "delete",
    "url": "/api/:sourceKey/graph/query/:id",
    "title": "Delete a graph query",
    "name": "DeleteGraphQuery",
    "group": "Graph",
    "permission": [
      {
        "name": "owner",
        "title": "Owner",
        "description": "<p>Only the owner of the item can use this API.</p>"
      },
      {
        "name": "apiright:savedGraphQuery.delete"
      }
    ],
    "description": "<p>Delete a graph query owned by the current user.</p>",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 204 No Content",
          "type": "none"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/graphQuery.ts",
    "groupTitle": "Graph",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the graph query</p>"
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/:sourceKey/graph/query",
    "title": "Get all graph queries",
    "name": "GetAllGraphQueries",
    "group": "Graph",
    "permission": [
      {
        "name": "guest_user",
        "title": "Guest user",
        "description": "<p>The guest user can use this API if guest mode is allowed.</p>"
      },
      {
        "name": "action:runQuery"
      },
      {
        "name": "apiright:savedGraphQuery.read"
      }
    ],
    "description": "<p>Get all the graph queries owned by the current user or shared with it.</p>",
    "version": "0.0.0",
    "filename": "server/routes/graphQuery.ts",
    "groupTitle": "Graph",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"static\"",
              "\"template\""
            ],
            "optional": true,
            "field": "type",
            "defaultValue": "static",
            "description": "<p>Type of the graph queries</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "queries",
            "description": "<p>Graph queries</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "queries.id",
            "description": "<p>ID of the graph query</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "queries.sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "queries.name",
            "description": "<p>Name of the graph query</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "queries.content",
            "description": "<p>Content of the graph query</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"cypher\"",
              "\"gremlin\""
            ],
            "optional": false,
            "field": "queries.dialect",
            "description": "<p>Dialect of the graph query</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "queries.description",
            "description": "<p>Description of the graph query</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"private\"",
              "\"source\"",
              "\"groups\""
            ],
            "optional": false,
            "field": "queries.sharing",
            "description": "<p>Sharing policy of the graph query</p>"
          },
          {
            "group": "Success 200",
            "type": "number[]",
            "optional": false,
            "field": "queries.[sharedWithGroups]",
            "description": "<p>IDs of the groups the graph query is shared with (if <code>sharing=&quot;groups&quot;</code>)</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "queries.write",
            "description": "<p>Whether the query may write the database</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"none\"",
              "\"1-node\"",
              "\"2-nodes\"",
              "\"nodeset\""
            ],
            "optional": false,
            "field": "queries.[graphInput]",
            "description": "<p>Type of inputs to the template query (if <code>type=&quot;template&quot;</code>)</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "queries.builtin",
            "description": "<p>Whether the query is builtin</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "queries.[templateFields]",
            "description": "<p>Parsed template fields (if <code>type=&quot;template&quot;</code>)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"static\"",
              "\"template\""
            ],
            "optional": false,
            "field": "queries.type",
            "description": "<p>Type of the graph query</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"owner\"",
              "\"read\""
            ],
            "optional": false,
            "field": "queries.right",
            "description": "<p>Current user's right on the query</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "queries.createdAt",
            "description": "<p>Creation date in ISO-8601 format</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "queries.updatedAt",
            "description": "<p>Last update date in ISO-8601 format</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n\n}",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "get",
    "url": "/api/:sourceKey/graph/query/:id",
    "title": "Get a graph query",
    "name": "GetGraphQuery",
    "group": "Graph",
    "permission": [
      {
        "name": "guest_user",
        "title": "Guest user",
        "description": "<p>The guest user can use this API if guest mode is allowed.</p>"
      },
      {
        "name": "action:runQuery"
      },
      {
        "name": "apiright:savedGraphQuery.read"
      }
    ],
    "description": "<p>Get a graph query owned by the current user or shared with it.</p>",
    "version": "0.0.0",
    "filename": "server/routes/graphQuery.ts",
    "groupTitle": "Graph",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the graph query</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the graph query</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the graph query</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "content",
            "description": "<p>Content of the graph query</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"cypher\"",
              "\"gremlin\""
            ],
            "optional": false,
            "field": "dialect",
            "description": "<p>Dialect of the graph query</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "description",
            "description": "<p>Description of the graph query</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"private\"",
              "\"source\"",
              "\"groups\""
            ],
            "optional": false,
            "field": "sharing",
            "description": "<p>Sharing policy of the graph query</p>"
          },
          {
            "group": "Success 200",
            "type": "number[]",
            "optional": true,
            "field": "sharedWithGroups",
            "description": "<p>IDs of the groups the graph query is shared with (if <code>sharing=&quot;groups&quot;</code>)</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "write",
            "description": "<p>Whether the query may write the database</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"none\"",
              "\"1-node\"",
              "\"2-nodes\"",
              "\"nodeset\""
            ],
            "optional": true,
            "field": "graphInput",
            "description": "<p>Type of inputs to the template query (if <code>type=&quot;template&quot;</code>)</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "builtin",
            "description": "<p>Whether the query is builtin</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": true,
            "field": "templateFields",
            "description": "<p>Parsed template fields (if <code>type=&quot;template&quot;</code>)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"static\"",
              "\"template\""
            ],
            "optional": false,
            "field": "type",
            "description": "<p>Type of the graph query</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"owner\"",
              "\"read\""
            ],
            "optional": false,
            "field": "right",
            "description": "<p>Current user's right on the query</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "createdAt",
            "description": "<p>Creation date in ISO-8601 format</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "updatedAt",
            "description": "<p>Last update date in ISO-8601 format</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n\n}",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "post",
    "url": "/api/:sourceKey/graph/run/query",
    "title": "Execute a graph query",
    "name": "RunGraphQueryByContent",
    "group": "Graph",
    "permission": [
      {
        "name": "action:raw(Read|Write)Query"
      },
      {
        "name": "apiright:graph.raw(Read|Write)"
      }
    ],
    "description": "<p>Get all the nodes and edges matching the given graph query. A subgraph made of all the nodes and the edges from each subgraph matching the graph query is returned.</p>",
    "version": "0.0.0",
    "filename": "server/routes/graph.ts",
    "groupTitle": "Graph",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "query",
            "description": "<p>The graph query</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"cypher\"",
              "\"gremlin\""
            ],
            "optional": true,
            "field": "dialect",
            "description": "<p>Dialect of the graph query (defaults to the first supported dialect of the data-source)</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": true,
            "field": "limit",
            "description": "<p>Maximum number of matched subgraphs</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": true,
            "field": "timeout",
            "description": "<p>Maximum execution time in milliseconds</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": true,
            "field": "templateData",
            "description": "<p>Key/value pair data to be filled in the template</p>"
          },
          {
            "group": "Parameter",
            "type": "string[]",
            "optional": true,
            "field": "edgesTo",
            "description": "<p>IDs of nodes that are already visible (they won't be included in the result, but their adjacent edges will be included in the <code>edges</code> field if the other nodes are in <code>nodes</code>)</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "withDigest",
            "defaultValue": "false",
            "description": "<p>Whether to include the adjacency digest in the returned nodes</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "withDegree",
            "defaultValue": "false",
            "description": "<p>Whether to include the degree in the returned nodes</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "nodes",
            "description": "<p>Nodes</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "nodes.id",
            "description": "<p>ID of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "nodes.data",
            "description": "<p>Properties of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "string[]",
            "optional": false,
            "field": "nodes.categories",
            "description": "<p>Categories of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "nodes.readAt",
            "description": "<p>Read timestamp in epoch time</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": true,
            "field": "nodes.statistics",
            "description": "<p>Statistics of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "type:LkDigestItem[]",
            "optional": true,
            "field": "nodes.statistics.digest",
            "description": "<p>Statistics of the neighborhood of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": true,
            "field": "nodes.statistics.degree",
            "description": "<p>Number of neighbors of the node readable by the current user</p>"
          },
          {
            "group": "Success 200",
            "type": "type:LkEdgeDigestItem[]",
            "optional": true,
            "field": "nodes.statistics.supernodeDigest",
            "description": "<p>Simplified statistics of the neighborhood of the node (alternative to <code>digest</code> for supernodes)</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": true,
            "field": "nodes.statistics.supernodeDegree",
            "description": "<p>Number of adjacent edges of the node (alternative to <code>degree</code> for supernodes)</p>"
          },
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "edges",
            "description": "<p>Edges</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "edges.id",
            "description": "<p>ID of the edge</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "edges.data",
            "description": "<p>Properties of the edge</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "edges.type",
            "description": "<p>Type of the edge</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "edges.source",
            "description": "<p>ID of the source node</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "edges.target",
            "description": "<p>ID of the target node</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "edges.readAt",
            "description": "<p>Read timestamp in epoch time</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": true,
            "field": "edges.statistics",
            "description": "<p>Statistics of the edge</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n\n}",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "post",
    "url": "/api/:sourceKey/graph/run/query/:id",
    "title": "Execute a graph query by ID",
    "name": "RunGraphQueryById",
    "group": "Graph",
    "permission": [
      {
        "name": "guest_user",
        "title": "Guest user",
        "description": "<p>The guest user can use this API if guest mode is allowed.</p>"
      },
      {
        "name": "action:runQuery"
      },
      {
        "name": "apiright:graph.runQuery"
      },
      {
        "name": "apiright:savedGraphQuery.read"
      }
    ],
    "description": "<p>Get all the nodes and edges matching the given saved graph query by ID. A subgraph made of all the nodes and the edges from each subgraph matching the graph query is returned.</p>",
    "version": "0.0.0",
    "filename": "server/routes/graph.ts",
    "groupTitle": "Graph",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the graph query</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"cypher\"",
              "\"gremlin\""
            ],
            "optional": true,
            "field": "dialect",
            "description": "<p>Dialect of the graph query (defaults to the first supported dialect of the data-source)</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": true,
            "field": "limit",
            "description": "<p>Maximum number of matched subgraphs</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": true,
            "field": "timeout",
            "description": "<p>Maximum execution time in milliseconds</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": true,
            "field": "templateData",
            "description": "<p>Key/value pair data to be filled in the template</p>"
          },
          {
            "group": "Parameter",
            "type": "string[]",
            "optional": true,
            "field": "edgesTo",
            "description": "<p>IDs of nodes that are already visible (they won't be included in the result, but their adjacent edges will be included in the <code>edges</code> field if the other nodes are in <code>nodes</code>)</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "withDigest",
            "defaultValue": "false",
            "description": "<p>Whether to include the adjacency digest in the returned nodes</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "withDegree",
            "defaultValue": "false",
            "description": "<p>Whether to include the degree in the returned nodes</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "nodes",
            "description": "<p>Nodes</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "nodes.id",
            "description": "<p>ID of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "nodes.data",
            "description": "<p>Properties of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "string[]",
            "optional": false,
            "field": "nodes.categories",
            "description": "<p>Categories of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "nodes.readAt",
            "description": "<p>Read timestamp in epoch time</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": true,
            "field": "nodes.statistics",
            "description": "<p>Statistics of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "type:LkDigestItem[]",
            "optional": true,
            "field": "nodes.statistics.digest",
            "description": "<p>Statistics of the neighborhood of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": true,
            "field": "nodes.statistics.degree",
            "description": "<p>Number of neighbors of the node readable by the current user</p>"
          },
          {
            "group": "Success 200",
            "type": "type:LkEdgeDigestItem[]",
            "optional": true,
            "field": "nodes.statistics.supernodeDigest",
            "description": "<p>Simplified statistics of the neighborhood of the node (alternative to <code>digest</code> for supernodes)</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": true,
            "field": "nodes.statistics.supernodeDegree",
            "description": "<p>Number of adjacent edges of the node (alternative to <code>degree</code> for supernodes)</p>"
          },
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "edges",
            "description": "<p>Edges</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "edges.id",
            "description": "<p>ID of the edge</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "edges.data",
            "description": "<p>Properties of the edge</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "edges.type",
            "description": "<p>Type of the edge</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "edges.source",
            "description": "<p>ID of the source node</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "edges.target",
            "description": "<p>ID of the target node</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "edges.readAt",
            "description": "<p>Read timestamp in epoch time</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": true,
            "field": "edges.statistics",
            "description": "<p>Statistics of the edge</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n\n}",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "patch",
    "url": "/api/:sourceKey/graph/query/:id",
    "title": "Update a graph query",
    "name": "UpdateGraphQuery",
    "group": "Graph",
    "permission": [
      {
        "name": "owner",
        "title": "Owner",
        "description": "<p>Only the owner of the item can use this API.</p>"
      },
      {
        "name": "action:raw(Read|Write)Query"
      },
      {
        "name": "apiright:savedGraphQuery.edit"
      }
    ],
    "description": "<p>Update a graph query owned by the current user.</p>",
    "version": "0.0.0",
    "filename": "server/routes/graphQuery.ts",
    "groupTitle": "Graph",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the graph query</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "name",
            "description": "<p>New name of the graph query</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "content",
            "description": "<p>New content of the graph query</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"cypher\"",
              "\"gremlin\""
            ],
            "optional": true,
            "field": "dialect",
            "description": "<p>New dialect of the graph query</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "description",
            "description": "<p>New description of the graph query</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"private\"",
              "\"source\"",
              "\"groups\""
            ],
            "optional": true,
            "field": "sharing",
            "description": "<p>New sharing policy of the graph query</p>"
          },
          {
            "group": "Parameter",
            "type": "number[]",
            "optional": true,
            "field": "sharedWithGroups",
            "description": "<p>IDs of the groups the graph query is shared with (if <code>sharing=&quot;groups&quot;</code>)</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the graph query</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the graph query</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "content",
            "description": "<p>Content of the graph query</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"cypher\"",
              "\"gremlin\""
            ],
            "optional": false,
            "field": "dialect",
            "description": "<p>Dialect of the graph query</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "description",
            "description": "<p>Description of the graph query</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"private\"",
              "\"source\"",
              "\"groups\""
            ],
            "optional": false,
            "field": "sharing",
            "description": "<p>Sharing policy of the graph query</p>"
          },
          {
            "group": "Success 200",
            "type": "number[]",
            "optional": true,
            "field": "sharedWithGroups",
            "description": "<p>IDs of the groups the graph query is shared with (if <code>sharing=&quot;groups&quot;</code>)</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "write",
            "description": "<p>Whether the query may write the database</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"none\"",
              "\"1-node\"",
              "\"2-nodes\"",
              "\"nodeset\""
            ],
            "optional": true,
            "field": "graphInput",
            "description": "<p>Type of inputs to the template query (if <code>type=&quot;template&quot;</code>)</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "builtin",
            "description": "<p>Whether the query is builtin</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": true,
            "field": "templateFields",
            "description": "<p>Parsed template fields (if <code>type=&quot;template&quot;</code>)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"static\"",
              "\"template\""
            ],
            "optional": false,
            "field": "type",
            "description": "<p>Type of the graph query</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"owner\"",
              "\"read\""
            ],
            "optional": false,
            "field": "right",
            "description": "<p>Current user's right on the query</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "createdAt",
            "description": "<p>Creation date in ISO-8601 format</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "updatedAt",
            "description": "<p>Last update date in ISO-8601 format</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n\n}",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "get",
    "url": "/api/admin/report",
    "title": "Create a report",
    "name": "CreateReport",
    "group": "Linkurious",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.report"
      }
    ],
    "description": "<p>Collect all the analytics and log files in a compressed tarball and return it.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "with_configuration",
            "defaultValue": "false",
            "description": "<p>Whether to include the configuration within the tarball</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK",
          "type": "tar.gz"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/general.js",
    "groupTitle": "Linkurious"
  },
  {
    "type": "get",
    "url": "/api/customFiles",
    "title": "Get the list of custom files",
    "name": "CustomFiles",
    "group": "Linkurious",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      }
    ],
    "description": "<p>List all custom files in the specified root directory.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "root",
            "defaultValue": ".",
            "description": "<p>Root directory of the files to be listed</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "extensions",
            "description": "<p>Comma separated list of file extensions to filter the results (e.g: <code>png,gif,jpg,jpeg</code>)</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "results",
            "description": "<p>The list of custom files</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "results.path",
            "description": "<p>The URL path of the file</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "results.name",
            "description": "<p>The path to the file relative to <code>root</code> and separated by <code>&gt;</code></p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"results\": [\n    {\n      \"path\": \"/myImages/ball.png\",\n      \"name\": \"ball\"\n    },\n    {\n      \"path\": \"/myImages/illustrations/Le_college_fou_fou_fou.jpg\",\n      \"name\": \"illustrations > Le_college_fou_fou_fou\"\n    },\n    {\n      \"path\": \"/myImages/illustrations/black-panther.jpg\",\n      \"name\": \"illustrations > black-panther\"\n    },\n    {\n      \"path\": \"/myImages/illustrations/house.png\",\n      \"name\": \"illustrations > house\"\n    },\n    {\n      \"path\": \"/myImages/illustrations/trump.jpg\",\n      \"name\": \"illustrations > trump\"\n    }\n   ]\n }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/customFiles.js",
    "groupTitle": "Linkurious"
  },
  {
    "type": "get",
    "url": "/api/dataSources",
    "title": "Get data-sources status",
    "name": "DataSourcesStatus",
    "group": "Linkurious",
    "permission": [
      {
        "name": "guest_user",
        "title": "Guest user",
        "description": "<p>The guest user can use this API if guest mode is allowed.</p>"
      }
    ],
    "description": "<p>Get the status of all the data-sources. Users can only see data-sources with at least one group belonging to that data-source. If a user has the &quot;admin.connect&quot; access right, it can also see all the disconnected data-sources.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "with_styles",
            "defaultValue": "false",
            "description": "<p>Whether to include the default styles of the data-sources</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "with_captions",
            "defaultValue": "false",
            "description": "<p>Whether to include the default captions of the data-sources</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "sources",
            "description": "<p>Data-sources</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "sources.name",
            "description": "<p>Name of the data-source</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "sources.configIndex",
            "description": "<p>Index of the data-source in the <code>dataSources</code> array in the configuration</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "sources.key",
            "description": "<p>Unique key of this data-source (it's <code>null</code> if the data-source is not connected)</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "sources.connected",
            "description": "<p>Whether the data-source is connected</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"offline\"",
              "\"connecting\"",
              "\"needConfig\"",
              "\"needFirstIndex\"",
              "\"needReindex\"",
              "\"indexing\"",
              "\"ready\""
            ],
            "optional": false,
            "field": "sources.state",
            "description": "<p>Current state of the data-source</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "sources.reason",
            "description": "<p>Explanation of the current state</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": true,
            "field": "sources.error",
            "description": "<p>The error that caused the current state, if any</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "sources.settings",
            "description": "<p>Settings of the data-source</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "sources.strictSchema",
            "description": "<p>Whether the schema is in strict mode</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "sources.settings.alternativeIds",
            "description": "<p>Current source alternative IDs</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "sources.settings.alternativeIds.node",
            "description": "<p>Alternative node ID</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "sources.settings.alternativeIds.edge",
            "description": "<p>Alternative edge ID</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "sources.settings.latitudeProperty",
            "description": "<p>The default node property used for latitude</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "sources.settings.longitudeProperty",
            "description": "<p>The default node property used for longitude</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "sources.settings.skipEdgeIndexation",
            "description": "<p>Whether edges are not indexed for this source</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "sources.settings.readOnly",
            "description": "<p>Whether the source is in readonly mode</p>"
          },
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "sources.settings.specialProperties",
            "description": "<p>Properties with special access rights for this source</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "sources.settings.specialProperties.key",
            "description": "<p>Key of the property</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "sources.settings.specialProperties.read",
            "description": "<p>Whether the property can be read</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "sources.settings.specialProperties.create",
            "description": "<p>Whether the property can be created</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "sources.settings.specialProperties.update",
            "description": "<p>Whether the property can be updated</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "sources.features",
            "description": "<p>Features of the data-source</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "sources.features.immutableNodeCategories",
            "description": "<p>Whether node categories are immutable</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "sources.features.maxNodeCategories",
            "description": "<p>Maximum number of categories for a node</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "sources.features.canCount",
            "description": "<p>Whether one among the graph or the index can count nodes and edges</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "sources.features.alerts",
            "description": "<p>Whether alerts are available</p>"
          },
          {
            "group": "Success 200",
            "type": "string[]",
            "optional": false,
            "field": "sources.features.dialects",
            "description": "<p>Dialects supported by the graph database</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "sources.features.externalIndex",
            "description": "<p>Whether the search index is internal (e.g: elasticsearch) or external</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "sources.features.alternativeIds",
            "description": "<p>Whether alternative IDs can be used</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "sources.features.canIndexEdges",
            "description": "<p>Whether the search index can index edges</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "sources.features.searchHitsCount",
            "description": "<p>Whether the search result will contain 'totalHits' or 'moreResults'</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": true,
            "field": "sources.defaultStyles",
            "description": "<p>Default styles of the data-source</p>"
          },
          {
            "group": "Success 200",
            "type": "type:NodeStyle[]",
            "optional": false,
            "field": "sources.defaultStyles.node",
            "description": "<p>Node Styles</p>"
          },
          {
            "group": "Success 200",
            "type": "type:EdgeStyle[]",
            "optional": false,
            "field": "sources.defaultStyles.edge",
            "description": "<p>Edge Styles</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": true,
            "field": "sources.defaultCaptions",
            "description": "<p>Default captions of the data-source</p>"
          },
          {
            "group": "Success 200",
            "type": "type:NodeCaption",
            "optional": false,
            "field": "sources.defaultCaptions.nodes",
            "description": "<p>Node Captions</p>"
          },
          {
            "group": "Success 200",
            "type": "type:EdgeCaption",
            "optional": false,
            "field": "sources.defaultCaptions.edges",
            "description": "<p>Edge Captions</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "with_styles=false, with_captions=false:",
          "content": "HTTP/1.1 200 OK\n{\n  \"sources\": [\n    {\n      \"name\": \"Database #0\",\n      \"configIndex\": 0,\n      \"key\": \"a2e3c50f\",\n      \"connected\": true,\n      \"state\": \"ready\",\n      \"reason\": \"The data-source is ready.\",\n      \"settings\": {\n        \"strictSchema\": false\n        \"alternativeIds\": {\n          \"node\": \"name\",\n          \"edge\": \"altEdgeID\"\n        },\n        \"skipEdgeIndexation\": false,\n        \"readOnly\": false,\n        \"specialProperties\": [\n          {\n            \"key\": \"propertyName\",\n            \"read\": true,\n            \"create\": true,\n            \"update\": false\n          }\n        ]\n      },\n      \"features\": {\n        \"immutableNodeCategories\": false,\n        \"canCount\": true,\n        \"alerts\": true,\n        \"dialects\": [\n          \"cypher\"\n        ],\n        \"externalIndex\": false,\n        \"alternativeIds\": true,\n        \"canIndexEdges\": true,\n        \"searchHitsCount\": true\n      }\n    }, {\n      \"name\": \"Database #1\",\n      \"configIndex\": 1,\n      \"key\": \"ef984bb0\",\n      \"connected\": true,\n      \"state\": \"needFirstIndex\",\n      \"reason\": \"The data-source needs to be indexed at least once.\",\n      \"settings\": {\n        // ...\n      },\n      \"features\": {\n        // ...\n      }\n    }, {\n      \"name\": \"Database #2\",\n      \"configIndex\": 2,\n      \"key\": null,\n      \"connected\": false,\n      \"state\": \"offline\",\n      \"reason\": \"Could not connect to graph database server.\",\n      \"error\": \"Connection refused (check your username and password)\",\n      \"settings\": {\n        // ...\n      },\n      \"features\": {\n        // ...\n      }\n    }\n  ]\n}",
          "type": "json"
        },
        {
          "title": "with_styles=true, with_captions=true:",
          "content": "HTTP/1.1 200 OK\n{\n  \"sources\": [{\n    \"name\": \"Database #0\",\n    \"configIndex\": 0,\n    \"connected\": true,\n    \"key\": \"4ee5973b\",\n    \"state\": \"ready\",\n    \"reason\": \"The data-source is ready.\",\n    \"settings\": {\n      \"readOnly\": false,\n      \"strictSchema\": false,\n      \"alternativeIds\": {},\n      \"specialProperties\": [{\n        \"key\": \"id\",\n        \"read\": true,\n        \"create\": true,\n        \"update\": false\n      }],\n      \"skipEdgeIndexation\": true\n    },\n    \"features\": {\n      \"immutableNodeCategories\": false,\n      \"canCount\": false,\n      \"alerts\": false,\n      \"dialects\": [\n        \"cypher\"\n      ],\n      \"externalIndex\": true,\n      \"alternativeIds\": false,\n      \"canIndexEdges\": false,\n      \"searchHitsCount\": false,\n      \"canDryRun\": false,\n      \"supportNativeDate\": false\n    },\n    \"defaultStyles\": {\n      \"node\": [{\n        \"index\": 0,\n        \"type\": \"any\",\n        \"style\": {\n          \"color\": {\n            \"type\": \"auto\",\n            \"input\": [\n              \"categories\"\n            ]\n          }\n        }\n      }],\n      \"edge\": []\n    },\n    \"defaultCaptions\": {\n      \"nodes\": {\n        \"CITY\": {\n          \"active\": true,\n          \"displayName\": true,\n          \"properties\": [\n            \"name\"\n          ]\n        },\n        \"COMPANY\": {\n          \"active\": true,\n          \"displayName\": false,\n          \"properties\": [\n            \"name\",\n            \"country\"\n          ]\n        }\n      },\n      \"edges\": {\n        \"INVESTED_IN\": {\n          \"active\": true,\n          \"displayName\": true,\n          \"properties\": [\n            \"funded_month\"\n          ]\n        }\n      }\n    }\n  }]\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/general.js",
    "groupTitle": "Linkurious"
  },
  {
    "type": "get",
    "url": "/api/config",
    "title": "Get the configuration",
    "name": "GetConfiguration",
    "group": "Linkurious",
    "description": "<p>Get the configuration of Linkurious.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "number",
            "optional": true,
            "field": "sourceIndex",
            "defaultValue": "0",
            "description": "<p>Index of the data-source in the <code>dataSources</code> array in the configuration of which the <code>source</code> field in the response will be about</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "access",
            "description": "<p>Access configuration</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "access.authRequired",
            "description": "<p>Whether authentication is required</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "access.guestMode",
            "description": "<p>Whether the guest mode is enabled</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "access.loginTimeout",
            "description": "<p>Seconds of inactivity after which a user is logged out</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"dashboard\"",
              "\"workspace\""
            ],
            "optional": false,
            "field": "access.defaultPage",
            "description": "<p>Default page</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "access.defaultPageParams",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "access.dataEdition",
            "description": "<p>Whether it's possible to create, update and delete nodes and edges</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "access.widget",
            "description": "<p>Whether the widget feature is enabled</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "access.autoRefreshGroupMapping",
            "description": "<p>Whether access rights for an external user should be refreshed at every login</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "ogma",
            "description": "<p>Configuration of Ogma</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "domain",
            "description": "<p>The server domain</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "url",
            "description": "<p>The server url</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "ssoProvider",
            "description": "<p>The current SSO provider (or <code>null</code> if none)</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "advanced",
            "description": "<p>Advanced data-source settings applied to all data-sources</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "advanced.supernodeThreshold",
            "description": "<p>Number of connections a node must have to be a supernode</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "advanced.connectionRetries",
            "description": "<p>Maximum number of retries when connecting/reconnecting to data-source</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "advanced.pollInterval",
            "description": "<p>Number of seconds between &quot;pings&quot; to a data-source when connected</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "advanced.indexationChunkSize",
            "description": "<p>Number of nodes/edges read at once from a data-source when indexing it</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "advanced.expandThreshold",
            "description": "<p>Number of expanded nodes that will trigger the &quot;limit expand to&quot; popup</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "advanced.rawQueryLimit",
            "description": "<p>Maximum number of nodes returned by a raw query</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "advanced.searchAddAllThreshold",
            "description": "<p>Maximum number of added nodes using the &quot;add all&quot; in a search</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "advanced.minSearchQueryLength",
            "description": "<p>Minimum number of characters in a search query before it is sent to the server</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "advanced.rawQueryTimeout",
            "description": "<p>Timeout of pattern queries (<code>cypher</code>, <code>gremlin</code>, etc.) in milliseconds</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "advanced.sampledItemsPerType",
            "description": "<p>Number of nodes/edges per label to read while sampling the graph schema</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "advanced.sampledVisualizationItems",
            "description": "<p>Number of nodes/edges to read to read from existing visualizations while sampling the graph schema</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "advanced.defaultTimezone",
            "description": "<p>The default timezone to be applied to temporal values</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "advanced.timeline",
            "description": "<p>Whether the visualization timeline is available in the workspace UI</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "advanced.layoutWorkers",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "advanced.defaultFuzziness",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "advanced.extraCertificateAuthorities",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "advanced.obfuscation",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "leaflet",
            "description": "<p>Leaflet layer configuration</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "leaflet.name",
            "description": "<p>Name of the layer</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "leaflet.urlTemplate",
            "description": "<p>Tile-URL template for this layer</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "leaflet.attribution",
            "description": "<p>Copyright attribution text for this layer</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "leaflet.minZoom",
            "description": "<p>Minimum valid zoom of the layer</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "leaflet.maxZoom",
            "description": "<p>Maximum valid zoom of the layer</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "leaflet.thumbnail",
            "description": "<p>Path of this layer's thumbnail, relative to client root</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "leaflet.subdomains",
            "description": "<p>Subdomain letters to use in tile-URL template</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "leaflet.id",
            "description": "<p>Layer ID (needed for MapBox layers)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "leaflet.accessToken",
            "description": "<p>Layer access token (user for MapBox layers)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "leaflet.overlay",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "db",
            "description": "<p>DB configuration (if admin)</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "server",
            "description": "<p>Server configuration (if admin)</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "alerts",
            "description": "<p>Alerts configuration</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "alerts.enabled",
            "description": "<p>Whether alerts are enabled</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "alerts.maxMatchTTL",
            "description": "<p>The maximum and default number of days after which the matches of this alert are going to be deleted</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "alerts.maxMatchesLimit",
            "description": "<p>The maximum and default number of matches stored for an alert</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "alerts.maxRuntimeLimit",
            "description": "<p>The maximum and default runtime limit for an alert update (in milliseconds)</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "alerts.maxConcurrency",
            "description": "<p>The maximum number of alerts updated at the same time</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "auditTrail",
            "description": "<p>AuditTrail configuration (if admin)</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "defaultPreferences",
            "description": "<p>Default preferences of a newly created user (if admin)</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "guestPreferences",
            "description": "<p>Preferences of the guest user (if admin)</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Data-source configuration (if admin)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "dataSource.name",
            "description": "<p>Name of the current data-source</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "dataSource.readOnly",
            "description": "<p>Whether the current data-source is read-only</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "dataSource.graphdb",
            "description": "<p>Graph configuration of the current data-source</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "dataSource.index",
            "description": "<p>Index configuration of the current data-source</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "needRestart",
            "description": "<p>Whether the Linkurious Server needs to be restarted</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/general.js",
    "groupTitle": "Linkurious"
  },
  {
    "type": "post",
    "url": "/api/admin/restart",
    "title": "Restart Linkurious",
    "name": "RestartLinkurious",
    "group": "Linkurious",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.config"
      }
    ],
    "description": "<p>Restart Linkurious.</p>",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "url",
            "description": "<p>The url of Linkurious to connect to after the restart</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"url\": \"http://localhost:3000\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/general.js",
    "groupTitle": "Linkurious"
  },
  {
    "type": "post",
    "url": "/api/analytics",
    "title": "Save an event",
    "name": "SaveEvent",
    "group": "Linkurious",
    "description": "<p>Save an event to the analytics' log file. All events follow the Segment Spec.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"identify\"",
              "\"track\"",
              "\"page\""
            ],
            "optional": false,
            "field": "type",
            "description": "<p>Type of message</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": true,
            "field": "userId",
            "description": "<p>ID of the user</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "event",
            "description": "<p>Name of the action that the user has performed</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "name",
            "description": "<p>Name of the page that the user has seen</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": true,
            "field": "properties",
            "description": "<p>Free-form dictionary of properties of the event/page</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": true,
            "field": "traits",
            "description": "<p>Free-form dictionary of traits of the user</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "timestamp",
            "description": "<p>Timestamp when the message itself took place, defaulted to the current time, in ISO-8601 format</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": true,
            "field": "context",
            "description": "<p>Dictionary of extra information of the user</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 204 No Content",
          "type": "none"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/general.js",
    "groupTitle": "Linkurious"
  },
  {
    "type": "get",
    "url": "/api/status",
    "title": "Get status",
    "name": "Status",
    "group": "Linkurious",
    "description": "<p>Get the status of the Linkurious Server.</p>",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "status",
            "description": "<p>Status of the server</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "status.code",
            "description": "<p>Status code of the server (<code>100</code> : starting, <code>200</code> : OK, <code>&gt;400</code> : problem)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "status.name",
            "description": "<p>Current server status</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "status.message",
            "description": "<p>Description of the current server status</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "status.uptime",
            "description": "<p>Seconds since the server is up</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"status\": {\n    \"code\": 200,\n    \"name\": \"initialized\",\n    \"message\": \"Linkurious ready to go :)\",\n    \"uptime\": 122\n  }\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/general.js",
    "groupTitle": "Linkurious"
  },
  {
    "type": "post",
    "url": "/api/config",
    "title": "Update the configuration",
    "name": "UpdateConfiguration",
    "group": "Linkurious",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.config"
      }
    ],
    "description": "<p>Update Linkurious' configuration.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "path",
            "description": "<p>The configuration path to override (use <code>dataSource.*</code> to edit the current data-source configuration)</p>"
          },
          {
            "group": "Parameter",
            "type": "any",
            "optional": true,
            "field": "configuration",
            "description": "<p>The configuration value to set for the given path</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": true,
            "field": "sourceIndex",
            "defaultValue": "0",
            "description": "<p>Index of the data-source in the <code>dataSources</code> array in the configuration</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "reset",
            "defaultValue": "false",
            "description": "<p>Whether to reset the configuration to default values (the <code>configuration</code> parameter will be ignored). If the <code>path</code> parameter is specified, only the configuration corresponding to the specified path will be reset</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n  \"path\": \"dataSource.name\",\n  \"configuration\": \"New data-source name\",\n  \"sourceIndex\": 2\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP 1.1 201 Created",
          "type": "none"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/general.js",
    "groupTitle": "Linkurious"
  },
  {
    "type": "get",
    "url": "/api/version",
    "title": "Get version",
    "name": "Version",
    "group": "Linkurious",
    "description": "<p>Get Linkurious' current version information.</p>",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "tag_name",
            "description": "<p>Version tag</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "name",
            "description": "<p>Version name</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "prerelease",
            "description": "<p>Whether this is a pre-release</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"tag_name\": \"v0.5.0\",\n  \"name\": \"Nasty Nostradamus\",\n  \"prerelease\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/general.js",
    "groupTitle": "Linkurious"
  },
  {
    "type": "post",
    "url": "/api/:sourceKey/graph/nodes",
    "title": "Create a node",
    "name": "CreateNode",
    "group": "Nodes",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "apiright:graphItem.create"
      }
    ],
    "description": "<p>Add a node to the graph.</p>",
    "success": {
      "fields": {
        "Success 201": [
          {
            "group": "Success 201",
            "type": "string",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the node</p>"
          },
          {
            "group": "Success 201",
            "type": "object",
            "optional": false,
            "field": "data",
            "description": "<p>Properties of the node</p>"
          },
          {
            "group": "Success 201",
            "type": "string[]",
            "optional": false,
            "field": "categories",
            "description": "<p>Categories of the node</p>"
          },
          {
            "group": "Success 201",
            "type": "number",
            "optional": false,
            "field": "readAt",
            "description": "<p>Read timestamp in epoch time</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 201 Created\n{\n  \"id\": \"123\",\n  \"data\": {\n    \"name\": \"Keanu Reeves\",\n    \"born\": {\n      \"type\": \"date\",\n      \"value\": \"1964-09-02T00:00:00.000Z\"\n    }\n  },\n  \"categories\": [\n    \"Person\"\n  ],\n  \"readAt\": 692362800000\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/graphNode.ts",
    "groupTitle": "Nodes",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": true,
            "field": "properties",
            "description": "<p>Properties of the node</p>"
          },
          {
            "group": "Parameter",
            "type": "string[]",
            "optional": true,
            "field": "categories",
            "description": "<p>Categories of the node</p>"
          }
        ]
      }
    }
  },
  {
    "type": "delete",
    "url": "/api/:dataSource/graph/nodes/:id",
    "title": "Delete a node",
    "name": "DeleteNode",
    "group": "Nodes",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "apiright:graphItem.delete"
      }
    ],
    "description": "<p>Delete a node and its adjacent edges from the graph.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the node to delete</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 204 No Content",
          "type": "none"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/graphNode.ts",
    "groupTitle": "Nodes"
  },
  {
    "type": "get|post",
    "url": "/api/:dataSource/graph/nodes/expand",
    "title": "Get adjacent nodes and edges",
    "name": "GetAdjacentGraph",
    "group": "Nodes",
    "permission": [
      {
        "name": "guest_user",
        "title": "Guest user",
        "description": "<p>The guest user can use this API if guest mode is allowed.</p>"
      },
      {
        "name": "apiright:graphItem.read"
      }
    ],
    "description": "<p>Get all the adjacent nodes and edges to one or more source nodes (<code>ids</code>). A subgraph made of the items that matched the expand query and the edges between them is returned.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "string[]",
            "optional": false,
            "field": "ids",
            "description": "<p>IDs of the nodes to retrieve the neighbors for</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": true,
            "field": "limit",
            "description": "<p>Maximum number of returned nodes</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"id\"",
              "\"highestDegree\"",
              "\"lowestDegree\""
            ],
            "optional": true,
            "field": "limitType",
            "defaultValue": "id",
            "description": "<p>Order direction used to limit the result</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "nodeCategories",
            "description": "<p>Exclusive list of node categories to restrict the result</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "edgeTypes",
            "description": "<p>Exclusive list of edge types to restrict the result</p>"
          },
          {
            "group": "Parameter",
            "type": "string[]",
            "optional": true,
            "field": "edgesTo",
            "description": "<p>IDs of nodes that are already visible (they won't be included in the result, but their adjacent edges will be included in the <code>edges</code> field if the other nodes are in <code>nodes</code>)</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "withDigest",
            "defaultValue": "false",
            "description": "<p>Whether to include the adjacency digest in the returned nodes</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "withDegree",
            "defaultValue": "false",
            "description": "<p>Whether to include the degree in the returned nodes</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/graphNode.ts",
    "groupTitle": "Nodes",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "nodes",
            "description": "<p>Nodes</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "nodes.id",
            "description": "<p>ID of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "nodes.data",
            "description": "<p>Properties of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "string[]",
            "optional": false,
            "field": "nodes.categories",
            "description": "<p>Categories of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "nodes.readAt",
            "description": "<p>Read timestamp in epoch time</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": true,
            "field": "nodes.statistics",
            "description": "<p>Statistics of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "type:LkDigestItem[]",
            "optional": true,
            "field": "nodes.statistics.digest",
            "description": "<p>Statistics of the neighborhood of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": true,
            "field": "nodes.statistics.degree",
            "description": "<p>Number of neighbors of the node readable by the current user</p>"
          },
          {
            "group": "Success 200",
            "type": "type:LkEdgeDigestItem[]",
            "optional": true,
            "field": "nodes.statistics.supernodeDigest",
            "description": "<p>Simplified statistics of the neighborhood of the node (alternative to <code>digest</code> for supernodes)</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": true,
            "field": "nodes.statistics.supernodeDegree",
            "description": "<p>Number of adjacent edges of the node (alternative to <code>degree</code> for supernodes)</p>"
          },
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "edges",
            "description": "<p>Edges</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "edges.id",
            "description": "<p>ID of the edge</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "edges.data",
            "description": "<p>Properties of the edge</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "edges.type",
            "description": "<p>Type of the edge</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "edges.source",
            "description": "<p>ID of the source node</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "edges.target",
            "description": "<p>ID of the target node</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "edges.readAt",
            "description": "<p>Read timestamp in epoch time</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"nodes\": [\n    {\n      \"id\": 1,\n      \"data\": {\n        \"name\": \"Keanu Reeves\",\n        \"born\": {\n          \"type\": \"date\",\n          \"value\": \"1964-09-02T00:00:00.000Z\"\n        }\n      },\n      \"categories\": [\n        \"Person\"\n      ],\n      \"statistics\": {\n        \"digest\": [\n          {\n            \"nodeCategories\": [\n              \"Movie\",\n              \"TheMatrix\",\n              \"TheMatrixReloaded\"\n            ],\n            \"edgeType\": \"ACTED_IN\",\n            \"nodes\": 3,\n            \"edges\": 3\n          }\n        ]\n      },\n      \"readAt\": 692362800000\n    },\n    {\n      \"id\": 2,\n      \"data\": {\n        \"title\": \"The Matrix\",\n        \"release\": 1999\n      },\n      \"categories\": [\n        \"Movie\"\n      ],\n      \"statistics\": {\n        \"digest\": [\n          {\n            \"nodeCategories\": [\n              \"Person\"\n            ],\n            \"edgeType\": \"ACTED_IN\",\n            \"nodes\": 2,\n            \"edges\": 2\n          }\n        ]\n      },\n      \"readAt\": 692362800000\n    }\n  ],\n  \"edges\": [\n    {\n      \"id\": 100,\n      \"type\": \"ACTED_IN\",\n      \"source\": 1,\n      \"target\": 2,\n      \"data\": {\n        \"role\": \"Neo\"\n      },\n      \"readAt\": 692362800000\n    }\n  ]\n}",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "post",
    "url": "/api/:dataSource/graph/neighborhood/statistics",
    "title": "Get statistics of adjacent nodes",
    "name": "GetNeighborsStatistics",
    "group": "Nodes",
    "permission": [
      {
        "name": "guest_user",
        "title": "Guest user",
        "description": "<p>The guest user can use this API if guest mode is allowed.</p>"
      },
      {
        "name": "apiright:graphItem.read"
      }
    ],
    "description": "<p>Get the digest (the number of adjacent nodes and edges grouped by node categories and edge types) and/or the degree of a given subset of nodes (<code>ids</code>). You can't get aggregated statistics of a subset of nodes containing one or more supernodes. To get the statistics of a supernode invoke the API with only its node ID.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "string[]",
            "optional": false,
            "field": "ids",
            "description": "<p>IDs of the nodes</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "withDigest",
            "defaultValue": "false",
            "description": "<p>Whether to include the adjacency digest in the returned nodes</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "withDegree",
            "defaultValue": "false",
            "description": "<p>Whether to include the degree in the returned nodes</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "type:LkDigestItem[]",
            "optional": true,
            "field": "digest",
            "description": "<p>Statistics of the neighborhood of the nodes</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": true,
            "field": "degree",
            "description": "<p>Number of neighbors of the nodes readable by the current user</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"digest\": [\n    {\n      \"edgeType\": \"ACTED_IN\",\n      \"nodeCategories\": [\n        \"TheMatrix\",\n        \"Movie\"\n      ],\n      \"nodes\": 1,\n      \"edges\": 1\n    }\n  ],\n  \"degree\": 1\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/graphNode.ts",
    "groupTitle": "Nodes"
  },
  {
    "type": "get|post",
    "url": "/api/:dataSource/graph/nodes/:id",
    "title": "Get a node",
    "name": "GetNode",
    "group": "Nodes",
    "permission": [
      {
        "name": "guest_user",
        "title": "Guest user",
        "description": "<p>The guest user can use this API if guest mode is allowed.</p>"
      },
      {
        "name": "apiright:graphItem.read"
      }
    ],
    "description": "<p>Get a node of the graph. A subgraph made of the single node is returned.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the node</p>"
          },
          {
            "group": "Parameter",
            "type": "string[]",
            "optional": true,
            "field": "edgesTo",
            "description": "<p>IDs of nodes that are already visible (they won't be included in the result, but their adjacent edges will be included in the <code>edges</code> field if the other nodes are in <code>nodes</code>)</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "withDigest",
            "defaultValue": "false",
            "description": "<p>Whether to include the adjacency digest in the returned nodes</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "withDegree",
            "defaultValue": "false",
            "description": "<p>Whether to include the degree in the returned nodes</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/graphNode.ts",
    "groupTitle": "Nodes",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "nodes",
            "description": "<p>Nodes</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "nodes.id",
            "description": "<p>ID of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "nodes.data",
            "description": "<p>Properties of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "string[]",
            "optional": false,
            "field": "nodes.categories",
            "description": "<p>Categories of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "nodes.readAt",
            "description": "<p>Read timestamp in epoch time</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": true,
            "field": "nodes.statistics",
            "description": "<p>Statistics of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "type:LkDigestItem[]",
            "optional": true,
            "field": "nodes.statistics.digest",
            "description": "<p>Statistics of the neighborhood of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": true,
            "field": "nodes.statistics.degree",
            "description": "<p>Number of neighbors of the node readable by the current user</p>"
          },
          {
            "group": "Success 200",
            "type": "type:LkEdgeDigestItem[]",
            "optional": true,
            "field": "nodes.statistics.supernodeDigest",
            "description": "<p>Simplified statistics of the neighborhood of the node (alternative to <code>digest</code> for supernodes)</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": true,
            "field": "nodes.statistics.supernodeDegree",
            "description": "<p>Number of adjacent edges of the node (alternative to <code>degree</code> for supernodes)</p>"
          },
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "edges",
            "description": "<p>Edges</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "edges.id",
            "description": "<p>ID of the edge</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "edges.data",
            "description": "<p>Properties of the edge</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "edges.type",
            "description": "<p>Type of the edge</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "edges.source",
            "description": "<p>ID of the source node</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "edges.target",
            "description": "<p>ID of the target node</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "edges.readAt",
            "description": "<p>Read timestamp in epoch time</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"nodes\": [\n    {\n      \"id\": 1,\n      \"data\": {\n        \"name\": \"Keanu Reeves\",\n        \"born\": {\n          \"type\": \"date\",\n          \"value\": \"1964-09-02T00:00:00.000Z\"\n        }\n      },\n      \"categories\": [\n        \"Person\"\n      ],\n      \"statistics\": {\n        \"digest\": [\n          {\n            \"nodeCategories\": [\n              \"Movie\",\n              \"TheMatrix\",\n              \"TheMatrixReloaded\"\n            ],\n            \"edgeType\": \"ACTED_IN\",\n            \"nodes\": 3,\n            \"edges\": 3\n          }\n        ]\n      },\n      \"readAt\": 692362800000\n    },\n    {\n      \"id\": 2,\n      \"data\": {\n        \"title\": \"The Matrix\",\n        \"release\": 1999\n      },\n      \"categories\": [\n        \"Movie\"\n      ],\n      \"statistics\": {\n        \"digest\": [\n          {\n            \"nodeCategories\": [\n              \"Person\"\n            ],\n            \"edgeType\": \"ACTED_IN\",\n            \"nodes\": 2,\n            \"edges\": 2\n          }\n        ]\n      },\n      \"readAt\": 692362800000\n    }\n  ],\n  \"edges\": [\n    {\n      \"id\": 100,\n      \"type\": \"ACTED_IN\",\n      \"source\": 1,\n      \"target\": 2,\n      \"data\": {\n        \"role\": \"Neo\"\n      },\n      \"readAt\": 692362800000\n    }\n  ]\n}",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "get",
    "url": "/api/:dataSource/graph/nodes/count",
    "title": "Get nodes count",
    "name": "GetNodesCount",
    "group": "Nodes",
    "permission": [
      {
        "name": "guest_user",
        "title": "Guest user",
        "description": "<p>The guest user can use this API if guest mode is allowed.</p>"
      },
      {
        "name": "apiright:graphItem.read"
      }
    ],
    "description": "<p>Get the number of nodes in the graph.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "count",
            "description": "<p>The number of nodes</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"count\": 42\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/graphNode.ts",
    "groupTitle": "Nodes"
  },
  {
    "type": "patch",
    "url": "/api/:sourceKey/graph/nodes/:id",
    "title": "Update a node",
    "name": "UpdateNode",
    "group": "Nodes",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "apiright:graphItem.edit"
      }
    ],
    "description": "<p>Update a subset of properties and categories of a node. Keep every other property and category of the node unchanged.</p>",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "data",
            "description": "<p>Properties of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "string[]",
            "optional": false,
            "field": "categories",
            "description": "<p>Categories of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "readAt",
            "description": "<p>Read timestamp in epoch time</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"id\": \"123\",\n  \"data\": {\n    \"name\": \"Keanu Reeves\",\n    \"born\": {\n      \"type\": \"date\",\n      \"value\": \"1964-09-02T00:00:00.000Z\"\n    }\n  },\n  \"categories\": [\n    \"Person\"\n  ],\n  \"readAt\": 692362800000\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/graphNode.ts",
    "groupTitle": "Nodes",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the node to update</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": true,
            "field": "properties",
            "description": "<p>Properties to update or create</p>"
          },
          {
            "group": "Parameter",
            "type": "string[]",
            "optional": true,
            "field": "deletedProperties",
            "description": "<p>Properties to delete</p>"
          },
          {
            "group": "Parameter",
            "type": "string[]",
            "optional": true,
            "field": "addedCategories",
            "description": "<p>Categories of the node to add</p>"
          },
          {
            "group": "Parameter",
            "type": "string[]",
            "optional": true,
            "field": "deletedCategories",
            "description": "<p>Categories of the node to delete</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": true,
            "field": "readAt",
            "description": "<p>Read timestamp in epoch time</p>"
          }
        ]
      }
    }
  },
  {
    "type": "post",
    "url": "/api/admin/:sourceKey/graph/schema/:entityType/properties",
    "title": "Create a new graph schema property",
    "name": "CreateGraphSchemaProperty",
    "group": "Schema",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.schema"
      }
    ],
    "description": "<p>Add a new property for a type on the graph schema.</p>",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "propertyKey",
            "description": "<p>Name of the property</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"visible\"",
              "\"searchable\"",
              "\"none\""
            ],
            "optional": false,
            "field": "visibility",
            "description": "<p>Whether the property can be searched, visualized or it is hidden</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "propertyType",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"auto\"",
              "\"boolean\"",
              "\"date\"",
              "\"datetime\"",
              "\"number\"",
              "\"string\""
            ],
            "optional": false,
            "field": "propertyType.name",
            "description": "<p>Data type of the property</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": true,
            "field": "propertyType.options",
            "description": "<p>Additional <code>propertyType</code> information (required when <code>propertyType.name</code> is &quot;date&quot; or &quot;datetime&quot;)</p>"
          },
          {
            "group": "Success 200",
            "type": "string[]",
            "optional": true,
            "field": "propertyType.options.values",
            "description": "<p>A list of values to restrict the value of the property (only applicable when <code>propertyType</code> is &quot;string&quot;)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"native\"",
              "\"iso\"",
              "\"dd/mm/yyyy\"",
              "\"mm/dd/yyyy\"",
              "\"timestamp\"",
              "\"timestamp-ms\""
            ],
            "optional": true,
            "field": "propertyType.options.format",
            "description": "<p>Storage format (required and only applicable when <code>propertyType</code> is &quot;date&quot; or &quot;datetime&quot;)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": true,
            "field": "propertyType.options.timezone",
            "description": "<p>Timezone (format: &quot;[+-]HH:MM | Z&quot;) (only applicable when <code>propertyType</code> is &quot;datetime&quot;)</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "required",
            "description": "<p>Whether the property is required on data edition</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"propertyKey\": \"nutri-score\",\n  \"propertyType\": {\n    \"name\": \"string\",\n    \"options\": {\n      \"values\": [\"A\", \"B\", \"C\", \"D\", \"E\"]\n    }\n  },\n  \"visibility\": \"searchable\",\n  \"required\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/graphSchema.ts",
    "groupTitle": "Schema",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"node\"",
              "\"edge\""
            ],
            "optional": false,
            "field": "entityType",
            "description": "<p>&quot;node&quot; or &quot;edge&quot;</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "label",
            "description": "<p>Name of the graph schema type</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "propertyKey",
            "description": "<p>Name of the property</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"visible\"",
              "\"searchable\"",
              "\"none\""
            ],
            "optional": false,
            "field": "visibility",
            "description": "<p>Whether the property can be searched, visualized or it is hidden</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": false,
            "field": "propertyType",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"auto\"",
              "\"boolean\"",
              "\"date\"",
              "\"datetime\"",
              "\"number\"",
              "\"string\""
            ],
            "optional": false,
            "field": "propertyType.name",
            "description": "<p>Data type of the property</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": true,
            "field": "propertyType.options",
            "description": "<p>Additional <code>propertyType</code> information (required when <code>propertyType.name</code> is &quot;date&quot; or &quot;datetime&quot;)</p>"
          },
          {
            "group": "Parameter",
            "type": "string[]",
            "optional": true,
            "field": "propertyType.options.values",
            "description": "<p>A list of values to restrict the value of the property (only applicable when <code>propertyType</code> is &quot;string&quot;)</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"native\"",
              "\"iso\"",
              "\"dd/mm/yyyy\"",
              "\"mm/dd/yyyy\"",
              "\"timestamp\"",
              "\"timestamp-ms\""
            ],
            "optional": true,
            "field": "propertyType.options.format",
            "description": "<p>Storage format (required and only applicable when <code>propertyType</code> is &quot;date&quot; or &quot;datetime&quot;)</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "propertyType.options.timezone",
            "description": "<p>Timezone (format: &quot;[+-]HH:MM | Z&quot;) (only applicable when <code>propertyType</code> is &quot;datetime&quot;)</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": false,
            "field": "required",
            "description": "<p>Whether the property is required on data edition</p>"
          }
        ]
      }
    }
  },
  {
    "type": "post",
    "url": "/api/admin/:sourceKey/graph/schema/:entityType/types",
    "title": "Create a new graph schema type",
    "name": "CreateGraphSchemaType",
    "group": "Schema",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.schema"
      }
    ],
    "description": "<p>Add a new type to the graph schema.</p>",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "label",
            "description": "<p>Name of the graph schema type</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"visible\"",
              "\"searchable\"",
              "\"none\""
            ],
            "optional": false,
            "field": "visibility",
            "description": "<p>Whether the type can be searched, visualized or it is hidden</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"label\": \"country\",\n  \"visibility\": \"searchable\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/graphSchema.ts",
    "groupTitle": "Schema",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"node\"",
              "\"edge\""
            ],
            "optional": false,
            "field": "entityType",
            "description": "<p>&quot;node&quot; or &quot;edge&quot;</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "label",
            "description": "<p>Name of the graph schema type</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"visible\"",
              "\"searchable\"",
              "\"none\""
            ],
            "optional": true,
            "field": "visibility",
            "description": "<p>Whether the type can be searched, visualized or it is hidden</p>"
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/admin/:sourceKey/graph/schema/:entityType/types",
    "title": "Get the full graph schema",
    "name": "GetAdminGraphSchema",
    "group": "Schema",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.schema"
      }
    ],
    "description": "<p>List all the types and properties of a data-source.</p>",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "results",
            "description": "<p>All existing types in the graph schema</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "results.label",
            "description": "<p>Name of the graph schema type</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"visible\"",
              "\"searchable\"",
              "\"none\""
            ],
            "optional": false,
            "field": "results.visibility",
            "description": "<p>Whether the type can be searched, visualized or it is hidden</p>"
          },
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "results.properties",
            "description": "<p>Properties of <code>label</code></p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "results.properties.propertyKey",
            "description": "<p>Name of the property</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"visible\"",
              "\"searchable\"",
              "\"none\""
            ],
            "optional": false,
            "field": "results.properties.visibility",
            "description": "<p>Whether the property can be searched, visualized or it is hidden</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "results.properties.propertyType",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"auto\"",
              "\"boolean\"",
              "\"date\"",
              "\"datetime\"",
              "\"number\"",
              "\"string\""
            ],
            "optional": false,
            "field": "results.properties.propertyType.name",
            "description": "<p>Data type of the property</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": true,
            "field": "results.properties.propertyType.options",
            "description": "<p>Additional <code>propertyType</code> information (required when <code>propertyType.name</code> is &quot;date&quot; or &quot;datetime&quot;)</p>"
          },
          {
            "group": "Success 200",
            "type": "string[]",
            "optional": true,
            "field": "results.properties.propertyType.options.values",
            "description": "<p>A list of values to restrict the value of the property (only applicable when <code>propertyType</code> is &quot;string&quot;)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"native\"",
              "\"iso\"",
              "\"dd/mm/yyyy\"",
              "\"mm/dd/yyyy\"",
              "\"timestamp\"",
              "\"timestamp-ms\""
            ],
            "optional": true,
            "field": "results.properties.propertyType.options.format",
            "description": "<p>Storage format (required and only applicable when <code>propertyType</code> is &quot;date&quot; or &quot;datetime&quot;)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": true,
            "field": "results.properties.propertyType.options.timezone",
            "description": "<p>Timezone (format: &quot;[+-]HH:MM | Z&quot;) (only applicable when <code>propertyType</code> is &quot;datetime&quot;)</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "results.properties.required",
            "description": "<p>Whether the property is required on data edition</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"results\": [\n    {\n      \"label\": \"country\",\n      \"visibility\": \"searchable\",\n      \"properties\": [\n        {\n          \"propertyKey\": \"GDP\",\n          \"propertyType\": {\"name\": \"number\"},\n          \"visibility\": \"searchable\",\n          \"required\": false\n        },\n        {\n          \"propertyKey\": \"capital city\",\n          \"propertyType\": {\"name\": \"string\"},\n          \"visibility\": \"searchable\",\n          \"required\": true\n        }\n      ]\n    }\n  ]\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/graphSchema.ts",
    "groupTitle": "Schema",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "entityType",
            "description": "<p>&quot;node&quot; or &quot;edge&quot;</p>"
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/:sourceKey/graph/:entityType/types",
    "title": "Get the readable graph schema with access rights",
    "name": "GetGraphSchema",
    "group": "Schema",
    "permission": [
      {
        "name": "guest_user",
        "title": "Guest user",
        "description": "<p>The guest user can use this API if guest mode is allowed.</p>"
      },
      {
        "name": "apiright:schema"
      }
    ],
    "description": "<p>List all the readable types and properties of a data-source.</p>",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "any",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"readable\"",
              "\"editable\"",
              "\"writable\"",
              "\"none\""
            ],
            "optional": false,
            "field": "any.access",
            "description": "<p>Default access level</p>"
          },
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "results",
            "description": "<p>All readable types in the graph schema</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"readable\"",
              "\"editable\"",
              "\"writable\""
            ],
            "optional": false,
            "field": "results.access",
            "description": "<p>Access level of the graph schema type</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "results.label",
            "description": "<p>Name of the graph schema type</p>"
          },
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "results.properties",
            "description": "<p>Properties of <code>label</code></p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"visible\"",
              "\"searchable\"",
              "\"none\""
            ],
            "optional": false,
            "field": "results.properties.visibility",
            "description": "<p>Whether the property can be searched, visualized or it is hidden</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "results.properties.propertyType",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"auto\"",
              "\"boolean\"",
              "\"date\"",
              "\"datetime\"",
              "\"number\"",
              "\"string\""
            ],
            "optional": false,
            "field": "results.properties.propertyType.name",
            "description": "<p>Data type of the property</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": true,
            "field": "results.properties.propertyType.options",
            "description": "<p>Additional <code>propertyType</code> information (required when <code>propertyType.name</code> is &quot;date&quot; or &quot;datetime&quot;)</p>"
          },
          {
            "group": "Success 200",
            "type": "string[]",
            "optional": true,
            "field": "results.properties.propertyType.options.values",
            "description": "<p>A list of values to restrict the value of the property (only applicable when <code>propertyType</code> is &quot;string&quot;)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"native\"",
              "\"iso\"",
              "\"dd/mm/yyyy\"",
              "\"mm/dd/yyyy\"",
              "\"timestamp\"",
              "\"timestamp-ms\""
            ],
            "optional": true,
            "field": "results.properties.propertyType.options.format",
            "description": "<p>Storage format (required and only applicable when <code>propertyType</code> is &quot;date&quot; or &quot;datetime&quot;)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": true,
            "field": "results.properties.propertyType.options.timezone",
            "description": "<p>Timezone (format: &quot;[+-]HH:MM | Z&quot;) (only applicable when <code>propertyType</code> is &quot;datetime&quot;)</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "results.properties.required",
            "description": "<p>Whether the property is required on data edition</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"any\": {\n    \"access\": \"writable\"\n  },\n  \"results\": [\n    {\n      \"name\": \"Movie\",\n      \"access\": \"writable\",\n      \"properties\": [\n        {\n          \"propertyKey\": \"released\",\n          \"propertyType\": {\n            \"name\": \"date\",\n            \"options\": {\n              \"format\": \"iso\"\n            }\n          },\n          \"visibility\": \"searchable\",\n          \"required\": false\n        },\n        {\n          \"propertyKey\": \"title\",\n          \"propertyType\": \"string\",\n          \"visibility\": \"searchable\",\n          \"required\": true\n        }\n      ]\n    }\n  ]\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/graphSchema.ts",
    "groupTitle": "Schema",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "entityType",
            "description": "<p>&quot;node&quot; or &quot;edge&quot;</p>"
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/{sourceKey}/schema/sampling/status",
    "title": "Get the schema sampling status",
    "name": "GetSamplingStatus",
    "group": "Schema",
    "permission": [
      {
        "name": "guest_user",
        "title": "Guest user",
        "description": "<p>The guest user can use this API if guest mode is allowed.</p>"
      },
      {
        "name": "apiright:schema"
      }
    ],
    "description": "<p>Get the schema sampling status.</p>",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"ongoing\"",
              "\"done\"",
              "\"error\""
            ],
            "optional": false,
            "field": "status",
            "description": "<p>The status of the schema sampling</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": true,
            "field": "progress",
            "description": "<p>Percentage of the schema sampling</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": true,
            "field": "message",
            "description": "<p>A human readable string describing the schema sampling status</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"status\": \"ongoing\",\n  \"progress\": \"22.22\",\n  \"message\": \"Sampling nodes with type: \\\"CITY\\\"\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/graphSchema.ts",
    "groupTitle": "Schema",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/:sourceKey/graph/schema/simple",
    "title": "Get simple schema",
    "name": "GetSimpleSchema",
    "group": "Schema",
    "permission": [
      {
        "name": "guest_user",
        "title": "Guest user",
        "description": "<p>The guest user can use this API if guest mode is allowed.</p>"
      },
      {
        "name": "apiright:schema"
      }
    ],
    "description": "<p>List all <code>edgeTypes</code>, <code>nodeCategories</code>, <code>edgeProperties</code>, <code>nodeProperties</code> that exist in the graph database. The user must belongs to at least one group of the data-source to use this API.</p>",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "string[]",
            "optional": false,
            "field": "nodeCategories",
            "description": "<p>List of node categories</p>"
          },
          {
            "group": "Success 200",
            "type": "string[]",
            "optional": false,
            "field": "edgeTypes",
            "description": "<p>List of edge types</p>"
          },
          {
            "group": "Success 200",
            "type": "string[]",
            "optional": false,
            "field": "nodeProperties",
            "description": "<p>List of node properties</p>"
          },
          {
            "group": "Success 200",
            "type": "string[]",
            "optional": false,
            "field": "edgeProperties",
            "description": "<p>List of edge properties</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"nodeCategories\": [\n    \"Movie\",\n    \"Person\"\n  ],\n  \"edgeTypes\": [\n    \"ACTED_IN\",\n    \"DIRECTED\"\n  ],\n  \"nodeProperties\": [\n    \"title\",\n    \"name\",\n    \"released\"\n  ],\n  \"edgeProperties\": [\n    \"role\"\n  ]\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/graphSchema.ts",
    "groupTitle": "Schema",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          }
        ]
      }
    }
  },
  {
    "type": "post",
    "url": "/api/admin/{sourceKey}/schema/sampling/start",
    "title": "Start the schema sampling",
    "name": "StartSchemaSampling",
    "group": "Schema",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.schema"
      }
    ],
    "description": "<p>Start the schema sampling.</p>",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 204 No Content",
          "type": "none"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/graphSchema.ts",
    "groupTitle": "Schema",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          }
        ]
      }
    }
  },
  {
    "type": "post",
    "url": "/api/admin/{sourceKey}/schema/sampling/stop",
    "title": "Stop the schema sampling",
    "name": "StopSchemaSampling",
    "group": "Schema",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.schema"
      }
    ],
    "description": "<p>Stop the schema sampling.</p>",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 204 No Content",
          "type": "none"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/graphSchema.ts",
    "groupTitle": "Schema",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          }
        ]
      }
    }
  },
  {
    "type": "patch",
    "url": "/api/admin/:sourceKey/graph/schema/:entityType/properties",
    "title": "Update a graph schema property",
    "name": "UpdateGraphSchemaProperty",
    "group": "Schema",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.schema"
      }
    ],
    "description": "<p>Update an existing graph schema property.</p>",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 204 No Content",
          "type": "none"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/graphSchema.ts",
    "groupTitle": "Schema",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"node\"",
              "\"edge\""
            ],
            "optional": false,
            "field": "entityType",
            "description": "<p>&quot;node&quot; or &quot;edge&quot;</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "label",
            "description": "<p>Name of the graph schema type</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "propertyKey",
            "description": "<p>Name of the property</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"visible\"",
              "\"searchable\"",
              "\"none\""
            ],
            "optional": true,
            "field": "visibility",
            "description": "<p>Whether the property can be searched, visualized or it is hidden</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": true,
            "field": "propertyType",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"auto\"",
              "\"boolean\"",
              "\"date\"",
              "\"datetime\"",
              "\"number\"",
              "\"string\""
            ],
            "optional": false,
            "field": "propertyType.name",
            "description": "<p>Data type of the property</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": true,
            "field": "propertyType.options",
            "description": "<p>Additional <code>propertyType</code> information (required when <code>propertyType.name</code> is &quot;date&quot; or &quot;datetime&quot;)</p>"
          },
          {
            "group": "Parameter",
            "type": "string[]",
            "optional": true,
            "field": "propertyType.options.values",
            "description": "<p>A list of values to restrict the value of the property (only applicable when <code>propertyType</code> is &quot;string&quot;)</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"native\"",
              "\"iso\"",
              "\"dd/mm/yyyy\"",
              "\"mm/dd/yyyy\"",
              "\"timestamp\"",
              "\"timestamp-ms\""
            ],
            "optional": true,
            "field": "propertyType.options.format",
            "description": "<p>Storage format (required and only applicable when <code>propertyType</code> is &quot;date&quot; or &quot;datetime&quot;)</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "propertyType.options.timezone",
            "description": "<p>Timezone (format: &quot;[+-]HH:MM | Z&quot;) (only applicable when <code>propertyType</code> is &quot;datetime&quot;)</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "required",
            "description": "<p>Whether the property is required on data edition</p>"
          }
        ]
      }
    }
  },
  {
    "type": "patch",
    "url": "/api/admin/:sourceKey/graph/schema/settings",
    "title": "Update the graph schema settings",
    "name": "UpdateGraphSchemaSettings",
    "group": "Schema",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.schema"
      }
    ],
    "description": "<p>Update the strict schema settings of the data-source.</p>",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 204 No Content",
          "type": "none"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/graphSchema.ts",
    "groupTitle": "Schema",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": false,
            "field": "settings",
            "description": "<p>Graph schema settings</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": false,
            "field": "settings.strictSchema",
            "description": "<p>Whether the graph schema is in strict mode</p>"
          }
        ]
      }
    }
  },
  {
    "type": "patch",
    "url": "/api/admin/:sourceKey/graph/schema/:entityType/types",
    "title": "Update a graph schema type",
    "name": "UpdateGraphSchemaType",
    "group": "Schema",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.schema"
      }
    ],
    "description": "<p>Update an existing graph schema type.</p>",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 204 No Content",
          "type": "none"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/graphSchema.ts",
    "groupTitle": "Schema",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"node\"",
              "\"edge\""
            ],
            "optional": false,
            "field": "entityType",
            "description": "<p>&quot;node&quot; or &quot;edge&quot;</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "label",
            "description": "<p>Name of the graph schema type</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"visible\"",
              "\"searchable\"",
              "\"none\""
            ],
            "optional": true,
            "field": "visibility",
            "description": "<p>Whether the type can be searched, visualized or it is hidden</p>"
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/:sourceKey/search/status",
    "title": "Get the indexation status",
    "name": "GetIndexationStatus",
    "group": "Search",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "apiright:graphItem.search"
      }
    ],
    "description": "<p>Get the indexation status for a given data-source.</p>",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"ongoing\"",
              "\"needed\"",
              "\"done\""
            ],
            "optional": false,
            "field": "indexing",
            "description": "<p>The status of the indexation</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": true,
            "field": "indexing_progress",
            "description": "<p>Percentage of the indexation (defined if indexing is <code>ongoing</code>)</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": true,
            "field": "node_count",
            "description": "<p>Number of nodes in the graph database (defined if indexing is <code>ongoing</code>)</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": true,
            "field": "edge_count",
            "description": "<p>Number of edges in the graph database (defined if indexing is <code>ongoing</code>)</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": true,
            "field": "index_size",
            "description": "<p>Number of nodes and edges in the index (defined if indexing is <code>ongoing</code>)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "indexed_source",
            "description": "<p>Key of the data-source (defined if indexing is <code>ongoing</code>)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "indexing_status",
            "description": "<p>A human readable string describing the indexation status</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"indexing\": \"ongoing\",\n  \"indexing_progress\": \"62.55\",\n  \"indexing_status\": \"Currently indexing 12375 nodes/s. Time left: 25 seconds.\",\n  \"node_count\": 10,\n  \"edge_count\": 25,\n  \"index_size\": 19,\n  \"indexed_source\": \"c1d3fe\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/search.ts",
    "groupTitle": "Search",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          }
        ]
      }
    }
  },
  {
    "type": "get|post",
    "url": "/api/:sourceKey/search/:type",
    "title": "Search nodes or edges",
    "name": "Search",
    "group": "Search",
    "permission": [
      {
        "name": "guest_user",
        "title": "Guest user",
        "description": "<p>The guest user can use this API if guest mode is allowed.</p>"
      },
      {
        "name": "apiright:graphItem.search"
      }
    ],
    "description": "<p>Perform a search of nodes or edges based on a search query, a fuzziness value and filters. The list of items that matched the search query is returned.</p>",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"node\"",
              "\"edge\""
            ],
            "optional": false,
            "field": "type",
            "description": "<p>The searched item type</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": true,
            "field": "totalHits",
            "description": "<p>The total number of matching items (if available)</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": true,
            "field": "moreResults",
            "description": "<p>If <code>totalHits</code> is <code>undefined</code>, <code>moreResults</code> will indicate if there are more items or not that can be retrieved (<code>undefined</code> if <code>totalHits</code> is returned)</p>"
          },
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "results",
            "description": "<p>Nodes or edges that matched the search query</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"type\": \"node\",\n  \"totalHits\": 3,\n  \"results\": [\n    {\n      \"id\": 123,\n      \"data\": {\n        \"name\": \"Matrix\",\n        \"released\": 1999\n      },\n      \"categories\": [\n        \"Movie\"\n      ],\n      \"readAt\": 692362800000\n    },\n    {\n      \"id\": 124,\n      \"data\": {\n        \"name\": \"Matrix Reloaded\",\n        \"released\": 2003\n      },\n      \"categories\": [\n        \"Movie\"\n      ],\n      \"readAt\": 692362800000\n    },\n    {\n      \"id\": 125,\n      \"data\": {\n        \"name\": \"Matrix Revolutions\",\n        \"released\": 2003\n      },\n      \"categories\": [\n        \"Movie\"\n      ],\n      \"readAt\": 692362800000\n    }\n  ]\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/search.ts",
    "groupTitle": "Search",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"node\"",
              "\"edge\""
            ],
            "optional": false,
            "field": "type",
            "description": "<p>The item type to search</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "q",
            "description": "<p>Search query</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "size": "0-1",
            "optional": true,
            "field": "fuzziness",
            "description": "<p>Fuzziness value (<code>0</code> means exact match, <code>1</code> completely fuzzy)</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": true,
            "field": "size",
            "description": "<p>Page size (maximum number of returned items)</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": true,
            "field": "from",
            "description": "<p>Offset from the first result</p>"
          },
          {
            "group": "Parameter",
            "type": "string[]",
            "optional": true,
            "field": "categoriesOrTypes",
            "description": "<p>Exclusive list of edge types or node categories to restrict the search on</p>"
          },
          {
            "group": "Parameter",
            "type": "string[][]",
            "optional": true,
            "field": "filter",
            "description": "<p>Array of pairs key-value used to filter the result. The keys represent object properties and the values are what should match for each property</p>"
          }
        ]
      }
    }
  },
  {
    "type": "get|post",
    "url": "/api/:sourceKey/search/:type/full",
    "title": "Search subgraph",
    "name": "SearchAndAddSubGraph",
    "group": "Search",
    "permission": [
      {
        "name": "guest_user",
        "title": "Guest user",
        "description": "<p>The guest user can use this API if guest mode is allowed.</p>"
      },
      {
        "name": "apiright:graphItem.search"
      }
    ],
    "description": "<p>Perform a search of nodes or edges based on a search query, a fuzziness value and filters. A subgraph made of the items that matched the search query and the edges between them is returned.</p>",
    "version": "0.0.0",
    "filename": "server/routes/search.ts",
    "groupTitle": "Search",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"node\"",
              "\"edge\""
            ],
            "optional": false,
            "field": "type",
            "description": "<p>The item type to search</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "q",
            "description": "<p>Search query</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "size": "0-1",
            "optional": true,
            "field": "fuzziness",
            "description": "<p>Fuzziness value (<code>0</code> means exact match, <code>1</code> completely fuzzy)</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": true,
            "field": "size",
            "description": "<p>Page size (maximum number of returned items)</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": true,
            "field": "from",
            "description": "<p>Offset from the first result</p>"
          },
          {
            "group": "Parameter",
            "type": "string[]",
            "optional": true,
            "field": "categoriesOrTypes",
            "description": "<p>Exclusive list of edge types or node categories to restrict the search on</p>"
          },
          {
            "group": "Parameter",
            "type": "string[][]",
            "optional": true,
            "field": "filter",
            "description": "<p>Array of pairs key-value used to filter the result. The keys represent object properties and the values are what should match for each property</p>"
          },
          {
            "group": "Parameter",
            "type": "string[]",
            "optional": true,
            "field": "edgesTo",
            "description": "<p>IDs of nodes that are already visible (they won't be included in the result, but their adjacent edges will be included in the <code>edges</code> field if the other nodes are in <code>nodes</code>)</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "withDigest",
            "description": "<p>Whether to include the adjacency digest in the returned nodes</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "withDegree",
            "description": "<p>Whether to include the degree in the returned nodes</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "nodes",
            "description": "<p>Nodes</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "nodes.id",
            "description": "<p>ID of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "nodes.data",
            "description": "<p>Properties of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "string[]",
            "optional": false,
            "field": "nodes.categories",
            "description": "<p>Categories of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "nodes.readAt",
            "description": "<p>Read timestamp in epoch time</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": true,
            "field": "nodes.statistics",
            "description": "<p>Statistics of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "type:LkDigestItem[]",
            "optional": true,
            "field": "nodes.statistics.digest",
            "description": "<p>Statistics of the neighborhood of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": true,
            "field": "nodes.statistics.degree",
            "description": "<p>Number of neighbors of the node readable by the current user</p>"
          },
          {
            "group": "Success 200",
            "type": "type:LkEdgeDigestItem[]",
            "optional": true,
            "field": "nodes.statistics.supernodeDigest",
            "description": "<p>Simplified statistics of the neighborhood of the node (alternative to <code>digest</code> for supernodes)</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": true,
            "field": "nodes.statistics.supernodeDegree",
            "description": "<p>Number of adjacent edges of the node (alternative to <code>degree</code> for supernodes)</p>"
          },
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "edges",
            "description": "<p>Edges</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "edges.id",
            "description": "<p>ID of the edge</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "edges.data",
            "description": "<p>Properties of the edge</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "edges.type",
            "description": "<p>Type of the edge</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "edges.source",
            "description": "<p>ID of the source node</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "edges.target",
            "description": "<p>ID of the target node</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "edges.readAt",
            "description": "<p>Read timestamp in epoch time</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"nodes\": [\n    {\n      \"id\": 1,\n      \"data\": {\n        \"name\": \"Keanu Reeves\",\n        \"born\": {\n          \"type\": \"date\",\n          \"value\": \"1964-09-02T00:00:00.000Z\"\n        }\n      },\n      \"categories\": [\n        \"Person\"\n      ],\n      \"statistics\": {\n        \"digest\": [\n          {\n            \"nodeCategories\": [\n              \"Movie\",\n              \"TheMatrix\",\n              \"TheMatrixReloaded\"\n            ],\n            \"edgeType\": \"ACTED_IN\",\n            \"nodes\": 3,\n            \"edges\": 3\n          }\n        ]\n      },\n      \"readAt\": 692362800000\n    },\n    {\n      \"id\": 2,\n      \"data\": {\n        \"title\": \"The Matrix\",\n        \"release\": 1999\n      },\n      \"categories\": [\n        \"Movie\"\n      ],\n      \"statistics\": {\n        \"digest\": [\n          {\n            \"nodeCategories\": [\n              \"Person\"\n            ],\n            \"edgeType\": \"ACTED_IN\",\n            \"nodes\": 2,\n            \"edges\": 2\n          }\n        ]\n      },\n      \"readAt\": 692362800000\n    }\n  ],\n  \"edges\": [\n    {\n      \"id\": 100,\n      \"type\": \"ACTED_IN\",\n      \"source\": 1,\n      \"target\": 2,\n      \"data\": {\n        \"role\": \"Neo\"\n      },\n      \"readAt\": 692362800000\n    }\n  ]\n}",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "post",
    "url": "/api/:sourceKey/search/index",
    "title": "Start the indexation",
    "name": "StartIndexation",
    "group": "Search",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.index"
      },
      {
        "name": "apiright:admin.index"
      }
    ],
    "description": "<p>Start the indexation. The API doesn't wait for the indexation to finish.</p>",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 204 No Content",
          "type": "none"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/search.ts",
    "groupTitle": "Search",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          }
        ]
      }
    }
  },
  {
    "type": "post",
    "url": "/api/admin/:dataSource/groups",
    "title": "Create a group",
    "name": "CreateGroup",
    "group": "Users",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.users"
      }
    ],
    "description": "<p>Add a new group.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the group</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/user.js",
    "groupTitle": "Users",
    "success": {
      "fields": {
        "Success 201": [
          {
            "group": "Success 201",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the group</p>"
          },
          {
            "group": "Success 201",
            "type": "string",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the group</p>"
          },
          {
            "group": "Success 201",
            "type": "boolean",
            "optional": false,
            "field": "builtin",
            "description": "<p>Whether the group was created internally by Linkurious</p>"
          },
          {
            "group": "Success 201",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Success 201",
            "type": "number",
            "optional": false,
            "field": "userCount",
            "description": "<p>Number of users in the group</p>"
          },
          {
            "group": "Success 201",
            "type": "string",
            "optional": false,
            "field": "createdAt",
            "description": "<p>Creation date in ISO-8601 format</p>"
          },
          {
            "group": "Success 201",
            "type": "string",
            "optional": false,
            "field": "updatedAt",
            "description": "<p>Last update date in ISO-8601 format</p>"
          },
          {
            "group": "Success 201",
            "type": "object[]",
            "optional": false,
            "field": "accessRights",
            "description": "<p>List of access rights</p>"
          },
          {
            "group": "Success 201",
            "type": "string",
            "allowedValues": [
              "\"read\"",
              "\"write\"",
              "\"edit\"",
              "\"do\"",
              "\"none\""
            ],
            "optional": false,
            "field": "accessRights.type",
            "description": "<p>Type of the right</p>"
          },
          {
            "group": "Success 201",
            "type": "string",
            "allowedValues": [
              "\"nodeCategory\"",
              "\"edgeType\"",
              "\"alert\"",
              "\"action\""
            ],
            "optional": false,
            "field": "accessRights.targetType",
            "description": "<p>Type of the target</p>"
          },
          {
            "group": "Success 201",
            "type": "string",
            "optional": false,
            "field": "accessRights.targetName",
            "description": "<p>Name of the target (node category, edge label, alert id or action name)</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 201 Created\n{\n  \"id\": 31,\n  \"name\": \"newGroup\",\n  \"builtin\": false,\n  \"sourceKey\": \"584f2569\",\n  \"userCount\": 0,\n  \"createdAt\": \"2016-05-16T08:23:35.730Z\",\n  \"updatedAt\": \"2016-05-16T08:23:35.730Z\",\n  \"accessRights\": [\n    {\n      \"type\": \"none\",\n      \"targetType\": \"nodeCategory\",\n      \"targetName\": \"Movie\"\n    },\n    {\n      \"type\": \"none\",\n      \"targetType\": \"nodeCategory\",\n      \"targetName\": \"Person\"\n    },\n    {\n      \"type\": \"none\",\n      \"targetType\": \"edgeType\",\n      \"targetName\": \"ACTED_IN\"\n    }\n  ]\n}",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "post",
    "url": "/api/admin/users",
    "title": "Create a user",
    "name": "CreateUser",
    "group": "Users",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.users"
      }
    ],
    "description": "<p>Add a new user.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "username",
            "description": "<p>Username of the user</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "email",
            "description": "<p>E-mail of the user</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "password",
            "description": "<p>Password of the user</p>"
          },
          {
            "group": "Parameter",
            "type": "number[]",
            "optional": true,
            "field": "groups",
            "description": "<p>IDs of the groups the user belong to</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/user.js",
    "groupTitle": "Users",
    "success": {
      "fields": {
        "Success 201": [
          {
            "group": "Success 201",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the user</p>"
          },
          {
            "group": "Success 201",
            "type": "string",
            "optional": false,
            "field": "username",
            "description": "<p>Username of the user</p>"
          },
          {
            "group": "Success 201",
            "type": "string",
            "optional": false,
            "field": "email",
            "description": "<p>E-mail of the user</p>"
          },
          {
            "group": "Success 201",
            "type": "string",
            "optional": false,
            "field": "source",
            "description": "<p>Source of the user (<code>&quot;local&quot;</code>, <code>&quot;ldap&quot;</code>, <code>&quot;oauth2&quot;</code>, etc.)</p>"
          },
          {
            "group": "Success 201",
            "type": "type:group[]",
            "optional": false,
            "field": "groups",
            "description": "<p>Groups the user belongs to</p>"
          },
          {
            "group": "Success 201",
            "type": "type:preferences",
            "optional": false,
            "field": "preferences",
            "description": "<p>Preferences of the user</p>"
          },
          {
            "group": "Success 201",
            "type": "object",
            "optional": false,
            "field": "actions",
            "description": "<p>Arrays of authorized actions indexed by data-source key. The special key <code>&quot;*&quot;</code> lists actions authorized on all the data-sources</p>"
          },
          {
            "group": "Success 201",
            "type": "object",
            "optional": false,
            "field": "accessRights",
            "description": "<p>Arrays of authorized node categories and edge types indexed by data-source key, by type and by right. The special key <code>&quot;*&quot;</code> lists access rights authorized on all the data-sources</p>"
          },
          {
            "group": "Success 201",
            "type": "string",
            "optional": false,
            "field": "createdAt",
            "description": "<p>Creation date in ISO-8601 format</p>"
          },
          {
            "group": "Success 201",
            "type": "string",
            "optional": false,
            "field": "updatedAt",
            "description": "<p>Last update date in ISO-8601 format</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 201 Created\n{\n  \"id\": 2,\n  \"username\": \"newUser\",\n  \"email\": \"new@linkurio.us\",\n  \"source\": \"local\",\n  \"groups\": [\n    {\n      \"id\": 2,\n      \"name\": \"source manager\",\n      \"builtin\": true,\n      \"sourceKey\": \"584f2569\"\n    }\n  ],\n  \"preferences\": {\n    \"pinOnDrag\": false,\n    \"locale\": \"en-US\",\n    \"incrementalLayout\": false\n  },\n  \"actions\": {\n    \"*\": [],\n    \"584f2569\": [\n      \"admin.users\",\n      \"admin.alerts\",\n      \"admin.connect\",\n      \"admin.index\",\n      \"rawReadQuery\",\n      \"rawWriteQuery\"\n    ]\n  },\n  \"accessRights\": {\n    \"*\": {\n      \"nodes\": {\n        \"edit\": [],\n        \"write\": []\n      },\n      \"edges\": {\n        \"edit\": [],\n        \"write\": []\n      },\n      \"alerts\": {\n        \"read\": []\n      }\n    },\n    \"584f2569\": {\n      \"nodes\": {\n        \"edit\": [],\n        \"write\": [\"*\"]\n      },\n      \"edges\": {\n        \"edit\": [],\n        \"write\": [\"*\"]\n      },\n      \"alerts\": {\n        \"read\": [\"*\"]\n      }\n    }\n  },\n  \"createdAt\": \"2016-05-16T08:23:35.730Z\",\n  \"updatedAt\": \"2016-05-16T08:23:35.730Z\"\n}",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "delete",
    "url": "/api/admin/:dataSource/groups/:id/access_rights",
    "title": "Delete access right",
    "name": "DeleteAccessRight",
    "group": "Users",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.users"
      }
    ],
    "description": "<p>Delete an access right from a group.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "groupId",
            "description": "<p>ID of the group</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"nodeCategory\"",
              "\"edgeType\"",
              "\"alert\"",
              "\"action\""
            ],
            "optional": false,
            "field": "targetType",
            "description": "<p>Type of the target</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "targetName",
            "description": "<p>Name of the target (node category, edge label, alert id or action name)</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 204 No Content",
          "type": "none"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/user.js",
    "groupTitle": "Users"
  },
  {
    "type": "delete",
    "url": "/api/admin/:dataSource/groups/:id",
    "title": "Delete a group",
    "name": "DeleteGroup",
    "group": "Users",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.users"
      }
    ],
    "description": "<p>Delete a group.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the group</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 204 No Content",
          "type": "none"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/user.js",
    "groupTitle": "Users"
  },
  {
    "type": "delete",
    "url": "/api/admin/users/:id",
    "title": "Delete a user",
    "name": "DeleteUser",
    "group": "Users",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.users.delete"
      }
    ],
    "description": "<p>Delete a user.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the user</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 204 No Content",
          "type": "none"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/user.js",
    "groupTitle": "Users"
  },
  {
    "type": "get",
    "url": "/api/admin/groups/rights_info",
    "title": "Get all access rights options",
    "name": "GetAccessRightsInfo",
    "group": "Users",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.users"
      }
    ],
    "description": "<p>Get all the possible access rights options: <code>types</code>, <code>targetTypes</code> and <code>actions</code>.</p>",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "string[]",
            "optional": false,
            "field": "types",
            "description": "<p>All the possible right types</p>"
          },
          {
            "group": "Success 200",
            "type": "string[]",
            "optional": false,
            "field": "targetTypes",
            "description": "<p>All the possible target types</p>"
          },
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "actions",
            "description": "<p>All the possible actions</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "actions.key",
            "description": "<p>Key of the action</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "actions.description",
            "description": "<p>Description of the action</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"types\": [\"read\", \"edit\", \"write\", \"do\", \"none\"],\n  \"targetTypes\": [\"nodeCategory\", \"edgeType\", \"action\", \"alert\"],\n  \"actions\": [\"admin.connect\", \"admin.index\", \"admin.users\", \"admin.alerts\", \"rawReadQuery\", \"rawWriteQuery\"]\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/user.js",
    "groupTitle": "Users"
  },
  {
    "type": "get",
    "url": "/api/admin/:dataSource/groups/:id",
    "title": "Get a group",
    "name": "GetGroup",
    "group": "Users",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.users"
      }
    ],
    "description": "<p>Get a group.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the group</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/user.js",
    "groupTitle": "Users",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the group</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the group</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "builtin",
            "description": "<p>Whether the group was created internally by Linkurious</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "userCount",
            "description": "<p>Number of users in the group</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "createdAt",
            "description": "<p>Creation date in ISO-8601 format</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "updatedAt",
            "description": "<p>Last update date in ISO-8601 format</p>"
          },
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "accessRights",
            "description": "<p>List of access rights</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"read\"",
              "\"write\"",
              "\"edit\"",
              "\"do\"",
              "\"none\""
            ],
            "optional": false,
            "field": "accessRights.type",
            "description": "<p>Type of the right</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"nodeCategory\"",
              "\"edgeType\"",
              "\"alert\"",
              "\"action\""
            ],
            "optional": false,
            "field": "accessRights.targetType",
            "description": "<p>Type of the target</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "accessRights.targetName",
            "description": "<p>Name of the target (node category, edge label, alert id or action name)</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"id\": 30,\n  \"name\": \"customGroup\",\n  \"builtin\": false,\n  \"sourceKey\": \"584f2569\",\n  \"userCount\": 2,\n  \"createdAt\": \"2016-05-16T08:23:35.730Z\",\n  \"updatedAt\": \"2016-05-16T08:23:35.730Z\",\n  \"accessRights\": [\n    {\n      \"type\": \"edit\",\n      \"targetType\": \"nodeCategory\",\n      \"targetName\": \"Movie\"\n    },\n    {\n      \"type\": \"read\",\n      \"targetType\": \"nodeCategory\",\n      \"targetName\": \"Person\"\n    },\n    {\n      \"type\": \"read\",\n      \"targetType\": \"edgeType\",\n      \"targetName\": \"ACTED_IN\"\n    },\n    {\n      \"type\": \"do\",\n      \"targetType\": \"actions\",\n      \"targetName\": \"admin.connect\"\n    }\n  ]\n}",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "get",
    "url": "/api/:dataSource/groups",
    "title": "Get group names",
    "name": "GetGroupNames",
    "group": "Users",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      }
    ],
    "description": "<p>Get the names of groups that can perform a given action on the data-source.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "action",
            "description": "<p>Action to filter on</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/user.js",
    "groupTitle": "Users"
  },
  {
    "type": "get",
    "url": "/api/admin/:dataSource/groups",
    "title": "Get all groups",
    "name": "GetGroups",
    "group": "Users",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.users"
      }
    ],
    "description": "<p>Get all the groups within a data-source.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "with_access_rights",
            "description": "<p>Whether to include the access rights</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "groups",
            "description": "<p>List of groups</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "groups.id",
            "description": "<p>ID of the group</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "groups.name",
            "description": "<p>Name of the group</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "groups.builtin",
            "description": "<p>Whether the group was created internally by Linkurious</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "groups.sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "groups.userCount",
            "description": "<p>Number of users in the group</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "groups.createdAt",
            "description": "<p>Creation date in ISO-8601 format</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "groups.updatedAt",
            "description": "<p>Last update date in ISO-8601 format</p>"
          },
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": true,
            "field": "groups.accessRights",
            "description": "<p>List of access rights</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"read\"",
              "\"write\"",
              "\"edit\"",
              "\"do\"",
              "\"none\""
            ],
            "optional": false,
            "field": "groups.accessRights.type",
            "description": "<p>Type of the right</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"nodeCategory\"",
              "\"edgeType\"",
              "\"alert\"",
              "\"action\""
            ],
            "optional": false,
            "field": "groups.accessRights.targetType",
            "description": "<p>Type of the target</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "groups.accessRights.targetName",
            "description": "<p>Name of the target (node category, edge label, alert id or action name)</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n[\n  {\n    \"id\": 1,\n    \"name\": \"admin\",\n    \"builtin\": true,\n    \"sourceKey\": \"*\",\n    \"userCount\": 1,\n    \"createdAt\": \"2016-05-16T08:23:35.730Z\",\n    \"updatedAt\": \"2016-05-16T08:23:35.730Z\"\n  },\n  {\n    \"id\": 2,\n    \"name\": \"read\",\n    \"builtin\": true,\n    \"sourceKey\": \"584f2569\",\n    \"userCount\": 1,\n    \"createdAt\": \"2016-05-16T08:23:35.730Z\",\n    \"updatedAt\": \"2016-05-16T08:23:35.730Z\"\n  },\n  {\n    \"id\": 3,\n    \"name\": \"read and edit\",\n    \"builtin\": true,\n    \"sourceKey\": \"584f2569\",\n    \"userCount\": 0,\n    \"createdAt\": \"2016-05-16T08:23:35.730Z\",\n    \"updatedAt\": \"2016-05-16T08:23:35.730Z\"\n  },\n  {\n    \"id\": 4,\n    \"name\": \"read, edit and delete\",\n    \"builtin\": true,\n    \"sourceKey\": \"584f2569\",\n    \"userCount\": 0,\n    \"createdAt\": \"2016-05-16T08:23:35.730Z\",\n    \"updatedAt\": \"2016-05-16T08:23:35.730Z\"\n  },\n  {\n    \"id\": 5,\n    \"name\": \"source manager\",\n    \"builtin\": true,\n    \"sourceKey\": \"584f2569\",\n    \"userCount\": 0,\n    \"createdAt\": \"2016-05-16T08:23:35.730Z\",\n    \"updatedAt\": \"2016-05-16T08:23:35.730Z\"\n  },\n  {\n    \"id\": 6,\n    \"name\": \"custom group\",\n    \"builtin\": false,\n    \"sourceKey\": \"584f2569\",\n    \"userCount\": 0,\n    \"createdAt\": \"2016-05-16T08:23:35.730Z\",\n    \"updatedAt\": \"2016-05-16T08:23:35.730Z\"\n  }\n]",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/user.js",
    "groupTitle": "Users"
  },
  {
    "type": "get",
    "url": "/api/admin/users/:id",
    "title": "Get a user",
    "name": "GetUser",
    "group": "Users",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.users"
      }
    ],
    "description": "<p>Get a user by id.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the user</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/user.js",
    "groupTitle": "Users",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "username",
            "description": "<p>Username of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "email",
            "description": "<p>E-mail of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "source",
            "description": "<p>Source of the user (<code>&quot;local&quot;</code>, <code>&quot;ldap&quot;</code>, <code>&quot;oauth2&quot;</code>, etc.)</p>"
          },
          {
            "group": "Success 200",
            "type": "type:group[]",
            "optional": false,
            "field": "groups",
            "description": "<p>Groups the user belongs to</p>"
          },
          {
            "group": "Success 200",
            "type": "type:preferences",
            "optional": false,
            "field": "preferences",
            "description": "<p>Preferences of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "actions",
            "description": "<p>Arrays of authorized actions indexed by data-source key The special key <code>&quot;*&quot;</code> lists actions authorized on all the data-sources</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "accessRights",
            "description": "<p>Arrays of authorized node categories and edge types indexed by data-source key, by type and by right The special key <code>&quot;*&quot;</code> lists access rights authorized on all the data-sources</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "createdAt",
            "description": "<p>Creation date in ISO-8601 format</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "updatedAt",
            "description": "<p>Last update date in ISO-8601 format</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"id\": 1,\n  \"username\": \"Unique user\",\n  \"email\": \"user@linkurio.us\",\n  \"source\": \"local\",\n  \"groups\": [\n    {\n      \"id\": 1,\n      \"name\": \"admin\",\n      \"builtin\": true,\n      \"sourceKey\": \"*\"\n    }\n  ],\n  \"preferences\": {\n    \"pinOnDrag\": false,\n    \"locale\": \"en-US\",\n    \"incrementalLayout\": false\n  },\n  \"actions\": {\n    \"*\": [\n      \"admin.users\",\n      \"admin.alerts\",\n      \"admin.connect\",\n      \"admin.index\",\n      \"admin.app\",\n      \"admin.report\",\n      \"admin.schema\",\n      \"admin.users.delete\",\n      \"admin.config\",\n      \"rawReadQuery\",\n      \"rawWriteQuery\"\n    ]\n  },\n  \"accessRights\": {\n    \"*\": {\n      \"nodes\": {\n        \"edit\": [],\n        \"write\": [\"*\"]\n      },\n      \"edges\": {\n        \"edit\": [],\n        \"write\": [\"*\"]\n      },\n      \"alerts\": {\n        \"read\": [\"*\"]\n      }\n    }\n  },\n  \"createdAt\": \"2016-05-16T08:23:35.730Z\",\n  \"updatedAt\": \"2016-05-16T08:23:45.730Z\"\n}",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "get",
    "url": "/api/users",
    "title": "Get users",
    "name": "GetUsers",
    "group": "Users",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      }
    ],
    "description": "<p>Get all the users or filter them by username, e-mail or group id.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "starts_with",
            "description": "<p>Return only users which username or e-mail starts with this</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "contains",
            "description": "<p>Return only users which username or e-mail contains this</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": true,
            "field": "group_id",
            "description": "<p>Return only users belongings to this group</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": true,
            "field": "offset",
            "description": "<p>Offset from the first result</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": true,
            "field": "limit",
            "defaultValue": "10",
            "description": "<p>Page size (maximum number of returned users)</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"id\"",
              "\"username\"",
              "\"email\""
            ],
            "optional": true,
            "field": "sort_by",
            "defaultValue": "id",
            "description": "<p>Sort by id, username or e-mail</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"asc\"",
              "\"desc\""
            ],
            "optional": true,
            "field": "sort_direction",
            "defaultValue": "asc",
            "description": "<p>Direction used to sort the users</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "found",
            "description": "<p>Number of hits</p>"
          },
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "results",
            "description": "<p>Users</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "results.id",
            "description": "<p>ID of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "results.username",
            "description": "<p>Username of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "results.email",
            "description": "<p>E-mail of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "results.source",
            "description": "<p>Source of the user (<code>&quot;local&quot;</code>, <code>&quot;ldap&quot;</code>, <code>&quot;oauth2&quot;</code>, etc.)</p>"
          },
          {
            "group": "Success 200",
            "type": "type:group[]",
            "optional": false,
            "field": "results.groups",
            "description": "<p>Groups the user belongs to</p>"
          },
          {
            "group": "Success 200",
            "type": "type:preferences",
            "optional": false,
            "field": "results.preferences",
            "description": "<p>Preferences of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "results.actions",
            "description": "<p>Arrays of authorized actions indexed by data-source key The special key <code>&quot;*&quot;</code> lists actions authorized on all the data-sources</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "results.visCount",
            "description": "<p>Number of visualization owned by the user</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "results.createdAt",
            "description": "<p>Creation date in ISO-8601 format</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "results.updatedAt",
            "description": "<p>Last update date in ISO-8601 format</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"found\": 2,\n  \"results\": [\n    {\n      \"id\": 1,\n      \"username\": \"Unique user\",\n      \"email\": \"user@linkurio.us\",\n      \"source\": \"local\",\n      \"groups\": [\n        {\n          \"id\": 1,\n          \"name\": \"admin\",\n          \"builtin\": true,\n          \"sourceKey\": \"*\"\n        }\n      ],\n      \"preferences\": {\n        \"pinOnDrag\": false,\n        \"locale\": \"en-US\",\n        \"incrementalLayout\": false\n      },\n      \"actions\": {\n        \"*\": [\n          \"admin.users\",\n          \"admin.alerts\",\n          \"admin.connect\",\n          \"admin.index\",\n          \"admin.app\",\n          \"admin.report\",\n          \"admin.users.delete\",\n          \"admin.config\",\n          \"rawReadQuery\",\n          \"rawWriteQuery\"\n        ]\n      },\n      \"accessRights\": {\n        \"*\": {\n          \"nodes\": {\n            \"edit\": [],\n            \"write\": [\"*\"]\n          },\n          \"edges\": {\n            \"edit\": [],\n            \"write\": [\"*\"]\n          },\n          \"alerts\": {\n            \"read\": [\"*\"]\n          }\n        }\n      },\n      \"visCount\": 2,\n      \"createdAt\": \"2016-05-16T08:23:35.730Z\",\n      \"updatedAt\": \"2016-05-16T08:23:35.730Z\"\n    },\n    {\n      \"id\": 2,\n      \"username\": \"newUser\",\n      \"email\": \"new@linkurio.us\",\n      \"source\": \"local\",\n      \"groups\": [\n        {\n          \"id\": 2,\n          \"name\": \"source manager\",\n          \"builtin\": true,\n          \"sourceKey\": \"584f2569\"\n        }\n      ],\n      \"preferences\": {\n        \"pinOnDrag\": false,\n        \"locale\": \"en-US\",\n        \"incrementalLayout\": false\n      },\n      \"actions\": {\n        \"*\": [],\n        \"584f2569\": [\n          \"admin.users\",\n          \"admin.alerts\",\n          \"admin.connect\",\n          \"admin.index\",\n          \"rawReadQuery\",\n          \"rawWriteQuery\"\n        ]\n      },\n      \"accessRights\": {\n        \"*\": {\n          \"nodes\": {\n            \"edit\": [],\n            \"write\": []\n          },\n          \"edges\": {\n            \"edit\": [],\n            \"write\": []\n          },\n          \"alerts\": {\n            \"read\": []\n          }\n        },\n        \"584f2569\": {\n          \"nodes\": {\n            \"edit\": [],\n            \"write\": [\"*\"]\n          },\n          \"edges\": {\n            \"edit\": [],\n            \"write\": [\"*\"]\n          },\n          \"alerts\": {\n            \"read\": [\"*\"]\n          }\n        }\n      },\n      \"visCount\": 0,\n      \"createdAt\": \"2016-05-16T08:23:35.730Z\",\n      \"updatedAt\": \"2016-05-16T08:23:35.730Z\"\n    }\n  ]\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/general.js",
    "groupTitle": "Users"
  },
  {
    "type": "post",
    "url": "/api/admin/users/mergeVisualizations",
    "title": "Transfer visualizations between users",
    "name": "MergeVisualizations",
    "group": "Users",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.users"
      }
    ],
    "description": "<p>Transfer all the visualizations from a source user to a target user.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "from",
            "description": "<p>ID of the source user</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "to",
            "description": "<p>ID of the target user</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 204 No Content",
          "type": "none"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/user.js",
    "groupTitle": "Users"
  },
  {
    "type": "put",
    "url": "/api/admin/:dataSource/groups/:id/access_rights",
    "title": "Set access rights",
    "name": "PutAccessRights",
    "group": "Users",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.users"
      }
    ],
    "description": "<p>Set access rights on a group.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "groupId",
            "description": "<p>ID of the group</p>"
          },
          {
            "group": "Parameter",
            "type": "object[]",
            "optional": false,
            "field": "accessRights",
            "description": "<p>List of access rights</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"read\"",
              "\"write\"",
              "\"edit\"",
              "\"do\"",
              "\"none\""
            ],
            "optional": false,
            "field": "accessRights.type",
            "description": "<p>Type of the right</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"nodeCategory\"",
              "\"edgeType\"",
              "\"alert\"",
              "\"action\""
            ],
            "optional": false,
            "field": "accessRights.targetType",
            "description": "<p>Type of the target</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "accessRights.targetName",
            "description": "<p>Name of the target (node category, edge label, alert id or action name)</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "validateAgainstSchema",
            "description": "<p>Whether the access rights will be checked to be of node categories or edge types in the schema</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 204 No Content",
          "type": "none"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/user.js",
    "groupTitle": "Users"
  },
  {
    "type": "patch",
    "url": "/api/admin/:dataSource/groups/:id",
    "title": "Rename a group",
    "name": "RenameGroup",
    "group": "Users",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.users"
      }
    ],
    "description": "<p>Rename a group.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the group</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the group</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/user.js",
    "groupTitle": "Users",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the group</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the group</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "builtin",
            "description": "<p>Whether the group was created internally by Linkurious</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "userCount",
            "description": "<p>Number of users in the group</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "createdAt",
            "description": "<p>Creation date in ISO-8601 format</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "updatedAt",
            "description": "<p>Last update date in ISO-8601 format</p>"
          },
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "accessRights",
            "description": "<p>List of access rights</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"read\"",
              "\"write\"",
              "\"edit\"",
              "\"do\"",
              "\"none\""
            ],
            "optional": false,
            "field": "accessRights.type",
            "description": "<p>Type of the right</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"nodeCategory\"",
              "\"edgeType\"",
              "\"alert\"",
              "\"action\""
            ],
            "optional": false,
            "field": "accessRights.targetType",
            "description": "<p>Type of the target</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "accessRights.targetName",
            "description": "<p>Name of the target (node category, edge label, alert id or action name)</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"id\": 30,\n  \"name\": \"customGroup\",\n  \"builtin\": false,\n  \"sourceKey\": \"584f2569\",\n  \"userCount\": 2,\n  \"createdAt\": \"2016-05-16T08:23:35.730Z\",\n  \"updatedAt\": \"2016-05-16T08:23:35.730Z\",\n  \"accessRights\": [\n    {\n      \"type\": \"edit\",\n      \"targetType\": \"nodeCategory\",\n      \"targetName\": \"Movie\"\n    },\n    {\n      \"type\": \"read\",\n      \"targetType\": \"nodeCategory\",\n      \"targetName\": \"Person\"\n    },\n    {\n      \"type\": \"read\",\n      \"targetType\": \"edgeType\",\n      \"targetName\": \"ACTED_IN\"\n    },\n    {\n      \"type\": \"do\",\n      \"targetType\": \"actions\",\n      \"targetName\": \"admin.connect\"\n    }\n  ]\n}",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "patch",
    "url": "/api/admin/users/:id",
    "title": "Update a user",
    "name": "UpdateUser",
    "group": "Users",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "action:admin.users"
      }
    ],
    "description": "<p>Update a user.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the user</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "username",
            "description": "<p>New username of the user</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "email",
            "description": "<p>New e-mail of the user</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "password",
            "description": "<p>New password of the user</p>"
          },
          {
            "group": "Parameter",
            "type": "type:preferences",
            "optional": true,
            "field": "preferences",
            "description": "<p>New preferences of the user</p>"
          },
          {
            "group": "Parameter",
            "type": "number[]",
            "optional": true,
            "field": "addedGroups",
            "description": "<p>IDs of the groups to add to the user</p>"
          },
          {
            "group": "Parameter",
            "type": "number[]",
            "optional": true,
            "field": "removedGroups",
            "description": "<p>IDs of the groups to remove from the user</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/admin/user.js",
    "groupTitle": "Users",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "username",
            "description": "<p>Username of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "email",
            "description": "<p>E-mail of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "source",
            "description": "<p>Source of the user (<code>&quot;local&quot;</code>, <code>&quot;ldap&quot;</code>, <code>&quot;oauth2&quot;</code>, etc.)</p>"
          },
          {
            "group": "Success 200",
            "type": "type:group[]",
            "optional": false,
            "field": "groups",
            "description": "<p>Groups the user belongs to</p>"
          },
          {
            "group": "Success 200",
            "type": "type:preferences",
            "optional": false,
            "field": "preferences",
            "description": "<p>Preferences of the user</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "actions",
            "description": "<p>Arrays of authorized actions indexed by data-source key The special key <code>&quot;*&quot;</code> lists actions authorized on all the data-sources</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "accessRights",
            "description": "<p>Arrays of authorized node categories and edge types indexed by data-source key, by type and by right The special key <code>&quot;*&quot;</code> lists access rights authorized on all the data-sources</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "createdAt",
            "description": "<p>Creation date in ISO-8601 format</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "updatedAt",
            "description": "<p>Last update date in ISO-8601 format</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"id\": 1,\n  \"username\": \"Unique user\",\n  \"email\": \"user@linkurio.us\",\n  \"source\": \"local\",\n  \"groups\": [\n    {\n      \"id\": 1,\n      \"name\": \"admin\",\n      \"builtin\": true,\n      \"sourceKey\": \"*\"\n    }\n  ],\n  \"preferences\": {\n    \"pinOnDrag\": false,\n    \"locale\": \"en-US\",\n    \"incrementalLayout\": false\n  },\n  \"actions\": {\n    \"*\": [\n      \"admin.users\",\n      \"admin.alerts\",\n      \"admin.connect\",\n      \"admin.index\",\n      \"admin.app\",\n      \"admin.report\",\n      \"admin.schema\",\n      \"admin.users.delete\",\n      \"admin.config\",\n      \"rawReadQuery\",\n      \"rawWriteQuery\"\n    ]\n  },\n  \"accessRights\": {\n    \"*\": {\n      \"nodes\": {\n        \"edit\": [],\n        \"write\": [\"*\"]\n      },\n      \"edges\": {\n        \"edit\": [],\n        \"write\": [\"*\"]\n      },\n      \"alerts\": {\n        \"read\": [\"*\"]\n      }\n    }\n  },\n  \"createdAt\": \"2016-05-16T08:23:35.730Z\",\n  \"updatedAt\": \"2016-05-16T08:23:45.730Z\"\n}",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "post",
    "url": "/api/:dataSource/visualizations",
    "title": "Create a visualization",
    "name": "CreateVisualization",
    "group": "Visualizations",
    "description": "<p>Create a new visualization.</p>",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "apiright:visualization.create"
      }
    ],
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source containing the nodes and edges</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "title",
            "description": "<p>Title of the new visualization</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": true,
            "field": "folder",
            "defaultValue": "-1",
            "description": "<p>ID of the folder to save the visualization in. (<code>-1</code> for root)</p>"
          },
          {
            "group": "Parameter",
            "type": "object[]",
            "optional": false,
            "field": "nodes",
            "description": "<p>Nodes in this visualization</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "nodes.id",
            "description": "<p>Identifier of the node (native ID or alternative ID, see <code>alternativeIds</code>)</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "nodes.selected",
            "description": "<p>Whether the node is selected</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": false,
            "field": "nodes.nodelink",
            "description": "<p>The node position information (in &quot;nodelink&quot; mode)</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "nodes.nodelink.x",
            "description": "<p>X coordinate of the node</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "nodes.nodelink.y",
            "description": "<p>Y coordinate of the node</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "nodes.nodelink.fixed",
            "description": "<p>Whether the node position has been locked</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": true,
            "field": "nodes.geo",
            "description": "<p>The node position information (in &quot;geo&quot; mode)</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": true,
            "field": "nodes.geo.latitude",
            "description": "<p>Latitude of the node (decimal format)</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": true,
            "field": "nodes.geo.longitude",
            "description": "<p>Longitude of the node (decimal format)</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": true,
            "field": "nodes.geo.latitudeDiff",
            "description": "<p>Latitude diff (if the node has been dragged)</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": true,
            "field": "nodes.geo.longitudeDiff",
            "description": "<p>Longitude diff (if the node has been dragged)</p>"
          },
          {
            "group": "Parameter",
            "type": "object[]",
            "optional": false,
            "field": "edges",
            "description": "<p>Edges in this visualization</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "edges.id",
            "description": "<p>Identifier of the edge (native ID or alternative ID, see <code>alternativeIds</code>)</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "edges.selected",
            "description": "<p>Whether the edge is selected</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": true,
            "field": "alternativeIds",
            "description": "<p>If nodes and/or edges should be referenced by a property instead of their database ID</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "alternativeIds.node",
            "description": "<p>Node property to use as identifier instead of database ID</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "alternativeIds.edge",
            "description": "<p>Edge property to use as identifier instead of database ID</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": true,
            "field": "layout",
            "description": "<p>The last layout used</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"force\"",
              "\"hierarchical\""
            ],
            "optional": true,
            "field": "layout.algorithm",
            "description": "<p>Layout algorithm</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "layout.mode",
            "description": "<p>Layout algorithm mode (depends on algorithm)</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "layout.incremental",
            "description": "<p>Whether the layout is incremental (only for <code>&quot;force&quot;</code> algorithm)</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"nodelink\"",
              "\"geo\""
            ],
            "optional": true,
            "field": "mode",
            "defaultValue": "nodelink",
            "description": "<p>The current interaction mode</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": true,
            "field": "geo",
            "description": "<p>Geographical info</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "geo.latitudeProperty",
            "description": "<p>Node property containing the latitude info</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "geo.longitudeProperty",
            "description": "<p>Node property containing the longitude info</p>"
          },
          {
            "group": "Parameter",
            "type": "string[]",
            "optional": true,
            "field": "geo.layers",
            "description": "<p>Names of used leaflet tile layers</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": true,
            "field": "design",
            "description": "<p>Design</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": false,
            "field": "design.styles",
            "description": "<p>Color, size and icon mapping</p>"
          },
          {
            "group": "Parameter",
            "type": "type:NodeStyle[]",
            "optional": false,
            "field": "design.styles.node",
            "description": "<p>Node Styles</p>"
          },
          {
            "group": "Parameter",
            "type": "type:EdgeStyle[]",
            "optional": false,
            "field": "design.styles.edge",
            "description": "<p>Edge Styles</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": false,
            "field": "design.palette",
            "description": "<p>Color and icon palette</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": true,
            "field": "filters",
            "description": "<p>Filters</p>"
          },
          {
            "group": "Parameter",
            "type": "type:Selector[]",
            "optional": true,
            "field": "filters.node",
            "description": "<p>Nodes filter rules</p>"
          },
          {
            "group": "Parameter",
            "type": "type:Selector[]",
            "optional": true,
            "field": "filters.edge",
            "description": "<p>Edges filter rules</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": false,
            "field": "nodeFields",
            "description": "<p>Captions and fields options</p>"
          },
          {
            "group": "Parameter",
            "type": "type:NodeCaption",
            "optional": false,
            "field": "nodeFields.captions",
            "description": "<p>Caption descriptions indexed by node-category</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": false,
            "field": "edgeFields",
            "description": "<p>Captions and fields options</p>"
          },
          {
            "group": "Parameter",
            "type": "type:EdgeCaption",
            "optional": false,
            "field": "edgeFields.captions",
            "description": "<p>Caption descriptions indexed by edge-type</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "visualization",
            "description": "<p>The visualization object</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "visualization.title",
            "description": "<p>Title of the visualization</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "visualization.folder",
            "description": "<p>Parent visualizationFolder ID (<code>null</code> for root folder)</p>"
          },
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "visualization.nodes",
            "description": "<p>Nodes in this visualization</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "visualization.nodes.id",
            "description": "<p>Identifier of the node (native ID or alternative ID, see <code>alternativeIds</code>)</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "visualization.nodes.selected",
            "description": "<p>Whether the node is selected</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "visualization.nodes.nodelink",
            "description": "<p>The node position information (in &quot;nodelink&quot; mode)</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "visualization.nodes.nodelink.x",
            "description": "<p>X coordinate of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "visualization.nodes.nodelink.y",
            "description": "<p>Y coordinate of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "visualization.nodes.nodelink.fixed",
            "description": "<p>Whether the node position has been locked</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "visualization.nodes.geo",
            "description": "<p>The node position information (in &quot;geo&quot; mode)</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "visualization.nodes.geo.latitude",
            "description": "<p>Latitude of the node (decimal format)</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "visualization.nodes.geo.longitude",
            "description": "<p>Longitude of the node (decimal format)</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "visualization.nodes.geo.latitudeDiff",
            "description": "<p>Latitude diff (if the node has been dragged)</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "visualization.nodes.geo.longitudeDiff",
            "description": "<p>Longitude diff (if the node has been dragged)</p>"
          },
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "visualization.edges",
            "description": "<p>Edges in this visualization</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "visualization.edges.id",
            "description": "<p>Identifier of the edge (native ID or alternative ID, see <code>alternativeIds</code>)</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "visualization.edges.selected",
            "description": "<p>Whether the edge is selected</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "visualization.alternativeIds",
            "description": "<p>Used to reference nodes or edges by a property instead of their database ID</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "visualization.alternativeIds.node",
            "description": "<p>Node property to use as identifier instead of database ID</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "visualization.alternativeIds.edge",
            "description": "<p>Edge property to use as identifier instead of database ID</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "visualization.layout",
            "description": "<p>The last used layout</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "visualization.layout.algorithm",
            "description": "<p>Layout algorithm name (&quot;force&quot;, &quot;hierarchical&quot;)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "visualization.layout.mode",
            "description": "<p>Layout algorithm mode (depends on algorithm)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "visualization.layout.incremental",
            "description": "<p>Whether the layout is incremental (only for <code>&quot;force&quot;</code> algorithm)</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "visualization.geo",
            "description": "<p>Geographical info</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "visualization.geo.latitudeProperty",
            "description": "<p>Node property containing the latitude</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "visualization.geo.longitudeProperty",
            "description": "<p>Node property containing the longitude</p>"
          },
          {
            "group": "Success 200",
            "type": "string[]",
            "optional": false,
            "field": "visualization.geo.layers",
            "description": "<p>Names of enabled leaflet tile layers</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"nodelink\"",
              "\"geo\""
            ],
            "optional": false,
            "field": "visualization.mode",
            "description": "<p>The current interaction mode</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "visualization.design",
            "description": "<p>Design</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "visualization.design.styles",
            "description": "<p>Style mappings</p>"
          },
          {
            "group": "Success 200",
            "type": "type:NodeStyle[]",
            "optional": false,
            "field": "visualization.design.styles.node",
            "description": "<p>Node Styles</p>"
          },
          {
            "group": "Success 200",
            "type": "type:EdgeStyle[]",
            "optional": false,
            "field": "visualization.design.styles.edge",
            "description": "<p>Edge Styles</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "visualization.design.palette",
            "description": "<p>Color and icon palette</p>"
          },
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "visualization.filters",
            "description": "<p>Filters</p>"
          },
          {
            "group": "Success 200",
            "type": "type:Selector[]",
            "optional": false,
            "field": "visualization.filters.node",
            "description": "<p>Node filter rules</p>"
          },
          {
            "group": "Success 200",
            "type": "type:Selector[]",
            "optional": false,
            "field": "visualization.filters.edge",
            "description": "<p>Edge filter rules</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "visualization.nodeFields",
            "description": "<p>Captions and fields options</p>"
          },
          {
            "group": "Success 200",
            "type": "type:NodeCaption",
            "optional": false,
            "field": "visualization.nodeFields.captions",
            "description": "<p>Caption descriptions indexed by node-category</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "visualization.edgeFields",
            "description": "<p>Captions and fields options</p>"
          },
          {
            "group": "Success 200",
            "type": "type:EdgeCaption",
            "optional": false,
            "field": "visualization.edgeFields.captions",
            "description": "<p>Caption descriptions indexed by edge-type</p>"
          },
          {
            "group": "Success 200",
            "type": "type:Timeline",
            "optional": true,
            "field": "visualization.timeline",
            "description": "<p>Timeline configuration</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "visualization.timeline.node",
            "description": "<p>Key value pairs representing the node type and property to be included in the timeline</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "visualization.timeline.edge",
            "description": "<p>Key value pairs representing the node type and property to be included in the timeline</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": true,
            "field": "visualization.timeline.range",
            "description": "<p>The selected time frame to filter the visualization data</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": true,
            "field": "visualization.timeline.range.",
            "description": "<p>&lt;=]     Less than or equal (date in milliseconds)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"years\"",
              "\"months\"",
              "\"days\"",
              "\"hours\"",
              "\"minutes\"",
              "\"seconds\""
            ],
            "optional": true,
            "field": "visualization.scope",
            "description": "<p>Scope level to display the timeline</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/visualization.js",
    "groupTitle": "Visualizations"
  },
  {
    "type": "delete",
    "url": "/api/:dataSource/visualizations/:id",
    "title": "Delete a visualization",
    "name": "DeleteVisualization",
    "group": "Visualizations",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "apiright:visualization.delete"
      }
    ],
    "description": "<p>Delete the visualization selected by id.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the visualization</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 204 No Content",
          "type": "none"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/visualization.js",
    "groupTitle": "Visualizations"
  },
  {
    "type": "post",
    "url": "/api/:dataSource/visualizations/:id/duplicate",
    "title": "Duplicate a visualization",
    "name": "DuplicateVisualization",
    "group": "Visualizations",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "apiright:visualization.create"
      }
    ],
    "description": "<p>Duplicates a visualization.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>The id of the visualization to duplicate</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "title",
            "description": "<p>Name of the created visualization (defaults to &quot;Copy of [source title]&quot;)</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": true,
            "field": "folder",
            "description": "<p>ID of the folder to duplicate the visualization to (defaults to the source visualization's folder)</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "result",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "result.visualizationId",
            "description": "<p>The id of the visualization copy</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/visualization.js",
    "groupTitle": "Visualizations"
  },
  {
    "type": "get",
    "url": "/api/:dataSource/visualizations/:id",
    "title": "Get a visualization",
    "name": "GetVisualization",
    "group": "Visualizations",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "apiright:visualization.read"
      }
    ],
    "description": "<p>Return a visualization selected by ID.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the isualization</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "populated",
            "defaultValue": "false",
            "description": "<p>Whether nodes and edges are populated of data, categories, type, source and target</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "with_digest",
            "defaultValue": "false",
            "description": "<p>Whether to include the adjacency digest in the returned nodes</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "with_degree",
            "defaultValue": "false",
            "description": "<p>Whether to include the degree in the returned nodes</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "visualization",
            "description": "<p>The visualization</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "visualization.id",
            "description": "<p>ID of the visualization</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "visualization.title",
            "description": "<p>Title of the visualization</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "visualization.folder",
            "description": "<p>Parent visualizationFolder ID (-1 for root folder)</p>"
          },
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "visualization.nodes",
            "description": "<p>Nodes in this visualization</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "visualization.nodes.id",
            "description": "<p>ID of the node (native or alternative ID)</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "visualization.nodes.nodelink",
            "description": "<p>The node position (in &quot;nodelink&quot; mode)</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "visualization.nodes.nodelink.x",
            "description": "<p>X coordinate of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "visualization.nodes.nodelink.y",
            "description": "<p>Y coordinate of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "visualization.nodes.geo",
            "description": "<p>The node position (in &quot;geo&quot; mode)</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": true,
            "field": "visualization.nodes.geo.latitude",
            "description": "<p>Latitude of the node (decimal format)</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": true,
            "field": "visualization.nodes.geo.longitude",
            "description": "<p>Longitude of the node (decimal format)</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "visualization.nodes.geo.latitudeDiff",
            "description": "<p>Latitude diff (if the node has been dragged)</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "visualization.nodes.geo.longitudeDiff",
            "description": "<p>Longitude diff (if the node has been dragged)</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "visualization.nodes.selected",
            "description": "<p>Whether the node is selected</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": true,
            "field": "visualization.nodes.data",
            "description": "<p>Properties of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "string[]",
            "optional": true,
            "field": "visualization.nodes.categories",
            "description": "<p>Categories of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": true,
            "field": "visualization.nodes.statistics",
            "description": "<p>Statistics of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "type:LkDigestItem[]",
            "optional": true,
            "field": "visualization.nodes.statistics.digest",
            "description": "<p>Statistics of the neighborhood of the node</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": true,
            "field": "visualization.nodes.statistics.degree",
            "description": "<p>Number of neighbors of the node readable by the current user</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "visualization.nodes.readAt",
            "description": "<p>Read timestamp in epoch time</p>"
          },
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "visualization.edges",
            "description": "<p>Edges in this visualization</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "visualization.edges.id",
            "description": "<p>ID of the edge (native or alternative ID)</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "visualization.edges.selected",
            "description": "<p>Whether the edge is selected</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": true,
            "field": "visualization.edges.type",
            "description": "<p>Type of the edge</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": true,
            "field": "visualization.edges.data",
            "description": "<p>Properties of the edge</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": true,
            "field": "visualization.edges.source",
            "description": "<p>Source of the edge</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": true,
            "field": "visualization.edges.target",
            "description": "<p>Target of the edge</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "visualization.edges.readAt",
            "description": "<p>Read timestamp in epoch time</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "visualization.design",
            "description": "<p>Design</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "visualization.design.styles",
            "description": "<p>Style mappings</p>"
          },
          {
            "group": "Success 200",
            "type": "type:NodeStyle[]",
            "optional": false,
            "field": "visualization.design.styles.node",
            "description": "<p>Node Styles</p>"
          },
          {
            "group": "Success 200",
            "type": "type:EdgeStyle[]",
            "optional": false,
            "field": "visualization.design.styles.edge",
            "description": "<p>Edge Styles</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "visualization.design.palette",
            "description": "<p>Color and icon palette</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"nodelink\"",
              "\"geo\""
            ],
            "optional": false,
            "field": "visualization.mode",
            "description": "<p>The current interaction mode</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "visualization.layout",
            "description": "<p>The last used layout</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "visualization.layout.algorithm",
            "description": "<p>Layout algorithm name (<code>&quot;force&quot;</code>, <code>&quot;hierarchical&quot;</code>)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "visualization.layout.mode",
            "description": "<p>Layout algorithm mode (depends on the algorithm)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": true,
            "field": "visualization.layout.incremental",
            "description": "<p>Whether the layout is incremental (only for <code>&quot;force&quot;</code> algorithm)</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "visualization.geo",
            "description": "<p>Geographical info</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": true,
            "field": "visualization.geo.latitudeProperty",
            "description": "<p>Property name containing the latitude</p>"
          },
          {
            "group": "Success 200",
            "type": "string[]",
            "optional": false,
            "field": "visualization.geo.layers",
            "description": "<p>Names of enabled leaflet tile layers</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "createdAt",
            "description": "<p>Creation date in ISO-8601 format</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "updatedAt",
            "description": "<p>Last update date in ISO-8601 format</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "visualization.alternativeIds",
            "description": "<p>Used to reference nodes or edges by a property instead of their database ID</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": true,
            "field": "visualization.alternativeIds.node",
            "description": "<p>Node property to use as identifier instead of database ID</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": true,
            "field": "visualization.alternativeIds.edge",
            "description": "<p>Edge property to use as identifier instead of database ID</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "visualization.filters",
            "description": "<p>Filters</p>"
          },
          {
            "group": "Success 200",
            "type": "type:Selector[]",
            "optional": false,
            "field": "visualization.filters.node",
            "description": "<p>Nodes filter rules</p>"
          },
          {
            "group": "Success 200",
            "type": "type:Selector[]",
            "optional": false,
            "field": "visualization.filters.edge",
            "description": "<p>Edges filter rules</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "visualization.sourceKey",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "visualization.user",
            "description": "<p>Owner of the visualization</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "visualization.userId",
            "description": "<p>ID of the owner of the visualization</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "visualization.widgetKey",
            "description": "<p>Key of the widget (<code>null</code> if the no widget exists)</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "visualization.sandbox",
            "description": "<p>Whether the visualization is the sandbox</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "visualization.right",
            "description": "<p>Right on the visualization of the current user</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "visualization.nodeFields",
            "description": "<p>Captions and fields options</p>"
          },
          {
            "group": "Success 200",
            "type": "type:NodeCaption",
            "optional": false,
            "field": "visualization.nodeFields.captions",
            "description": "<p>Caption descriptions indexed by node category</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "visualization.edgeFields",
            "description": "<p>Captions and fields options</p>"
          },
          {
            "group": "Success 200",
            "type": "type:EdgeCaption",
            "optional": false,
            "field": "visualization.edgeFields.captions",
            "description": "<p>Caption descriptions indexed by edge type</p>"
          },
          {
            "group": "Success 200",
            "type": "type:Timeline",
            "optional": true,
            "field": "visualization.timeline",
            "description": "<p>Timeline configuration</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "visualization.timeline.node",
            "description": "<p>Key value pairs representing the node type and property to be included in the timeline</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "visualization.timeline.edge",
            "description": "<p>Key value pairs representing the node type and property to be included in the timeline</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": true,
            "field": "visualization.timeline.range",
            "description": "<p>The selected time frame to filter the visualization data</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": true,
            "field": "visualization.timeline.range.",
            "description": "<p>&lt;=]       Less than or equal (date in milliseconds)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "allowedValues": [
              "\"years\"",
              "\"months\"",
              "\"days\"",
              "\"hours\"",
              "\"minutes\"",
              "\"seconds\""
            ],
            "optional": true,
            "field": "visualization.scope",
            "description": "<p>Scope level to display the timeline</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"visualization\": {\n    \"id\": 2,\n    \"title\": \"Viz name\",\n    \"folder\": -1,\n    \"nodes\": [\n      {\n        \"id\": 1,\n        \"nodelink\": {\n          \"x\": 10.124,\n          \"y\": 12.505\n        },\n        \"geo\": {\n          \"latitudeDiff\": 0,\n          \"longitudeDiff\": 0\n        },\n        \"selected\": true,\n        \"data\": {\n          \"firstName\": \"David\"\n        },\n        \"categories\": [\n          \"Person\"\n        ],\n        \"statistics\": {\n          \"digest\": [\n            {\n              \"edgeType\": \"worksAt\",\n              \"nodeCategories\": [\n                \"Company\"\n              ],\n              \"nodes\": 1,\n              \"edges\": 1\n            }\n          ]\n        },\n        \"readAt\": 692362800000\n      },\n      {\n        \"id\": 2,\n        \"nodelink\": {\n          \"x\": -6.552,\n          \"y\": -8.094\n        },\n        \"geo\": {\n          \"latitudeDiff\": 0,\n          \"longitudeDiff\": 0\n        },\n        \"data\": {\n          \"name\": \"Linkurious\"\n        },\n        \"categories\": [\n          \"Company\"\n        ],\n        \"statistics\": {\n          \"digest\": [\n            {\n              \"edgeType\": \"worksAt\",\n              \"nodeCategories\": [\n                \"Person\"\n              ],\n              \"nodes\": 1,\n              \"edges\": 1\n            }\n          ]\n        },\n        \"readAt\": 692362800000\n      }\n    ],\n    \"edges\": [\n      {\n        \"id\": 0,\n        \"type\": \"worksAt\",\n        \"data\": {},\n        \"source\": 1,\n        \"target\": 2,\n        \"readAt\": 692362800000\n      }\n    ],\n    \"nodeFields\": {\n      \"captions\": {\n        \"Person\": {\n          \"active\": true,\n          \"displayName\": true,\n          \"properties\": []\n        },\n        \"Company\": {\n          \"active\": true,\n          \"displayName\": true,\n          \"properties\": []\n        },\n        \"No category\": {\n          \"active\": true,\n          \"displayName\": true,\n          \"properties\": []\n        }\n      }\n    },\n    \"edgeFields\": {\n      \"captions\": {\n        \"worksAt\": {\n          \"name\": \"worksAt\",\n          \"active\": true,\n          \"displayName\": true,\n          \"properties\": []\n        }\n      }\n    },\n    \"design\": {\n      // ...\n    },\n    \"filters\": {\n       \"node\": [{\n         \"type\": \"any\",\n         \"itemType\": \"Person\",\n         \"input\": [\"properties\", \"firstName\"],\n         \"value\": \"David\"\n       }],\n       \"edge\": []\n    },\n    \"sourceKey\": \"860555c4\",\n    \"user\": {\n      \"id\": 1,\n      \"username\": \"Unique user\",\n      \"email\": \"user@linkurio.us\",\n      \"source\": \"local\",\n      \"preferences\": {\n        \"pinOnDrag\": false,\n        \"locale\": \"en-US\",\n        \"incrementalLayout\": false\n      }\n    },\n    \"userId\": 1,\n    \"sandbox\": false,\n    \"createdAt\": \"2017-06-01T12:30:40.397Z\",\n    \"updatedAt\": \"2017-06-01T12:30:55.389Z\",\n    \"alternativeIds\": {},\n    \"mode\": \"nodelink\",\n    \"layout\": {\n      \"incremental\": false,\n      \"algorithm\": \"force\",\n      \"mode\": \"fast\"\n    },\n    \"geo\": {\n      \"layers\": []\n    },\n    \"right\": \"owner\",\n    \"widgetKey\": null\n  }\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/visualization.js",
    "groupTitle": "Visualizations"
  },
  {
    "type": "get",
    "url": "/api/:dataSource/visualizations/count",
    "title": "Get visualizations count",
    "name": "GetVisualizationCount",
    "group": "Visualizations",
    "permission": [
      {
        "name": "guest_user",
        "title": "Guest user",
        "description": "<p>The guest user can use this API if guest mode is allowed.</p>"
      }
    ],
    "description": "<p>Get the number of visualizations for this data-source.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "count",
            "description": ""
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/visualization.js",
    "groupTitle": "Visualizations"
  },
  {
    "type": "patch",
    "url": "/api/:dataSource/visualizations/:id",
    "title": "Update a visualization",
    "name": "UpdateVisualization",
    "group": "Visualizations",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "apiright:visualization.edit"
      }
    ],
    "description": "<p>Update visualization selected by id.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source (ignored in this API)</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>Visualization ID</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": false,
            "field": "visualization",
            "description": "<p>The visualization object. Only passed fields will be updated</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "force_lock",
            "defaultValue": "false",
            "description": "<p>Take the edit-lock by force (in case the current user doesn't own it)</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "do_layout",
            "defaultValue": "false",
            "description": "<p>Do a server-side layout of the visualization graph</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/visualization.js",
    "groupTitle": "Visualizations"
  },
  {
    "type": "post",
    "url": "/api/:dataSource/visualizations/folder",
    "title": "Create a visualization folder",
    "name": "createVisualizationFolder",
    "group": "Visualizations",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "apiright:visualizationFolder.create"
      }
    ],
    "description": "<p>Create a folder for visualizations</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "title",
            "description": "<p>Folder title</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "parent",
            "description": "<p>Parent folder id</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/visualization.js",
    "groupTitle": "Visualizations"
  },
  {
    "type": "post",
    "url": "/api/widget",
    "title": "Create a widget",
    "name": "createVisualizationWidget",
    "group": "Visualizations",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "apiright:widget.create"
      }
    ],
    "description": "<p>Create a widget for a visualization.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "visualization_id",
            "description": "<p>The visualization id</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": true,
            "field": "options",
            "description": "<p>The configuration of the user interface elements</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "options.search",
            "defaultValue": "false",
            "description": "<p>Whether the search bar is shown</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "options.share",
            "defaultValue": "false",
            "description": "<p>The the share button is shown</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "options.fullscreen",
            "defaultValue": "false",
            "description": "<p>Whether the full-screen button is shown</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "options.zoom",
            "defaultValue": "false",
            "description": "<p>Whether to zoom-in and zoom-out controllers are shown</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "options.legend",
            "defaultValue": "false",
            "description": "<p>Whether the graph legend is shown</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "options.geo",
            "defaultValue": "false",
            "description": "<p>Whether the geo-mode toggle button is visible. Ignored if the nodes don't have geo coordinates</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "options.password",
            "description": "<p>Optional password to protect the widget</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "key",
            "description": "<p>The key of the created widget</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/visualization.js",
    "groupTitle": "Visualizations"
  },
  {
    "type": "delete",
    "url": "/api/:dataSource/visualizations/folder/:id",
    "title": "Delete a visualization folder",
    "name": "deleteVisualizationFolder",
    "group": "Visualizations",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "apiright:visualizationFolder.delete"
      }
    ],
    "description": "<p>Remove the specified folder</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "visualization",
            "description": "<p>ID</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source (for API homogeneity, not actually used)</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/visualization.js",
    "groupTitle": "Visualizations"
  },
  {
    "type": "delete",
    "url": "/api/:dataSource/visualizations/:id/share/:userId",
    "title": "Un-share a visualization",
    "name": "deleteVisualizationShare",
    "group": "Visualizations",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "apiright:visualizationShare.delete"
      }
    ],
    "description": "<p>Remove a share right of a user on a visualization</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "userId",
            "description": "<p>id of a user</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/visualization.js",
    "groupTitle": "Visualizations"
  },
  {
    "type": "delete",
    "url": "/api/widget/:key",
    "title": "Delete a widget",
    "name": "deleteVisualizationWidget",
    "group": "Visualizations",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "apiright:widget.delete"
      }
    ],
    "description": "<p>Delete a widget for a visualization.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "key",
            "description": "<p>the key of the widget to delete</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/visualization.js",
    "groupTitle": "Visualizations"
  },
  {
    "type": "get",
    "url": "/api/:dataSource/sandbox",
    "title": "Get the visualization sandbox",
    "name": "getSandbox",
    "group": "Visualizations",
    "permission": [
      {
        "name": "guest_user",
        "title": "Guest user",
        "description": "<p>The guest user can use this API if guest mode is allowed.</p>"
      },
      {
        "name": "apiright:sandbox"
      }
    ],
    "description": "<p>Return the visualization sandbox of the current user for a given data-source</p>",
    "examples": [
      {
        "title": "Populate examples:",
        "content": "# Visualization by ID\ncurl -i \"http://localhost:3000/api/e4b5d8/sandbox?populate=visualizationId&item_id=123\"\n\n# Node by ID\ncurl -i \"http://localhost:3000/api/e4b5d8/sandbox?populate=nodeId&item_id=123\"\n\n# Edge by ID\ncurl -i \"http://localhost:3000/api/e4b5d8/sandbox?populate=edgeId&item_id=456\"\n\n# Node by ID + neighbors\ncurl -i \"http://localhost:3000/api/e4b5d8/sandbox?populate=expandNodeId&item_id=123\"\n\n# Nodes by search query\ncurl -i \"http://localhost:3000/api/e4b5d8/sandbox?populate=searchNodes&search_query=paris&search_fuzziness=0.2\"\n\n# Edges by search query\ncurl -i \"http://localhost:3000/api/e4b5d8/sandbox?populate=searchEdges&search_query=has_city\"\n\n# Nodes and/or edges by pattern query\ncurl -i \"http://localhost:3000/api/e4b5d8/sandbox?populate=pattern&pattern_dialect=cypher&pattern_query=MATCH+(n1)-%5Be%5D-(n2)+WHERE+ID(n1)%3D10+RETURN+e\"",
        "type": "curl"
      }
    ],
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"visualizationId\"",
              "\"expandNodeId\"",
              "\"nodeId\"",
              "\"edgeId\"",
              "\"searchNodes\"",
              "\"searchEdges\"",
              "\"pattern\"",
              "\"matchId\""
            ],
            "optional": true,
            "field": "populate",
            "description": "<p>Describes how the sandbox should be populated</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "item_id",
            "description": "<p>ID of the node, edge or visualization to load (when <code>populate</code> is one of  <code>[&quot;visualizationId&quot;, &quot;nodeId&quot;, &quot;edgeId&quot;, &quot;expandNodeId&quot;]</code>)</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": true,
            "field": "match_id",
            "description": "<p>ID of alert match to load (when <code>populate</code> is <code>&quot;matchId&quot;</code>)</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "search_query",
            "description": "<p>Search query to search for nodes or edges (when <code>populate</code> is one of  <code>[&quot;searchNodes&quot;, &quot;searchEdges&quot;]</code>)</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "size": "0-1",
            "optional": true,
            "field": "search_fuzziness",
            "defaultValue": "0.1",
            "description": "<p>Search query fuzziness (when <code>populate</code> is one of  <code>[&quot;searchNodes&quot;, &quot;searchEdges&quot;]</code>)</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "pattern_query",
            "description": "<p>Pattern query to match nodes and/or edges (when <code>populate</code> is <code>&quot;pattern&quot;</code>)</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "do_layout",
            "description": "<p>Whether to do a server-side layout of the graph</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"cypher\"",
              "\"gremlin\""
            ],
            "optional": true,
            "field": "pattern_dialect",
            "description": "<p>Pattern dialect (when <code>populate</code> is <code>&quot;pattern&quot;</code>)</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "with_digest",
            "defaultValue": "false",
            "description": "<p>Whether to include the adjacency digest in the returned nodes</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "with_degree",
            "defaultValue": "false",
            "description": "<p>Whether to include the degree in the returned nodes</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/visualization.js",
    "groupTitle": "Visualizations"
  },
  {
    "type": "get",
    "url": "/api/:dataSource/visualizations/tree",
    "title": "Get the visualization tree",
    "name": "getVisualizationTree",
    "group": "Visualizations",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "apiright:visualization.list"
      }
    ],
    "description": "<p>Return visualizations ordered with folders hierarchy.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "response",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "response.tree",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "response.tree.type",
            "description": "<p><code>&quot;visu&quot;</code> or <code>&quot;folder&quot;</code></p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "response.tree.id",
            "description": "<p>visualization or folder ID</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "response.tree.title",
            "description": "<p>visualization or folder title</p>"
          },
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": true,
            "field": "response.tree.children",
            "description": "<p>children visualizations and folders (mandatory when <code>type</code> is <code>&quot;folder&quot;</code>)</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": true,
            "field": "response.tree.shareCount",
            "description": "<p>number of users a visualization is shared with (mandatory <code>type</code> is <code>&quot;visu&quot;</code>)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": true,
            "field": "response.tree.widgetKey",
            "description": "<p>key of the widget created for this visualization (possible if <code>type</code> is <code>&quot;visu&quot;</code>)</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"tree\": [\n   {\n     \"id\": 1,\n     \"type\": \"folder\",\n     \"title\": \"Toto\",\n     \"children\": [\n       {\n         \"id\": 2,\n         \"type\": \"folder\",\n         \"title\": \"Titi\",\n         \"children\": [\n           {\n             \"id\": 3,\n             \"type\": \"visu\",\n             \"title\": \"vis. three\",\n             \"shareCount\": 0,\n             \"widgetKey\": \"aef3ce\"\n           }\n         ]\n       },\n       {\n         \"id\": 1,\n         \"type\": \"visu\",\n         \"title\": \"a\",\n         \"shareCount\": 0\n       },\n       {\n         \"id\": 2,\n         \"type\": \"visu\",\n         \"title\": \"vis. two\",\n         \"shareCount\": 0\n       }\n     ]\n   },\n   {\n     \"id\": 4,\n     \"type\": \"visu\",\n     \"title\": \"vis. four\",\n     \"shareCount\": 0\n   }\n ]\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/visualization.js",
    "groupTitle": "Visualizations"
  },
  {
    "type": "get",
    "url": "/api/widget/:key",
    "title": "Get a widget",
    "name": "getWidgetByKey",
    "group": "Visualizations",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "apiright:widget.read"
      }
    ],
    "description": "<p>Get a visualization widget's data by key</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "key",
            "description": "<p>the key of a widget</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "title",
            "description": "<p>the title of the visualization used to generate this widget</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "key",
            "description": "<p>the key of this widget</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "userId",
            "description": "<p>the owner ID of the visualization used to generate this widget</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "visualizationId",
            "description": "<p>the ID of the visualization used to generate this widget</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "password",
            "description": "<p>Whether password protection is enabled</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "content",
            "description": "<p>the content of the widget, as sent while generating this widget</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n\n{\n  \"title\": \"Foo Bar\",\n  \"key\": \"key\",\n  \"userId\": 12,\n  \"password\": false,\n  \"visualizationId\": 3,\n  \"content\": {\n     \"key\": \"value\"\n  }\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "server/routes/visualization.js",
    "groupTitle": "Visualizations"
  },
  {
    "type": "put",
    "url": "/api/:dataSource/visualizations/:id/share/:userId",
    "title": "Share a visualization",
    "name": "setVisualizationShare",
    "group": "Visualizations",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "apiright:visualizationShare.create"
      }
    ],
    "description": "<p>Set the share right of a user on a visualization</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "userId",
            "description": "<p>id of a user User to grant access to</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"read\"",
              "\"write\""
            ],
            "optional": false,
            "field": "right",
            "description": "<p>Granted access level</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>a visualization id Visualization to grant access to</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "visualizationId",
            "description": "<p>ID of the shared visualization</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "userId",
            "description": "<p>ID of the user the visualization has been shared with</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "right",
            "description": "<p>Name of the right (<code>&quot;none&quot;</code>, <code>&quot;read&quot;</code>, <code>&quot;write&quot;</code> or <code>&quot;owner&quot;</code>)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "createdAt",
            "description": "<p>Date the visualization has been shared</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "updatedAt",
            "description": "<p>Date at which the share has been updated</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/visualization.js",
    "groupTitle": "Visualizations"
  },
  {
    "type": "get",
    "url": "/api/:dataSource/visualizations/shared",
    "title": "Get visualizations shared with current user",
    "name": "sharedVisualizations",
    "group": "Visualizations",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "apiright:visualization.list"
      }
    ],
    "description": "<p>Get all visualizations shared with the current user</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "title",
            "description": "<p>Title of the visualization</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "visualizationId",
            "description": "<p>ID of the visualization</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "ownerId",
            "description": "<p>ID of the user that owns the visualization</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "sourceKey",
            "description": "<p>Key of the dataSource the visualization is related to</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/visualization.js",
    "groupTitle": "Visualizations"
  },
  {
    "type": "patch",
    "url": "/api/:dataSource/sandbox",
    "title": "Update the visualization sandbox",
    "name": "updateSandbox",
    "group": "Visualizations",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "apiright:sandbox"
      }
    ],
    "description": "<p>Update the sandbox of the current user for a given data-source.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source (ignored in this API)</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": false,
            "field": "visualization",
            "description": "<p>The sandbox visualization object</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": true,
            "field": "visualization.design",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": true,
            "field": "visualization.nodeFields",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": true,
            "field": "visualization.edgeFields",
            "description": ""
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/visualization.js",
    "groupTitle": "Visualizations"
  },
  {
    "type": "patch",
    "url": "/api/:dataSource/visualizations/folder/:id",
    "title": "Update a visualization folder",
    "name": "updateVisualizationFolder",
    "group": "Visualizations",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "apiright:visualizationFolder.edit"
      }
    ],
    "description": "<p>Update a property of a folder</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>ID of the visualization folder to modify</p>"
          },
          {
            "group": "Parameter",
            "type": "-1",
            "optional": true,
            "field": "parent",
            "description": "<p>ID of the parent visualization folder</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "title",
            "description": "<p>Title</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/visualization.js",
    "groupTitle": "Visualizations"
  },
  {
    "type": "put",
    "url": "/api/widget",
    "title": "Update a widget",
    "name": "updateVisualizationWidget",
    "group": "Visualizations",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "apiright:widget.edit"
      }
    ],
    "description": "<p>Update a widget for a visualization.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "visualization_id",
            "description": "<p>The visualization id</p>"
          },
          {
            "group": "Parameter",
            "type": "object",
            "optional": true,
            "field": "options",
            "description": "<p>The configuration of the user interface elements</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "options.search",
            "defaultValue": "false",
            "description": "<p>Whether the search bar is shown</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "options.share",
            "defaultValue": "false",
            "description": "<p>The the share button is shown</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "options.layout",
            "defaultValue": "false",
            "description": "<p>Whether the layout button is shown</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "options.fullscreen",
            "defaultValue": "false",
            "description": "<p>Whether the full-screen button is shown</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "options.zoom",
            "defaultValue": "false",
            "description": "<p>Whether to zoom-in and zoom-out controllers are shown</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "options.legend",
            "defaultValue": "false",
            "description": "<p>Whether the graph legend is shown</p>"
          },
          {
            "group": "Parameter",
            "type": "boolean",
            "optional": true,
            "field": "options.geo",
            "defaultValue": "false",
            "description": "<p>Whether the geo-mode toggle button is visible. Ignored if the nodes don't have geo coordinates</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": true,
            "field": "options.password",
            "description": "<p>Optional password to protect the widget</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "key",
            "description": "<p>The key of the updated widget</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/visualization.js",
    "groupTitle": "Visualizations"
  },
  {
    "type": "get",
    "url": "/api/:dataSource/visualizations/:id/shares",
    "title": "Get visualization share rights",
    "name": "visualizationShares",
    "group": "Visualizations",
    "permission": [
      {
        "name": "authenticated",
        "title": "Authenticated",
        "description": "<p>Any authenticated user can use this API.</p>"
      },
      {
        "name": "apiright:visualizationShare.read"
      }
    ],
    "description": "<p>Get all share rights on a visualization</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "dataSource",
            "description": "<p>Key of the data-source</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "id",
            "description": "<p>a visualization id</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "res",
            "description": "<p>result object</p>"
          },
          {
            "group": "Success 200",
            "type": "object",
            "optional": false,
            "field": "res.owner",
            "description": "<p>Owner of the shares</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "res.owner.id",
            "description": "<p>Owner's user id</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "res.owner.source",
            "description": "<p>Owner's source ('local', 'ldap', 'oauth', etc.)</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "res.owner.username",
            "description": "<p>Owner's username</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "res.owner.email",
            "description": "<p>Owner's email</p>"
          },
          {
            "group": "Success 200",
            "type": "object[]",
            "optional": false,
            "field": "res.shares",
            "description": "<p>Description of all shares defined by owner</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "res.shares.userId",
            "description": "<p>ID of the target user of this share</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "res.shares.username",
            "description": "<p>Username of the target user of this share</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "res.shares.email",
            "description": "<p>Email of the target user of this share</p>"
          },
          {
            "group": "Success 200",
            "type": "number",
            "optional": false,
            "field": "res.shares.visualizationId",
            "description": "<p>ID of the shared visualization</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "res.shares.right",
            "description": "<p>type of right granted to target user (<code>&quot;read&quot;</code>, <code>&quot;write&quot;</code> or <code>&quot;owner&quot;</code>)</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "server/routes/visualization.js",
    "groupTitle": "Visualizations"
  }
] });
