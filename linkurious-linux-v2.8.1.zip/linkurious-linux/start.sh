#!/bin/bash
# Copyright (c) 2015-2019 "Linkurious SAS"
# This file is part of Linkurious.

LK_DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
"${LK_DIR}/menu.sh" "start" $@
