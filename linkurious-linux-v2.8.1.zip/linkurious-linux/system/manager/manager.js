/**
 * Linkurious management script
 *
 * This script is usually invoked by menu.sh/menu.sh.command/menu.bat
 * The "menu" script will try to guess the unprivileged user Linkurious should
 * be started as and pass it to this script using the "--user" parameter.
 *
 * For usage information, invoke this script with the "help" argument.
 */
'use strict';
const path = require('path');
const os = require('os');
const spawnSync = require('child_process').spawnSync;
const fs = require('fs-extra');
const JavaHomeFinder = require('../lib/JavaHomeFinder');
const LKE = require('../server/services');
const Patty = require('pattypm/src/Patty');
const PattyUtils = require('pattypm/src/Utils');
const PattyError = require('pattypm/src/PattyError');
const Promise = require('bluebird');
// const
const COMMANDS = ['menu', 'status', 'start', 'stop', 'install', 'uninstall', 'help'];
const FLAGS = {
    'reset-config': 'Reset the configuration of Linkurious to defaults',
    'json': 'Output the result as JSON (only for "status")',
    'reset-manager-config': 'Reset the configuration of the manager to defaults',
    'no-browser': 'Don\'t open Linkurious in a new browser window (only for "start")'
};
const OPTIONS = ['user'];
const IS_WINDOWS = process.platform === 'win32';
const IS_MAC = process.platform === 'darwin';
const NODE_FILE = 'node' + (IS_WINDOWS ? '.exe' : '');
const SYSTEM_NODE_PATH = LKE.systemFile(NODE_FILE);
const SERVICE_LK = 'Linkurious Server';
const SERVICE_ES = 'Embedded ElasticSearch';
const MANAGER_PORT = 5891;
const MODE = 'production';
const MIN_JAVA_VERSION = '1.7.0';
const MAX_JAVA_VERSION = '1.8.999';
/**
 * @typedef {object} ManagerCommand
 * @property {string} name
 * @property {object<string>} options
 * @property {object<boolean>} flags
 */
/**
 *
 */
class LkManager {
    static run() {
        const m = new LkManager();
        m.main();
    }
    constructor() {
        this.configPath = LKE.dataFile('manager/manager.json');
        /** @type {Patty} */
        this.patty = undefined;
    }
    /**
     * @param {ManagerCommand} command
     * @returns {Promise}
     */
    initPattyConfig(command) {
        const reset = command.flags['reset-manager-config'];
        if (!fs.existsSync(this.configPath) || reset) {
            return LkManager.createConfig(this.configPath, LKE.isProdMode());
        }
    }
    /**
     * @param {string} absPath
     * @param {boolean} isProdMode
     * @param {boolean} [isWindows]
     * @returns {Promise.<Patty>}
     */
    static createConfig(absPath, isProdMode, isWindows) {
        if (isWindows === undefined) {
            isWindows = IS_WINDOWS;
        }
        const ramGb = os.totalmem() / (1024 * 1024 * 1024);
        let esRamGb;
        if (ramGb >= 32) {
            esRamGb = 4;
        }
        else if (ramGb >= 16) {
            esRamGb = 2;
        }
        else {
            esRamGb = 1;
        }
        return Patty.createConfigFile(absPath, {
            name: 'Linkurious',
            description: 'http://linkurio.us',
            autoStartServices: true,
            port: MANAGER_PORT,
            secret: 'graphs-are-awesome',
            processOwner: undefined,
            services: [
                {
                    name: SERVICE_LK,
                    home: '../../' + (isProdMode ? 'system' : 'linkurious-server'),
                    maxRestarts: 0,
                    noRestartExitCodes: [2, 3],
                    restartDelay: 2000,
                    binPath: 'node' + (isWindows ? '.exe' : ''),
                    arguments: ['server/app.js', '-p'],
                    env: {
                        NODE_EXTRA_CA_CERTS: undefined
                    }
                },
                {
                    name: SERVICE_ES,
                    disabled: false,
                    maxRestarts: 100,
                    restartDelay: 5000,
                    home: '../../' + (isProdMode ? 'system' : 'linkurious-server'),
                    binPath: (isWindows ? 'elasticsearch/bin/elasticsearch.bat' : '/bin/sh'),
                    arguments: (isWindows ? [] : ['elasticsearch/bin/elasticsearch']),
                    env: {
                        // java home will be auto-detected later on
                        JAVA_HOME: undefined,
                        // we set the max heap size to 4GB by default
                        ES_HEAP_SIZE: esRamGb + 'g'
                    }
                }
            ]
        });
    }
    /**
     * @param {ManagerCommand} command
     * @returns {string|undefined}
     */
    findBestProcessOwner(command) {
        if (IS_WINDOWS) {
            return undefined;
        }
        let user;
        // --user command line parameter
        if (command.options.user) {
            if (!command.options.user.match(/^[A-Za-z0-9_-]+$/)) {
                throw PattyError.business(`Invalid user "${command.options.user}"`);
            }
            const id = this._exec(`id -u ${command.options.user}`);
            if (!id) {
                throw PattyError.business(`User "${command.options.user}" does not exist`);
            }
            return command.options.user;
        }
        // owner of the current directory (very safe)
        user = this._exec('ls -ld .');
        if (user) {
            user = user.split(/\s+/)[2];
            if (user) {
                return user;
            }
        }
        // SUDO_USER env variable (if we were run using SUDO, this is the original user)
        user = process.env.SUDO_USER;
        if (user) {
            return user;
        }
        // last resort: current user (the actual current process owner, could be root)
        return os.userInfo().username;
    }
    //noinspection JSMethodCanBeStatic
    /**
     * @returns {boolean}
     */
    useEmbeddedES() {
        return LKE.getConfig().get('dataSources', []).some(s => {
            return (s.index.vendor === 'elasticSearch') &&
                (s.index.port === 9201 || s.index.port === '9201') &&
                (s.index.host === 'localhost' || s.index.host === '127.0.0.1');
        });
    }
    /**
     * - Enable or disable Embedded Elasticsearch before startup
     * - EXTRA_CA_CERT_PATH for LKE based on LKe config
     *
     * @param {ManagerCommand} command
     * @returns {Promise}
     */
    updateManagerConfig(command) {
        // 1) set process owner
        return this._setProcessOwner(command).then(() => {
            // if the LKE config has errors, stop here
            if (this._lkeError) {
                return;
            }
            // 2) set enabled/disable Embedded-ES
            return this._setEsState().then(() => {
                // 3) set extra CA
                return this._setExtraCA();
            });
        }).catch(e => {
            this._lkeError = e;
        });
    }
    /**
     * @param {ManagerCommand} command
     * @returns {Promise}
     * @private
     */
    _setProcessOwner(command) {
        return Promise.resolve().then(() => {
            // if we a not root, we cannot set the process owner
            if (IS_WINDOWS || !process.getuid || process.getuid() !== 0) {
                return;
            }
            const user = this.findBestProcessOwner(command);
            if (user) {
                return this.patty.setProcessOwner(user);
            }
        });
    }
    /**
     * @returns {Promise}
     * @private
     */
    _setEsState() {
        const useES = this.useEmbeddedES();
        return this.patty.getServiceOptions(SERVICE_ES).then(so => {
            // don't fail if Embedded-Elasticsearch was removed from the manager config
            if (!so) {
                return;
            }
            // if ES is already disabled, skip
            if (so.disabled && !useES) {
                return;
            }
            // detect JAVA_HOME if ES is enabled
            if (useES) {
                const jhf = new JavaHomeFinder();
                const jhOptions = { version: MIN_JAVA_VERSION, maxVersion: MAX_JAVA_VERSION };
                // if (JAVA_HOME is not set) OR (JAVA_HOME is invalid) try to resolve JAVA_HOME
                if (!so.env.JAVA_HOME || !jhf.isJavaHome(so.env.JAVA_HOME, jhOptions)) {
                    const javaHome = jhf.findJava(jhOptions);
                    if (!javaHome) {
                        return PattyError.businessP(`Could find JAVA_HOME (required: Java ${MIN_JAVA_VERSION} or later).`
                        //+ '\nSee https://doc.linkurio.us/admin-manual/latest/requirements/#java-jdk'
                        );
                    }
                    so.env.JAVA_HOME = javaHome;
                }
            }
            // update options
            so.disabled = !useES;
            return this.patty.setServiceOptions(SERVICE_ES, so);
        });
    }
    /**
     * @returns {Promise}
     * @private
     */
    _setExtraCA() {
        const extraCA = LKE.getConfig().get('advanced.extraCertificateAuthorities');
        return this.patty.getServiceOptions(SERVICE_LK).then(so => {
            // don't fail if Linkurious-Server was removed from the manager config
            if (!so) {
                return;
            }
            // if the extra CA did not change, skip
            if (extraCA === so.env.NODE_EXTRA_CA_CERTS) {
                return;
            }
            // update options
            so.env.NODE_EXTRA_CA_CERTS = extraCA;
            return this.patty.setServiceOptions(SERVICE_LK, so);
        });
    }
    //noinspection JSMethodCanBeStatic
    /**
     * Open LKE in the browser
     */
    openBrowser() {
        const url = LKE.getBaseURL();
        const options = { detached: true, stdio: 'ignore' };
        try {
            if (IS_WINDOWS) {
                spawnSync('cmd.exe', ['/C', 'START', url], options);
            }
            else if (IS_MAC) {
                options.shell = true;
                spawnSync('open', [url], options);
            }
            else {
                options.shell = true;
                spawnSync('xdg-open', [url], options);
            }
        }
        catch (e) {
            // ignore failures
        }
    }
    //noinspection JSMethodCanBeStatic
    /**
     * @param {string} command
     * @returns {string}
     * @private
     */
    _exec(command) {
        return spawnSync(command, [], { shell: true }).stdout.toString().trim();
    }
    /**
     * @returns {ManagerCommand}
     */
    parseCLA() {
        const args = process.argv.slice(2);
        const commands = [];
        const options = {};
        const flags = {};
        args.forEach(arg => {
            if (arg.indexOf('--') === 0) {
                const eqIndex = arg.indexOf('=');
                if (eqIndex > 0) {
                    options[arg.substring(2, eqIndex)] = arg.substring(eqIndex + 1);
                }
                else {
                    flags[arg.substr(2)] = true;
                }
            }
            else {
                commands.push(arg);
            }
        });
        const command = {
            name: commands.length ? commands[0] : 'menu',
            flags: flags,
            options: options
        };
        if (commands.length > 1 || !COMMANDS.includes(command.name)) {
            this.usage();
        }
        Object.keys(command.options).filter(option => !OPTIONS.includes(option)).forEach(() => {
            this.usage();
        });
        const legalFlags = Object.keys(FLAGS);
        Object.keys(command.flags).filter(flag => !legalFlags.includes(flag)).forEach(() => {
            this.usage();
        });
        return command;
    }
    /**
     * Die with an error message explaining the command line arguments usage.
     */
    usage() {
        // ${process.argv[1]}
        this.fatal('Usage', `[${COMMANDS.join('|')}] [${Object.keys(FLAGS).map(f => `--${f}`).join('] [')}] [${OPTIONS.map(o => `--${o}=${o.toUpperCase()}`).join('] [')}]\n` +
            (Object.keys(FLAGS).map(f => ` --${f}: ${FLAGS[f]}.`).join('\n')) +
            '\nOnline documentation available at https://doc.linkurio.us/admin-manual/latest/');
    }
    /**
     * @returns {Promise}
     */
    main() {
        let command;
        return Promise.resolve().then(() => {
            command = this.parseCLA();
            return this.loadLkeConfig(command);
        }).then(() => {
            if (LKE.isProdMode()) {
                this.ensureUpdater();
            }
            return this.initPattyConfig(command);
        }).then(() => {
            return Patty.loadConfig(this.configPath).catch(e => {
                return PattyError.businessP(`Could not load manager configuration (${this.configPath}). ` +
                    'Try fixing the file or use --reset-manager-config', e);
            });
        }).then(patty => {
            this.patty = patty;
            return this.updateManagerConfig(command);
        }).then(() => {
            if (command.name !== 'menu' && command.name !== 'help' && this._lkeError) {
                this.fatal('Linkurious Manager error', this._lkeError);
            }
            switch (command.name) {
                case 'start': return this.doStart(command);
                case 'stop': return this.doStop();
                case 'restart': return this.doStop().then(() => this.doStart(command));
                case 'install': return this.doInstall();
                case 'uninstall': return this.doUninstall();
                case 'status': return this.doStatus(command);
                case 'menu': return this.doShowMenu();
                case 'help': return this.usage();
                default: this.usage();
            }
        }).catch(e => {
            this.fatal('Linkurious Manager error', e);
        });
    }
    doShowMenu() {
        return this.patty.showMenu(m => {
            // if there was an error, hide all menu items except "stop" and "leave this menu"
            if (this._lkeError) {
                return m.constructor.name === 'CloseItem' || m.constructor.name === 'StopItem';
            }
            return true;
        }).then(() => {
            if (this._lkeError) {
                if (!this._lkeError.stack && this._lkeError.message) {
                    this.patty.menu.showError(PattyError.other(this._lkeError.message));
                }
                else {
                    this.patty.menu.showError(PattyError.fix(this._lkeError));
                }
            }
        });
    }
    /**
     * @param {ManagerCommand} command
     * @returns {Promise}
     */
    doStart(command) {
        return this.patty.ensureStarted().then(started => {
            if (started) {
                const c = this.patty.enabledServiceCount;
                console.log(`"start": started manager and ${c} service${c > 1 ? 's' : ''}.`);
                return;
            }
            return this.patty.client.startServices().then(pids => {
                if (!pids.length) {
                    console.log('"start": already running.');
                }
                else {
                    console.log(`"start": started ${pids.length} service${pids.length > 1 ? 's' : ''}.`);
                }
            });
        }).then(() => {
            if (!command.flags['no-browser']) {
                this.openBrowser();
            }
        });
    }
    /**
     * @returns {Promise}
     */
    doStop() {
        return this.patty.ensureStopped().then(stopped => {
            if (stopped) {
                console.log('"stop": stopped Linkurious.');
            }
            else {
                console.log('"stop": already stopped.');
            }
        });
    }
    /**
     * @returns {Promise}
     */
    doInstall() {
        return this.patty.ensureInstalled().then(installed => {
            if (installed) {
                console.log('"install": installed Linkurious as a service.');
            }
            else {
                console.log('"install": already installed.');
            }
        });
    }
    /**
     * @returns {Promise}
     */
    doUninstall() {
        return this.patty.ensureUninstalled().then(uninstalled => {
            if (uninstalled) {
                console.log('"uninstall": uninstalled Linkurious from services.');
            }
            else {
                console.log('"uninstall": not installed.');
            }
        });
    }
    /**
     * @param {ManagerCommand} [command]
     * @returns {Promise}
     */
    doStatus(command) {
        return this.patty.getStatus().then(result => {
            if (command && command.flags.json) {
                this.log(JSON.stringify(result, null, ' '));
                return;
            }
            this.log(`Linkurious status:\n- Version: ${LKE.getVersion()}\n- Installed as a service: ${result.installed ? 'yes' : 'no'}${result.processOwner ? ('\n- Process owner: "' + result.processOwner + '"') : ''}\n- Manager state: ${result.started ? 'running' : 'stopped'}`);
            if (!result.services) {
                return;
            }
            result.services.forEach(service => {
                /** @type {ServiceState} */
                const s = service.state;
                let postFix = '';
                if (s.started) {
                    postFix = ' (';
                    postFix += `pid: ${s.pid}`;
                    if (s.restarts) {
                        postFix += `, restarts: ${s.restarts}`;
                    }
                    postFix += `, started: ${PattyUtils.humanize.relativeTime(s.startTime / 1000)}`;
                    postFix += ')';
                }
                else if (s.stopTime) {
                    postFix = ' (';
                    postFix += `exit code: ${s.exitCode}`;
                    if (s.restarts) {
                        postFix += `, restarts: ${s.restarts}`;
                    }
                    postFix += `, stopped: ${PattyUtils.humanize.relativeTime(s.stopTime / 1000)}`;
                    postFix += ')';
                }
                this.log(`- ${service.name}: ${s.disabled ? 'disabled' : (s.started ? 'running' : 'stopped')}${postFix}`);
            });
        });
    }
    /**
     * @param {object} command
     * @param {string} command.name
     * @param {object<string>} command.options
     * @param {object<boolean>} command.flags
     * @returns {Promise}
     */
    loadLkeConfig(command) {
        const noReject = ['menu', 'status', 'stop', 'help'].includes(command.name);
        return Promise.resolve().then(() => {
            LKE.init({ mode: MODE, resetConfig: command.flags['reset-config'] });
            LKE.getConfig().load();
        }).catch(e => {
            if (noReject) {
                this._lkeError = e;
                return;
            }
            return Promise.reject(e);
        });
    }
    /**
     *
     * @param {string} message
     * @param {string|Error} e
     */
    fatal(message, e) {
        if (e instanceof PattyError && e.type === 'business') {
            this.log(`\x1b[31m${message}\x1b[0m: ${e.fullMessage}`);
        }
        else {
            this.log(`\x1b[31m${message}\x1b[0m: ` +
                (typeof e === 'string'
                    ? e
                    : (e.fullStack ? e.fullStack : (e.stack ? e.stack : (e.message ? e.message : e)))));
        }
        process.exit(1);
    }
    //noinspection JSMethodCanBeStatic
    /**
     * @param {string} m
     */
    log(m) {
        console.log(m);
    }
    //noinspection JSMethodCanBeStatic
    /**
     * Ensure that the updated folder is created (with a NodeJS binary copy)
     */
    ensureUpdater() {
        const systemStats = fs.statSync(path.resolve(__dirname, '..'));
        const updaterDirPath = path.resolve(__dirname, '..', 'updater');
        if (!fs.existsSync(updaterDirPath)) {
            fs.mkdirSync(updaterDirPath, 0o755);
            fs.chownSync(updaterDirPath, systemStats.uid, systemStats.gid);
        }
        // copy updater.js
        const updaterPath = path.resolve(updaterDirPath, 'updater.js');
        fs.copySync(path.resolve(__dirname, 'updater.js'), updaterPath, { clobber: true });
        fs.chownSync(updaterPath, systemStats.uid, systemStats.gid);
        const updaterNodePath = path.resolve(updaterDirPath, NODE_FILE);
        if (!fs.existsSync(updaterNodePath)) {
            // copy node binary
            fs.copySync(SYSTEM_NODE_PATH, updaterNodePath);
            fs.chownSync(updaterNodePath, systemStats.uid, systemStats.gid);
        }
    }
}
if (require.main === module) {
    LkManager.run();
}
else {
    module.exports = LkManager;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWFuYWdlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL21hbmFnZXIvbWFuYWdlci5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7R0FRRztBQUNILFlBQVksQ0FBQztBQUViLE1BQU0sSUFBSSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUM3QixNQUFNLEVBQUUsR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDekIsTUFBTSxTQUFTLEdBQUcsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUNyRCxNQUFNLEVBQUUsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDL0IsTUFBTSxjQUFjLEdBQUcsT0FBTyxDQUFDLHVCQUF1QixDQUFDLENBQUM7QUFDeEQsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLG9CQUFvQixDQUFDLENBQUM7QUFDMUMsTUFBTSxLQUFLLEdBQUcsT0FBTyxDQUFDLG1CQUFtQixDQUFDLENBQUM7QUFDM0MsTUFBTSxVQUFVLEdBQUcsT0FBTyxDQUFDLG1CQUFtQixDQUFDLENBQUM7QUFDaEQsTUFBTSxVQUFVLEdBQUcsT0FBTyxDQUFDLHdCQUF3QixDQUFDLENBQUM7QUFDckQsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBRXBDLFFBQVE7QUFDUixNQUFNLFFBQVEsR0FBRyxDQUFDLE1BQU0sRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsV0FBVyxFQUFFLE1BQU0sQ0FBQyxDQUFDO0FBQ3JGLE1BQU0sS0FBSyxHQUFHO0lBQ1osY0FBYyxFQUFFLG1EQUFtRDtJQUNuRSxNQUFNLEVBQUUsK0NBQStDO0lBQ3ZELHNCQUFzQixFQUFFLG9EQUFvRDtJQUM1RSxZQUFZLEVBQUUsbUVBQW1FO0NBQ2xGLENBQUM7QUFDRixNQUFNLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ3pCLE1BQU0sVUFBVSxHQUFHLE9BQU8sQ0FBQyxRQUFRLEtBQUssT0FBTyxDQUFDO0FBQ2hELE1BQU0sTUFBTSxHQUFHLE9BQU8sQ0FBQyxRQUFRLEtBQUssUUFBUSxDQUFDO0FBQzdDLE1BQU0sU0FBUyxHQUFHLE1BQU0sR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUN0RCxNQUFNLGdCQUFnQixHQUFHLEdBQUcsQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDbkQsTUFBTSxVQUFVLEdBQUcsbUJBQW1CLENBQUM7QUFDdkMsTUFBTSxVQUFVLEdBQUcsd0JBQXdCLENBQUM7QUFDNUMsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDO0FBQzFCLE1BQU0sSUFBSSxHQUFHLFlBQVksQ0FBQztBQUMxQixNQUFNLGdCQUFnQixHQUFHLE9BQU8sQ0FBQztBQUNqQyxNQUFNLGdCQUFnQixHQUFHLFNBQVMsQ0FBQztBQUVuQzs7Ozs7R0FLRztBQUVIOztHQUVHO0FBQ0gsTUFBTSxTQUFTO0lBRWIsTUFBTSxDQUFDLEdBQUc7UUFDUixNQUFNLENBQUMsR0FBRyxJQUFJLFNBQVMsRUFBRSxDQUFDO1FBQzFCLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUNYLENBQUM7SUFFRDtRQUNFLElBQUksQ0FBQyxVQUFVLEdBQUcsR0FBRyxDQUFDLFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO1FBQ3ZELG9CQUFvQjtRQUNwQixJQUFJLENBQUMsS0FBSyxHQUFHLFNBQVMsQ0FBQztJQUN6QixDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsZUFBZSxDQUFDLE9BQU87UUFDckIsTUFBTSxLQUFLLEdBQUcsT0FBTyxDQUFDLEtBQUssQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO1FBQ3BELElBQUksQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxLQUFLLEVBQUU7WUFDNUMsT0FBTyxTQUFTLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsR0FBRyxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUM7U0FDbEU7SUFDSCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxNQUFNLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRSxVQUFVLEVBQUUsU0FBUztRQUNoRCxJQUFJLFNBQVMsS0FBSyxTQUFTLEVBQUU7WUFBRSxTQUFTLEdBQUcsVUFBVSxDQUFDO1NBQUU7UUFFeEQsTUFBTSxLQUFLLEdBQUcsRUFBRSxDQUFDLFFBQVEsRUFBRSxHQUFHLENBQUMsSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLENBQUMsQ0FBQztRQUNuRCxJQUFJLE9BQU8sQ0FBQztRQUNaLElBQUksS0FBSyxJQUFJLEVBQUUsRUFBRTtZQUNmLE9BQU8sR0FBRyxDQUFDLENBQUM7U0FDYjthQUFNLElBQUksS0FBSyxJQUFJLEVBQUUsRUFBRTtZQUN0QixPQUFPLEdBQUcsQ0FBQyxDQUFDO1NBQ2I7YUFBTTtZQUNMLE9BQU8sR0FBRyxDQUFDLENBQUM7U0FDYjtRQUVELE9BQU8sS0FBSyxDQUFDLGdCQUFnQixDQUFDLE9BQU8sRUFBRTtZQUNyQyxJQUFJLEVBQUUsWUFBWTtZQUNsQixXQUFXLEVBQUUsb0JBQW9CO1lBQ2pDLGlCQUFpQixFQUFFLElBQUk7WUFDdkIsSUFBSSxFQUFFLFlBQVk7WUFDbEIsTUFBTSxFQUFFLG9CQUFvQjtZQUM1QixZQUFZLEVBQUUsU0FBUztZQUN2QixRQUFRLEVBQUU7Z0JBQ1I7b0JBQ0UsSUFBSSxFQUFFLFVBQVU7b0JBQ2hCLElBQUksRUFBRSxRQUFRLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUM7b0JBQzlELFdBQVcsRUFBRSxDQUFDO29CQUNkLGtCQUFrQixFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztvQkFDMUIsWUFBWSxFQUFFLElBQUk7b0JBQ2xCLE9BQU8sRUFBRSxNQUFNLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO29CQUMzQyxTQUFTLEVBQUUsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO29CQUNsQyxHQUFHLEVBQUU7d0JBQ0gsbUJBQW1CLEVBQUUsU0FBUztxQkFDL0I7aUJBQ0Y7Z0JBQ0Q7b0JBQ0UsSUFBSSxFQUFFLFVBQVU7b0JBQ2hCLFFBQVEsRUFBRSxLQUFLO29CQUNmLFdBQVcsRUFBRSxHQUFHO29CQUNoQixZQUFZLEVBQUUsSUFBSTtvQkFDbEIsSUFBSSxFQUFFLFFBQVEsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQztvQkFDOUQsT0FBTyxFQUFFLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO29CQUN4RSxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDO29CQUNqRSxHQUFHLEVBQUU7d0JBQ0gsMkNBQTJDO3dCQUMzQyxTQUFTLEVBQUUsU0FBUzt3QkFDcEIsNkNBQTZDO3dCQUM3QyxZQUFZLEVBQUUsT0FBTyxHQUFHLEdBQUc7cUJBQzVCO2lCQUNGO2FBQ0Y7U0FDRixDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsb0JBQW9CLENBQUMsT0FBTztRQUMxQixJQUFJLFVBQVUsRUFBRTtZQUNkLE9BQU8sU0FBUyxDQUFDO1NBQ2xCO1FBQ0QsSUFBSSxJQUFJLENBQUM7UUFFVCxnQ0FBZ0M7UUFDaEMsSUFBSSxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRTtZQUN4QixJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLGtCQUFrQixDQUFDLEVBQUU7Z0JBQ25ELE1BQU0sVUFBVSxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDO2FBQ3JFO1lBQ0QsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQztZQUN2RCxJQUFJLENBQUMsRUFBRSxFQUFFO2dCQUNQLE1BQU0sVUFBVSxDQUFDLFFBQVEsQ0FBQyxTQUFTLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxrQkFBa0IsQ0FBQyxDQUFDO2FBQzVFO1lBQ0QsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQztTQUM3QjtRQUVELDZDQUE2QztRQUM3QyxJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUM5QixJQUFJLElBQUksRUFBRTtZQUNSLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzVCLElBQUksSUFBSSxFQUFFO2dCQUFFLE9BQU8sSUFBSSxDQUFDO2FBQUU7U0FDM0I7UUFFRCxnRkFBZ0Y7UUFDaEYsSUFBSSxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDO1FBQzdCLElBQUksSUFBSSxFQUFFO1lBQUUsT0FBTyxJQUFJLENBQUM7U0FBRTtRQUUxQiw4RUFBOEU7UUFDOUUsT0FBTyxFQUFFLENBQUMsUUFBUSxFQUFFLENBQUMsUUFBUSxDQUFDO0lBQ2hDLENBQUM7SUFFRCxrQ0FBa0M7SUFDbEM7O09BRUc7SUFDSCxhQUFhO1FBQ1gsT0FBTyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUU7WUFDckQsT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxLQUFLLGVBQWUsQ0FBQztnQkFDekMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksS0FBSyxJQUFJLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLEtBQUssTUFBTSxDQUFDO2dCQUNsRCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxLQUFLLFdBQVcsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksS0FBSyxXQUFXLENBQUMsQ0FBQztRQUNuRSxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxtQkFBbUIsQ0FBQyxPQUFPO1FBQ3pCLHVCQUF1QjtRQUN2QixPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBRTlDLDBDQUEwQztZQUMxQyxJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7Z0JBQ2xCLE9BQU87YUFDUjtZQUVELHFDQUFxQztZQUNyQyxPQUFPLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNsQyxrQkFBa0I7Z0JBQ2xCLE9BQU8sSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQzVCLENBQUMsQ0FBQyxDQUFDO1FBRUwsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFO1lBQ1gsSUFBSSxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUM7UUFDckIsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILGdCQUFnQixDQUFDLE9BQU87UUFDdEIsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUVqQyxvREFBb0Q7WUFDcEQsSUFBSSxVQUFVLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxJQUFJLE9BQU8sQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLEVBQUU7Z0JBQzNELE9BQU87YUFDUjtZQUVELE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUNoRCxJQUFJLElBQUksRUFBRTtnQkFDUixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3pDO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsV0FBVztRQUNULE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNuQyxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsaUJBQWlCLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFO1lBQ3hELDJFQUEyRTtZQUMzRSxJQUFJLENBQUMsRUFBRSxFQUFFO2dCQUFFLE9BQU87YUFBRTtZQUVwQixrQ0FBa0M7WUFDbEMsSUFBSSxFQUFFLENBQUMsUUFBUSxJQUFJLENBQUMsS0FBSyxFQUFFO2dCQUFFLE9BQU87YUFBRTtZQUV0QyxvQ0FBb0M7WUFDcEMsSUFBSSxLQUFLLEVBQUU7Z0JBQ1QsTUFBTSxHQUFHLEdBQUcsSUFBSSxjQUFjLEVBQUUsQ0FBQztnQkFDakMsTUFBTSxTQUFTLEdBQUcsRUFBQyxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsVUFBVSxFQUFFLGdCQUFnQixFQUFDLENBQUM7Z0JBRTVFLCtFQUErRTtnQkFDL0UsSUFBSSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsU0FBUyxJQUFJLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBRSxTQUFTLENBQUMsRUFBRTtvQkFDckUsTUFBTSxRQUFRLEdBQUcsR0FBRyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQztvQkFDekMsSUFBSSxDQUFDLFFBQVEsRUFBRTt3QkFDYixPQUFPLFVBQVUsQ0FBQyxTQUFTLENBQ3pCLHdDQUF3QyxnQkFBZ0IsYUFBYTt3QkFDckUsOEVBQThFO3lCQUMvRSxDQUFDO3FCQUNIO29CQUNELEVBQUUsQ0FBQyxHQUFHLENBQUMsU0FBUyxHQUFHLFFBQVEsQ0FBQztpQkFDN0I7YUFDRjtZQUVELGlCQUFpQjtZQUNqQixFQUFFLENBQUMsUUFBUSxHQUFHLENBQUMsS0FBSyxDQUFDO1lBQ3JCLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxVQUFVLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDdEQsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsV0FBVztRQUNULE1BQU0sT0FBTyxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxHQUFHLENBQUMsc0NBQXNDLENBQUMsQ0FBQztRQUM1RSxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsaUJBQWlCLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFO1lBQ3hELHNFQUFzRTtZQUN0RSxJQUFJLENBQUMsRUFBRSxFQUFFO2dCQUFFLE9BQU87YUFBRTtZQUVwQix1Q0FBdUM7WUFDdkMsSUFBSSxPQUFPLEtBQUssRUFBRSxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsRUFBRTtnQkFBRSxPQUFPO2FBQUU7WUFFdkQsaUJBQWlCO1lBQ2pCLEVBQUUsQ0FBQyxHQUFHLENBQUMsbUJBQW1CLEdBQUcsT0FBTyxDQUFDO1lBQ3JDLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxVQUFVLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDdEQsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQsa0NBQWtDO0lBQ2xDOztPQUVHO0lBQ0gsV0FBVztRQUNULE1BQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUM3QixNQUFNLE9BQU8sR0FBRyxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBQyxDQUFDO1FBRWxELElBQUk7WUFDRixJQUFJLFVBQVUsRUFBRTtnQkFDZCxTQUFTLENBQUMsU0FBUyxFQUFFLENBQUMsSUFBSSxFQUFFLE9BQU8sRUFBRSxHQUFHLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQzthQUNyRDtpQkFBTSxJQUFJLE1BQU0sRUFBRTtnQkFDakIsT0FBTyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUM7Z0JBQ3JCLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQzthQUNuQztpQkFBTTtnQkFDTCxPQUFPLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQztnQkFDckIsU0FBUyxDQUFDLFVBQVUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDO2FBQ3ZDO1NBQ0Y7UUFBQyxPQUFNLENBQUMsRUFBRTtZQUNULGtCQUFrQjtTQUNuQjtJQUNILENBQUM7SUFFRCxrQ0FBa0M7SUFDbEM7Ozs7T0FJRztJQUNILEtBQUssQ0FBQyxPQUFPO1FBQ1gsT0FBTyxTQUFTLENBQUMsT0FBTyxFQUFFLEVBQUUsRUFBRSxFQUFDLEtBQUssRUFBRSxJQUFJLEVBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUN4RSxDQUFDO0lBRUQ7O09BRUc7SUFDSCxRQUFRO1FBQ04sTUFBTSxJQUFJLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFbkMsTUFBTSxRQUFRLEdBQUcsRUFBRSxDQUFDO1FBQ3BCLE1BQU0sT0FBTyxHQUFHLEVBQUUsQ0FBQztRQUNuQixNQUFNLEtBQUssR0FBRyxFQUFFLENBQUM7UUFDakIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUNqQixJQUFJLEdBQUcsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUMzQixNQUFNLE9BQU8sR0FBRyxHQUFHLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNqQyxJQUFJLE9BQU8sR0FBRyxDQUFDLEVBQUU7b0JBQ2YsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQyxPQUFPLEdBQUcsQ0FBQyxDQUFDLENBQUM7aUJBQ2pFO3FCQUFNO29CQUNMLEtBQUssQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDO2lCQUM3QjthQUNGO2lCQUFNO2dCQUNMLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7YUFDcEI7UUFDSCxDQUFDLENBQUMsQ0FBQztRQUVILE1BQU0sT0FBTyxHQUFHO1lBQ2QsSUFBSSxFQUFFLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTTtZQUM1QyxLQUFLLEVBQUUsS0FBSztZQUNaLE9BQU8sRUFBRSxPQUFPO1NBQ2pCLENBQUM7UUFFRixJQUFJLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDM0QsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1NBQ2Q7UUFDRCxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFO1lBQ3BGLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNmLENBQUMsQ0FBQyxDQUFDO1FBQ0gsTUFBTSxVQUFVLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN0QyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFO1lBQ2pGLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNmLENBQUMsQ0FBQyxDQUFDO1FBRUgsT0FBTyxPQUFPLENBQUM7SUFDakIsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSztRQUNILHFCQUFxQjtRQUNyQixJQUFJLENBQUMsS0FBSyxDQUNSLE9BQU8sRUFBRSxJQUNQLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQ2xCLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsTUFDakQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxXQUFXLEVBQUUsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLO1lBQzlELENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNqRSxrRkFBa0YsQ0FDckYsQ0FBQztJQUNKLENBQUM7SUFFRDs7T0FFRztJQUNILElBQUk7UUFDRixJQUFJLE9BQU8sQ0FBQztRQUNaLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDakMsT0FBTyxHQUFHLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUUxQixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDckMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNYLElBQUksR0FBRyxDQUFDLFVBQVUsRUFBRSxFQUFFO2dCQUNwQixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7YUFDdEI7WUFFRCxPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdkMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNYLE9BQU8sS0FBSyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUNqRCxPQUFPLFVBQVUsQ0FBQyxTQUFTLENBQ3pCLHlDQUF5QyxJQUFJLENBQUMsVUFBVSxLQUFLO29CQUM3RCxtREFBbUQsRUFDbkQsQ0FBQyxDQUNGLENBQUM7WUFDSixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUNkLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO1lBQ25CLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQzNDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCxJQUFJLE9BQU8sQ0FBQyxJQUFJLEtBQUssTUFBTSxJQUFJLE9BQU8sQ0FBQyxJQUFJLEtBQUssTUFBTSxJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7Z0JBQ3hFLElBQUksQ0FBQyxLQUFLLENBQUMsMEJBQTBCLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO2FBQ3hEO1lBRUQsUUFBUSxPQUFPLENBQUMsSUFBSSxFQUFFO2dCQUNwQixLQUFLLE9BQU8sQ0FBQyxDQUFDLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDM0MsS0FBSyxNQUFNLENBQUMsQ0FBQyxPQUFPLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztnQkFDbEMsS0FBSyxTQUFTLENBQUMsQ0FBQyxPQUFPLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO2dCQUN2RSxLQUFLLFNBQVMsQ0FBQyxDQUFDLE9BQU8sSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO2dCQUN4QyxLQUFLLFdBQVcsQ0FBQyxDQUFDLE9BQU8sSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUM1QyxLQUFLLFFBQVEsQ0FBQyxDQUFDLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDN0MsS0FBSyxNQUFNLENBQUMsQ0FBQyxPQUFPLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztnQkFDdEMsS0FBSyxNQUFNLENBQUMsQ0FBQyxPQUFPLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztnQkFDakMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO2FBQ3ZCO1FBQ0gsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFO1lBQ1gsSUFBSSxDQUFDLEtBQUssQ0FBQywwQkFBMEIsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUM1QyxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRCxVQUFVO1FBQ1IsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUM3QixpRkFBaUY7WUFDakYsSUFBSSxJQUFJLENBQUMsU0FBUyxFQUFFO2dCQUNsQixPQUFPLENBQUMsQ0FBQyxXQUFXLENBQUMsSUFBSSxLQUFLLFdBQVcsSUFBSSxDQUFDLENBQUMsV0FBVyxDQUFDLElBQUksS0FBSyxVQUFVLENBQUM7YUFDaEY7WUFDRCxPQUFPLElBQUksQ0FBQztRQUNkLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCxJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7Z0JBQ2xCLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sRUFBRTtvQkFDbkQsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO2lCQUNyRTtxQkFBTTtvQkFDTCxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztpQkFDM0Q7YUFDRjtRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7T0FHRztJQUNILE9BQU8sQ0FBQyxPQUFPO1FBQ2IsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLGFBQWEsRUFBRSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUUvQyxJQUFJLE9BQU8sRUFBRTtnQkFDWCxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLG1CQUFtQixDQUFDO2dCQUN6QyxPQUFPLENBQUMsR0FBRyxDQUFDLGdDQUFnQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO2dCQUM3RSxPQUFPO2FBQ1I7WUFFRCxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLGFBQWEsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtnQkFFbkQsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7b0JBQ2hCLE9BQU8sQ0FBQyxHQUFHLENBQUMsMkJBQTJCLENBQUMsQ0FBQztpQkFDMUM7cUJBQU07b0JBQ0wsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsSUFBSSxDQUFDLE1BQU0sV0FBVyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO2lCQUN0RjtZQUNILENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNYLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxFQUFFO2dCQUNoQyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7YUFDcEI7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNILE1BQU07UUFDSixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsYUFBYSxFQUFFLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQy9DLElBQUksT0FBTyxFQUFFO2dCQUNYLE9BQU8sQ0FBQyxHQUFHLENBQUMsNkJBQTZCLENBQUMsQ0FBQzthQUM1QztpQkFBTTtnQkFDTCxPQUFPLENBQUMsR0FBRyxDQUFDLDBCQUEwQixDQUFDLENBQUM7YUFDekM7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNILFNBQVM7UUFDUCxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQ25ELElBQUksU0FBUyxFQUFFO2dCQUNiLE9BQU8sQ0FBQyxHQUFHLENBQUMsK0NBQStDLENBQUMsQ0FBQzthQUM5RDtpQkFBTTtnQkFDTCxPQUFPLENBQUMsR0FBRyxDQUFDLCtCQUErQixDQUFDLENBQUM7YUFDOUM7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNILFdBQVc7UUFDVCxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsaUJBQWlCLEVBQUUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDdkQsSUFBSSxXQUFXLEVBQUU7Z0JBQ2YsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvREFBb0QsQ0FBQyxDQUFDO2FBQ25FO2lCQUFNO2dCQUNMLE9BQU8sQ0FBQyxHQUFHLENBQUMsNkJBQTZCLENBQUMsQ0FBQzthQUM1QztRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7T0FHRztJQUNILFFBQVEsQ0FBQyxPQUFPO1FBQ2QsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUMxQyxJQUFJLE9BQU8sSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRTtnQkFDakMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQztnQkFDNUMsT0FBTzthQUNSO1lBRUQsSUFBSSxDQUFDLEdBQUcsQ0FDTixrQ0FBa0MsR0FBRyxDQUFDLFVBQVUsRUFDaEQsK0JBQStCLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFDMUQsR0FBRyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLHNCQUFzQixHQUFHLE1BQU0sQ0FBQyxZQUFZLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQ2hGLHNCQUFzQixNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFNBQ25ELEVBQUUsQ0FBQyxDQUFDO1lBQ04sSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUU7Z0JBQUUsT0FBTzthQUFFO1lBQ2pDLE1BQU0sQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFFO2dCQUNoQywyQkFBMkI7Z0JBQzNCLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0JBQ3hCLElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQztnQkFDakIsSUFBSSxDQUFDLENBQUMsT0FBTyxFQUFFO29CQUNiLE9BQU8sR0FBRyxJQUFJLENBQUM7b0JBQ2YsT0FBTyxJQUFJLFFBQVEsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO29CQUMzQixJQUFJLENBQUMsQ0FBQyxRQUFRLEVBQUU7d0JBQ2QsT0FBTyxJQUFJLGVBQWUsQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDO3FCQUN4QztvQkFDRCxPQUFPLElBQUksY0FBYyxVQUFVLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxFQUFFLENBQUM7b0JBQ2hGLE9BQU8sSUFBSSxHQUFHLENBQUM7aUJBQ2hCO3FCQUFNLElBQUksQ0FBQyxDQUFDLFFBQVEsRUFBRTtvQkFDckIsT0FBTyxHQUFHLElBQUksQ0FBQztvQkFDZixPQUFPLElBQUksY0FBYyxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUM7b0JBQ3RDLElBQUksQ0FBQyxDQUFDLFFBQVEsRUFBRTt3QkFDZCxPQUFPLElBQUksZUFBZSxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUM7cUJBQ3hDO29CQUNELE9BQU8sSUFBSSxjQUFjLFVBQVUsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLEVBQUUsQ0FBQztvQkFDL0UsT0FBTyxJQUFJLEdBQUcsQ0FBQztpQkFDaEI7Z0JBQ0QsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLE9BQU8sQ0FBQyxJQUFJLEtBQ3hCLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLE9BQU8sRUFBRSxDQUFDLENBQUM7WUFDL0UsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxhQUFhLENBQUMsT0FBTztRQUNuQixNQUFNLFFBQVEsR0FBRyxDQUFDLE1BQU0sRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLE1BQU0sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFM0UsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNqQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUMsSUFBSSxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsT0FBTyxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsRUFBQyxDQUFDLENBQUM7WUFDbkUsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDLElBQUksRUFBRSxDQUFDO1FBQ3pCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUNYLElBQUksUUFBUSxFQUFFO2dCQUNaLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDO2dCQUNuQixPQUFPO2FBQ1I7WUFDRCxPQUFPLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDM0IsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUNkLElBQUksQ0FBQyxZQUFZLFVBQVUsSUFBSSxDQUFDLENBQUMsSUFBSSxLQUFLLFVBQVUsRUFBRTtZQUNwRCxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsT0FBTyxZQUFZLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDO1NBQ3pEO2FBQU07WUFDTCxJQUFJLENBQUMsR0FBRyxDQUNOLFdBQVcsT0FBTyxXQUFXO2dCQUM3QixDQUFDLE9BQU8sQ0FBQyxLQUFLLFFBQVE7b0JBQ3BCLENBQUMsQ0FBQyxDQUFDO29CQUNILENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQ2xGLENBQ0YsQ0FBQztTQUNIO1FBQ0QsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNsQixDQUFDO0lBRUQsa0NBQWtDO0lBQ2xDOztPQUVHO0lBQ0gsR0FBRyxDQUFDLENBQUM7UUFDSCxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ2pCLENBQUM7SUFFRCxrQ0FBa0M7SUFDbEM7O09BRUc7SUFDSCxhQUFhO1FBQ1gsTUFBTSxXQUFXLEdBQUcsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBRS9ELE1BQU0sY0FBYyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRSxTQUFTLENBQUMsQ0FBQztRQUNoRSxJQUFJLENBQUMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsRUFBRTtZQUNsQyxFQUFFLENBQUMsU0FBUyxDQUFDLGNBQWMsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUNwQyxFQUFFLENBQUMsU0FBUyxDQUFDLGNBQWMsRUFBRSxXQUFXLENBQUMsR0FBRyxFQUFFLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUNoRTtRQUVELGtCQUFrQjtRQUNsQixNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLGNBQWMsRUFBRSxZQUFZLENBQUMsQ0FBQztRQUMvRCxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLFlBQVksQ0FBQyxFQUFFLFdBQVcsRUFBRSxFQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUMsQ0FBQyxDQUFDO1FBQ2pGLEVBQUUsQ0FBQyxTQUFTLENBQUMsV0FBVyxFQUFFLFdBQVcsQ0FBQyxHQUFHLEVBQUUsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBRTVELE1BQU0sZUFBZSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsY0FBYyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBQ2hFLElBQUksQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDLGVBQWUsQ0FBQyxFQUFFO1lBQ25DLG1CQUFtQjtZQUNuQixFQUFFLENBQUMsUUFBUSxDQUFDLGdCQUFnQixFQUFFLGVBQWUsQ0FBQyxDQUFDO1lBQy9DLEVBQUUsQ0FBQyxTQUFTLENBQUMsZUFBZSxFQUFFLFdBQVcsQ0FBQyxHQUFHLEVBQUUsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ2pFO0lBQ0gsQ0FBQztDQUNGO0FBRUQsSUFBSSxPQUFPLENBQUMsSUFBSSxLQUFLLE1BQU0sRUFBRTtJQUMzQixTQUFTLENBQUMsR0FBRyxFQUFFLENBQUM7Q0FDakI7S0FBTTtJQUNMLE1BQU0sQ0FBQyxPQUFPLEdBQUcsU0FBUyxDQUFDO0NBQzVCIn0=