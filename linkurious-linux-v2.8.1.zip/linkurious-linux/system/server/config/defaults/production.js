// this is a default configuration file used for fallback
//                      ______
//                     /     /\
//                    /     /##\
//                   /     /####\
//                  /     /######\
//                 /     /########\
//                /     /##########\
//               /     /#####/\#####\
//              /     /#####/++\#####\
//             /     /#####/++++\#####\
//            /     /#####/\+++++\#####\
//           /     /#####/  \+++++\#####\
//          /     /#####/ |  \+++++\#####\
//         /     /#####/  |   \+++++\#####\
//        /     /#####/   .    \+++++\#####\
//       /     /#####/__________\+++++\#####\
//      /                        \+++++\#####\
//     /__________________________\+++++\####/
//     \+++++++++++++++++++++++++++++++++\##/
//      \+++++++++++++++++++++++++++++++++\/
//       ``````````````````````````````````
//      _                     _              _ _ _
//   __| | ___    _ __   ___ | |_    ___  __| (_) |_
//  / _` |/ _ \  | '_ \ / _ \| __|  / _ \/ _` | | __|
// | (_| | (_) | | | | | (_) | |_  |  __/ (_| | | |_
//  \__,_|\___/  |_| |_|\___/ \__|  \___|\__,_|_|\__|
//
'use strict';
module.exports = {
    dataSources: [{
            readOnly: false,
            graphdb: {
                vendor: 'neo4j',
                url: 'http://127.0.0.1:7474',
                user: null,
                password: null
            },
            index: {
                vendor: 'elasticSearch',
                host: '127.0.0.1',
                port: 9201,
                forceReindex: false,
                dynamicMapping: false,
                skipEdgeIndexation: false
            }
        }],
    advanced: {
        supernodeThreshold: 10000,
        connectionRetries: 10,
        pollInterval: 10,
        indexationChunkSize: 5000,
        expandThreshold: 50,
        rawQueryLimit: 500,
        searchAddAllThreshold: 500,
        minSearchQueryLength: 1,
        rawQueryTimeout: 60000,
        defaultFuzziness: 0.1,
        layoutWorkers: 2,
        edgesBetweenSupernodes: false,
        sampledItemsPerType: 500,
        sampledVisualizationItems: 10000,
        defaultTimezone: 'Z',
        timeline: false
    },
    db: {
        name: 'linkurious',
        username: null,
        password: null,
        options: {
            dialect: 'sqlite',
            // file path is relative to data directory
            storage: 'server/database.sqlite'
        }
    },
    server: {
        listenPort: 3000,
        listenPortHttps: 3443,
        clientFolder: 'server/public',
        cookieSecret: 'zO6Yb7u5H907dfEcmjS8pXgWNEo3B9pNQF8mKjdzRR3I64o88GrGLWEjqNq1Yx5',
        allowOrigin: null,
        domain: null,
        publicPortHttp: null,
        publicPortHttps: null,
        useHttps: false,
        forceHttps: false,
        certificateFile: null,
        certificateKeyFile: null,
        certificatePassphrase: null
    },
    defaultPreferences: {
        pinOnDrag: false,
        locale: 'en-US',
        incrementalLayout: false
    },
    guestPreferences: {
        locale: 'en-US',
        uiWorkspaceSearch: false,
        uiExport: false,
        uiLayout: 'regular',
        uiDesign: false,
        uiFilter: false
    },
    alerts: {
        enabled: true,
        maxMatchTTL: 0,
        maxMatchesLimit: 5000,
        maxRuntimeLimit: 600000,
        maxConcurrency: 1
    },
    auditTrail: {
        enabled: false,
        logFolder: 'audit-trail',
        fileSizeLimit: 5242880,
        strictMode: false,
        mode: 'rw' // log read and/or write action: r || w || rw
    },
    access: {
        authRequired: false,
        guestMode: false,
        floatingLicenses: null,
        defaultPage: 'dashboard',
        defaultPageParams: {},
        dataEdition: true,
        widget: true,
        loginTimeout: null,
        oauth2: {
            enabled: false,
            provider: 'openidconnect',
            authorizationURL: 'https://accounts.google.com/o/oauth2/v2/auth?hd=MY-CUSTOM-DOMAIN.com',
            tokenURL: 'https://www.googleapis.com/oauth2/v4/token',
            clientID: 'MY-CLIENT-ID.apps.googleusercontent.com',
            clientSecret: 'MY-CLIENT-SECRET'
        },
        externalUsersAllowedGroups: null,
        externalUsersGroupMapping: {},
        autoRefreshGroupMapping: false
    },
    leaflet: [
        {
            name: 'Wikimedia',
            thumbnail: '/assets/img/Wikimedia.png',
            urlTemplate: 'https://maps.wikimedia.org/osm-intl/{z}/{x}/{y}.png',
            attribution: '<a href="https://wikimediafoundation.org/wiki/Maps_Terms_of_Use">Wikimedia</a>',
            subdomains: null,
            id: null,
            accessToken: null,
            minZoom: 2,
            maxZoom: 19
        }, {
            name: 'Stamen Toner Lite',
            thumbnail: '/assets/img/Stamen_TonerLite.png',
            urlTemplate: 'http://{s}.tile.stamen.com/toner-lite/{z}/{x}/{y}.png',
            attribution: 'Map tiles by <a href="http://stamen.com">Stamen Design</a>, <a href="http://creativecommons.org/licenses/by/3.0">CC BY 3.0</a> &mdash; Map data &copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>',
            subdomains: null,
            id: null,
            accessToken: null,
            minZoom: 2,
            maxZoom: 20
        }, {
            name: 'Esri World Gray Canvas',
            thumbnail: '/assets/img/Esri_WorldGrayCanvas.png',
            urlTemplate: 'http://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Light_Gray_Base/MapServer/tile/{z}/{y}/{x}',
            attribution: 'Tiles &copy; Esri &mdash; Esri, DeLorme, NAVTEQ',
            subdomains: null,
            id: null,
            accessToken: null,
            minZoom: 2,
            maxZoom: 16
        }, {
            name: 'CartoDB Positron',
            thumbnail: '/assets/img/CartoDB_Positron.png',
            urlTemplate: 'http://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png',
            attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="http://cartodb.com/attributions">CartoDB</a>',
            subdomains: 'abcd',
            id: null,
            accessToken: null,
            minZoom: 2,
            maxZoom: 19
        }, {
            name: 'MapBox Light',
            thumbnail: '/assets/img/MapBox_Light.png',
            urlTemplate: 'https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}',
            attribution: 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a>, <a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery &copy <a href="http://mapbox.com">Mapbox</a>',
            subdomains: null,
            id: 'mapbox.light',
            accessToken: 'pk.eyJ1Ijoic2hleW1hbm4iLCJhIjoiY2lqNGZmanhpMDAxaHc4bTNhZGFrcHZleiJ9.VliJNQs7QBK5e5ZmYl9RTw',
            minZoom: 2,
            maxZoom: 20
        }, {
            name: 'MapBox Streets',
            thumbnail: '/assets/img/MapBox_Streets.png',
            urlTemplate: 'https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}',
            attribution: 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a>, <a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery &copy <a href="http://mapbox.com">Mapbox</a>',
            subdomains: null,
            id: 'mapbox.streets',
            accessToken: 'pk.eyJ1Ijoic2hleW1hbm4iLCJhIjoiY2lqNGZmanhpMDAxaHc4bTNhZGFrcHZleiJ9.VliJNQs7QBK5e5ZmYl9RTw',
            minZoom: 2,
            maxZoom: 20
        }
    ],
    ogma: {
        renderer: 'webgl',
        options: {
            styles: {
                node: {
                    nodeRadius: 5,
                    shape: 'circle',
                    text: {
                        maxTextLength: 60,
                        minVisibleSize: 12,
                        maxLineLength: 30,
                        backgroundColor: null,
                        font: 'roboto',
                        color: '#000',
                        size: 14
                    }
                },
                edge: {
                    edgeWidth: 1,
                    shape: 'arrow',
                    text: {
                        maxTextLength: 60,
                        minVisibleSize: 3,
                        maxLineLength: 30,
                        backgroundColor: null,
                        font: 'roboto',
                        color: '#000',
                        size: 14
                    }
                }
            },
            interactions: {
                zoom: {
                    modifier: 1.382
                },
                pan: {},
                rotation: {
                    enabled: false
                }
            },
            backgroundColor: 'rgba(240, 240, 240, 0)'
        }
    }
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJvZHVjdGlvbi5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9jb25maWcvZGVmYXVsdHMvcHJvZHVjdGlvbi5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSx5REFBeUQ7QUFDekQsOEJBQThCO0FBQzlCLCtCQUErQjtBQUMvQixnQ0FBZ0M7QUFDaEMsaUNBQWlDO0FBQ2pDLGtDQUFrQztBQUNsQyxtQ0FBbUM7QUFDbkMsb0NBQW9DO0FBQ3BDLHFDQUFxQztBQUNyQyxzQ0FBc0M7QUFDdEMsdUNBQXVDO0FBQ3ZDLHdDQUF3QztBQUN4Qyx5Q0FBeUM7QUFDekMsMENBQTBDO0FBQzFDLDJDQUEyQztBQUMzQyw0Q0FBNEM7QUFDNUMsNkNBQTZDO0FBQzdDLDhDQUE4QztBQUM5Qyw4Q0FBOEM7QUFDOUMsNkNBQTZDO0FBQzdDLDRDQUE0QztBQUM1QywyQ0FBMkM7QUFDM0Msa0RBQWtEO0FBQ2xELG9EQUFvRDtBQUNwRCxxREFBcUQ7QUFDckQsb0RBQW9EO0FBQ3BELHFEQUFxRDtBQUNyRCxFQUFFO0FBQ0YsWUFBWSxDQUFDO0FBRWIsTUFBTSxDQUFDLE9BQU8sR0FBRztJQUNmLFdBQVcsRUFBRSxDQUFDO1lBQ1osUUFBUSxFQUFFLEtBQUs7WUFDZixPQUFPLEVBQUU7Z0JBQ1AsTUFBTSxFQUFFLE9BQU87Z0JBQ2YsR0FBRyxFQUFFLHVCQUF1QjtnQkFDNUIsSUFBSSxFQUFFLElBQUk7Z0JBQ1YsUUFBUSxFQUFFLElBQUk7YUFDZjtZQUNELEtBQUssRUFBRTtnQkFDTCxNQUFNLEVBQUUsZUFBZTtnQkFDdkIsSUFBSSxFQUFFLFdBQVc7Z0JBQ2pCLElBQUksRUFBRSxJQUFJO2dCQUNWLFlBQVksRUFBRSxLQUFLO2dCQUNuQixjQUFjLEVBQUUsS0FBSztnQkFDckIsa0JBQWtCLEVBQUUsS0FBSzthQUMxQjtTQUNGLENBQUM7SUFDRixRQUFRLEVBQUU7UUFDUixrQkFBa0IsRUFBRSxLQUFLO1FBQ3pCLGlCQUFpQixFQUFFLEVBQUU7UUFDckIsWUFBWSxFQUFFLEVBQUU7UUFDaEIsbUJBQW1CLEVBQUUsSUFBSTtRQUN6QixlQUFlLEVBQUUsRUFBRTtRQUNuQixhQUFhLEVBQUUsR0FBRztRQUNsQixxQkFBcUIsRUFBRSxHQUFHO1FBQzFCLG9CQUFvQixFQUFFLENBQUM7UUFDdkIsZUFBZSxFQUFFLEtBQUs7UUFDdEIsZ0JBQWdCLEVBQUUsR0FBRztRQUNyQixhQUFhLEVBQUUsQ0FBQztRQUNoQixzQkFBc0IsRUFBRSxLQUFLO1FBQzdCLG1CQUFtQixFQUFFLEdBQUc7UUFDeEIseUJBQXlCLEVBQUUsS0FBSztRQUNoQyxlQUFlLEVBQUUsR0FBRztRQUNwQixRQUFRLEVBQUUsS0FBSztLQUNoQjtJQUNELEVBQUUsRUFBRTtRQUNGLElBQUksRUFBRSxZQUFZO1FBQ2xCLFFBQVEsRUFBRSxJQUFJO1FBQ2QsUUFBUSxFQUFFLElBQUk7UUFDZCxPQUFPLEVBQUU7WUFDUCxPQUFPLEVBQUUsUUFBUTtZQUNqQiwwQ0FBMEM7WUFDMUMsT0FBTyxFQUFFLHdCQUF3QjtTQUNsQztLQUNGO0lBQ0QsTUFBTSxFQUFFO1FBQ04sVUFBVSxFQUFFLElBQUk7UUFDaEIsZUFBZSxFQUFFLElBQUk7UUFDckIsWUFBWSxFQUFFLGVBQWU7UUFDN0IsWUFBWSxFQUFFLGlFQUFpRTtRQUMvRSxXQUFXLEVBQUUsSUFBSTtRQUNqQixNQUFNLEVBQUUsSUFBSTtRQUNaLGNBQWMsRUFBRSxJQUFJO1FBQ3BCLGVBQWUsRUFBRSxJQUFJO1FBQ3JCLFFBQVEsRUFBRSxLQUFLO1FBQ2YsVUFBVSxFQUFFLEtBQUs7UUFDakIsZUFBZSxFQUFFLElBQUk7UUFDckIsa0JBQWtCLEVBQUUsSUFBSTtRQUN4QixxQkFBcUIsRUFBRSxJQUFJO0tBQzVCO0lBQ0Qsa0JBQWtCLEVBQUU7UUFDbEIsU0FBUyxFQUFFLEtBQUs7UUFDaEIsTUFBTSxFQUFFLE9BQU87UUFDZixpQkFBaUIsRUFBRSxLQUFLO0tBQ3pCO0lBQ0QsZ0JBQWdCLEVBQUU7UUFDaEIsTUFBTSxFQUFFLE9BQU87UUFDZixpQkFBaUIsRUFBRSxLQUFLO1FBQ3hCLFFBQVEsRUFBRSxLQUFLO1FBQ2YsUUFBUSxFQUFFLFNBQVM7UUFDbkIsUUFBUSxFQUFFLEtBQUs7UUFDZixRQUFRLEVBQUUsS0FBSztLQUNoQjtJQUNELE1BQU0sRUFBRTtRQUNOLE9BQU8sRUFBRSxJQUFJO1FBQ2IsV0FBVyxFQUFFLENBQUM7UUFDZCxlQUFlLEVBQUUsSUFBSTtRQUNyQixlQUFlLEVBQUUsTUFBTTtRQUN2QixjQUFjLEVBQUUsQ0FBQztLQUNsQjtJQUNELFVBQVUsRUFBRTtRQUNWLE9BQU8sRUFBRSxLQUFLO1FBQ2QsU0FBUyxFQUFFLGFBQWE7UUFDeEIsYUFBYSxFQUFFLE9BQU87UUFDdEIsVUFBVSxFQUFFLEtBQUs7UUFDakIsSUFBSSxFQUFFLElBQUksQ0FBQyw2Q0FBNkM7S0FDekQ7SUFDRCxNQUFNLEVBQUU7UUFDTixZQUFZLEVBQUUsS0FBSztRQUNuQixTQUFTLEVBQUUsS0FBSztRQUNoQixnQkFBZ0IsRUFBRSxJQUFJO1FBQ3RCLFdBQVcsRUFBRSxXQUFXO1FBQ3hCLGlCQUFpQixFQUFFLEVBQUU7UUFDckIsV0FBVyxFQUFFLElBQUk7UUFDakIsTUFBTSxFQUFFLElBQUk7UUFDWixZQUFZLEVBQUUsSUFBSTtRQUNsQixNQUFNLEVBQUU7WUFDTixPQUFPLEVBQUUsS0FBSztZQUNkLFFBQVEsRUFBRSxlQUFlO1lBQ3pCLGdCQUFnQixFQUFFLHNFQUFzRTtZQUN4RixRQUFRLEVBQUUsNENBQTRDO1lBQ3RELFFBQVEsRUFBRSx5Q0FBeUM7WUFDbkQsWUFBWSxFQUFFLGtCQUFrQjtTQUNqQztRQUNELDBCQUEwQixFQUFFLElBQUk7UUFDaEMseUJBQXlCLEVBQUUsRUFFMUI7UUFDRCx1QkFBdUIsRUFBRSxLQUFLO0tBQy9CO0lBQ0QsT0FBTyxFQUFFO1FBQ1A7WUFDRSxJQUFJLEVBQUUsV0FBVztZQUNqQixTQUFTLEVBQUUsMkJBQTJCO1lBQ3RDLFdBQVcsRUFBRSxxREFBcUQ7WUFDbEUsV0FBVyxFQUFFLGdGQUFnRjtZQUM3RixVQUFVLEVBQUUsSUFBSTtZQUNoQixFQUFFLEVBQUUsSUFBSTtZQUNSLFdBQVcsRUFBRSxJQUFJO1lBQ2pCLE9BQU8sRUFBRSxDQUFDO1lBQ1YsT0FBTyxFQUFFLEVBQUU7U0FDWixFQUFFO1lBQ0QsSUFBSSxFQUFFLG1CQUFtQjtZQUN6QixTQUFTLEVBQUUsa0NBQWtDO1lBQzdDLFdBQVcsRUFBRSx1REFBdUQ7WUFDcEUsV0FBVyxFQUFFLDJOQUEyTjtZQUN4TyxVQUFVLEVBQUUsSUFBSTtZQUNoQixFQUFFLEVBQUUsSUFBSTtZQUNSLFdBQVcsRUFBRSxJQUFJO1lBQ2pCLE9BQU8sRUFBRSxDQUFDO1lBQ1YsT0FBTyxFQUFFLEVBQUU7U0FDWixFQUFFO1lBQ0QsSUFBSSxFQUFFLHdCQUF3QjtZQUM5QixTQUFTLEVBQUUsc0NBQXNDO1lBQ2pELFdBQVcsRUFBRSw2R0FBNkc7WUFDMUgsV0FBVyxFQUFFLGlEQUFpRDtZQUM5RCxVQUFVLEVBQUUsSUFBSTtZQUNoQixFQUFFLEVBQUUsSUFBSTtZQUNSLFdBQVcsRUFBRSxJQUFJO1lBQ2pCLE9BQU8sRUFBRSxDQUFDO1lBQ1YsT0FBTyxFQUFFLEVBQUU7U0FDWixFQUFFO1lBQ0QsSUFBSSxFQUFFLGtCQUFrQjtZQUN4QixTQUFTLEVBQUUsa0NBQWtDO1lBQzdDLFdBQVcsRUFBRSw0REFBNEQ7WUFDekUsV0FBVyxFQUFFLHdJQUF3STtZQUNySixVQUFVLEVBQUUsTUFBTTtZQUNsQixFQUFFLEVBQUUsSUFBSTtZQUNSLFdBQVcsRUFBRSxJQUFJO1lBQ2pCLE9BQU8sRUFBRSxDQUFDO1lBQ1YsT0FBTyxFQUFFLEVBQUU7U0FDWixFQUFFO1lBQ0QsSUFBSSxFQUFFLGNBQWM7WUFDcEIsU0FBUyxFQUFFLDhCQUE4QjtZQUN6QyxXQUFXLEVBQUUsaUZBQWlGO1lBQzlGLFdBQVcsRUFBRSxtTUFBbU07WUFDaE4sVUFBVSxFQUFFLElBQUk7WUFDaEIsRUFBRSxFQUFFLGNBQWM7WUFDbEIsV0FBVyxFQUFFLDRGQUE0RjtZQUN6RyxPQUFPLEVBQUUsQ0FBQztZQUNWLE9BQU8sRUFBRSxFQUFFO1NBQ1osRUFBRTtZQUNELElBQUksRUFBRSxnQkFBZ0I7WUFDdEIsU0FBUyxFQUFFLGdDQUFnQztZQUMzQyxXQUFXLEVBQUUsaUZBQWlGO1lBQzlGLFdBQVcsRUFBRSxtTUFBbU07WUFDaE4sVUFBVSxFQUFFLElBQUk7WUFDaEIsRUFBRSxFQUFFLGdCQUFnQjtZQUNwQixXQUFXLEVBQUUsNEZBQTRGO1lBQ3pHLE9BQU8sRUFBRSxDQUFDO1lBQ1YsT0FBTyxFQUFFLEVBQUU7U0FDWjtLQUNGO0lBQ0QsSUFBSSxFQUFFO1FBQ0osUUFBUSxFQUFFLE9BQU87UUFDakIsT0FBTyxFQUFFO1lBQ1AsTUFBTSxFQUFFO2dCQUNOLElBQUksRUFBRTtvQkFDSixVQUFVLEVBQUUsQ0FBQztvQkFDYixLQUFLLEVBQUUsUUFBUTtvQkFDZixJQUFJLEVBQUU7d0JBQ0osYUFBYSxFQUFFLEVBQUU7d0JBQ2pCLGNBQWMsRUFBRSxFQUFFO3dCQUNsQixhQUFhLEVBQUUsRUFBRTt3QkFDakIsZUFBZSxFQUFFLElBQUk7d0JBQ3JCLElBQUksRUFBRSxRQUFRO3dCQUNkLEtBQUssRUFBRSxNQUFNO3dCQUNiLElBQUksRUFBRSxFQUFFO3FCQUNUO2lCQUNGO2dCQUNELElBQUksRUFBRTtvQkFDSixTQUFTLEVBQUUsQ0FBQztvQkFDWixLQUFLLEVBQUUsT0FBTztvQkFDZCxJQUFJLEVBQUU7d0JBQ0osYUFBYSxFQUFFLEVBQUU7d0JBQ2pCLGNBQWMsRUFBRSxDQUFDO3dCQUNqQixhQUFhLEVBQUUsRUFBRTt3QkFDakIsZUFBZSxFQUFFLElBQUk7d0JBQ3JCLElBQUksRUFBRSxRQUFRO3dCQUNkLEtBQUssRUFBRSxNQUFNO3dCQUNiLElBQUksRUFBRSxFQUFFO3FCQUNUO2lCQUNGO2FBQ0Y7WUFDRCxZQUFZLEVBQUU7Z0JBQ1osSUFBSSxFQUFFO29CQUNKLFFBQVEsRUFBRSxLQUFLO2lCQUNoQjtnQkFDRCxHQUFHLEVBQUUsRUFDSjtnQkFDRCxRQUFRLEVBQUU7b0JBQ1IsT0FBTyxFQUFFLEtBQUs7aUJBQ2Y7YUFDRjtZQUNELGVBQWUsRUFBRSx3QkFBd0I7U0FDMUM7S0FDRjtDQUNGLENBQUMifQ==