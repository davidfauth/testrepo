"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2018-07-12.
 */
Object.defineProperty(exports, "__esModule", { value: true });
const Bluebird = require("bluebird");
const _ = require("lodash");
const LkRequest = require("../../lib/LkRequest");
const connector_1 = require("./connector");
const LKE = require('../../services');
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
class AzureSearchConnector extends connector_1.Connector {
    $getStoreId() {
        return Utils.NOT_IMPLEMENTED();
    }
    /**
     * @returns {LkRequest}
     */
    get $request() {
        if (Utils.noValue(this.request)) {
            const { scheme, host, port } = Utils.extractHostPort(this.getIndexOption('url'));
            this.request = new LkRequest({
                url: '',
                headers: {
                    'Content-type': 'application/json',
                    'api-key': this.getIndexOption('apiKey')
                },
                baseUrl: `${scheme}://${host}:${port}`,
                json: true,
                pool: { maxSockets: 5 }
            });
        }
        return this.request;
    }
    /**
     * Azure search service API version.
     *
     * @returns {string}
     */
    get API_VERSION() {
        // Latest version of azure search rest api.
        // It is required for any request and cannot be detected automatically
        return '2019-05-06';
    }
    /**
     * Execute a get request on the azure search endpoint.
     *
     * @param {string}   url
     * @param {object}   [params]
     * @param {number[]} [expectedStatusCodes]
     * @returns {Bluebird<IncomingMessage>}
     * @private
     */
    async doGet(url, params, expectedStatusCodes) {
        const defaultParams = {
            'api-version': this.API_VERSION
        };
        const urlParams = Utils.hasValue(params) ? _.merge(defaultParams, params) : defaultParams;
        return this.$request.get('', { url: url, qs: urlParams }, expectedStatusCodes);
    }
    /**
     * Get the number of indexed documents on `indexName`.
     *
     * @param {string} indexName
     * @returns {Bluebird<number>}
     */
    async getCount(indexName) {
        const response = await this.doGet(`/indexes/${indexName}/docs/$count`, undefined, [200]);
        return Number(response.body);
    }
    /**
     * Return an `AzureSearchIndex` if exists.
     */
    async findIndex(indexName) {
        return this.doGet(`/indexes/${indexName}`).then(response => {
            if (response.statusCode !== 200) {
                if (response.statusCode === 404) {
                    return Errors.business('source_action_needed', `Index ${indexName} was not found`, true);
                }
                const errorMessage = response.body.Message
                    || JSON.stringify(response.body);
                return Errors.technical('index_unreachable', `Index ${indexName} was not found, error: ` + errorMessage, true);
            }
            return response.body;
        });
    }
    /**
     * Execute a full text search request on the search service.
     *
     * @param {string}             indexName
     * @param {AzureSearchOptions} options
     * @returns {Bluebird<AzureSearchResult>}
     */
    async doFullTextSearch(indexName, options) {
        const response = await this.doGet(`/indexes/${indexName}/docs`, {
            search: options.luceneQuery,
            queryType: 'full',
            searchFields: options.searchFields + '',
            $filter: options.filterQuery,
            $top: options.size,
            $skip: options.from,
            $orderby: 'search.score() desc',
            $count: true
        }, [200]);
        return response.body;
    }
    /**
     * Connect to the remote server.
     *
     * @returns {Bluebird<string>} resolved with the SemVer version of the remote server
     */
    $connect() {
        return this.$checkUp()
            .catch(error => {
            if (error.key === 'critical' && error.message.includes('403')) {
                throw Errors.business('invalid_parameter', 'Authentication failed, please check azure ' +
                    'search url and apiKey in configuration');
            }
            throw error;
        }).return('[unknown]');
    }
    /**
     * Check if the remote server is alive.
     *
     * @returns {Bluebird<void>}
     */
    $checkUp() {
        return Bluebird.resolve().then(() => this.doGet('', undefined, [200]).then(r => {
            if (Utils.noValue(r)) {
                return Errors.technical('index_unreachable', 'Cannot connect to the search service', true);
            }
        }));
    }
    /**
     * Data that the connector will pass to the driver.
     */
    $getConnectorData() {
        return Bluebird.resolve({});
    }
}
exports.AzureSearchConnector = AzureSearchConnector;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXp1cmVTZWFyY2hDb25uZWN0b3IuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2Nvbm5lY3Rvci9henVyZVNlYXJjaENvbm5lY3Rvci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7O0dBS0c7O0FBRUgscUNBQXFDO0FBQ3JDLDRCQUE0QjtBQUM1QixpREFBa0Q7QUFFbEQsMkNBQXdDO0FBQ3hDLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0FBQ3RDLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUF3Qi9CLE1BQWEsb0JBQXFCLFNBQVEscUJBQVM7SUFHMUMsV0FBVztRQUNoQixPQUFPLEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUNqQyxDQUFDO0lBQ0Q7O09BRUc7SUFDSCxJQUFZLFFBQVE7UUFDbEIsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUMvQixNQUFNLEVBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUMsR0FBRyxLQUFLLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztZQUMvRSxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksU0FBUyxDQUFDO2dCQUMzQixHQUFHLEVBQUUsRUFBRTtnQkFDUCxPQUFPLEVBQUU7b0JBQ1AsY0FBYyxFQUFFLGtCQUFrQjtvQkFDbEMsU0FBUyxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDO2lCQUN6QztnQkFDRCxPQUFPLEVBQUUsR0FBRyxNQUFNLE1BQU0sSUFBSSxJQUFJLElBQUksRUFBRTtnQkFDdEMsSUFBSSxFQUFFLElBQUk7Z0JBQ1YsSUFBSSxFQUFFLEVBQUMsVUFBVSxFQUFFLENBQUMsRUFBQzthQUN0QixDQUFDLENBQUM7U0FDSjtRQUNELE9BQU8sSUFBSSxDQUFDLE9BQVEsQ0FBQztJQUN2QixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILElBQUksV0FBVztRQUNiLDJDQUEyQztRQUMzQyxzRUFBc0U7UUFDdEUsT0FBTyxZQUFZLENBQUM7SUFDdEIsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0ssS0FBSyxDQUFDLEtBQUssQ0FDakIsR0FBVyxFQUNYLE1BQWUsRUFDZixtQkFBOEI7UUFFOUIsTUFBTSxhQUFhLEdBQUc7WUFDcEIsYUFBYSxFQUFFLElBQUksQ0FBQyxXQUFXO1NBQ2hDLENBQUM7UUFDRixNQUFNLFNBQVMsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGFBQWEsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDO1FBRTFGLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEVBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFDLEVBQUUsbUJBQW1CLENBQUMsQ0FBQztJQUMvRSxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxLQUFLLENBQUMsUUFBUSxDQUFDLFNBQWlCO1FBQ3JDLE1BQU0sUUFBUSxHQUFJLE1BQU0sSUFBSSxDQUFDLEtBQUssQ0FBQyxZQUFZLFNBQVMsY0FBYyxFQUFFLFNBQVMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDMUYsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQy9CLENBQUM7SUFFRDs7T0FFRztJQUNJLEtBQUssQ0FBQyxTQUFTLENBQUMsU0FBaUI7UUFDdEMsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksU0FBUyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDekQsSUFBSSxRQUFRLENBQUMsVUFBVSxLQUFLLEdBQUcsRUFBRTtnQkFDL0IsSUFBSSxRQUFRLENBQUMsVUFBVSxLQUFLLEdBQUcsRUFBRTtvQkFDL0IsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLHNCQUFzQixFQUFFLFNBQVMsU0FBUyxnQkFBZ0IsRUFBRSxJQUFJLENBQUMsQ0FBQztpQkFDMUY7Z0JBQ0QsTUFBTSxZQUFZLEdBQUksUUFBUSxDQUFDLElBQTJCLENBQUMsT0FBTzt1QkFDN0QsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ25DLE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsRUFDekMsU0FBUyxTQUFTLHlCQUF5QixHQUFHLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQzthQUNyRTtZQUNELE9BQU8sUUFBUSxDQUFDLElBQUksQ0FBQztRQUN2QixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSSxLQUFLLENBQUMsZ0JBQWdCLENBQzNCLFNBQWlCLEVBQ2pCLE9BQTJCO1FBRTNCLE1BQU0sUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDLEtBQUssQ0FBQyxZQUFZLFNBQVMsT0FBTyxFQUFFO1lBQzlELE1BQU0sRUFBRSxPQUFPLENBQUMsV0FBVztZQUMzQixTQUFTLEVBQUUsTUFBTTtZQUNqQixZQUFZLEVBQUUsT0FBTyxDQUFDLFlBQVksR0FBRyxFQUFFO1lBQ3ZDLE9BQU8sRUFBRSxPQUFPLENBQUMsV0FBVztZQUM1QixJQUFJLEVBQUUsT0FBTyxDQUFDLElBQUk7WUFDbEIsS0FBSyxFQUFFLE9BQU8sQ0FBQyxJQUFJO1lBQ25CLFFBQVEsRUFBRSxxQkFBcUI7WUFDL0IsTUFBTSxFQUFFLElBQUk7U0FDYixFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUVWLE9BQU8sUUFBUSxDQUFDLElBQXlCLENBQUM7SUFDNUMsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxRQUFRO1FBQ2IsT0FBTyxJQUFJLENBQUMsUUFBUSxFQUFFO2FBQ25CLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUNiLElBQUksS0FBSyxDQUFDLEdBQUcsS0FBSyxVQUFVLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQzdELE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsRUFBRSw0Q0FBNEM7b0JBQ3JGLHdDQUF3QyxDQUFDLENBQUM7YUFDN0M7WUFDRCxNQUFNLEtBQUssQ0FBQztRQUNkLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUMzQixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNJLFFBQVE7UUFDYixPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLEVBQUUsU0FBUyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUU7WUFDN0UsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUNwQixPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQUMsbUJBQW1CLEVBQUUsc0NBQXNDLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDNUY7UUFDSCxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ04sQ0FBQztJQUVEOztPQUVHO0lBQ0ksaUJBQWlCO1FBQ3RCLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUM5QixDQUFDO0NBQ0Y7QUFwSkQsb0RBb0pDIn0=