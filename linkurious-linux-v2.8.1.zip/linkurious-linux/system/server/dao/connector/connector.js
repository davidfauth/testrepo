"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const LKE = require("../../services");
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
class Connector {
    /**
     * Use `indexOptions` if this connector will be used only for IndexDAOs.
     * If used by a GraphDAO, `indexOptions` is not defined.
     *
     * @param graphOptions   GraphDAO options
     * @param [indexOptions] IndexDAO options (only if the type of the DAO is 'Index')
     */
    constructor(graphOptions, indexOptions) {
        this.CONNECT_TIMEOUT = 10000; // 10 seconds
        this.graphOptions = graphOptions;
        this.indexOptions = indexOptions;
    }
    get SLOW_QUERY_THRESHOLD() {
        return LKE.isTestMode() ? 50 : 1000;
    }
    /**
     * Return a GraphDAO option by key (or a default value if undefined or null).
     *
     * @param key            Option key
     * @param [defaultValue] Default value
     */
    getGraphOption(key, defaultValue) {
        const value = this.graphOptions[key];
        return Utils.hasValue(value) ? value : defaultValue;
    }
    /**
     * Return an IndexDAO option by key (or a default value if undefined or null).
     *
     * @param key            Option key
     * @param [defaultValue] Default value
     */
    getIndexOption(key, defaultValue) {
        if (Utils.noValue(this.indexOptions)) {
            throw Errors.technical('bug', "Don't call getIndexOption in a connector used for GraphDAOs");
        }
        const value = this.indexOptions[key];
        return Utils.hasValue(value) ? value : defaultValue;
    }
    /**
     * Disconnect from the remote server.
     *
     * Optional to implement.
     */
    $disconnect() { }
}
exports.Connector = Connector;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29ubmVjdG9yLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL2Rhby9jb25uZWN0b3IvY29ubmVjdG9yLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBU0Esc0NBQXVDO0FBRXZDLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFFL0IsTUFBc0IsU0FBUztJQU03Qjs7Ozs7O09BTUc7SUFDSCxZQUFZLFlBQW9DLEVBQUUsWUFBcUM7UUFadkUsb0JBQWUsR0FBRyxLQUFLLENBQUMsQ0FBQyxhQUFhO1FBYXBELElBQUksQ0FBQyxZQUFZLEdBQUcsWUFBWSxDQUFDO1FBQ2pDLElBQUksQ0FBQyxZQUFZLEdBQUcsWUFBWSxDQUFDO0lBQ25DLENBQUM7SUFFRCxJQUFJLG9CQUFvQjtRQUN0QixPQUFPLEdBQUcsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7SUFDdEMsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ08sY0FBYyxDQUFDLEdBQVcsRUFBRSxZQUFzQjtRQUMxRCxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ3JDLE9BQU8sS0FBSyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUM7SUFDdEQsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ08sY0FBYyxDQUFDLEdBQVcsRUFBRSxZQUFzQjtRQUMxRCxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFO1lBQ3BDLE1BQU0sTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsNkRBQTZELENBQUMsQ0FBQztTQUM5RjtRQUVELE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDckMsT0FBTyxLQUFLLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQztJQUN0RCxDQUFDO0lBT0Q7Ozs7T0FJRztJQUNJLFdBQVcsS0FBVSxDQUFDO0NBbUI5QjtBQTdFRCw4QkE2RUMifQ==