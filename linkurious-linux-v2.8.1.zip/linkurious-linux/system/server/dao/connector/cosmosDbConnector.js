"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2018-06-29.
 */
Object.defineProperty(exports, "__esModule", { value: true });
const Bluebird = require("bluebird");
const LKE = require('../../services');
const Errors = LKE.getErrors();
const Utils = LKE.getUtils();
const crypto = require("crypto");
const LkRequest = require("../../lib/LkRequest");
const GremlinUtils = require("../utils/gremlinUtils");
const GremlinConnector = require("./gremlinConnector");
class CosmosDbConnector extends GremlinConnector {
    /**
     * @param {any} graphOptions   GraphDAO options
     * @param {any} [indexOptions] IndexDAO options (only if the type of the DAO is 'Index')
     */
    constructor(graphOptions, indexOptions) {
        super(graphOptions, indexOptions, {
            manageTransactions: true,
            httpPathGremlinServer: '/gremlin',
            binaryMessages: true,
            useSessions: false
        });
    }
    /**
     * @returns {string} username
     */
    get $username() {
        // Cosmos Db username is derived from the database and the collection
        return `/dbs/${this.getGraphOption('database')}/colls/${this.getGraphOption('collection')}`;
    }
    /**
     * @returns {string} password
     */
    get $password() {
        // The password is the account primary key
        return this.getGraphOption('primaryKey');
    }
    get documentsHost() {
        const dotNetURI = this.getGraphOption('.NET SDK URI');
        if (dotNetURI !== undefined) {
            return Utils.extractHostPort(dotNetURI).host;
        }
        const url = this.getGraphOption('url');
        const host = Utils.extractHostPort(url).host;
        return host.replace('gremlin.cosmosdb', 'documents');
    }
    /**
     * @returns {LkRequest}
     */
    async doSQLQuery(query, parameters) {
        const date = new Date().toUTCString();
        const client = new LkRequest({
            headers: {
                // TODO Understand the role of each header
                'Content-type': 'application/query+json',
                Authorization: this.getSqlQueryAuthToken(date),
                'x-ms-date': date,
                'x-ms-documentdb-query-enable-scan': 'true',
                'x-ms-documentdb-populatequerymetrics': 'true',
                'x-ms-documentdb-query-parallelizecrosspartitionquery': 'true',
                'x-ms-documentdb-query-enablecrosspartition': 'true',
                Accept: 'application/json',
                'Cache-Control': 'no-cache',
                'x-ms-version': '2018-12-31',
                'x-ms-documentdb-isquery': 'true',
                'x-ms-max-item-count': '1000',
                'x-ms-cosmos-allow-tentative-writes': 'true',
                'x-ms-documentdb-partitionkeyrangeid': '0'
            },
            url: `https://${this.documentsHost}/${this.resourceLink}/docs`,
            json: true,
            body: {
                query: query,
                parameters: parameters
            }
        });
        const response = await client.post('', undefined, [200]);
        return response.body.Documents;
    }
    get resourceLink() {
        const database = this.getGraphOption('database');
        const collection = this.getGraphOption('collection');
        return `dbs/${database}/colls/${collection}`;
    }
    getSqlQueryAuthToken(date) {
        // Construct authorization token from the master key
        // source: https://docs.microsoft.com/en-us/rest/api/cosmos-db/access-control-on-cosmosdb-resources
        const verb = 'post';
        const resourceType = 'docs';
        const masterKey = this.$password;
        const key = Buffer.from(masterKey, 'base64');
        const text = verb +
            '\n' +
            resourceType +
            '\n' +
            this.resourceLink +
            '\n' +
            date.toLowerCase() +
            '\n' +
            '' +
            '\n';
        const body = Buffer.from(text, 'utf8');
        const signature = crypto
            .createHmac('sha256', key)
            .update(body)
            .digest('base64');
        return encodeURIComponent('type=master&ver=1.0&sig=' + signature);
    }
    /**
     * Connect to the remote server.
     *
     * @returns {Bluebird<string>} resolved with the SemVer version of the remote server
     */
    async $connect() {
        return super.$connect().catch((error) => {
            // the url is valid but the authentication failed, the primary key must be wrong
            if (error.message.includes('Invalid credentials')) {
                throw Errors.business('invalid_parameter', 'Authentication failed, ' + 'please check cosmos db primaryKey in configuration');
            }
            // the resource could not be found, knows causes:
            // - database and collection are inverted in the config file
            // - some typo in the database name or collection name
            if (error.message.includes('BackendStatusCode : NotFound')) {
                throw Errors.business('invalid_parameter', 'Resource Not Found, ' + 'please check cosmos db database and collection in configuration');
            }
            // There can be a confusion here between:
            // - the document db endpoint (.NET SDK URI) e.g: <service-name>.documents.azure.com
            // - the gremlin endpoint for the same service e.g: <service-name>.gremlin.cosmosdb.azure.com
            // Both matches the same service but for different APIs
            // What we need is the gremlin endpoint.
            if (error.message.includes('unexpected server response') &&
                this.getGraphOption('url').includes('documents.azure.com')) {
                throw Errors.business('invalid_parameter', 'Cannot connect to the gremlin server, ' +
                    'please provide the gremlin endpoint as url in configuration');
            }
            throw error;
        });
    }
    /**
     * Check if the remote server is alive.
     *
     * @returns {Bluebird<void>}
     */
    $checkUp() {
        return this.$doGremlinQuery('g.inject(true)', { session: 'none' })
            .then((r) => {
            if (r && r.length === 1 && r[0] === true) {
                return;
            }
            return Errors.technical('graph_unreachable', 'Cannot connect to the gremlin server.', true);
        })
            .catch((error) => {
            // if the checkup failed, reset the client
            return this.$closeConnection(error);
        });
    }
    /**
     * Get the SemVer of the remote server.
     *
     * @returns {Bluebird<string>} resolved with the SemVer version of the remote server
     */
    async $getVersion() {
        // We do not know yet how to detect the cosmos db version.
        return Promise.resolve('[unknown]');
    }
    /**
     * Detect the current store ID.
     *
     * A store ID is the name of the current database (if the graph server is multi-tenant)
     * otherwise the vendor name.
     *
     * @returns {Bluebird<string>}
     */
    async $getStoreId() {
        const storeId = `${this.getGraphOption('database')}/${this.getGraphOption('collection')}`;
        return Promise.resolve(storeId);
    }
    /**
     * Stream gremlin query results.
     *
     * @param {string}  query
     * @param {object}  [options]
     * @param {object}  [options.bindings]                      Gremlin Variable bindings
     * @param {number}  [options.batchSize=1]                   Number of results to read from the gremlin server at a time
     * @param {number}  [options.timeout]                       Milliseconds to wait before it fails
     * @param {boolean} [options.allowForbiddenStatements=true] Whether the query can use forbidden statements
     * @param {boolean} [options.useDef]                        Whether to use def keyword to declare session variables
     * @returns {Bluebird<Readable<any>>}
     */
    $streamGremlinQuery(query, options = {}) {
        const { timeout, allowForbiddenStatements } = options;
        return Bluebird.resolve().then(() => {
            if (!this._connected) {
                return Errors.technical('graph_unreachable', 'Cannot connect to the gremlin server.', true);
            }
            GremlinUtils.checkQuery(query, allowForbiddenStatements);
            const request = this.$buildGremlinRequest(query, {
                scriptEvaluationTimeout: timeout,
                manageTransaction: false,
                batchSize: options.batchSize,
                caching: 'phantom',
                bindings: options.bindings
            });
            return this.$sendRequest(request).then((messageStream) => {
                // the number of results received by the gremlin server at a time depends on `batchSize`
                // we flatten the stream to ensure that we emit one item at a time
                return Utils.safePipe(messageStream, Utils.flatStream());
            });
        });
    }
}
exports.CosmosDbConnector = CosmosDbConnector;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29zbW9zRGJDb25uZWN0b3IuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2Nvbm5lY3Rvci9jb3Ntb3NEYkNvbm5lY3Rvci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7O0dBS0c7O0FBRUgscUNBQXFDO0FBSXJDLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0FBRXRDLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsaUNBQWlDO0FBQ2pDLGlEQUFrRDtBQUNsRCxzREFBdUQ7QUFDdkQsdURBQXdEO0FBRXhELE1BQWEsaUJBQWtCLFNBQVEsZ0JBQWdCO0lBQ3JEOzs7T0FHRztJQUNILFlBQVksWUFBb0MsRUFBRSxZQUFvQztRQUNwRixLQUFLLENBQUMsWUFBWSxFQUFFLFlBQVksRUFBRTtZQUNoQyxrQkFBa0IsRUFBRSxJQUFJO1lBQ3hCLHFCQUFxQixFQUFFLFVBQVU7WUFDakMsY0FBYyxFQUFFLElBQUk7WUFDcEIsV0FBVyxFQUFFLEtBQUs7U0FDbkIsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0gsSUFBSSxTQUFTO1FBQ1gscUVBQXFFO1FBQ3JFLE9BQU8sUUFBUSxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQztJQUM5RixDQUFDO0lBRUQ7O09BRUc7SUFDSCxJQUFJLFNBQVM7UUFDWCwwQ0FBMEM7UUFDMUMsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBVyxDQUFDO0lBQ3JELENBQUM7SUFFRCxJQUFZLGFBQWE7UUFDdkIsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsQ0FBQztRQUN0RCxJQUFJLFNBQVMsS0FBSyxTQUFTLEVBQUU7WUFDM0IsT0FBTyxLQUFLLENBQUMsZUFBZSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQztTQUM5QztRQUNELE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFXLENBQUM7UUFDakQsTUFBTSxJQUFJLEdBQVcsS0FBSyxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFDckQsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLGtCQUFrQixFQUFFLFdBQVcsQ0FBQyxDQUFDO0lBQ3ZELENBQUM7SUFFRDs7T0FFRztJQUNJLEtBQUssQ0FBQyxVQUFVLENBQUMsS0FBYSxFQUFFLFVBQXFCO1FBQzFELE1BQU0sSUFBSSxHQUFHLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDdEMsTUFBTSxNQUFNLEdBQUcsSUFBSSxTQUFTLENBQUM7WUFDM0IsT0FBTyxFQUFFO2dCQUNQLDBDQUEwQztnQkFDMUMsY0FBYyxFQUFFLHdCQUF3QjtnQkFDeEMsYUFBYSxFQUFFLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUM7Z0JBQzlDLFdBQVcsRUFBRSxJQUFJO2dCQUNqQixtQ0FBbUMsRUFBRSxNQUFNO2dCQUMzQyxzQ0FBc0MsRUFBRSxNQUFNO2dCQUM5QyxzREFBc0QsRUFBRSxNQUFNO2dCQUM5RCw0Q0FBNEMsRUFBRSxNQUFNO2dCQUNwRCxNQUFNLEVBQUUsa0JBQWtCO2dCQUMxQixlQUFlLEVBQUUsVUFBVTtnQkFDM0IsY0FBYyxFQUFFLFlBQVk7Z0JBQzVCLHlCQUF5QixFQUFFLE1BQU07Z0JBQ2pDLHFCQUFxQixFQUFFLE1BQU07Z0JBQzdCLG9DQUFvQyxFQUFFLE1BQU07Z0JBQzVDLHFDQUFxQyxFQUFFLEdBQUc7YUFDM0M7WUFDRCxHQUFHLEVBQUUsV0FBVyxJQUFJLENBQUMsYUFBYSxJQUFJLElBQUksQ0FBQyxZQUFZLE9BQU87WUFDOUQsSUFBSSxFQUFFLElBQUk7WUFDVixJQUFJLEVBQUU7Z0JBQ0osS0FBSyxFQUFFLEtBQUs7Z0JBQ1osVUFBVSxFQUFFLFVBQVU7YUFDdkI7U0FDRixDQUFDLENBQUM7UUFFSCxNQUFNLFFBQVEsR0FBRyxNQUFNLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFFLFNBQVMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDekQsT0FBTyxRQUFRLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQztJQUNqQyxDQUFDO0lBRUQsSUFBWSxZQUFZO1FBQ3RCLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDakQsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUNyRCxPQUFPLE9BQU8sUUFBUSxVQUFVLFVBQVUsRUFBRSxDQUFDO0lBQy9DLENBQUM7SUFFTyxvQkFBb0IsQ0FBQyxJQUFZO1FBQ3ZDLG9EQUFvRDtRQUNwRCxtR0FBbUc7UUFDbkcsTUFBTSxJQUFJLEdBQUcsTUFBTSxDQUFDO1FBQ3BCLE1BQU0sWUFBWSxHQUFHLE1BQU0sQ0FBQztRQUM1QixNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO1FBRWpDLE1BQU0sR0FBRyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLFFBQVEsQ0FBQyxDQUFDO1FBRTdDLE1BQU0sSUFBSSxHQUNSLElBQUk7WUFDSixJQUFJO1lBQ0osWUFBWTtZQUNaLElBQUk7WUFDSixJQUFJLENBQUMsWUFBWTtZQUNqQixJQUFJO1lBQ0osSUFBSSxDQUFDLFdBQVcsRUFBRTtZQUNsQixJQUFJO1lBQ0osRUFBRTtZQUNGLElBQUksQ0FBQztRQUVQLE1BQU0sSUFBSSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQ3ZDLE1BQU0sU0FBUyxHQUFHLE1BQU07YUFDckIsVUFBVSxDQUFDLFFBQVEsRUFBRSxHQUFHLENBQUM7YUFDekIsTUFBTSxDQUFDLElBQUksQ0FBQzthQUNaLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUVwQixPQUFPLGtCQUFrQixDQUFDLDBCQUEwQixHQUFHLFNBQVMsQ0FBQyxDQUFDO0lBQ3BFLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ksS0FBSyxDQUFDLFFBQVE7UUFDbkIsT0FBTyxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBWSxFQUFFLEVBQUU7WUFDN0MsZ0ZBQWdGO1lBQ2hGLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMscUJBQXFCLENBQUMsRUFBRTtnQkFDakQsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUNuQixtQkFBbUIsRUFDbkIseUJBQXlCLEdBQUcsb0RBQW9ELENBQ2pGLENBQUM7YUFDSDtZQUVELGlEQUFpRDtZQUNqRCw0REFBNEQ7WUFDNUQsc0RBQXNEO1lBQ3RELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsOEJBQThCLENBQUMsRUFBRTtnQkFDMUQsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUNuQixtQkFBbUIsRUFDbkIsc0JBQXNCLEdBQUcsaUVBQWlFLENBQzNGLENBQUM7YUFDSDtZQUVELHlDQUF5QztZQUN6QyxvRkFBb0Y7WUFDcEYsNkZBQTZGO1lBQzdGLHVEQUF1RDtZQUN2RCx3Q0FBd0M7WUFDeEMsSUFDRSxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyw0QkFBNEIsQ0FBQztnQkFDbkQsSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQVksQ0FBQyxRQUFRLENBQUMscUJBQXFCLENBQUMsRUFDdEU7Z0JBQ0EsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUNuQixtQkFBbUIsRUFDbkIsd0NBQXdDO29CQUN0Qyw2REFBNkQsQ0FDaEUsQ0FBQzthQUNIO1lBRUQsTUFBTSxLQUFLLENBQUM7UUFDZCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ksUUFBUTtRQUNiLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsRUFBRSxFQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUMsQ0FBQzthQUM3RCxJQUFJLENBQUMsQ0FBQyxDQUFZLEVBQUUsRUFBRTtZQUNyQixJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssSUFBSSxFQUFFO2dCQUN4QyxPQUFPO2FBQ1I7WUFDRCxPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQUMsbUJBQW1CLEVBQUUsdUNBQXVDLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDOUYsQ0FBQyxDQUFDO2FBQ0QsS0FBSyxDQUFDLENBQUMsS0FBWSxFQUFFLEVBQUU7WUFDdEIsMENBQTBDO1lBQzFDLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3RDLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxLQUFLLENBQUMsV0FBVztRQUN0QiwwREFBMEQ7UUFDMUQsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0ksS0FBSyxDQUFDLFdBQVc7UUFDdEIsTUFBTSxPQUFPLEdBQUcsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQztRQUMxRixPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDbEMsQ0FBQztJQUVEOzs7Ozs7Ozs7OztPQVdHO0lBQ0ksbUJBQW1CLENBQ3hCLEtBQWEsRUFDYixVQUErQixFQUFFO1FBRWpDLE1BQU0sRUFBQyxPQUFPLEVBQUUsd0JBQXdCLEVBQUMsR0FBRyxPQUFPLENBQUM7UUFDcEQsT0FBTyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNsQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRTtnQkFDcEIsT0FBTyxNQUFNLENBQUMsU0FBUyxDQUFDLG1CQUFtQixFQUFFLHVDQUF1QyxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQzdGO1lBQ0QsWUFBWSxDQUFDLFVBQVUsQ0FBQyxLQUFLLEVBQUUsd0JBQXdCLENBQUMsQ0FBQztZQUV6RCxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsb0JBQW9CLENBQUMsS0FBSyxFQUFFO2dCQUMvQyx1QkFBdUIsRUFBRSxPQUFPO2dCQUNoQyxpQkFBaUIsRUFBRSxLQUFLO2dCQUN4QixTQUFTLEVBQUUsT0FBTyxDQUFDLFNBQVM7Z0JBQzVCLE9BQU8sRUFBRSxTQUFTO2dCQUNsQixRQUFRLEVBQUUsT0FBTyxDQUFDLFFBQVE7YUFDM0IsQ0FBQyxDQUFDO1lBRUgsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLGFBQWdDLEVBQUUsRUFBRTtnQkFDMUUsd0ZBQXdGO2dCQUN4RixrRUFBa0U7Z0JBQ2xFLE9BQU8sS0FBSyxDQUFDLFFBQVEsQ0FBQyxhQUFhLEVBQUUsS0FBSyxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUM7WUFDM0QsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7Q0FDRjtBQTVPRCw4Q0E0T0MifQ==