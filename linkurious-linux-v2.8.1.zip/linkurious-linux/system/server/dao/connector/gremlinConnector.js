/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-09-01.
 */
'use strict';
const stream = require('stream');
const _ = require('lodash');
const Promise = require('bluebird');
const WebSocket = require('ws');
const uuid = require('uuid');
const LKE = require('../../services');
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
const Log = LKE.getLogger(__filename);
const { Connector } = require('./connector');
const GremlinUtils = require('../utils/gremlinUtils');
const LRUQueue = require('../../../lib/LRUQueue');
const GremlinStream = require('../utils/gremlinStream');
const { GraphRequestTimeout, Vendor } = require('../../models/errors/GraphRequestTimeout');
const { TechnicalError } = require('../../models/errors/TechnicalError');
const DEFAULT_SESSION_POOL_SIZE = 8;
const SESSION_REFRESH_MS = 10 * 60 * 1000; // 10 minutes
const COMMIT_QUERY = 'graph.tx().commit(); []';
class GremlinConnector extends Connector {
    /**
     * @param {any}     graphOptions                               GraphDAO options
     * @param {any}     [indexOptions]                             IndexDAO options (only if the type of the DAO is 'Index')
     * @param {object}  gremlinOptions
     * @param {boolean} gremlinOptions.manageTransactions          Whether transactions are committed automatically
     * @param {string}  [gremlinOptions.httpPathGremlinServer='/'] HTTP path of them gremlin server
     * @param {boolean} gremlinOptions.binaryMessages              Whether messages to the gremlin server should be packed as binary
     * @param {boolean} gremlinOptions.useSessions                 Whether to use a session for all gremlin requests
     */
    constructor(graphOptions, indexOptions, gremlinOptions) {
        super(graphOptions, indexOptions);
        this._manageTransactions = gremlinOptions.manageTransactions;
        this._httpPathGremlinServer = gremlinOptions.httpPathGremlinServer;
        this._aliases = {};
        this._binaryMessages = gremlinOptions.binaryMessages;
        this._useSessions = gremlinOptions.useSessions;
        this._pendingRequests = new Map();
        this._connected = false;
        this._activeSessions = new LRUQueue();
        // Max amount of time before external changes are seen by LKE
        // This helps spacing the read commits frequency
        // It improves performance when the server is under heavy read usage.
        this._maxStale = this.getGraphOption('maxStale', 0);
        this._lastCommit = new Map();
        this._isIndex = Utils.hasValue(indexOptions); // Whether the connector is used by an index dao
    }
    /**
     * Get the size of the session pool
     *
     * @returns {number}
     */
    get sessionPoolSize() {
        if (this._isIndex) {
            // Use only 1 sessions for the index dao
            // This is required for how today  JanusGraphSearchDriver._createIndex is implemented
            return 1;
        }
        return this.getGraphOption('sessionPool', DEFAULT_SESSION_POOL_SIZE);
    }
    /**
     *
     * @returns {boolean} Whether to use a session for all gremlin requests
     */
    get useSessions() {
        return this._useSessions;
    }
    /**
     * @returns {string} username
     */
    get $username() {
        return this.getGraphOption('user');
    }
    /**
     * @returns {string} password
     */
    get $password() {
        return this.getGraphOption('password');
    }
    /**
     * Connect to the remote server.
     *
     * @returns {Bluebird<string>} resolved with the SemVer version of the remote server
     */
    $connect() {
        return this._connectGremlinServer().then(() => {
            // Stateless connectors will not require this
            if (this._useSessions) {
                // Generate unique session ids.
                for (let i = 0; i < this.sessionPoolSize; i++) {
                    const sessionId = uuid.v4();
                    this._activeSessions.add(sessionId);
                    this._lastCommit.set(sessionId, 0);
                }
                return this.$initGremlinSession();
            } // checkUp is necessary here to trigger authentication
        }).then(() => this.$checkUp()
            .then(() => this.$getVersion()));
    }
    /**
     * Connect to the gremlin server.
     *
     * @returns {Bluebird<void>}
     * @private
     */
    _connectGremlinServer() {
        if (this._connected) {
            return Promise.resolve();
        }
        return new Promise((resolve, reject) => {
            const configuredUrl = /**@type {string}*/ this.getGraphOption('url');
            const { scheme, host = 'localhost', port = 8182 } = Utils.extractHostPort(configuredUrl);
            // connect to the gremlin server via WebSocket
            const ssl = scheme === 'wss' || scheme === 'https';
            const url = `ws${ssl ? 's' : ''}://${host}:${port}${this._httpPathGremlinServer}`;
            const wsOptions = {
                rejectUnauthorized: !this.getGraphOption('allowSelfSigned', false),
                handshakeTimeout: 60 * 1000 // drop handshake request after 60 secs
            };
            this._ws = new WebSocket(url, null, wsOptions)
                .once('open', resolve)
                .once('error', reject)
                .on('open', () => (this._connected = true))
                .on('error', error => Log.error('Gremlin server communication error', error))
                .on('message', message => this._handleProtocolMessage(message))
                .on('close', () => {
                this.$closeConnection(Errors.technical('critical', 'WebSocket closed')).catch(error => {
                    Log.error(error.message);
                });
            });
        });
    }
    /**
     * @param {string} message
     * @private
     */
    _handleProtocolMessage(message) {
        let rawMessage, requestId, statusCode;
        try {
            rawMessage = this._binaryMessages
                ? JSON.parse(Buffer.from(message, 'binary').toString('utf-8'))
                : JSON.parse(message);
            requestId = rawMessage.requestId;
            statusCode = rawMessage.status.code;
        }
        catch (e) {
            Log.warn('MalformedResponse', 'Received malformed response message: ' + message);
            return;
        }
        const request = this._pendingRequests.get(requestId);
        // If there was no request for this response, just ignore the response
        if (Utils.noValue(request)) {
            return;
        }
        switch (statusCode) {
            case 200: // SUCCESS
                this._pendingRequests.delete(requestId);
                request.responseStream.push(rawMessage.result.data['@value'] || rawMessage.result.data);
                request.responseStream.push(null);
                break;
            case 204: // NO_CONTENT
                this._pendingRequests.delete(requestId);
                request.responseStream.push(null);
                break;
            case 206: // PARTIAL_CONTENT
                request.responseStream.push(rawMessage.result.data['@value'] || rawMessage.result.data);
                if (this.useSessions) {
                    // allow long running requests to have less concurrency
                    this._activeSessions.touch(request.message.args.session);
                }
                break;
            case 407: // AUTHENTICATE CHALLENGE
                this._sendMessage({
                    requestId: requestId,
                    processor: this._pendingRequests.get(requestId).message.processor,
                    op: 'authentication',
                    args: { saslMechanism: 'PLAIN',
                        sasl: GremlinUtils.encodeSASLCredentials(this.$username, this.$password) }
                });
                break;
            default: {
                // Other status codes (498, 499, 500, 597, 598, 599) are all errors
                this._handleProtocolError(request, rawMessage.status);
                break;
            }
        }
    }
    /**
     * @param {GremlinRequest} request
     * @param {object}         status
     * @param {string | null}  status.message
     * @param {number}         status.code
     * @param {object}         status.attributes
     * @param {string}         [status.attributes.stackTrace]
     * @param {string}         [status.attributes.exceptions]
     * @private
     */
    _handleProtocolError(request, status) {
        const { code, message, attributes } = status;
        this._pendingRequests.delete(request.message.requestId);
        const queryFailed = request.message.args.gremlin;
        const timeout = request.message.args.scriptEvaluationTimeout;
        const errorMessage = message + '\nQuery was: ' + queryFailed + '\nError code: ' + code;
        let error;
        if (code === 597) { // SCRIPT EVALUATION ERROR
            // detect session expired
            const { exceptions = [], stackTrace } = attributes;
            // the best clue that a session expired is when a commit query fails (done before every query)
            // with a null pointer exception. This means that `graph` is no longer defined in the session
            const sessionExpired = queryFailed === COMMIT_QUERY &&
                _.includes(exceptions, 'java.lang.NullPointerException');
            if (sessionExpired) {
                this.$closeConnection(new TechnicalError('critical', `Gremlin session expired ${message} ${stackTrace}`)).catch(error => {
                    Log.error(error.message);
                });
                return;
            }
            // If the session didn't expire then it's just a bad query
            error = Errors.business('bad_graph_request', 'Gremlin server error: ' + errorMessage);
        }
        else if (code === 401) { // UNAUTHORIZED
            error = Errors.business('invalid_parameter', 'Authentication failed, ' +
                'Please check the username and password in the configuration.');
        }
        else if (code === 598) { // SERVER TIMEOUT
            if (timeout === undefined) {
                error = new GraphRequestTimeout(Vendor.GREMLIN_SERVER);
            }
            else {
                // the scriptEvaluation timeout is set by Linkurious based on the rawQueryTimeout configuration parameter
                error = new GraphRequestTimeout(Vendor.LINKURIOUS);
            }
        }
        else {
            // All other errors are technical
            // 498 MALFORMED REQUEST
            // 499 INVALID REQUEST ARGUMENTS
            // 500 SERVER ERROR
            // 599 SERVER SERIALIZATION ERROR
            // see http://tinkerpop.apache.org/docs/current/dev/provider/#_graph_driver_provider_requirements
            error = new TechnicalError('critical', 'Gremlin server error: ' + errorMessage);
        }
        request.responseStream.emit('error', error);
    }
    /**
     * @param {string}                    script
     * @param {GremlinOperationArguments} args
     * @returns {GremlinRequest}
     */
    $buildGremlinRequest(script, args) {
        const gremlinMessage = {
            // V4 is a random id
            requestId: uuid.v4(),
            processor: Utils.hasValue(args.session) ? 'session' : '',
            op: 'eval',
            args: _.merge({
                gremlin: script,
                bindings: {},
                manageTransaction: this._manageTransactions,
                aliases: this._aliases,
                accept: 'application/json',
                language: 'gremlin-groovy'
            }, args)
        };
        return {
            message: gremlinMessage,
            responseStream: new stream.PassThrough({ objectMode: true })
        };
    }
    /**
     * @param {GremlinRequest} request
     * @returns {Bluebrid<ReadableStream>}
     */
    $sendRequest(request) {
        this._pendingRequests.set(request.message.requestId, request);
        return this._sendMessage(request.message)
            .return(request.responseStream)
            .catch(error => {
            this._pendingRequests.delete(request.message.requestId);
            throw error;
        });
    }
    /**
     * @param {GremlinMessage} message
     * @returns {Bluebrid<void>}
     * @private
     */
    _sendMessage(message) {
        return new Promise((resolve, reject) => {
            const formattedMessage = this._binaryMessages ? GremlinUtils.toBinary(message) : message;
            this._ws.send(formattedMessage, { binary: Boolean(this._binaryMessages) }, error => {
                // this callback the only way of being notified that data has actually been sent
                // if `error` is defined, then we have failed to send the message
                if (Utils.hasValue(error)) {
                    reject(error);
                }
                else {
                    resolve();
                }
            });
        });
    }
    /**
     * Disconnect from the gremlin server.
     *
     * @param {Error} [reason]
     * @returns {Bluebird<void>}
     */
    $closeConnection(reason) {
        // release the client
        return Promise.resolve().then(() => {
            if (this._connected) {
                this._connected = false;
                this._cancelPendingRequests(reason);
                return this._closeSessions().catch(error => {
                    Log.error('Failed to close opened sessions', error.stack || error);
                    // Always resolve because gremlin server might not be reachable.
                }).then(() => {
                    // close the WebSocket
                    try {
                        this._ws.close();
                    }
                    catch (e) {
                        // do nothing
                    }
                });
            }
        }).then(() => {
            if (Utils.hasValue(reason)) {
                // fail properly
                return Errors.technical('critical', `Cannot connect to the gremlin server (${this.getGraphOption('url')}): ` +
                    reason.message, true);
            }
        });
    }
    /**
     * Disconnect from the remote server.
     *
     * Optional to implement.
     */
    $disconnect() {
        this.$closeConnection();
    }
    /**
     * Add definitions in the gremlin session and/or perform additional checks.
     *
     * Implement only if gremlinOptions.useSessions is true.
     *
     * @returns {Bluebird<void>}
     */
    $initGremlinSession() {
        return Utils.NOT_IMPLEMENTED();
    }
    /**
     * Close active response streams.
     *
     * @param {Error} [reason]
     * @private
     */
    _cancelPendingRequests(reason) {
        for (const request of this._pendingRequests.values()) {
            request.responseStream.destroy(reason);
        }
    }
    /**
     * Close open gremlin sessions if any.
     *
     * @returns {Bluebird<void>}
     * @private
     */
    _closeSessions() {
        return Promise.resolve().then(() => {
            const closingSessions = [];
            for (const session of this._activeSessions) {
                closingSessions.push(this._closeSession(session));
            }
            return Promise.all(closingSessions).return();
        });
    }
    /**
     * Send close session request.
     *
     * @param {string} sessionId
     * @returns {Bluebird<void>}
     * @private
     */
    _closeSession(sessionId) {
        const message = {
            requestId: uuid.v4(),
            processor: 'session',
            op: 'close',
            args: {
                session: sessionId,
                // the force close option force: true will not wait for pending transaction to complete
                // resulting in a faster release of resources
                force: true
            }
        };
        const request = {
            message: message,
            responseStream: new stream.PassThrough({ objectMode: true })
        };
        return this.$sendRequest(request).then(messageStream => {
            return Utils.collectStream(messageStream).then(() => {
                this._activeSessions.delete(sessionId);
                this._lastCommit.delete(sessionId);
            });
        });
    }
    /**
     * Check if the remote server is alive.
     *
     * @returns {Bluebird<void>}
     */
    $checkUp() {
        // Gremlin sessions need to be periodically checked because they expire after 8 hours (default config)
        let sessions = 'none';
        if (this.useSessions) {
            const now = Date.now();
            for (const [, commitTs] of this._lastCommit) {
                if ((now - commitTs) > SESSION_REFRESH_MS) {
                    sessions = 'all';
                    break;
                }
            }
        }
        return this.$doGremlinQuery('true', { session: sessions }).then(r => {
            if (!r.length || _.some(r, status => status !== true)) {
                return Errors.technical('graph_unreachable', 'Cannot connect to the gremlin server.', true);
            }
        }).catch(error => {
            // if the checkup failed, reset the client
            return this.$closeConnection(error);
        });
    }
    /**
     * Detect the current store ID.
     *
     * A store ID is an identifier of the database as specific as possible.
     * It should contains the address (url and port) of the database and, if the service
     * is multi-tenant, the name of the database.
     *
     * @returns {Bluebird<string>}
     */
    $getStoreId() {
        return Utils.NOT_IMPLEMENTED();
    }
    /**
     * Data that the connector will pass to the driver.
     *
     * @returns {Bluebird<any>}
     */
    $getConnectorData() {
        return Promise.resolve({});
    }
    /**
     * Get the SemVer of the remote server.
     *
     * @returns {Bluebird<string>} resolved with the SemVer version of the remote server
     */
    $getVersion() {
        return Utils.NOT_IMPLEMENTED();
    }
    /**
     * @param {object} aliases
     */
    $setAliases(aliases) {
        this._aliases = aliases;
    }
    /**
     * Attach a transaction commit before or after the query if necessary.
     * Also identifies:
     * - updatedSessions: Sessions known to have updated data.
     * - outdatedSessions: Sessions known to have stale data.
     *
     * @param {number}                    t0            request timestamp
     * @param {string}                    query
     * @param {GremlinOperationArguments} args
     * @param {object}                    [commitStrategy]         How to manage the current transaction
     * @param {boolean}                   [commitStrategy.before]  Commit before executing the query
     * @param {boolean}                   [commitStrategy.after]   Commit after the query is executed
     *
     * @returns {GremlinTransaction}
     * @private
     */
    _buildTransaction(t0, query, args, commitStrategy = {}) {
        const transaction = {
            requests: [],
            outdatedSessions: [],
            updatedSessions: []
        };
        if (commitStrategy.before) {
            // Check last commit for read queries
            if ((t0 - this._lastCommit.get(args.session)) > this._maxStale) {
                transaction.requests.push(this.$buildGremlinRequest(COMMIT_QUERY, args));
                transaction.updatedSessions.push(args.session);
            }
        }
        transaction.requests.push(this.$buildGremlinRequest(query, args));
        if (commitStrategy.after) {
            transaction.requests.push(this.$buildGremlinRequest(COMMIT_QUERY, args));
            // Write queries are committed after the query is successful
            // That means all other sessions will have stale data.
            for (const session of this._activeSessions) {
                // Invalidate all other sessions
                if (args.session !== session) {
                    transaction.outdatedSessions.push(session);
                }
            }
            // Update current session
            transaction.updatedSessions.push(args.session);
        }
        return transaction;
    }
    /**
     * @param {number} t0            time of the request
     * @param {GremlinTransaction[]} transactions
     * @private
     */
    _updatedSessionsStatus(t0, transactions) {
        const outdatedSessions = _.uniq(_.flatMap(transactions, 'outdatedSessions'));
        const updatedSessions = _.uniq(_.flatMap(transactions, 'updatedSessions'));
        for (const session of updatedSessions) {
            this._lastCommit.set(session, t0);
        }
        for (const session of outdatedSessions) {
            this._lastCommit.set(session, -Infinity);
        }
    }
    /**
     * Execute a gremlin query.
     *
     * @param {string}              query
     * @param {GremlinQueryOptions} [options]
     * @returns {Bluebird<any>}
     */
    $doGremlinQuery(query, options = {}) {
        const { timeout, allowForbiddenStatements, autoCommit = true } = options;
        const t0 = Date.now();
        if (!this._connected) {
            return Errors.technical('graph_unreachable', 'Cannot connect to the gremlin server.', true);
        }
        // TODO #919 Improve Gremlin read-only raw query check
        const willWrite = GremlinUtils.checkQuery(query, allowForbiddenStatements);
        const session = this._useSessions ? options.session || 'any' : 'none';
        // use the appropriate caching policy to reduce scripts memory footprint
        // see http://tinkerpop.apache.org/docs/current/reference/#_cache_management
        const scriptCachePolicy = Utils.hasValue(options.caching)
            ? { '#jsr223.groovy.engine.keep.globals': options.caching }
            : {};
        const args = {
            scriptEvaluationTimeout: timeout,
            bindings: _.defaults(scriptCachePolicy, options.bindings)
        };
        const transactions = [];
        if (session === 'none') {
            // transactions are managed for session less requests : 1 request = 1 transaction
            // A transaction is started when the script is first evaluated
            // and is committed automatically when the script completes.
            transactions.push(this._buildTransaction(t0, query, args));
        }
        else {
            const targetSessions = session === 'all'
                ? this._activeSessions.values()
                : session === 'any' ? [this._activeSessions.next()] : [this._activeSessions.touch(session)];
            // Commit the transaction if transactions are not managed directly by the graph vendor.
            // We commit before every query and after every write query
            // to make sure the graph data is up to date
            const commitStrategy = {
                before: autoCommit && !this._manageTransactions,
                // Commit all write queries after the query completed successfully
                after: autoCommit && !this._manageTransactions && willWrite
            };
            for (const sessionId of targetSessions) {
                args.session = sessionId;
                transactions.push(this._buildTransaction(t0, query, args, commitStrategy));
            }
        }
        const requests = _.flatMap(transactions, 'requests');
        // Queries should be executed sequentially and in order.
        return Promise.mapSeries(requests, r => {
            return this.$sendRequest(r).then(messageStream => {
                return Utils.collectStream(messageStream).then(_.flatten);
            });
        }).then(responses => {
            this._updatedSessionsStatus(t0, transactions);
            // The commit request will return empty results
            // We do not want that in the response
            // flatten will discard empty arrays.
            return _.flatten(responses);
        }).finally(() => Utils.logSlow(t0, this.SLOW_QUERY_THRESHOLD, 'Query (WS): ' + query, Log));
    }
    /**
     * Stream gremlin query results.
     *
     * Valid only if `gremlinOptions.useSessions` is true.
     *
     * @param {string}  query
     * @param {object}  [options]
     * @param {object}  [options.bindings]                      Gremlin Variable bindings
     * @param {number}  [options.batchSize=1]                   Number of results to read from the gremlin server at a time
     * @param {number}  [options.timeout]                       Milliseconds to wait before it fails
     * @param {boolean} [options.allowForbiddenStatements=true] Whether the query can use forbidden statements
     * @param {boolean} [options.useDef]                        Whether to use def keyword to declare session variables
     * @returns {Bluebird<Readable<any>>}
     */
    $streamGremlinQuery(query, options = {}) {
        const { batchSize = 1 } = options;
        // V4 is a random uuid, allows streaming multiple raw queries in the same session
        const streamUid = `LK_${uuid.v4().split('-')[0]}`;
        const setupQuery = `${options.useDef ? 'def ' : ''}${streamUid} = ${query}`;
        const cleanupQuery = `${streamUid} = []`;
        const hasNextQuery = `${streamUid}.hasNext()`;
        const nextQuery = `${streamUid}.next(${batchSize})`;
        const sessionId = this._activeSessions.next();
        let initialised = false;
        const fetchNextPage = () => {
            const usedSession = this._activeSessions.touch(sessionId);
            if (!initialised) {
                initialised = true;
                return this.$doGremlinQuery(`${setupQuery}; ${hasNextQuery} ? ${nextQuery} : []`, {
                    timeout: options.timeout,
                    allowForbiddenStatements: options.allowForbiddenStatements,
                    session: usedSession,
                    caching: 'phantom',
                    bindings: options.bindings
                });
            }
            return this.$doGremlinQuery(`${hasNextQuery} ? ${nextQuery} : (${cleanupQuery})`, {
                timeout: options.timeout,
                session: usedSession,
                autoCommit: false,
                caching: 'weak'
            });
        };
        const cleanup = () => {
            const usedSession = this._activeSessions.touch(sessionId);
            // Cleanup is necessary on abort
            return this.$doGremlinQuery(cleanupQuery, {
                session: usedSession,
                caching: 'phantom'
            });
        };
        return Promise.resolve(new GremlinStream(fetchNextPage, cleanup));
    }
}
module.exports = GremlinConnector;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JlbWxpbkNvbm5lY3Rvci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9kYW8vY29ubmVjdG9yL2dyZW1saW5Db25uZWN0b3IuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFFSCxZQUFZLENBQUM7QUFDYixNQUFNLE1BQU0sR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDakMsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNwQyxNQUFNLFNBQVMsR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDaEMsTUFBTSxJQUFJLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQzdCLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0FBQ3RDLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxHQUFHLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUN0QyxNQUFNLEVBQUUsU0FBUyxFQUFFLEdBQUcsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDO0FBQzdDLE1BQU0sWUFBWSxHQUFHLE9BQU8sQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO0FBQ3RELE1BQU0sUUFBUSxHQUFHLE9BQU8sQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO0FBQ2xELE1BQU0sYUFBYSxHQUFHLE9BQU8sQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO0FBQ3hELE1BQU0sRUFBQyxtQkFBbUIsRUFBRSxNQUFNLEVBQUMsR0FBRyxPQUFPLENBQUMseUNBQXlDLENBQUMsQ0FBQztBQUN6RixNQUFNLEVBQUMsY0FBYyxFQUFDLEdBQUcsT0FBTyxDQUFDLG9DQUFvQyxDQUFDLENBQUM7QUFFdkUsTUFBTSx5QkFBeUIsR0FBRyxDQUFDLENBQUM7QUFFcEMsTUFBTSxrQkFBa0IsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQyxDQUFDLGFBQWE7QUFFeEQsTUFBTSxZQUFZLEdBQUcseUJBQXlCLENBQUM7QUFFL0MsTUFBTSxnQkFBaUIsU0FBUSxTQUFTO0lBRXRDOzs7Ozs7OztPQVFHO0lBQ0gsWUFBWSxZQUFZLEVBQUUsWUFBWSxFQUFFLGNBQWM7UUFDcEQsS0FBSyxDQUFDLFlBQVksRUFBRSxZQUFZLENBQUMsQ0FBQztRQUVsQyxJQUFJLENBQUMsbUJBQW1CLEdBQUcsY0FBYyxDQUFDLGtCQUFrQixDQUFDO1FBQzdELElBQUksQ0FBQyxzQkFBc0IsR0FBRyxjQUFjLENBQUMscUJBQXFCLENBQUM7UUFDbkUsSUFBSSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUM7UUFDbkIsSUFBSSxDQUFDLGVBQWUsR0FBRyxjQUFjLENBQUMsY0FBYyxDQUFDO1FBQ3JELElBQUksQ0FBQyxZQUFZLEdBQUcsY0FBYyxDQUFDLFdBQVcsQ0FBQztRQUMvQyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQztRQUNsQyxJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztRQUN4QixJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksUUFBUSxFQUFFLENBQUM7UUFDdEMsNkRBQTZEO1FBQzdELGdEQUFnRDtRQUNoRCxxRUFBcUU7UUFDckUsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUNwRCxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7UUFDN0IsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsZ0RBQWdEO0lBQ2hHLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsSUFBSSxlQUFlO1FBQ2pCLElBQUksSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNqQix3Q0FBd0M7WUFDeEMscUZBQXFGO1lBQ3JGLE9BQU8sQ0FBQyxDQUFDO1NBQ1Y7UUFDRCxPQUFPLElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxFQUFFLHlCQUF5QixDQUFDLENBQUM7SUFDdkUsQ0FBQztJQUVEOzs7T0FHRztJQUNILElBQUksV0FBVztRQUNiLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQztJQUMzQixDQUFDO0lBRUQ7O09BRUc7SUFDSCxJQUFJLFNBQVM7UUFDWCxPQUFPLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUM7SUFFckMsQ0FBQztJQUVEOztPQUVHO0lBQ0gsSUFBSSxTQUFTO1FBQ1gsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsUUFBUTtRQUNOLE9BQU8sSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUM1Qyw2Q0FBNkM7WUFDN0MsSUFBSSxJQUFJLENBQUMsWUFBWSxFQUFFO2dCQUNyQiwrQkFBK0I7Z0JBQy9CLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsRUFBRSxFQUFFO29CQUM3QyxNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsRUFBRSxFQUFFLENBQUM7b0JBQzVCLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDO29CQUNwQyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUM7aUJBQ3BDO2dCQUVELE9BQU8sSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUM7YUFDbkMsQ0FBQyxzREFBc0Q7UUFDMUQsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUU7YUFDMUIsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFDckMsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gscUJBQXFCO1FBQ25CLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtZQUNuQixPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQztTQUMxQjtRQUVELE9BQU8sSUFBSSxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDckMsTUFBTSxhQUFhLEdBQUcsbUJBQW1CLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNyRSxNQUFNLEVBQUMsTUFBTSxFQUFFLElBQUksR0FBRyxXQUFXLEVBQUUsSUFBSSxHQUFHLElBQUksRUFBQyxHQUFHLEtBQUssQ0FBQyxlQUFlLENBQUMsYUFBYSxDQUFDLENBQUM7WUFFdkYsOENBQThDO1lBQzlDLE1BQU0sR0FBRyxHQUFHLE1BQU0sS0FBSyxLQUFLLElBQUksTUFBTSxLQUFLLE9BQU8sQ0FBQztZQUNuRCxNQUFNLEdBQUcsR0FBRyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLE1BQU0sSUFBSSxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztZQUNsRixNQUFNLFNBQVMsR0FBRztnQkFDaEIsa0JBQWtCLEVBQUUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLGlCQUFpQixFQUFFLEtBQUssQ0FBQztnQkFDbEUsZ0JBQWdCLEVBQUUsRUFBRSxHQUFHLElBQUksQ0FBQyx1Q0FBdUM7YUFDcEUsQ0FBQztZQUNGLElBQUksQ0FBQyxHQUFHLEdBQUcsSUFBSSxTQUFTLENBQUMsR0FBRyxFQUFFLElBQUksRUFBRSxTQUFTLENBQUM7aUJBQzNDLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDO2lCQUNyQixJQUFJLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQztpQkFDckIsRUFBRSxDQUFDLE1BQU0sRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLENBQUM7aUJBQzFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLG9DQUFvQyxFQUFFLEtBQUssQ0FBQyxDQUFDO2lCQUM1RSxFQUFFLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLHNCQUFzQixDQUFDLE9BQU8sQ0FBQyxDQUFDO2lCQUM5RCxFQUFFLENBQUMsT0FBTyxFQUFFLEdBQUcsRUFBRTtnQkFDaEIsSUFBSSxDQUFDLGdCQUFnQixDQUNuQixNQUFNLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxrQkFBa0IsQ0FBQyxDQUNqRCxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRTtvQkFDZCxHQUFHLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDM0IsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7T0FHRztJQUNILHNCQUFzQixDQUFDLE9BQU87UUFDNUIsSUFBSSxVQUFVLEVBQUUsU0FBUyxFQUFFLFVBQVUsQ0FBQztRQUN0QyxJQUFJO1lBQ0YsVUFBVSxHQUFHLElBQUksQ0FBQyxlQUFlO2dCQUMvQixDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxRQUFRLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQzlELENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ3hCLFNBQVMsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDO1lBQ2pDLFVBQVUsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztTQUNyQztRQUFDLE9BQU0sQ0FBQyxFQUFFO1lBQ1QsR0FBRyxDQUFDLElBQUksQ0FBQyxtQkFBbUIsRUFBRSx1Q0FBdUMsR0FBRyxPQUFPLENBQUMsQ0FBQztZQUNqRixPQUFPO1NBQ1I7UUFFRCxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBRXJELHNFQUFzRTtRQUN0RSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDMUIsT0FBTztTQUNSO1FBRUQsUUFBUSxVQUFVLEVBQUU7WUFDbEIsS0FBSyxHQUFHLEVBQUUsVUFBVTtnQkFDbEIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQztnQkFDeEMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDeEYsT0FBTyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ2xDLE1BQU07WUFDUixLQUFLLEdBQUcsRUFBRSxhQUFhO2dCQUNyQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO2dCQUN4QyxPQUFPLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDbEMsTUFBTTtZQUNSLEtBQUssR0FBRyxFQUFFLGtCQUFrQjtnQkFDMUIsT0FBTyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDeEYsSUFBSSxJQUFJLENBQUMsV0FBVyxFQUFFO29CQUNwQix1REFBdUQ7b0JBQ3ZELElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2lCQUMxRDtnQkFDRCxNQUFNO1lBQ1IsS0FBSyxHQUFHLEVBQUUseUJBQXlCO2dCQUNqQyxJQUFJLENBQUMsWUFBWSxDQUFDO29CQUNoQixTQUFTLEVBQUUsU0FBUztvQkFDcEIsU0FBUyxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVM7b0JBQ2pFLEVBQUUsRUFBRSxnQkFBZ0I7b0JBQ3BCLElBQUksRUFBRSxFQUFFLGFBQWEsRUFBRSxPQUFPO3dCQUM1QixJQUFJLEVBQUUsWUFBWSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFDO2lCQUM1RSxDQUFDLENBQUM7Z0JBQ0gsTUFBTTtZQUNSLE9BQU8sQ0FBQyxDQUFDO2dCQUNQLG1FQUFtRTtnQkFDbkUsSUFBSSxDQUFDLG9CQUFvQixDQUFDLE9BQU8sRUFBRSxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQ3RELE1BQU07YUFDUDtTQUNGO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7Ozs7T0FTRztJQUNILG9CQUFvQixDQUFDLE9BQU8sRUFBRSxNQUFNO1FBQ2xDLE1BQU0sRUFBQyxJQUFJLEVBQUUsT0FBTyxFQUFFLFVBQVUsRUFBQyxHQUFHLE1BQU0sQ0FBQztRQUMzQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDeEQsTUFBTSxXQUFXLEdBQUcsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO1FBQ2pELE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDO1FBQzdELE1BQU0sWUFBWSxHQUFHLE9BQU8sR0FBRyxlQUFlLEdBQUcsV0FBVyxHQUFHLGdCQUFnQixHQUFHLElBQUksQ0FBQztRQUV2RixJQUFJLEtBQUssQ0FBQztRQUVWLElBQUksSUFBSSxLQUFLLEdBQUcsRUFBRSxFQUFFLDBCQUEwQjtZQUM1Qyx5QkFBeUI7WUFDekIsTUFBTSxFQUFDLFVBQVUsR0FBRyxFQUFFLEVBQUUsVUFBVSxFQUFDLEdBQUcsVUFBVSxDQUFDO1lBQ2pELDhGQUE4RjtZQUM5Riw2RkFBNkY7WUFDN0YsTUFBTSxjQUFjLEdBQUcsV0FBVyxLQUFLLFlBQVk7Z0JBQ2pELENBQUMsQ0FBQyxRQUFRLENBQUMsVUFBVSxFQUFFLGdDQUFnQyxDQUFDLENBQUM7WUFFM0QsSUFBSSxjQUFjLEVBQUU7Z0JBQ2xCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLGNBQWMsQ0FBQyxVQUFVLEVBQ2pELDJCQUEyQixPQUFPLElBQUksVUFBVSxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRTtvQkFDbkUsR0FBRyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQzNCLENBQUMsQ0FBQyxDQUFDO2dCQUNILE9BQU87YUFDUjtZQUVELDBEQUEwRDtZQUMxRCxLQUFLLEdBQUcsTUFBTSxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsRUFBRSx3QkFBd0IsR0FBRyxZQUFZLENBQUMsQ0FBQztTQUN2RjthQUFNLElBQUksSUFBSSxLQUFLLEdBQUcsRUFBRSxFQUFFLGVBQWU7WUFDeEMsS0FBSyxHQUFHLE1BQU0sQ0FBQyxRQUFRLENBQUMsbUJBQW1CLEVBQ3pDLHlCQUF5QjtnQkFDekIsOERBQThELENBQy9ELENBQUM7U0FDSDthQUFNLElBQUksSUFBSSxLQUFLLEdBQUcsRUFBRSxFQUFFLGlCQUFpQjtZQUMxQyxJQUFJLE9BQU8sS0FBSyxTQUFTLEVBQUU7Z0JBQ3pCLEtBQUssR0FBRyxJQUFJLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsQ0FBQzthQUN4RDtpQkFBTTtnQkFDTCx5R0FBeUc7Z0JBQ3pHLEtBQUssR0FBRyxJQUFJLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQzthQUNwRDtTQUNGO2FBQU07WUFDTCxpQ0FBaUM7WUFDakMsd0JBQXdCO1lBQ3hCLGdDQUFnQztZQUNoQyxtQkFBbUI7WUFDbkIsaUNBQWlDO1lBQ2pDLGlHQUFpRztZQUNqRyxLQUFLLEdBQUcsSUFBSSxjQUFjLENBQUMsVUFBVSxFQUFFLHdCQUF3QixHQUFHLFlBQVksQ0FBQyxDQUFDO1NBQ2pGO1FBRUQsT0FBTyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzlDLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsb0JBQW9CLENBQUMsTUFBTSxFQUFFLElBQUk7UUFDL0IsTUFBTSxjQUFjLEdBQUc7WUFDckIsb0JBQW9CO1lBQ3BCLFNBQVMsRUFBRSxJQUFJLENBQUMsRUFBRSxFQUFFO1lBQ3BCLFNBQVMsRUFBRSxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFO1lBQ3hELEVBQUUsRUFBRSxNQUFNO1lBQ1YsSUFBSSxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUM7Z0JBQ1osT0FBTyxFQUFFLE1BQU07Z0JBQ2YsUUFBUSxFQUFFLEVBQUU7Z0JBQ1osaUJBQWlCLEVBQUUsSUFBSSxDQUFDLG1CQUFtQjtnQkFDM0MsT0FBTyxFQUFFLElBQUksQ0FBQyxRQUFRO2dCQUN0QixNQUFNLEVBQUUsa0JBQWtCO2dCQUMxQixRQUFRLEVBQUUsZ0JBQWdCO2FBQzNCLEVBQUUsSUFBSSxDQUFDO1NBQ1QsQ0FBQztRQUVGLE9BQU87WUFDTCxPQUFPLEVBQUUsY0FBYztZQUN2QixjQUFjLEVBQUUsSUFBSSxNQUFNLENBQUMsV0FBVyxDQUFDLEVBQUMsVUFBVSxFQUFFLElBQUksRUFBQyxDQUFDO1NBQzNELENBQUM7SUFDSixDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsWUFBWSxDQUFDLE9BQU87UUFDbEIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUM5RCxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQzthQUN0QyxNQUFNLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQzthQUM5QixLQUFLLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDYixJQUFJLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDeEQsTUFBTSxLQUFLLENBQUM7UUFDZCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsWUFBWSxDQUFDLE9BQU87UUFDbEIsT0FBTyxJQUFJLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsRUFBRTtZQUNyQyxNQUFNLGdCQUFnQixHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztZQUN6RixJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxFQUFFLE1BQU0sRUFBRSxPQUFPLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxFQUFFLEVBQUUsS0FBSyxDQUFDLEVBQUU7Z0JBQ2pGLGdGQUFnRjtnQkFDaEYsaUVBQWlFO2dCQUNqRSxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLEVBQUU7b0JBQ3pCLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztpQkFDZjtxQkFBTTtvQkFDTCxPQUFPLEVBQUUsQ0FBQztpQkFDWDtZQUNILENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxnQkFBZ0IsQ0FBQyxNQUFNO1FBQ3JCLHFCQUFxQjtRQUNyQixPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ2pDLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtnQkFDbkIsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7Z0JBQ3hCLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDcEMsT0FBTyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFO29CQUN6QyxHQUFHLENBQUMsS0FBSyxDQUFDLGlDQUFpQyxFQUFFLEtBQUssQ0FBQyxLQUFLLElBQUksS0FBSyxDQUFDLENBQUM7b0JBQ25FLGdFQUFnRTtnQkFDbEUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtvQkFDWCxzQkFBc0I7b0JBQ3RCLElBQUk7d0JBQ0YsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsQ0FBQztxQkFDbEI7b0JBQUMsT0FBTSxDQUFDLEVBQUU7d0JBQ1QsYUFBYTtxQkFDZDtnQkFDSCxDQUFDLENBQUMsQ0FBQzthQUNKO1FBQ0gsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNYLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRTtnQkFDMUIsZ0JBQWdCO2dCQUNoQixPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQ3JCLFVBQVUsRUFDVix5Q0FBeUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsS0FBSztvQkFDeEUsTUFBTSxDQUFDLE9BQU8sRUFDZCxJQUFJLENBQUMsQ0FBQzthQUNUO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFFTCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILFdBQVc7UUFDVCxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsbUJBQW1CO1FBQ2pCLE9BQU8sS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQ2pDLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILHNCQUFzQixDQUFDLE1BQU07UUFDM0IsS0FBSyxNQUFNLE9BQU8sSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxFQUFFLEVBQUU7WUFDcEQsT0FBTyxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDeEM7SUFDSCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxjQUFjO1FBQ1osT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNqQyxNQUFNLGVBQWUsR0FBRyxFQUFFLENBQUM7WUFFM0IsS0FBSyxNQUFNLE9BQU8sSUFBSSxJQUFJLENBQUMsZUFBZSxFQUFFO2dCQUMxQyxlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQzthQUNuRDtZQUVELE9BQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUMvQyxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxhQUFhLENBQUMsU0FBUztRQUNyQixNQUFNLE9BQU8sR0FBRztZQUNkLFNBQVMsRUFBRSxJQUFJLENBQUMsRUFBRSxFQUFFO1lBQ3BCLFNBQVMsRUFBRSxTQUFTO1lBQ3BCLEVBQUUsRUFBRSxPQUFPO1lBQ1gsSUFBSSxFQUFFO2dCQUNKLE9BQU8sRUFBRSxTQUFTO2dCQUNsQix1RkFBdUY7Z0JBQ3ZGLDZDQUE2QztnQkFDN0MsS0FBSyxFQUFFLElBQUk7YUFDWjtTQUNGLENBQUM7UUFFRixNQUFNLE9BQU8sR0FBRztZQUNkLE9BQU8sRUFBRSxPQUFPO1lBQ2hCLGNBQWMsRUFBRSxJQUFJLE1BQU0sQ0FBQyxXQUFXLENBQUMsRUFBQyxVQUFVLEVBQUUsSUFBSSxFQUFDLENBQUM7U0FDM0QsQ0FBQztRQUVGLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUU7WUFDckQsT0FBTyxLQUFLLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ2xELElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO2dCQUN2QyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUNyQyxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBRUwsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxRQUFRO1FBQ04sc0dBQXNHO1FBQ3RHLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQztRQUN0QixJQUFJLElBQUksQ0FBQyxXQUFXLEVBQUU7WUFDcEIsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQ3ZCLEtBQUssTUFBTSxDQUFDLEVBQUUsUUFBUSxDQUFDLElBQUksSUFBSSxDQUFDLFdBQVcsRUFBRTtnQkFDM0MsSUFBSSxDQUFDLEdBQUcsR0FBRyxRQUFRLENBQUMsR0FBRyxrQkFBa0IsRUFBRTtvQkFDekMsUUFBUSxHQUFHLEtBQUssQ0FBQztvQkFDakIsTUFBTTtpQkFDUDthQUNGO1NBQ0Y7UUFDRCxPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxFQUFFLEVBQUMsT0FBTyxFQUFFLFFBQVEsRUFBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFO1lBQ2hFLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxFQUFFLENBQUMsTUFBTSxLQUFLLElBQUksQ0FBQyxFQUFFO2dCQUNyRCxPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQUMsbUJBQW1CLEVBQUUsdUNBQXVDLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDN0Y7UUFDSCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDZiwwQ0FBMEM7WUFDMUMsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDdEMsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSCxXQUFXO1FBQ1QsT0FBTyxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDakMsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxpQkFBaUI7UUFDZixPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDN0IsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxXQUFXO1FBQ1QsT0FBTyxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDakMsQ0FBQztJQUVEOztPQUVHO0lBQ0gsV0FBVyxDQUFDLE9BQU87UUFDakIsSUFBSSxDQUFDLFFBQVEsR0FBRyxPQUFPLENBQUM7SUFDMUIsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7Ozs7T0FlRztJQUNILGlCQUFpQixDQUFDLEVBQUUsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLGNBQWMsR0FBRyxFQUFFO1FBQ3BELE1BQU0sV0FBVyxHQUFHO1lBQ2xCLFFBQVEsRUFBRSxFQUFFO1lBQ1osZ0JBQWdCLEVBQUUsRUFBRTtZQUNwQixlQUFlLEVBQUUsRUFBRTtTQUNwQixDQUFDO1FBRUYsSUFBSSxjQUFjLENBQUMsTUFBTSxFQUFFO1lBQ3pCLHFDQUFxQztZQUNyQyxJQUFJLENBQUMsRUFBRSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxTQUFTLEVBQUU7Z0JBQzlELFdBQVcsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFDekUsV0FBVyxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2FBQ2hEO1NBQ0Y7UUFFRCxXQUFXLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7UUFFbEUsSUFBSSxjQUFjLENBQUMsS0FBSyxFQUFFO1lBQ3hCLFdBQVcsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQztZQUN6RSw0REFBNEQ7WUFDNUQsc0RBQXNEO1lBQ3RELEtBQUssTUFBTSxPQUFPLElBQUksSUFBSSxDQUFDLGVBQWUsRUFBRTtnQkFDMUMsZ0NBQWdDO2dCQUNoQyxJQUFJLElBQUksQ0FBQyxPQUFPLEtBQUssT0FBTyxFQUFFO29CQUM1QixXQUFXLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2lCQUM1QzthQUNGO1lBQ0QseUJBQXlCO1lBQ3pCLFdBQVcsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztTQUNoRDtRQUVELE9BQU8sV0FBVyxDQUFDO0lBQ3JCLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsc0JBQXNCLENBQUMsRUFBRSxFQUFFLFlBQVk7UUFDckMsTUFBTSxnQkFBZ0IsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsWUFBWSxFQUFFLGtCQUFrQixDQUFDLENBQUMsQ0FBQztRQUM3RSxNQUFNLGVBQWUsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsWUFBWSxFQUFFLGlCQUFpQixDQUFDLENBQUMsQ0FBQztRQUMzRSxLQUFLLE1BQU0sT0FBTyxJQUFJLGVBQWUsRUFBRTtZQUNyQyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDLENBQUM7U0FDbkM7UUFDRCxLQUFLLE1BQU0sT0FBTyxJQUFJLGdCQUFnQixFQUFFO1lBQ3RDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1NBQzFDO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILGVBQWUsQ0FBQyxLQUFLLEVBQUUsT0FBTyxHQUFHLEVBQUU7UUFDakMsTUFBTSxFQUFDLE9BQU8sRUFBRSx3QkFBd0IsRUFBRSxVQUFVLEdBQUcsSUFBSSxFQUFDLEdBQUcsT0FBTyxDQUFDO1FBQ3ZFLE1BQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUN0QixJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRTtZQUNwQixPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQUMsbUJBQW1CLEVBQUUsdUNBQXVDLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDN0Y7UUFFRCxzREFBc0Q7UUFDdEQsTUFBTSxTQUFTLEdBQUcsWUFBWSxDQUFDLFVBQVUsQ0FBQyxLQUFLLEVBQUUsd0JBQXdCLENBQUMsQ0FBQztRQUUzRSxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO1FBRXRFLHdFQUF3RTtRQUN4RSw0RUFBNEU7UUFDNUUsTUFBTSxpQkFBaUIsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUM7WUFDdkQsQ0FBQyxDQUFDLEVBQUMsb0NBQW9DLEVBQUUsT0FBTyxDQUFDLE9BQU8sRUFBQztZQUN6RCxDQUFDLENBQUMsRUFBRSxDQUFDO1FBRVAsTUFBTSxJQUFJLEdBQUc7WUFDWCx1QkFBdUIsRUFBRSxPQUFPO1lBQ2hDLFFBQVEsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLGlCQUFpQixFQUFFLE9BQU8sQ0FBQyxRQUFRLENBQUM7U0FDMUQsQ0FBQztRQUVGLE1BQU0sWUFBWSxHQUFHLEVBQUUsQ0FBQztRQUN4QixJQUFJLE9BQU8sS0FBSyxNQUFNLEVBQUU7WUFDdEIsaUZBQWlGO1lBQ2pGLDhEQUE4RDtZQUM5RCw0REFBNEQ7WUFDNUQsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsRUFBRSxFQUFFLEtBQUssRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDO1NBQzVEO2FBQU07WUFDTCxNQUFNLGNBQWMsR0FBRyxPQUFPLEtBQUssS0FBSztnQkFDdEMsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxFQUFFO2dCQUMvQixDQUFDLENBQUMsT0FBTyxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztZQUU5Rix1RkFBdUY7WUFDdkYsMkRBQTJEO1lBQzNELDRDQUE0QztZQUM1QyxNQUFNLGNBQWMsR0FBRztnQkFDckIsTUFBTSxFQUFFLFVBQVUsSUFBSSxDQUFDLElBQUksQ0FBQyxtQkFBbUI7Z0JBQy9DLGtFQUFrRTtnQkFDbEUsS0FBSyxFQUFFLFVBQVUsSUFBSSxDQUFDLElBQUksQ0FBQyxtQkFBbUIsSUFBSSxTQUFTO2FBQzVELENBQUM7WUFFRixLQUFLLE1BQU0sU0FBUyxJQUFJLGNBQWMsRUFBRTtnQkFDdEMsSUFBSSxDQUFDLE9BQU8sR0FBRyxTQUFTLENBQUM7Z0JBQ3pCLFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEVBQUUsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLGNBQWMsQ0FBQyxDQUFDLENBQUM7YUFDNUU7U0FDRjtRQUVELE1BQU0sUUFBUSxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsWUFBWSxFQUFFLFVBQVUsQ0FBQyxDQUFDO1FBRXJELHdEQUF3RDtRQUN4RCxPQUFPLE9BQU8sQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQyxFQUFFO1lBQ3JDLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUU7Z0JBQy9DLE9BQU8sS0FBSyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQzVELENBQUMsQ0FBQyxDQUFDO1FBRUwsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQ2xCLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxFQUFFLEVBQUUsWUFBWSxDQUFDLENBQUM7WUFDOUMsK0NBQStDO1lBQy9DLHNDQUFzQztZQUN0QyxxQ0FBcUM7WUFDckMsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzlCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsb0JBQW9CLEVBQUUsY0FBYyxHQUFHLEtBQUssRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQzlGLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7OztPQWFHO0lBQ0gsbUJBQW1CLENBQUMsS0FBSyxFQUFFLE9BQU8sR0FBRyxFQUFFO1FBQ3JDLE1BQU0sRUFBQyxTQUFTLEdBQUcsQ0FBQyxFQUFDLEdBQUcsT0FBTyxDQUFDO1FBQ2hDLGlGQUFpRjtRQUNqRixNQUFNLFNBQVMsR0FBRyxNQUFNLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUNsRCxNQUFNLFVBQVUsR0FBRyxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLFNBQVMsTUFBTSxLQUFLLEVBQUUsQ0FBQztRQUM1RSxNQUFNLFlBQVksR0FBRyxHQUFHLFNBQVMsT0FBTyxDQUFDO1FBQ3pDLE1BQU0sWUFBWSxHQUFHLEdBQUcsU0FBUyxZQUFZLENBQUM7UUFDOUMsTUFBTSxTQUFTLEdBQUcsR0FBRyxTQUFTLFNBQVMsU0FBUyxHQUFHLENBQUM7UUFDcEQsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUM5QyxJQUFJLFdBQVcsR0FBRyxLQUFLLENBQUM7UUFFeEIsTUFBTSxhQUFhLEdBQUcsR0FBRyxFQUFFO1lBQ3pCLE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQzFELElBQUksQ0FBQyxXQUFXLEVBQUU7Z0JBQ2hCLFdBQVcsR0FBRyxJQUFJLENBQUM7Z0JBQ25CLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLFVBQVUsS0FBSyxZQUFZLE1BQU0sU0FBUyxPQUFPLEVBQUU7b0JBQ2hGLE9BQU8sRUFBRSxPQUFPLENBQUMsT0FBTztvQkFDeEIsd0JBQXdCLEVBQUUsT0FBTyxDQUFDLHdCQUF3QjtvQkFDMUQsT0FBTyxFQUFFLFdBQVc7b0JBQ3BCLE9BQU8sRUFBRSxTQUFTO29CQUNsQixRQUFRLEVBQUUsT0FBTyxDQUFDLFFBQVE7aUJBQzNCLENBQUMsQ0FBQzthQUNKO1lBQ0QsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsWUFBWSxNQUFNLFNBQVMsT0FBTyxZQUFZLEdBQUcsRUFBRTtnQkFDaEYsT0FBTyxFQUFFLE9BQU8sQ0FBQyxPQUFPO2dCQUN4QixPQUFPLEVBQUUsV0FBVztnQkFDcEIsVUFBVSxFQUFFLEtBQUs7Z0JBQ2pCLE9BQU8sRUFBRSxNQUFNO2FBQ2hCLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQztRQUVGLE1BQU0sT0FBTyxHQUFHLEdBQUcsRUFBRTtZQUNuQixNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUMxRCxnQ0FBZ0M7WUFDaEMsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksRUFBRTtnQkFDeEMsT0FBTyxFQUFFLFdBQVc7Z0JBQ3BCLE9BQU8sRUFBRSxTQUFTO2FBQ25CLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQztRQUVGLE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLGFBQWEsQ0FBQyxhQUFhLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQztJQUNwRSxDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLGdCQUFnQixDQUFDIn0=