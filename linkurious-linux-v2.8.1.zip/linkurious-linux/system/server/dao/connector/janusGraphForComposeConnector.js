/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2018-02-08.
 */
'use strict';
const Promise = require('bluebird');
const LKE = require('../../services');
const Log = LKE.getLogger(__filename);
const Errors = LKE.getErrors();
const JanusGraphConnector = require('./janusGraphConnector');
class JanusGraphForComposeConnector extends JanusGraphConnector {
    /**
     * Add definitions in the gremlin session and/or perform additional checks.
     *
     * @returns {Bluebird<void>}
     */
    $initGremlinSession() {
        const sName = JSON.stringify(this.getGraphOption('graphName'));
        const gremlinQuery = verb => `
      def graph = ConfiguredGraphFactory.${verb}(${sName});
      def g = graph.traversal();
      null
    `;
        return this.$doGremlinQuery(gremlinQuery('open'), {
            session: 'all',
            autoCommit: false
        }).return()
            .catch(e => {
            // If compose doesn't have the graph it will respond with
            // [...] Please create configuration for this graph [...]
            if (e.message.includes('create')) {
                if (this.getGraphOption('create')) {
                    Log.info(`Creating JanusGraph For Compose graph ${sName}. It can take a while...`);
                    return this.$doGremlinQuery(gremlinQuery('create'), {
                        session: 'all',
                        autoCommit: false
                    });
                }
                else {
                    return Errors.technical('graph_unreachable', `The graph database ${sName} does not exist and auto-creation is disabled` +
                        ' ("create" option is false).', true);
                }
            }
            throw e;
        });
    }
    /**
     * Detect the current store ID.
     *
     * A store ID is the name of the current database (if the graph server is multi-tenant)
     * otherwise the vendor name.
     *
     * @returns {Bluebird<string>}
     */
    $getStoreId() {
        return Promise.resolve(this.getGraphOption('graphName'));
    }
}
module.exports = JanusGraphForComposeConnector;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiamFudXNHcmFwaEZvckNvbXBvc2VDb25uZWN0b3IuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2Nvbm5lY3Rvci9qYW51c0dyYXBoRm9yQ29tcG9zZUNvbm5lY3Rvci5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7R0FLRztBQUNILFlBQVksQ0FBQztBQUNiLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNwQyxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztBQUN0QyxNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3RDLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLG1CQUFtQixHQUFHLE9BQU8sQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO0FBRTdELE1BQU0sNkJBQThCLFNBQVEsbUJBQW1CO0lBRTdEOzs7O09BSUc7SUFDSCxtQkFBbUI7UUFDakIsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7UUFFL0QsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLEVBQUUsQ0FBQzsyQ0FDVSxJQUFJLElBQUksS0FBSzs7O0tBR25ELENBQUM7UUFFRixPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQ2hELE9BQU8sRUFBRSxLQUFLO1lBQ2QsVUFBVSxFQUFFLEtBQUs7U0FDbEIsQ0FBQyxDQUFDLE1BQU0sRUFBRTthQUNSLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUNULHlEQUF5RDtZQUN6RCx5REFBeUQ7WUFDekQsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsRUFBRTtnQkFDaEMsSUFBSSxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxFQUFFO29CQUNqQyxHQUFHLENBQUMsSUFBSSxDQUFDLHlDQUF5QyxLQUFLLDBCQUEwQixDQUFDLENBQUM7b0JBQ25GLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLEVBQUU7d0JBQ2xELE9BQU8sRUFBRSxLQUFLO3dCQUNkLFVBQVUsRUFBRSxLQUFLO3FCQUNsQixDQUFDLENBQUM7aUJBQ0o7cUJBQU07b0JBQ0wsT0FBTyxNQUFNLENBQUMsU0FBUyxDQUNyQixtQkFBbUIsRUFDbkIsc0JBQXNCLEtBQUssK0NBQStDO3dCQUMxRSw4QkFBOEIsRUFDOUIsSUFBSSxDQUNMLENBQUM7aUJBQ0g7YUFDRjtZQUVELE1BQU0sQ0FBQyxDQUFDO1FBQ1YsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILFdBQVc7UUFDVCxPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0lBQzNELENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsNkJBQTZCLENBQUMifQ==