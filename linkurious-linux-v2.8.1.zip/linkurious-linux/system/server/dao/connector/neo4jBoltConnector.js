/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-10-09.
 */
'use strict';
const neo4j = require('neo4j-driver').v1;
const Promise = require('bluebird');
const _ = require('lodash');
const LKE = require('../../services');
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
const Log = LKE.getLogger(__filename);
const Config = LKE.getConfig();
const Neo4jHTTPConnector = require('./neo4jHTTPConnector');
const CypherUtils = require('../utils/cypherUtils');
const { GraphRequestTimeout, Vendor } = require('../../models/errors/GraphRequestTimeout');
class Neo4jBoltConnector extends Neo4jHTTPConnector {
    /**
     * @param {any} graphOptions   GraphDAO options
     * @param {any} [indexOptions] IndexDAO options (only if the type of the DAO is 'Index')
     */
    constructor(graphOptions, indexOptions) {
        super(graphOptions, indexOptions);
        const url = Utils.normalizeUrl(this.getGraphOption('url'));
        const hostPort = Utils.extractHostPort(url);
        this._host = hostPort.host;
        if (hostPort.scheme === 'bolt' || hostPort.scheme === 'bolt+routing') {
            this._boltUrl = url;
        }
        else {
            this.$httpUrl = url;
        }
        this._authToken = this.getGraphOption('user')
            ? neo4j.auth.basic(this.getGraphOption('user'), this.getGraphOption('password'))
            : undefined;
        this._maxTransactionRetryTime = Config.get('advanced.rawQueryTimeout');
    }
    /**
     * Disconnect from the remote server.
     */
    $disconnect() {
        this._closeConnection();
    }
    /**
     * Close the connection.
     *
     * @private
     */
    _closeConnection() {
        try {
            this._driver.close();
        }
        catch (e) {
            // do nothing
        }
        // release the client
        this._driver = undefined;
    }
    /**
     * Given a Neo4j configuration object returned by Neo4j, create a valid HTTP/S Url.
     *
     * @param {object} configuration Neo4j configuration
     * @returns {string}
     * @throws {LkError} if not possible
     * @private
     */
    _createHTTPUrl(configuration) {
        const isHTTPEnabled = Utils.hasValue(configuration['dbms.connector.http.enabled'])
            ? configuration['dbms.connector.http.enabled'] === 'true'
            : false;
        const isHTTPSEnabled = Utils.hasValue(configuration['dbms.connector.https.enabled'])
            ? configuration['dbms.connector.https.enabled'] === 'true'
            : false;
        // "advertised_address" will have priority over "listen_address"
        // In some version of Neo4j "listen_address" is just "address"
        const httpPortConfigurationValue = configuration['dbms.connector.http.advertised_address'] ||
            configuration['dbms.connector.http.listen_address'] ||
            configuration['dbms.connector.http.address'];
        const httpPort = Utils.hasValue(httpPortConfigurationValue)
            ? httpPortConfigurationValue.split(':')[1]
            : '7474'; // default Neo4j HTTP port
        const httpsPortConfigurationValue = configuration['dbms.connector.https.advertised_address'] ||
            configuration['dbms.connector.https.listen_address'] ||
            configuration['dbms.connector.https.address'];
        const httpsPort = Utils.hasValue(httpsPortConfigurationValue)
            ? httpsPortConfigurationValue.split(':')[1]
            : '7473'; // default Neo4j HTTPS port
        if (isHTTPEnabled || isHTTPSEnabled) {
            const protocol = isHTTPEnabled ? 'http' : 'https';
            const port = isHTTPEnabled ? httpPort : httpsPort;
            return protocol + '://' + this._host + ':' + port;
        }
        throw Errors.business('invalid_parameter', 'HTTP or HTTPS has to be enabled even when using the Bolt protocol.');
    }
    /**
     * Given a Neo4j configuration object returned by Neo4j, create a valid Bolt Url.
     *
     * @param {object} configuration
     * @returns {string}
     * @throws {LkError} if not possible
     * @private
     */
    _createBoltUrl(configuration) {
        const isBoltEnabled = Utils.hasValue(configuration['dbms.connector.bolt.enabled'])
            ? configuration['dbms.connector.bolt.enabled'] === 'true'
            : false;
        const boltPortConfigurationValue = configuration['dbms.connector.bolt.advertised_address'] ||
            configuration['dbms.connector.bolt.listen_address'] ||
            configuration['dbms.connector.bolt.address'];
        const boltPort = Utils.hasValue(boltPortConfigurationValue)
            ? boltPortConfigurationValue.split(':')[1]
            : '7687'; // default Neo4j Bolt port
        if (isBoltEnabled) {
            return 'bolt://' + this._host + ':' + boltPort;
        }
        throw Errors.business('invalid_parameter', 'Bolt has to be enabled to use the Neo4j Bolt connector.');
    }
    /**
     * Connect to the remote server using Bolt.
     *
     * @returns {Bluebird<string>} resolved with the SemVer version of the remote server
     */
    _connect() {
        this._driver = neo4j.driver(this._boltUrl, this._authToken, { maxTransactionRetryTime: this._maxTransactionRetryTime });
        return new Promise((resolve, reject) => {
            this._driver.onCompleted = resolve;
            this._driver.onError = error => {
                this._closeConnection();
                if (error.code === 'Neo.ClientError.Security.Unauthorized') {
                    // fail for wrong credentials
                    reject(Errors.business('invalid_parameter', 'Please check the Neo4j username and password in the configuration.'));
                }
                else {
                    // fail for every other error
                    reject(Errors.technical('critical', `Cannot connect to the Neo4j server (${this.getGraphOption('url')}): ` +
                        `${error.code}, ${error.message}`));
                }
            };
        }).then(() => {
            return this.$queryJmx('org.neo4j', 'instance=kernel#0,name=Kernel', 'KernelVersion').then(kernelVersion => {
                // kernelVersion is in the following format:
                // "neo4j-kernel, version: 3.3.0,5b700972242a5ec3e0140261120f2845fb3520ad"
                const match = kernelVersion.match(/\d+\.\d+.\d+/);
                if (Utils.noValue(match)) {
                    return Errors.technical('critical', 'Cannot get Neo4j version. KernelVersion is: ' + kernelVersion, true);
                }
                return match[0];
            });
        });
    }
    /**
     * Connect to the remote server.
     *
     * @returns {Bluebird<string>} resolved with the SemVer version of the remote server
     */
    $connect() {
        // In this connector we have to connect via both Bolt and HTTP/S
        // We can start from any of them, we retrieve the configuration and test the other
        const firstBolt = Utils.hasValue(this._boltUrl);
        return Promise.resolve().then(() => {
            if (firstBolt) {
                // we connect over Bolt
                return this._connect();
            }
            else {
                // we connect over HTTP/S
                return super.$connect();
            }
        }).then(() => {
            if (firstBolt) {
                // we get the configuration over Bolt
                return this.$queryJmx('org.neo4j', 'instance=kernel#0,name=Configuration');
            }
            else {
                // we get the configuration over HTTP/S
                return super.$queryJmx('org.neo4j', 'instance=kernel#0,name=Configuration');
            }
        }).then(configuration => {
            // after we got the configuration, we try to create the other protocol url and connect with it
            if (firstBolt) {
                this.$httpUrl = this._createHTTPUrl(configuration);
                // we connect over HTTP/S
                return super.$connect();
            }
            else {
                this._boltUrl = this._createBoltUrl(configuration);
                // we connect over Bolt
                return this._connect();
            }
        });
    }
    /**
     * Encode a property value from Neo4j.
     *
     * @param {any} rawProperty
     * @returns {LkPropertyValue}
     * @private
     */
    $encodeProperty(rawProperty) {
        if (Utils.hasValue(rawProperty.inSafeRange)) { // it's an Integer
            // if it's a safe range integer we convert it to a number, otherwise to a string
            return rawProperty.inSafeRange() ? rawProperty.toNumber() : rawProperty.toString();
        }
        return super.$encodeProperty(rawProperty);
    }
    /**
     * Encode a path response from Neo4j in a valid alternation of LkNodes and LkEdges.
     * This format was chosen to match the behaviour of the HTTP connector where we cannot find out,
     * a priori, if the response is an actual Path or just an alternation of LkNodes and LkEdges.
     *
     * @param {any} rawField
     * @private
     * @returns {any}
     */
    _encodePath(rawField) {
        const result = [];
        for (let i = 0; i < rawField.segments.length; i++) {
            result.push(this._encodeNode(rawField.segments[i].start));
            result.push(this._encodeEdge(rawField.segments[i].relationship));
        }
        result.push(this._encodeNode(rawField.segments[rawField.segments.length - 1].end));
        return result;
    }
    /**
     * Encode a node response from Neo4j in a valid LkNode.
     *
     * @param {any} rawField
     * @private
     * @returns {any}
     */
    _encodeNode(rawField) {
        return {
            id: rawField.identity.toString(),
            categories: rawField.labels.sort(),
            data: _.mapValues(rawField.properties, this.$encodeProperty.bind(this))
        };
    }
    /**
     * Encode an edge response from Neo4j in a valid LkEdge.
     *
     * @param {any} rawField
     * @private
     * @returns {any}
     */
    _encodeEdge(rawField) {
        return {
            id: rawField.identity.toString(),
            source: rawField.start.toString(),
            target: rawField.end.toString(),
            type: rawField.type,
            data: _.mapValues(rawField.properties, this.$encodeProperty.bind(this))
        };
    }
    /**
     * Encode a raw field response from Neo4j in a valid response for Linkurious
     * (an LkNode an LkEdge, literal values or an array of these).
     *
     * Add every node and edge to `nodesById` and `edgesById`.
     * Return the content of the node/edge to be consistent with the HTTP response.
     *
     * @param {any}                 rawField
     * @param {Map<string, LkNode>} nodesById
     * @param {Map<string, LkEdge>} edgesById
     * @private
     * @returns {any}
     */
    _encodeBoltResponseField(rawField, nodesById, edgesById) {
        // for every field (a Node, an Edge or a literal value)
        // we convert it to our internal format (LkNode, LkEdge or literal value)
        // IDs, represented in Neo4j as 64bit unsigned int, are represented here as strings
        if (Utils.noValue(rawField)) {
            return rawField;
        }
        else if (Utils.hasValue(rawField.labels) && Utils.hasValue(rawField.identity)) { // it's a Node
            const node = this._encodeNode(rawField);
            nodesById.set(node.id, node);
            return node.data;
        }
        else if (Utils.hasValue(rawField.type) && Utils.hasValue(rawField.identity)) { // it's an Edge
            const edge = this._encodeEdge(rawField);
            edgesById.set(edge.id, edge);
            return edge.data;
        }
        else if (Utils.hasValue(rawField.segments)) { // it's a Path
            const path = this._encodePath(rawField);
            path.forEach(item => {
                if (Utils.hasValue(item.categories)) { // it's a Node
                    nodesById.set(item.id, item);
                }
                else {
                    edgesById.set(item.id, item);
                }
            });
            return path.map(item => item.data);
        }
        else if (Utils.hasValue(rawField.inSafeRange)) { // it's an Integer
            // if it's a safe range integer we convert it to a number, otherwise to a string
            return rawField.inSafeRange() ? rawField.toNumber() : rawField.toString();
        }
        else if (Array.isArray(rawField)) {
            return _.map(rawField, innerRawField => {
                return this._encodeBoltResponseField(innerRawField, nodesById, edgesById);
            });
        }
        else if (Utils.isObject(rawField)) {
            return _.mapValues(rawField, innerRawField => {
                return this._encodeBoltResponseField(innerRawField, nodesById, edgesById);
            });
        }
        // it's a literal value
        return rawField;
    }
    /**
     * Encode a record from Neo4j in a valid response for Linkurious.
     *
     * @param {any} record
     * @private
     * @returns {{nodes: LkNode[], edges: LkEdge[], rows: any[]}}
     */
    _encodeBoltResponseRecord(record) {
        const nodesById = new Map();
        const edgesById = new Map();
        const rows = record._fields.map(field => this._encodeBoltResponseField.call(this, field, nodesById, edgesById));
        // We ignore nodes with no categories
        const nodes = _.filter(Array.from(nodesById.values()), node => node.categories.length > 0);
        return {
            nodes: nodes,
            edges: Array.from(edgesById.values()),
            rows: rows
        };
    }
    /**
     * Execute a cypher query on Neo4j.
     *
     * Note that this function is not meant for user queries.
     * We don't enforce a limit or check if the query contains write statements.
     * Use $safeCypherQueryStream instead.
     *
     * @param {string}  query        The graph query
     * @param {object}  [parameters] The graph query parameters
     * @param {boolean} [ignoreSlow] Don't log slow requests
     * @returns {Bluebird<{keys: string[], results: Array<{nodes: LkNode[], edges: LkEdge[], rows: any[]}>}>}
     */
    $doCypherQuery(query, parameters, ignoreSlow) {
        return this._doCypherQuery(query, parameters, ignoreSlow).then(result => {
            // if no record is found, we don't return anything, including the keys
            if (Utils.noValue(result.records[0])) {
                return {
                    keys: [],
                    results: []
                };
            }
            return {
                keys: result.records[0].keys,
                results: result.records.map(record => this._encodeBoltResponseRecord.call(this, record))
            };
        });
    }
    /**
     * Execute a cypher query on Neo4j.
     *
     * @param {string}  query
     * @param {object}  [parameters]
     * @param {boolean} [ignoreSlow] Don't log slow requests
     * @returns {Bluebird<{records: any[], summary: object}>}
     * @private
     */
    _doCypherQuery(query, parameters, ignoreSlow) {
        if (!this._driver) {
            return Errors.technical('graph_unreachable', 'Cannot connect to the Neo4j server.', true);
        }
        const session = this._driver.session();
        // we select the right endpoint for Causal Clustering
        // (write transactions will only be forwarded to a Core Neo4j instance)
        const willWrite = CypherUtils.isWrite(query);
        const getTransaction = willWrite
            ? session.writeTransaction.bind(session)
            : session.readTransaction.bind(session);
        const t0 = Date.now();
        return Promise.resolve().then(() => {
            return getTransaction(transaction => transaction.run(query, parameters));
        }).then(results => {
            session.close();
            return results;
        }).catch(error => {
            // Neo4j has multiple Constraint violation errors (depending on the version):
            // - Neo.ClientError.Schema.ConstraintValidationFailed
            // - Neo.ClientError.Schema.ConstraintViolation
            if (Utils.hasValue(error.code) && error.code.includes('Constraint')) {
                return Errors.business('constraint_violation', 'Constraint violation: ' + error.message, true);
            }
            // Query timeout
            // - Neo.ClientError.Transaction.TransactionTimedOut
            if (_.includes(error.code, 'TimedOut')) {
                throw new GraphRequestTimeout(Vendor.NEO4J);
            }
            if (error.code === 'ServiceUnavailable') {
                return Errors.business('dataSource_unavailable', 'Request to graph server failed: ' + error.code + ': ' + error.message, true);
            }
            const isBadGraphRequest = Utils.hasValue(error.code) && error.code.includes('Syntax');
            const errorMessage = 'Neo4j (Bolt) wasn\'t able to execute the query: ' + error.message;
            if (isBadGraphRequest) {
                const offset = this.extractErrorOffset(errorMessage);
                if (Utils.hasValue(offset)) {
                    return Errors.business('bad_graph_request', errorMessage, true, { offset: offset });
                }
                return Errors.business('bad_graph_request', errorMessage, true);
            }
            return Errors.technical('critical', errorMessage, true);
        }).finally(() => {
            if (ignoreSlow) {
                return;
            }
            Utils.logSlow(t0, this.SLOW_QUERY_THRESHOLD, 'Query (Bolt): ' + query, Log);
        });
    }
    /**
     * Query JMX management data of Neo4j by domain, name and key.
     *
     * @param {string} domain
     * @param {string} name
     * @param {string} [key]
     * @returns {Bluebird<any>}
     */
    $queryJmx(domain, name, key) {
        return this.$doCypherQuery(`CALL dbms.queryJmx("${domain}:${name}")`).then(response => {
            if (Utils.hasValue(key)) {
                return Utils.safeGet(response, `results.0.rows.2.${key}.value`);
            }
            else {
                return _.mapValues(Utils.safeGet(response, 'results.0.rows.2'), 'value');
            }
        });
    }
}
module.exports = Neo4jBoltConnector;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmVvNGpCb2x0Q29ubmVjdG9yLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL2Rhby9jb25uZWN0b3IvbmVvNGpCb2x0Q29ubmVjdG9yLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBQ2IsTUFBTSxLQUFLLEdBQUcsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUN6QyxNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDcEMsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVCLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0FBQ3RDLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxHQUFHLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUN0QyxNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxrQkFBa0IsR0FBRyxPQUFPLENBQUMsc0JBQXNCLENBQUMsQ0FBQztBQUMzRCxNQUFNLFdBQVcsR0FBRyxPQUFPLENBQUMsc0JBQXNCLENBQUMsQ0FBQztBQUNwRCxNQUFNLEVBQUMsbUJBQW1CLEVBQUUsTUFBTSxFQUFDLEdBQUcsT0FBTyxDQUFDLHlDQUF5QyxDQUFDLENBQUM7QUFFekYsTUFBTSxrQkFBbUIsU0FBUSxrQkFBa0I7SUFFakQ7OztPQUdHO0lBQ0gsWUFBWSxZQUFZLEVBQUUsWUFBWTtRQUNwQyxLQUFLLENBQUMsWUFBWSxFQUFFLFlBQVksQ0FBQyxDQUFDO1FBRWxDLE1BQU0sR0FBRyxHQUFHLEtBQUssQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1FBQzNELE1BQU0sUUFBUSxHQUFHLEtBQUssQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLENBQUM7UUFFNUMsSUFBSSxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO1FBQzNCLElBQUksUUFBUSxDQUFDLE1BQU0sS0FBSyxNQUFNLElBQUksUUFBUSxDQUFDLE1BQU0sS0FBSyxjQUFjLEVBQUU7WUFDcEUsSUFBSSxDQUFDLFFBQVEsR0FBRyxHQUFHLENBQUM7U0FDckI7YUFBTTtZQUNMLElBQUksQ0FBQyxRQUFRLEdBQUcsR0FBRyxDQUFDO1NBQ3JCO1FBRUQsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQztZQUMzQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQ2hGLENBQUMsQ0FBQyxTQUFTLENBQUM7UUFFZCxJQUFJLENBQUMsd0JBQXdCLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQywwQkFBMEIsQ0FBQyxDQUFDO0lBQ3pFLENBQUM7SUFFRDs7T0FFRztJQUNILFdBQVc7UUFDVCxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILGdCQUFnQjtRQUNkLElBQUk7WUFDRixJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDO1NBQ3RCO1FBQUMsT0FBTSxDQUFDLEVBQUU7WUFDVCxhQUFhO1NBQ2Q7UUFFRCxxQkFBcUI7UUFDckIsSUFBSSxDQUFDLE9BQU8sR0FBRyxTQUFTLENBQUM7SUFDM0IsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxjQUFjLENBQUMsYUFBYTtRQUMxQixNQUFNLGFBQWEsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO1lBQ2hGLENBQUMsQ0FBQyxhQUFhLENBQUMsNkJBQTZCLENBQUMsS0FBSyxNQUFNO1lBQ3pELENBQUMsQ0FBQyxLQUFLLENBQUM7UUFDVixNQUFNLGNBQWMsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDO1lBQ2xGLENBQUMsQ0FBQyxhQUFhLENBQUMsOEJBQThCLENBQUMsS0FBSyxNQUFNO1lBQzFELENBQUMsQ0FBQyxLQUFLLENBQUM7UUFFVixnRUFBZ0U7UUFDaEUsOERBQThEO1FBQzlELE1BQU0sMEJBQTBCLEdBQzlCLGFBQWEsQ0FBQyx3Q0FBd0MsQ0FBQztZQUN2RCxhQUFhLENBQUMsb0NBQW9DLENBQUM7WUFDbkQsYUFBYSxDQUFDLDZCQUE2QixDQUFDLENBQUM7UUFFL0MsTUFBTSxRQUFRLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQywwQkFBMEIsQ0FBQztZQUN6RCxDQUFDLENBQUMsMEJBQTBCLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMxQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsMEJBQTBCO1FBRXRDLE1BQU0sMkJBQTJCLEdBQy9CLGFBQWEsQ0FBQyx5Q0FBeUMsQ0FBQztZQUN4RCxhQUFhLENBQUMscUNBQXFDLENBQUM7WUFDcEQsYUFBYSxDQUFDLDhCQUE4QixDQUFDLENBQUM7UUFDaEQsTUFBTSxTQUFTLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQywyQkFBMkIsQ0FBQztZQUMzRCxDQUFDLENBQUMsMkJBQTJCLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMzQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsMkJBQTJCO1FBRXZDLElBQUksYUFBYSxJQUFJLGNBQWMsRUFBRTtZQUNuQyxNQUFNLFFBQVEsR0FBRyxhQUFhLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO1lBQ2xELE1BQU0sSUFBSSxHQUFHLGFBQWEsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUM7WUFDbEQsT0FBTyxRQUFRLEdBQUcsS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQztTQUNuRDtRQUVELE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FDbkIsbUJBQW1CLEVBQ25CLG9FQUFvRSxDQUNyRSxDQUFDO0lBQ0osQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxjQUFjLENBQUMsYUFBYTtRQUMxQixNQUFNLGFBQWEsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO1lBQ2hGLENBQUMsQ0FBQyxhQUFhLENBQUMsNkJBQTZCLENBQUMsS0FBSyxNQUFNO1lBQ3pELENBQUMsQ0FBQyxLQUFLLENBQUM7UUFFVixNQUFNLDBCQUEwQixHQUM5QixhQUFhLENBQUMsd0NBQXdDLENBQUM7WUFDdkQsYUFBYSxDQUFDLG9DQUFvQyxDQUFDO1lBQ25ELGFBQWEsQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO1FBQy9DLE1BQU0sUUFBUSxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsMEJBQTBCLENBQUM7WUFDekQsQ0FBQyxDQUFDLDBCQUEwQixDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDMUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLDBCQUEwQjtRQUV0QyxJQUFJLGFBQWEsRUFBRTtZQUNqQixPQUFPLFNBQVMsR0FBRyxJQUFJLENBQUMsS0FBSyxHQUFHLEdBQUcsR0FBRyxRQUFRLENBQUM7U0FDaEQ7UUFFRCxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQ25CLG1CQUFtQixFQUNuQix5REFBeUQsQ0FDMUQsQ0FBQztJQUNKLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsUUFBUTtRQUNOLElBQUksQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxVQUFVLEVBQ3hELEVBQUMsdUJBQXVCLEVBQUUsSUFBSSxDQUFDLHdCQUF3QixFQUFDLENBQUMsQ0FBQztRQUU1RCxPQUFPLElBQUksT0FBTyxDQUFDLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxFQUFFO1lBQ3JDLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxHQUFHLE9BQU8sQ0FBQztZQUVuQyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUMsRUFBRTtnQkFDN0IsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7Z0JBRXhCLElBQUksS0FBSyxDQUFDLElBQUksS0FBSyx1Q0FBdUMsRUFBRTtvQkFDMUQsNkJBQTZCO29CQUM3QixNQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FDcEIsbUJBQW1CLEVBQ25CLG9FQUFvRSxDQUNyRSxDQUFDLENBQUM7aUJBQ0o7cUJBQU07b0JBQ0wsNkJBQTZCO29CQUM3QixNQUFNLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FDckIsVUFBVSxFQUNWLHVDQUF1QyxJQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxLQUFLO3dCQUN0RSxHQUFHLEtBQUssQ0FBQyxJQUFJLEtBQUssS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUNsQyxDQUFDLENBQUM7aUJBQ0o7WUFDSCxDQUFDLENBQUM7UUFDSixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1gsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUNuQixXQUFXLEVBQUUsK0JBQStCLEVBQUUsZUFBZSxDQUM5RCxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRTtnQkFDckIsNENBQTRDO2dCQUM1QywwRUFBMEU7Z0JBQzFFLE1BQU0sS0FBSyxHQUFHLGFBQWEsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUM7Z0JBQ2xELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRTtvQkFDeEIsT0FBTyxNQUFNLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFDaEMsOENBQThDLEdBQUcsYUFBYSxFQUFFLElBQUksQ0FBQyxDQUFDO2lCQUN6RTtnQkFFRCxPQUFPLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNsQixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxRQUFRO1FBQ04sZ0VBQWdFO1FBQ2hFLGtGQUFrRjtRQUNsRixNQUFNLFNBQVMsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUVoRCxPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ2pDLElBQUksU0FBUyxFQUFFO2dCQUNiLHVCQUF1QjtnQkFDdkIsT0FBTyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7YUFDeEI7aUJBQU07Z0JBQ0wseUJBQXlCO2dCQUN6QixPQUFPLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQzthQUN6QjtRQUNILENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCxJQUFJLFNBQVMsRUFBRTtnQkFDYixxQ0FBcUM7Z0JBQ3JDLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsc0NBQXNDLENBQUMsQ0FBQzthQUM1RTtpQkFBTTtnQkFDTCx1Q0FBdUM7Z0JBQ3ZDLE9BQU8sS0FBSyxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsc0NBQXNDLENBQUMsQ0FBQzthQUM3RTtRQUNILENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRTtZQUN0Qiw4RkFBOEY7WUFDOUYsSUFBSSxTQUFTLEVBQUU7Z0JBQ2IsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxDQUFDO2dCQUNuRCx5QkFBeUI7Z0JBQ3pCLE9BQU8sS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDO2FBQ3pCO2lCQUFNO2dCQUNMLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxhQUFhLENBQUMsQ0FBQztnQkFDbkQsdUJBQXVCO2dCQUN2QixPQUFPLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQzthQUN4QjtRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILGVBQWUsQ0FBQyxXQUFXO1FBQ3pCLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLEVBQUUsRUFBRSxrQkFBa0I7WUFDL0QsZ0ZBQWdGO1lBQ2hGLE9BQU8sV0FBVyxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztTQUNwRjtRQUVELE9BQU8sS0FBSyxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSCxXQUFXLENBQUMsUUFBUTtRQUNsQixNQUFNLE1BQU0sR0FBRyxFQUFFLENBQUM7UUFFbEIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ2pELE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7WUFDMUQsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztTQUNsRTtRQUVELE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFFbkYsT0FBTyxNQUFNLENBQUM7SUFDaEIsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILFdBQVcsQ0FBQyxRQUFRO1FBQ2xCLE9BQU87WUFDTCxFQUFFLEVBQUUsUUFBUSxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUU7WUFDaEMsVUFBVSxFQUFFLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFO1lBQ2xDLElBQUksRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDeEUsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxXQUFXLENBQUMsUUFBUTtRQUNsQixPQUFPO1lBQ0wsRUFBRSxFQUFFLFFBQVEsQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFO1lBQ2hDLE1BQU0sRUFBRSxRQUFRLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRTtZQUNqQyxNQUFNLEVBQUUsUUFBUSxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUU7WUFDL0IsSUFBSSxFQUFFLFFBQVEsQ0FBQyxJQUFJO1lBQ25CLElBQUksRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDeEUsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7O09BWUc7SUFDSCx3QkFBd0IsQ0FBQyxRQUFRLEVBQUUsU0FBUyxFQUFFLFNBQVM7UUFDckQsdURBQXVEO1FBQ3ZELHlFQUF5RTtRQUN6RSxtRkFBbUY7UUFDbkYsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQzNCLE9BQU8sUUFBUSxDQUFDO1NBQ2pCO2FBQU0sSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLGNBQWM7WUFDL0YsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUN4QyxTQUFTLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDN0IsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDO1NBQ2xCO2FBQU0sSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLGVBQWU7WUFDOUYsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUN4QyxTQUFTLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDN0IsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDO1NBQ2xCO2FBQU0sSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLGNBQWM7WUFDNUQsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUN4QyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUNsQixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLEVBQUUsY0FBYztvQkFDbkQsU0FBUyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDO2lCQUM5QjtxQkFBTTtvQkFDTCxTQUFTLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUM7aUJBQzlCO1lBQ0gsQ0FBQyxDQUFDLENBQUM7WUFDSCxPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDcEM7YUFBTSxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxFQUFFLEVBQUUsa0JBQWtCO1lBQ25FLGdGQUFnRjtZQUNoRixPQUFPLFFBQVEsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFLENBQUM7U0FDM0U7YUFBTSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDbEMsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxhQUFhLENBQUMsRUFBRTtnQkFDckMsT0FBTyxJQUFJLENBQUMsd0JBQXdCLENBQUMsYUFBYSxFQUFFLFNBQVMsRUFBRSxTQUFTLENBQUMsQ0FBQztZQUM1RSxDQUFDLENBQUMsQ0FBQztTQUNKO2FBQU0sSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ25DLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxRQUFRLEVBQUUsYUFBYSxDQUFDLEVBQUU7Z0JBQzNDLE9BQU8sSUFBSSxDQUFDLHdCQUF3QixDQUFDLGFBQWEsRUFBRSxTQUFTLEVBQUUsU0FBUyxDQUFDLENBQUM7WUFDNUUsQ0FBQyxDQUFDLENBQUM7U0FDSjtRQUVELHVCQUF1QjtRQUN2QixPQUFPLFFBQVEsQ0FBQztJQUNsQixDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gseUJBQXlCLENBQUMsTUFBTTtRQUM5QixNQUFNLFNBQVMsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBQzVCLE1BQU0sU0FBUyxHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7UUFDNUIsTUFBTSxJQUFJLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQzdCLEtBQUssQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLHdCQUF3QixDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxTQUFTLENBQUMsQ0FDL0UsQ0FBQztRQUVGLHFDQUFxQztRQUNyQyxNQUFNLEtBQUssR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsSUFBSSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztRQUUzRixPQUFPO1lBQ0wsS0FBSyxFQUFFLEtBQUs7WUFDWixLQUFLLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDckMsSUFBSSxFQUFFLElBQUk7U0FDWCxDQUFDO0lBQ0osQ0FBQztJQUVEOzs7Ozs7Ozs7OztPQVdHO0lBQ0gsY0FBYyxDQUFDLEtBQUssRUFBRSxVQUFVLEVBQUUsVUFBVTtRQUMxQyxPQUFPLElBQUksQ0FBQyxjQUFjLENBQUMsS0FBSyxFQUFFLFVBQVUsRUFBRSxVQUFVLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDdEUsc0VBQXNFO1lBQ3RFLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0JBQ3BDLE9BQU87b0JBQ0wsSUFBSSxFQUFFLEVBQUU7b0JBQ1IsT0FBTyxFQUFFLEVBQUU7aUJBQ1osQ0FBQzthQUNIO1lBRUQsT0FBTztnQkFDTCxJQUFJLEVBQUUsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO2dCQUM1QixPQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQ3pCLE1BQU0sQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLHlCQUF5QixDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUM7YUFDL0QsQ0FBQztRQUNKLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsY0FBYyxDQUFDLEtBQUssRUFBRSxVQUFVLEVBQUUsVUFBVTtRQUMxQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNqQixPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQUMsbUJBQW1CLEVBQUUscUNBQXFDLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDM0Y7UUFFRCxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQ3ZDLHFEQUFxRDtRQUNyRCx1RUFBdUU7UUFDdkUsTUFBTSxTQUFTLEdBQUcsV0FBVyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUU3QyxNQUFNLGNBQWMsR0FBRyxTQUFTO1lBQzlCLENBQUMsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztZQUN4QyxDQUFDLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFMUMsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1FBQ3RCLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDakMsT0FBTyxjQUFjLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFDO1FBQzNFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUNoQixPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDaEIsT0FBTyxPQUFPLENBQUM7UUFDakIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ2YsNkVBQTZFO1lBQzdFLHNEQUFzRDtZQUN0RCwrQ0FBK0M7WUFDL0MsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxLQUFLLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsRUFBRTtnQkFDbkUsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLHNCQUFzQixFQUMzQyx3QkFBd0IsR0FBRyxLQUFLLENBQUMsT0FBTyxFQUFFLElBQUksQ0FDL0MsQ0FBQzthQUNIO1lBRUQsZ0JBQWdCO1lBQ2hCLG9EQUFvRDtZQUNwRCxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxVQUFVLENBQUMsRUFBRTtnQkFDdEMsTUFBTSxJQUFJLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUM3QztZQUVELElBQUksS0FBSyxDQUFDLElBQUksS0FBSyxvQkFBb0IsRUFBRTtnQkFDdkMsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUNwQix3QkFBd0IsRUFDeEIsa0NBQWtDLEdBQUcsS0FBSyxDQUFDLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSyxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQzdFLENBQUM7YUFDSDtZQUVELE1BQU0saUJBQWlCLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUM7WUFFdEYsTUFBTSxZQUFZLEdBQUcsa0RBQWtELEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQztZQUN4RixJQUFJLGlCQUFpQixFQUFFO2dCQUNyQixNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxDQUFDLENBQUM7Z0JBQ3JELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRTtvQkFDMUIsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLG1CQUFtQixFQUFFLFlBQVksRUFBRSxJQUFJLEVBQUUsRUFBQyxNQUFNLEVBQUUsTUFBTSxFQUFDLENBQUMsQ0FBQztpQkFDbkY7Z0JBQ0QsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLG1CQUFtQixFQUFFLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQzthQUNqRTtZQUNELE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUUsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzFELENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUU7WUFDZCxJQUFJLFVBQVUsRUFBRTtnQkFBRSxPQUFPO2FBQUU7WUFDM0IsS0FBSyxDQUFDLE9BQU8sQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLG9CQUFvQixFQUFFLGdCQUFnQixHQUFHLEtBQUssRUFBRSxHQUFHLENBQUMsQ0FBQztRQUM5RSxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsU0FBUyxDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsR0FBRztRQUN6QixPQUFPLElBQUksQ0FBQyxjQUFjLENBQ3hCLHVCQUF1QixNQUFNLElBQUksSUFBSSxJQUFJLENBQzFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ2hCLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRTtnQkFDdkIsT0FBTyxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxvQkFBb0IsR0FBRyxRQUFRLENBQUMsQ0FBQzthQUNqRTtpQkFBTTtnQkFDTCxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsa0JBQWtCLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQzthQUMxRTtRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxrQkFBa0IsQ0FBQyJ9