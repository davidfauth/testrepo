"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-10-09.
 */
const _ = require("lodash");
const umd_1 = require("linkurious-shared/umd");
const LKE = require("../../services");
const Utils = LKE.getUtils();
const Log = LKE.getLogger(__filename);
const CypherConnector = require('./cypherConnector');
var ADVANCED_TYPES;
(function (ADVANCED_TYPES) {
    ADVANCED_TYPES[ADVANCED_TYPES["DATE"] = 0] = "DATE";
    ADVANCED_TYPES[ADVANCED_TYPES["TIME"] = 1] = "TIME";
    ADVANCED_TYPES[ADVANCED_TYPES["DATE_TIME"] = 2] = "DATE_TIME";
    ADVANCED_TYPES[ADVANCED_TYPES["DURATION"] = 3] = "DURATION";
    ADVANCED_TYPES[ADVANCED_TYPES["COORDINATES"] = 4] = "COORDINATES";
    ADVANCED_TYPES[ADVANCED_TYPES["UNKNOWN"] = 5] = "UNKNOWN";
})(ADVANCED_TYPES || (ADVANCED_TYPES = {}));
class Neo4jConnector extends CypherConnector {
    /**
     * @param graphOptions   GraphDAO options
     * @param [indexOptions] IndexDAO options (only if the type of the DAO is 'Index')
     */
    constructor(graphOptions, indexOptions) {
        super(graphOptions, indexOptions);
        const envUser = process.env.LINKURIOUS_NEO4J_USER;
        const envPassword = process.env.LINKURIOUS_NEO4J_PASSWORD;
        if (Utils.hasValue(envUser) &&
            Utils.hasValue(envPassword) &&
            Utils.noValue(graphOptions.user) &&
            Utils.noValue(graphOptions.password)) {
            Log.info('Using Neo4j credentials from environment variables.');
            graphOptions.user = envUser;
            graphOptions.password = envPassword;
        }
    }
    /**
     * Do an HTTP POST request toward Neo4j.
     *
     * Used to create a case insensitive Neo4j search index.
     *
     * @param url
     * @param parameters
     * @param expectedStatusCode
     */
    $doHTTPPostRequest(url, parameters, expectedStatusCode) {
        return Utils.NOT_IMPLEMENTED();
    }
    /**
     * Do an HTTP GET request toward Neo4j. Return the body of the response directly.
     *
     * Used to retrieve the simple schema before procedures were introduced.
     *
     * @param url
     */
    $doHTTPGetRequest(url) {
        return Utils.NOT_IMPLEMENTED();
    }
    /**
     * Do an HTTP GET stream request toward Neo4j.
     *
     * @param url
     */
    $doHTTPGetStreamRequest(url) {
        return Utils.NOT_IMPLEMENTED();
    }
    /**
     * Query JMX management data of Neo4j by domain, name and key.
     *
     * @param domain
     * @param name
     * @param [key]
     */
    $queryJmx(domain, name, key) {
        return Utils.NOT_IMPLEMENTED();
    }
    /**
     * Detect the current store ID.
     *
     * A store ID is the name of the current database (if the graph server is multi-tenant)
     * otherwise the vendor name.
     */
    $getStoreId() {
        return this.$queryJmx('org.neo4j', 'instance=kernel#0,name=Kernel', 'StoreId');
    }
    /**
     * Detect the Neo4j type from a serialized value.
     *
     * @param value
     */
    static detectObjectType(value) {
        const year = _.get(value, 'year.low', false);
        const hour = _.get(value, 'hour.low', false);
        if (year && hour) {
            return ADVANCED_TYPES.DATE_TIME;
        }
        if (year) {
            return ADVANCED_TYPES.DATE;
        }
        if (hour) {
            return ADVANCED_TYPES.TIME;
        }
        if (_.has(value, 'crs.srid') || _.has(value, 'srid.low')) {
            return ADVANCED_TYPES.COORDINATES;
        }
        if (_.has(value, 'months') || _.has(value, 'seconds')) {
            return ADVANCED_TYPES.DURATION;
        }
        return ADVANCED_TYPES.UNKNOWN;
    }
    /**
     * Convert a Neo4j dateTime object to NativeDateTime.
     *
     * @param value
     */
    static toNativeDateTime(value) {
        const offsetSeconds = _.get(value, 'timeZoneOffsetSeconds.low');
        if (Utils.hasValue(value.timeZoneId)) {
            Log.warn('Neo4j datetime with political timezone are not supported ' +
                'and they are treated as UTC+0 dates. Detected timezone: ' +
                value.timeZoneId);
        }
        return new umd_1.NativeDateTime(Date.UTC(_.get(value, 'year.low', 0), _.get(value, 'month.low', 1) - 1, _.get(value, 'day.low', 1), _.get(value, 'hour.low', 0), _.get(value, 'minute.low', 0), _.get(value, 'second.low', 0)) -
            (offsetSeconds || 0) * 1000, Utils.hasValue(offsetSeconds));
    }
    /**
     * Convert a Neo4j dateTime object to NativeDate.
     *
     * @param value
     */
    static toNativeDate(value) {
        return new umd_1.NativeDate(Date.UTC(_.get(value, 'year.low', 0), _.get(value, 'month.low', 1) - 1, _.get(value, 'day.low', 1)));
    }
    /**
     * Convert a Neo4j object to string.
     *
     * @param value
     */
    static $encodeObject(value) {
        const dataType = Neo4jConnector.detectObjectType(value);
        if (dataType === ADVANCED_TYPES.DATE) {
            return Neo4jConnector.toNativeDate(value);
        }
        if (dataType === ADVANCED_TYPES.DATE_TIME) {
            return Neo4jConnector.toNativeDateTime(value);
        }
        return dataType;
    }
    /**
     * Encode a property value from Neo4j.
     *
     * @param rawProperty
     */
    $encodeProperty(rawProperty) {
        if (!_.isObject(rawProperty)) {
            // value is a primitive type
            return rawProperty;
        }
        if (Array.isArray(rawProperty)) {
            return rawProperty.map(this.$encodeProperty.bind(this));
        }
        return Neo4jConnector.$encodeObject(rawProperty);
    }
    /**
     * Extract offset from neo4j error message.
     *
     * @param errorMessage
     */
    extractErrorOffset(errorMessage) {
        // offset information looks like (line 1, column 15 (offset: 14))
        const offsetRx = /[(]line \d+, column \d+ [(]offset: (\d+)[)]{2}$/g;
        // offset information is usually at the end of the first line of the error message
        const match = offsetRx.exec(errorMessage.split('\n')[0]);
        if (match !== null) {
            return Number.parseInt(match[1], 10);
        }
    }
}
module.exports = Neo4jConnector;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmVvNGpDb25uZWN0b3IuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2Nvbm5lY3Rvci9uZW80akNvbm5lY3Rvci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7O0dBS0c7QUFLSCw0QkFBNEI7QUFDNUIsK0NBQWlFO0FBSWpFLHNDQUF1QztBQUN2QyxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxHQUFHLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUN0QyxNQUFNLGVBQWUsR0FBRyxPQUFPLENBQUMsbUJBQW1CLENBQW9CLENBQUM7QUFFeEUsSUFBSyxjQU9KO0FBUEQsV0FBSyxjQUFjO0lBQ2pCLG1EQUFJLENBQUE7SUFDSixtREFBSSxDQUFBO0lBQ0osNkRBQVMsQ0FBQTtJQUNULDJEQUFRLENBQUE7SUFDUixpRUFBVyxDQUFBO0lBQ1gseURBQU8sQ0FBQTtBQUNULENBQUMsRUFQSSxjQUFjLEtBQWQsY0FBYyxRQU9sQjtBQUVELE1BQWUsY0FBZSxTQUFRLGVBQWU7SUFDbkQ7OztPQUdHO0lBQ0gsWUFBWSxZQUFvQyxFQUFFLFlBQXFDO1FBQ3JGLEtBQUssQ0FBQyxZQUFZLEVBQUUsWUFBWSxDQUFDLENBQUM7UUFFbEMsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsQ0FBQztRQUNsRCxNQUFNLFdBQVcsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLHlCQUF5QixDQUFDO1FBQzFELElBQ0UsS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7WUFDdkIsS0FBSyxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUM7WUFDM0IsS0FBSyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDO1lBQ2hDLEtBQUssQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxFQUNwQztZQUNBLEdBQUcsQ0FBQyxJQUFJLENBQUMscURBQXFELENBQUMsQ0FBQztZQUNoRSxZQUFZLENBQUMsSUFBSSxHQUFHLE9BQU8sQ0FBQztZQUM1QixZQUFZLENBQUMsUUFBUSxHQUFHLFdBQVcsQ0FBQztTQUNyQztJQUNILENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNJLGtCQUFrQixDQUN2QixHQUFXLEVBQ1gsVUFBbUIsRUFDbkIsa0JBQTRCO1FBRTVCLE9BQU8sS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQ2pDLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSSxpQkFBaUIsQ0FBQyxHQUFXO1FBQ2xDLE9BQU8sS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQ2pDLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ksdUJBQXVCLENBQUMsR0FBVztRQUN4QyxPQUFPLEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUNqQyxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0ksU0FBUyxDQUFDLE1BQWMsRUFBRSxJQUFZLEVBQUUsR0FBWTtRQUN6RCxPQUFPLEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUNqQyxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxXQUFXO1FBQ2hCLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsK0JBQStCLEVBQUUsU0FBUyxDQUU1RSxDQUFDO0lBQ0osQ0FBQztJQUVEOzs7O09BSUc7SUFDSyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsS0FBYztRQUM1QyxNQUFNLElBQUksR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDN0MsTUFBTSxJQUFJLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsVUFBVSxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRTdDLElBQUksSUFBSSxJQUFJLElBQUksRUFBRTtZQUNoQixPQUFPLGNBQWMsQ0FBQyxTQUFTLENBQUM7U0FDakM7UUFFRCxJQUFJLElBQUksRUFBRTtZQUNSLE9BQU8sY0FBYyxDQUFDLElBQUksQ0FBQztTQUM1QjtRQUVELElBQUksSUFBSSxFQUFFO1lBQ1IsT0FBTyxjQUFjLENBQUMsSUFBSSxDQUFDO1NBQzVCO1FBRUQsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxVQUFVLENBQUMsRUFBRTtZQUN4RCxPQUFPLGNBQWMsQ0FBQyxXQUFXLENBQUM7U0FDbkM7UUFFRCxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLFNBQVMsQ0FBQyxFQUFFO1lBQ3JELE9BQU8sY0FBYyxDQUFDLFFBQVEsQ0FBQztTQUNoQztRQUVELE9BQU8sY0FBYyxDQUFDLE9BQU8sQ0FBQztJQUNoQyxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNLLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxLQUE2QjtRQUMzRCxNQUFNLGFBQWEsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSwyQkFBMkIsQ0FBVyxDQUFDO1FBRTFFLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLEVBQUU7WUFDcEMsR0FBRyxDQUFDLElBQUksQ0FDTiwyREFBMkQ7Z0JBQ3pELDBEQUEwRDtnQkFDMUQsS0FBSyxDQUFDLFVBQVUsQ0FDbkIsQ0FBQztTQUNIO1FBRUQsT0FBTyxJQUFJLG9CQUFjLENBQ3ZCLElBQUksQ0FBQyxHQUFHLENBQ04sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsVUFBVSxFQUFFLENBQUMsQ0FBVyxFQUNwQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxXQUFXLEVBQUUsQ0FBQyxDQUFZLEdBQUcsQ0FBQyxFQUM1QyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFXLEVBQ3BDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLFVBQVUsRUFBRSxDQUFDLENBQVcsRUFDckMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsWUFBWSxFQUFFLENBQUMsQ0FBVyxFQUN2QyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxZQUFZLEVBQUUsQ0FBQyxDQUFXLENBQ3hDO1lBQ0MsQ0FBQyxhQUFhLElBQUksQ0FBQyxDQUFDLEdBQUcsSUFBSSxFQUM3QixLQUFLLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxDQUM5QixDQUFDO0lBQ0osQ0FBQztJQUVEOzs7O09BSUc7SUFDSyxNQUFNLENBQUMsWUFBWSxDQUFDLEtBQTZCO1FBQ3ZELE9BQU8sSUFBSSxnQkFBVSxDQUNuQixJQUFJLENBQUMsR0FBRyxDQUNOLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLFVBQVUsRUFBRSxDQUFDLENBQVcsRUFDcEMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsV0FBVyxFQUFFLENBQUMsQ0FBWSxHQUFHLENBQUMsRUFDNUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsU0FBUyxFQUFFLENBQUMsQ0FBVyxDQUNyQyxDQUNGLENBQUM7SUFDSixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNLLE1BQU0sQ0FBQyxhQUFhLENBQzFCLEtBQTZCO1FBRTdCLE1BQU0sUUFBUSxHQUFHLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUV4RCxJQUFJLFFBQVEsS0FBSyxjQUFjLENBQUMsSUFBSSxFQUFFO1lBQ3BDLE9BQU8sY0FBYyxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUMzQztRQUVELElBQUksUUFBUSxLQUFLLGNBQWMsQ0FBQyxTQUFTLEVBQUU7WUFDekMsT0FBTyxjQUFjLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDL0M7UUFFRCxPQUFPLFFBQVEsQ0FBQztJQUNsQixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNPLGVBQWUsQ0FBQyxXQUFvQjtRQUM1QyxJQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUM1Qiw0QkFBNEI7WUFDNUIsT0FBTyxXQUFXLENBQUM7U0FDcEI7UUFFRCxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDOUIsT0FBTyxXQUFXLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7U0FDekQ7UUFFRCxPQUFPLGNBQWMsQ0FBQyxhQUFhLENBQUMsV0FBcUMsQ0FBQyxDQUFDO0lBQzdFLENBQUM7SUFFRDs7OztPQUlHO0lBQ08sa0JBQWtCLENBQUMsWUFBb0I7UUFDL0MsaUVBQWlFO1FBQ2pFLE1BQU0sUUFBUSxHQUFHLGtEQUFrRCxDQUFDO1FBQ3BFLGtGQUFrRjtRQUNsRixNQUFNLEtBQUssR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN6RCxJQUFJLEtBQUssS0FBSyxJQUFJLEVBQUU7WUFDbEIsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztTQUN0QztJQUNILENBQUM7Q0FDRjtBQUVELGlCQUFTLGNBQWMsQ0FBQyJ9