/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-10-09.
 */
'use strict';
const _ = require('lodash');
const through = require('through');
const Promise = require('bluebird');
const LKE = require('../../services');
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
const Log = LKE.getLogger(__filename);
const JsonStream = require('../../../lib/JsonStream');
const Neo4jConnector = require('./neo4jConnector');
const LkRequest = require('../../lib/LkRequest');
const CypherUtils = require('./../utils/cypherUtils');
const { GraphRequestTimeout, Vendor } = require('../../models/errors/GraphRequestTimeout');
class Neo4jHTTPConnector extends Neo4jConnector {
    /**
     * @param {any} graphOptions   GraphDAO options
     * @param {any} [indexOptions] IndexDAO options (only if the type of the DAO is 'Index')
     */
    constructor(graphOptions, indexOptions) {
        super(graphOptions, indexOptions);
        this.$httpUrl = Utils.normalizeUrl(this.getGraphOption('url'));
        this.$request = new LkRequest({
            strictSSL: !this.getGraphOption('allowSelfSigned'),
            auth: this.getGraphOption('user') ? {
                user: this.getGraphOption('user'),
                password: this.getGraphOption('password')
            } : undefined,
            proxy: this.getGraphOption('proxy'),
            pool: { maxSockets: 5 },
            json: true,
            gzip: true
        });
    }
    /**
     * Connect to the remote server.
     *
     * @returns {Bluebird<string>} resolved with the SemVer version of the remote server
     */
    $connect() {
        // The request is explicitly towards /db/data/ and not /db/data due to a GrapheneDB bug #1201
        return this.$request.get(this.$httpUrl + '/db/data/', {}, [200, 401, 403]).then(response => {
            if (response.statusCode === 401 || response.statusCode === 403) {
                return Errors.business('invalid_parameter', 'Please check the Neo4j username and password in the configuration.', true);
            }
            // check version
            this.version = response.body['neo4j_version'];
            if (Utils.noValue(this.version)) {
                return Errors.technical('critical', 'Cannot get Neo4j version.', true);
            }
            return this.version;
        });
    }
    /**
     * Encode a record from Neo4j in a valid response for Linkurious.
     *
     * @param {any} record
     * @private
     * @returns {{nodes: LkNode[], edges: LkEdge[], rows: any[]}}
     */
    _encodeHTTPResponseRecord(record) {
        // for every node and edge in the graph response we parse it and set it in a map (for nodes or edges)
        // we need the graph response because the row response doesn't contain all the info we need
        // (like the edge source and target or the labels)
        const nodesById = new Map();
        for (let i = 0; i < record.graph.nodes.length; i++) {
            const node = record.graph.nodes[i];
            if (node.deleted) {
                // node was deleted and a deleted node doesn't have labels and properties
                node.labels = [];
            }
            // We ignore nodes with no categories
            if (node.labels.length > 0) {
                // node.id (as sent by Neo4j) is a string in HTTP responses
                nodesById.set(node.id, {
                    id: node.id,
                    categories: node.labels.sort(),
                    tolerateIsoStringAsNativeDate: true,
                    data: _.mapValues(node.properties, this.$encodeProperty.bind(this))
                });
            }
        }
        const edgesById = new Map();
        for (let i = 0; i < record.graph.relationships.length; i++) {
            // edge.id (as sent by Neo4j) is a string in HTTP responses
            const edge = record.graph.relationships[i];
            edgesById.set(edge.id, {
                id: edge.id,
                source: edge.startNode,
                target: edge.endNode,
                type: edge.type,
                tolerateIsoStringAsNativeDate: true,
                data: _.mapValues(edge.properties, this.$encodeProperty.bind(this))
            });
        }
        return {
            nodes: Array.from(nodesById.values()),
            edges: Array.from(edgesById.values()),
            rows: record.row
        };
    }
    /**
     * @private
     */
    get _writeUrl() {
        return Utils.hasValue(this.getGraphOption('writeUrl'))
            ? Utils.normalizeUrl(this.getGraphOption('writeUrl'))
            : this.$httpUrl;
    }
    /**
     * Do an HTTP POST request toward Neo4j.
     *
     * Used to create a case insensitive Neo4j search index.
     *
     * @param {string}   url
     * @param {any}      parameters
     * @param {number[]} expectedStatusCode
     * @returns {Bluebird<IncomingMessage>}
     */
    $doHTTPPostRequest(url, parameters, expectedStatusCode) {
        return this.$request.post(url, {
            baseUrl: this.$httpUrl,
            body: parameters
        }, expectedStatusCode);
    }
    /**
     * Do an HTTP GET request toward Neo4j. Return the body of the response directly.
     *
     * Used to retrieve the simple schema before procedures were introduced.
     *
     * @param {string} url
     * @returns {Bluebird<any>}
     */
    $doHTTPGetRequest(url) {
        return this.$request.get(url, {
            baseUrl: this.$httpUrl
        }, [200]).get('body');
    }
    /**
     * Do an HTTP GET stream request toward Neo4j.
     *
     * @param {string} url
     * @returns {Bluebird<Readable<Buffer>>}
     */
    $doHTTPGetStreamRequest(url) {
        return this.$request.getStream(url, 'get', {
            baseUrl: this.$httpUrl
        }, [200]);
    }
    /**
     * Execute a cypher query on Neo4j.
     *
     * Note that this function is not meant for user queries.
     * We don't enforce a limit or check if the query contains write statements.
     * Use $safeCypherQueryStream instead.
     *
     * @param {string}  query        The graph query
     * @param {object}  [parameters] The graph query parameters
     * @param {boolean} [ignoreSlow] Don't log slow requests
     * @returns {Bluebird<{keys: string[], results: Array<{nodes: LkNode[], edges: LkEdge[], rows: any[]}>}>}
     */
    $doCypherQuery(query, parameters, ignoreSlow) {
        const willWrite = CypherUtils.isWrite(query);
        const baseUrl = willWrite ? this._writeUrl : this.$httpUrl;
        const t0 = Date.now();
        return this.$request.post('/db/data/transaction/commit', {
            baseUrl: baseUrl,
            body: {
                statements: [{
                        statement: query,
                        parameters: parameters,
                        resultDataContents: ['row', 'graph']
                    }]
            }
        }, [200]).then(response => {
            if (Utils.hasValue(response.body.errors) && response.body.errors.length > 0) {
                let errorMessage = Utils.safeGet(response.body, 'errors.0.message');
                const errorCode = Utils.safeGet(response.body, 'errors.0.code');
                // Neo4j has multiple Constraint violation errors (depending on the version):
                // - Neo.ClientError.Schema.ConstraintValidationFailed
                // - Neo.ClientError.Schema.ConstraintViolation
                if (Utils.hasValue(errorCode) && errorCode.includes('Constraint')) {
                    return Errors.business('constraint_violation', 'Constraint violation: ' + errorMessage, true);
                }
                // Query timeout
                // - Neo.ClientError.Transaction.TransactionTimedOut
                if (_.includes(errorCode, 'TimedOut')) {
                    throw new GraphRequestTimeout(Vendor.NEO4J);
                }
                // Neo4j has multiple Syntax errors (depending on the version):
                // - Neo.ClientError.Statement.InvalidSyntax
                // - Neo.ClientError.Statement.SyntaxError
                const isBadGraphRequest = Utils.hasValue(errorCode) && errorCode.includes('Syntax');
                errorMessage = 'Neo4j (HTTP) wasn\'t able to execute the query: ' + errorMessage;
                if (isBadGraphRequest) {
                    const offset = this.extractErrorOffset(errorMessage);
                    if (Utils.hasValue(offset)) {
                        return Errors.business('bad_graph_request', errorMessage, true, { offset: offset });
                    }
                    return Errors.business('bad_graph_request', errorMessage, true);
                }
                return Errors.technical('critical', errorMessage, true);
            }
            // if no record is found, we don't return anything, including the keys
            if (Utils.noValue(response.body.results[0]) || Utils.noValue(response.body.results[0].data[0])) {
                return {
                    keys: [],
                    results: []
                };
            }
            return {
                keys: response.body.results[0].columns,
                results: response.body.results[0].data.map(record => this._encodeHTTPResponseRecord(record))
            };
        }).catch(error => {
            if (error.key === 'socket_error') {
                throw Errors.business('dataSource_unavailable', 'Request to graph server failed: ' + error.message);
            }
            throw error;
        }).finally(() => {
            if (ignoreSlow) {
                return;
            }
            Utils.logSlow(t0, this.SLOW_QUERY_THRESHOLD, 'Query (HTTP): ' + query, Log);
        });
    }
    /**
     * Execute `func` under a transaction.
     * `func` will be invoke with two arguments:
     * - transactionURL
     * - rollback function
     *
     * @param {boolean}                              willWrite
     * @param {function(string, any): Bluebird<any>} func
     * @returns {Bluebird<any>}
     */
    _underTransaction(willWrite, func) {
        const baseUrl = (willWrite ? this._writeUrl : this.$httpUrl);
        return this.$request.post('/db/data/transaction', {
            baseUrl: baseUrl,
            body: {
                statements: []
            }
        }, [201]).then(response => {
            const transactionURL = response.headers.location;
            if (!transactionURL) {
                return Errors.business('graph_request_timeout', 'Failed to start transaction.', true);
            }
            return func(transactionURL, () => {
                // rollback function
                return this.$request.delete('/db/data/transaction', {
                    baseUrl: baseUrl
                    // HTTP status code 405 occurs after the transaction timed out in Neo4j
                }, [200, 405]).catch(e => {
                    Log.debug('Failed to delete transaction: ' + e.message);
                });
            });
        });
    }
    /**
     * Query JMX management data of Neo4j by domain, name and key.
     *
     * @param {string} domain
     * @param {string} name
     * @param {string} [key]
     * @returns {Bluebird<any>}
     */
    $queryJmx(domain, name, key) {
        const path = '/db/manage/server/jmx/domain/' + encodeURIComponent(domain) + '/' +
            encodeURIComponent(name);
        return this.$request.get(path, {
            baseUrl: this.$httpUrl
        }, [200]).then(response => {
            const items = _.fromPairs(Utils.safeGet(response.body, '0.attributes').map(i => [i.name, i.value]));
            if (Utils.noValue(key)) {
                return items;
            }
            if (Utils.noValue(items[key])) {
                return Errors.technical('critical', `Cannot get '${key}' (missing field)`, true);
            }
            return items[key];
        });
    }
    /**
     * @param {{code: string, message: string}} error
     * @returns {LkError}
     * @private
     */
    _parseError(error) {
        // Client statement and procedure errors are considered as bad graph request. eg.:
        // Neo.ClientError.Procedure.ProcedureCallFailed
        // Neo.ClientError.Statement.ArithmeticError
        const isBadGraphRequest = /.*ClientError[.](Statement|Procedure).*/.test(error.code);
        if (!isBadGraphRequest) {
            const message = `Unexpected Neo4j response: ${error.message}`;
            return Errors.technical('critical', message);
        }
        const offset = this.extractErrorOffset(error.message);
        const errorHighlight = Utils.hasValue(offset) ? { offset: offset } : undefined;
        const message = `Neo4j wasn't able to execute the cypher query: ${error.message}`;
        return Errors.business('bad_graph_request', message, false, errorHighlight);
    }
    /**
     * Execute a cypher query on Neo4j and return a stream as a result.
     * If `limit` is defined, the limit of the Cypher query is modified to not be higher
     * than `limit`.
     *
     * @param {string[]} queries      The graph queries
     * @param {object}   [parameters] The graph query parameters
     * @param {number}   [limit]      Maximum number of matched subgraphs
     * @returns {Bluebird<{keys: string[], results: Readable<{nodes: LkNode[], edges: LkEdge[], rows: any[]}>}>}
     */
    $safeCypherQueryStream(queries, parameters, limit = Infinity) {
        const willWrite = _.some(queries, query => CypherUtils.checkQuery(query));
        return this._underTransaction(willWrite, (transactionUrl, rollback) => {
            // run the original query using the transaction URL (autocommit)
            const autoCommitUrl = transactionUrl + '/commit';
            // Stream request of the data
            return this.$request.getStream(autoCommitUrl, 'post', {
                body: {
                    statements: queries.map(query => ({
                        statement: query,
                        resultDataContents: ['row', 'graph']
                    }))
                }
            }, [200]).then(readableStream => {
                const self = this;
                return new Promise((resolve, reject) => {
                    const jsonStream = Utils.safePipe(readableStream, JsonStream.parse(['results', '*', 'data', '*'], ['results', 0, 'columns'], ['errors', '*']));
                    // We assume that the initial chunk is the columns. Otherwise we reject.
                    jsonStream.once('data', initialChunk => {
                        const parseError = this._parseError.bind(this);
                        if (!Array.isArray(initialChunk)) {
                            if (Utils.hasValue(initialChunk.code)) {
                                reject(parseError(initialChunk));
                            }
                            reject(Errors.technical('critical', 'Unexpected Neo4j response, "results.columns" is not defined, received data: ' +
                                initialChunk));
                        }
                        const recordStream = through(function (record) {
                            if (Utils.hasValue(record.code)) {
                                this.emit('error', parseError(record));
                            }
                            else if (Utils.noValue(record.graph) || Utils.noValue(record.graph.nodes) ||
                                Utils.noValue(record.graph.relationships) || Utils.noValue(record.row)) {
                                // This is our best hint that Neo4j timedout:
                                // The JSON is properly closed but the data is missing.
                                // At the end of the HTTP response there should be the reason of the error but
                                // it's not easy to access from within the stream that goes through a JsonStream
                                this.emit('error', new GraphRequestTimeout(Vendor.NEO4J));
                            }
                            else {
                                this.queue(self._encodeHTTPResponseRecord(record));
                            }
                        });
                        // Abort the http request (close the socket)
                        const abortRequestJs = readableStream.abort.bind(readableStream);
                        const streamCap = Utils.capStream(limit, () => {
                            abortRequestJs();
                            if (willWrite) {
                                // when write queries are aborted, all changes are rolled back
                                // we fail the query because we know changes will not be persisted
                                streamCap.emit('error', Errors.business('bad_graph_request', `The write query involved more than ${limit} results. No change was applied.`));
                            }
                        });
                        // We want the filter one specific error from jsonStream which is the consequence of
                        // aborting before the end of the json stream.
                        recordStream.on('error', error => {
                            if (!error.message.includes('Unexpected JSON stream end')) {
                                streamCap.emit('error', error);
                            }
                        });
                        // Abort the http request and rollback the transaction
                        streamCap.abort = () => {
                            abortRequestJs();
                            rollback();
                        };
                        // TODO #1565 Use TransformedStream
                        // Warning: pausing the stream at the source is necessary,
                        // otherwise it will keep emitting data and middle streams
                        // can use this data to emit an error while the returned stream is paused
                        // and no error handler is registered, resulting in the application crashing
                        readableStream.pause();
                        jsonStream.pause();
                        resolve({
                            keys: initialChunk,
                            // We have to resolve with a paused stream because the stream is already in flowing mode
                            results: Utils.safePipe(jsonStream, recordStream).pipe(streamCap).pause()
                        });
                    }).resume();
                });
            });
        }).catch(error => {
            if (error.key === 'socket_error') {
                throw Errors.business('dataSource_unavailable', 'Request to graph server failed: ' + error.message);
            }
            throw error;
        });
    }
}
module.exports = Neo4jHTTPConnector;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmVvNGpIVFRQQ29ubmVjdG9yLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL2Rhby9jb25uZWN0b3IvbmVvNGpIVFRQQ29ubmVjdG9yLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBQ2IsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUNuQyxNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDcEMsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUM7QUFDdEMsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzdCLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3RDLE1BQU0sVUFBVSxHQUFHLE9BQU8sQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO0FBQ3RELE1BQU0sY0FBYyxHQUFHLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0FBQ25ELE1BQU0sU0FBUyxHQUFHLE9BQU8sQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO0FBQ2pELE1BQU0sV0FBVyxHQUFHLE9BQU8sQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO0FBQ3RELE1BQU0sRUFBQyxtQkFBbUIsRUFBRSxNQUFNLEVBQUMsR0FBRyxPQUFPLENBQUMseUNBQXlDLENBQUMsQ0FBQztBQUV6RixNQUFNLGtCQUFtQixTQUFRLGNBQWM7SUFFN0M7OztPQUdHO0lBQ0gsWUFBWSxZQUFZLEVBQUUsWUFBWTtRQUNwQyxLQUFLLENBQUMsWUFBWSxFQUFFLFlBQVksQ0FBQyxDQUFDO1FBRWxDLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7UUFFL0QsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLFNBQVMsQ0FBQztZQUM1QixTQUFTLEVBQUUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLGlCQUFpQixDQUFDO1lBQ2xELElBQUksRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDbEMsSUFBSSxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDO2dCQUNqQyxRQUFRLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUM7YUFDMUMsQ0FBQyxDQUFDLENBQUMsU0FBUztZQUNiLEtBQUssRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQztZQUNuQyxJQUFJLEVBQUUsRUFBQyxVQUFVLEVBQUUsQ0FBQyxFQUFDO1lBQ3JCLElBQUksRUFBRSxJQUFJO1lBQ1YsSUFBSSxFQUFFLElBQUk7U0FDWCxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILFFBQVE7UUFDTiw2RkFBNkY7UUFDN0YsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsUUFBUSxHQUFHLFdBQVcsRUFBRSxFQUFFLEVBQUUsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ3pGLElBQUksUUFBUSxDQUFDLFVBQVUsS0FBSyxHQUFHLElBQUksUUFBUSxDQUFDLFVBQVUsS0FBSyxHQUFHLEVBQUU7Z0JBQzlELE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FDcEIsbUJBQW1CLEVBQ25CLG9FQUFvRSxFQUNwRSxJQUFJLENBQ0wsQ0FBQzthQUNIO1lBRUQsZ0JBQWdCO1lBQ2hCLElBQUksQ0FBQyxPQUFPLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztZQUM5QyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFO2dCQUMvQixPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLDJCQUEyQixFQUFFLElBQUksQ0FBQyxDQUFDO2FBQ3hFO1lBRUQsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDO1FBQ3RCLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILHlCQUF5QixDQUFDLE1BQU07UUFDOUIscUdBQXFHO1FBQ3JHLDJGQUEyRjtRQUMzRixrREFBa0Q7UUFFbEQsTUFBTSxTQUFTLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQztRQUM1QixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ2xELE1BQU0sSUFBSSxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ25DLElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRTtnQkFDaEIseUVBQXlFO2dCQUN6RSxJQUFJLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQzthQUNsQjtZQUVELHFDQUFxQztZQUNyQyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtnQkFDMUIsMkRBQTJEO2dCQUMzRCxTQUFTLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUU7b0JBQ3JCLEVBQUUsRUFBRSxJQUFJLENBQUMsRUFBRTtvQkFDWCxVQUFVLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUU7b0JBQzlCLDZCQUE2QixFQUFFLElBQUk7b0JBQ25DLElBQUksRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7aUJBQ3BFLENBQUMsQ0FBQzthQUNKO1NBQ0Y7UUFDRCxNQUFNLFNBQVMsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBQzVCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDMUQsMkRBQTJEO1lBQzNELE1BQU0sSUFBSSxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzNDLFNBQVMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRTtnQkFDckIsRUFBRSxFQUFFLElBQUksQ0FBQyxFQUFFO2dCQUNYLE1BQU0sRUFBRSxJQUFJLENBQUMsU0FBUztnQkFDdEIsTUFBTSxFQUFFLElBQUksQ0FBQyxPQUFPO2dCQUNwQixJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUk7Z0JBQ2YsNkJBQTZCLEVBQUUsSUFBSTtnQkFDbkMsSUFBSSxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUNwRSxDQUFDLENBQUM7U0FDSjtRQUVELE9BQU87WUFDTCxLQUFLLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDckMsS0FBSyxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ3JDLElBQUksRUFBRSxNQUFNLENBQUMsR0FBRztTQUNqQixDQUFDO0lBQ0osQ0FBQztJQUVEOztPQUVHO0lBQ0gsSUFBSSxTQUFTO1FBQ1gsT0FBTyxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDcEQsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUNyRCxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztJQUNwQixDQUFDO0lBRUQ7Ozs7Ozs7OztPQVNHO0lBQ0gsa0JBQWtCLENBQUMsR0FBRyxFQUFFLFVBQVUsRUFBRSxrQkFBa0I7UUFDcEQsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDN0IsT0FBTyxFQUFFLElBQUksQ0FBQyxRQUFRO1lBQ3RCLElBQUksRUFBRSxVQUFVO1NBQ2pCLEVBQUUsa0JBQWtCLENBQUMsQ0FBQztJQUN6QixDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILGlCQUFpQixDQUFDLEdBQUc7UUFDbkIsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUU7WUFDNUIsT0FBTyxFQUFFLElBQUksQ0FBQyxRQUFRO1NBQ3ZCLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUN4QixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCx1QkFBdUIsQ0FBQyxHQUFHO1FBQ3pCLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRTtZQUN6QyxPQUFPLEVBQUUsSUFBSSxDQUFDLFFBQVE7U0FDdkIsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFDWixDQUFDO0lBRUQ7Ozs7Ozs7Ozs7O09BV0c7SUFDSCxjQUFjLENBQUMsS0FBSyxFQUFFLFVBQVUsRUFBRSxVQUFVO1FBQzFDLE1BQU0sU0FBUyxHQUFHLFdBQVcsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDN0MsTUFBTSxPQUFPLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDO1FBRTNELE1BQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUN0QixPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLDZCQUE2QixFQUFFO1lBQ3ZELE9BQU8sRUFBRSxPQUFPO1lBQ2hCLElBQUksRUFBRTtnQkFDSixVQUFVLEVBQUUsQ0FBQzt3QkFDWCxTQUFTLEVBQUUsS0FBSzt3QkFDaEIsVUFBVSxFQUFFLFVBQVU7d0JBQ3RCLGtCQUFrQixFQUFFLENBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQztxQkFDckMsQ0FBQzthQUNIO1NBQ0YsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ3hCLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7Z0JBQzNFLElBQUksWUFBWSxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxrQkFBa0IsQ0FBQyxDQUFDO2dCQUNwRSxNQUFNLFNBQVMsR0FBRyxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsZUFBZSxDQUFDLENBQUM7Z0JBQ2hFLDZFQUE2RTtnQkFDN0Usc0RBQXNEO2dCQUN0RCwrQ0FBK0M7Z0JBQy9DLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsSUFBSSxTQUFTLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxFQUFFO29CQUNqRSxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsc0JBQXNCLEVBQzNDLHdCQUF3QixHQUFHLFlBQVksRUFBRSxJQUFJLENBQzlDLENBQUM7aUJBQ0g7Z0JBRUQsZ0JBQWdCO2dCQUNoQixvREFBb0Q7Z0JBQ3BELElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxTQUFTLEVBQUUsVUFBVSxDQUFDLEVBQUU7b0JBQ3JDLE1BQU0sSUFBSSxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7aUJBQzdDO2dCQUVELCtEQUErRDtnQkFDL0QsNENBQTRDO2dCQUM1QywwQ0FBMEM7Z0JBQzFDLE1BQU0saUJBQWlCLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsSUFBSSxTQUFTLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUVwRixZQUFZLEdBQUcsa0RBQWtELEdBQUcsWUFBWSxDQUFDO2dCQUNqRixJQUFJLGlCQUFpQixFQUFFO29CQUNyQixNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxDQUFDLENBQUM7b0JBQ3JELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRTt3QkFDMUIsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLG1CQUFtQixFQUFFLFlBQVksRUFBRSxJQUFJLEVBQUUsRUFBQyxNQUFNLEVBQUUsTUFBTSxFQUFDLENBQUMsQ0FBQztxQkFDbkY7b0JBQ0QsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLG1CQUFtQixFQUFFLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQztpQkFDakU7Z0JBQ0QsT0FBTyxNQUFNLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxZQUFZLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDekQ7WUFFRCxzRUFBc0U7WUFDdEUsSUFDRSxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFDMUY7Z0JBQ0EsT0FBTztvQkFDTCxJQUFJLEVBQUUsRUFBRTtvQkFDUixPQUFPLEVBQUUsRUFBRTtpQkFDWixDQUFDO2FBQ0g7WUFFRCxPQUFPO2dCQUNMLElBQUksRUFBRSxRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO2dCQUN0QyxPQUFPLEVBQUUsUUFBUSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FDeEMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMseUJBQXlCLENBQUMsTUFBTSxDQUFDLENBQUM7YUFDcEQsQ0FBQztRQUNKLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUNmLElBQUksS0FBSyxDQUFDLEdBQUcsS0FBSyxjQUFjLEVBQUU7Z0JBQ2hDLE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FDbkIsd0JBQXdCLEVBQUUsa0NBQWtDLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FDN0UsQ0FBQzthQUNIO1lBRUQsTUFBTSxLQUFLLENBQUM7UUFDZCxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFO1lBQ2QsSUFBSSxVQUFVLEVBQUU7Z0JBQUUsT0FBTzthQUFFO1lBQzNCLEtBQUssQ0FBQyxPQUFPLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxnQkFBZ0IsR0FBRyxLQUFLLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDOUUsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7OztPQVNHO0lBQ0gsaUJBQWlCLENBQUMsU0FBUyxFQUFFLElBQUk7UUFDL0IsTUFBTSxPQUFPLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUU3RCxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLHNCQUFzQixFQUFFO1lBQ2hELE9BQU8sRUFBRSxPQUFPO1lBQ2hCLElBQUksRUFBRTtnQkFDSixVQUFVLEVBQUUsRUFBRTthQUNmO1NBQ0YsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ3hCLE1BQU0sY0FBYyxHQUFHLFFBQVEsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDO1lBRWpELElBQUksQ0FBQyxjQUFjLEVBQUU7Z0JBQ25CLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyx1QkFBdUIsRUFBRSw4QkFBOEIsRUFBRSxJQUFJLENBQUMsQ0FBQzthQUN2RjtZQUVELE9BQU8sSUFBSSxDQUFDLGNBQWMsRUFBRSxHQUFHLEVBQUU7Z0JBQy9CLG9CQUFvQjtnQkFDcEIsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsRUFBRTtvQkFDbEQsT0FBTyxFQUFFLE9BQU87b0JBQ2hCLHVFQUF1RTtpQkFDeEUsRUFBRSxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRTtvQkFDdkIsR0FBRyxDQUFDLEtBQUssQ0FBQyxnQ0FBZ0MsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQzFELENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsU0FBUyxDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsR0FBRztRQUN6QixNQUFNLElBQUksR0FBRywrQkFBK0IsR0FBRyxrQkFBa0IsQ0FBQyxNQUFNLENBQUMsR0FBRyxHQUFHO1lBQzdFLGtCQUFrQixDQUFDLElBQUksQ0FBQyxDQUFDO1FBRTNCLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFO1lBQzdCLE9BQU8sRUFBRSxJQUFJLENBQUMsUUFBUTtTQUN2QixFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDeEIsTUFBTSxLQUFLLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FDdkIsS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLGNBQWMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FDekUsQ0FBQztZQUVGLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRTtnQkFDdEIsT0FBTyxLQUFLLENBQUM7YUFDZDtZQUVELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRTtnQkFDN0IsT0FBTyxNQUFNLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxlQUFlLEdBQUcsbUJBQW1CLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDbEY7WUFFRCxPQUFPLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNwQixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsV0FBVyxDQUFDLEtBQUs7UUFDZixrRkFBa0Y7UUFDbEYsZ0RBQWdEO1FBQ2hELDRDQUE0QztRQUM1QyxNQUFNLGlCQUFpQixHQUFHLHlDQUF5QyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFckYsSUFBSSxDQUFDLGlCQUFpQixFQUFFO1lBQ3RCLE1BQU0sT0FBTyxHQUFHLDhCQUE4QixLQUFLLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDOUQsT0FBTyxNQUFNLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxPQUFPLENBQUMsQ0FBQztTQUM5QztRQUVELE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEQsTUFBTSxjQUFjLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxNQUFNLEVBQUUsTUFBTSxFQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztRQUU3RSxNQUFNLE9BQU8sR0FBRyxrREFBa0QsS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQ2xGLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLGNBQWMsQ0FBQyxDQUFDO0lBQzlFLENBQUM7SUFFRDs7Ozs7Ozs7O09BU0c7SUFDSCxzQkFBc0IsQ0FBQyxPQUFPLEVBQUUsVUFBVSxFQUFFLEtBQUssR0FBRyxRQUFRO1FBQzFELE1BQU0sU0FBUyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxFQUFFLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1FBRTFFLE9BQU8sSUFBSSxDQUFDLGlCQUFpQixDQUFDLFNBQVMsRUFBRSxDQUFDLGNBQWMsRUFBRSxRQUFRLEVBQUUsRUFBRTtZQUNwRSxnRUFBZ0U7WUFDaEUsTUFBTSxhQUFhLEdBQUcsY0FBYyxHQUFHLFNBQVMsQ0FBQztZQUVqRCw2QkFBNkI7WUFDN0IsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxhQUFhLEVBQUUsTUFBTSxFQUFFO2dCQUNwRCxJQUFJLEVBQUU7b0JBQ0osVUFBVSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDO3dCQUNoQyxTQUFTLEVBQUUsS0FBSzt3QkFDaEIsa0JBQWtCLEVBQUUsQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDO3FCQUNyQyxDQUFDLENBQUM7aUJBQ0o7YUFDRixFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLEVBQUU7Z0JBQzlCLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQztnQkFDbEIsT0FBTyxJQUFJLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsRUFBRTtvQkFDckMsTUFBTSxVQUFVLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxjQUFjLEVBQzlDLFVBQVUsQ0FBQyxLQUFLLENBQ2QsQ0FBQyxTQUFTLEVBQUUsR0FBRyxFQUFFLE1BQU0sRUFBRSxHQUFHLENBQUMsRUFDN0IsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxFQUN6QixDQUFDLFFBQVEsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBRXRCLHdFQUF3RTtvQkFDeEUsVUFBVSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsWUFBWSxDQUFDLEVBQUU7d0JBQ3JDLE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUMvQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsRUFBRTs0QkFDaEMsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsRUFBRTtnQ0FDckMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDOzZCQUNsQzs0QkFDRCxNQUFNLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQ2hDLDhFQUE4RTtnQ0FDaEYsWUFBWSxDQUFDLENBQUMsQ0FBQzt5QkFDaEI7d0JBRUQsTUFBTSxZQUFZLEdBQUcsT0FBTyxDQUFDLFVBQVMsTUFBTTs0QkFDMUMsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRTtnQ0FDL0IsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7NkJBQ3hDO2lDQUFNLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQztnQ0FDekUsS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxFQUFFO2dDQUN4RSw2Q0FBNkM7Z0NBQzdDLHVEQUF1RDtnQ0FDdkQsOEVBQThFO2dDQUM5RSxnRkFBZ0Y7Z0NBQ2hGLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksbUJBQW1CLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7NkJBQzNEO2lDQUFNO2dDQUNMLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLHlCQUF5QixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7NkJBQ3BEO3dCQUNILENBQUMsQ0FBQyxDQUFDO3dCQUVILDRDQUE0Qzt3QkFDNUMsTUFBTSxjQUFjLEdBQUcsY0FBYyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7d0JBRWpFLE1BQU0sU0FBUyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLEdBQUcsRUFBRTs0QkFDNUMsY0FBYyxFQUFFLENBQUM7NEJBQ2pCLElBQUksU0FBUyxFQUFFO2dDQUNiLDhEQUE4RDtnQ0FDOUQsa0VBQWtFO2dDQUNsRSxTQUFTLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsUUFBUSxDQUFDLG1CQUFtQixFQUN6RCxzQ0FBc0MsS0FBSyxrQ0FBa0MsQ0FBQyxDQUFDLENBQUM7NkJBQ25GO3dCQUNILENBQUMsQ0FBQyxDQUFDO3dCQUVILG9GQUFvRjt3QkFDcEYsOENBQThDO3dCQUM5QyxZQUFZLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsRUFBRTs0QkFDL0IsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLDRCQUE0QixDQUFDLEVBQUU7Z0NBQ3pELFNBQVMsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDOzZCQUNoQzt3QkFDSCxDQUFDLENBQUMsQ0FBQzt3QkFFSCxzREFBc0Q7d0JBQ3RELFNBQVMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxFQUFFOzRCQUNyQixjQUFjLEVBQUUsQ0FBQzs0QkFDakIsUUFBUSxFQUFFLENBQUM7d0JBQ2IsQ0FBQyxDQUFDO3dCQUVGLG1DQUFtQzt3QkFDbkMsMERBQTBEO3dCQUMxRCwwREFBMEQ7d0JBQzFELHlFQUF5RTt3QkFDekUsNEVBQTRFO3dCQUM1RSxjQUFjLENBQUMsS0FBSyxFQUFFLENBQUM7d0JBQ3ZCLFVBQVUsQ0FBQyxLQUFLLEVBQUUsQ0FBQzt3QkFFbkIsT0FBTyxDQUFDOzRCQUNOLElBQUksRUFBRSxZQUFZOzRCQUNsQix3RkFBd0Y7NEJBQ3hGLE9BQU8sRUFBRSxLQUFLLENBQUMsUUFBUSxDQUFDLFVBQVUsRUFBRSxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsS0FBSyxFQUFFO3lCQUMxRSxDQUFDLENBQUM7b0JBQ0wsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7Z0JBQ2QsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUNmLElBQUksS0FBSyxDQUFDLEdBQUcsS0FBSyxjQUFjLEVBQUU7Z0JBQ2hDLE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FDbkIsd0JBQXdCLEVBQUUsa0NBQWtDLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FDN0UsQ0FBQzthQUNIO1lBRUQsTUFBTSxLQUFLLENBQUM7UUFDZCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsa0JBQWtCLENBQUMifQ==