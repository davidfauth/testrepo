"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2018-10-08.
 */
// TODO #1424 implement and use DaoOptions
//
// abstract class DaoOptions<T> {
//   public options: T;
//   private allowed: Array<keyof T>;
//   private required: Array<keyof T>;
//
//   constructor(options: T, allowed: Array<keyof T>, required: Array<keyof T>) {
//     this.options = options;
//     this.required = required;
//     this.allowed = allowed;
//   }
//
//   public check(): void {
//     // check allowed
//     // check required
//   }
// }
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGFvT3B0aW9ucy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NlcnZlci9kYW8vZGFvT3B0aW9ucy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7O0dBS0c7QUFFSCwwQ0FBMEM7QUFDMUMsRUFBRTtBQUNGLGlDQUFpQztBQUNqQyx1QkFBdUI7QUFDdkIscUNBQXFDO0FBQ3JDLHNDQUFzQztBQUN0QyxFQUFFO0FBQ0YsaUZBQWlGO0FBQ2pGLDhCQUE4QjtBQUM5QixnQ0FBZ0M7QUFDaEMsOEJBQThCO0FBQzlCLE1BQU07QUFDTixFQUFFO0FBQ0YsMkJBQTJCO0FBQzNCLHVCQUF1QjtBQUN2Qix3QkFBd0I7QUFDeEIsTUFBTTtBQUNOLElBQUkifQ==