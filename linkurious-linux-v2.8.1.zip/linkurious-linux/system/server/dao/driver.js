"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-09-05.
 */
const Bluebird = require("bluebird");
const LKE = require("../services");
const Utils = LKE.getUtils();
class Driver {
    /**
     * @param connector     Connector used by the DAO
     * @param graphOptions  GraphDAO options
     * @param connectorData Data from the connector
     */
    constructor(connector, graphOptions, connectorData) {
        this.connector = connector;
        this.graphOptions = graphOptions;
        this.connectorData = connectorData;
    }
    /**
     * Return a Connector data by key (or a default value if undefined or null).
     *
     * @param key            Option key
     * @param [defaultValue] Default value
     */
    getConnectorData(key, defaultValue) {
        const value = this.connectorData[key];
        return Utils.hasValue(value) ? value : defaultValue;
    }
    /**
     * Return a GraphDAO option by key (or a default value if undefined or null).
     *
     * @param key            Option key
     * @param [defaultValue] Default value
     */
    getGraphOption(key, defaultValue) {
        const value = this.graphOptions[key];
        return Utils.hasValue(value) ? value : defaultValue;
    }
    /**
     * Called at the end of the indexation phase for additional initializations.
     *
     * Optional to implement.
     */
    $onAfterIndexation() {
        return Bluebird.resolve();
    }
    /**
     * Called at the end of the connect phase for additional initializations.
     *
     * Optional to implement.
     */
    $onAfterConnect() {
        return Bluebird.resolve();
    }
}
exports.Driver = Driver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHJpdmVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc2VydmVyL2Rhby9kcml2ZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQTs7Ozs7R0FLRztBQUNILHFDQUFxQztBQUlyQyxtQ0FBb0M7QUFFcEMsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBRTdCLE1BQXNCLE1BQU07SUFJMUI7Ozs7T0FJRztJQUNILFlBQ0UsU0FBWSxFQUNaLFlBQW9DLEVBQ3BDLGFBQXFDO1FBRXJDLElBQUksQ0FBQyxTQUFTLEdBQUcsU0FBUyxDQUFDO1FBQzNCLElBQUksQ0FBQyxZQUFZLEdBQUcsWUFBWSxDQUFDO1FBQ2pDLElBQUksQ0FBQyxhQUFhLEdBQUcsYUFBYSxDQUFDO0lBQ3JDLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNPLGdCQUFnQixDQUFDLEdBQVcsRUFBRSxZQUFzQjtRQUM1RCxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ3RDLE9BQU8sS0FBSyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUM7SUFDdEQsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ08sY0FBYyxDQUFDLEdBQVcsRUFBRSxZQUFzQjtRQUMxRCxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ3JDLE9BQU8sS0FBSyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUM7SUFDdEQsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxrQkFBa0I7UUFDdkIsT0FBTyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUM7SUFDNUIsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxlQUFlO1FBQ3BCLE9BQU8sUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDO0lBQzVCLENBQUM7Q0FDRjtBQTFERCx3QkEwREMifQ==