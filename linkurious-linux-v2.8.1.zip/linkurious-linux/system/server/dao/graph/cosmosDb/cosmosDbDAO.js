/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2018-06-29.
 */
'use strict';
const { GraphDAO } = require('../graphDAO');
const { CosmosDbConnector } = require('../../connector/cosmosDbConnector');
const { CosmosDbDriver } = require('./cosmosDbDriver');
class CosmosDbDAO extends GraphDAO {
    /**
     * @param {object}  options
     * @param {string}  options.url               Cosmos db Gremlin Endpoint
     * @param {string}  options.database          Database name
     * @param {string}  options.collection        Collection name
     * @param {string}  options.primaryKey        Cosmos db authentication key
     * @param {boolean} [options.allowSelfSigned] Whether to allow self-signed certificates
     */
    constructor(options) {
        super('cosmosDb', ['url', 'database', 'collection', 'primaryKey'], ['url', '.NET SDK URI', 'database', 'collection', 'primaryKey', 'allowSelfSigned'], options, {
            immutableNodeCategories: true,
            maxNodeCategories: 1,
            canCount: false,
            alerts: false,
            alternativeIds: false,
            dialects: ['gremlin'],
            canDryRun: false,
            supportNativeDate: false
        }, CosmosDbConnector, [
            { version: '0', driver: '[latest]' },
            { version: '0', driver: CosmosDbDriver }
        ]);
    }
}
module.exports = CosmosDbDAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29zbW9zRGJEQU8uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2dyYXBoL2Nvc21vc0RiL2Nvc21vc0RiREFPLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBQ2IsTUFBTSxFQUFFLFFBQVEsRUFBRSxHQUFHLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUM1QyxNQUFNLEVBQUUsaUJBQWlCLEVBQUUsR0FBRyxPQUFPLENBQUMsbUNBQW1DLENBQUMsQ0FBQztBQUMzRSxNQUFNLEVBQUUsY0FBYyxFQUFFLEdBQUcsT0FBTyxDQUFDLGtCQUFrQixDQUFDLENBQUM7QUFFdkQsTUFBTSxXQUFZLFNBQVEsUUFBUTtJQUNoQzs7Ozs7OztPQU9HO0lBQ0gsWUFBWSxPQUFPO1FBQ2pCLEtBQUssQ0FBQyxVQUFVLEVBQ2QsQ0FBQyxLQUFLLEVBQUUsVUFBVSxFQUFFLFlBQVksRUFBRSxZQUFZLENBQUMsRUFDL0MsQ0FBQyxLQUFLLEVBQUUsY0FBYyxFQUFFLFVBQVUsRUFBRSxZQUFZLEVBQUUsWUFBWSxFQUFFLGlCQUFpQixDQUFDLEVBQ2xGLE9BQU8sRUFDUDtZQUNFLHVCQUF1QixFQUFFLElBQUk7WUFDN0IsaUJBQWlCLEVBQUUsQ0FBQztZQUNwQixRQUFRLEVBQUUsS0FBSztZQUNmLE1BQU0sRUFBRSxLQUFLO1lBQ2IsY0FBYyxFQUFFLEtBQUs7WUFDckIsUUFBUSxFQUFFLENBQUMsU0FBUyxDQUFDO1lBQ3JCLFNBQVMsRUFBRSxLQUFLO1lBQ2hCLGlCQUFpQixFQUFFLEtBQUs7U0FDekIsRUFDRCxpQkFBaUIsRUFDakI7WUFDRSxFQUFDLE9BQU8sRUFBRSxHQUFHLEVBQUUsTUFBTSxFQUFFLFVBQVUsRUFBQztZQUNsQyxFQUFDLE9BQU8sRUFBRSxHQUFHLEVBQUUsTUFBTSxFQUFFLGNBQWMsRUFBQztTQUN2QyxDQUNGLENBQUM7SUFDSixDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLFdBQVcsQ0FBQyJ9