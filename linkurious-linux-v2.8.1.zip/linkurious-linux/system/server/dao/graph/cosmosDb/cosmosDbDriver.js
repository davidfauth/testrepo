/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2018-06-29.
 */
'use strict';
Object.defineProperty(exports, "__esModule", { value: true });
const LKE = require("../../../services");
const Utils = LKE.getUtils();
const Bluebird = require("bluebird");
const NotSupportedError_1 = require("../../../models/errors/NotSupportedError");
const GremlinDriver = require("../gremlinDriver");
class CosmosDbDriver extends GremlinDriver {
    $getNodeCount(approx) {
        throw new NotSupportedError_1.NotSupportedError('node count', 'cosmos db');
    }
    $getEdgeCount(approx) {
        throw new NotSupportedError_1.NotSupportedError('edge count', 'cosmos db');
    }
    $dryRun(query) {
        throw new NotSupportedError_1.NotSupportedError('dry run', 'cosmos db');
    }
    /**
     * @returns {GremlinOptions}
     */
    // @ts-ignore TODO GremlinOptions is declared in js_services.d.ts
    get $gremlinOptions() {
        return {
            disableTypeChecks: false,
            useDef: false,
            canFoldAndDedupById: false
        };
    }
    /**
     * Check if the given edge ID is legal.
     *
     * @param {string}  key
     * @param {string}  id
     * @throws {LkError} if the ID is not valid
     */
    $checkEdgeId(key, id) {
        return this._checkId(key, id);
    }
    /**
     * Check if the given node ID is legal.
     *
     *
     * @param {string}  key
     * @param {string}  id
     * @throws {LkError} if the ID is not valid
     */
    $checkNodeId(key, id) {
        return this._checkId(key, id);
    }
    /**
     * @param {string}  key
     * @param {string}  id
     * @throws {LkError} if the ID is not valid
     * @private
     */
    _checkId(key, id) {
        // Cosmos db ids cannot be empty strings
        Utils.check.string(key, id.trim(), true);
    }
    /**
     * List all edgeTypes, nodeCategories, edgeProperties, nodeProperties
     * that exist in the graph database.
     *
     * @returns {Bluebird<SimpleGraphSchema>}
     */
    $getSimpleSchema() {
        // https://docs.microsoft.com/en-us/azure/cosmos-db/indexing-policies
        const connector = this.connector;
        const edgeTypesQuery = 'SELECT DISTINCT VALUE c.label from c where IS_DEFINED(c._isEdge)';
        const nodeCategoriesQuery = 'SELECT DISTINCT VALUE c.label from c where ' + 'NOT IS_DEFINED(c._isEdge)';
        return Bluebird.resolve().then(async () => {
            const edgeTypes = await connector.doSQLQuery(edgeTypesQuery);
            const nodeCategories = await connector.doSQLQuery(nodeCategoriesQuery);
            return {
                nodeCategories: nodeCategories,
                edgeTypes: edgeTypes,
                nodeProperties: [],
                edgeProperties: []
            };
        });
    }
}
exports.CosmosDbDriver = CosmosDbDriver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29zbW9zRGJEcml2ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2dyYXBoL2Nvc21vc0RiL2Nvc21vc0RiRHJpdmVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBRUgsWUFBWSxDQUFDOztBQUNiLHlDQUEwQztBQUMxQyxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFHN0IscUNBQXNDO0FBQ3RDLGdGQUEyRTtBQUUzRSxrREFBbUQ7QUFFbkQsTUFBYSxjQUFlLFNBQVEsYUFBYTtJQUN4QyxhQUFhLENBQUMsTUFBZTtRQUNsQyxNQUFNLElBQUkscUNBQWlCLENBQUMsWUFBWSxFQUFFLFdBQVcsQ0FBQyxDQUFDO0lBQ3pELENBQUM7SUFDTSxhQUFhLENBQUMsTUFBZTtRQUNsQyxNQUFNLElBQUkscUNBQWlCLENBQUMsWUFBWSxFQUFFLFdBQVcsQ0FBQyxDQUFDO0lBQ3pELENBQUM7SUFDTSxPQUFPLENBQUMsS0FBYTtRQUMxQixNQUFNLElBQUkscUNBQWlCLENBQUMsU0FBUyxFQUFFLFdBQVcsQ0FBQyxDQUFDO0lBQ3RELENBQUM7SUFDRDs7T0FFRztJQUNILGlFQUFpRTtJQUNqRSxJQUFJLGVBQWU7UUFDakIsT0FBTztZQUNMLGlCQUFpQixFQUFFLEtBQUs7WUFDeEIsTUFBTSxFQUFFLEtBQUs7WUFDYixtQkFBbUIsRUFBRSxLQUFLO1NBQzNCLENBQUM7SUFDSixDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0ksWUFBWSxDQUFDLEdBQVcsRUFBRSxFQUFVO1FBQ3pDLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLENBQUM7SUFDaEMsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSSxZQUFZLENBQUMsR0FBVyxFQUFFLEVBQVU7UUFDekMsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsQ0FBQztJQUNoQyxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxRQUFRLENBQUMsR0FBVyxFQUFFLEVBQVU7UUFDckMsd0NBQXdDO1FBQ3hDLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsSUFBSSxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksZ0JBQWdCO1FBQ3JCLHFFQUFxRTtRQUVyRSxNQUFNLFNBQVMsR0FBc0IsSUFBSSxDQUFDLFNBQVMsQ0FBQztRQUNwRCxNQUFNLGNBQWMsR0FBRyxrRUFBa0UsQ0FBQztRQUMxRixNQUFNLG1CQUFtQixHQUN2Qiw2Q0FBNkMsR0FBRywyQkFBMkIsQ0FBQztRQUU5RSxPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsS0FBSyxJQUFJLEVBQUU7WUFDeEMsTUFBTSxTQUFTLEdBQUcsTUFBTSxTQUFTLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1lBQzdELE1BQU0sY0FBYyxHQUFHLE1BQU0sU0FBUyxDQUFDLFVBQVUsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1lBQ3ZFLE9BQU87Z0JBQ0wsY0FBYyxFQUFFLGNBQTBCO2dCQUMxQyxTQUFTLEVBQUUsU0FBcUI7Z0JBQ2hDLGNBQWMsRUFBRSxFQUFFO2dCQUNsQixjQUFjLEVBQUUsRUFBRTthQUNuQixDQUFDO1FBQ0osQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0NBQ0Y7QUFqRkQsd0NBaUZDIn0=