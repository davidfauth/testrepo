/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-10-09.
 */
'use strict';
const _ = require('lodash');
const Promise = require('bluebird');
const through = require('through');
const { InputSerialization } = require('linkurious-shared/umd');
const LKE = require('../../services');
const Errors = LKE.getErrors();
const Utils = LKE.getUtils();
const { GraphDriver } = require('./graphDriver');
const CypherUtils = require('./../utils/cypherUtils');
class CypherDriver extends GraphDriver {
    /**
     * Encode value in a string that can be inserted in a query template.
     *
     * @param {TemplateDataValue}  value
     * @param {InputSerialization} serializer
     * @returns {string}
     */
    $quote(value, serializer) {
        switch (serializer) {
            case InputSerialization.NODE:
                const id = value + '';
                this.$checkNodeId('nodeId', id);
                return id;
            case InputSerialization.NODE_SET:
                _.forEach(value, v => this.$checkNodeId('nodeId', v));
                return CypherUtils.encodeIDArray(value);
            case InputSerialization.NATIVE_DATE:
                Utils.check.string('date', value, false);
                return `date('${value}')`;
            case InputSerialization.NATIVE_DATE_TIME:
                Utils.check.string('date', value, true);
                const datetime = ( /**@type {string}*/value);
                const withTimezone = /.+([+-]\d{2}:\d{2}|Z)$/.test(datetime);
                const type = withTimezone ? 'datetime' : 'localDatetime';
                return `${type}('${datetime}')`;
            case InputSerialization.STRING:
                return CypherUtils.encodeValue(value);
            default:
                return value + '';
        }
    }
    /**
     * Create a node.
     *
     * @param {LkNodeAttributes} newNode
     * @returns {Bluebird<LkNode>}
     */
    $createNode(newNode) {
        const sLabel = ':' + newNode.categories.map(category => CypherUtils.encodeName(category)).join((':'));
        const sChanges = [];
        // set properties
        _.forEach(newNode.data, (value, key) => {
            if (Utils.hasValue(value)) {
                sChanges.push('SET n.' + CypherUtils.encodeName(key) + ' = ' +
                    CypherUtils.encodeValue(value));
            }
        });
        return this.connector.$doCypherQuery(`CREATE (n${sLabel}) ${sChanges.join(' ')} RETURN n`).then(response => {
            return response.results[0].nodes[0];
        });
    }
    /**
     * Create an edge.
     *
     * This method is responsible to check that source and target nodes have been found.
     *
     * @param {LkEdgeAttributes} newEdge The edge to create
     * @returns {Bluebird<LkEdge>}
     */
    $createEdge(newEdge) {
        const sChanges = [];
        // set properties
        _.forEach(newEdge.data, (value, key) => {
            if (Utils.hasValue(value)) {
                sChanges.push('SET r.' + CypherUtils.encodeName(key) + ' = ' +
                    CypherUtils.encodeValue(value));
            }
        });
        return this.connector.$doCypherQuery(`MATCH (a), (b) WHERE id(a) = ${newEdge.source} AND id(b) = ${newEdge.target}
       CREATE (a)-[r:${CypherUtils.encodeName(newEdge.type)}]->(b) ${sChanges.join(' ')} RETURN r`).then(response => {
            if (response.results.length === 0) {
                throw Errors.business('node_not_found', 'Source or target node not found.');
            }
            this._invalidateCaches();
            return response.results[0].edges[0];
        });
    }
    /**
     * Get a stream of all nodes.
     *
     * @param {object} options
     * @param {number} [options.chunkSize]
     * @param {number} [options.offset=0]
     * @param {number} [options.limit]
     * @param {number} [options.type]
     * @returns {Bluebird<Readable<LkNode>>}
     */
    $getNodeStream(options) {
        // getStream with SKIP but without ORDER BY is risky. We hope Neo4j always returns the nodes
        // in the same order, but no guarantee is given. ORDER BY is extremely expensive:
        // sorting all nodes is done in memory and does not scale
        let sType = '';
        if (Utils.hasValue(options.type)) {
            sType = ':' + CypherUtils.encodeName(options.type);
        }
        let sLimit = '';
        if (Utils.hasValue(options.limit)) {
            sLimit = ' LIMIT ' + options.limit;
        }
        const query = `MATCH (n${sType}) RETURN n` +
            (options.offset ? ' SKIP ' + options.offset : '') + sLimit;
        return this.connector.$safeCypherQueryStream([query]).then(response => {
            // for every returned row, we emit the first element that is a node
            return Utils.safePipe(response.results, through(function (record) {
                if (record.nodes.length > 0) {
                    // since we filter out nodes with no categories, let's make sure we don't emit undefined values
                    this.emit('data', record.nodes[0]);
                }
            }));
        });
    }
    /**
     * Get a stream of all edges.
     *
     * @param {object} options
     * @param {number} [options.chunkSize]
     * @param {number} [options.offset=0]
     * @param {number} [options.limit]
     * @param {number} [options.type]
     * @returns {Bluebird<Readable<LkEdge>>}
     */
    $getEdgeStream(options) {
        let sType = '';
        if (Utils.hasValue(options.type)) {
            sType = ':' + CypherUtils.encodeName(options.type);
        }
        let sLimit = '';
        if (Utils.hasValue(options.limit)) {
            sLimit = ' LIMIT ' + options.limit;
        }
        const query = `MATCH ()-[r${sType}]->() RETURN r` +
            (options.offset ? ' SKIP ' + options.offset : '') + sLimit;
        return this.connector.$safeCypherQueryStream([query]).then(response => {
            // for every returned row, we emit the first element that is an edge
            return Utils.safePipe(response.results, through(function (record) {
                this.emit('data', record.edges[0]);
            }));
        });
    }
    /**
     * Create a QueryMatchPopulated from a Neo4j response record.
     *
     * @param {{nodes: LkNode[], edges: LkEdge[], rows: any[]}} record A record from Neo4j
     * @param {string[]}                                        keys   The list of returned keys of the query
     * @returns {QueryMatchPopulated}
     * @private
     */
    _getNeoMatchPopulated(record, keys) {
        const properties = {};
        for (let i = 0; i < keys.length; i++) {
            properties[keys[i]] = record.rows[i];
        }
        // we return the populated nodes
        return {
            nodes: _.uniqBy(record.nodes, 'id'),
            edges: _.uniqBy(record.edges, 'id'),
            properties: properties
        };
    }
    /**
     * Create a QueryMatch from a Neo4j response record.
     *
     * @param {{nodes: LkNode[], edges: LkEdge[], rows: any[]}} record A record from Neo4j
     * @param {string[]}                                        keys   The list of returned keys of the query
     * @returns {QueryMatch}
     * @private
     */
    _getNeoMatch(record, keys) {
        const properties = {};
        for (let i = 0; i < keys.length; i++) {
            properties[keys[i]] = record.rows[i];
        }
        // we just return the ids
        return {
            nodes: _.map(record.nodes, 'id'),
            edges: _.map(record.edges, 'id'),
            properties: properties
        };
    }
    /**
     * Run a raw query.
     *
     * If options.populated is true, return a Readable<QueryMatchPopulated>, otherwise a Readable<QueryMatch>.
     *
     * @param {object}   options
     * @param {string}   options.dialect   Supported graph query dialect
     * @param {string[]} options.queries   The graph queries
     * @param {boolean}  options.populated Whether to return QueryMatchPopulated or QueryMatch
     * @param {number}   options.limit     Maximum number of matched subgraphs
     * @returns {Bluebird<Readable<(QueryMatch | QueryMatchPopulated)>>}
     */
    $rawQuery(options) {
        return this.connector.$safeCypherQueryStream(options.queries, null, options.limit).then(response => {
            const self = this;
            if (options.populated) {
                return Utils.safePipe(response.results, through(function (record) {
                    this.queue(self._getNeoMatchPopulated(record, response.keys));
                }));
            }
            else {
                return Utils.safePipe(response.results, through(function (record) {
                    this.queue(self._getNeoMatch(record, response.keys));
                }));
            }
        });
    }
    /**
     * Return true is query is a write query.
     */
    $isWrite(query) {
        return CypherUtils.isWrite(query);
    }
    /**
     * Check if a query is correct.
     *
     * @param {string}  query      The graph query
     * @returns {boolean} Whether the `query` will alter the data
     * @throws {LkError} if the query is not valid or not authorized
     */
    $checkQuery(query) {
        return CypherUtils.checkQuery(query);
    }
    /**
     * Update the properties and categories of a node.
     * Check if the node exists and fail if it doesn't.
     *
     * @param {object}   nodeUpdate
     * @param {any}      nodeUpdate.id                ID of the node to update
     * @param {any}      nodeUpdate.data              Properties to update
     * @param {string[]} nodeUpdate.deletedProperties Properties to delete
     * @param {string[]} nodeUpdate.addedCategories   Categories to add
     * @param {string[]} nodeUpdate.deletedCategories Categories to delete
     * @returns {Bluebird<LkNode>} null if not found
     */
    $updateNode(nodeUpdate) {
        const getNodeQuery = 'MATCH (n) WHERE id(n)=' + nodeUpdate.id + ' RETURN n';
        return this.connector.$doCypherQuery(getNodeQuery).then(getNodeResponse => {
            const originalNode = getNodeResponse.results[0] &&
                getNodeResponse.results[0].nodes[0] || null;
            if (Utils.noValue(originalNode)) {
                return null;
            }
            let categoriesAfterUpdate = _.difference(originalNode.categories, nodeUpdate.deletedCategories);
            categoriesAfterUpdate = _.union(categoriesAfterUpdate, nodeUpdate.addedCategories);
            if (categoriesAfterUpdate.length === 0) {
                return Errors.business('invalid_parameter', 'A node needs at least 1 category.', true);
            }
            const sChanges = [];
            // add categories
            if (nodeUpdate.addedCategories.length > 0) {
                sChanges.push('SET n:' + nodeUpdate.addedCategories.map(category => CypherUtils.encodeName(category)).join((':')));
            }
            // remove categories
            if (nodeUpdate.deletedCategories.length > 0) {
                sChanges.push('REMOVE n:' + nodeUpdate.deletedCategories.map(category => CypherUtils.encodeName(category)).join((':')));
            }
            // set properties
            _.forEach(nodeUpdate.data, (value, key) => {
                if (Utils.hasValue(value)) {
                    sChanges.push('SET n.' + CypherUtils.encodeName(key) + ' = ' +
                        CypherUtils.encodeValue(value));
                }
            });
            // delete properties
            _.forEach(nodeUpdate.deletedProperties, key => {
                sChanges.push('REMOVE n.' + CypherUtils.encodeName(key));
            });
            const query = 'MATCH (n) WHERE id(n)=' + nodeUpdate.id + ' ' +
                sChanges.join(' ') + ' RETURN n';
            return this.connector.$doCypherQuery(query).then(response => {
                return response.results[0] && response.results[0].nodes[0] || null;
            });
        });
    }
    /**
     * Update an edge content.
     * It's not possible to update the type of an edge.
     *
     * @param {object}   edgeUpdate
     * @param {any}      edgeUpdate.id                ID of the edge
     * @param {any}      edgeUpdate.data              Properties updates
     * @param {string[]} edgeUpdate.deletedProperties Properties to delete
     * @returns {Bluebird<LkEdge>} null if not found
     */
    $updateEdge(edgeUpdate) {
        const sChanges = [];
        // set properties
        _.forEach(edgeUpdate.data, (value, key) => {
            if (Utils.hasValue(value)) {
                sChanges.push('SET e.' + CypherUtils.encodeName(key) + ' = ' +
                    CypherUtils.encodeValue(value));
            }
        });
        // delete properties
        _.forEach(edgeUpdate.deletedProperties, key => {
            sChanges.push('REMOVE e.' + CypherUtils.encodeName(key));
        });
        const query = 'MATCH ()-[e]->() WHERE id(e)=' + edgeUpdate.id + ' ' +
            sChanges.join(' ') + ' RETURN e';
        return this.connector.$doCypherQuery(query).then(response => {
            this._invalidateCaches();
            return response.results[0] && response.results[0].edges[0] || null;
        });
    }
    /**
     * Delete an edge.
     *
     * @param {any} edgeId ID of the edge
     * @returns {Bluebird<void>}
     */
    $deleteEdge(edgeId) {
        const query = 'MATCH ()-[e]->() WHERE id(e)=' + edgeId +
            ' WITH e, id(e) AS id DELETE e RETURN id';
        return this.connector.$doCypherQuery(query).then(() => {
            this._invalidateCaches();
        });
    }
    /**
     * Delete a node and all edges connected to it.
     *
     * @param {any} nodeId ID of the node to delete
     * @returns {Bluebird<void>}
     */
    $deleteNode(nodeId) {
        const query = 'MATCH (n) WHERE id(n)=' + nodeId +
            ' WITH n, id(n) AS id OPTIONAL MATCH (n)-[r]-() DELETE n, r RETURN id';
        return this.connector.$doCypherQuery(query);
    }
    /**
     * Get a list of nodes by ID.
     * This method should return nodes in the same order as the input ids.
     *
     * @param {object} options
     * @param {any[]}  options.ids             List of IDs to read
     * @param {string} [options.alternativeId] The property to match `options.ids` on (instead of the actual IDs)
     * @returns {Bluebird<LkNode[]>}
     */
    $getNodesByID(options) {
        const sMatch = Utils.noValue(options.alternativeId)
            ? `id(n) IN ${CypherUtils.encodeIDArray(options.ids)}`
            : `n.${CypherUtils.encodeName(options.alternativeId)} IN ` +
                CypherUtils.encodeValue(options.ids);
        const query = `MATCH (n) WHERE ${sMatch} RETURN n`;
        return this.connector.$doCypherQuery(query).then(response => {
            return _.flatMap(response.results, 'nodes');
        });
    }
    /**
     * Get the neighbors of a subset of nodes.
     *
     * @param {string[]} nodeIds                  IDs of the nodes to retrieve the neighbors for
     * @param {object}   options
     * @param {number}   [options.limit]          Max number of nodes in result
     * @param {string}   options.limitType        "id", "lowestDegree" or "highestDegree" to sort results before limiting
     * @param {string[]} [options.nodeCategories] Exclusive list of node-categories to restrict the result
     * @param {string[]} [options.edgeTypes]      Exclusive list of edge-type to restrict the result
     * @param {string[]} [options.ignoredNodeIds] IDs of nodes we do not want in the results
     * @returns {Bluebird<LkNode[]>}
     */
    $getAdjacentNodes(nodeIds, options) {
        let sEdgeTypeFilter = '';
        let sMatchEdges = '';
        let sReadableCategories = 'AND size(labels(nN)) > 0 ';
        let sOrder = '';
        if (options.limitType !== 'id') {
            // we have to match edges if we sort nodes by cardinality
            sMatchEdges = 'MATCH (nN)-[nE]-()';
        }
        if (options.limitType === 'lowestDegree') {
            sOrder = 'ASC';
        }
        else if (options.limitType === 'highestDegree') {
            sOrder = 'DESC';
        }
        if (Utils.hasValue(options.nodeCategories)) {
            const readableCategories = options.nodeCategories
                .map(category => 'nN:' + CypherUtils.encodeName(category));
            sReadableCategories = `AND (${readableCategories.join(' OR ')}) `;
        }
        // Note this filter will not work anymore in the future
        // in conjunction with the use of variable binding, e.g.: ()-[e:TYPE1|:TYPE2]-()
        if (Utils.hasValue(options.edgeTypes)) {
            sEdgeTypeFilter = options.edgeTypes.map(type => ':' + CypherUtils.encodeName(type)).join('|');
        }
        let sIgnoreVisibles = '';
        if (Utils.hasValue(options.ignoredNodeIds)) {
            sIgnoreVisibles = `AND NOT (id(nN) IN ${CypherUtils.encodeIDArray(options.ignoredNodeIds)}) `;
        }
        // nN=neighborNode
        let expandQuery = `MATCH (n)-[${sEdgeTypeFilter}]-(nN) ` +
            `WHERE id(n) IN ${CypherUtils.encodeIDArray(nodeIds)} ` +
            sIgnoreVisibles +
            sReadableCategories +
            sMatchEdges +
            'RETURN DISTINCT nN ';
        if (options.limit > 0) {
            if (options.limitType !== 'id') {
                expandQuery += `, count(nE) as degree ORDER BY degree ${sOrder} `;
            }
            expandQuery += `LIMIT ${options.limit}`;
        }
        // we get the neighbors
        return this.connector.$doCypherQuery(expandQuery).then(response => {
            return _.flatMap(response.results, 'nodes');
        });
    }
    /**
     * Get the edges between two set of nodes.
     *
     * @param {string[]} nodeIds         IDs of the first set of nodes
     * @param {string[]} otherNodeIds    IDs of the second set of nodes
     * @param options
     * @param [options.edgeTypes]      Exclusive list of edge types to restrict the result
     * @param [options.nodeCategories] Exclusive list of node categories (of nodes in `otherNodeIds`) to restrict the result
     * @returns {Bluebird<LkEdge[]>}
     */
    $getMutualEdges(nodeIds, otherNodeIds, options) {
        const sNodesIds = CypherUtils.encodeIDArray(nodeIds);
        const sOtherNodeIds = CypherUtils.encodeIDArray(otherNodeIds);
        let sEdgeTypeFilter = '';
        if (Utils.hasValue(options.edgeTypes)) {
            sEdgeTypeFilter = options.edgeTypes.map(type => ':' + CypherUtils.encodeName(type)).join('|');
        }
        let sReadableCategories = 'AND size(labels(a)) > 0 ';
        if (Utils.hasValue(options.nodeCategories)) {
            const readableCategories = options.nodeCategories
                .map(category => 'a:' + CypherUtils.encodeName(category));
            sReadableCategories = `AND (${readableCategories.join(' OR ')}) `;
        }
        // The reason that variables are called 'a', 'b', 'e' is not casual
        // It's to hint to the planner to actually scan the list of nodes in `nodeIds` instead
        // of nodes in `otherNodeIds`. See #1462
        const edgeQuery = `MATCH (b)-[e${sEdgeTypeFilter}]-(a) ` +
            `WHERE id(b) IN ${sNodesIds} AND id(a) IN ${sOtherNodeIds} ` +
            sReadableCategories +
            'RETURN DISTINCT e';
        return this.connector.$doCypherQuery(edgeQuery).then(response => {
            const edges = _.map(response.results, record => record.edges[0]);
            return edges;
        });
    }
    /**
     * Provide a neighborhood digest of a specified subset of nodes.
     *
     * @param {any[]} nodeIds IDs of the nodes
     * @returns {Bluebird<LkDigestItem[]>}
     */
    $getAdjacencyDigest(nodeIds) {
        const digestQuery = 'MATCH (node)-[e]-(n) ' +
            `WHERE ID(node) IN ${CypherUtils.encodeIDArray(nodeIds)} ` +
            'AND size(labels(n)) > 0 ' +
            'RETURN type(e), labels(n), count(DISTINCT n), count(DISTINCT e)';
        return this.connector.$doCypherQuery(digestQuery).then(response => {
            return _.map(response.results, result => ({
                edgeType: result.rows[0],
                nodeCategories: result.rows[1].sort(),
                nodes: result.rows[2],
                edges: result.rows[3]
            }));
        });
    }
    /**
     * Return the degrees of the specified nodes.
     * If `discreteResults` is false:
     *   Return the degree of the specified node if `nodeIds` has cardinality 1.
     *   If multiple `nodeIds` are specified, return the cardinality of the intersection
     *   of the neighbors of the nodes (not including the nodes in input themselves).
     * If `discreteResults` is true:
     *   Return a map indexed by id populated with the degree of each node.
     *
     * @param {any[]}    nodeIds                      IDs of the nodes
     * @param {object}   options
     * @param {string[]} [options.readableCategories] Exclusive list of node-categories to restrict the result
     * @param {string[]} [options.readableTypes]      Exclusive list of edge-type to restrict the result
     * @param {boolean}  [options.discreteResults]    Whether to return the degree of each node
     * @returns {Bluebird<number | Map<string, number>>}
     */
    $getNodeDegree(nodeIds, options) {
        const sNodeIds = CypherUtils.encodeIDArray(nodeIds);
        let sReadableCategories = 'AND size(labels(n)) > 0 ';
        let sEdgeTypeFilter = '';
        if (Utils.hasValue(options.readableCategories)) {
            const readableCategories = options.readableCategories
                .map(category => 'n:' + CypherUtils.encodeName(category));
            sReadableCategories = `AND (${readableCategories.join(' OR ')}) `;
        }
        // Note this filter will not work anymore in the future
        // in conjunction with the use of variable binding, e.g.: ()-[e:TYPE1|:TYPE2]-()
        if (Utils.hasValue(options.readableTypes)) {
            sEdgeTypeFilter = options.readableTypes.map(type => ':' + CypherUtils.encodeName(type)).join('|');
        }
        const combinedDegreeQuery = `MATCH (node)-[e${sEdgeTypeFilter}]-(n)
      WHERE id(node) IN ${sNodeIds}
      AND NOT id(n) IN ${sNodeIds}
      ${sReadableCategories}
      RETURN count(DISTINCT n)`;
        const discreteDegreeQuery = nodeId => `MATCH (node)-[e${sEdgeTypeFilter}]-(n)
      WHERE id(node) = ${nodeId}
      AND NOT id(n) = ${nodeId}
      ${sReadableCategories}
      RETURN ${nodeId} as id, count(DISTINCT n) as count`;
        let degreeQuery = combinedDegreeQuery;
        if (options.discreteResults) {
            degreeQuery = nodeIds.map(discreteDegreeQuery).join(' UNION ');
        }
        return this.connector.$doCypherQuery(degreeQuery).then(response => {
            if (options.discreteResults) {
                return response.results.reduce((degreeResult, result) => {
                    const [nodeId, degree] = result.rows;
                    return degreeResult.set('' + nodeId, degree);
                }, new Map());
            }
            return response.results[0].rows[0];
        });
    }
    /**
     * Get a list of edges by ID.
     * This method should return edges in the same order as the input ids.
     *
     * @param {object} options
     * @param {any[]}  options.ids             List of IDs to read
     * @param {string} [options.alternativeId] The property to match `options.ids` on (instead of the actual IDs)
     * @returns {Bluebird<LkEdge[]>}
     */
    $getEdgesByID(options) {
        const sMatch = Utils.noValue(options.alternativeId)
            ? `id(e) IN ${CypherUtils.encodeIDArray(options.ids)}`
            : `e.${CypherUtils.encodeName(options.alternativeId)} IN ` +
                CypherUtils.encodeValue(options.ids);
        const query = `MATCH ()-[e]->() WHERE ${sMatch} RETURN e`;
        return this.connector.$doCypherQuery(query).then(response => {
            return _.flatMap(response.results, 'edges');
        });
    }
    /**
     * List all edgeTypes that exist in the graph database.
     *
     * @returns {Bluebird<string[]>}
     */
    $getEdgeTypes() {
        return Utils.NOT_IMPLEMENTED();
    }
    /**
     * Provide a neighborhood edge digest for a specific node.
     *
     * @param {any}      nodeId                  ID of the node
     * @param {object}   options
     * @param {string[]} [options.readableTypes] Exclusive list of edge-type to restrict the result
     * @returns {Bluebird<LkEdgeDigestItem[]>}
     */
    $getEdgeDigest(nodeId, options) {
        return Promise.resolve().then(() => {
            // if readableTypes is defined, we know we have to compute the edge digest only
            // towards these edge types
            if (Utils.hasValue(options.readableTypes)) {
                return options.readableTypes;
            }
            // Otherwise, we need to retrieve the whole list of edge types
            return Promise.resolve().then(() => {
                // We cache the list of edge types to avoid to retrieve it all the times
                if (Utils.noValue(this._allEdgeTypesCached)) {
                    return this.$getEdgeTypes().then(types => {
                        this._allEdgeTypesCached = types;
                    });
                }
            }).then(() => {
                return this._allEdgeTypesCached;
            });
        }).then(types => {
            if (types.length === 0) {
                return [];
            }
            const queryReturns = [];
            for (let i = 0; i < types.length; i++) {
                queryReturns.push(`size((n)-[:${CypherUtils.encodeName(types[i])}]-())`);
            }
            const query = `MATCH (n) WHERE id(n) = ${nodeId} RETURN ` + queryReturns.join(', ');
            return this.connector.$doCypherQuery(query).then(response => {
                let edgeDigest = _.map(_.zip(types, response.results[0].rows), digestEntry => {
                    return {
                        edgeType: digestEntry[0],
                        edges: digestEntry[1]
                    };
                });
                edgeDigest = _.filter(edgeDigest, digestEntry => digestEntry.edges > 0);
                return edgeDigest;
            });
        });
    }
    /**
     * Return a map indexed by id populated with `true` if the node is a supernode.
     * A supernode is a node with a number of relationships greater or equal than `supernodeThreshold`.
     * Return `false` if the node is not found.
     *
     * @param {any[]}  nodeIds            IDs of the node
     * @param {number} supernodeThreshold
     * @returns {Bluebird<Map<string, boolean>>}
     */
    $isSuperNode(nodeIds, supernodeThreshold) {
        const degreeQuery = nodeId => `MATCH (n) WHERE id(n) = ${nodeId} RETURN ${nodeId} as id, size((n)-[]-()) as count`;
        const superNodeQuery = nodeIds.map(degreeQuery).join(' UNION ');
        return this.connector.$doCypherQuery(superNodeQuery).then(response => {
            return response.results.reduce((superNodeResult, result) => {
                const [nodeId, degree] = result.rows;
                return superNodeResult.set('' + nodeId, degree >= supernodeThreshold);
            }, new Map());
        });
    }
    /**
     * Invalidate the following caches:
     * - List of edge types (used to compute the edge digest)
     *
     * @private
     */
    _invalidateCaches() {
        this._allEdgeTypesCached = null;
    }
    /**
     * Called at the end of the indexation phase for additional initializations.
     *
     * @returns {Bluebird<void>}
     */
    $onAfterIndexation() {
        this._invalidateCaches();
        return Promise.resolve();
    }
    /**
     * Called at the end of the connect phase for additional initializations.
     *
     * @returns {Bluebird<void>}
     */
    $onAfterConnect() {
        this._invalidateCaches();
        return Promise.resolve();
    }
}
module.exports = CypherDriver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3lwaGVyRHJpdmVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL2Rhby9ncmFwaC9jeXBoZXJEcml2ZXIuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFDYixNQUFNLENBQUMsR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDNUIsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3BDLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUNuQyxNQUFNLEVBQUMsa0JBQWtCLEVBQUMsR0FBRyxPQUFPLENBQUMsdUJBQXVCLENBQUMsQ0FBQztBQUM5RCxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztBQUN0QyxNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzdCLE1BQU0sRUFBQyxXQUFXLEVBQUMsR0FBRyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUM7QUFDL0MsTUFBTSxXQUFXLEdBQUcsT0FBTyxDQUFDLHdCQUF3QixDQUFDLENBQUM7QUFFdEQsTUFBTSxZQUFhLFNBQVEsV0FBVztJQUNwQzs7Ozs7O09BTUc7SUFDSCxNQUFNLENBQUMsS0FBSyxFQUFFLFVBQVU7UUFDdEIsUUFBUSxVQUFVLEVBQUU7WUFDbEIsS0FBSyxrQkFBa0IsQ0FBQyxJQUFJO2dCQUMxQixNQUFNLEVBQUUsR0FBRyxLQUFLLEdBQUcsRUFBRSxDQUFDO2dCQUN0QixJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQztnQkFDaEMsT0FBTyxFQUFFLENBQUM7WUFFWixLQUFLLGtCQUFrQixDQUFDLFFBQVE7Z0JBQzlCLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDdEQsT0FBTyxXQUFXLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBRTFDLEtBQUssa0JBQWtCLENBQUMsV0FBVztnQkFDakMsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLEtBQUssRUFBRSxLQUFLLENBQUMsQ0FBQztnQkFDekMsT0FBTyxTQUFTLEtBQUssSUFBSSxDQUFDO1lBRTVCLEtBQUssa0JBQWtCLENBQUMsZ0JBQWdCO2dCQUN0QyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUN4QyxNQUFNLFFBQVEsR0FBRyxFQUFDLG1CQUFvQixLQUFLLENBQUMsQ0FBQztnQkFDN0MsTUFBTSxZQUFZLEdBQUcsd0JBQXdCLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUM3RCxNQUFNLElBQUksR0FBRyxZQUFZLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDO2dCQUN6RCxPQUFPLEdBQUcsSUFBSSxLQUFLLFFBQVEsSUFBSSxDQUFDO1lBRWxDLEtBQUssa0JBQWtCLENBQUMsTUFBTTtnQkFDNUIsT0FBTyxXQUFXLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3hDO2dCQUNFLE9BQU8sS0FBSyxHQUFHLEVBQUUsQ0FBQztTQUNyQjtJQUNILENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILFdBQVcsQ0FBQyxPQUFPO1FBQ2pCLE1BQU0sTUFBTSxHQUFHLEdBQUcsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FDekMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUU1RCxNQUFNLFFBQVEsR0FBRyxFQUFFLENBQUM7UUFDcEIsaUJBQWlCO1FBQ2pCLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDLEtBQUssRUFBRSxHQUFHLEVBQUUsRUFBRTtZQUNyQyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQ3pCLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxHQUFHLFdBQVcsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSztvQkFDMUQsV0FBVyxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO2FBQ25DO1FBQ0gsQ0FBQyxDQUFDLENBQUM7UUFFSCxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUNsQyxZQUFZLE1BQU0sS0FBSyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQ3JELENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ2hCLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDdEMsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILFdBQVcsQ0FBQyxPQUFPO1FBQ2pCLE1BQU0sUUFBUSxHQUFHLEVBQUUsQ0FBQztRQUNwQixpQkFBaUI7UUFDakIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUMsS0FBSyxFQUFFLEdBQUcsRUFBRSxFQUFFO1lBQ3JDLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDekIsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLEdBQUcsV0FBVyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsR0FBRyxLQUFLO29CQUMxRCxXQUFXLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7YUFDbkM7UUFDSCxDQUFDLENBQUMsQ0FBQztRQUVILE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQ2xDLGdDQUFnQyxPQUFPLENBQUMsTUFBTSxnQkFBZ0IsT0FBTyxDQUFDLE1BQU07dUJBQzNELFdBQVcsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxVQUFVLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FDN0YsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDaEIsSUFBSSxRQUFRLENBQUMsT0FBTyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7Z0JBQ2pDLE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsRUFBRSxrQ0FBa0MsQ0FBQyxDQUFDO2FBQzdFO1lBRUQsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7WUFDekIsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN0QyxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7O09BU0c7SUFDSCxjQUFjLENBQUMsT0FBTztRQUNwQiw0RkFBNEY7UUFDNUYsaUZBQWlGO1FBQ2pGLHlEQUF5RDtRQUV6RCxJQUFJLEtBQUssR0FBRyxFQUFFLENBQUM7UUFDZixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ2hDLEtBQUssR0FBRyxHQUFHLEdBQUcsV0FBVyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDcEQ7UUFFRCxJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUM7UUFDaEIsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUNqQyxNQUFNLEdBQUcsU0FBUyxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUM7U0FDcEM7UUFFRCxNQUFNLEtBQUssR0FBRyxXQUFXLEtBQUssWUFBWTtZQUN4QyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFNLENBQUM7UUFFN0QsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLHNCQUFzQixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDcEUsbUVBQW1FO1lBQ25FLE9BQU8sS0FBSyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxVQUFTLE1BQU07Z0JBQzdELElBQUksTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO29CQUMzQiwrRkFBK0Y7b0JBQy9GLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDcEM7WUFDSCxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ04sQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7OztPQVNHO0lBQ0gsY0FBYyxDQUFDLE9BQU87UUFDcEIsSUFBSSxLQUFLLEdBQUcsRUFBRSxDQUFDO1FBQ2YsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNoQyxLQUFLLEdBQUcsR0FBRyxHQUFHLFdBQVcsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ3BEO1FBRUQsSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFDO1FBQ2hCLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDakMsTUFBTSxHQUFHLFNBQVMsR0FBRyxPQUFPLENBQUMsS0FBSyxDQUFDO1NBQ3BDO1FBRUQsTUFBTSxLQUFLLEdBQUcsY0FBYyxLQUFLLGdCQUFnQjtZQUMvQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFNLENBQUM7UUFFN0QsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLHNCQUFzQixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDcEUsb0VBQW9FO1lBQ3BFLE9BQU8sS0FBSyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxVQUFTLE1BQU07Z0JBQzdELElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNyQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ04sQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILHFCQUFxQixDQUFDLE1BQU0sRUFBRSxJQUFJO1FBQ2hDLE1BQU0sVUFBVSxHQUFHLEVBQUUsQ0FBQztRQUN0QixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNwQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUN0QztRQUVELGdDQUFnQztRQUNoQyxPQUFPO1lBQ0wsS0FBSyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUM7WUFDbkMsS0FBSyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUM7WUFDbkMsVUFBVSxFQUFFLFVBQVU7U0FDdkIsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsWUFBWSxDQUFDLE1BQU0sRUFBRSxJQUFJO1FBQ3ZCLE1BQU0sVUFBVSxHQUFHLEVBQUUsQ0FBQztRQUN0QixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNwQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUN0QztRQUVELHlCQUF5QjtRQUN6QixPQUFPO1lBQ0wsS0FBSyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUM7WUFDaEMsS0FBSyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUM7WUFDaEMsVUFBVSxFQUFFLFVBQVU7U0FDdkIsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7T0FXRztJQUNILFNBQVMsQ0FBQyxPQUFPO1FBQ2YsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLHNCQUFzQixDQUMxQyxPQUFPLENBQUMsT0FBTyxFQUFFLElBQUksRUFBRSxPQUFPLENBQUMsS0FBSyxDQUNyQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUNoQixNQUFNLElBQUksR0FBRyxJQUFJLENBQUM7WUFDbEIsSUFBSSxPQUFPLENBQUMsU0FBUyxFQUFFO2dCQUNyQixPQUFPLEtBQUssQ0FBQyxRQUFRLENBQ25CLFFBQVEsQ0FBQyxPQUFPLEVBQ2hCLE9BQU8sQ0FBQyxVQUFTLE1BQU07b0JBQ3JCLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLE1BQU0sRUFBRSxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFDaEUsQ0FBQyxDQUFDLENBQ0gsQ0FBQzthQUNIO2lCQUFNO2dCQUNMLE9BQU8sS0FBSyxDQUFDLFFBQVEsQ0FDbkIsUUFBUSxDQUFDLE9BQU8sRUFDaEIsT0FBTyxDQUFDLFVBQVMsTUFBTTtvQkFDckIsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFDdkQsQ0FBQyxDQUFDLENBQ0gsQ0FBQzthQUNIO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxRQUFRLENBQUMsS0FBSztRQUNaLE9BQU8sV0FBVyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsV0FBVyxDQUFDLEtBQUs7UUFDZixPQUFPLFdBQVcsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUVEOzs7Ozs7Ozs7OztPQVdHO0lBQ0gsV0FBVyxDQUFDLFVBQVU7UUFDcEIsTUFBTSxZQUFZLEdBQUcsd0JBQXdCLEdBQUcsVUFBVSxDQUFDLEVBQUUsR0FBRyxXQUFXLENBQUM7UUFFNUUsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLEVBQUU7WUFDeEUsTUFBTSxZQUFZLEdBQUcsZUFBZSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7Z0JBQzdDLGVBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQztZQUM5QyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLEVBQUU7Z0JBQy9CLE9BQU8sSUFBSSxDQUFDO2FBQ2I7WUFFRCxJQUFJLHFCQUFxQixHQUFHLENBQUMsQ0FBQyxVQUFVLENBQ3RDLFlBQVksQ0FBQyxVQUFVLEVBQUUsVUFBVSxDQUFDLGlCQUFpQixDQUN0RCxDQUFDO1lBQ0YscUJBQXFCLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsRUFBRSxVQUFVLENBQUMsZUFBZSxDQUFDLENBQUM7WUFFbkYsSUFBSSxxQkFBcUIsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO2dCQUN0QyxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsbUJBQW1CLEVBQ3hDLG1DQUFtQyxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQzlDO1lBRUQsTUFBTSxRQUFRLEdBQUcsRUFBRSxDQUFDO1lBRXBCLGlCQUFpQjtZQUNqQixJQUFJLFVBQVUsQ0FBQyxlQUFlLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtnQkFDekMsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLEdBQUcsVUFBVSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQ3JELFFBQVEsQ0FBQyxFQUFFLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUM5RDtZQUVELG9CQUFvQjtZQUNwQixJQUFJLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO2dCQUMzQyxRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsR0FBRyxVQUFVLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUMxRCxRQUFRLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDOUQ7WUFFRCxpQkFBaUI7WUFDakIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLENBQUMsS0FBSyxFQUFFLEdBQUcsRUFBRSxFQUFFO2dCQUN4QyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLEVBQUU7b0JBQ3pCLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxHQUFHLFdBQVcsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSzt3QkFDMUQsV0FBVyxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO2lCQUNuQztZQUNILENBQUMsQ0FBQyxDQUFDO1lBRUgsb0JBQW9CO1lBQ3BCLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLGlCQUFpQixFQUFFLEdBQUcsQ0FBQyxFQUFFO2dCQUM1QyxRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsR0FBRyxXQUFXLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDM0QsQ0FBQyxDQUFDLENBQUM7WUFFSCxNQUFNLEtBQUssR0FBRyx3QkFBd0IsR0FBRyxVQUFVLENBQUMsRUFBRSxHQUFHLEdBQUc7Z0JBQzFELFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsV0FBVyxDQUFDO1lBQ25DLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO2dCQUMxRCxPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDO1lBQ3JFLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7OztPQVNHO0lBQ0gsV0FBVyxDQUFDLFVBQVU7UUFDcEIsTUFBTSxRQUFRLEdBQUcsRUFBRSxDQUFDO1FBRXBCLGlCQUFpQjtRQUNqQixDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxLQUFLLEVBQUUsR0FBRyxFQUFFLEVBQUU7WUFDeEMsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUN6QixRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxXQUFXLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEtBQUs7b0JBQzFELFdBQVcsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQzthQUNuQztRQUNILENBQUMsQ0FBQyxDQUFDO1FBRUgsb0JBQW9CO1FBQ3BCLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLGlCQUFpQixFQUFFLEdBQUcsQ0FBQyxFQUFFO1lBQzVDLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxHQUFHLFdBQVcsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUMzRCxDQUFDLENBQUMsQ0FBQztRQUVILE1BQU0sS0FBSyxHQUFHLCtCQUErQixHQUFHLFVBQVUsQ0FBQyxFQUFFLEdBQUcsR0FBRztZQUNqRSxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLFdBQVcsQ0FBQztRQUNuQyxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUMxRCxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztZQUN6QixPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDO1FBQ3JFLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsV0FBVyxDQUFDLE1BQU07UUFDaEIsTUFBTSxLQUFLLEdBQUcsK0JBQStCLEdBQUcsTUFBTTtZQUNwRCx5Q0FBeUMsQ0FBQztRQUM1QyxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDcEQsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFDM0IsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxXQUFXLENBQUMsTUFBTTtRQUNoQixNQUFNLEtBQUssR0FBRyx3QkFBd0IsR0FBRyxNQUFNO1lBQzdDLHNFQUFzRSxDQUFDO1FBQ3pFLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDOUMsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsYUFBYSxDQUFDLE9BQU87UUFDbkIsTUFBTSxNQUFNLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDO1lBQ2pELENBQUMsQ0FBQyxZQUFZLFdBQVcsQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQ3RELENBQUMsQ0FBQyxLQUFLLFdBQVcsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxNQUFNO2dCQUMxRCxXQUFXLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUV2QyxNQUFNLEtBQUssR0FBRyxtQkFBbUIsTUFBTSxXQUFXLENBQUM7UUFFbkQsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDMUQsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDOUMsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7O09BV0c7SUFDSCxpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsT0FBTztRQUNoQyxJQUFJLGVBQWUsR0FBRyxFQUFFLENBQUM7UUFDekIsSUFBSSxXQUFXLEdBQUcsRUFBRSxDQUFDO1FBQ3JCLElBQUksbUJBQW1CLEdBQUcsMkJBQTJCLENBQUM7UUFDdEQsSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFDO1FBQ2hCLElBQUksT0FBTyxDQUFDLFNBQVMsS0FBSyxJQUFJLEVBQUU7WUFDOUIseURBQXlEO1lBQ3pELFdBQVcsR0FBRyxvQkFBb0IsQ0FBQztTQUNwQztRQUVELElBQUksT0FBTyxDQUFDLFNBQVMsS0FBSyxjQUFjLEVBQUU7WUFDeEMsTUFBTSxHQUFHLEtBQUssQ0FBQztTQUNoQjthQUFNLElBQUksT0FBTyxDQUFDLFNBQVMsS0FBSyxlQUFlLEVBQUU7WUFDaEQsTUFBTSxHQUFHLE1BQU0sQ0FBQztTQUNqQjtRQUVELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLEVBQUU7WUFDMUMsTUFBTSxrQkFBa0IsR0FBRyxPQUFPLENBQUMsY0FBYztpQkFDOUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsS0FBSyxHQUFHLFdBQVcsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztZQUU3RCxtQkFBbUIsR0FBRyxRQUFRLGtCQUFrQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO1NBQ25FO1FBRUQsdURBQXVEO1FBQ3ZELGdGQUFnRjtRQUNoRixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQ3JDLGVBQWUsR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FDckMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsV0FBVyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FDM0MsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDYjtRQUVELElBQUksZUFBZSxHQUFHLEVBQUUsQ0FBQztRQUN6QixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxFQUFFO1lBQzFDLGVBQWUsR0FBRyxzQkFBc0IsV0FBVyxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQztTQUMvRjtRQUVELGtCQUFrQjtRQUNsQixJQUFJLFdBQVcsR0FBRyxjQUFjLGVBQWUsU0FBUztZQUN0RCxrQkFBa0IsV0FBVyxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsR0FBRztZQUN2RCxlQUFlO1lBQ2YsbUJBQW1CO1lBQ25CLFdBQVc7WUFDWCxxQkFBcUIsQ0FBQztRQUV4QixJQUFJLE9BQU8sQ0FBQyxLQUFLLEdBQUcsQ0FBQyxFQUFFO1lBQ3JCLElBQUksT0FBTyxDQUFDLFNBQVMsS0FBSyxJQUFJLEVBQUU7Z0JBQzlCLFdBQVcsSUFBSSx5Q0FBeUMsTUFBTSxHQUFHLENBQUM7YUFDbkU7WUFFRCxXQUFXLElBQUksU0FBUyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7U0FDekM7UUFFRCx1QkFBdUI7UUFDdkIsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDaEUsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDOUMsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7OztPQVNHO0lBQ0gsZUFBZSxDQUFDLE9BQU8sRUFBRSxZQUFZLEVBQUUsT0FBTztRQUM1QyxNQUFNLFNBQVMsR0FBRyxXQUFXLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3JELE1BQU0sYUFBYSxHQUFHLFdBQVcsQ0FBQyxhQUFhLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDOUQsSUFBSSxlQUFlLEdBQUcsRUFBRSxDQUFDO1FBQ3pCLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDckMsZUFBZSxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUNyQyxJQUFJLENBQUMsRUFBRSxDQUFDLEdBQUcsR0FBRyxXQUFXLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUMzQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUNiO1FBRUQsSUFBSSxtQkFBbUIsR0FBRywwQkFBMEIsQ0FBQztRQUNyRCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxFQUFFO1lBQzFDLE1BQU0sa0JBQWtCLEdBQUcsT0FBTyxDQUFDLGNBQWM7aUJBQzlDLEdBQUcsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksR0FBRyxXQUFXLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7WUFFNUQsbUJBQW1CLEdBQUcsUUFBUSxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztTQUNuRTtRQUVELG1FQUFtRTtRQUNuRSxzRkFBc0Y7UUFDdEYsd0NBQXdDO1FBRXhDLE1BQU0sU0FBUyxHQUFHLGVBQWUsZUFBZSxRQUFRO1lBQ3RELGtCQUFrQixTQUFTLGlCQUFpQixhQUFhLEdBQUc7WUFDNUQsbUJBQW1CO1lBQ25CLG1CQUFtQixDQUFDO1FBRXRCLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQzlELE1BQU0sS0FBSyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVqRSxPQUFPLEtBQUssQ0FBQztRQUNmLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsbUJBQW1CLENBQUMsT0FBTztRQUN6QixNQUFNLFdBQVcsR0FBRyx1QkFBdUI7WUFDekMscUJBQXFCLFdBQVcsQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLEdBQUc7WUFDMUQsMEJBQTBCO1lBQzFCLGlFQUFpRSxDQUFDO1FBRXBFLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ2hFLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFDeEMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUN4QixjQUFjLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUU7Z0JBQ3JDLEtBQUssRUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFDckIsS0FBSyxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2FBQ3RCLENBQUMsQ0FBQyxDQUFDO1FBQ04sQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7Ozs7OztPQWVHO0lBQ0gsY0FBYyxDQUFDLE9BQU8sRUFBRSxPQUFPO1FBQzdCLE1BQU0sUUFBUSxHQUFHLFdBQVcsQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDcEQsSUFBSSxtQkFBbUIsR0FBRywwQkFBMEIsQ0FBQztRQUNyRCxJQUFJLGVBQWUsR0FBRyxFQUFFLENBQUM7UUFFekIsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFO1lBQzlDLE1BQU0sa0JBQWtCLEdBQUcsT0FBTyxDQUFDLGtCQUFrQjtpQkFDbEQsR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxHQUFHLFdBQVcsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztZQUU1RCxtQkFBbUIsR0FBRyxRQUFRLGtCQUFrQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO1NBQ25FO1FBRUQsdURBQXVEO1FBQ3ZELGdGQUFnRjtRQUNoRixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxFQUFFO1lBQ3pDLGVBQWUsR0FBRyxPQUFPLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FDekMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsV0FBVyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FDM0MsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDYjtRQUVELE1BQU0sbUJBQW1CLEdBQUcsa0JBQWtCLGVBQWU7MEJBQ3ZDLFFBQVE7eUJBQ1QsUUFBUTtRQUN6QixtQkFBbUI7K0JBQ0ksQ0FBQztRQUU1QixNQUFNLG1CQUFtQixHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUMsa0JBQWtCLGVBQWU7eUJBQ2xELE1BQU07d0JBQ1AsTUFBTTtRQUN0QixtQkFBbUI7ZUFDWixNQUFNLG9DQUFvQyxDQUFDO1FBRXRELElBQUksV0FBVyxHQUFHLG1CQUFtQixDQUFDO1FBRXRDLElBQUksT0FBTyxDQUFDLGVBQWUsRUFBRTtZQUMzQixXQUFXLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztTQUNoRTtRQUVELE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ2hFLElBQUksT0FBTyxDQUFDLGVBQWUsRUFBRTtnQkFDM0IsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFlBQVksRUFBRSxNQUFNLEVBQUUsRUFBRTtvQkFDdEQsTUFBTSxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDO29CQUNyQyxPQUFPLFlBQVksQ0FBQyxHQUFHLENBQUMsRUFBRSxHQUFHLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQztnQkFDL0MsQ0FBQyxFQUFFLElBQUksR0FBRyxFQUFFLENBQUMsQ0FBQzthQUNmO1lBQ0QsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNyQyxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILGFBQWEsQ0FBQyxPQUFPO1FBQ25CLE1BQU0sTUFBTSxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQztZQUNqRCxDQUFDLENBQUMsWUFBWSxXQUFXLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUN0RCxDQUFDLENBQUMsS0FBSyxXQUFXLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsTUFBTTtnQkFDMUQsV0FBVyxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7UUFFdkMsTUFBTSxLQUFLLEdBQUcsMEJBQTBCLE1BQU0sV0FBVyxDQUFDO1FBRTFELE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQzFELE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQzlDLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxhQUFhO1FBQ1gsT0FBTyxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDakMsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxjQUFjLENBQUMsTUFBTSxFQUFFLE9BQU87UUFDNUIsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNqQywrRUFBK0U7WUFDL0UsMkJBQTJCO1lBQzNCLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLEVBQUU7Z0JBQ3pDLE9BQU8sT0FBTyxDQUFDLGFBQWEsQ0FBQzthQUM5QjtZQUVELDhEQUE4RDtZQUM5RCxPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNqQyx3RUFBd0U7Z0JBQ3hFLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsRUFBRTtvQkFDM0MsT0FBTyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO3dCQUN2QyxJQUFJLENBQUMsbUJBQW1CLEdBQUcsS0FBSyxDQUFDO29CQUNuQyxDQUFDLENBQUMsQ0FBQztpQkFDSjtZQUNILENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ1gsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUM7WUFDbEMsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDZCxJQUFJLEtBQUssQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO2dCQUN0QixPQUFPLEVBQUUsQ0FBQzthQUNYO1lBRUQsTUFBTSxZQUFZLEdBQUcsRUFBRSxDQUFDO1lBQ3hCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUNyQyxZQUFZLENBQUMsSUFBSSxDQUFDLGNBQWMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7YUFDMUU7WUFFRCxNQUFNLEtBQUssR0FBRywyQkFBMkIsTUFBTSxVQUFVLEdBQUcsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUVwRixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtnQkFDMUQsSUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLFdBQVcsQ0FBQyxFQUFFO29CQUMzRSxPQUFPO3dCQUNMLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQyxDQUFDO3dCQUN4QixLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsQ0FBQztxQkFDdEIsQ0FBQztnQkFDSixDQUFDLENBQUMsQ0FBQztnQkFFSCxVQUFVLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsV0FBVyxDQUFDLEVBQUUsQ0FBQyxXQUFXLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUV4RSxPQUFPLFVBQVUsQ0FBQztZQUNwQixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsWUFBWSxDQUFDLE9BQU8sRUFBRSxrQkFBa0I7UUFDdEMsTUFBTSxXQUFXLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FDM0IsMkJBQTJCLE1BQU0sV0FBVyxNQUFNLGtDQUFrQyxDQUFDO1FBRXZGLE1BQU0sY0FBYyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBRWhFLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ25FLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxlQUFlLEVBQUUsTUFBTSxFQUFFLEVBQUU7Z0JBQ3pELE1BQU0sQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQztnQkFDckMsT0FBTyxlQUFlLENBQUMsR0FBRyxDQUFDLEVBQUUsR0FBRyxNQUFNLEVBQUUsTUFBTSxJQUFJLGtCQUFrQixDQUFDLENBQUM7WUFDeEUsQ0FBQyxFQUFFLElBQUksR0FBRyxFQUFFLENBQUMsQ0FBQztRQUNoQixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILGlCQUFpQjtRQUNmLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxJQUFJLENBQUM7SUFDbEMsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxrQkFBa0I7UUFDaEIsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFDekIsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7SUFDM0IsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxlQUFlO1FBQ2IsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFDekIsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7SUFDM0IsQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxZQUFZLENBQUMifQ==