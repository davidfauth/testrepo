"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-12-30.
 */
Object.defineProperty(exports, "__esModule", { value: true });
const Bluebird = require("bluebird");
const umd_1 = require("linkurious-shared/umd");
const _ = require("lodash");
const through = require("through");
const CappedQueue = require("../../../lib/CappedQueue");
const NotFoundError_1 = require("../../models/errors/NotFoundError");
const NotSupportedError_1 = require("../../models/errors/NotSupportedError");
const LKE = require("../../services");
const DAO_1 = require("../DAO");
const Utils = LKE.getUtils();
const Config = LKE.getConfig();
const Errors = LKE.getErrors();
const NODE_STATISTICS_BATCH_SIZE = 20;
const READ_BY_ID_BATCH_SIZE = 50;
const SUPERNODE_CACHE_SIZE = 5000;
const MAX_GET_ADJACENT_NODES_LIMIT = 10000;
/**
 * GraphFeatures
 *
 * @property immutableNodeCategories  Whether node categories are immutable for this vendor
 * @property [maxNodeCategories]      Maximum number of categories for a node
 * @property canCount                 Whether the graph can count nodes and edges
 * @property alerts                   Whether alerts are supported
 * @property alternativeIds           Whether the DAO supports alternative ids
 * @property dialects                 List of supported dialects
 * @property canDryRun                Whether the DAO is able to perform a dryRun
 * @property supportNativeDate        Whether the DAO is able to store dates (without using a string or a number type)
 */
class GraphDAO extends DAO_1.DAO {
    /**
     * @param vendor           Name of the vendor for this DAO (e.g.: neo4j, elasticSearch)
     * @param requiredOptions  List of required option properties
     * @param availableOptions List of available option properties
     * @param options          DAO constructor options
     * @param features         Features of the Graph DAO
     * @param connectors       Connectors of the DAO
     * @param drivers          Driver to use from a given version
     */
    constructor(vendor, requiredOptions, availableOptions, options, features, connectors, drivers) {
        super('Graph', vendor, requiredOptions, availableOptions.concat([
            // name of the property used as alternative ID for node and edges
            'alternativeNodeId',
            'alternativeEdgeId',
            // node properties for latitude and longitude (for geographical layout)
            'latitudeProperty',
            'longitudeProperty'
        ]), options, undefined, connectors, drivers);
        if (!features) {
            throw Errors.technical('bug', 'Graph DAO: "features" is required');
        }
        this.features = features;
        Utils.check.properties('features', features, {
            immutableNodeCategories: { required: true, type: 'boolean' },
            maxNodeCategories: { check: ['integer', 0] },
            canCount: { required: true, type: 'boolean' },
            alerts: { required: true, type: 'boolean' },
            alternativeIds: { required: true, type: 'boolean' },
            dialects: { required: true, arrayItem: { check: 'nonEmpty' } },
            canDryRun: { required: true, type: 'boolean' },
            supportNativeDate: { required: true, type: 'boolean' }
        });
        this.isSupernodeCache = new CappedQueue(SUPERNODE_CACHE_SIZE);
    }
    /**
     * Special properties that can't be read, created or updated.
     */
    get specialProperties() {
        return this.driver.$specialProperties;
    }
    /**
     * Create a GraphDAO instance.
     *
     * @param vendor  Vendor name
     * @param options GraphDAO constructor options
     */
    static createGraphDAOInstance(vendor, options) {
        return DAO_1.DAO.createDAOInstance('Graph', vendor, options);
    }
    /**
     * Check if `dialect` is supported by this Graph DAO.
     *
     * @param dialect           Name of a query dialect
     * @param [throwIfNot=true] Whether to reject if the condition is not met
     */
    checkDialect(dialect, throwIfNot = true) {
        if (throwIfNot) {
            // this throws an error if dialect is not in this.features.dialect
            Utils.check.values('dialect', dialect, this.features.dialects);
            return true;
        }
        // non-throwing alternative
        for (let i = 0; i < this.features.dialects.length; ++i) {
            if (this.features.dialects[i] === dialect) {
                return true;
            }
        }
        return false;
    }
    /**
     * Encode value in a string that can be inserted in a query template.
     *
     * @param value
     * @param serializer
     */
    quote(value, serializer) {
        return this.driver.$quote(value, serializer);
    }
    /**
     * Check if the given edge ID is legal. Throw an error if not.
     *
     * @param key
     * @param id
     */
    checkEdgeId(key, id) {
        return this.driver.$checkEdgeId(key, id);
    }
    /**
     * Check if the given node ID is legal. Throw an error if not.
     *
     * @param key
     * @param id
     */
    checkNodeId(key, id) {
        return this.driver.$checkNodeId(key, id);
    }
    /**
     * Check if an array of node IDs is legal. Throw an error if not.
     *
     * @param key
     * @param nodeIds
     * @param [minSize]
     */
    checkNodeIds(key, nodeIds, minSize) {
        Utils.check.array(key, nodeIds, minSize);
        nodeIds.map((nodeId, i) => this.checkNodeId(key + '[' + i + ']', nodeId));
    }
    /**
     * Check if an array of edge IDs is legal. Throw an error if not.
     *
     * @param key
     * @param edgeIds
     * @param [minSize]
     */
    checkEdgeIds(key, edgeIds, minSize) {
        Utils.check.array(key, edgeIds, minSize);
        edgeIds.map((edgeId, i) => this.checkEdgeId(key + '[' + i + ']', edgeId));
    }
    /**
     * Check if an array of alternative IDs is legal.
     *
     * @param key       Field name of this array of IDs
     * @param ids       Array of alternative IDs to check
     * @param [minSize] Minimum size of the array of IDs
     */
    static checkAlternativeIds(key, ids, minSize) {
        Utils.check.stringArray(key, ids, minSize, undefined, true);
    }
    /**
     * Check if the given alternative ID is legal.
     *
     * @param key
     * @param id
     */
    static checkAlternativeId(key, id) {
        Utils.check.nonEmpty(key, id);
    }
    /**
     * Called at the begin of the internal indexation phase for additional initializations.
     * Not called for external indices.
     */
    onInternalIndexation() {
        return this.driver.$onInternalIndexation();
    }
    /**
     * List all `edgeTypes`, `nodeCategories`, `edgeProperties`, `nodeProperties`
     * that exist in the graph database.
     */
    getSimpleSchema() {
        return this.driver.$getSimpleSchema();
    }
    /**
     * Count the number of nodes.
     *
     * @param [approx] Allow an approximated answer
     */
    getNodeCount(approx = false) {
        if (!this.features.canCount) {
            return Errors.business('not_supported', 'Counting nodes is not supported by ' + this.vendor + '.', true);
        }
        else {
            return this.driver.$getNodeCount(approx);
        }
    }
    /**
     * Count the number of edges.
     *
     * @param [approx] Allow an approximated answer
     */
    getEdgeCount(approx = false) {
        if (!this.features.canCount) {
            return Errors.business('not_supported', 'Counting edges is not supported by ' + this.vendor + '.', true);
        }
        else {
            return this.driver.$getEdgeCount(approx);
        }
    }
    /**
     * @param ids        IDs of the nodes to retrieve the statistics for
     * @param statistics Map indexed by nodeId of LkNodeStatistics where to add the supernode statistic
     */
    addSupernodeStatistic(ids, statistics) {
        // filter out nodes where the supernode statistic is already defined
        const uncheckedNodes = ids.filter(nodeId => Utils.noValue(statistics.get(nodeId).supernode));
        return this.isSuperNode(uncheckedNodes).then(superNodeResult => {
            uncheckedNodes.forEach(nodeId => {
                statistics.get(nodeId).supernode = superNodeResult.get(nodeId);
            });
        });
    }
    /**
     * @param ids                          IDs of the nodes to retrieve the statistics for
     * @param statistics                   Map indexed by nodeId of LkNodeStatistics where to add the digest
     * @param options
     * @param [options.readableTypes]      Exclusive list of edge types to restrict the result
     */
    addDigestStatistic(ids, statistics, options) {
        return this.addSupernodeStatistic(ids, statistics).then(() => {
            const [supernodes, ordinaryNodes] = _.partition(ids, id => statistics.get(id).supernode);
            // we add the edge digest only for supernodes
            const addEdgeDigest = Bluebird.map(supernodes, nodeId => {
                return this.getEdgeDigest(nodeId, { readableTypes: options.readableTypes }).then(digest => {
                    statistics.get(nodeId).supernodeDigest = digest;
                });
            });
            // we add the complete digest for other nodes
            const addAdjacencyDigest = Bluebird.map(ordinaryNodes, nodeId => {
                return this.getAdjacencyDigest([nodeId]).then(digest => {
                    statistics.get(nodeId).digest = digest;
                });
            });
            return Bluebird.join(addEdgeDigest, addAdjacencyDigest).return();
        });
    }
    /**
     * @param ids                          IDs of the nodes to retrieve the statistics for
     * @param statistics                   Map indexed by nodeId of LkNodeStatistics where to add the degree
     * @param options
     * @param [options.readableCategories] Exclusive list of node categories to restrict the result
     * @param [options.readableTypes]      Exclusive list of edge types to restrict the result
     */
    addDegreeStatistic(ids, statistics, options) {
        return this.addSupernodeStatistic(ids, statistics).then(() => {
            const [supernodes, ordinaryNodes] = _.partition(ids, id => statistics.get(id).supernode);
            const supernodeThreshold = Config.get('advanced.supernodeThreshold');
            // we add the supernodeThreshold for supernodes
            supernodes.forEach(superNodeId => {
                // TODO #1413 remove all unnecessary typescript casting (LkNodeStatistics)
                // map.get does not guarantee that the result is defined. Using an array of IDs
                // along a Map of these IDs is probably not the best way to do things here
                // use the following:
                // class NodeStats extends Map<string, LkNodeStats> {
                //   isSupernode(id: string): boolean {
                //     const s: LkNodeStats | undefined = this.get(id);
                //     return !!s && s.supernode;
                //   }
                // }
                statistics.get(superNodeId).supernodeDegree = supernodeThreshold;
            });
            if (ordinaryNodes.length === 0) {
                return;
            }
            // we add the degree for other nodes
            return this.getNodeDegree(ordinaryNodes, _.defaults({ discreteResults: true }, options)).then(nodeDegreeResult => {
                ordinaryNodes.forEach(nodeId => {
                    const degree = nodeDegreeResult.get(nodeId);
                    statistics.get(nodeId).degree = degree;
                });
            });
        });
    }
    /**
     * @param nodes                        Nodes without statistics
     * @param options
     * @param [options.withDigest]         Whether to include the adjacency digest in the returned nodes
     * @param [options.withDegree]         Whether to include the degree in the returned nodes
     * @param [options.readableCategories] Exclusive list of node categories to restrict the result
     * @param [options.readableTypes]      Exclusive list of edge types to restrict the result
     */
    addStatistics(nodes, options) {
        if (!options.withDigest && !options.withDegree) {
            return Bluebird.resolve(nodes);
        }
        // we divide the input into slices of NODE_STATISTICS_BATCH_SIZE nodes for which we batch the statistics request
        return Utils.sliceMap(nodes, NODE_STATISTICS_BATCH_SIZE, currentBatch => {
            const nodeIds = currentBatch.map(node => node.id);
            // add statistics for each node slice then merge the slices
            return this.getStatistics(nodeIds, options)
                .then(statisticsByNodeId => {
                currentBatch.forEach(node => {
                    node.statistics = statisticsByNodeId.get(node.id);
                });
            })
                .return(currentBatch);
        }).then(batchesWithStatistics => _.flatten(batchesWithStatistics));
    }
    /**
     * @param ids                          IDs of the nodes to retrieve the statistics for
     * @param options
     * @param [options.withDigest]         Whether to include the adjacency digest in the returned nodes
     * @param [options.withDegree]         Whether to include the degree in the returned nodes
     * @param [options.readableCategories] Exclusive list of node categories to restrict the result
     * @param [options.readableTypes]      Exclusive list of edge types to restrict the result
     */
    getStatistics(ids, options) {
        if (_.isEmpty(ids)) {
            return Bluebird.resolve(new Map());
        }
        const statisticsByNodeId = ids.reduce((statistics, nodeId) => statistics.set(nodeId, {}), new Map());
        return Bluebird.resolve()
            .then(() => {
            if (options.withDigest) {
                return this.addDigestStatistic(ids, statisticsByNodeId, options);
            }
            return;
        })
            .then(() => {
            if (options.withDegree) {
                return this.addDegreeStatistic(ids, statisticsByNodeId, options);
            }
            return;
        })
            .return(statisticsByNodeId);
    }
    /**
     * Get a stream of all nodes.
     */
    getNodeStream(options) {
        return this.driver.$getNodeStream(options);
    }
    /**
     * Get a list of nodes by ID.
     *
     * @param options
     * @param options.ids                  List of IDs to read
     * @param [options.alternativeId]      The property to match `options.ids` on (instead of the actual IDs)
     * @param [options.ignoreMissing]      Whether to fail if there are missing nodes
     * @param [options.withDigest]         Whether to include the adjacency digest in the returned nodes
     * @param [options.withDegree]         Whether to include the degree in the returned nodes
     * @param [options.readableCategories] Exclusive list of node categories to restrict the result (used for the node degree)
     * @param [options.readableTypes]      Exclusive list of edge types to restrict the result (used for the node degree and the edge digest)
     */
    getNodesByID(options) {
        return Bluebird.resolve().then(() => {
            if (_.isEmpty(options.ids)) {
                return [];
            }
            // check IDs
            if (Utils.noValue(options.alternativeId)) {
                this.checkNodeIds('options.ids', options.ids);
            }
            else {
                if (!this.features.alternativeIds) {
                    throw Errors.business('not_supported', `Alternative ids are not supported by ${this.vendor}.`);
                }
                GraphDAO.checkAlternativeIds('options.ids', options.ids);
            }
            return Utils.sliceMap(options.ids, READ_BY_ID_BATCH_SIZE, batchIds => {
                const sliceOptions = Utils.clone(options);
                sliceOptions.ids = batchIds;
                return this.driver.$getNodesByID(sliceOptions);
            })
                .then(nodeBatches => _.flatten(nodeBatches))
                .then(nodes => {
                if (!options.ignoreMissing) {
                    Utils.checkMissing('node', options.ids, nodes, options.alternativeId);
                }
                return nodes;
            })
                .then(nodes => this.addStatistics(nodes, options));
        });
    }
    /**
     * Get a list of edges by ID.
     *
     * @param options
     * @param options.ids             List of IDs to read
     * @param [options.alternativeId] The property to match `options.ids` on (instead of the actual IDs)
     * @param [options.ignoreMissing] Whether to fail if there are missing nodes
     */
    getEdgesByID(options) {
        return Bluebird.resolve().then(() => {
            if (_.isEmpty(options.ids)) {
                return [];
            }
            // check IDs
            if (Utils.noValue(options.alternativeId)) {
                this.checkEdgeIds('options.ids', options.ids);
            }
            else {
                if (!this.features.alternativeIds) {
                    throw Errors.business('not_supported', `Alternative ids are not supported by ${this.vendor}.`);
                }
                GraphDAO.checkAlternativeIds('options.ids', options.ids);
            }
            return Utils.sliceMap(options.ids, READ_BY_ID_BATCH_SIZE, batchIds => {
                const sliceOptions = Utils.clone(options);
                sliceOptions.ids = batchIds;
                return this.driver.$getEdgesByID(sliceOptions);
            })
                .then(edgeBatches => _.flatten(edgeBatches))
                .then(edges => {
                if (!options.ignoreMissing) {
                    Utils.checkMissing('edge', options.ids, edges, options.alternativeId);
                }
                return edges;
            });
        });
    }
    /**
     * Get all the adjacent nodes and edges to one or more source nodes (`nodeIds`).
     *
     * @param nodeIds                      IDs of the nodes to retrieve the neighbors for
     * @param options
     * @param [options.limit]              Maximum number of returned nodes
     * @param [options.limitType]          Order direction used to limit the result ('id', 'lowestDegree' or 'highestDegree')
     * @param [options.nodeCategories]     Exclusive list of node categories to restrict the result (used for the expand)
     * @param [options.edgeTypes]          Exclusive list of edge types to restrict the result (used for the expand)
     * @param [options.ignoredNodeIds]     IDs of nodes we do not want in the results
     * @param [options.withDigest]         Whether to include the adjacency digest in the returned nodes
     * @param [options.withDegree]         Whether to include the degree in the returned nodes
     * @param [options.readableCategories] Exclusive list of node categories to restrict the result (used for the node degree and the expand)
     * @param [options.readableTypes]      Exclusive list of edge types to restrict the result (used for the node degree, the edge digest and the expand)
     */
    getAdjacentNodes(nodeIds, options) {
        return Bluebird.resolve()
            .then(() => {
            // TODO #1424 check if is the best error message (maybe we need an ExpandOptions model?)
            this.checkNodeIds('nodeIds', nodeIds, 1);
            if (Utils.hasValue(options.ignoredNodeIds)) {
                this.checkNodeIds('ignoredNodeIds', options.ignoredNodeIds);
            }
            if (Utils.hasValue(options.nodeCategories)) {
                Utils.check.stringArray('nodeCategories', options.nodeCategories, 1, undefined, true);
            }
            else {
                // to filter the expand on the readable categories is just an optimization
                // the resulting subgraph will be filtered in the DataProxy anyway
                options.nodeCategories = options.readableCategories;
            }
            if (Utils.hasValue(options.edgeTypes)) {
                Utils.check.stringArray('edgeTypes', options.edgeTypes, 1, undefined, true);
            }
            else {
                options.edgeTypes = options.readableTypes;
            }
            if ((Utils.hasValue(options.nodeCategories) && _.isEmpty(options.nodeCategories)) ||
                (Utils.hasValue(options.edgeTypes) && _.isEmpty(options.edgeTypes))) {
                // nothing to expand
                return [];
            }
            if (Utils.hasValue(options.limit)) {
                Utils.check.integer('limit', options.limit, 1, MAX_GET_ADJACENT_NODES_LIMIT);
            }
            else {
                // #1628 if limit is not defined we set it at 10k nodes
                options.limit = MAX_GET_ADJACENT_NODES_LIMIT;
            }
            if (Utils.noValue(options.limitType)) {
                options.limitType = 'id';
            }
            Utils.check.values('limitType', options.limitType, ['id', 'lowestDegree', 'highestDegree']);
            const expandOptions = {
                limit: options.limit,
                limitType: options.limitType,
                nodeCategories: options.nodeCategories,
                edgeTypes: options.edgeTypes,
                ignoredNodeIds: options.ignoredNodeIds
            };
            return this.driver
                .$getNodesByID({ ids: nodeIds })
                .then(existingNodes => Utils.checkMissing('node', nodeIds, existingNodes))
                .then(() => this.driver.$getAdjacentNodes(nodeIds, expandOptions));
        })
            .then(nodes => this.addStatistics(nodes, options));
    }
    /**
     * Get the edges between two set of nodes.
     *
     * @param nodeIds                  IDs of the first set of nodes
     * @param otherNodeIds             IDs of the second set of nodes
     * @param options
     * @param [options.edgeTypes]      Exclusive list of edge types to restrict the result
     * @param [options.nodeCategories] Exclusive list of node categories (of nodes in `otherNodeIds`) to restrict the result
     */
    getMutualEdges(nodeIds, otherNodeIds, options) {
        if (_.isEmpty(nodeIds) || _.isEmpty(otherNodeIds)) {
            return Bluebird.resolve([]);
        }
        if ((Utils.hasValue(options.edgeTypes) && _.isEmpty(options.edgeTypes)) ||
            (Utils.hasValue(options.nodeCategories) && _.isEmpty(options.nodeCategories))) {
            // no edge to retrieve
            return Bluebird.resolve([]);
        }
        return Bluebird.resolve().then(() => {
            this.checkNodeIds('nodeIds', nodeIds);
            this.checkNodeIds('otherNodeIds', otherNodeIds);
            return this.driver.$getMutualEdges(nodeIds, otherNodeIds, options, this.isSupernodeCache);
        });
    }
    /**
     * Provide a neighborhood edge digest for a specific node.
     *
     * @param nodeId                  ID of the node
     * @param options
     * @param [options.readableTypes] Exclusive list of edge types to restrict the result
     */
    getEdgeDigest(nodeId, options) {
        return Bluebird.resolve().then(() => {
            this.checkNodeId('nodeId', nodeId);
            return this.driver.$getEdgeDigest(nodeId, options);
        });
    }
    /**
     * Provide a neighborhood digest of a specified subset of nodes.
     *
     * @param nodeIds IDs of the nodes
     */
    getAdjacencyDigest(nodeIds) {
        return Bluebird.resolve().then(() => {
            this.checkNodeIds('nodeIds', nodeIds, 1);
            return this.driver.$getAdjacencyDigest(nodeIds);
        });
    }
    /**
     * Return a map indexed by id populated with `true` if the node is a supernode.
     * A supernode is a node with a number of relationships greater or equal than `supernodeThreshold`.
     * Return `false` if the node is not found.
     *
     * @param nodeIds IDs of the nodes
     */
    isSuperNode(nodeIds) {
        if (_.isEmpty(nodeIds)) {
            return Bluebird.resolve(new Map());
        }
        const supernodeThreshold = Config.get('advanced.supernodeThreshold');
        this.checkNodeIds('nodeIds', nodeIds);
        return this.driver
            .$isSuperNode(nodeIds, supernodeThreshold)
            .then((supernodesMap) => {
            for (const [nodeId, isSuperNode] of supernodesMap.entries()) {
                // we cache every node that is a supernode (up to SUPERNODE_CACHE_SIZE nodes)
                if (isSuperNode) {
                    this.isSupernodeCache.add(nodeId);
                }
            }
            return supernodesMap;
        });
    }
    /**
     * Return the degrees of the specified nodes.
     * If `discreteResults` is false:
     *   Return the degree of the specified node if `nodeIds` has cardinality 1.
     *   If multiple `nodeIds` are specified, return the cardinality of the intersection
     *   of the neighbors of the nodes (not including the nodes in input themselves).
     * If `discreteResults` is true:
     *   Return a map indexed by id populated with the degree of each node.
     *
     * @param nodeIds                      IDs of the nodes
     * @param options
     * @param [options.readableCategories] Exclusive list of node categories to restrict the result
     * @param [options.readableTypes]      Exclusive list of edge types to restrict the result
     * @param [options.discreteResults]    Whether to return the degree of each node
     */
    getNodeDegree(nodeIds, options) {
        if ((Utils.hasValue(options.readableTypes) && _.isEmpty(options.readableTypes)) ||
            (Utils.hasValue(options.readableCategories) && _.isEmpty(options.readableCategories))) {
            // no readable type or category, we return a degree of 0 for every node
            const zeroDegree = nodeIds.reduce((acc, v) => acc.set(v, 0), new Map());
            return Bluebird.resolve(zeroDegree);
        }
        return Bluebird.resolve().then(() => {
            this.checkNodeIds('nodeIds', nodeIds, 1);
            return this.driver.$getNodeDegree(nodeIds, options);
        });
    }
    // TODO TS2019 refactor above here
    /**
     * Add a node to the graph.
     */
    async createNode(newNode) {
        // check amount of node category
        Utils.check.stringArray('categories', newNode.categories, 1, this.features.maxNodeCategories);
        return this.driver.$createNode(newNode);
    }
    /**
     * Update a subset of properties and categories of a node.
     * Keep every other property and category of the node unchanged.
     */
    async updateNode(params) {
        this.checkNodeId('nodeId', params.id);
        // check category immutability
        if (this.features.immutableNodeCategories &&
            (params.addedCategories.length > 0 || params.deletedCategories.length > 0)) {
            throw new NotSupportedError_1.NotSupportedError('Updating node categories', this.vendor);
        }
        const newNode = await this.driver.$updateNode(params);
        if (Utils.noValue(newNode)) {
            throw new NotFoundError_1.NotFoundError('node', params.id);
        }
        return newNode;
    }
    /**
     * Add an edge to the graph.
     */
    async createEdge(newEdge) {
        this.checkNodeId('source', newEdge.source);
        this.checkNodeId('target', newEdge.target);
        return this.driver.$createEdge(newEdge);
    }
    /**
     * Update a subset of properties of an edge. Keep every other property of the edge unchanged.
     * It's not possible to update the type of an edge.
     */
    async updateEdge(params) {
        this.checkEdgeId('edgeId', params.id);
        const newEdge = await this.driver.$updateEdge(params);
        if (Utils.noValue(newEdge)) {
            throw new NotFoundError_1.NotFoundError('edge', params.id);
        }
        return newEdge;
    }
    // TODO TS2019 refactor under here
    /**
     * Delete a node and its adjacent edges from the graph.
     *
     * @param nodeId ID of the node to delete
     */
    deleteNode(nodeId) {
        return Bluebird.resolve().then(() => {
            this.checkNodeId('nodeId', nodeId);
            return this.driver.$deleteNode(nodeId);
        });
    }
    /**
     * Get a stream of all edges.
     */
    getEdgeStream(options) {
        return this.driver.$getEdgeStream(options);
    }
    /**
     * Delete an edge from the graph.
     *
     * @param edgeId ID of the edge to delete
     */
    deleteEdge(edgeId) {
        return Bluebird.resolve().then(() => {
            this.checkEdgeId('edgeId', edgeId);
            return this.driver.$deleteEdge(edgeId);
        });
    }
    /**
     * Check that the given graph query is syntactically correct.
     */
    async dryRun(query) {
        if (!this.features.canDryRun) {
            return Promise.resolve();
        }
        return Promise.resolve().then(() => {
            return this.driver.$dryRun(query);
        });
    }
    /**
     * Generate template data with dummy values to obtain a valid query for a dry run.
     */
    getDummyTemplateData(templateFields) {
        const templateData = {};
        const dummyString = '-';
        // TODO #1555 Generate dummy values for TemplateField Types
        for (const template of templateFields) {
            let dummyValue;
            switch (template.type) {
                case umd_1.TemplateFieldType.NODE:
                    dummyValue = this.driver.$getDummyNodeId();
                    break;
                case umd_1.TemplateFieldType.NODE_SET:
                    dummyValue = [this.driver.$getDummyNodeId()];
                    break;
                case umd_1.TemplateFieldType.BOOLEAN:
                    dummyValue = false;
                    break;
                case umd_1.TemplateFieldType.NUMBER:
                    dummyValue = (template.options && (template.options.min || template.options.max)) || 0;
                    break;
                case umd_1.TemplateFieldType.ENUM:
                    dummyValue = _.get(template.options, 'values.0.value');
                    break;
                case umd_1.TemplateFieldType.DATE:
                case umd_1.TemplateFieldType.DATE_TIME:
                    const date = ((template.options &&
                        (template.options.default || template.options.min || template.options.max)) ||
                        '1969-01-01');
                    dummyValue = new Date(date).toISOString();
                    break;
                default:
                    dummyValue = dummyString;
            }
            templateData[template.key] = dummyValue;
        }
        return templateData;
    }
    /**
     * Return true is the query is a write query.
     */
    isWrite(query) {
        return this.driver.$isWrite(query);
    }
    /**
     * Check if a query is correct.
     * Throw if the query is not valid or not authorized.
     * Return true if the query is a write query.
     */
    checkQuery(query) {
        return this.driver.$checkQuery(query);
    }
    rawQuery(options, populated = true) {
        return Bluebird.resolve()
            .then(() => {
            options = _.defaults(options);
            if (options.dialect === undefined || options.dialect === null) {
                options.dialect = this.features.dialects[0];
            }
            Utils.check.string('options.dialect', options.dialect, true);
            this.checkDialect(options.dialect);
            Utils.check.stringArray('options.queries', options.queries, 1, undefined, true);
            Utils.check.boolean('options.populated', populated);
            Utils.check.integer('options.limit', options.limit, 1);
            return this.driver.$rawQuery({
                dialect: options.dialect,
                queries: options.queries,
                populated: populated,
                limit: options.limit
            });
        })
            .then(readableStream => {
            if (!populated) {
                // we can't add statistics if the result is not populated
                return readableStream;
            }
            const self = this;
            let spool = [];
            return Utils.safePipe(readableStream, through(function (match) {
                spool.push(match);
                if (spool.length >= NODE_STATISTICS_BATCH_SIZE) {
                    // stop the flow to be able to retrieve the digest after collecting NODE_STATISTICS_BATCH_SIZE matches
                    // @ts-ignore
                    this.pause();
                    self
                        .addQueryMatchPopulatedStatistics(spool, options)
                        .then(matchesWithStatistics => {
                        matchesWithStatistics.forEach(matchWithStats => {
                            // @ts-ignore
                            this.emit('data', matchWithStats);
                        });
                        // spool = [] has to be called before this.resume()
                        // this.resume() may synchronously call this function again
                        spool = [];
                        // @ts-ignore
                        this.resume();
                    })
                        .catch(error => {
                        // @ts-ignore
                        this.emit('error', error);
                    });
                }
            }, function () {
                self
                    .addQueryMatchPopulatedStatistics(spool, options)
                    .then(matchesWithStatistics => {
                    matchesWithStatistics.forEach(match => {
                        // @ts-ignore
                        this.emit('data', match);
                    });
                    // @ts-ignore
                    this.emit('end');
                })
                    .catch(error => {
                    // @ts-ignore
                    this.emit('error', error);
                });
            }));
        });
    }
    /**
     * Add statistics to the nodes in each `QueryMatchPopulated`.
     *
     * We want to avoid to retrieve the statistics for the same node twice.
     * To avoid that, we extract all the nodes from the matches, we deduplicate them,
     * we retrieve the statistics for the deduplicated nodes and we set
     * the node statistics to the respective nodes in the matches.
     *
     * @param {QueryMatchPopulated[]} matches
     * @param {object}                options
     * @param {boolean}               [options.withDigest]         Whether to include the adjacency digest in the returned nodes
     * @param {boolean}               [options.withDegree]         Whether to include the degree in the returned nodes
     * @param {string[]}              [options.readableCategories] Exclusive list of node categories to restrict the result (used for the node degree)
     * @param {string[]}              [options.readableTypes]      Exclusive list of edge types to restrict the result (used for the node degree and the edge digest)
     */
    addQueryMatchPopulatedStatistics(matches, options) {
        // 1) we extract all the nodes from the matches and we deduplicate them
        const nodesByNodeId = new Map();
        for (let i = 0; i < matches.length; i++) {
            for (let y = 0; y < matches[i].nodes.length; y++) {
                const node = matches[i].nodes[y];
                nodesByNodeId.set(node.id, node);
            }
        }
        // 2) we retrieve the statistics for the deduplicated nodes
        const nodes = Array.from(nodesByNodeId.values());
        return this.addStatistics(nodes, options).then(() => {
            for (let i = 0; i < matches.length; i++) {
                for (let y = 0; y < matches[i].nodes.length; y++) {
                    const node = matches[i].nodes[y];
                    // 3) we set the node statistics to the respective nodes in the matches
                    node.statistics = nodesByNodeId.get(node.id).statistics;
                }
            }
            return matches;
        });
    }
}
exports.GraphDAO = GraphDAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGhEQU8uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2dyYXBoL2dyYXBoREFPLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRzs7QUFlSCxxQ0FBcUM7QUFDckMsK0NBSytCO0FBQy9CLDRCQUE0QjtBQUM1QixtQ0FBbUM7QUFFbkMsd0RBQXlEO0FBQ3pELHFFQUFnRTtBQUNoRSw2RUFBd0U7QUFHeEUsc0NBQXVDO0FBRXZDLGdDQUEyQjtBQUkzQixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUUvQixNQUFNLDBCQUEwQixHQUFHLEVBQUUsQ0FBQztBQUN0QyxNQUFNLHFCQUFxQixHQUFHLEVBQUUsQ0FBQztBQUNqQyxNQUFNLG9CQUFvQixHQUFHLElBQUksQ0FBQztBQVlsQyxNQUFNLDRCQUE0QixHQUFHLEtBQUssQ0FBQztBQUUzQzs7Ozs7Ozs7Ozs7R0FXRztBQUVILE1BQXNCLFFBQXdELFNBQVEsU0FBUztJQUs3Rjs7Ozs7Ozs7T0FRRztJQUNILFlBQ0UsTUFBYyxFQUNkLGVBQXlCLEVBQ3pCLGdCQUEwQixFQUMxQixPQUErQixFQUMvQixRQUF1QixFQUN2QixVQUEwRCxFQUMxRCxPQUEwRTtRQUUxRSxLQUFLLENBQ0gsT0FBTyxFQUNQLE1BQU0sRUFDTixlQUFlLEVBQ2YsZ0JBQWdCLENBQUMsTUFBTSxDQUFDO1lBQ3RCLGlFQUFpRTtZQUNqRSxtQkFBbUI7WUFDbkIsbUJBQW1CO1lBQ25CLHVFQUF1RTtZQUN2RSxrQkFBa0I7WUFDbEIsbUJBQW1CO1NBQ3BCLENBQUMsRUFDRixPQUFPLEVBQ1AsU0FBUyxFQUNULFVBQVUsRUFDVixPQUFPLENBQ1IsQ0FBQztRQUVGLElBQUksQ0FBQyxRQUFRLEVBQUU7WUFDYixNQUFNLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLG1DQUFtQyxDQUFDLENBQUM7U0FDcEU7UUFFRCxJQUFJLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztRQUN6QixLQUFLLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsUUFBUSxFQUFFO1lBQzNDLHVCQUF1QixFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFDO1lBQzFELGlCQUFpQixFQUFFLEVBQUMsS0FBSyxFQUFFLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxFQUFDO1lBQzFDLFFBQVEsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBQztZQUMzQyxNQUFNLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUM7WUFDekMsY0FBYyxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFDO1lBQ2pELFFBQVEsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQyxFQUFDO1lBQzFELFNBQVMsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBQztZQUM1QyxpQkFBaUIsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBQztTQUNyRCxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxXQUFXLENBQVMsb0JBQW9CLENBQUMsQ0FBQztJQUN4RSxDQUFDO0lBRUQ7O09BRUc7SUFDSCxJQUFJLGlCQUFpQjtRQUNuQixPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsa0JBQWtCLENBQUM7SUFDeEMsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksTUFBTSxDQUFDLHNCQUFzQixDQUNsQyxNQUFjLEVBQ2QsT0FBK0I7UUFFL0IsT0FBTyxTQUFHLENBQUMsaUJBQWlCLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxPQUFPLENBR3BELENBQUM7SUFDSixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSyxZQUFZLENBQUMsT0FBZSxFQUFFLFVBQVUsR0FBRyxJQUFJO1FBQ3JELElBQUksVUFBVSxFQUFFO1lBQ2Qsa0VBQWtFO1lBQ2xFLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUMvRCxPQUFPLElBQUksQ0FBQztTQUNiO1FBRUQsMkJBQTJCO1FBQzNCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDdEQsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxPQUFPLEVBQUU7Z0JBQ3pDLE9BQU8sSUFBSSxDQUFDO2FBQ2I7U0FDRjtRQUNELE9BQU8sS0FBSyxDQUFDO0lBQ2YsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksS0FBSyxDQUFDLEtBQXdCLEVBQUUsVUFBOEI7UUFDbkUsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsVUFBVSxDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksV0FBVyxDQUFDLEdBQVcsRUFBRSxFQUFVO1FBQ3hDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0lBQzNDLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLFdBQVcsQ0FBQyxHQUFXLEVBQUUsRUFBVTtRQUN4QyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0ksWUFBWSxDQUFDLEdBQVcsRUFBRSxPQUFpQixFQUFFLE9BQWdCO1FBQ2xFLEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxPQUFPLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDekMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDLEdBQUcsR0FBRyxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUM7SUFDNUUsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLFlBQVksQ0FBQyxHQUFXLEVBQUUsT0FBaUIsRUFBRSxPQUFnQjtRQUNsRSxLQUFLLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ3pDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQyxHQUFHLEdBQUcsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDO0lBQzVFLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSSxNQUFNLENBQUMsbUJBQW1CLENBQUMsR0FBVyxFQUFFLEdBQWEsRUFBRSxPQUFnQjtRQUM1RSxLQUFLLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLE9BQU8sRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDOUQsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksTUFBTSxDQUFDLGtCQUFrQixDQUFDLEdBQVcsRUFBRSxFQUFVO1FBQ3RELEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsQ0FBQztJQUNoQyxDQUFDO0lBRUQ7OztPQUdHO0lBQ0ksb0JBQW9CO1FBQ3pCLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO0lBQzdDLENBQUM7SUFFRDs7O09BR0c7SUFDSSxlQUFlO1FBQ3BCLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO0lBQ3hDLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ksWUFBWSxDQUFDLE1BQU0sR0FBRyxLQUFLO1FBQ2hDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRTtZQUMzQixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQ3BCLGVBQWUsRUFDZixxQ0FBcUMsR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLEdBQUcsRUFDekQsSUFBSSxDQUNMLENBQUM7U0FDSDthQUFNO1lBQ0wsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUMxQztJQUNILENBQUM7SUFFRDs7OztPQUlHO0lBQ0ksWUFBWSxDQUFDLE1BQU0sR0FBRyxLQUFLO1FBQ2hDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRTtZQUMzQixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQ3BCLGVBQWUsRUFDZixxQ0FBcUMsR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLEdBQUcsRUFDekQsSUFBSSxDQUNMLENBQUM7U0FDSDthQUFNO1lBQ0wsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUMxQztJQUNILENBQUM7SUFFRDs7O09BR0c7SUFDSyxxQkFBcUIsQ0FDM0IsR0FBYSxFQUNiLFVBQXlDO1FBRXpDLG9FQUFvRTtRQUNwRSxNQUFNLGNBQWMsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQ3pDLEtBQUssQ0FBQyxPQUFPLENBQUUsVUFBVSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQXNCLENBQUMsU0FBUyxDQUFDLENBQ3RFLENBQUM7UUFFRixPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsY0FBYyxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxFQUFFO1lBQzdELGNBQWMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUU7Z0JBQzdCLFVBQVUsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFzQixDQUFDLFNBQVMsR0FBRyxlQUFlLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ3ZGLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSyxrQkFBa0IsQ0FDeEIsR0FBYSxFQUNiLFVBQXlDLEVBQ3pDLE9BRUM7UUFFRCxPQUFPLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxHQUFHLEVBQUUsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUMzRCxNQUFNLENBQUMsVUFBVSxFQUFFLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQzdDLEdBQUcsRUFDSCxFQUFFLENBQUMsRUFBRSxDQUFFLFVBQVUsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFzQixDQUFDLFNBQVMsQ0FDekQsQ0FBQztZQUVGLDZDQUE2QztZQUM3QyxNQUFNLGFBQWEsR0FBRyxRQUFRLENBQUMsR0FBRyxDQUFDLFVBQVUsRUFBRSxNQUFNLENBQUMsRUFBRTtnQkFDdEQsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sRUFBRSxFQUFDLGFBQWEsRUFBRSxPQUFPLENBQUMsYUFBYSxFQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7b0JBQ3JGLFVBQVUsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFzQixDQUFDLGVBQWUsR0FBRyxNQUFNLENBQUM7Z0JBQ3hFLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUM7WUFFSCw2Q0FBNkM7WUFDN0MsTUFBTSxrQkFBa0IsR0FBRyxRQUFRLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxNQUFNLENBQUMsRUFBRTtnQkFDOUQsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtvQkFDcEQsVUFBVSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQXNCLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztnQkFDL0QsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDLENBQUMsQ0FBQztZQUVILE9BQU8sUUFBUSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUUsa0JBQWtCLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNuRSxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSyxrQkFBa0IsQ0FDeEIsR0FBYSxFQUNiLFVBQXlDLEVBQ3pDLE9BR0M7UUFFRCxPQUFPLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxHQUFHLEVBQUUsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUMzRCxNQUFNLENBQUMsVUFBVSxFQUFFLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQzdDLEdBQUcsRUFDSCxFQUFFLENBQUMsRUFBRSxDQUFFLFVBQVUsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFzQixDQUFDLFNBQVMsQ0FDekQsQ0FBQztZQUVGLE1BQU0sa0JBQWtCLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyw2QkFBNkIsQ0FBVyxDQUFDO1lBRS9FLCtDQUErQztZQUMvQyxVQUFVLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxFQUFFO2dCQUMvQiwwRUFBMEU7Z0JBQzFFLCtFQUErRTtnQkFDL0UsMEVBQTBFO2dCQUMxRSxxQkFBcUI7Z0JBQ3JCLHFEQUFxRDtnQkFDckQsdUNBQXVDO2dCQUN2Qyx1REFBdUQ7Z0JBQ3ZELGlDQUFpQztnQkFDakMsTUFBTTtnQkFDTixJQUFJO2dCQUNILFVBQVUsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFzQixDQUFDLGVBQWUsR0FBRyxrQkFBa0IsQ0FBQztZQUN6RixDQUFDLENBQUMsQ0FBQztZQUVILElBQUksYUFBYSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7Z0JBQzlCLE9BQU87YUFDUjtZQUVELG9DQUFvQztZQUNwQyxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsYUFBYSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBQyxlQUFlLEVBQUUsSUFBSSxFQUFDLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQ3pGLGdCQUFnQixDQUFDLEVBQUU7Z0JBQ2pCLGFBQWEsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUU7b0JBQzdCLE1BQU0sTUFBTSxHQUFJLGdCQUF3QyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDcEUsVUFBVSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQXNCLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztnQkFDL0QsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDLENBQ0YsQ0FBQztRQUNKLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSyxhQUFhLENBQ25CLEtBQWUsRUFDZixPQUtDO1FBRUQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFO1lBQzlDLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUNoQztRQUVELGdIQUFnSDtRQUNoSCxPQUFPLEtBQUssQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFFLDBCQUEwQixFQUFFLFlBQVksQ0FBQyxFQUFFO1lBQ3RFLE1BQU0sT0FBTyxHQUFHLFlBQVksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDbEQsMkRBQTJEO1lBQzNELE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDO2lCQUN4QyxJQUFJLENBQUMsa0JBQWtCLENBQUMsRUFBRTtnQkFDekIsWUFBWSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRTtvQkFDMUIsSUFBSSxDQUFDLFVBQVUsR0FBRyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUNwRCxDQUFDLENBQUMsQ0FBQztZQUNMLENBQUMsQ0FBQztpQkFDRCxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDMUIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQztJQUNyRSxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNJLGFBQWEsQ0FDbEIsR0FBYSxFQUNiLE9BS0M7UUFFRCxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDbEIsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLElBQUksR0FBRyxFQUFFLENBQUMsQ0FBQztTQUNwQztRQUVELE1BQU0sa0JBQWtCLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FDbkMsQ0FBQyxVQUFVLEVBQUUsTUFBTSxFQUFFLEVBQUUsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFDbEQsSUFBSSxHQUFHLEVBQUUsQ0FDVixDQUFDO1FBRUYsT0FBTyxRQUFRLENBQUMsT0FBTyxFQUFFO2FBQ3RCLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDVCxJQUFJLE9BQU8sQ0FBQyxVQUFVLEVBQUU7Z0JBQ3RCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLEdBQUcsRUFBRSxrQkFBa0IsRUFBRSxPQUFPLENBQUMsQ0FBQzthQUNsRTtZQUNELE9BQU87UUFDVCxDQUFDLENBQUM7YUFDRCxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1QsSUFBSSxPQUFPLENBQUMsVUFBVSxFQUFFO2dCQUN0QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLEVBQUUsa0JBQWtCLEVBQUUsT0FBTyxDQUFDLENBQUM7YUFDbEU7WUFDRCxPQUFPO1FBQ1QsQ0FBQyxDQUFDO2FBQ0QsTUFBTSxDQUFDLGtCQUFrQixDQUFDLENBQUM7SUFDaEMsQ0FBQztJQUVEOztPQUVHO0lBQ0ksYUFBYSxDQUFDLE9BS3BCO1FBQ0MsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7O09BV0c7SUFDSSxZQUFZLENBQUMsT0FRbkI7UUFDQyxPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ2xDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQzFCLE9BQU8sRUFBRSxDQUFDO2FBQ1g7WUFFRCxZQUFZO1lBQ1osSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsRUFBRTtnQkFDeEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxhQUFhLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2FBQy9DO2lCQUFNO2dCQUNMLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGNBQWMsRUFBRTtvQkFDakMsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUNuQixlQUFlLEVBQ2Ysd0NBQXdDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FDdkQsQ0FBQztpQkFDSDtnQkFFRCxRQUFRLENBQUMsbUJBQW1CLENBQUMsYUFBYSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQzthQUMxRDtZQUVELE9BQU8sS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLHFCQUFxQixFQUFFLFFBQVEsQ0FBQyxFQUFFO2dCQUNuRSxNQUFNLFlBQVksR0FHZCxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUN6QixZQUFZLENBQUMsR0FBRyxHQUFHLFFBQVEsQ0FBQztnQkFDNUIsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUNqRCxDQUFDLENBQUM7aUJBQ0MsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQztpQkFDM0MsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUNaLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFO29CQUMxQixLQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRSxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUM7aUJBQ3ZFO2dCQUNELE9BQU8sS0FBSyxDQUFDO1lBQ2YsQ0FBQyxDQUFDO2lCQUNELElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFDdkQsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNJLFlBQVksQ0FBQyxPQUluQjtRQUNDLE9BQU8sUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDbEMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRTtnQkFDMUIsT0FBTyxFQUFFLENBQUM7YUFDWDtZQUVELFlBQVk7WUFDWixJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxFQUFFO2dCQUN4QyxJQUFJLENBQUMsWUFBWSxDQUFDLGFBQWEsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7YUFDL0M7aUJBQU07Z0JBQ0wsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsY0FBYyxFQUFFO29CQUNqQyxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQ25CLGVBQWUsRUFDZix3Q0FBd0MsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUN2RCxDQUFDO2lCQUNIO2dCQUVELFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxhQUFhLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2FBQzFEO1lBRUQsT0FBTyxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUscUJBQXFCLEVBQUUsUUFBUSxDQUFDLEVBQUU7Z0JBQ25FLE1BQU0sWUFBWSxHQUdkLEtBQUssQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQ3pCLFlBQVksQ0FBQyxHQUFHLEdBQUcsUUFBUSxDQUFDO2dCQUM1QixPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQ2pELENBQUMsQ0FBQztpQkFDQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDO2lCQUMzQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQ1osSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUU7b0JBQzFCLEtBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztpQkFDdkU7Z0JBQ0QsT0FBTyxLQUFLLENBQUM7WUFDZixDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7OztPQWNHO0lBQ0ksZ0JBQWdCLENBQ3JCLE9BQWlCLEVBQ2pCLE9BVUM7UUFFRCxPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUU7YUFDdEIsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNULHdGQUF3RjtZQUN4RixJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsRUFBRSxPQUFPLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFFekMsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsRUFBRTtnQkFDMUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxnQkFBZ0IsRUFBRSxPQUFPLENBQUMsY0FBYyxDQUFDLENBQUM7YUFDN0Q7WUFFRCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxFQUFFO2dCQUMxQyxLQUFLLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsRUFBRSxPQUFPLENBQUMsY0FBYyxFQUFFLENBQUMsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDdkY7aUJBQU07Z0JBQ0wsMEVBQTBFO2dCQUMxRSxrRUFBa0U7Z0JBQ2xFLE9BQU8sQ0FBQyxjQUFjLEdBQUcsT0FBTyxDQUFDLGtCQUFrQixDQUFDO2FBQ3JEO1lBRUQsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsRUFBRTtnQkFDckMsS0FBSyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsV0FBVyxFQUFFLE9BQU8sQ0FBQyxTQUFTLEVBQUUsQ0FBQyxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQzthQUM3RTtpQkFBTTtnQkFDTCxPQUFPLENBQUMsU0FBUyxHQUFHLE9BQU8sQ0FBQyxhQUFhLENBQUM7YUFDM0M7WUFFRCxJQUNFLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLENBQUM7Z0JBQzdFLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsRUFDbkU7Z0JBQ0Esb0JBQW9CO2dCQUNwQixPQUFPLEVBQUUsQ0FBQzthQUNYO1lBRUQsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDakMsS0FBSyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxFQUFFLDRCQUE0QixDQUFDLENBQUM7YUFDOUU7aUJBQU07Z0JBQ0wsdURBQXVEO2dCQUN2RCxPQUFPLENBQUMsS0FBSyxHQUFHLDRCQUE0QixDQUFDO2FBQzlDO1lBRUQsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsRUFBRTtnQkFDcEMsT0FBTyxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7YUFDMUI7WUFDRCxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUUsT0FBTyxDQUFDLFNBQVMsRUFBRSxDQUFDLElBQUksRUFBRSxjQUFjLEVBQUUsZUFBZSxDQUFDLENBQUMsQ0FBQztZQUU1RixNQUFNLGFBQWEsR0FBRztnQkFDcEIsS0FBSyxFQUFFLE9BQU8sQ0FBQyxLQUFLO2dCQUNwQixTQUFTLEVBQUUsT0FBTyxDQUFDLFNBQW9EO2dCQUN2RSxjQUFjLEVBQUUsT0FBTyxDQUFDLGNBQWM7Z0JBQ3RDLFNBQVMsRUFBRSxPQUFPLENBQUMsU0FBUztnQkFDNUIsY0FBYyxFQUFFLE9BQU8sQ0FBQyxjQUFjO2FBQ3ZDLENBQUM7WUFFRixPQUFPLElBQUksQ0FBQyxNQUFNO2lCQUNmLGFBQWEsQ0FBQyxFQUFDLEdBQUcsRUFBRSxPQUFPLEVBQUMsQ0FBQztpQkFDN0IsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFLGFBQWEsQ0FBQyxDQUFDO2lCQUN6RSxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsYUFBYSxDQUFDLENBQUMsQ0FBQztRQUN2RSxDQUFDLENBQUM7YUFDRCxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDO0lBQ3ZELENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNJLGNBQWMsQ0FDbkIsT0FBaUIsRUFDakIsWUFBc0IsRUFDdEIsT0FHQztRQUVELElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxFQUFFO1lBQ2pELE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQztTQUM3QjtRQUVELElBQ0UsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUNuRSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDLEVBQzdFO1lBQ0Esc0JBQXNCO1lBQ3RCLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQztTQUM3QjtRQUVELE9BQU8sUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDbEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFDdEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxjQUFjLEVBQUUsWUFBWSxDQUFDLENBQUM7WUFFaEQsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxPQUFPLEVBQUUsWUFBWSxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztRQUM1RixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSSxhQUFhLENBQ2xCLE1BQWMsRUFDZCxPQUVDO1FBRUQsT0FBTyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNsQyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxNQUFNLENBQUMsQ0FBQztZQUNuQyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsQ0FBQztRQUNyRCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ksa0JBQWtCLENBQUMsT0FBaUI7UUFDekMsT0FBTyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNsQyxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsRUFBRSxPQUFPLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDekMsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ2xELENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLFdBQVcsQ0FBQyxPQUFpQjtRQUNsQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDdEIsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLElBQUksR0FBRyxFQUFFLENBQUMsQ0FBQztTQUNwQztRQUVELE1BQU0sa0JBQWtCLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyw2QkFBNkIsQ0FBVyxDQUFDO1FBRS9FLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE9BQU8sSUFBSSxDQUFDLE1BQU07YUFDZixZQUFZLENBQUMsT0FBTyxFQUFFLGtCQUFrQixDQUFDO2FBQ3pDLElBQUksQ0FBQyxDQUFDLGFBQW1DLEVBQUUsRUFBRTtZQUM1QyxLQUFLLE1BQU0sQ0FBQyxNQUFNLEVBQUUsV0FBVyxDQUFDLElBQUksYUFBYSxDQUFDLE9BQU8sRUFBRSxFQUFFO2dCQUMzRCw2RUFBNkU7Z0JBQzdFLElBQUksV0FBVyxFQUFFO29CQUNmLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7aUJBQ25DO2FBQ0Y7WUFFRCxPQUFPLGFBQWEsQ0FBQztRQUN2QixDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7T0FjRztJQUNJLGFBQWEsQ0FDbEIsT0FBaUIsRUFDakIsT0FJQztRQUVELElBQ0UsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUMzRSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxFQUNyRjtZQUNBLHVFQUF1RTtZQUN2RSxNQUFNLFVBQVUsR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsSUFBSSxHQUFHLEVBQUUsQ0FBQyxDQUFDO1lBQ3hFLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztTQUNyQztRQUVELE9BQU8sUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDbEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLEVBQUUsT0FBTyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQ3pDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ3RELENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVELGtDQUFrQztJQUVsQzs7T0FFRztJQUNJLEtBQUssQ0FBQyxVQUFVLENBQUMsT0FBeUI7UUFDL0MsZ0NBQWdDO1FBQ2hDLEtBQUssQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLFlBQVksRUFBRSxPQUFPLENBQUMsVUFBVSxFQUFFLENBQUMsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLGlCQUFpQixDQUFDLENBQUM7UUFFOUYsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBRUQ7OztPQUdHO0lBQ0ksS0FBSyxDQUFDLFVBQVUsQ0FBQyxNQU12QjtRQUNDLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUV0Qyw4QkFBOEI7UUFDOUIsSUFDRSxJQUFJLENBQUMsUUFBUSxDQUFDLHVCQUF1QjtZQUNyQyxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxNQUFNLENBQUMsaUJBQWlCLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxFQUMxRTtZQUNBLE1BQU0sSUFBSSxxQ0FBaUIsQ0FBQywwQkFBMEIsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDdEU7UUFFRCxNQUFNLE9BQU8sR0FBRyxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRXRELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUMxQixNQUFNLElBQUksNkJBQWEsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1NBQzVDO1FBRUQsT0FBTyxPQUFPLENBQUM7SUFDakIsQ0FBQztJQUVEOztPQUVHO0lBQ0ksS0FBSyxDQUFDLFVBQVUsQ0FBQyxPQUF5QjtRQUMvQyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDM0MsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUUsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRTNDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUVEOzs7T0FHRztJQUNJLEtBQUssQ0FBQyxVQUFVLENBQUMsTUFJdkI7UUFDQyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7UUFFdEMsTUFBTSxPQUFPLEdBQUcsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUV0RCxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDMUIsTUFBTSxJQUFJLDZCQUFhLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQztTQUM1QztRQUVELE9BQU8sT0FBTyxDQUFDO0lBQ2pCLENBQUM7SUFFRCxrQ0FBa0M7SUFFbEM7Ozs7T0FJRztJQUNJLFVBQVUsQ0FBQyxNQUFjO1FBQzlCLE9BQU8sUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDbEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFFbkMsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUN6QyxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNJLGFBQWEsQ0FBQyxPQUtwQjtRQUNDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxVQUFVLENBQUMsTUFBYztRQUM5QixPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ2xDLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBRW5DLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDekMsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSSxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQWE7UUFDL0IsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsU0FBUyxFQUFFO1lBQzVCLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO1NBQzFCO1FBRUQsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNqQyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3BDLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0ksb0JBQW9CLENBQUMsY0FBK0I7UUFDekQsTUFBTSxZQUFZLEdBQTJCLEVBQUUsQ0FBQztRQUNoRCxNQUFNLFdBQVcsR0FBRyxHQUFHLENBQUM7UUFFeEIsMkRBQTJEO1FBQzNELEtBQUssTUFBTSxRQUFRLElBQUksY0FBYyxFQUFFO1lBQ3JDLElBQUksVUFBVSxDQUFDO1lBQ2YsUUFBUSxRQUFRLENBQUMsSUFBSSxFQUFFO2dCQUNyQixLQUFLLHVCQUFpQixDQUFDLElBQUk7b0JBQ3pCLFVBQVUsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLGVBQWUsRUFBRSxDQUFDO29CQUMzQyxNQUFNO2dCQUNSLEtBQUssdUJBQWlCLENBQUMsUUFBUTtvQkFDN0IsVUFBVSxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxlQUFlLEVBQUUsQ0FBQyxDQUFDO29CQUM3QyxNQUFNO2dCQUNSLEtBQUssdUJBQWlCLENBQUMsT0FBTztvQkFDNUIsVUFBVSxHQUFHLEtBQUssQ0FBQztvQkFDbkIsTUFBTTtnQkFDUixLQUFLLHVCQUFpQixDQUFDLE1BQU07b0JBQzNCLFVBQVUsR0FBRyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEdBQUcsSUFBSSxRQUFRLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUN2RixNQUFNO2dCQUNSLEtBQUssdUJBQWlCLENBQUMsSUFBSTtvQkFDekIsVUFBVSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO29CQUN2RCxNQUFNO2dCQUNSLEtBQUssdUJBQWlCLENBQUMsSUFBSSxDQUFDO2dCQUM1QixLQUFLLHVCQUFpQixDQUFDLFNBQVM7b0JBQzlCLE1BQU0sSUFBSSxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTzt3QkFDN0IsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLE9BQU8sSUFBSSxRQUFRLENBQUMsT0FBTyxDQUFDLEdBQUcsSUFBSSxRQUFRLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO3dCQUMzRSxZQUFZLENBQVcsQ0FBQztvQkFDMUIsVUFBVSxHQUFHLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO29CQUMxQyxNQUFNO2dCQUNSO29CQUNFLFVBQVUsR0FBRyxXQUFXLENBQUM7YUFDNUI7WUFDRCxZQUFZLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxHQUFHLFVBQVUsQ0FBQztTQUN6QztRQUVELE9BQU8sWUFBWSxDQUFDO0lBQ3RCLENBQUM7SUFFRDs7T0FFRztJQUNJLE9BQU8sQ0FBQyxLQUFhO1FBQzFCLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDckMsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxVQUFVLENBQUMsS0FBYTtRQUM3QixPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFzQk0sUUFBUSxDQUNiLE9BQXdCLEVBQ3hCLFNBQVMsR0FBRyxJQUFJO1FBRWhCLE9BQU8sUUFBUSxDQUFDLE9BQU8sRUFBRTthQUN0QixJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1QsT0FBTyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUM7WUFFOUIsSUFBSSxPQUFPLENBQUMsT0FBTyxLQUFLLFNBQVMsSUFBSSxPQUFPLENBQUMsT0FBTyxLQUFLLElBQUksRUFBRTtnQkFDN0QsT0FBTyxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQXNCLENBQUM7YUFDbEU7WUFFRCxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsRUFBRSxPQUFPLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQzdELElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ25DLEtBQUssQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLGlCQUFpQixFQUFFLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUNoRixLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxtQkFBbUIsRUFBRSxTQUFTLENBQUMsQ0FBQztZQUNwRCxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxlQUFlLEVBQUUsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQztZQUV2RCxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDO2dCQUMzQixPQUFPLEVBQUUsT0FBTyxDQUFDLE9BQU87Z0JBQ3hCLE9BQU8sRUFBRSxPQUFPLENBQUMsT0FBTztnQkFDeEIsU0FBUyxFQUFFLFNBQVM7Z0JBQ3BCLEtBQUssRUFBRSxPQUFPLENBQUMsS0FBSzthQUNyQixDQUFDLENBQUM7UUFDTCxDQUFDLENBQUM7YUFDRCxJQUFJLENBQUMsY0FBYyxDQUFDLEVBQUU7WUFDckIsSUFBSSxDQUFDLFNBQVMsRUFBRTtnQkFDZCx5REFBeUQ7Z0JBQ3pELE9BQU8sY0FBYyxDQUFDO2FBQ3ZCO1lBRUQsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDO1lBRWxCLElBQUksS0FBSyxHQUEwQixFQUFFLENBQUM7WUFDdEMsT0FBTyxLQUFLLENBQUMsUUFBUSxDQUNuQixjQUFjLEVBQ2QsT0FBTyxDQUNMLFVBQVMsS0FBMEI7Z0JBQ2pDLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ2xCLElBQUksS0FBSyxDQUFDLE1BQU0sSUFBSSwwQkFBMEIsRUFBRTtvQkFDOUMsc0dBQXNHO29CQUN0RyxhQUFhO29CQUNiLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztvQkFDYixJQUFJO3lCQUNELGdDQUFnQyxDQUFDLEtBQUssRUFBRSxPQUFPLENBQUM7eUJBQ2hELElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFO3dCQUM1QixxQkFBcUIsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLEVBQUU7NEJBQzdDLGFBQWE7NEJBQ2IsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsY0FBYyxDQUFDLENBQUM7d0JBQ3BDLENBQUMsQ0FBQyxDQUFDO3dCQUNILG1EQUFtRDt3QkFDbkQsMkRBQTJEO3dCQUMzRCxLQUFLLEdBQUcsRUFBRSxDQUFDO3dCQUNYLGFBQWE7d0JBQ2IsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO29CQUNoQixDQUFDLENBQUM7eUJBQ0QsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFO3dCQUNiLGFBQWE7d0JBQ2IsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7b0JBQzVCLENBQUMsQ0FBQyxDQUFDO2lCQUNOO1lBQ0gsQ0FBQyxFQUNEO2dCQUNFLElBQUk7cUJBQ0QsZ0NBQWdDLENBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQztxQkFDaEQsSUFBSSxDQUFDLHFCQUFxQixDQUFDLEVBQUU7b0JBQzVCLHFCQUFxQixDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRTt3QkFDcEMsYUFBYTt3QkFDYixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQztvQkFDM0IsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsYUFBYTtvQkFDYixJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNuQixDQUFDLENBQUM7cUJBQ0QsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFO29CQUNiLGFBQWE7b0JBQ2IsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7Z0JBQzVCLENBQUMsQ0FBQyxDQUFDO1lBQ1AsQ0FBQyxDQUNGLENBQ0YsQ0FBQztRQUNKLENBQUMsQ0FBeUQsQ0FBQztJQUMvRCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7Ozs7O09BY0c7SUFDSyxnQ0FBZ0MsQ0FDdEMsT0FBOEIsRUFDOUIsT0FLQztRQUVELHVFQUF1RTtRQUN2RSxNQUFNLGFBQWEsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBQ2hDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3ZDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDaEQsTUFBTSxJQUFJLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDakMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQ2xDO1NBQ0Y7UUFFRCwyREFBMkQ7UUFDM0QsTUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQztRQUNqRCxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDbEQsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQ3ZDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtvQkFDaEQsTUFBTSxJQUFJLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDakMsdUVBQXVFO29CQUN2RSxJQUFJLENBQUMsVUFBVSxHQUFHLGFBQWEsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLFVBQVUsQ0FBQztpQkFDekQ7YUFDRjtZQUVELE9BQU8sT0FBTyxDQUFDO1FBQ2pCLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGO0FBdmtDRCw0QkF1a0NDIn0=