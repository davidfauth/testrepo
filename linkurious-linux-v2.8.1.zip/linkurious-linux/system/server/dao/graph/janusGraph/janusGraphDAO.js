/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-09-01.
 */
'use strict';
const { GraphDAO } = require('../graphDAO');
const JanusGraphConnector = require('../../connector/janusGraphConnector');
const JanusGraphDriver = require('./janusGraphDriver');
class JanusGraphDAO extends GraphDAO {
    /**
     * @param {object}  options
     * @param {string}  options.url                 JanusGraph url
     * @param {string}  [options.configurationPath] Path to the Gremlin configuration file
     * @param {object}  [options.configuration]     JanusGraph graph configuration
     * @param {string}  [options.user]              JanusGraph user
     * @param {string}  [options.password]          JanusGraph password
     * @param {boolean} [options.allowSelfSigned]   Whether to allow self-signed certificates
     */
    constructor(options) {
        super('janusGraph', ['url'], [
            'url',
            'graphAlias',
            'traversalSourceAlias',
            'configurationPath',
            'configuration',
            'user',
            'password',
            'allowSelfSigned',
            'disableIndexExistCheck',
            'sessionPool',
            'maxStale' // experimental
        ], options, {
            immutableNodeCategories: true,
            maxNodeCategories: 1,
            canCount: false,
            alerts: true,
            alternativeIds: true,
            dialects: ['gremlin'],
            canDryRun: false,
            supportNativeDate: false
        }, JanusGraphConnector, [
            { version: '0.2.0', driver: '[latest]' },
            { version: '0.1.1', driver: JanusGraphDriver }
        ]);
    }
}
module.exports = JanusGraphDAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiamFudXNHcmFwaERBTy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NlcnZlci9kYW8vZ3JhcGgvamFudXNHcmFwaC9qYW51c0dyYXBoREFPLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBQ2IsTUFBTSxFQUFFLFFBQVEsRUFBRSxHQUFHLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUM1QyxNQUFNLG1CQUFtQixHQUFHLE9BQU8sQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDO0FBQzNFLE1BQU0sZ0JBQWdCLEdBQUcsT0FBTyxDQUFDLG9CQUFvQixDQUFDLENBQUM7QUFFdkQsTUFBTSxhQUFjLFNBQVEsUUFBUTtJQUVsQzs7Ozs7Ozs7T0FRRztJQUNILFlBQVksT0FBTztRQUNqQixLQUFLLENBQUMsWUFBWSxFQUNoQixDQUFDLEtBQUssQ0FBQyxFQUNQO1lBQ0UsS0FBSztZQUNMLFlBQVk7WUFDWixzQkFBc0I7WUFDdEIsbUJBQW1CO1lBQ25CLGVBQWU7WUFDZixNQUFNO1lBQ04sVUFBVTtZQUNWLGlCQUFpQjtZQUNqQix3QkFBd0I7WUFDeEIsYUFBYTtZQUNiLFVBQVUsQ0FBQyxlQUFlO1NBQzNCLEVBQ0QsT0FBTyxFQUNQO1lBQ0UsdUJBQXVCLEVBQUUsSUFBSTtZQUM3QixpQkFBaUIsRUFBRSxDQUFDO1lBQ3BCLFFBQVEsRUFBRSxLQUFLO1lBQ2YsTUFBTSxFQUFFLElBQUk7WUFDWixjQUFjLEVBQUUsSUFBSTtZQUNwQixRQUFRLEVBQUUsQ0FBQyxTQUFTLENBQUM7WUFDckIsU0FBUyxFQUFFLEtBQUs7WUFDaEIsaUJBQWlCLEVBQUUsS0FBSztTQUN6QixFQUNELG1CQUFtQixFQUNuQjtZQUNFLEVBQUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFDO1lBQ3RDLEVBQUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsZ0JBQWdCLEVBQUM7U0FDN0MsQ0FDRixDQUFDO0lBQ0osQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxhQUFhLENBQUMifQ==