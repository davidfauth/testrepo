/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2018-02-08.
 */
'use strict';
const { GraphDAO } = require('../graphDAO');
const JanusGraphForComposeConnector = require('../../connector/janusGraphForComposeConnector');
const JanusGraphForComposeDriver = require('./janusGraphForComposeDriver');
class JanusGraphForComposeDAO extends GraphDAO {
    /**
     * @param {object}  options
     * @param {string}  options.url               JanusGraph url
     * @param {string}  options.graphName         The name of the JanusGraph graph to load
     * @param {string}  [options.user]            JanusGraph user
     * @param {string}  [options.password]        JanusGraph password
     * @param {boolean} [options.create]          Whether to create the graph if it does not exist
     * @param {boolean} [options.allowSelfSigned] Whether to allow self-signed certificates
     */
    constructor(options) {
        super('janusGraphForCompose', ['url', 'graphName'], [
            'url',
            'graphName',
            'user',
            'password',
            'create',
            'allowSelfSigned',
            'disableIndexExistCheck',
            'sessionPool',
            'maxStale' // experimental
        ], options, {
            immutableNodeCategories: true,
            maxNodeCategories: 1,
            canCount: false,
            alerts: true,
            alternativeIds: true,
            dialects: ['gremlin'],
            canDryRun: false,
            supportNativeDate: false
        }, JanusGraphForComposeConnector, [
            { version: '0.1.1', driver: '[latest]' },
            { version: '0.1.1', driver: JanusGraphForComposeDriver }
        ]);
    }
}
module.exports = JanusGraphForComposeDAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiamFudXNHcmFwaEZvckNvbXBvc2VEQU8uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2dyYXBoL2phbnVzR3JhcGhGb3JDb21wb3NlL2phbnVzR3JhcGhGb3JDb21wb3NlREFPLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBQ2IsTUFBTSxFQUFFLFFBQVEsRUFBRSxHQUFHLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUM1QyxNQUFNLDZCQUE2QixHQUFHLE9BQU8sQ0FBQywrQ0FBK0MsQ0FBQyxDQUFDO0FBQy9GLE1BQU0sMEJBQTBCLEdBQUcsT0FBTyxDQUFDLDhCQUE4QixDQUFDLENBQUM7QUFFM0UsTUFBTSx1QkFBd0IsU0FBUSxRQUFRO0lBRTVDOzs7Ozs7OztPQVFHO0lBQ0gsWUFBWSxPQUFPO1FBQ2pCLEtBQUssQ0FBQyxzQkFBc0IsRUFDMUIsQ0FBQyxLQUFLLEVBQUUsV0FBVyxDQUFDLEVBQ3BCO1lBQ0UsS0FBSztZQUNMLFdBQVc7WUFDWCxNQUFNO1lBQ04sVUFBVTtZQUNWLFFBQVE7WUFDUixpQkFBaUI7WUFDakIsd0JBQXdCO1lBQ3hCLGFBQWE7WUFDYixVQUFVLENBQUMsZUFBZTtTQUMzQixFQUNELE9BQU8sRUFDUDtZQUNFLHVCQUF1QixFQUFFLElBQUk7WUFDN0IsaUJBQWlCLEVBQUUsQ0FBQztZQUNwQixRQUFRLEVBQUUsS0FBSztZQUNmLE1BQU0sRUFBRSxJQUFJO1lBQ1osY0FBYyxFQUFFLElBQUk7WUFDcEIsUUFBUSxFQUFFLENBQUMsU0FBUyxDQUFDO1lBQ3JCLFNBQVMsRUFBRSxLQUFLO1lBQ2hCLGlCQUFpQixFQUFFLEtBQUs7U0FDekIsRUFDRCw2QkFBNkIsRUFDN0I7WUFDRSxFQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLFVBQVUsRUFBQztZQUN0QyxFQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLDBCQUEwQixFQUFDO1NBQ3ZELENBQ0YsQ0FBQztJQUNKLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsdUJBQXVCLENBQUMifQ==