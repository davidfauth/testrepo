/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2018-02-19.
 */
'use strict';
const Neo4jDriver = require('./neo4jDriver');
const CypherUtils = require('../../utils/cypherUtils');
/**
 * From Neo4j 2.2.0 we can use the following statements:
 * - EXPLAIN
 * - PROFILE
 *
 * We need EXPLAIN to perform a dry run.
 */
class Neo4j220Driver extends Neo4jDriver {
    /**
     * Called at the end of the connect phase for additional initializations.
     *
     * @returns {Bluebird<void>}
     */
    $onAfterConnect() {
        this.graphFeatures.canDryRun = true;
        return super.$onAfterConnect();
    }
    /**
     * Check that the given graph query is syntactically correct.
     *
     * @param {string} query
     * @returns {Bluebird<void>}
     */
    $dryRun(query) {
        const newQuery = CypherUtils.enforceExplainStatement(query);
        return this.connector.$doCypherQuery(newQuery).catch(error => {
            if (error.data && error.data.offset) {
                // Enforce explain adds 8 characters to the original query
                error.data.offset -= 8;
            }
            throw error;
        });
    }
}
module.exports = Neo4j220Driver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmVvNGoyMjBEcml2ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2dyYXBoL25lbzRqL25lbzRqMjIwRHJpdmVyLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBQ2IsTUFBTSxXQUFXLEdBQUcsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDO0FBQzdDLE1BQU0sV0FBVyxHQUFHLE9BQU8sQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO0FBRXZEOzs7Ozs7R0FNRztBQUNILE1BQU0sY0FBZSxTQUFRLFdBQVc7SUFFdEM7Ozs7T0FJRztJQUNILGVBQWU7UUFDYixJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7UUFDcEMsT0FBTyxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDakMsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsT0FBTyxDQUFDLEtBQUs7UUFDWCxNQUFNLFFBQVEsR0FBRyxXQUFXLENBQUMsdUJBQXVCLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDNUQsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDM0QsSUFBSSxLQUFLLENBQUMsSUFBSSxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO2dCQUNuQywwREFBMEQ7Z0JBQzFELEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQzthQUN4QjtZQUNELE1BQU0sS0FBSyxDQUFDO1FBQ2QsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLGNBQWMsQ0FBQyJ9