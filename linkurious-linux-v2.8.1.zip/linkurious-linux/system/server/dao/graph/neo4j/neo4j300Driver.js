/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-10-09.
 */
'use strict';
const Promise = require('bluebird');
const _ = require('lodash');
const Neo4j220Driver = require('./neo4j220Driver');
/**
 * From Neo4j 3.0.0 we can use the following procedures instead of an HTTP request:
 * - db.relationshipTypes
 * - db.labels
 * - db.propertyKeys
 */
class Neo4j300Driver extends Neo4j220Driver {
    /**
     * List all edgeTypes, nodeCategories, edgeProperties, nodeProperties
     * that exist in the graph database.
     *
     * @returns {Bluebird<SimpleGraphSchema>}
     */
    $getSimpleSchema() {
        return Promise.props({
            edgeTypes: this.$getEdgeTypes(),
            nodeCategories: this.connector.$doCypherQuery('CALL db.labels()'),
            nodeProperties: this.connector.$doCypherQuery('CALL db.propertyKeys()')
        }).then(response => {
            return {
                edgeTypes: response.edgeTypes,
                nodeCategories: _.map(response.nodeCategories.results, r => r.rows[0]),
                nodeProperties: _.map(response.nodeProperties.results, r => r.rows[0]),
                edgeProperties: _.map(response.nodeProperties.results, r => r.rows[0]) // same as nodeProperties
            };
        });
    }
    /**
     * List all edgeTypes that exist in the graph database.
     *
     * @returns {Bluebird<string[]>}
     */
    $getEdgeTypes() {
        return this.connector.$doCypherQuery('CALL db.relationshipTypes()').then(response => {
            return _.map(response.results, r => r.rows[0]);
        });
    }
}
module.exports = Neo4j300Driver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmVvNGozMDBEcml2ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2dyYXBoL25lbzRqL25lbzRqMzAwRHJpdmVyLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBQ2IsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3BDLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM1QixNQUFNLGNBQWMsR0FBRyxPQUFPLENBQUMsa0JBQWtCLENBQUMsQ0FBQztBQUVuRDs7Ozs7R0FLRztBQUNILE1BQU0sY0FBZSxTQUFRLGNBQWM7SUFFekM7Ozs7O09BS0c7SUFDSCxnQkFBZ0I7UUFDZCxPQUFPLE9BQU8sQ0FBQyxLQUFLLENBQUM7WUFDbkIsU0FBUyxFQUFFLElBQUksQ0FBQyxhQUFhLEVBQUU7WUFDL0IsY0FBYyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLGtCQUFrQixDQUFDO1lBQ2pFLGNBQWMsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyx3QkFBd0IsQ0FBQztTQUN4RSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ2pCLE9BQU87Z0JBQ0wsU0FBUyxFQUFFLFFBQVEsQ0FBQyxTQUFTO2dCQUM3QixjQUFjLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3RFLGNBQWMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDdEUsY0FBYyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMseUJBQXlCO2FBQ2pHLENBQUM7UUFDSixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsYUFBYTtRQUNYLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsNkJBQTZCLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDbEYsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDakQsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLGNBQWMsQ0FBQyJ9