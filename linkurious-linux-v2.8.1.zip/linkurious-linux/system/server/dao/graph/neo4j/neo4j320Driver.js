/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-01-02.
 */
'use strict';
const _ = require('lodash');
const LKE = require('../../../services');
const Config = LKE.getConfig();
const Utils = LKE.getUtils();
const Neo4j300Driver = require('./neo4j300Driver');
const CypherUtils = require('../../utils/cypherUtils');
class Neo4j320Driver extends Neo4j300Driver {
    /**
     * Get the edges between two set of nodes.
     *
     * @param {string[]} nodeIds         IDs of the first set of nodes
     * @param {string[]} otherNodeIds    IDs of the second set of nodes
     * @param options
     * @param [options.edgeTypes]      Exclusive list of edge types to restrict the result
     * @param [options.nodeCategories] Exclusive list of node categories (of nodes in `otherNodeIds`) to restrict the result
     * @param isSuperNodeCache         List of known supernodes
     * @returns {Bluebird<LkEdge[]>}
     */
    $getMutualEdges(nodeIds, otherNodeIds, options, isSuperNodeCache) {
        // TODO #1644 Avoid to fetch mutual edges between supernodes at the dataservice layer instead of the driver
        const edgesBetweenSupernodes = Config.get('advanced.edgesBetweenSupernodes');
        if (edgesBetweenSupernodes) {
            return super.$getMutualEdges(nodeIds, otherNodeIds, options);
        }
        const sNodesIds = CypherUtils.encodeIDArray(nodeIds);
        const sOtherNodeIds = CypherUtils.encodeIDArray(otherNodeIds);
        let sEdgeTypeFilter = '';
        if (Utils.hasValue(options.edgeTypes)) {
            sEdgeTypeFilter = options.edgeTypes.map(type => ':' + CypherUtils.encodeName(type)).join('|');
        }
        let sReadableCategories1 = 'AND size(labels(a)) > 0 ';
        if (Utils.hasValue(options.nodeCategories)) {
            const readableCategories = options.nodeCategories
                .map(category => 'a:' + CypherUtils.encodeName(category));
            sReadableCategories1 = `AND (${readableCategories.join(' OR ')}) `;
        }
        let sReadableCategories2 = 'AND size(labels(b)) > 0 ';
        if (Utils.hasValue(options.nodeCategories)) {
            const readableCategories = options.nodeCategories
                .map(category => 'b:' + CypherUtils.encodeName(category));
            sReadableCategories2 = `AND (${readableCategories.join(' OR ')}) `;
        }
        // The reason that variables are called 'a', 'b', 'e' is not casual
        // It's to hint to the planner to actually scan the list of nodes in `nodeIds` instead
        // of nodes in `otherNodeIds`. See #1462
        return Promise.resolve().then(() => {
            const nodeIdsWithoutSuperNode = _.filter(nodeIds, n => !isSuperNodeCache.has(n));
            const otherNodeIdsWithoutSuperNode = _.filter(otherNodeIds, n => !isSuperNodeCache.has(n));
            const sNodesIdsWithoutSuperNode = CypherUtils.encodeIDArray(nodeIdsWithoutSuperNode);
            const sOtherNodeIdsWithoutSuperNode = CypherUtils.encodeIDArray(otherNodeIdsWithoutSuperNode);
            const edgeQuery1 = `CYPHER 3.1 MATCH (b)-[e${sEdgeTypeFilter}]-(a) ` +
                `WHERE id(b) IN ${sNodesIdsWithoutSuperNode} AND id(a) IN ${sOtherNodeIds} ` +
                sReadableCategories1 +
                'RETURN DISTINCT e';
            const edgeQuery2 = `CYPHER 3.1 MATCH (b)-[e${sEdgeTypeFilter}]-(a) ` +
                `WHERE id(b) IN ${sOtherNodeIdsWithoutSuperNode} AND id(a) IN ${sNodesIds}` +
                sReadableCategories2 +
                'RETURN DISTINCT e';
            return this.connector.$doCypherQuery(edgeQuery1).then(response1 => {
                const edges1 = _.map(response1.results, record => record.edges[0]);
                return this.connector.$doCypherQuery(edgeQuery2).then(response2 => {
                    const edges2 = _.map(response2.results, record => record.edges[0]);
                    return _.uniqBy(edges1.concat(edges2), 'id');
                });
            });
        });
    }
}
module.exports = Neo4j320Driver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmVvNGozMjBEcml2ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2dyYXBoL25lbzRqL25lbzRqMzIwRHJpdmVyLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBQ2IsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVCLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0FBQ3pDLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxjQUFjLEdBQUcsT0FBTyxDQUFDLGtCQUFrQixDQUFDLENBQUM7QUFDbkQsTUFBTSxXQUFXLEdBQUcsT0FBTyxDQUFDLHlCQUF5QixDQUFDLENBQUM7QUFFdkQsTUFBTSxjQUFlLFNBQVEsY0FBYztJQUN6Qzs7Ozs7Ozs7OztPQVVHO0lBQ0gsZUFBZSxDQUFDLE9BQU8sRUFBRSxZQUFZLEVBQUUsT0FBTyxFQUFFLGdCQUFnQjtRQUM5RCwyR0FBMkc7UUFDM0csTUFBTSxzQkFBc0IsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLGlDQUFpQyxDQUFDLENBQUM7UUFDN0UsSUFBSSxzQkFBc0IsRUFBRTtZQUMxQixPQUFPLEtBQUssQ0FBQyxlQUFlLENBQUMsT0FBTyxFQUFFLFlBQVksRUFBRSxPQUFPLENBQUMsQ0FBQztTQUM5RDtRQUVELE1BQU0sU0FBUyxHQUFHLFdBQVcsQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDckQsTUFBTSxhQUFhLEdBQUcsV0FBVyxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUM5RCxJQUFJLGVBQWUsR0FBRyxFQUFFLENBQUM7UUFDekIsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsRUFBRTtZQUNyQyxlQUFlLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQ3JDLElBQUksQ0FBQyxFQUFFLENBQUMsR0FBRyxHQUFHLFdBQVcsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQzNDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ2I7UUFFRCxJQUFJLG9CQUFvQixHQUFHLDBCQUEwQixDQUFDO1FBQ3RELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLEVBQUU7WUFDMUMsTUFBTSxrQkFBa0IsR0FBRyxPQUFPLENBQUMsY0FBYztpQkFDOUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxHQUFHLFdBQVcsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztZQUU1RCxvQkFBb0IsR0FBRyxRQUFRLGtCQUFrQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO1NBQ3BFO1FBRUQsSUFBSSxvQkFBb0IsR0FBRywwQkFBMEIsQ0FBQztRQUN0RCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxFQUFFO1lBQzFDLE1BQU0sa0JBQWtCLEdBQUcsT0FBTyxDQUFDLGNBQWM7aUJBQzlDLEdBQUcsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksR0FBRyxXQUFXLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7WUFFNUQsb0JBQW9CLEdBQUcsUUFBUSxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztTQUNwRTtRQUVELG1FQUFtRTtRQUNuRSxzRkFBc0Y7UUFDdEYsd0NBQXdDO1FBRXhDLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDakMsTUFBTSx1QkFBdUIsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDakYsTUFBTSw0QkFBNEIsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDM0YsTUFBTSx5QkFBeUIsR0FBRyxXQUFXLENBQUMsYUFBYSxDQUFDLHVCQUF1QixDQUFDLENBQUM7WUFDckYsTUFBTSw2QkFBNkIsR0FBRyxXQUFXLENBQUMsYUFBYSxDQUFDLDRCQUE0QixDQUFDLENBQUM7WUFFOUYsTUFBTSxVQUFVLEdBQUcsMEJBQTBCLGVBQWUsUUFBUTtnQkFDbEUsa0JBQWtCLHlCQUF5QixpQkFBaUIsYUFBYSxHQUFHO2dCQUM1RSxvQkFBb0I7Z0JBQ3BCLG1CQUFtQixDQUFDO1lBRXRCLE1BQU0sVUFBVSxHQUFHLDBCQUEwQixlQUFlLFFBQVE7Z0JBQ2xFLGtCQUFrQiw2QkFBNkIsaUJBQWlCLFNBQVMsRUFBRTtnQkFDM0Usb0JBQW9CO2dCQUNwQixtQkFBbUIsQ0FBQztZQUV0QixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRTtnQkFDaEUsTUFBTSxNQUFNLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUVuRSxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRTtvQkFDaEUsTUFBTSxNQUFNLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUVuRSxPQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDL0MsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxjQUFjLENBQUMifQ==