"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-07-16.
 */
Object.defineProperty(exports, "__esModule", { value: true });
// TS2019-DONE
const Neo4j320Driver = require("./neo4j320Driver");
// @ts-ignore TODO TS2019 remove once all Neo4j Driver is refactored
class Neo4j340Driver extends Neo4j320Driver {
    /**
     * Called at the end of the connect phase for additional initializations.
     */
    async $onAfterConnect() {
        this.graphFeatures.supportNativeDate = true;
        return super.$onAfterConnect();
    }
}
exports.Neo4j340Driver = Neo4j340Driver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmVvNGozNDBEcml2ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2dyYXBoL25lbzRqL25lbzRqMzQwRHJpdmVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRzs7QUFFSCxjQUFjO0FBRWQsbURBQW9EO0FBRXBELG9FQUFvRTtBQUNwRSxNQUFhLGNBQWUsU0FBUSxjQUFjO0lBQ2hEOztPQUVHO0lBQ0ksS0FBSyxDQUFDLGVBQWU7UUFDMUIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUM7UUFDNUMsT0FBTyxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDakMsQ0FBQztDQUNGO0FBUkQsd0NBUUMifQ==