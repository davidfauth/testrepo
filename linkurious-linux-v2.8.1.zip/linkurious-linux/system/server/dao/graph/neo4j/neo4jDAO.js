/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-10-09.
 */
'use strict';
const { GraphDAO } = require('../graphDAO');
const Neo4jHTTPConnector = require('../../connector/neo4jHTTPConnector');
const Neo4jBoltConnector = require('../../connector/neo4jBoltConnector');
const Neo4jDriver = require('./neo4jDriver');
const Neo4j220Driver = require('./neo4j220Driver');
const Neo4j300Driver = require('./neo4j300Driver');
const Neo4j320Driver = require('./neo4j320Driver');
const { Neo4j340Driver } = require('./neo4j340Driver');
class Neo4jDAO extends GraphDAO {
    /**
     * @param {object}  options
     * @param {string}  options.url               Neo4j Bolt/HTTP/HTTPS url
     * @param {string}  [options.user]            Neo4j user
     * @param {string}  [options.password]        Neo4j password
     * @param {string}  [options.writeURL]        Neo4j HTTP/HTTPS Core Server url (not used for Bolt)
     * @param {string}  [options.proxy]           HTTP proxy (not used for Bolt)
     * @param {boolean} [options.allowSelfSigned] Whether to allow self-signed certificates (not used for Bolt)
     */
    constructor(options) {
        const useBolt = options.url.toLowerCase().startsWith('bolt');
        super('neo4j', ['url'], ['url', 'user', 'password', 'writeURL', 'proxy', 'allowSelfSigned'], options, {
            immutableNodeCategories: false,
            maxNodeCategories: undefined,
            canCount: true,
            alerts: true,
            alternativeIds: true,
            dialects: ['cypher'],
            canDryRun: false,
            supportNativeDate: false // true from 3.4.0
        }, useBolt ? Neo4jBoltConnector : [Neo4jBoltConnector, Neo4jHTTPConnector], [
            { version: '3.5.7', driver: '[latest]' },
            { version: '3.4.0', driver: Neo4j340Driver },
            { version: '3.2.0', driver: Neo4j320Driver },
            { version: '3.0.0', driver: Neo4j300Driver },
            { version: '2.2.0', driver: Neo4j220Driver },
            { version: '2.1.5', driver: Neo4jDriver }
        ]);
    }
}
module.exports = Neo4jDAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmVvNGpEQU8uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2dyYXBoL25lbzRqL25lbzRqREFPLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBQ2IsTUFBTSxFQUFFLFFBQVEsRUFBRSxHQUFHLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUM1QyxNQUFNLGtCQUFrQixHQUFHLE9BQU8sQ0FBQyxvQ0FBb0MsQ0FBQyxDQUFDO0FBQ3pFLE1BQU0sa0JBQWtCLEdBQUcsT0FBTyxDQUFDLG9DQUFvQyxDQUFDLENBQUM7QUFDekUsTUFBTSxXQUFXLEdBQUcsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDO0FBQzdDLE1BQU0sY0FBYyxHQUFHLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0FBQ25ELE1BQU0sY0FBYyxHQUFHLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0FBQ25ELE1BQU0sY0FBYyxHQUFHLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0FBQ25ELE1BQU0sRUFBRSxjQUFjLEVBQUUsR0FBRyxPQUFPLENBQUMsa0JBQWtCLENBQUMsQ0FBQztBQUV2RCxNQUFNLFFBQVMsU0FBUSxRQUFRO0lBRTdCOzs7Ozs7OztPQVFHO0lBQ0gsWUFBWSxPQUFPO1FBQ2pCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRTdELEtBQUssQ0FBQyxPQUFPLEVBQ1gsQ0FBQyxLQUFLLENBQUMsRUFDUCxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFFLFVBQVUsRUFBRSxPQUFPLEVBQUUsaUJBQWlCLENBQUMsRUFDbkUsT0FBTyxFQUNQO1lBQ0UsdUJBQXVCLEVBQUUsS0FBSztZQUM5QixpQkFBaUIsRUFBRSxTQUFTO1lBQzVCLFFBQVEsRUFBRSxJQUFJO1lBQ2QsTUFBTSxFQUFFLElBQUk7WUFDWixjQUFjLEVBQUUsSUFBSTtZQUNwQixRQUFRLEVBQUUsQ0FBQyxRQUFRLENBQUM7WUFDcEIsU0FBUyxFQUFFLEtBQUs7WUFDaEIsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLGtCQUFrQjtTQUM1QyxFQUNELE9BQU8sQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLEVBQUUsa0JBQWtCLENBQUMsRUFDdkU7WUFDRSxFQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLFVBQVUsRUFBQztZQUN0QyxFQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLGNBQWMsRUFBQztZQUMxQyxFQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLGNBQWMsRUFBQztZQUMxQyxFQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLGNBQWMsRUFBQztZQUMxQyxFQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLGNBQWMsRUFBQztZQUMxQyxFQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLFdBQVcsRUFBQztTQUN4QyxDQUNGLENBQUM7SUFDSixDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLFFBQVEsQ0FBQyJ9