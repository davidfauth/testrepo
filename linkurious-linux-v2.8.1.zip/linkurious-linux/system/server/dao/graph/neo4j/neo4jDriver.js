"use strict";
const Bluebird = require("bluebird");
const _ = require("lodash");
const LKE = require("../../../services");
const Errors = LKE.getErrors();
const CypherDriver = require('../cypherDriver');
// @ts-ignore Neo4jConnector needs to be written in TS
class Neo4jDriver extends CypherDriver {
    /**
     * Check if the given edge ID is legal.
     *
     * @param key
     * @param id
     */
    $checkEdgeId(key, id) {
        // Negative values are accepted in order to tolerate virtual Edges
        if (!/^[-]?\d+$/.test(id)) {
            throw Errors.business('invalid_parameter', '"' + key + '" must be an integer.');
        }
    }
    /**
     * Check if the given node ID is legal.
     *
     * @param key
     * @param id
     */
    $checkNodeId(key, id) {
        // Negative values are accepted in order to tolerate virtual Nodes
        if (!/^[-]?\d+$/.test(id)) {
            throw Errors.business('invalid_parameter', '"' + key + '" must be an integer.');
        }
    }
    /**
     * Count the number of nodes.
     *
     * @param approx Allow an approximated answer
     */
    $getNodeCount(approx) {
        if (approx) {
            return this.connector.$queryJmx('org.neo4j', 'instance=kernel#0,name=Primitive count', 'NumberOfNodeIdsInUse');
        }
        return this.connector.$doCypherQuery('MATCH (n) RETURN count(n)').then(response => {
            return _.get(response, 'results.0.rows.0', 0);
        });
    }
    /**
     * Count the number of edges.
     *
     * @param approx Allow an approximated answer
     */
    $getEdgeCount(approx) {
        if (approx) {
            return this.connector.$queryJmx('org.neo4j', 'instance=kernel#0,name=Primitive count', 'NumberOfRelationshipIdsInUse');
        }
        return this.connector.$doCypherQuery('MATCH ()-->() RETURN COUNT(*)').then(response => {
            return _.get(response, 'results.0.rows.0', 0);
        });
    }
    /**
     * List all edgeTypes, nodeCategories, edgeProperties, nodeProperties
     * that exist in the graph database.
     */
    $getSimpleSchema() {
        return Bluebird.resolve(Bluebird.props({
            edgeTypes: this.$getEdgeTypes(),
            nodeCategories: this.connector.$doHTTPGetRequest('/db/data/labels'),
            nodeProperties: this.connector.$doHTTPGetRequest('/db/data/propertykeys'),
            edgeProperties: null
        }).then(r => {
            return {
                edgeTypes: r.edgeTypes,
                nodeCategories: r.nodeCategories,
                nodeProperties: r.nodeProperties,
                edgeProperties: r.nodeProperties
            };
        }));
    }
    /**
     * List all edgeTypes that exist in the graph database.
     */
    $getEdgeTypes() {
        return this.connector.$doHTTPGetRequest('/db/data/relationship/types');
    }
    /**
     * Called at the end of the connect phase for additional initializations.
     */
    $onAfterConnect() {
        // TODO #1436 check that alternative IDs are actually properties that exist in the graph
        // TODO #1337 check if HA is enabled and warn is writeURL is not set
        return super.$onAfterConnect();
    }
}
module.exports = Neo4jDriver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmVvNGpEcml2ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2dyYXBoL25lbzRqL25lbzRqRHJpdmVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFPQSxxQ0FBcUM7QUFDckMsNEJBQTRCO0FBQzVCLHlDQUEwQztBQUcxQyxNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxZQUFZLEdBQUcsT0FBTyxDQUFDLGlCQUFpQixDQUFpQyxDQUFDO0FBRWhGLHNEQUFzRDtBQUN0RCxNQUFNLFdBQXNDLFNBQVEsWUFBWTtJQUM5RDs7Ozs7T0FLRztJQUNJLFlBQVksQ0FBQyxHQUFXLEVBQUUsRUFBVTtRQUN6QyxrRUFBa0U7UUFDbEUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUU7WUFDekIsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUFDLG1CQUFtQixFQUFFLEdBQUcsR0FBRyxHQUFHLEdBQUcsdUJBQXVCLENBQUMsQ0FBQztTQUNqRjtJQUNILENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLFlBQVksQ0FBQyxHQUFXLEVBQUUsRUFBVTtRQUN6QyxrRUFBa0U7UUFDbEUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUU7WUFDekIsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUFDLG1CQUFtQixFQUFFLEdBQUcsR0FBRyxHQUFHLEdBQUcsdUJBQXVCLENBQUMsQ0FBQztTQUNqRjtJQUNILENBQUM7SUFFRDs7OztPQUlHO0lBQ0ksYUFBYSxDQUFDLE1BQWdCO1FBQ25DLElBQUksTUFBTSxFQUFFO1lBQ1YsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FDN0IsV0FBVyxFQUNYLHdDQUF3QyxFQUN4QyxzQkFBc0IsQ0FDSCxDQUFDO1NBQ3ZCO1FBRUQsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUNoRixPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLGtCQUFrQixFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ2hELENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxhQUFhLENBQUMsTUFBZ0I7UUFDbkMsSUFBSSxNQUFNLEVBQUU7WUFDVixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUM3QixXQUFXLEVBQ1gsd0NBQXdDLEVBQ3hDLDhCQUE4QixDQUNYLENBQUM7U0FDdkI7UUFFRCxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLCtCQUErQixDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ3BGLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUUsa0JBQWtCLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDaEQsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0ksZ0JBQWdCO1FBQ3JCLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FDckIsUUFBUSxDQUFDLEtBQUssQ0FBQztZQUNiLFNBQVMsRUFBRSxJQUFJLENBQUMsYUFBYSxFQUFFO1lBQy9CLGNBQWMsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLGlCQUFpQixDQUFDLGlCQUFpQixDQUFDO1lBQ25FLGNBQWMsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLGlCQUFpQixDQUFDLHVCQUF1QixDQUFDO1lBQ3pFLGNBQWMsRUFBRSxJQUFJO1NBQ3JCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUU7WUFDVixPQUFPO2dCQUNMLFNBQVMsRUFBRSxDQUFDLENBQUMsU0FBUztnQkFDdEIsY0FBYyxFQUFFLENBQUMsQ0FBQyxjQUEwQjtnQkFDNUMsY0FBYyxFQUFFLENBQUMsQ0FBQyxjQUEwQjtnQkFDNUMsY0FBYyxFQUFFLENBQUMsQ0FBQyxjQUEwQjthQUM3QyxDQUFDO1FBQ0osQ0FBQyxDQUFDLENBQ0gsQ0FBQztJQUNKLENBQUM7SUFFRDs7T0FFRztJQUNJLGFBQWE7UUFDbEIsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGlCQUFpQixDQUFDLDZCQUE2QixDQUF1QixDQUFDO0lBQy9GLENBQUM7SUFFRDs7T0FFRztJQUNJLGVBQWU7UUFDcEIsd0ZBQXdGO1FBQ3hGLG9FQUFvRTtRQUNwRSxPQUFPLEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUNqQyxDQUFDO0NBQ0Y7QUFFRCxpQkFBUyxXQUFXLENBQUMifQ==