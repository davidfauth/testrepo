/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-07-28.
 */
'use strict';
// libraries
const _ = require('lodash');
const Promise = require('bluebird');
// imports
const { DAO } = require('../DAO');
const { IndexDAO } = require('./indexDAO');
const LKE = require('../../services');
const Errors = LKE.getErrors();
const Log = LKE.getLogger(__filename);
const Utils = LKE.getUtils();
const DaoUtils = require('../utils/daoUtils');
const DEFAULT_PAGE_SIZE = 20;
// constants
const ADVANCED_QUERY_RE = /(\sAND\s|\s\|\|\s|\s&&\s|\sOR\s|>|<|\[|:|\s\+|\s-)/;
const BAD_SORT_COLUMN_RE = new RegExp('No mapping found for \\[([^\\]]+)\\] in order to sort on');
const BAD_QUERY_MAPPING_RE = new RegExp('NumberFormatException\\[(.+?")\\];');
const UNDERSCORE_REPLACEMENT_CHAR = '\u0332';
const ES_META_FIELDS = [
    '_index', '_uid', '_type',
    '_id', '_source', '_size',
    '_all', '_field_names', '_ignored',
    '_routing', '_meta'
];
const ES_META_FIELDS_MAPPING = new Map(ES_META_FIELDS
    .map(f => [f, f.replace(/[_]/, UNDERSCORE_REPLACEMENT_CHAR)]));
const ES_META_FIELDS_REVERSE_MAPPING = new Map(ES_META_FIELDS
    .map(f => [f.replace(/[_]/, UNDERSCORE_REPLACEMENT_CHAR), f]));
/**
 * Abstract ElasticSearch Index DAO
 */
class AbstractElasticDAO extends IndexDAO {
    constructor(vendor, requiredOptions, availableOptions, options, features) {
        super(vendor, requiredOptions, availableOptions, options, features);
        this._simplifiedSearch = false;
        this.indexIsConsistent = true;
    }
    /**
     * Return true if the source must be re-indexed to repair data consistency.
     *
     * @returns {boolean}
     */
    mustReindex() {
        return !this.indexIsConsistent;
    }
    /**
     * The `_source` field used to store a node's categories.
     *
     * @param {boolean} [raw=false]
     * @returns {string}
     */
    $nodeCategoriesField(raw) {
        return 'lk_categories';
    }
    /**
     * The `_source` field used to store an edge's type.
     *
     * @param {boolean} [raw=false]
     * @returns {string}
     */
    $edgeTypeField(raw) {
        return 'lk_type';
    }
    get ADVANCED_QUERY_RE() {
        return ADVANCED_QUERY_RE;
    }
    /**
     * Default number of seconds to wait for a connection/ping response
     *
     * @returns {number}
     */
    get DEFAULT_PING_TIMEOUT() {
        return 5;
    }
    /**
     * Maximum number of characters to keep in un-analyzed search sub-fields used for sorting
     *
     * @returns {number}
     */
    get SORT_FIELD_LENGTH() {
        return 15;
    }
    get META_FIELD_MAPPING() {
        return ES_META_FIELDS_MAPPING;
    }
    get META_FIELD_REVERSE_MAPPING() {
        return ES_META_FIELDS_REVERSE_MAPPING;
    }
    /**
     * Convert a raw property into it's alias counterpart
     *
     * @param {string} propertyRawName
     * @returns {string}
     */
    mapIndexField(propertyRawName) {
        if (propertyRawName === this.$nodeCategoriesField()) {
            return '[categories]';
        }
        else if (propertyRawName === this.$edgeTypeField()) {
            return '[type]';
        }
        else if (this.META_FIELD_REVERSE_MAPPING.has(propertyRawName)) {
            return this.META_FIELD_REVERSE_MAPPING.get(propertyRawName);
        }
        else {
            return propertyRawName;
        }
    }
    /**
     * Convert a property alias into it's raw counterpart
     *
     * @param {string} propertyAlias
     * @returns {string}
     */
    resolveIndexField(propertyAlias) {
        if (propertyAlias === '[categories]') {
            return this.$nodeCategoriesField();
        }
        else if (propertyAlias === '[type]') {
            return this.$edgeTypeField();
        }
        else {
            return propertyAlias;
        }
    }
    /**
     * @inheritdoc
     */
    $search(options) {
        return this._failSafeSearch(options).then(result => {
            return Promise.resolve({
                type: options.type,
                totalHits: result.hits.total,
                results: result.hits.hits.map(o => o._id)
            });
        });
    }
    /**
     * Contains the logic or retrying a search query when advanced mode fails
     *
     * `result.hits.hits` example:
     * [{
     *   _index: 'linkurious_xxxxx',
     *   _type: 'node',
     *   _id: '10906',
     *   _score: 0.095891505
     * }]
     *
     * @param {ISearchDAOParams} params
     * @param {boolean} [forceSimpleMode=false] whether to force a simple query (even with advanced syntax)
     * @returns {Bluebird<{hits: {hits: {_index:string, _type:string, _id:string, _score:number, _source:object, highlight:object}[]}}>}
     */
    _failSafeSearch(options, forceSimpleMode) {
        // first call: let the query decide of the search mode
        if (forceSimpleMode === undefined) {
            forceSimpleMode = false;
        }
        const advanced = !forceSimpleMode && options.q.match(this.ADVANCED_QUERY_RE);
        const searchQuery = {
            body: this._buildSearchQuery(options, advanced),
            advanced: advanced
        };
        searchQuery.size = searchQuery.body.size;
        searchQuery.from = searchQuery.body.from;
        if (Utils.noValue(searchQuery.body)) {
            return Promise.resolve({
                hits: {
                    hits: [],
                    total: 0
                }
            });
        }
        return this.searchPromise(options.type, searchQuery, advanced).catch(customError => {
            if (!advanced) {
                // a simple search failing : we have a serious problem
                return Promise.reject(customError);
            }
            else {
                // retry: force 'simple' mode
                return this._failSafeSearch(options, true);
            }
        });
    }
    /**
     * @param {string} itemType "node" or "edge"
     * @returns {string} the ElasticSearch type for the given itemType
     */
    $resolveESType(itemType) { return Utils.NOT_IMPLEMENTED(); }
    /**
     * @param {string} itemType
     * @returns {string} the ElasticSearch index for the given itemType
     */
    $resolveESIndex(itemType) { return Utils.NOT_IMPLEMENTED(); }
    /**
     * ES2 wants the fuzziness expressed in number of characters of distance.
     * The editDistance is 0 if fuzziness === 0
     * AUTO if 0 < fuzziness <= 0.6
     * 2 if fuzziness > 0.6
     *
     * Definition of AUTO:
     * https://www.elastic.co/guide/en/elasticsearch/reference/1.4/common-options.html#_string_fields
     *
     * @param {number} length    length of the searchString
     * @param {number} fuzziness
     * @returns {*}
     * @private
     */
    _editDistanceFromFuzziness(length, fuzziness) {
        if (fuzziness === 0) {
            return 0;
        }
        else if (fuzziness <= 0.6) {
            return 'AUTO';
        }
        else {
            return 2;
        }
    }
    /**
     * @param {ISearchDAOParams} params
     * @param {boolean}          advanced
     */
    _buildSearchQuery(params, advanced) {
        const editDistance = this._editDistanceFromFuzziness(params.q.length, params.fuzziness);
        const filteredLabelsByPropertyLength = params.schema.labels.filter(label => params.schema.get(label).properties.length > 0);
        // avoid to return all documents and force to return none if there is no label to search on
        if (!filteredLabelsByPropertyLength.length) {
            return undefined;
        }
        return {
            query: {
                bool: {
                    should: filteredLabelsByPropertyLength.map((rawLabel => {
                        let shouldMatch;
                        if (advanced) {
                            shouldMatch = [{
                                    'query_string': {
                                        query: params.q,
                                        lenient: true,
                                        fields: params.schema.get(rawLabel).properties.map(p => p.propertyKey),
                                        analyzer: this._analyzer
                                    }
                                }];
                        }
                        else if (this._simplifiedSearch) {
                            shouldMatch = [{
                                    'multi_match': {
                                        query: params.q,
                                        lenient: true,
                                        fields: params.schema.get(rawLabel).properties.map(p => p.propertyKey),
                                        fuzziness: editDistance
                                    }
                                }];
                        }
                        else {
                            shouldMatch = [{
                                    'multi_match': {
                                        query: params.q,
                                        lenient: true,
                                        fields: params.schema.get(rawLabel).properties.map(p => p.propertyKey),
                                        fuzziness: editDistance
                                    }
                                }, {
                                    'multi_match': {
                                        query: params.q,
                                        lenient: true,
                                        type: 'phrase_prefix',
                                        fields: params.schema.get(rawLabel).properties.map(p => p.propertyKey)
                                    }
                                }];
                        }
                        let labelTerms;
                        if (this._isES1) {
                            // lk_categories/lk_type are indexed with the default analyser in ES1
                            // lowercase + space tokenizer
                            // a.a, a:a, 1.1 don't have to be split
                            labelTerms = rawLabel.replace(/([a-z])[:.]((?![a-z]).*)/gi, '$1 $2');
                            labelTerms = labelTerms.replace(/([0-9])[.]((?![0-9]).*)/gi, '$1 $2');
                            labelTerms = labelTerms.replace(/[()|/@<>#-]+/g, ' ')
                                .trim().toLowerCase().split(/ +/);
                        }
                        else {
                            labelTerms = [rawLabel];
                        }
                        return {
                            bool: {
                                should: shouldMatch,
                                must: labelTerms.map(term => ({
                                    term: {
                                        [params.type === 'node'
                                            ? this.$nodeCategoriesField(true)
                                            : this.$edgeTypeField(true)]: term
                                    }
                                })),
                                'minimum_should_match': 1
                            }
                        };
                    })),
                    must: _.map(params.filter, propertyFilter => ({
                        match: {
                            [propertyFilter[0]]: { query: propertyFilter[1], operator: 'and' }
                        }
                    })),
                    'minimum_should_match': 1
                }
            },
            size: params.size,
            from: params.from,
            _source: false
        };
    }
    /**
     * @param {string} itemType "node" or edge"
     * @param {object} queryBody an ElasticSearch query object
     * @param {boolean} [doNotLogErrorQuery=false]
     * @returns {Bluebird<Object|LkError>} a response promise
     */
    searchPromise(itemType, queryBody, doNotLogErrorQuery) {
        return this.$searchPromise(itemType, queryBody).catch(err => {
            if (typeof err === 'object' && typeof err.message === 'string') {
                let groups;
                if ((groups = BAD_SORT_COLUMN_RE.exec(err.message))) {
                    return Errors.business('invalid_parameter', 'ElasticSearch: invalid sort column (' + groups[1] + ')', true);
                }
                if ((groups = BAD_QUERY_MAPPING_RE.exec(err.message))) {
                    return Errors.business('invalid_parameter', 'ElasticSearch: invalid number (' + groups[1] + ')', true);
                }
            }
            if (!doNotLogErrorQuery) {
                Log.error('ElasticSearch error, query was:', global.JSON.stringify(queryBody, null, ' '));
            }
            return Promise.reject(this.getLkError(err, undefined, itemType));
        });
    }
    /**
     * Run a search query
     *
     * @param {string} itemType "node" or "edge"
     * @param {object} query
     * @param {object} query.body actual query
     * @param {number} [query.from]
     * @param {number} [query.size]
     * @param {boolean} [query.version]
     *
     * @returns {Bluebird<object>}
     */
    $searchPromise(itemType, query) { return Utils.NOT_IMPLEMENTED(); }
    /**
     * @param {*} esError
     * @param {string} [prefix]
     * @param {string} [itemType] "node" or "edge"
   * @returns {LkError}
     */
    getLkError(esError, prefix, itemType) {
        prefix = 'ElasticSearch' + (prefix ? ' ' + prefix : '');
        const errorMessage = (typeof esError === 'string'
            ? esError
            : (esError && typeof esError.message === 'string'
                ? esError.message
                : JSON.stringify(esError)));
        if (errorMessage === 'No Living connections') {
            return Errors.business('dataSource_unavailable', 'Could not connect to ElasticSearch.');
        }
        if (errorMessage.includes('MapperParsingException')) {
            Log.error(esError);
            let message = _.capitalize(itemType || 'item') + ' property had an unexpected type';
            if (errorMessage.includes('NumberFormatException')) {
                message += ' (expected a number)';
            }
            message += ', try setting "dynamicMapping:false" in index configuration.';
            return Errors.business('index_mapping_error', message);
        }
        return Errors.technical('critical', prefix + ': ' + errorMessage);
    }
}
module.exports = AbstractElasticDAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWJzdHJhY3RFbGFzdGljREFPLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL2Rhby9pbmRleC9hYnN0cmFjdEVsYXN0aWNEQU8uanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFFYixZQUFZO0FBQ1osTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUVwQyxVQUFVO0FBQ1YsTUFBTSxFQUFFLEdBQUcsRUFBRSxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNsQyxNQUFNLEVBQUUsUUFBUSxFQUFFLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDO0FBQzNDLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0FBQ3RDLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3RDLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUU3QixNQUFNLFFBQVEsR0FBRyxPQUFPLENBQUMsbUJBQW1CLENBQUMsQ0FBQztBQUU5QyxNQUFNLGlCQUFpQixHQUFHLEVBQUUsQ0FBQztBQUU3QixZQUFZO0FBQ1osTUFBTSxpQkFBaUIsR0FBRyxvREFBb0QsQ0FBQztBQUUvRSxNQUFNLGtCQUFrQixHQUFHLElBQUksTUFBTSxDQUFDLDBEQUEwRCxDQUFDLENBQUM7QUFFbEcsTUFBTSxvQkFBb0IsR0FBRyxJQUFJLE1BQU0sQ0FBQyxvQ0FBb0MsQ0FBQyxDQUFDO0FBRTlFLE1BQU0sMkJBQTJCLEdBQUcsUUFBUSxDQUFDO0FBRTdDLE1BQU0sY0FBYyxHQUFHO0lBQ3JCLFFBQVEsRUFBRSxNQUFNLEVBQUUsT0FBTztJQUN6QixLQUFLLEVBQUUsU0FBUyxFQUFFLE9BQU87SUFDekIsTUFBTSxFQUFFLGNBQWMsRUFBRSxVQUFVO0lBQ2xDLFVBQVUsRUFBRSxPQUFPO0NBQ3BCLENBQUM7QUFFRixNQUFNLHNCQUFzQixHQUFHLElBQUksR0FBRyxDQUFDLGNBQWM7S0FDbEQsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsMkJBQTJCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUVqRSxNQUFNLDhCQUE4QixHQUFHLElBQUksR0FBRyxDQUFDLGNBQWM7S0FDMUQsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSwyQkFBMkIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUVqRTs7R0FFRztBQUNILE1BQU0sa0JBQW1CLFNBQVEsUUFBUTtJQUV2QyxZQUFZLE1BQU0sRUFBRSxlQUFlLEVBQUUsZ0JBQWdCLEVBQUUsT0FBTyxFQUFFLFFBQVE7UUFDdEUsS0FBSyxDQUNILE1BQU0sRUFDTixlQUFlLEVBQ2YsZ0JBQWdCLEVBQ2hCLE9BQU8sRUFDUCxRQUFRLENBQ1QsQ0FBQztRQUVGLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxLQUFLLENBQUM7UUFDL0IsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQztJQUNoQyxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILFdBQVc7UUFDVCxPQUFPLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDO0lBQ2pDLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILG9CQUFvQixDQUFDLEdBQUc7UUFDdEIsT0FBTyxlQUFlLENBQUM7SUFDekIsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsY0FBYyxDQUFDLEdBQUc7UUFDaEIsT0FBTyxTQUFTLENBQUM7SUFDbkIsQ0FBQztJQUVELElBQUksaUJBQWlCO1FBQ25CLE9BQU8saUJBQWlCLENBQUM7SUFDM0IsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxJQUFJLG9CQUFvQjtRQUN0QixPQUFPLENBQUMsQ0FBQztJQUNYLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsSUFBSSxpQkFBaUI7UUFDbkIsT0FBTyxFQUFFLENBQUM7SUFDWixDQUFDO0lBRUQsSUFBSSxrQkFBa0I7UUFDcEIsT0FBTyxzQkFBc0IsQ0FBQztJQUNoQyxDQUFDO0lBRUQsSUFBSSwwQkFBMEI7UUFDNUIsT0FBTyw4QkFBOEIsQ0FBQztJQUN4QyxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxhQUFhLENBQUMsZUFBZTtRQUMzQixJQUFJLGVBQWUsS0FBSyxJQUFJLENBQUMsb0JBQW9CLEVBQUUsRUFBRTtZQUNuRCxPQUFPLGNBQWMsQ0FBQztTQUN2QjthQUFNLElBQUksZUFBZSxLQUFLLElBQUksQ0FBQyxjQUFjLEVBQUUsRUFBRTtZQUNwRCxPQUFPLFFBQVEsQ0FBQztTQUNqQjthQUFNLElBQUksSUFBSSxDQUFDLDBCQUEwQixDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsRUFBRTtZQUMvRCxPQUFPLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUM7U0FDN0Q7YUFBTTtZQUNMLE9BQU8sZUFBZSxDQUFDO1NBQ3hCO0lBQ0gsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsaUJBQWlCLENBQUMsYUFBYTtRQUM3QixJQUFJLGFBQWEsS0FBSyxjQUFjLEVBQUU7WUFDcEMsT0FBTyxJQUFJLENBQUMsb0JBQW9CLEVBQUUsQ0FBQztTQUNwQzthQUFNLElBQUksYUFBYSxLQUFLLFFBQVEsRUFBRTtZQUNyQyxPQUFPLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztTQUM5QjthQUFNO1lBQ0wsT0FBTyxhQUFhLENBQUM7U0FDdEI7SUFDSCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxPQUFPLENBQUMsT0FBTztRQUViLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDakQsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDO2dCQUNyQixJQUFJLEVBQUUsT0FBTyxDQUFDLElBQUk7Z0JBQ2xCLFNBQVMsRUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUs7Z0JBQzVCLE9BQU8sRUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO2FBQzFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7OztPQWNHO0lBQ0gsZUFBZSxDQUFDLE9BQU8sRUFBRSxlQUFlO1FBQ3RDLHNEQUFzRDtRQUN0RCxJQUFJLGVBQWUsS0FBSyxTQUFTLEVBQUU7WUFDakMsZUFBZSxHQUFHLEtBQUssQ0FBQztTQUN6QjtRQUVELE1BQU0sUUFBUSxHQUFHLENBQUMsZUFBZSxJQUFJLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1FBQzdFLE1BQU0sV0FBVyxHQUFHO1lBQ2xCLElBQUksRUFBRSxJQUFJLENBQUMsaUJBQWlCLENBQUMsT0FBTyxFQUFFLFFBQVEsQ0FBQztZQUMvQyxRQUFRLEVBQUUsUUFBUTtTQUNuQixDQUFDO1FBQ0YsV0FBVyxDQUFDLElBQUksR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztRQUN6QyxXQUFXLENBQUMsSUFBSSxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBRXpDLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDbkMsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDO2dCQUNyQixJQUFJLEVBQUU7b0JBQ0osSUFBSSxFQUFFLEVBQUU7b0JBQ1IsS0FBSyxFQUFFLENBQUM7aUJBQ1Q7YUFDRixDQUFDLENBQUM7U0FDSjtRQUVELE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLFdBQVcsRUFBRSxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDakYsSUFBSSxDQUFDLFFBQVEsRUFBRTtnQkFDYixzREFBc0Q7Z0JBQ3RELE9BQU8sT0FBTyxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQzthQUNwQztpQkFBTTtnQkFDTCw2QkFBNkI7Z0JBQzdCLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDNUM7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7O09BR0c7SUFDSCxjQUFjLENBQUMsUUFBUSxJQUFJLE9BQU8sS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUU1RDs7O09BR0c7SUFDSCxlQUFlLENBQUMsUUFBUSxJQUFJLE9BQU8sS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUU3RDs7Ozs7Ozs7Ozs7OztPQWFHO0lBQ0gsMEJBQTBCLENBQUMsTUFBTSxFQUFFLFNBQVM7UUFDMUMsSUFBSSxTQUFTLEtBQUssQ0FBQyxFQUFFO1lBQ25CLE9BQU8sQ0FBQyxDQUFDO1NBQ1Y7YUFBTSxJQUFJLFNBQVMsSUFBSSxHQUFHLEVBQUU7WUFDM0IsT0FBTyxNQUFNLENBQUM7U0FDZjthQUFNO1lBQ0wsT0FBTyxDQUFDLENBQUM7U0FDVjtJQUNILENBQUM7SUFFRDs7O09BR0c7SUFDSCxpQkFBaUIsQ0FBQyxNQUFNLEVBQUUsUUFBUTtRQUNoQyxNQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsMEJBQTBCLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBRXhGLE1BQU0sOEJBQThCLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUNoRSxLQUFLLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUN4RCxDQUFDO1FBRUYsMkZBQTJGO1FBQzNGLElBQUksQ0FBQyw4QkFBOEIsQ0FBQyxNQUFNLEVBQUU7WUFDMUMsT0FBTyxTQUFTLENBQUM7U0FDbEI7UUFFRCxPQUFPO1lBQ0wsS0FBSyxFQUFFO2dCQUNMLElBQUksRUFBRTtvQkFDSixNQUFNLEVBQUUsOEJBQThCLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLEVBQUU7d0JBQ3JELElBQUksV0FBVyxDQUFDO3dCQUVoQixJQUFJLFFBQVEsRUFBRTs0QkFDWixXQUFXLEdBQUcsQ0FBQztvQ0FDYixjQUFjLEVBQUU7d0NBQ2QsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDO3dDQUNmLE9BQU8sRUFBRSxJQUFJO3dDQUNiLE1BQU0sRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQzt3Q0FDdEUsUUFBUSxFQUFFLElBQUksQ0FBQyxTQUFTO3FDQUN6QjtpQ0FDRixDQUFDLENBQUM7eUJBQ0o7NkJBQU0sSUFBSSxJQUFJLENBQUMsaUJBQWlCLEVBQUU7NEJBQ2pDLFdBQVcsR0FBRyxDQUFDO29DQUNiLGFBQWEsRUFBRTt3Q0FDYixLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUM7d0NBQ2YsT0FBTyxFQUFFLElBQUk7d0NBQ2IsTUFBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDO3dDQUN0RSxTQUFTLEVBQUUsWUFBWTtxQ0FDeEI7aUNBQ0YsQ0FBQyxDQUFDO3lCQUNKOzZCQUFNOzRCQUNMLFdBQVcsR0FBRyxDQUFDO29DQUNiLGFBQWEsRUFBRTt3Q0FDYixLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUM7d0NBQ2YsT0FBTyxFQUFFLElBQUk7d0NBQ2IsTUFBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDO3dDQUN0RSxTQUFTLEVBQUUsWUFBWTtxQ0FDeEI7aUNBQUUsRUFBRTtvQ0FDTCxhQUFhLEVBQUU7d0NBQ2IsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDO3dDQUNmLE9BQU8sRUFBRSxJQUFJO3dDQUNiLElBQUksRUFBRSxlQUFlO3dDQUNyQixNQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUM7cUNBQ3ZFO2lDQUNGLENBQUMsQ0FBQzt5QkFDSjt3QkFFRCxJQUFJLFVBQVUsQ0FBQzt3QkFDZixJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUU7NEJBQ2YscUVBQXFFOzRCQUNyRSw4QkFBOEI7NEJBRTlCLHVDQUF1Qzs0QkFDdkMsVUFBVSxHQUFHLFFBQVEsQ0FBQyxPQUFPLENBQUMsNEJBQTRCLEVBQUUsT0FBTyxDQUFDLENBQUM7NEJBQ3JFLFVBQVUsR0FBRyxVQUFVLENBQUMsT0FBTyxDQUFDLDJCQUEyQixFQUFFLE9BQU8sQ0FBQyxDQUFDOzRCQUN0RSxVQUFVLEdBQUcsVUFBVSxDQUFDLE9BQU8sQ0FBQyxlQUFlLEVBQUUsR0FBRyxDQUFDO2lDQUNsRCxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7eUJBQ3JDOzZCQUFNOzRCQUNMLFVBQVUsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3lCQUN6Qjt3QkFFRCxPQUFPOzRCQUNMLElBQUksRUFBRTtnQ0FDSixNQUFNLEVBQUUsV0FBVztnQ0FDbkIsSUFBSSxFQUFFLFVBQVUsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO29DQUM1QixJQUFJLEVBQUU7d0NBQ0osQ0FBQyxNQUFNLENBQUMsSUFBSSxLQUFLLE1BQU07NENBQ3JCLENBQUMsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDOzRDQUNqQyxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FDNUIsRUFBRSxJQUFJO3FDQUFFO2lDQUFDLENBQUMsQ0FBQztnQ0FDaEIsc0JBQXNCLEVBQUUsQ0FBQzs2QkFDMUI7eUJBQ0YsQ0FBQztvQkFDSixDQUFDLENBQUMsQ0FBQztvQkFDSCxJQUFJLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLGNBQWMsQ0FBQyxFQUFFLENBQUMsQ0FBQzt3QkFDNUMsS0FBSyxFQUFFOzRCQUNMLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBQyxLQUFLLEVBQUUsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUM7eUJBQ2pFO3FCQUNGLENBQUMsQ0FBQztvQkFDSCxzQkFBc0IsRUFBRSxDQUFDO2lCQUMxQjthQUNGO1lBQ0QsSUFBSSxFQUFFLE1BQU0sQ0FBQyxJQUFJO1lBQ2pCLElBQUksRUFBRSxNQUFNLENBQUMsSUFBSTtZQUNqQixPQUFPLEVBQUUsS0FBSztTQUNmLENBQUM7SUFDSixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxhQUFhLENBQUMsUUFBUSxFQUFFLFNBQVMsRUFBRSxrQkFBa0I7UUFDbkQsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxTQUFTLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDMUQsSUFBSSxPQUFPLEdBQUcsS0FBSyxRQUFRLElBQUksT0FBTyxHQUFHLENBQUMsT0FBTyxLQUFLLFFBQVEsRUFBRTtnQkFDOUQsSUFBSSxNQUFNLENBQUM7Z0JBQ1gsSUFBSSxDQUFDLE1BQU0sR0FBRyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUU7b0JBQ25ELE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FDcEIsbUJBQW1CLEVBQUUsc0NBQXNDLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsRUFBRSxJQUFJLENBQ3BGLENBQUM7aUJBQ0g7Z0JBQ0QsSUFBSSxDQUFDLE1BQU0sR0FBRyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUU7b0JBQ3JELE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FDcEIsbUJBQW1CLEVBQUUsaUNBQWlDLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsRUFBRSxJQUFJLENBQy9FLENBQUM7aUJBQ0g7YUFDRjtZQUVELElBQUksQ0FBQyxrQkFBa0IsRUFBRTtnQkFDdkIsR0FBRyxDQUFDLEtBQUssQ0FBQyxpQ0FBaUMsRUFDekMsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRSxHQUFHLENBQUMsQ0FDNUMsQ0FBQzthQUNIO1lBRUQsT0FBTyxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxFQUFFLFNBQVMsRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDO1FBQ25FLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7OztPQVdHO0lBQ0gsY0FBYyxDQUFDLFFBQVEsRUFBRSxLQUFLLElBQUksT0FBTyxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBRW5FOzs7OztPQUtHO0lBQ0gsVUFBVSxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsUUFBUTtRQUNsQyxNQUFNLEdBQUcsZUFBZSxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUV4RCxNQUFNLFlBQVksR0FBRyxDQUFDLE9BQU8sT0FBTyxLQUFLLFFBQVE7WUFDL0MsQ0FBQyxDQUFDLE9BQU87WUFDVCxDQUFDLENBQUMsQ0FBQyxPQUFPLElBQUksT0FBTyxPQUFPLENBQUMsT0FBTyxLQUFLLFFBQVE7Z0JBQy9DLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTztnQkFDakIsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQzFCLENBQ0YsQ0FBQztRQUVGLElBQUksWUFBWSxLQUFLLHVCQUF1QixFQUFFO1lBQzVDLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyx3QkFBd0IsRUFBRSxxQ0FBcUMsQ0FBQyxDQUFDO1NBQ3pGO1FBRUQsSUFBSSxZQUFZLENBQUMsUUFBUSxDQUFDLHdCQUF3QixDQUFDLEVBQUU7WUFDbkQsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUVuQixJQUFJLE9BQU8sR0FBRyxDQUFDLENBQUMsVUFBVSxDQUFDLFFBQVEsSUFBSSxNQUFNLENBQUMsR0FBRyxrQ0FBa0MsQ0FBQztZQUNwRixJQUFJLFlBQVksQ0FBQyxRQUFRLENBQUMsdUJBQXVCLENBQUMsRUFBRTtnQkFDbEQsT0FBTyxJQUFJLHNCQUFzQixDQUFDO2FBQ25DO1lBQ0QsT0FBTyxJQUFJLDhEQUE4RCxDQUFDO1lBRTFFLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxxQkFBcUIsRUFBRSxPQUFPLENBQUMsQ0FBQztTQUN4RDtRQUVELE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUUsTUFBTSxHQUFHLElBQUksR0FBRyxZQUFZLENBQUMsQ0FBQztJQUNwRSxDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLGtCQUFrQixDQUFDIn0=