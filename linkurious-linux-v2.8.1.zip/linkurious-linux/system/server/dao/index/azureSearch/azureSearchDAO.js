"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2018-07-11.
 */
Object.defineProperty(exports, "__esModule", { value: true });
const azureSearchConnector_1 = require("../../connector/azureSearchConnector");
const indexDAO_1 = require("../indexDAO");
const azureSearchDriver_1 = require("./azureSearchDriver");
class AzureSearchDAO extends indexDAO_1.IndexDAO {
    constructor(options, graphDao) {
        super('azureSearch', ['url', 'apiKey', 'nodeIndexName'], ['url', 'apiKey', 'nodeIndexName', 'edgeIndexName'], options, {
            external: true,
            canCount: true,
            canIndexEdges: true,
            searchHitsCount: true
        }, graphDao, azureSearchConnector_1.AzureSearchConnector, [
            // The API version of the azure search service has the format: YYYY-MM-DD
            // We use a semVer compatible version format
            { version: '2019.05.06', driver: '[latest]' },
            { version: '2019.05.06', driver: azureSearchDriver_1.AzureSearchDriver }
        ], ['cosmosDb']);
    }
}
module.exports = AzureSearchDAO;
/**
 * @dokapi azure.search.config
 *
 * Azure search is the recommended full text search solution for Cosmos DB.
 *
 * ## Azure search integration
 *
 * Linkurious requires an index on nodes to perform a search.
 * If you do not have a configured index yet, you can create one via the [azure portal](https://docs.microsoft.com/en-us/azure/search/search-howto-index-cosmosdb).
 *
 * Additionally, you can create an index on edges if you want search them as well with Linkurious.
 *
 * Please review the description of each index attributes and make sure the `label` field is marked
 * as `filterable`. Linkurious will not be able to use the index otherwise.
 *
 * ## Configuration
 * To edit the AzureSearch data-source configuration,
 * you can either [use the Web user-interface](/configure-sources/#using-the-web-user-interface)
 * or edit the configuration file located at {{config}}.
 *
 * Example configuration:
 * ```json
 * {
 *   "dataSources": [
 *     {
 *       "graphdb": {
 *         "vendor": "cosmosDb",
 *         "url": "https://your-service.gremlin.cosmosdb.azure.com:443/",
 *         "database": "your-graph-database",
 *         "collection":  "your-collection",
 *         "primaryKey": "your-account-primary-key"
 *       },
 *       "index": {
 *         "vendor": "azureSearch",
 *         "url": "https://your-search-service.search.windows.net",
 *         "apiKey": "your-search-service-admin-api-key",
 *         "nodeIndexName": "your-node-index-name",
 *         "edgeIndexName": "your-edge-index-name"
 *       }
 *     }
 *   ]
 * }
 * ```
 *
 *  Supported `index` options with Azure search:
 *
 * - `url` (*required*): URL of the search service
 * - `apiKey` (*required*): Primary Admin Key of the search service
 * - `nodeIndexName` (*required*): Name of the node index of your graph database
 * - `edgeIndexName` (optional): Name of the edge index of your graph database
 *
 * Please refer to the
 * [Azure search online documentation](https://docs.microsoft.com/en-us/azure/search/search-import-data-portal)
 * for details on how to load data into Azure search.
 */
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXp1cmVTZWFyY2hEQU8uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2luZGV4L2F6dXJlU2VhcmNoL2F6dXJlU2VhcmNoREFPLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRzs7QUFHSCwrRUFBMEU7QUFJMUUsMENBQXVDO0FBQ3ZDLDJEQUFzRDtBQUV0RCxNQUFNLGNBQ0osU0FBUSxtQkFBYztJQUN0QixZQUNFLE9BQStCLEVBQy9CLFFBQXFEO1FBQ3JELEtBQUssQ0FBQyxhQUFhLEVBQ2pCLENBQUMsS0FBSyxFQUFFLFFBQVEsRUFBRSxlQUFlLENBQUMsRUFDbEMsQ0FBQyxLQUFLLEVBQUUsUUFBUSxFQUFFLGVBQWUsRUFBRSxlQUFlLENBQUMsRUFDbkQsT0FBTyxFQUFFO1lBQ1AsUUFBUSxFQUFFLElBQUk7WUFDZCxRQUFRLEVBQUUsSUFBSTtZQUNkLGFBQWEsRUFBRSxJQUFJO1lBQ25CLGVBQWUsRUFBRSxJQUFJO1NBQ3RCLEVBQ0QsUUFBUSxFQUNSLDJDQUEwQyxFQUMxQztZQUNFLHlFQUF5RTtZQUN6RSw0Q0FBNEM7WUFDNUMsRUFBQyxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUM7WUFDM0MsRUFBQyxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sRUFBRSxxQ0FBa0QsRUFBQztTQUNwRixFQUNELENBQUMsVUFBVSxDQUFDLENBQ2IsQ0FBQztJQUNKLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsY0FBYyxDQUFDO0FBRWhDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0FzREcifQ==