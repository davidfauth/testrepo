"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2018-07-11.
 */
Object.defineProperty(exports, "__esModule", { value: true });
const rest_client_1 = require("@linkurious/rest-client");
const Bluebird = require("bluebird");
const _ = require("lodash");
const DaoUtils = require("../../utils/daoUtils");
const indexDriver_1 = require("../indexDriver");
const LKE = require('../../../services/index');
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
class AzureSearchDriver extends indexDriver_1.IndexDriver {
    /**
     * Index Driver constructor
     *
     * @param connector     Connector used by the DAO
     * @param graphDAO      The connected Graph DAO
     * @param indexOptions  IndexDAO options
     * @param connectorData Data from the connector
     * @param indexFeatures Features of the Index DAO
     */
    constructor(connector, graphDAO, indexOptions, connectorData, indexFeatures) {
        super(connector, graphDAO, indexOptions, connectorData, indexFeatures);
        this.filterableNodeProperties = new Set();
        this.searchableNodeProperties = new Set();
        this.filterableEdgeProperties = new Set();
        this.searchableEdgeProperties = new Set();
        this.nodeIndexName = this.getIndexOption('nodeIndexName');
        this.edgeIndexName = this.getIndexOption('edgeIndexName');
        if (Utils.noValue(this.edgeIndexName)) {
            this.indexFeatures.canIndexEdges = false;
        }
    }
    /**
     * Called at the end of the connect phase for additional initializations.
     *
     * Optional to implement.
     */
    $onAfterConnect() {
        return Bluebird.resolve().then(() => this.checkIndexes());
    }
    /**
     * Get the number of nodes or edges in the search index.
     */
    $getSize(type) {
        if (type === rest_client_1.EntityType.NODE) {
            return Bluebird.resolve().then(() => this.connector.getCount(this.nodeIndexName));
        }
        if (Utils.hasValue(this.edgeIndexName)) {
            return Bluebird.resolve().then(() => this.connector.getCount(this.edgeIndexName));
        }
        return Bluebird.resolve(0);
    }
    collectIndexedFields(index, filterable, searchable) {
        filterable.clear();
        searchable.clear();
        index.fields.forEach(field => {
            if (field.filterable) {
                filterable.add(field.name);
            }
            if (field.searchable) {
                searchable.add(field.name);
            }
        });
    }
    /**
     * Check that Node and Edge indices exist.
     * Check that the fields `id` and `label` (required by LKE) are retrievable on each index.
     *
     * @throws {LkError} If an index doesn't exist or does not have the required fields
     */
    async checkIndexes() {
        const nodeIndex = await this.connector.findIndex(this.nodeIndexName);
        // The index should be capable to filter by node category
        AzureSearchDriver.checkIndex(nodeIndex, ['label']);
        this.collectIndexedFields(nodeIndex, this.filterableNodeProperties, this.searchableNodeProperties);
        if (Utils.hasValue(this.edgeIndexName)) {
            const edgeIndex = await this.connector.findIndex(this.edgeIndexName);
            // The index should be capable to filter by edge type
            AzureSearchDriver.checkIndex(edgeIndex, ['label']);
            this.collectIndexedFields(edgeIndex, this.filterableEdgeProperties, this.searchableEdgeProperties);
        }
    }
    /**
     * Fail if any field in `requiredFilterable` is not filterable.
     */
    static checkIndex(index, requiredFilterable) {
        const configuredFilterable = _.map(_.filter(index.fields, 'filterable'), 'name');
        for (const field of requiredFilterable) {
            if (!configuredFilterable.includes(field)) {
                return Errors.business('source_action_needed', `The field "${field}"` +
                    `should be filterable on the index "${index.name}"`, true);
            }
        }
    }
    /**
     * Generate an Azure Search Filter query.
     */
    generateFilterQuery(label, filter, filterableProperties = []) {
        const filterClauses = [`search.in(label, '${label}')`];
        if (filter !== undefined) {
            filter.forEach(([key, value]) => {
                if (filterableProperties.includes(key)) {
                    filterClauses.push(`search.ismatch('${value}', '${key}')`);
                }
            });
        }
        return filterClauses.join(' and ');
    }
    /**
     * Search for nodes or edges using `options.q`.
     * Search results are grouped by categories or types.
     *
     * Some DAOs can't compute `totalHits` cheaply. As an alternative, `moreResults` is returned.
     * Which one is returned is defined by features.searchHitsCount.
     *
     * Support edge entries only if features.canIndexEdges is true.
     */
    async $search(options) {
        const luceneQuery = DaoUtils.generateLuceneQuery(options.q, options.fuzziness, {});
        const noSearchQuery = luceneQuery.trim().length === 0;
        const noReadableType = options.schema.size === 0;
        if (noSearchQuery || noReadableType) {
            return {
                type: options.type,
                results: []
            };
        }
        const index = options.type === rest_client_1.EntityType.NODE ? this.nodeIndexName : this.edgeIndexName;
        const filterableProperties = options.type === rest_client_1.EntityType.NODE
            ? Array.from(this.filterableNodeProperties)
            : Array.from(this.filterableEdgeProperties);
        const searchableProperties = options.type === rest_client_1.EntityType.NODE
            ? Array.from(this.searchableNodeProperties)
            : Array.from(this.searchableEdgeProperties);
        const searchOptions = options.schema.labels.map(label => ({
            luceneQuery: luceneQuery,
            filterQuery: this.generateFilterQuery(label, options.filter, filterableProperties),
            searchFields: _.intersection(searchableProperties, options.schema.get(label).properties
                .map(p => p.propertyKey)),
            size: options.from + options.size
        }));
        const searchResults = (await Promise.all(searchOptions
            .map(query => this.connector.doFullTextSearch(index, query))))
            .reduce((result, r) => {
            result.totalHits += r['@odata.count'];
            result.hits = result.hits.concat(...r.value);
            return result;
        }, { totalHits: 0, hits: [] });
        const hits = searchResults.hits
            .sort((a, b) => a['@search.score'] - b['@search.score'])
            .splice(options.from, options.size);
        return {
            type: options.type,
            totalHits: searchResults.totalHits,
            results: _.map(hits, 'id')
        };
    }
    /**
     * Run the indexation of the external index.
     */
    async $indexSource(progress, schema) {
        // reload the list of filterable and searchable properties
        return this.checkIndexes();
    }
    $addEntries(type, entries) {
        return Utils.NOT_IMPLEMENTED();
    }
    $commit() {
        return Utils.NOT_IMPLEMENTED();
    }
    $createIndex() {
        return Utils.NOT_IMPLEMENTED();
    }
    $deleteEntry(id, type) {
        return Utils.NOT_IMPLEMENTED();
    }
    $deleteIfExists() {
        return Utils.NOT_IMPLEMENTED();
    }
    $upsertEntry(type, entry) {
        return Utils.NOT_IMPLEMENTED();
    }
}
exports.AzureSearchDriver = AzureSearchDriver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXp1cmVTZWFyY2hEcml2ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2luZGV4L2F6dXJlU2VhcmNoL2F6dXJlU2VhcmNoRHJpdmVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRzs7QUFFSCx5REFBbUU7QUFDbkUscUNBQXFDO0FBQ3JDLDRCQUE0QjtBQVM1QixpREFBaUQ7QUFDakQsZ0RBQWlGO0FBR2pGLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO0FBQy9DLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFFL0IsTUFBYSxpQkFBa0QsU0FBUSx5QkFBYztJQVFuRjs7Ozs7Ozs7T0FRRztJQUNILFlBQ0UsU0FBWSxFQUNaLFFBQXFDLEVBQ3JDLFlBQW9DLEVBQ3BDLGFBQXFDLEVBQ3JDLGFBQTRCO1FBQzVCLEtBQUssQ0FBQyxTQUFTLEVBQUUsUUFBUSxFQUFFLFlBQVksRUFBRSxhQUFhLEVBQUUsYUFBYSxDQUFDLENBQUM7UUFwQmpFLDZCQUF3QixHQUFnQixJQUFJLEdBQUcsRUFBRSxDQUFDO1FBQ2xELDZCQUF3QixHQUFnQixJQUFJLEdBQUcsRUFBRSxDQUFDO1FBQ2xELDZCQUF3QixHQUFnQixJQUFJLEdBQUcsRUFBRSxDQUFDO1FBQ2xELDZCQUF3QixHQUFnQixJQUFJLEdBQUcsRUFBRSxDQUFDO1FBa0J4RCxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsZUFBZSxDQUFXLENBQUM7UUFDcEUsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLGVBQWUsQ0FBVyxDQUFDO1FBQ3BFLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUU7WUFDckMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO1NBQzFDO0lBQ0gsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxlQUFlO1FBQ3BCLE9BQU8sUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUMsQ0FBQztJQUM1RCxDQUFDO0lBRUQ7O09BRUc7SUFDSSxRQUFRLENBQUMsSUFBZ0I7UUFDOUIsSUFBSSxJQUFJLEtBQUssd0JBQVUsQ0FBQyxJQUFJLEVBQUU7WUFDNUIsT0FBTyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDO1NBQ25GO1FBRUQsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRTtZQUN0QyxPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUM7U0FDbkY7UUFFRCxPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDN0IsQ0FBQztJQUVPLG9CQUFvQixDQUMxQixLQUF1QixFQUN2QixVQUF1QixFQUN2QixVQUF1QjtRQUV2QixVQUFVLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDbkIsVUFBVSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ25CLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQzNCLElBQUksS0FBSyxDQUFDLFVBQVUsRUFBRTtnQkFDcEIsVUFBVSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDNUI7WUFFRCxJQUFJLEtBQUssQ0FBQyxVQUFVLEVBQUU7Z0JBQ3BCLFVBQVUsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQzVCO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSyxLQUFLLENBQUMsWUFBWTtRQUN4QixNQUFNLFNBQVMsR0FBRyxNQUFNLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUNyRSx5REFBeUQ7UUFDekQsaUJBQWlCLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFFbkQsSUFBSSxDQUFDLG9CQUFvQixDQUFDLFNBQVMsRUFDakMsSUFBSSxDQUFDLHdCQUF3QixFQUM3QixJQUFJLENBQUMsd0JBQXdCLENBQUMsQ0FBQztRQUVqQyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFO1lBQ3RDLE1BQU0sU0FBUyxHQUFHLE1BQU0sSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBQ3JFLHFEQUFxRDtZQUNyRCxpQkFBaUIsQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztZQUNuRCxJQUFJLENBQUMsb0JBQW9CLENBQUMsU0FBUyxFQUNqQyxJQUFJLENBQUMsd0JBQXdCLEVBQzdCLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO1NBQ2xDO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0ssTUFBTSxDQUFDLFVBQVUsQ0FBQyxLQUF1QixFQUFFLGtCQUE0QjtRQUM3RSxNQUFNLG9CQUFvQixHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLFlBQVksQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBRWpGLEtBQUssTUFBTSxLQUFLLElBQUksa0JBQWtCLEVBQUU7WUFDdEMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDekMsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLHNCQUFzQixFQUFFLGNBQWMsS0FBSyxHQUFHO29CQUNuRSxzQ0FBc0MsS0FBSyxDQUFDLElBQUksR0FBRyxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQzlEO1NBQ0Y7SUFDSCxDQUFDO0lBRUQ7O09BRUc7SUFDSyxtQkFBbUIsQ0FDekIsS0FBYSxFQUNiLE1BQWdDLEVBQ2hDLHVCQUFpQyxFQUFFO1FBRW5DLE1BQU0sYUFBYSxHQUFHLENBQUMscUJBQXFCLEtBQUssSUFBSSxDQUFDLENBQUM7UUFFdkQsSUFBSSxNQUFNLEtBQUssU0FBUyxFQUFFO1lBQ3hCLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsRUFBRSxFQUFFO2dCQUM5QixJQUFJLG9CQUFvQixDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRTtvQkFDdEMsYUFBYSxDQUFDLElBQUksQ0FBQyxtQkFBbUIsS0FBSyxPQUFPLEdBQUcsSUFBSSxDQUFDLENBQUM7aUJBQzVEO1lBQ0gsQ0FBQyxDQUFDLENBQUM7U0FDSjtRQUVELE9BQU8sYUFBYSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSSxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQXlCO1FBQzVDLE1BQU0sV0FBVyxHQUFHLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDbkYsTUFBTSxhQUFhLEdBQUcsV0FBVyxDQUFDLElBQUksRUFBRSxDQUFDLE1BQU0sS0FBSyxDQUFDLENBQUM7UUFDdEQsTUFBTSxjQUFjLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEtBQUssQ0FBQyxDQUFDO1FBRWpELElBQUksYUFBYSxJQUFJLGNBQWMsRUFBRTtZQUNuQyxPQUFPO2dCQUNMLElBQUksRUFBRSxPQUFPLENBQUMsSUFBSTtnQkFDbEIsT0FBTyxFQUFFLEVBQUU7YUFDWixDQUFDO1NBQ0g7UUFFRCxNQUFNLEtBQUssR0FBRyxPQUFPLENBQUMsSUFBSSxLQUFLLHdCQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDO1FBQ3pGLE1BQU0sb0JBQW9CLEdBQUcsT0FBTyxDQUFDLElBQUksS0FBSyx3QkFBVSxDQUFDLElBQUk7WUFDM0QsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLHdCQUF3QixDQUFDO1lBQzNDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO1FBRTlDLE1BQU0sb0JBQW9CLEdBQUcsT0FBTyxDQUFDLElBQUksS0FBSyx3QkFBVSxDQUFDLElBQUk7WUFDM0QsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLHdCQUF3QixDQUFDO1lBQzNDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO1FBRTlDLE1BQU0sYUFBYSxHQUF5QixPQUFPLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQzlFLFdBQVcsRUFBRSxXQUFXO1lBQ3hCLFdBQVcsRUFBRSxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxNQUFNLEVBQUUsb0JBQW9CLENBQUM7WUFDbEYsWUFBWSxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsb0JBQW9CLEVBQUUsT0FBTyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFFLENBQUMsVUFBVTtpQkFDckYsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQzNCLElBQUksRUFBRSxPQUFPLENBQUMsSUFBSSxHQUFHLE9BQU8sQ0FBQyxJQUFJO1NBQ2xDLENBQUMsQ0FBQyxDQUFDO1FBRUosTUFBTSxhQUFhLEdBQUcsQ0FBQyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUMsYUFBYTthQUNuRCxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLGdCQUFnQixDQUFDLEtBQUssRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDN0QsTUFBTSxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3BCLE1BQU0sQ0FBQyxTQUFTLElBQUksQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDO1lBQ3RDLE1BQU0sQ0FBQyxJQUFJLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBVyxDQUFDLENBQUM7WUFDbkQsT0FBTyxNQUFNLENBQUM7UUFDaEIsQ0FBQyxFQUFFLEVBQUMsU0FBUyxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFDLENBQUMsQ0FBQztRQUUvQixNQUFNLElBQUksR0FBRyxhQUFhLENBQUMsSUFBSTthQUM1QixJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDO2FBQ3ZELE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUV0QyxPQUFPO1lBQ0wsSUFBSSxFQUFFLE9BQU8sQ0FBQyxJQUFJO1lBQ2xCLFNBQVMsRUFBRSxhQUFhLENBQUMsU0FBUztZQUNsQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDO1NBQzNCLENBQUM7SUFDSixDQUFDO0lBRUQ7O09BRUc7SUFDSSxLQUFLLENBQUMsWUFBWSxDQUN2QixRQUFrQixFQUNsQixNQUFnRDtRQUVoRCwwREFBMEQ7UUFDMUQsT0FBTyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7SUFDN0IsQ0FBQztJQUVNLFdBQVcsQ0FBQyxJQUFjLEVBQUUsT0FBNEI7UUFDN0QsT0FBTyxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDakMsQ0FBQztJQUVNLE9BQU87UUFDWixPQUFPLEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUNqQyxDQUFDO0lBRU0sWUFBWTtRQUNqQixPQUFPLEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUNqQyxDQUFDO0lBRU0sWUFBWSxDQUFDLEVBQVUsRUFBRSxJQUFjO1FBQzVDLE9BQU8sS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQ2pDLENBQUM7SUFFTSxlQUFlO1FBQ3BCLE9BQU8sS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQ2pDLENBQUM7SUFFTSxZQUFZLENBQUMsSUFBYyxFQUFFLEtBQXNCO1FBQ3hELE9BQU8sS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQ2pDLENBQUM7Q0FDRjtBQWhPRCw4Q0FnT0MifQ==