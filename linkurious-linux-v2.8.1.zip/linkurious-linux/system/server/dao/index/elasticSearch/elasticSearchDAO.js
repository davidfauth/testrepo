/**
 * LINKURIOUS CONFIDENTIAL
 * __________________
 *
 *  [2012] - [2014] Linkurious SAS
 *  All Rights Reserved.
 *
 *  Description: This file handles the link between the Linkurious API and
 *  the Elasticsearch one.
 *
 */
'use strict';
const _ = require('lodash');
const Promise = require('bluebird');
const elasticsearch = require('elasticsearch');
const LKE = require('../../../services/index');
const Log = LKE.getLogger(__filename);
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
const AbstractElasticDAO = require('../abstractElasticDAO');
/**
 * Embedded ElasticSearch Index DAO
 */
class ElasticSearchDAO extends AbstractElasticDAO {
    /**
     * ElasticSearch DAO constructor
     *
     * @param {object} options
     * @param {string} options.host server host
     * @param {String|Number} options.port server port
     * @param {string} options.indexName index name
     * @param {string} [options.mapping] custom mapping options (see ElasticSearch manual)
     * @param {boolean} [options.https] whether to use an HTTPS connection
     * @param {GraphDAO} graphDao The connected Graph DAO
     */
    constructor(options, graphDao) {
        super('elasticSearch', ['host', 'port'], [
            'url', 'host', 'port', 'mapping', 'forceReindex',
            'dynamicMapping', 'dateDetection', 'user', 'password', 'https', 'analyzer'
        ], options, {
            canCount: true,
            canIndexEdges: true,
            searchHitsCount: true,
            // this is the internally-indexed ES index
            external: false
        });
        if (Utils.hasValue(options.url)) {
            this.url = options.url;
        }
        else {
            let auth = '';
            if (Utils.hasValue(options.user) && Utils.hasValue(options.password)) {
                auth = options.user + ':' + options.password + '@';
            }
            this.url = `http${options.https ? 's' : ''}://${auth}${options.host}:${options.port}`;
        }
        this.fieldDataHeapLimit = null;
        // we do not let ElasticSearch print any logs.
        // to change the way ElasticSearch logs, see the documentation:
        // http://www.elasticsearch.org/guide/en/elasticsearch/client/javascript-api/current/logging.html
        function LogPlug() {
            //this.error = Log.error.bind(Log),
            this.error = () => { };
            this.warning = () => { };
            this.info = () => { };
            this.debug = () => { };
            this.trace = () => { };
            this.close = () => { };
        }
        this.esclient = new elasticsearch.Client({
            log: LogPlug,
            host: this.url,
            apiVersion: '1.2'
        });
        this._isES1 = true;
    }
    mustReindex() {
        return !this.indexIsConsistent;
    }
    /**
     * @param {LkNode|LkEdge} item
     * @param {number} item.version version increment
     * @param {string} type 'node' or 'edge'
     *
     * @returns {{id: string, type: string, data: object, version?: number}}
     * @private
     */
    _formatDataToIndex(item, type) {
        const result = {
            id: item.id,
            type: type === 'node' ? 'node' : 'edge',
            version: item.version,
            data: Utils.clone(item.data)
        };
        // fix unsafe properties.
        const keys = Object.keys(result.data);
        for (let i = 0; i < keys.length; ++i) {
            const originalKey = keys[i];
            if (this.META_FIELD_MAPPING.has(originalKey)) {
                // If the user property is also an elastic search meta field, replace the property
                // with a non conflicting equivalent.
                const value = result.data[originalKey];
                result.data[originalKey] = undefined;
                // Using the combining low line as a replacement
                // https://www.fileformat.info/info/unicode/char/0332/index.htm
                const fixedKey = this.META_FIELD_MAPPING.get(originalKey);
                result.data[fixedKey] = value;
            }
        }
        if (type === 'edge') {
            result.data[this.$edgeTypeField()] = item.type;
        }
        else if (item.categories) {
            result.data[this.$nodeCategoriesField()] = item.categories;
        }
        return result;
    }
    /**
     * @inheritdoc
     */
    connect() {
        const timeout = this.DEFAULT_PING_TIMEOUT * 1000;
        return new Promise((resolve, reject) => {
            /**
             * Connection-error handler
             *
             * @param {*} err
             * @returns {boolean} true if there was an error.
             */
            const handleError = err => {
                if (err) {
                    reject(Errors.technical('index_unreachable', 'Cannot connect to ElasticSearch: ' +
                        (err.message ? err.message : err)));
                    return true;
                }
                else {
                    return false;
                }
            };
            this.esclient.info({ timeout: timeout }, (err, info) => {
                if (err && err.message && err.message.includes &&
                    err.message.includes('contains unrecognized parameter: [timeout]')) {
                    // TODO #1306 refactor embedded ES driver
                    reject(Errors.business('not_supported', 'ElasticSearch 6.x is not supported by this driver. Please use ElasticSearch 2 driver.'));
                }
                if (handleError(err)) {
                    return;
                }
                const version = info.version.number;
                if (Utils.compareSemVer(version, '2.0.0') >= 0) {
                    reject(Errors.business('not_supported', 'ElasticSearch 2.x is not supported by this driver. Please use ElasticSearch 2 driver.'));
                }
                this.esclient.cluster.stats({ timeout: timeout }, (err, stats) => {
                    if (handleError(err)) {
                        return;
                    }
                    // default to 1GB is the value is zero or undefined (zero actually happens)
                    const maxHeap = stats.nodes.jvm.mem['heap_max_in_bytes'] || (1024 * 1000 * 1000);
                    this.esclient.cluster.getSettings({ timeout: timeout }, (err, settings) => {
                        // default values
                        let fieldDataLimit = '60%';
                        let fieldDataOverhead = 1.03;
                        // ignore error: this will fails (HTTP 401) in AWS because of security policies
                        if (!err) {
                            // see https://www.elastic.co/guide/en/elasticsearch/reference/1.5/index-modules-fielddata.html
                            fieldDataLimit = settings.persistent['indices.breaker.fielddata.limit'] || '60%';
                            fieldDataOverhead = settings.persistent['indices.breaker.fielddata.limit'] || 1.03;
                        }
                        const fieldDataLimitRatio = fieldDataLimit.replace('%', '') / 100;
                        // maximum number of bytes that can be used by field-data (e.g.: sorting)
                        this.fieldDataHeapLimit = Math.floor(maxHeap * fieldDataLimitRatio / fieldDataOverhead);
                        resolve(version);
                    });
                });
            });
        }).then(version => {
            // fill the size caches and return the version
            return Promise.join(version, this.$getSize('node'), this.$getSize('edge'), version => version);
        }).then(version => {
            return this.$indexExists().then(exists => {
                if (!exists) {
                    this.indexIsConsistent = false;
                }
                return version;
            });
        });
    }
    /**
     * @inheritdoc
     */
    $indexExists() {
        return this._indexAction('exists', { expandWildcards: 'closed' });
    }
    /**
     * @inheritdoc
     */
    $deleteIfExists() {
        return this.$indexExists().then(exists => {
            if (!exists) {
                return false;
            }
            return this._indexAction('delete');
        }).then(() => {
            return true;
        });
    }
    /**
     * @inheritdoc
     */
    checkUp() {
        return new Promise((resolve, reject) => {
            this.esclient.ping({ requestTimeout: this.DEFAULT_PING_TIMEOUT * 1000 }, err => {
                if (err) {
                    reject(Errors.technical('index_unreachable', 'Cannot connect to ElasticSearch: ' +
                        (err.message ? err.message : err)));
                }
                else {
                    resolve();
                }
            });
        });
    }
    /**
     * @inheritdoc
     */
    $getSize(type) {
        const indexName = this.$resolveESIndex(type);
        return new Promise((resolve, reject) => {
            this.esclient.count({
                index: indexName,
                ignoreUnavailable: true,
                type: type
            }, (err, result) => {
                if (err && err.message) {
                    if (err.message === 'IndexMissingException[[' + indexName + '] missing]') {
                        return resolve(0);
                    }
                    if (err.message === 'Service Unavailable') {
                        return resolve(0);
                    }
                }
                if (err) {
                    return this.onError(reject, err, undefined, type);
                }
                if (!result) {
                    return resolve(0);
                }
                resolve(result.count);
            });
        });
    }
    /**
     * @inheritdoc
     */
    $commit() {
        return new Promise((resolve, reject) => {
            this.esclient.indices.flush({ index: this.options.indexName }, err => {
                if (err) {
                    return this.onError(reject, err);
                }
                resolve();
            });
        });
    }
    /**
     * @inheritdoc
     */
    $createIndex() {
        this.indexIsConsistent = true;
        const defaultAnalyzer = this.getOption('analyzer', 'standard');
        // analysis config
        const analysisConfig = {
            analyzer: {
                // sort field (*.sort) analyser
                'lk_sort': {
                    type: 'custom',
                    tokenizer: 'keyword',
                    filter: [
                        //'icu_collation',
                        'lowercase',
                        'trim',
                        'truncateSort' // cut sort field at 15 chars
                    ]
                }
            },
            filter: {
                truncateSort: {
                    type: 'truncate',
                    length: this.SORT_FIELD_LENGTH
                }
            }
        };
        // field for sorting
        const sortField = { sort: {
                type: 'string', analyzer: 'lk_sort', stored: false, 'include_in_all': false //, index: 'no'
            } };
        // dynamic mapping safety (default: true). see issue #273
        const dynamicMapping = this.getOption('dynamicMapping', true);
        // dynamic template for sorting sub-field
        const fieldTemplate = {
            'lk_template': {
                match: '*',
                mapping: {
                    type: dynamicMapping ? '{dynamic_type}' : 'string',
                    analyzer: defaultAnalyzer,
                    fields: sortField
                }
            }
        };
        // set node/edge mapping
        let mapping = {};
        if (this.options.mapping) {
            mapping = this.options.mapping;
        }
        const nodeMapping = Utils.clone(mapping);
        nodeMapping[this.$nodeCategoriesField()] = { type: 'string', fields: sortField };
        const edgeMapping = Utils.clone(mapping);
        edgeMapping[this.$edgeTypeField()] = { type: 'string', fields: sortField };
        // date detection safety. (default: false). see issues #282
        const dateDetection = this.getOption('dateDetection', false);
        return this._indexAction('create', {
            body: {
                settings: {
                    // custom analyzer for efficient sorting. see:
                    // https://www.elastic.co/guide/en/elasticsearch/guide/master/sorting-collations.html
                    analysis: analysisConfig
                },
                mappings: {
                    '_default_': {
                        'dynamic_templates': [fieldTemplate]
                    },
                    node: {
                        'date_detection': dateDetection,
                        properties: nodeMapping,
                        dynamic: true // must always be true to allow dynamic templates
                    },
                    edge: {
                        'date_detection': dateDetection,
                        properties: edgeMapping,
                        dynamic: true // must always be true to allow dynamic templates
                    }
                }
            }
        }).catch(Errors.LkError, e => {
            if (e.message.indexOf('IndexAlreadyExistsException') > 0) {
                // ignore this error
                return;
            }
            return Promise.reject(e);
        });
    }
    /**
     * Call method `action` on ESClient.indices with options (`index:indexName` is added to options)
     *
     * @param {string} action action name
     * @param {object} [options]
     * @returns {Bluebird<*>}
     * @private
     */
    _indexAction(action, options) {
        if (!options) {
            options = {};
        }
        options.index = this.options.indexName;
        return new Promise((resolve, reject) => {
            // create new index
            this.esclient.indices[action](options, (err, result) => {
                if (err) {
                    return this.onError(reject, err, 'could not ' + action + ' index "' + options.index + '"');
                }
                resolve(result);
            });
        });
    }
    /**
     * @inheritdoc
     */
    $upsertEntry(type, entry) {
        const indexEntry = this._formatDataToIndex(entry, type);
        return new Promise((resolve, reject) => {
            this.esclient.update({
                // force an index refresh to make sur we read up-to-date values in the next read
                //   see:
                //   Boolean — Specify whether to perform the operation in realtime or search mode
                refresh: true,
                index: this.$resolveESIndex(indexEntry.type),
                type: this.$resolveESType(indexEntry.type),
                id: indexEntry.id,
                body: {
                    doc: indexEntry.data,
                    'doc_as_upsert': true
                }
            }, (err, result) => {
                if (err) {
                    if (err.message && err.message.match('DocumentMissingException')) {
                        const key = indexEntry.type === 'node' ? 'node_not_found' : 'edge_not_found';
                        return reject(Errors.business(key, JSON.stringify(err)));
                    }
                    return this.onError(reject, err, undefined, type);
                }
                resolve(result._version);
            });
        });
    }
    /**
     * Delete an entry
     *
     * @param {string} id the id fo the entry to delete
     * @param {string} type the type ('node' or 'edge') or the entry to delete
     * @returns {Promise}
     */
    $deleteEntry(id, type) {
        return new Promise((resolve, reject) => {
            this.esclient.delete({
                index: this.$resolveESIndex(type),
                type: this.$resolveESType(type),
                id: id
            }, err => {
                if (err) {
                    if (err.message && err.message.match('Not Found')) {
                        return resolve();
                    }
                    return this.onError(reject, err, undefined, type);
                }
                return resolve();
            });
        });
    }
    /**
     * @inheritdoc
     */
    $addEntries(type, entries) {
        // about batch size:
        // http://www.elasticsearch.org/guide/en/elasticsearch/guide/current/bulk.html#_how_big_is_too_big
        // 1000 / 5000 document
        const chunkSize = 1000;
        if (entries.length === 0) {
            return Promise.resolve();
        }
        const startIndexes = [];
        if (entries.length > chunkSize) {
            for (let i = 0; i < Math.ceil(entries.length / chunkSize); ++i) {
                startIndexes.push(i * chunkSize);
            }
        }
        else {
            startIndexes.push(0);
        }
        return Promise.each(startIndexes, startIndex => {
            const commands = [];
            for (let i = startIndex; i < entries.length && i < (startIndex + chunkSize); i++) {
                commands.push({ index: {
                        '_id': entries[i].id
                    } });
                commands.push(this._formatDataToIndex(entries[i], type).data);
            }
            return new Promise((resolve, reject) => {
                this.esclient.bulk({
                    index: this.$resolveESIndex(type),
                    type: this.$resolveESType(type),
                    body: commands
                }, (err, res) => {
                    if (err) {
                        return this.onError(reject, err, undefined, type);
                    }
                    if (res.errors && res.errors.length) {
                        return this.onError(reject, res.errors, undefined, type);
                    }
                    if (res.errors === true) {
                        let error = 'unknown error';
                        _.forEach(res.items, item => {
                            if (item.index && item.index.error) {
                                error = item.index.error;
                                return false;
                            }
                        });
                        return this.onError(reject, error, undefined, type);
                    }
                    resolve();
                });
            });
        });
    }
    /**
     * @inheritdoc
     */
    $searchPromise(itemType, query) {
        query.index = this.$resolveESIndex(itemType);
        query.type = this.$resolveESType(itemType);
        return new Promise((resolve, reject) => {
            this.esclient.search(query, (err, result) => {
                if (err) {
                    reject(err);
                }
                else {
                    resolve(result);
                }
            });
        });
    }
    /**
     * @inheritdoc
     */
    $resolveESType(itemType) {
        return itemType;
    }
    /**
     * @inheritdoc
     */
    $resolveESIndex(itemType) {
        return this.options.indexName;
    }
    /**
     * @param {function} reject Promise rejection callback
     * @param {*} esError
     * @param {string|undefined} [prefix]
     * @param {string} [itemType] "node" or "edge"
     */
    onError(reject, esError, prefix, itemType) {
        return reject(this.getLkError(esError, prefix, itemType));
    }
}
/**
 * @param {string} query
 * @param {string} field
 * @param {*} value
 * @returns {{query: {span_first: {end: number, match: {span_multi: {match: {}}}}}}}
 *
 * @private
 */
function spanFirstFilter(query, field, value) {
    value = value.toLowerCase();
    const f = { query: {
            'span_first': {
                end: 1,
                match: {
                    'span_multi': {
                        match: {}
                    }
                }
            }
        } };
    f.query['span_first'].match['span_multi'].match[query] = {};
    f.query['span_first'].match['span_multi'].match[query][field] = value;
    return f;
}
module.exports = ElasticSearchDAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZWxhc3RpY1NlYXJjaERBTy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NlcnZlci9kYW8vaW5kZXgvZWxhc3RpY1NlYXJjaC9lbGFzdGljU2VhcmNoREFPLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7O0dBVUc7QUFDSCxZQUFZLENBQUM7QUFFYixNQUFNLENBQUMsR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDNUIsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3BDLE1BQU0sYUFBYSxHQUFHLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQztBQUMvQyxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMseUJBQXlCLENBQUMsQ0FBQztBQUMvQyxNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3RDLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxrQkFBa0IsR0FBRyxPQUFPLENBQUMsdUJBQXVCLENBQUMsQ0FBQztBQUU1RDs7R0FFRztBQUNILE1BQU0sZ0JBQWlCLFNBQVEsa0JBQWtCO0lBQy9DOzs7Ozs7Ozs7O09BVUc7SUFDSCxZQUFZLE9BQU8sRUFBRSxRQUFRO1FBQzNCLEtBQUssQ0FDSCxlQUFlLEVBQ2YsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLEVBQ2hCO1lBQ0UsS0FBSyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsU0FBUyxFQUFFLGNBQWM7WUFDaEQsZ0JBQWdCLEVBQUUsZUFBZSxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUUsT0FBTyxFQUFFLFVBQVU7U0FDM0UsRUFDRCxPQUFPLEVBQ1A7WUFDRSxRQUFRLEVBQUUsSUFBSTtZQUNkLGFBQWEsRUFBRSxJQUFJO1lBQ25CLGVBQWUsRUFBRSxJQUFJO1lBRXJCLDBDQUEwQztZQUMxQyxRQUFRLEVBQUUsS0FBSztTQUNoQixDQUNGLENBQUM7UUFFRixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQy9CLElBQUksQ0FBQyxHQUFHLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQztTQUN4QjthQUFNO1lBQ0wsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO1lBQ2QsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBRTtnQkFDcEUsSUFBSSxHQUFHLE9BQU8sQ0FBQyxJQUFJLEdBQUcsR0FBRyxHQUFHLE9BQU8sQ0FBQyxRQUFRLEdBQUcsR0FBRyxDQUFDO2FBQ3BEO1lBQ0QsSUFBSSxDQUFDLEdBQUcsR0FBRyxPQUFPLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxNQUFNLElBQUksR0FBRyxPQUFPLENBQUMsSUFBSSxJQUFJLE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQztTQUN2RjtRQUVELElBQUksQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLENBQUM7UUFFL0IsOENBQThDO1FBQzlDLCtEQUErRDtRQUMvRCxpR0FBaUc7UUFDakcsU0FBUyxPQUFPO1lBQ2QsbUNBQW1DO1lBQ25DLElBQUksQ0FBQyxLQUFLLEdBQUcsR0FBRyxFQUFFLEdBQUUsQ0FBQyxDQUFDO1lBQ3RCLElBQUksQ0FBQyxPQUFPLEdBQUcsR0FBRyxFQUFFLEdBQUUsQ0FBQyxDQUFDO1lBQ3hCLElBQUksQ0FBQyxJQUFJLEdBQUcsR0FBRyxFQUFFLEdBQUUsQ0FBQyxDQUFDO1lBQ3JCLElBQUksQ0FBQyxLQUFLLEdBQUcsR0FBRyxFQUFFLEdBQUUsQ0FBQyxDQUFDO1lBQ3RCLElBQUksQ0FBQyxLQUFLLEdBQUcsR0FBRyxFQUFFLEdBQUUsQ0FBQyxDQUFDO1lBQ3RCLElBQUksQ0FBQyxLQUFLLEdBQUcsR0FBRyxFQUFFLEdBQUUsQ0FBQyxDQUFDO1FBQ3hCLENBQUM7UUFFRCxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksYUFBYSxDQUFDLE1BQU0sQ0FBQztZQUN2QyxHQUFHLEVBQUUsT0FBTztZQUNaLElBQUksRUFBRSxJQUFJLENBQUMsR0FBRztZQUNkLFVBQVUsRUFBRSxLQUFLO1NBQ2xCLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO0lBQ3JCLENBQUM7SUFFRCxXQUFXO1FBQ1QsT0FBTyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQztJQUNqQyxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILGtCQUFrQixDQUFDLElBQUksRUFBRSxJQUFJO1FBQzNCLE1BQU0sTUFBTSxHQUFHO1lBQ2IsRUFBRSxFQUFFLElBQUksQ0FBQyxFQUFFO1lBQ1gsSUFBSSxFQUFFLElBQUksS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTTtZQUN2QyxPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU87WUFDckIsSUFBSSxFQUFFLEtBQUssQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztTQUM3QixDQUFDO1FBRUYseUJBQXlCO1FBQ3pCLE1BQU0sSUFBSSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3RDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBRXBDLE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUU1QixJQUFJLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLEVBQUU7Z0JBQzVDLGtGQUFrRjtnQkFDbEYscUNBQXFDO2dCQUNyQyxNQUFNLEtBQUssR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUN2QyxNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLFNBQVMsQ0FBQztnQkFDckMsZ0RBQWdEO2dCQUNoRCwrREFBK0Q7Z0JBQy9ELE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBQzFELE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsS0FBSyxDQUFDO2FBQy9CO1NBQ0Y7UUFFRCxJQUFJLElBQUksS0FBSyxNQUFNLEVBQUU7WUFDbkIsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO1NBQ2hEO2FBQU0sSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFO1lBQzFCLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDO1NBQzVEO1FBRUQsT0FBTyxNQUFNLENBQUM7SUFDaEIsQ0FBQztJQUVEOztPQUVHO0lBQ0gsT0FBTztRQUNMLE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxvQkFBb0IsR0FBRyxJQUFJLENBQUM7UUFDakQsT0FBTyxJQUFJLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsRUFBRTtZQUVyQzs7Ozs7ZUFLRztZQUNILE1BQU0sV0FBVyxHQUFHLEdBQUcsQ0FBQyxFQUFFO2dCQUN4QixJQUFJLEdBQUcsRUFBRTtvQkFDUCxNQUFNLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsRUFBRSxtQ0FBbUM7d0JBQzlFLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQ2xDLENBQUMsQ0FBQztvQkFDSCxPQUFPLElBQUksQ0FBQztpQkFDYjtxQkFBTTtvQkFDTCxPQUFPLEtBQUssQ0FBQztpQkFDZDtZQUNILENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUMsT0FBTyxFQUFFLE9BQU8sRUFBQyxFQUFFLENBQUMsR0FBRyxFQUFFLElBQUksRUFBRSxFQUFFO2dCQUNuRCxJQUNFLEdBQUcsSUFBSSxHQUFHLENBQUMsT0FBTyxJQUFJLEdBQUcsQ0FBQyxPQUFPLENBQUMsUUFBUTtvQkFDMUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsNENBQTRDLENBQUMsRUFDbEU7b0JBQ0EseUNBQXlDO29CQUN6QyxNQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FDcEIsZUFBZSxFQUNmLHVGQUF1RixDQUN4RixDQUFDLENBQUM7aUJBQ0o7Z0JBRUQsSUFBSSxXQUFXLENBQUMsR0FBRyxDQUFDLEVBQUU7b0JBQUUsT0FBTztpQkFBRTtnQkFFakMsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUM7Z0JBQ3BDLElBQUksS0FBSyxDQUFDLGFBQWEsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFO29CQUM5QyxNQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FDcEIsZUFBZSxFQUNmLHVGQUF1RixDQUN4RixDQUFDLENBQUM7aUJBQ0o7Z0JBRUQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUMsT0FBTyxFQUFFLE9BQU8sRUFBQyxFQUFFLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRSxFQUFFO29CQUM3RCxJQUFJLFdBQVcsQ0FBQyxHQUFHLENBQUMsRUFBRTt3QkFBRSxPQUFPO3FCQUFFO29CQUVqQywyRUFBMkU7b0JBQzNFLE1BQU0sT0FBTyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLENBQUMsQ0FBQztvQkFFakYsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLEVBQUMsT0FBTyxFQUFFLE9BQU8sRUFBQyxFQUFFLENBQUMsR0FBRyxFQUFFLFFBQVEsRUFBRSxFQUFFO3dCQUN0RSxpQkFBaUI7d0JBQ2pCLElBQUksY0FBYyxHQUFHLEtBQUssQ0FBQzt3QkFDM0IsSUFBSSxpQkFBaUIsR0FBRyxJQUFJLENBQUM7d0JBRTdCLCtFQUErRTt3QkFDL0UsSUFBSSxDQUFDLEdBQUcsRUFBRTs0QkFDUiwrRkFBK0Y7NEJBQy9GLGNBQWMsR0FBRyxRQUFRLENBQUMsVUFBVSxDQUFDLGlDQUFpQyxDQUFDLElBQUksS0FBSyxDQUFDOzRCQUNqRixpQkFBaUIsR0FBRyxRQUFRLENBQUMsVUFBVSxDQUFDLGlDQUFpQyxDQUFDLElBQUksSUFBSSxDQUFDO3lCQUNwRjt3QkFFRCxNQUFNLG1CQUFtQixHQUFHLGNBQWMsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxHQUFHLEdBQUcsQ0FBQzt3QkFDbEUseUVBQXlFO3dCQUN6RSxJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsbUJBQW1CLEdBQUcsaUJBQWlCLENBQUMsQ0FBQzt3QkFFeEYsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO29CQUNuQixDQUFDLENBQUMsQ0FBQztnQkFDTCxDQUFDLENBQUMsQ0FBQztZQUNMLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQ2hCLDhDQUE4QztZQUM5QyxPQUFPLE9BQU8sQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEVBQ2hELElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEVBQUUsT0FBTyxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUMvQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDaEIsT0FBTyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO2dCQUN2QyxJQUFJLENBQUMsTUFBTSxFQUFFO29CQUNYLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxLQUFLLENBQUM7aUJBQ2hDO2dCQUVELE9BQU8sT0FBTyxDQUFDO1lBQ2pCLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxZQUFZO1FBQ1YsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsRUFBRSxFQUFDLGVBQWUsRUFBRSxRQUFRLEVBQUMsQ0FBQyxDQUFDO0lBQ2xFLENBQUM7SUFFRDs7T0FFRztJQUNILGVBQWU7UUFDYixPQUFPLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDdkMsSUFBSSxDQUFDLE1BQU0sRUFBRTtnQkFDWCxPQUFPLEtBQUssQ0FBQzthQUNkO1lBQ0QsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3JDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCxPQUFPLElBQUksQ0FBQztRQUNkLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0gsT0FBTztRQUNMLE9BQU8sSUFBSSxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDckMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBQyxjQUFjLEVBQUUsSUFBSSxDQUFDLG9CQUFvQixHQUFHLElBQUksRUFBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFO2dCQUMzRSxJQUFJLEdBQUcsRUFBRTtvQkFDUCxNQUFNLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsRUFBRSxtQ0FBbUM7d0JBQzlFLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQ2xDLENBQUMsQ0FBQztpQkFDSjtxQkFBTTtvQkFDTCxPQUFPLEVBQUUsQ0FBQztpQkFDWDtZQUNILENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxRQUFRLENBQUMsSUFBSTtRQUNYLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDN0MsT0FBTyxJQUFJLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsRUFBRTtZQUNyQyxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQztnQkFDbEIsS0FBSyxFQUFFLFNBQVM7Z0JBQ2hCLGlCQUFpQixFQUFFLElBQUk7Z0JBQ3ZCLElBQUksRUFBRSxJQUFJO2FBQ1gsRUFBRSxDQUFDLEdBQUcsRUFBRSxNQUFNLEVBQUUsRUFBRTtnQkFDakIsSUFBSSxHQUFHLElBQUksR0FBRyxDQUFDLE9BQU8sRUFBRTtvQkFDdEIsSUFBSSxHQUFHLENBQUMsT0FBTyxLQUFLLHlCQUF5QixHQUFHLFNBQVMsR0FBRyxZQUFZLEVBQUU7d0JBQ3hFLE9BQU8sT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO3FCQUNuQjtvQkFDRCxJQUFJLEdBQUcsQ0FBQyxPQUFPLEtBQUsscUJBQXFCLEVBQUU7d0JBQ3pDLE9BQU8sT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO3FCQUNuQjtpQkFDRjtnQkFDRCxJQUFJLEdBQUcsRUFBRTtvQkFDUCxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLEdBQUcsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7aUJBQ25EO2dCQUNELElBQUksQ0FBQyxNQUFNLEVBQUU7b0JBQ1gsT0FBTyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQ25CO2dCQUVELE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDeEIsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNILE9BQU87UUFDTCxPQUFPLElBQUksT0FBTyxDQUFDLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxFQUFFO1lBQ3JDLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFO2dCQUNqRSxJQUFJLEdBQUcsRUFBRTtvQkFDUCxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxDQUFDO2lCQUNsQztnQkFDRCxPQUFPLEVBQUUsQ0FBQztZQUNaLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxZQUFZO1FBQ1YsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQztRQUU5QixNQUFNLGVBQWUsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxVQUFVLENBQUMsQ0FBQztRQUUvRCxrQkFBa0I7UUFDbEIsTUFBTSxjQUFjLEdBQUc7WUFDckIsUUFBUSxFQUFFO2dCQUNSLCtCQUErQjtnQkFDL0IsU0FBUyxFQUFFO29CQUNULElBQUksRUFBRSxRQUFRO29CQUNkLFNBQVMsRUFBRSxTQUFTO29CQUNwQixNQUFNLEVBQUU7d0JBQ04sa0JBQWtCO3dCQUNsQixXQUFXO3dCQUNYLE1BQU07d0JBQ04sY0FBYyxDQUFDLDZCQUE2QjtxQkFDN0M7aUJBQ0Y7YUFDRjtZQUNELE1BQU0sRUFBRTtnQkFDTixZQUFZLEVBQUU7b0JBQ1osSUFBSSxFQUFFLFVBQVU7b0JBQ2hCLE1BQU0sRUFBRSxJQUFJLENBQUMsaUJBQWlCO2lCQUMvQjthQUNGO1NBQ0YsQ0FBQztRQUVGLG9CQUFvQjtRQUNwQixNQUFNLFNBQVMsR0FBRyxFQUFDLElBQUksRUFBRTtnQkFDdkIsSUFBSSxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsZ0JBQWdCLEVBQUUsS0FBSyxDQUFDLGVBQWU7YUFDNUYsRUFBQyxDQUFDO1FBRUgseURBQXlEO1FBQ3pELE1BQU0sY0FBYyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFFOUQseUNBQXlDO1FBQ3pDLE1BQU0sYUFBYSxHQUFHO1lBQ3BCLGFBQWEsRUFBRTtnQkFDYixLQUFLLEVBQUUsR0FBRztnQkFDVixPQUFPLEVBQUU7b0JBQ1AsSUFBSSxFQUFFLGNBQWMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLFFBQVE7b0JBQ2xELFFBQVEsRUFBRSxlQUFlO29CQUN6QixNQUFNLEVBQUUsU0FBUztpQkFDbEI7YUFDRjtTQUNGLENBQUM7UUFFRix3QkFBd0I7UUFDeEIsSUFBSSxPQUFPLEdBQUcsRUFBRSxDQUFDO1FBQ2pCLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUU7WUFDeEIsT0FBTyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDO1NBQ2hDO1FBQ0QsTUFBTSxXQUFXLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN6QyxXQUFXLENBQUMsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUMsR0FBRyxFQUFDLElBQUksRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLFNBQVMsRUFBQyxDQUFDO1FBQy9FLE1BQU0sV0FBVyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDekMsV0FBVyxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQyxHQUFHLEVBQUMsSUFBSSxFQUFFLFFBQVEsRUFBRSxNQUFNLEVBQUUsU0FBUyxFQUFDLENBQUM7UUFFekUsMkRBQTJEO1FBQzNELE1BQU0sYUFBYSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsZUFBZSxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRTdELE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLEVBQUU7WUFDakMsSUFBSSxFQUFFO2dCQUNKLFFBQVEsRUFBRTtvQkFDUiw4Q0FBOEM7b0JBQzlDLHFGQUFxRjtvQkFDckYsUUFBUSxFQUFFLGNBQWM7aUJBQ3pCO2dCQUNELFFBQVEsRUFBRTtvQkFDUixXQUFXLEVBQUU7d0JBQ1gsbUJBQW1CLEVBQUUsQ0FBQyxhQUFhLENBQUM7cUJBQ3JDO29CQUNELElBQUksRUFBRTt3QkFDSixnQkFBZ0IsRUFBRSxhQUFhO3dCQUMvQixVQUFVLEVBQUUsV0FBVzt3QkFDdkIsT0FBTyxFQUFFLElBQUksQ0FBQyxpREFBaUQ7cUJBQ2hFO29CQUNELElBQUksRUFBRTt3QkFDSixnQkFBZ0IsRUFBRSxhQUFhO3dCQUMvQixVQUFVLEVBQUUsV0FBVzt3QkFDdkIsT0FBTyxFQUFFLElBQUksQ0FBQyxpREFBaUQ7cUJBQ2hFO2lCQUNGO2FBQ0Y7U0FDRixDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLEVBQUU7WUFDM0IsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyw2QkFBNkIsQ0FBQyxHQUFHLENBQUMsRUFBRTtnQkFDeEQsb0JBQW9CO2dCQUNwQixPQUFPO2FBQ1I7WUFDRCxPQUFPLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDM0IsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILFlBQVksQ0FBQyxNQUFNLEVBQUUsT0FBTztRQUMxQixJQUFJLENBQUMsT0FBTyxFQUFFO1lBQUUsT0FBTyxHQUFHLEVBQUUsQ0FBQztTQUFFO1FBQy9CLE9BQU8sQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUM7UUFFdkMsT0FBTyxJQUFJLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsRUFBRTtZQUNyQyxtQkFBbUI7WUFDbkIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUMsR0FBRyxFQUFFLE1BQU0sRUFBRSxFQUFFO2dCQUNyRCxJQUFJLEdBQUcsRUFBRTtvQkFDUCxPQUFPLElBQUksQ0FBQyxPQUFPLENBQ2pCLE1BQU0sRUFBRSxHQUFHLEVBQUUsWUFBWSxHQUFHLE1BQU0sR0FBRyxVQUFVLEdBQUcsT0FBTyxDQUFDLEtBQUssR0FBRyxHQUFHLENBQ3RFLENBQUM7aUJBQ0g7Z0JBQ0QsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ2xCLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxZQUFZLENBQUMsSUFBSSxFQUFFLEtBQUs7UUFDdEIsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsQ0FBQztRQUN4RCxPQUFPLElBQUksT0FBTyxDQUFDLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxFQUFFO1lBQ3JDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDO2dCQUNuQixnRkFBZ0Y7Z0JBQ2hGLFNBQVM7Z0JBQ1Qsa0ZBQWtGO2dCQUNsRixPQUFPLEVBQUUsSUFBSTtnQkFDYixLQUFLLEVBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDO2dCQUM1QyxJQUFJLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDO2dCQUMxQyxFQUFFLEVBQUUsVUFBVSxDQUFDLEVBQUU7Z0JBQ2pCLElBQUksRUFBRTtvQkFDSixHQUFHLEVBQUUsVUFBVSxDQUFDLElBQUk7b0JBQ3BCLGVBQWUsRUFBRSxJQUFJO2lCQUN0QjthQUNGLEVBQUUsQ0FBQyxHQUFHLEVBQUUsTUFBTSxFQUFFLEVBQUU7Z0JBQ2pCLElBQUksR0FBRyxFQUFFO29CQUNQLElBQUksR0FBRyxDQUFDLE9BQU8sSUFBSSxHQUFHLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQywwQkFBMEIsQ0FBQyxFQUFFO3dCQUNoRSxNQUFNLEdBQUcsR0FBRyxVQUFVLENBQUMsSUFBSSxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDO3dCQUM3RSxPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDMUQ7b0JBQ0QsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxHQUFHLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO2lCQUNuRDtnQkFFRCxPQUFPLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQzNCLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsWUFBWSxDQUFDLEVBQUUsRUFBRSxJQUFJO1FBQ25CLE9BQU8sSUFBSSxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDckMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7Z0JBQ25CLEtBQUssRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQztnQkFDakMsSUFBSSxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDO2dCQUMvQixFQUFFLEVBQUUsRUFBRTthQUNQLEVBQUUsR0FBRyxDQUFDLEVBQUU7Z0JBQ1AsSUFBSSxHQUFHLEVBQUU7b0JBQ1AsSUFBSSxHQUFHLENBQUMsT0FBTyxJQUFJLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxFQUFFO3dCQUNqRCxPQUFPLE9BQU8sRUFBRSxDQUFDO3FCQUNsQjtvQkFDRCxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLEdBQUcsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7aUJBQ25EO2dCQUNELE9BQU8sT0FBTyxFQUFFLENBQUM7WUFDbkIsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNILFdBQVcsQ0FBQyxJQUFJLEVBQUUsT0FBTztRQUN2QixvQkFBb0I7UUFDcEIsa0dBQWtHO1FBQ2xHLHVCQUF1QjtRQUN2QixNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUM7UUFFdkIsSUFBSSxPQUFPLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUN4QixPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQztTQUMxQjtRQUVELE1BQU0sWUFBWSxHQUFHLEVBQUUsQ0FBQztRQUN4QixJQUFJLE9BQU8sQ0FBQyxNQUFNLEdBQUcsU0FBUyxFQUFFO1lBQzlCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEdBQUcsU0FBUyxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUU7Z0JBQzlELFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxDQUFDO2FBQ2xDO1NBQ0Y7YUFBTTtZQUNMLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDdEI7UUFFRCxPQUFPLE9BQU8sQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLFVBQVUsQ0FBQyxFQUFFO1lBQzdDLE1BQU0sUUFBUSxHQUFHLEVBQUUsQ0FBQztZQUVwQixLQUFLLElBQUksQ0FBQyxHQUFHLFVBQVUsRUFBRSxDQUFDLEdBQUcsT0FBTyxDQUFDLE1BQU0sSUFBSSxDQUFDLEdBQUcsQ0FBQyxVQUFVLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQ2hGLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBQyxLQUFLLEVBQUU7d0JBQ3BCLEtBQUssRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtxQkFDckIsRUFBQyxDQUFDLENBQUM7Z0JBQ0osUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQy9EO1lBRUQsT0FBTyxJQUFJLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsRUFBRTtnQkFDckMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUM7b0JBQ2pCLEtBQUssRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQztvQkFDakMsSUFBSSxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDO29CQUMvQixJQUFJLEVBQUUsUUFBUTtpQkFDZixFQUFFLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxFQUFFO29CQUNkLElBQUksR0FBRyxFQUFFO3dCQUNQLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsR0FBRyxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztxQkFDbkQ7b0JBRUQsSUFBSSxHQUFHLENBQUMsTUFBTSxJQUFJLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFO3dCQUNuQyxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO3FCQUMxRDtvQkFFRCxJQUFJLEdBQUcsQ0FBQyxNQUFNLEtBQUssSUFBSSxFQUFFO3dCQUN2QixJQUFJLEtBQUssR0FBRyxlQUFlLENBQUM7d0JBQzVCLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsRUFBRTs0QkFDMUIsSUFBSSxJQUFJLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxFQUFFO2dDQUNsQyxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUM7Z0NBQ3pCLE9BQU8sS0FBSyxDQUFDOzZCQUNkO3dCQUNILENBQUMsQ0FBQyxDQUFDO3dCQUNILE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztxQkFDckQ7b0JBRUQsT0FBTyxFQUFFLENBQUM7Z0JBQ1osQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0gsY0FBYyxDQUFDLFFBQVEsRUFBRSxLQUFLO1FBQzVCLEtBQUssQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUM3QyxLQUFLLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLENBQUM7UUFFM0MsT0FBTyxJQUFJLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsRUFBRTtZQUNyQyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxHQUFHLEVBQUUsTUFBTSxFQUFFLEVBQUU7Z0JBQzFDLElBQUksR0FBRyxFQUFFO29CQUNQLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDYjtxQkFBTTtvQkFDTCxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7aUJBQ2pCO1lBQ0gsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNILGNBQWMsQ0FBQyxRQUFRO1FBQ3JCLE9BQU8sUUFBUSxDQUFDO0lBQ2xCLENBQUM7SUFFRDs7T0FFRztJQUNILGVBQWUsQ0FBQyxRQUFRO1FBQ3RCLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUM7SUFDaEMsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLFFBQVE7UUFDdkMsT0FBTyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUM7SUFDNUQsQ0FBQztDQUNGO0FBRUQ7Ozs7Ozs7R0FPRztBQUNILFNBQVMsZUFBZSxDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsS0FBSztJQUMxQyxLQUFLLEdBQUcsS0FBSyxDQUFDLFdBQVcsRUFBRSxDQUFDO0lBQzVCLE1BQU0sQ0FBQyxHQUFHLEVBQUMsS0FBSyxFQUFFO1lBQ2hCLFlBQVksRUFBRTtnQkFDWixHQUFHLEVBQUUsQ0FBQztnQkFDTixLQUFLLEVBQUU7b0JBQ0wsWUFBWSxFQUFFO3dCQUNaLEtBQUssRUFBRSxFQUFFO3FCQUNWO2lCQUNGO2FBQ0Y7U0FDRixFQUFDLENBQUM7SUFDSCxDQUFDLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDO0lBQzVELENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxLQUFLLENBQUM7SUFDdEUsT0FBTyxDQUFDLENBQUM7QUFDWCxDQUFDO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxnQkFBZ0IsQ0FBQyJ9