/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-08-30.
 */
'use strict';
// libraries
const _ = require('lodash');
const Promise = require('bluebird');
const fs = require('fs');
// imports
const { IndexDAO } = require('../indexDAO');
const LKE = require('../../../services/index');
const LkRequest = require('../../../lib/LkRequest');
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
const Log = LKE.getLogger(__filename);
const DaoUtils = require('../../utils/daoUtils');
////////////////////////////////////////////////////////////////////////////////
const DOT_REPLACEMENT_CHAR = '\u00B7';
const UNDERSCORE_REPLACEMENT_CHAR = '\u0332';
const EARLIEST_SUPPORTED_VERSION = '2.0';
// size of the payload of a bulk operation
// https://www.elastic.co/guide/en/elasticsearch/guide/current/bulk.html#_how_big_is_too_big
const BULK_SIZE_IN_BYTE = 10000000; // 10MB
// name of the fields where categories and types are store in ES documents
const NODE_CATEGORIES_FIELD = 'lk_categories';
const EDGE_TYPE_FIELD = 'lk_type';
// RegExp to recognize an advanced query
const ADVANCED_QUERY_RE = /(\sAND\s|\s\|\|\s|\s&&\s|\sOR\s|>|<|\[|:|\s\+|\s-)/;
const ES_META_FIELDS = [
    '_index', '_uid', '_type',
    '_id', '_source', '_size',
    '_all', '_field_names', '_ignored',
    '_routing', '_meta'
];
const ES_META_FIELDS_MAPPING = new Map(ES_META_FIELDS
    .map(f => [f, f.replace(/[_]/, UNDERSCORE_REPLACEMENT_CHAR)]));
const ES_META_FIELDS_REVERSE_MAPPING = new Map(ES_META_FIELDS
    .map(f => [f.replace(/[_]/, UNDERSCORE_REPLACEMENT_CHAR), f]));
class ElasticSearch2DAO extends IndexDAO {
    /**
     * ElasticSearch2 DAO constructor
     *
     * Notes:
     * We are going to have two individual indices, one for nodes and one for edges (if edge
     * indexation is enabled).
     *
     * @param {object} options
     * @param {string} options.host                   ES host
     * @param {string|number} options.port            ES port
     * @param {boolean} [options.https]               Boolean that represents if we have to use HTTP over SSL
     * @param {string} [options.username]             ES username
     * @param {string} [options.password]             ES password
     * @param {boolean} [options.dynamicMapping=true] Boolean that represents if ES can automatically choose the type of a field
     * @param {string[]} [options.forceStringMapping] List of fields that are mapped to strings even with dynamicMapping=true
     * @param {boolean} [options.analyzer]            Analyzer used by ES to index string fields
     * @param {boolean} [options.skipEdgeIndexation]  Boolean that represents if we don't have to index the edges
     * @param {string} options.indexName              Prefix of the names of the indices
     * @param {string} options.caCert                 Absolute path to CA certificate
     * @param {GraphDAO} graphDao                     The connected Graph DAO
     */
    constructor(options, graphDao) {
        super('elasticSearch2', // name of the index
        ['host', 'port'], // required params
        ['host', 'port', 'https', 'user', 'password', 'dynamicMapping', 'forceStringMapping',
            'analyzer', 'forceReindex', 'caCert', 'simplifiedSearch'], // optional params
        options, {
            canCount: true,
            canIndexEdges: true,
            searchHitsCount: true,
            external: false // this is an internal index
        });
        this._simplifiedSearch = options.simplifiedSearch;
        this._nodeIndexName = options.indexName + '_nodes';
        this._edgeIndexName = options.indexName + '_edges';
        // dynamicMapping set to true means that if the schema is consistent the fields are mapped
        // automatically to a type (integer, float, boolean, date, string). This break if the
        // schema is not consistent and it must be disabled. If disabled all fields are still mapped
        // automatically to the type string.
        this._dynamicMapping = this.getOption('dynamicMapping', false); // by default it's false
        this._forceStringMapping = this.getOption('forceStringMapping', []);
        this._analyzer = this.getOption('analyzer', 'lk_analyzer');
        const protocol = options.https ? 'https' : 'http';
        this._url = protocol + '://' + options.host + ':' + options.port;
        this._request = new LkRequest({
            baseUrl: this._url,
            auth: options.user ? {
                user: options.user,
                password: options.password
            } : undefined,
            json: true,
            pool: { maxSockets: 5 },
            gzip: true,
            agentOptions: {
                ca: options.caCert ? fs.readFileSync(options.caCert) : undefined
            }
        }, {
            errorPrefix: 'ElasticSearch2'
        });
        this.indexIsConsistent = true;
    }
    /**
     * Return true if the source must be re-indexed to repair data consistency.
     *
     * @returns {boolean}
     */
    mustReindex() {
        return !this.indexIsConsistent;
    }
    get META_FIELD_MAPPING() {
        return ES_META_FIELDS_MAPPING;
    }
    get META_FIELD_REVERSE_MAPPING() {
        return ES_META_FIELDS_REVERSE_MAPPING;
    }
    ////////////////////////////////////////////////////////////////////////////////
    /**
     * Return a dynamic template that match `match` and index the matched field as a string and
     * as a not_analyzed. The not_analyzed version of the field is called `${field}.raw`.
     *
     * @param {string} match
     * @returns {object}
     * @private
     */
    _templateForNotAnalyzedFields(match) {
        const templateName = match + '_has_raw';
        const result = {};
        result[templateName] = {
            match: match,
            mapping: this.elasticSearch6 ? {
                type: 'text',
                analyzer: this._analyzer,
                fields: {
                    raw: {
                        type: 'keyword'
                    }
                }
            } : {
                type: 'string',
                analyzer: this._analyzer,
                fields: {
                    raw: {
                        type: 'string',
                        index: 'not_analyzed'
                    }
                }
            }
        };
        return result;
    }
    /**
     * It generate the options for the index (indices) based on the `dynamicMapping` and `analyzer`
     * options.
     *
     * @param {string} type 'node' or 'edge'
     * @returns {{mappings: {_default_: {dynamic_templates: *[]}}}}
     * @private
     */
    _newIndexOptions(type) {
        // we add a new analyzer 'lk_analyzer' that will replace `.` with ` ` but, for all the rest,
        // it will behave like the standard analyzer
        // https://www.elastic.co/guide/en/elasticsearch/reference/current/analysis-standard-analyzer.html
        // https://www.elastic.co/guide/en/elasticsearch/guide/current/standard-analyzer.html
        const lkAnalizerIndexSettings = {
            // number_of_shards: 1, // ALWAYS use this line while analyzing the scores
            index: {
                analysis: {
                    'char_filter': {
                        'dot_to_whitespace': {
                            type: 'pattern_replace',
                            pattern: '(\\D)\\.(\\D)',
                            replacement: '$1 $2'
                        },
                        'underscore_to_whitespace': {
                            type: 'pattern_replace',
                            pattern: '_',
                            replacement: ' '
                        }
                    },
                    filter: {
                        'asciifolding_original': {
                            type: 'asciifolding',
                            'preserve_original': true
                        }
                    },
                    analyzer: {
                        'lk_analyzer': {
                            tokenizer: 'standard',
                            'char_filter': [
                                'dot_to_whitespace',
                                'underscore_to_whitespace'
                            ],
                            filter: ['asciifolding_original', 'lowercase', 'stop']
                        }
                    }
                }
            }
        };
        const mappingToString = {
            type: this.elasticSearch6 ? 'text' : 'string',
            analyzer: this._analyzer
        };
        const dynamicTemplates = [];
        if (type === 'node') {
            dynamicTemplates.push(this._templateForNotAnalyzedFields(NODE_CATEGORIES_FIELD));
        }
        else { // 'edge'
            dynamicTemplates.push(this._templateForNotAnalyzedFields(EDGE_TYPE_FIELD));
        }
        if (!this._dynamicMapping) {
            // everything is a string
            dynamicTemplates.push({
                'all_fields_are_strings': {
                    match: '*',
                    mapping: mappingToString
                }
            });
        }
        else {
            // everything in forceStringMapping is forced to a string
            _.forEach(this._forceStringMapping, field => {
                const template = {};
                template[field + '_is_a_string'] = {
                    match: field,
                    mapping: mappingToString
                };
                dynamicTemplates.push(template);
            });
            // we change the analyzer to any other field that was mapped by dynamic mapping as a string
            dynamicTemplates.push({
                'all_strings_use_this_analyzer': {
                    match: '*',
                    'match_mapping_type': 'string',
                    mapping: mappingToString
                }
            });
        }
        const indexOptions = {
            'settings': lkAnalizerIndexSettings,
            'mappings': {
                '_default_': {
                    'dynamic_templates': dynamicTemplates
                }
            }
        };
        // change _all mapping to use our analyzer
        indexOptions.mappings[type] = {
            '_all': {
                type: this.elasticSearch6 ? 'text' : 'string',
                analyzer: this._analyzer
            }
        };
        return indexOptions;
    }
    ////////////////////////////////////////////////////////////////////////////////
    /**
     * Return the index url for nodes and edges.
     *
     * @param {string} type
     * @returns {string}
     * @private
     */
    _indexUrl(type) {
        if (type === 'node') {
            return this._nodeIndexName;
        }
        else {
            return this._edgeIndexName;
        }
    }
    /**
     * Return the type url for nodes and edges.
     *
     * @param {string} type
     * @returns {string}
     * @private
     */
    _typeUrl(type) {
        return this._indexUrl(type) + '/' + type;
    }
    /**
     * Return the id url for a given type and id.
     *
     * @param {string} type
     * @param {*} id
     * @returns {string}
     * @private
     */
    _idUrl(type, id) {
        return this._typeUrl(type) + '/' + encodeURIComponent(id);
    }
    /**
     * Return the array of indices used by this DAO.
     * Usually used when we have to do the same operation (create, delete, flush) on both indices.
     *
     * @returns {string[]}
     * @private
     */
    _indices() {
        return [this._nodeIndexName, this._edgeIndexName];
    }
    /**
     * @param {string} type 'node' or 'edge'
     * @param {boolean} [raw] true to obtain the not_analyzed field
     * @returns {string}
     * @private
     */
    _fieldCategoriesOrTypes(type, raw) {
        let result;
        if (type === 'node') {
            result = NODE_CATEGORIES_FIELD;
        }
        else {
            result = EDGE_TYPE_FIELD;
        }
        if (raw) {
            return result + '.raw';
        }
        return result;
    }
    ////////////////////////////////////////////////////////////////////////////////
    /**
     * A wrapper for bulk operations to ES.
     * This function will automatically split the bulk request in many requests as long as the payload
     * of each is close to `BULK_SIZE_IN_BYTE`.
     *
     * The format of `operations` follows the pattern used by ElasticSearch:
     *   https://www.elastic.co/guide/en/elasticsearch/reference/current/docs-bulk.html
     *
     * The main difference here is that entries are not delimited by the newline character
     * (as requested by ES) but they are in an array.
     *
     * The possible actions are 'index', 'create', 'delete' and 'update'.
     * 'index', 'create' and 'update' actions require a 'source' field.
     * 'delete' cannot have a 'source' field.
     *
     * @example
     * _bulk([
     *   {
     *     action: {index: {_index: 'test', _type: 'type1', _id: 1}},
     *     source: {field1: 'value1'}
     *   },
     *   {
     *     action: {delete: {_index: 'test', _type: 'type1', _id: 2}}
     *   }
     * ])
     * It indexes a document {field1: value1} in '/test/type1/1' and it deletes '/test/type1/2'.
     *
     * @param {object[]} operations
     * @param {string} [defaultIndex] Instead of specifying the index for each bulk operation use this default index
     * @param {string} [defaultType]  Instead of specifying the type for each bulk operation use this default type (`defaultIndex` is required)
     * @returns {Bluebird<object[]>} a response for each action (exactly as returned by ES)
     * @private
     */
    _bulk(operations, defaultIndex, defaultType) {
        return Promise.resolve().then(() => {
            if (operations.length === 0) {
                return [];
            }
            // 1) split the operations in payloads of BULK_SIZE_IN_BYTE
            const payloads = [];
            let body = '';
            _.forEach(operations, operation => {
                body += global.JSON.stringify(operation.action) + '\n';
                if (Utils.hasValue(operation.source)) {
                    // an 'index', 'create' and 'update' action will use 2 lines
                    body += global.JSON.stringify(operation.source) + '\n';
                }
                if (body.length >= BULK_SIZE_IN_BYTE) {
                    payloads.push(body);
                    body = '';
                }
            });
            if (body.length > 0) {
                payloads.push(body);
            }
            let url = '';
            if (defaultIndex) {
                url += '/' + defaultIndex;
                if (defaultType) {
                    url += '/' + defaultType;
                }
            }
            url += '/_bulk';
            // 2) make as many request as payloads we have
            return Promise.map(payloads, payload => {
                const options = { json: false, body: payload };
                if (this.elasticSearch6) {
                    options.headers = { 'Content-type': 'application/x-ndjson' };
                }
                return this._request.post(url, options, [200]).then(bulkR => {
                    // our body is not a valid json, but the answer is, so we decode it
                    return global.JSON.parse(bulkR.body);
                });
            }, { concurrency: 1 }).then(multipleBulkR => {
                // we join the responses in a unique response
                return {
                    errors: _.reduce(_.map(multipleBulkR, 'errors'), (clause, error) => {
                        return clause || error;
                    }, false),
                    items: [].concat.apply([], _.map(multipleBulkR, 'items'))
                };
            });
        });
    }
    ////////////////////////////////////////////////////////////////////////////////
    /**
     * Transform a node in another document following these rules:
     * - result = node.data
     * - result[NODE_CATEGORIES_FIELD] = node.categories
     *
     * Transform an edge in another document following these rules:
     * - result = edge.data
     * - result[EDGE_TYPE_FIELD] = edge.type
     *
     * @param {LkNode|LkEdge} lkObject
     * @param {string} type
     * @returns {object}
     * @private
     */
    _transformLkObjectToESDocument(lkObject, type) {
        const result = Utils.clone(lkObject.data);
        if (type === 'node') {
            result[NODE_CATEGORIES_FIELD] = lkObject.categories;
        }
        else { // edge
            result[EDGE_TYPE_FIELD] = lkObject.type;
        }
        // fix unsafe properties.
        const keys = Object.keys(result);
        for (let i = 0; i < keys.length; ++i) {
            const originalKey = keys[i];
            if (this.META_FIELD_MAPPING.has(originalKey)) {
                // If the user property is also an elastic search meta field, replace the property
                // with a non conflicting equivalent.
                const value = result[originalKey];
                result[originalKey] = undefined;
                // Using the combining low line as a replacement
                // https://www.fileformat.info/info/unicode/char/0332/index.htm
                const fixedKey = this.META_FIELD_MAPPING.get(originalKey);
                result[fixedKey] = value;
                continue;
            }
            if (originalKey.includes('.')) {
                // Replace the dot in the key by something ES2 accepts:
                // http://www.fileformat.info/info/unicode/char/b7/index.htm
                const value = result[originalKey];
                result[originalKey] = undefined;
                const fixedKey = originalKey.replace(/[.]/g, DOT_REPLACEMENT_CHAR);
                result[fixedKey] = value;
            }
        }
        return result;
    }
    ////////////////////////////////////////////////////////////////////////////////
    /**
     * ES2 wants the fuzziness expressed in number of characters of distance.
     * The editDistance is 0 if fuzziness === 0
     * AUTO if 0 < fuzziness <= 0.6
     * 2 if fuzziness > 0.6
     *
     * Definition of AUTO:
     * https://www.elastic.co/guide/en/elasticsearch/reference/1.4/common-options.html#_string_fields
     *
     * @param {number} length    length of the searchString
     * @param {number} fuzziness
     * @returns {*}
     * @private
     */
    _editDistanceFromFuzziness(length, fuzziness) {
        if (fuzziness === 0) {
            return 0;
        }
        else if (fuzziness <= 0.6) {
            return 'AUTO';
        }
        else {
            return 2;
        }
    }
    /**
     * Convert the artificial fields for categories and types.
     *
     * @param {string} propertyName
     * @returns {string}
     */
    _mapIndexField(propertyName) {
        if (propertyName.indexOf(this._fieldCategoriesOrTypes('node')) >= 0) {
            return '[categories]';
        }
        else if (propertyName.indexOf(this._fieldCategoriesOrTypes('edge')) >= 0) {
            return '[type]';
        }
        else if (propertyName.includes(DOT_REPLACEMENT_CHAR)) {
            return propertyName.replace(new RegExp(DOT_REPLACEMENT_CHAR, 'g'), '.');
        }
        else if (this.META_FIELD_REVERSE_MAPPING.has(propertyName)) {
            return this.META_FIELD_REVERSE_MAPPING.get(propertyName);
        }
        else {
            return propertyName;
        }
    }
    /**
     * @param {ISearchDAOParams} params
     * @param {boolean}          advanced
     */
    _buildQuery(params, advanced) {
        const editDistance = this._editDistanceFromFuzziness(params.q.length, params.fuzziness);
        const filteredLabelsByPropertyLength = params.schema.labels.filter(label => params.schema.get(label).properties.length > 0);
        // avoid to return all documents and force to return none if there is no label to search on
        if (!filteredLabelsByPropertyLength.length) {
            return undefined;
        }
        return {
            query: {
                bool: {
                    should: filteredLabelsByPropertyLength.map((label => {
                        let shouldMatch;
                        if (advanced) {
                            shouldMatch = [{
                                    'query_string': {
                                        query: params.q,
                                        lenient: true,
                                        fields: params.schema.get(label).properties.map(p => p.propertyKey),
                                        analyzer: this._analyzer
                                    }
                                }];
                        }
                        else if (this._simplifiedSearch) {
                            shouldMatch = [{
                                    'multi_match': {
                                        query: params.q,
                                        lenient: true,
                                        fields: params.schema.get(label).properties.map(p => p.propertyKey),
                                        fuzziness: editDistance
                                    }
                                }];
                        }
                        else {
                            shouldMatch = [{
                                    'multi_match': {
                                        query: params.q,
                                        lenient: true,
                                        fields: params.schema.get(label).properties.map(p => p.propertyKey),
                                        fuzziness: editDistance
                                    }
                                }, {
                                    'multi_match': {
                                        query: params.q,
                                        lenient: true,
                                        type: 'phrase_prefix',
                                        fields: params.schema.get(label).properties.map(p => p.propertyKey)
                                    }
                                }];
                        }
                        return {
                            bool: {
                                should: shouldMatch,
                                must: {
                                    term: { [params.type === 'node' ? 'lk_categories.raw' : 'lk_type.raw']: label }
                                },
                                'minimum_should_match': 1
                            }
                        };
                    })),
                    must: _.map(params.filter, propertyFilter => ({
                        match: {
                            [propertyFilter[0]]: { query: propertyFilter[1], operator: 'and' }
                        }
                    })),
                    'minimum_should_match': 1
                }
            },
            size: params.size,
            from: params.from,
            _source: false
        };
    }
    ////////////////////////////////////////////////////////////////////////////////
    /**
     * @inheritdoc
     */
    connect() {
        return this._request.get('', {}, [200]).catch(err => {
            Log.warn('Cannot connect to ElasticSearch due to: ' + err);
            return Errors.technical('index_unreachable', 'Cannot connect to ElasticSearch.', true);
        }).then(connectR => {
            const version = connectR.body.version.number;
            if (Utils.compareSemVer(version, EARLIEST_SUPPORTED_VERSION) < 0) {
                return Errors.business('not_supported', `ElasticSearch ${version} is not supported by ElasticSearch2.`, true);
            }
            if (Utils.compareSemVer(version, '6.0.0') >= 0) {
                // TODO #987 use a custom driver for es6
                this.elasticSearch6 = true;
            }
            return this.$indexExists().then(exists => {
                if (!exists) {
                    this.indexIsConsistent = false;
                }
                return version;
            });
        });
    }
    /**
     * @inheritdoc
     */
    checkUp() {
        return this._request.get('', {}, [200]).catch(() => {
            return Errors.technical('index_unreachable', 'Cannot reach ElasticSearch.', true);
        });
    }
    /**
     * @inheritdoc
     */
    $indexExists() {
        return this._request.get('/_cat/indices', { qs: { format: 'json' } }, [200]).then(indicesR => {
            const indicesInES = _.map(indicesR.body, 'index');
            // we check if it contains the node index and, if we indexed also the edges, the edge index
            return _.includes(indicesInES, this._nodeIndexName) &&
                _.includes(indicesInES, this._edgeIndexName);
        });
    }
    /**
     * Delete ES index with name `indexName`. Return 'true' if deletion was successful.
     *
     * @param {string} indexName
     * @returns {Bluebird<boolean>}
     * @private
     */
    _deleteIfExistsIndexWithName(indexName) {
        return this._request.delete(indexName, {}, [200, 404])
            .then(deleteR => deleteR.statusCode === 200);
    }
    /**
     * @inheritdoc
     */
    $deleteIfExists() {
        return Promise.map(this._indices(), index => {
            return this._deleteIfExistsIndexWithName(index);
        }).then(deleteIndicesR => {
            // It should never happen that one index exists and the other doesn't except if one of them
            // was manually deleted in ES.
            if (deleteIndicesR[0] ? !deleteIndicesR[1] : deleteIndicesR[1]) { // XOR operation
                Log.warn('The was an inconsistency in ES where one of the index existed ' +
                    'and the other did not.');
            }
            return deleteIndicesR[0] || deleteIndicesR[1];
        });
    }
    /**
     * @inheritdoc
     */
    $createIndex() {
        this.indexIsConsistent = true;
        return Promise.map(['node', 'edge'], type => {
            return this._request.put(this._indexUrl(type), { body: this._newIndexOptions(type) }, [200]).return(this._indexUrl(type));
        });
    }
    /**
     * Look at $addEntries.
     *
     * @param {string} type
     * @param {LkNode[]|LkEdge[]} entries
     * @returns {Bluebird<{index: {_version: number}}[]>}
     * @private
     */
    _addEntries(type, entries) {
        const index = type === 'node' ? this._nodeIndexName : this._edgeIndexName;
        return this._bulk(_.map(entries, entry => ({
            action: { index: { _id: entry.id } },
            source: this._transformLkObjectToESDocument(entry, type)
        })), index, type).then(bulkR => {
            if (bulkR.errors) {
                // If there was an error, we search for it so we can throw nicely
                const faultyIndexations = _.filter(bulkR.items, item => [200, 201].indexOf(item.index.status) < 0);
                if (faultyIndexations.length >= 0) {
                    // if the error type is mapper_parsing_exception or illegal_argument_exception we throw an ad-hoc error
                    const error = faultyIndexations[0].index.error;
                    if (error.type === 'mapper_parsing_exception' ||
                        error.type === 'illegal_argument_exception') {
                        // we parse the property name on which occurred the mapping exception
                        // the reason has the following format 'failed to parse [propertyName]' or 'mapper [propertyName] of ...'
                        const propertyName = /\[(.*?)]/g.exec(error.reason)[1];
                        // propertyName is an heuristic. There might be other reasons for 'mapper_parsing_exception' or 'illegal_argument_exception' errors
                        // we build the message
                        let errorMsg = 'There was an error while updating Elasticsearch.';
                        if (Utils.hasValue(propertyName)) {
                            if (error.reason.includes('cannot contain ')) {
                                const char = error.reason.split('cannot contain ')[1];
                                errorMsg = 'The property "' + propertyName + '" has an illegal character: ' + char;
                            }
                            else {
                                errorMsg = 'The property "' + propertyName + '" had an unexpected type.';
                                if (Utils.hasValue(error['caused_by']) &&
                                    error['caused_by'].type === 'number_format_exception') {
                                    errorMsg += ' (expecting a number)';
                                }
                            }
                        }
                        return Errors.business('index_mapping_error', errorMsg, true);
                    }
                    else {
                        // otherwise return a generic error
                        return Errors.technical('critical', 'ElasticSearch wasn\'t able to index the record. ' +
                            global.JSON.stringify(faultyIndexations[0].index.error), true);
                    }
                }
            }
            return bulkR.items;
        });
    }
    /**
     * @inheritdoc
     */
    $addEntries(type, entries) {
        return this._addEntries(type, entries).return();
    }
    /**
     * @inheritdoc
     */
    $commit() {
        return this._request.post(this._indices().join(',') + '/_flush', {}, [200]).catch(e => {
            return Errors.technical('critical', 'Couldn\'t flush indices: ' + e.message, true);
        });
    }
    /**
     * @inheritdoc
     */
    $getSize(type) {
        return this._request.get(this._idUrl(type, '_count'), {}, [200, 404, 403]).then(countR => {
            if (countR.statusCode === 404) {
                return 0;
            }
            if (countR.statusCode === 403) {
                // we shouldn't fail if we don't have the rights, it's not critical
                Log.warn(`Failed to read the ${type} count from the index, ` +
                    'please check elasticsearch permissions');
                this.features.canCount = false;
                return 0;
            }
            return countR.body.count;
        });
    }
    /**
     * @inheritdoc
     */
    $upsertEntry(type, entry) {
        return this._addEntries(type, [entry]).then(addEntriesR => addEntriesR[0].index._version);
    }
    /**
     * @inheritdoc
     */
    $deleteEntry(id, type) {
        return this._request.delete(this._idUrl(type, id), {}, [200, 404]);
    }
    /**
     * @inheritdoc
     */
    $search(options) {
        return Promise.resolve().then(() => {
            // if options.q looks alike an advanced query
            if (options.q.match(ADVANCED_QUERY_RE)) {
                const query = this._buildQuery(options, true);
                if (Utils.noValue(query)) {
                    return undefined;
                }
                return this._request.get(this._idUrl(options.type, '_search'), { body: query }, [200]).catch(() => undefined);
                // catch advanced query errors to fallback to simple query
            }
            else {
                // directly fallback to simple query
                return undefined;
            }
        }).then(advancedQueryR => {
            if (advancedQueryR) {
                return advancedQueryR;
            }
            const query = this._buildQuery(options, false);
            if (Utils.noValue(query)) {
                return undefined;
            }
            return this._request.get(this._idUrl(options.type, '_search'), { body: query }, [200]);
        }).then(queryR => {
            if (queryR) {
                return {
                    type: options.type,
                    totalHits: queryR.body.hits.total,
                    results: queryR.body.hits.hits.map(o => o._id)
                };
            }
            return {
                type: options.type, totalHits: 0, results: []
            };
        });
    }
}
module.exports = ElasticSearch2DAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZWxhc3RpY1NlYXJjaDJEQU8uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2luZGV4L2VsYXN0aWNTZWFyY2gyL2VsYXN0aWNTZWFyY2gyREFPLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsWUFBWTtBQUNaLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM1QixNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDcEMsTUFBTSxFQUFFLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBRXpCLFVBQVU7QUFDVixNQUFNLEVBQUUsUUFBUSxFQUFFLEdBQUcsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDO0FBQzVDLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO0FBQy9DLE1BQU0sU0FBUyxHQUFHLE9BQU8sQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO0FBQ3BELE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxHQUFHLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUV0QyxNQUFNLFFBQVEsR0FBRyxPQUFPLENBQUMsc0JBQXNCLENBQUMsQ0FBQztBQUVqRCxnRkFBZ0Y7QUFFaEYsTUFBTSxvQkFBb0IsR0FBRyxRQUFRLENBQUM7QUFDdEMsTUFBTSwyQkFBMkIsR0FBRyxRQUFRLENBQUM7QUFDN0MsTUFBTSwwQkFBMEIsR0FBRyxLQUFLLENBQUM7QUFFekMsMENBQTBDO0FBQzFDLDRGQUE0RjtBQUM1RixNQUFNLGlCQUFpQixHQUFHLFFBQVEsQ0FBQyxDQUFDLE9BQU87QUFFM0MsMEVBQTBFO0FBQzFFLE1BQU0scUJBQXFCLEdBQUcsZUFBZSxDQUFDO0FBQzlDLE1BQU0sZUFBZSxHQUFHLFNBQVMsQ0FBQztBQUVsQyx3Q0FBd0M7QUFDeEMsTUFBTSxpQkFBaUIsR0FBRyxvREFBb0QsQ0FBQztBQUUvRSxNQUFNLGNBQWMsR0FBRztJQUNyQixRQUFRLEVBQUUsTUFBTSxFQUFFLE9BQU87SUFDekIsS0FBSyxFQUFFLFNBQVMsRUFBRSxPQUFPO0lBQ3pCLE1BQU0sRUFBRSxjQUFjLEVBQUUsVUFBVTtJQUNsQyxVQUFVLEVBQUUsT0FBTztDQUNwQixDQUFDO0FBRUYsTUFBTSxzQkFBc0IsR0FBRyxJQUFJLEdBQUcsQ0FBQyxjQUFjO0tBQ2xELEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLDJCQUEyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFFakUsTUFBTSw4QkFBOEIsR0FBRyxJQUFJLEdBQUcsQ0FBQyxjQUFjO0tBQzFELEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsMkJBQTJCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFFakUsTUFBTSxpQkFBa0IsU0FBUSxRQUFRO0lBRXRDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQW9CRztJQUNILFlBQVksT0FBTyxFQUFFLFFBQVE7UUFDM0IsS0FBSyxDQUNILGdCQUFnQixFQUFFLG9CQUFvQjtRQUN0QyxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsRUFBRSxrQkFBa0I7UUFDcEMsQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFFLGdCQUFnQixFQUFFLG9CQUFvQjtZQUNsRixVQUFVLEVBQUUsY0FBYyxFQUFFLFFBQVEsRUFBRSxrQkFBa0IsQ0FBQyxFQUFFLGtCQUFrQjtRQUMvRSxPQUFPLEVBQ1A7WUFDRSxRQUFRLEVBQUUsSUFBSTtZQUNkLGFBQWEsRUFBRSxJQUFJO1lBQ25CLGVBQWUsRUFBRSxJQUFJO1lBRXJCLFFBQVEsRUFBRSxLQUFLLENBQUMsNEJBQTRCO1NBQzdDLENBQ0YsQ0FBQztRQUVGLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxPQUFPLENBQUMsZ0JBQWdCLENBQUM7UUFFbEQsSUFBSSxDQUFDLGNBQWMsR0FBRyxPQUFPLENBQUMsU0FBUyxHQUFHLFFBQVEsQ0FBQztRQUNuRCxJQUFJLENBQUMsY0FBYyxHQUFHLE9BQU8sQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDO1FBRW5ELDBGQUEwRjtRQUMxRixxRkFBcUY7UUFDckYsNEZBQTRGO1FBQzVGLG9DQUFvQztRQUNwQyxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyx3QkFBd0I7UUFDeEYsSUFBSSxDQUFDLG1CQUFtQixHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsb0JBQW9CLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFFcEUsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxhQUFhLENBQUMsQ0FBQztRQUUzRCxNQUFNLFFBQVEsR0FBRyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztRQUVsRCxJQUFJLENBQUMsSUFBSSxHQUFHLFFBQVEsR0FBRyxLQUFLLEdBQUcsT0FBTyxDQUFDLElBQUksR0FBRyxHQUFHLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQztRQUVqRSxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksU0FBUyxDQUFDO1lBQzVCLE9BQU8sRUFBRSxJQUFJLENBQUMsSUFBSTtZQUNsQixJQUFJLEVBQUUsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBQ25CLElBQUksRUFBRSxPQUFPLENBQUMsSUFBSTtnQkFDbEIsUUFBUSxFQUFFLE9BQU8sQ0FBQyxRQUFRO2FBQzNCLENBQUMsQ0FBQyxDQUFDLFNBQVM7WUFDYixJQUFJLEVBQUUsSUFBSTtZQUNWLElBQUksRUFBRSxFQUFDLFVBQVUsRUFBRSxDQUFDLEVBQUM7WUFDckIsSUFBSSxFQUFFLElBQUk7WUFDVixZQUFZLEVBQUU7Z0JBQ1osRUFBRSxFQUFFLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTO2FBQ2pFO1NBQ0YsRUFBRTtZQUNELFdBQVcsRUFBRSxnQkFBZ0I7U0FDOUIsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQztJQUNoQyxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILFdBQVc7UUFDVCxPQUFPLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDO0lBQ2pDLENBQUM7SUFFRCxJQUFJLGtCQUFrQjtRQUNwQixPQUFPLHNCQUFzQixDQUFDO0lBQ2hDLENBQUM7SUFFRCxJQUFJLDBCQUEwQjtRQUM1QixPQUFPLDhCQUE4QixDQUFDO0lBQ3hDLENBQUM7SUFFRCxnRkFBZ0Y7SUFFaEY7Ozs7Ozs7T0FPRztJQUNILDZCQUE2QixDQUFDLEtBQUs7UUFDakMsTUFBTSxZQUFZLEdBQUcsS0FBSyxHQUFHLFVBQVUsQ0FBQztRQUN4QyxNQUFNLE1BQU0sR0FBRyxFQUFFLENBQUM7UUFDbEIsTUFBTSxDQUFDLFlBQVksQ0FBQyxHQUFHO1lBQ3JCLEtBQUssRUFBRSxLQUFLO1lBQ1osT0FBTyxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDO2dCQUM3QixJQUFJLEVBQUUsTUFBTTtnQkFDWixRQUFRLEVBQUUsSUFBSSxDQUFDLFNBQVM7Z0JBQ3hCLE1BQU0sRUFBRTtvQkFDTixHQUFHLEVBQUU7d0JBQ0gsSUFBSSxFQUFFLFNBQVM7cUJBQ2hCO2lCQUNGO2FBQ0YsQ0FBQyxDQUFDLENBQUM7Z0JBQ0YsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsUUFBUSxFQUFFLElBQUksQ0FBQyxTQUFTO2dCQUN4QixNQUFNLEVBQUU7b0JBQ04sR0FBRyxFQUFFO3dCQUNILElBQUksRUFBRSxRQUFRO3dCQUNkLEtBQUssRUFBRSxjQUFjO3FCQUN0QjtpQkFDRjthQUNGO1NBQ0YsQ0FBQztRQUNGLE9BQU8sTUFBTSxDQUFDO0lBQ2hCLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsZ0JBQWdCLENBQUMsSUFBSTtRQUNuQiw0RkFBNEY7UUFDNUYsNENBQTRDO1FBQzVDLGtHQUFrRztRQUNsRyxxRkFBcUY7UUFDckYsTUFBTSx1QkFBdUIsR0FBRztZQUM5QiwwRUFBMEU7WUFDMUUsS0FBSyxFQUFFO2dCQUNMLFFBQVEsRUFBRTtvQkFDUixhQUFhLEVBQUU7d0JBQ2IsbUJBQW1CLEVBQUU7NEJBQ25CLElBQUksRUFBRSxpQkFBaUI7NEJBQ3ZCLE9BQU8sRUFBRSxlQUFlOzRCQUN4QixXQUFXLEVBQUUsT0FBTzt5QkFDckI7d0JBQ0QsMEJBQTBCLEVBQUU7NEJBQzFCLElBQUksRUFBRSxpQkFBaUI7NEJBQ3ZCLE9BQU8sRUFBRSxHQUFHOzRCQUNaLFdBQVcsRUFBRSxHQUFHO3lCQUNqQjtxQkFDRjtvQkFDRCxNQUFNLEVBQUU7d0JBQ04sdUJBQXVCLEVBQUU7NEJBQ3ZCLElBQUksRUFBRSxjQUFjOzRCQUNwQixtQkFBbUIsRUFBRSxJQUFJO3lCQUMxQjtxQkFDRjtvQkFDRCxRQUFRLEVBQUU7d0JBQ1IsYUFBYSxFQUFFOzRCQUNiLFNBQVMsRUFBRSxVQUFVOzRCQUNyQixhQUFhLEVBQUU7Z0NBQ2IsbUJBQW1CO2dDQUNuQiwwQkFBMEI7NkJBQzNCOzRCQUNELE1BQU0sRUFBRSxDQUFDLHVCQUF1QixFQUFFLFdBQVcsRUFBRSxNQUFNLENBQUM7eUJBQ3ZEO3FCQUNGO2lCQUNGO2FBQ0Y7U0FDRixDQUFDO1FBRUYsTUFBTSxlQUFlLEdBQUc7WUFDdEIsSUFBSSxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsUUFBUTtZQUM3QyxRQUFRLEVBQUUsSUFBSSxDQUFDLFNBQVM7U0FDekIsQ0FBQztRQUVGLE1BQU0sZ0JBQWdCLEdBQUcsRUFBRSxDQUFDO1FBRTVCLElBQUksSUFBSSxLQUFLLE1BQU0sRUFBRTtZQUNuQixnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLDZCQUE2QixDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQztTQUNsRjthQUFNLEVBQUUsU0FBUztZQUNoQixnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLDZCQUE2QixDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUM7U0FDNUU7UUFFRCxJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRTtZQUN6Qix5QkFBeUI7WUFDekIsZ0JBQWdCLENBQUMsSUFBSSxDQUNuQjtnQkFDRSx3QkFBd0IsRUFBRTtvQkFDeEIsS0FBSyxFQUFFLEdBQUc7b0JBQ1YsT0FBTyxFQUFFLGVBQWU7aUJBQ3pCO2FBQ0YsQ0FDRixDQUFDO1NBQ0g7YUFBTTtZQUNMLHlEQUF5RDtZQUN6RCxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxLQUFLLENBQUMsRUFBRTtnQkFDMUMsTUFBTSxRQUFRLEdBQUcsRUFBRSxDQUFDO2dCQUNwQixRQUFRLENBQUMsS0FBSyxHQUFHLGNBQWMsQ0FBQyxHQUFHO29CQUNqQyxLQUFLLEVBQUUsS0FBSztvQkFDWixPQUFPLEVBQUUsZUFBZTtpQkFDekIsQ0FBQztnQkFFRixnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDbEMsQ0FBQyxDQUFDLENBQUM7WUFFSCwyRkFBMkY7WUFDM0YsZ0JBQWdCLENBQUMsSUFBSSxDQUNuQjtnQkFDRSwrQkFBK0IsRUFBRTtvQkFDL0IsS0FBSyxFQUFFLEdBQUc7b0JBQ1Ysb0JBQW9CLEVBQUUsUUFBUTtvQkFDOUIsT0FBTyxFQUFFLGVBQWU7aUJBQ3pCO2FBQ0YsQ0FDRixDQUFDO1NBQ0g7UUFFRCxNQUFNLFlBQVksR0FBRztZQUNuQixVQUFVLEVBQUUsdUJBQXVCO1lBQ25DLFVBQVUsRUFBRTtnQkFDVixXQUFXLEVBQUU7b0JBQ1gsbUJBQW1CLEVBQUUsZ0JBQWdCO2lCQUN0QzthQUNGO1NBQ0YsQ0FBQztRQUVGLDBDQUEwQztRQUMxQyxZQUFZLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHO1lBQzVCLE1BQU0sRUFBRTtnQkFDTixJQUFJLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxRQUFRO2dCQUM3QyxRQUFRLEVBQUUsSUFBSSxDQUFDLFNBQVM7YUFDekI7U0FDRixDQUFDO1FBRUYsT0FBTyxZQUFZLENBQUM7SUFDdEIsQ0FBQztJQUVELGdGQUFnRjtJQUVoRjs7Ozs7O09BTUc7SUFDSCxTQUFTLENBQUMsSUFBSTtRQUNaLElBQUksSUFBSSxLQUFLLE1BQU0sRUFBRTtZQUNuQixPQUFPLElBQUksQ0FBQyxjQUFjLENBQUM7U0FDNUI7YUFBTTtZQUNMLE9BQU8sSUFBSSxDQUFDLGNBQWMsQ0FBQztTQUM1QjtJQUNILENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxRQUFRLENBQUMsSUFBSTtRQUNYLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDO0lBQzNDLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsTUFBTSxDQUFDLElBQUksRUFBRSxFQUFFO1FBQ2IsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLEdBQUcsR0FBRyxrQkFBa0IsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUM1RCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsUUFBUTtRQUNOLE9BQU8sQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUNwRCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCx1QkFBdUIsQ0FBQyxJQUFJLEVBQUUsR0FBRztRQUMvQixJQUFJLE1BQU0sQ0FBQztRQUNYLElBQUksSUFBSSxLQUFLLE1BQU0sRUFBRTtZQUNuQixNQUFNLEdBQUcscUJBQXFCLENBQUM7U0FDaEM7YUFBTTtZQUNMLE1BQU0sR0FBRyxlQUFlLENBQUM7U0FDMUI7UUFFRCxJQUFJLEdBQUcsRUFBRTtZQUNQLE9BQU8sTUFBTSxHQUFHLE1BQU0sQ0FBQztTQUN4QjtRQUVELE9BQU8sTUFBTSxDQUFDO0lBQ2hCLENBQUM7SUFFRCxnRkFBZ0Y7SUFFaEY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O09BZ0NHO0lBQ0gsS0FBSyxDQUFDLFVBQVUsRUFBRSxZQUFZLEVBQUUsV0FBVztRQUN6QyxPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ2pDLElBQUksVUFBVSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7Z0JBQzNCLE9BQU8sRUFBRSxDQUFDO2FBQ1g7WUFFRCwyREFBMkQ7WUFDM0QsTUFBTSxRQUFRLEdBQUcsRUFBRSxDQUFDO1lBRXBCLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQztZQUNkLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFLFNBQVMsQ0FBQyxFQUFFO2dCQUNoQyxJQUFJLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQztnQkFDdkQsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsRUFBRTtvQkFDcEMsNERBQTREO29CQUM1RCxJQUFJLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQztpQkFDeEQ7Z0JBRUQsSUFBSSxJQUFJLENBQUMsTUFBTSxJQUFJLGlCQUFpQixFQUFFO29CQUNwQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUNwQixJQUFJLEdBQUcsRUFBRSxDQUFDO2lCQUNYO1lBQ0gsQ0FBQyxDQUFDLENBQUM7WUFFSCxJQUFJLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO2dCQUNuQixRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3JCO1lBRUQsSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDO1lBQ2IsSUFBSSxZQUFZLEVBQUU7Z0JBQ2hCLEdBQUcsSUFBSSxHQUFHLEdBQUcsWUFBWSxDQUFDO2dCQUMxQixJQUFJLFdBQVcsRUFBRTtvQkFDZixHQUFHLElBQUksR0FBRyxHQUFHLFdBQVcsQ0FBQztpQkFDMUI7YUFDRjtZQUNELEdBQUcsSUFBSSxRQUFRLENBQUM7WUFFaEIsOENBQThDO1lBQzlDLE9BQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUUsT0FBTyxDQUFDLEVBQUU7Z0JBRXJDLE1BQU0sT0FBTyxHQUFHLEVBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFDLENBQUM7Z0JBQzdDLElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTtvQkFDdkIsT0FBTyxDQUFDLE9BQU8sR0FBRyxFQUFFLGNBQWMsRUFBRSxzQkFBc0IsRUFBRSxDQUFDO2lCQUM5RDtnQkFFRCxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxPQUFPLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtvQkFDMUQsbUVBQW1FO29CQUNuRSxPQUFPLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDdkMsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDLEVBQUUsRUFBQyxXQUFXLEVBQUUsQ0FBQyxFQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUU7Z0JBQ3hDLDZDQUE2QztnQkFDN0MsT0FBTztvQkFDTCxNQUFNLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsRUFBRTt3QkFDakUsT0FBTyxNQUFNLElBQUksS0FBSyxDQUFDO29CQUN6QixDQUFDLEVBQUUsS0FBSyxDQUFDO29CQUNULEtBQUssRUFBRSxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsT0FBTyxDQUFDLENBQUM7aUJBQzFELENBQUM7WUFDSixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVELGdGQUFnRjtJQUVoRjs7Ozs7Ozs7Ozs7OztPQWFHO0lBQ0gsOEJBQThCLENBQUMsUUFBUSxFQUFFLElBQUk7UUFDM0MsTUFBTSxNQUFNLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDMUMsSUFBSSxJQUFJLEtBQUssTUFBTSxFQUFFO1lBQ25CLE1BQU0sQ0FBQyxxQkFBcUIsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxVQUFVLENBQUM7U0FDckQ7YUFBTSxFQUFFLE9BQU87WUFDZCxNQUFNLENBQUMsZUFBZSxDQUFDLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQztTQUN6QztRQUVELHlCQUF5QjtRQUN6QixNQUFNLElBQUksR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ2pDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBRXBDLE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUU1QixJQUFJLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLEVBQUU7Z0JBQzVDLGtGQUFrRjtnQkFDbEYscUNBQXFDO2dCQUNyQyxNQUFNLEtBQUssR0FBRyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBQ2xDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxTQUFTLENBQUM7Z0JBQ2hDLGdEQUFnRDtnQkFDaEQsK0RBQStEO2dCQUMvRCxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUMxRCxNQUFNLENBQUMsUUFBUSxDQUFDLEdBQUcsS0FBSyxDQUFDO2dCQUN6QixTQUFTO2FBQ1Y7WUFFRCxJQUFJLFdBQVcsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQzdCLHVEQUF1RDtnQkFDdkQsNERBQTREO2dCQUM1RCxNQUFNLEtBQUssR0FBRyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBQ2xDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxTQUFTLENBQUM7Z0JBQ2hDLE1BQU0sUUFBUSxHQUFHLFdBQVcsQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLG9CQUFvQixDQUFDLENBQUM7Z0JBQ25FLE1BQU0sQ0FBQyxRQUFRLENBQUMsR0FBRyxLQUFLLENBQUM7YUFDMUI7U0FDRjtRQUVELE9BQU8sTUFBTSxDQUFDO0lBQ2hCLENBQUM7SUFFRCxnRkFBZ0Y7SUFFaEY7Ozs7Ozs7Ozs7Ozs7T0FhRztJQUNILDBCQUEwQixDQUFDLE1BQU0sRUFBRSxTQUFTO1FBQzFDLElBQUksU0FBUyxLQUFLLENBQUMsRUFBRTtZQUNuQixPQUFPLENBQUMsQ0FBQztTQUNWO2FBQU0sSUFBSSxTQUFTLElBQUksR0FBRyxFQUFFO1lBQzNCLE9BQU8sTUFBTSxDQUFDO1NBQ2Y7YUFBTTtZQUNMLE9BQU8sQ0FBQyxDQUFDO1NBQ1Y7SUFDSCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxjQUFjLENBQUMsWUFBWTtRQUN6QixJQUFJLFlBQVksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ25FLE9BQU8sY0FBYyxDQUFDO1NBQ3ZCO2FBQU0sSUFBSSxZQUFZLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUMxRSxPQUFPLFFBQVEsQ0FBQztTQUNqQjthQUFNLElBQUksWUFBWSxDQUFDLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxFQUFFO1lBQ3RELE9BQU8sWUFBWSxDQUFDLE9BQU8sQ0FBQyxJQUFJLE1BQU0sQ0FBQyxvQkFBb0IsRUFBRSxHQUFHLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztTQUN6RTthQUFNLElBQUksSUFBSSxDQUFDLDBCQUEwQixDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsRUFBRTtZQUM1RCxPQUFPLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLENBQUM7U0FDMUQ7YUFBTTtZQUNMLE9BQU8sWUFBWSxDQUFDO1NBQ3JCO0lBQ0gsQ0FBQztJQUVEOzs7T0FHRztJQUNILFdBQVcsQ0FBQyxNQUFNLEVBQUUsUUFBUTtRQUMxQixNQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsMEJBQTBCLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBRXhGLE1BQU0sOEJBQThCLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUNoRSxLQUFLLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUN4RCxDQUFDO1FBRUYsMkZBQTJGO1FBQzNGLElBQUksQ0FBQyw4QkFBOEIsQ0FBQyxNQUFNLEVBQUU7WUFDMUMsT0FBTyxTQUFTLENBQUM7U0FDbEI7UUFFRCxPQUFPO1lBQ0wsS0FBSyxFQUFFO2dCQUNMLElBQUksRUFBRTtvQkFDSixNQUFNLEVBQUUsOEJBQThCLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUU7d0JBQ2xELElBQUksV0FBVyxDQUFDO3dCQUVoQixJQUFJLFFBQVEsRUFBRTs0QkFDWixXQUFXLEdBQUcsQ0FBQztvQ0FDYixjQUFjLEVBQUU7d0NBQ2QsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDO3dDQUNmLE9BQU8sRUFBRSxJQUFJO3dDQUNiLE1BQU0sRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQzt3Q0FDbkUsUUFBUSxFQUFFLElBQUksQ0FBQyxTQUFTO3FDQUN6QjtpQ0FDRixDQUFDLENBQUM7eUJBQ0o7NkJBQU0sSUFBSSxJQUFJLENBQUMsaUJBQWlCLEVBQUU7NEJBQ2pDLFdBQVcsR0FBRyxDQUFDO29DQUNiLGFBQWEsRUFBRTt3Q0FDYixLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUM7d0NBQ2YsT0FBTyxFQUFFLElBQUk7d0NBQ2IsTUFBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDO3dDQUNuRSxTQUFTLEVBQUUsWUFBWTtxQ0FDeEI7aUNBQ0YsQ0FBQyxDQUFDO3lCQUNKOzZCQUFNOzRCQUNMLFdBQVcsR0FBRyxDQUFDO29DQUNiLGFBQWEsRUFBRTt3Q0FDYixLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUM7d0NBQ2YsT0FBTyxFQUFFLElBQUk7d0NBQ2IsTUFBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDO3dDQUNuRSxTQUFTLEVBQUUsWUFBWTtxQ0FDeEI7aUNBQUUsRUFBRTtvQ0FDTCxhQUFhLEVBQUU7d0NBQ2IsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDO3dDQUNmLE9BQU8sRUFBRSxJQUFJO3dDQUNiLElBQUksRUFBRSxlQUFlO3dDQUNyQixNQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUM7cUNBQ3BFO2lDQUNGLENBQUMsQ0FBQzt5QkFDSjt3QkFFRCxPQUFPOzRCQUNMLElBQUksRUFBRTtnQ0FDSixNQUFNLEVBQUUsV0FBVztnQ0FDbkIsSUFBSSxFQUFFO29DQUNKLElBQUksRUFBRSxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsRUFBRSxLQUFLLEVBQUM7aUNBQUU7Z0NBQ2xGLHNCQUFzQixFQUFFLENBQUM7NkJBQzFCO3lCQUNGLENBQUM7b0JBQ0osQ0FBQyxDQUFDLENBQUM7b0JBQ0gsSUFBSSxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxjQUFjLENBQUMsRUFBRSxDQUFDLENBQUM7d0JBQzVDLEtBQUssRUFBRTs0QkFDTCxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUMsS0FBSyxFQUFFLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRSxRQUFRLEVBQUUsS0FBSyxFQUFDO3lCQUNqRTtxQkFDRixDQUFDLENBQUM7b0JBQ0gsc0JBQXNCLEVBQUUsQ0FBQztpQkFDMUI7YUFDRjtZQUNELElBQUksRUFBRSxNQUFNLENBQUMsSUFBSTtZQUNqQixJQUFJLEVBQUUsTUFBTSxDQUFDLElBQUk7WUFDakIsT0FBTyxFQUFFLEtBQUs7U0FDZixDQUFDO0lBQ0osQ0FBQztJQUVELGdGQUFnRjtJQUVoRjs7T0FFRztJQUNILE9BQU87UUFDTCxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUNsRCxHQUFHLENBQUMsSUFBSSxDQUFDLDBDQUEwQyxHQUFHLEdBQUcsQ0FBQyxDQUFDO1lBQzNELE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsRUFBRSxrQ0FBa0MsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUN6RixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDakIsTUFBTSxPQUFPLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDO1lBRTdDLElBQUksS0FBSyxDQUFDLGFBQWEsQ0FBQyxPQUFPLEVBQUUsMEJBQTBCLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQ2hFLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxlQUFlLEVBQ3BDLGlCQUFpQixPQUFPLHNDQUFzQyxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQ3pFO1lBRUQsSUFBSSxLQUFLLENBQUMsYUFBYSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQzlDLHdDQUF3QztnQkFDeEMsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUM7YUFDNUI7WUFFRCxPQUFPLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7Z0JBQ3ZDLElBQUksQ0FBQyxNQUFNLEVBQUU7b0JBQ1gsSUFBSSxDQUFDLGlCQUFpQixHQUFHLEtBQUssQ0FBQztpQkFDaEM7Z0JBRUQsT0FBTyxPQUFPLENBQUM7WUFDakIsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNILE9BQU87UUFDTCxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUU7WUFDakQsT0FBTyxNQUFNLENBQUMsU0FBUyxDQUFDLG1CQUFtQixFQUFFLDZCQUE2QixFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3BGLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0gsWUFBWTtRQUNWLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsZUFBZSxFQUFFLEVBQUMsRUFBRSxFQUFFLEVBQUMsTUFBTSxFQUFFLE1BQU0sRUFBQyxFQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUN2RixNQUFNLFdBQVcsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFDbEQsMkZBQTJGO1lBQzNGLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQztnQkFDakQsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1FBQ2pELENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILDRCQUE0QixDQUFDLFNBQVM7UUFDcEMsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsRUFBRSxFQUFFLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO2FBQ25ELElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxVQUFVLEtBQUssR0FBRyxDQUFDLENBQUM7SUFDakQsQ0FBQztJQUVEOztPQUVHO0lBQ0gsZUFBZTtRQUNiLE9BQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLEVBQUUsS0FBSyxDQUFDLEVBQUU7WUFDMUMsT0FBTyxJQUFJLENBQUMsNEJBQTRCLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDbEQsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFO1lBQ3ZCLDJGQUEyRjtZQUMzRiw4QkFBOEI7WUFDOUIsSUFBSSxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxnQkFBZ0I7Z0JBQ2hGLEdBQUcsQ0FBQyxJQUFJLENBQUMsZ0VBQWdFO29CQUN2RSx3QkFBd0IsQ0FBQyxDQUFDO2FBQzdCO1lBRUQsT0FBTyxjQUFjLENBQUMsQ0FBQyxDQUFDLElBQUksY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ2hELENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0gsWUFBWTtRQUNWLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUM7UUFFOUIsT0FBTyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxFQUFFLElBQUksQ0FBQyxFQUFFO1lBQzFDLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsRUFDM0MsRUFBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxFQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDN0UsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILFdBQVcsQ0FBQyxJQUFJLEVBQUUsT0FBTztRQUN2QixNQUFNLEtBQUssR0FBRyxJQUFJLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDO1FBRTFFLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDekMsTUFBTSxFQUFFLEVBQUMsS0FBSyxFQUFFLEVBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxFQUFFLEVBQUMsRUFBQztZQUNoQyxNQUFNLEVBQUUsSUFBSSxDQUFDLDhCQUE4QixDQUFDLEtBQUssRUFBRSxJQUFJLENBQUM7U0FDekQsQ0FBQyxDQUFDLEVBQUUsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUM3QixJQUFJLEtBQUssQ0FBQyxNQUFNLEVBQUU7Z0JBQ2hCLGlFQUFpRTtnQkFDakUsTUFBTSxpQkFBaUIsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQzVDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0JBQ3JELElBQUksaUJBQWlCLENBQUMsTUFBTSxJQUFJLENBQUMsRUFBRTtvQkFDakMsdUdBQXVHO29CQUN2RyxNQUFNLEtBQUssR0FBRyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDO29CQUUvQyxJQUFJLEtBQUssQ0FBQyxJQUFJLEtBQUssMEJBQTBCO3dCQUMzQyxLQUFLLENBQUMsSUFBSSxLQUFLLDRCQUE0QixFQUFFO3dCQUM3QyxxRUFBcUU7d0JBQ3JFLHlHQUF5Rzt3QkFDekcsTUFBTSxZQUFZLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ3ZELG1JQUFtSTt3QkFFbkksdUJBQXVCO3dCQUN2QixJQUFJLFFBQVEsR0FBRyxrREFBa0QsQ0FBQzt3QkFFbEUsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxFQUFFOzRCQUNoQyxJQUFJLEtBQUssQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLGlCQUFpQixDQUFDLEVBQUU7Z0NBQzVDLE1BQU0sSUFBSSxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQ3RELFFBQVEsR0FBRyxnQkFBZ0IsR0FBRyxZQUFZLEdBQUcsOEJBQThCLEdBQUcsSUFBSSxDQUFDOzZCQUNwRjtpQ0FBTTtnQ0FDTCxRQUFRLEdBQUcsZ0JBQWdCLEdBQUcsWUFBWSxHQUFHLDJCQUEyQixDQUFDO2dDQUN6RSxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDO29DQUNwQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxLQUFLLHlCQUF5QixFQUFFO29DQUN2RCxRQUFRLElBQUksdUJBQXVCLENBQUM7aUNBQ3JDOzZCQUNGO3lCQUNGO3dCQUVELE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxxQkFBcUIsRUFBRSxRQUFRLEVBQUUsSUFBSSxDQUFDLENBQUM7cUJBQy9EO3lCQUFNO3dCQUNMLG1DQUFtQzt3QkFDbkMsT0FBTyxNQUFNLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxrREFBa0Q7NEJBQ3BGLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQztxQkFDbEU7aUJBQ0Y7YUFDRjtZQUVELE9BQU8sS0FBSyxDQUFDLEtBQUssQ0FBQztRQUNyQixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNILFdBQVcsQ0FBQyxJQUFJLEVBQUUsT0FBTztRQUN2QixPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO0lBQ2xELENBQUM7SUFFRDs7T0FFRztJQUNILE9BQU87UUFDTCxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsU0FBUyxFQUFFLEVBQUUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFO1lBQ3BGLE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUUsMkJBQTJCLEdBQUcsQ0FBQyxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNyRixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNILFFBQVEsQ0FBQyxJQUFJO1FBQ1gsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FDdEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FDakQsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDZCxJQUFJLE1BQU0sQ0FBQyxVQUFVLEtBQUssR0FBRyxFQUFFO2dCQUM3QixPQUFPLENBQUMsQ0FBQzthQUNWO1lBRUQsSUFBSSxNQUFNLENBQUMsVUFBVSxLQUFLLEdBQUcsRUFBRTtnQkFDN0IsbUVBQW1FO2dCQUNuRSxHQUFHLENBQUMsSUFBSSxDQUFDLHNCQUFzQixJQUFJLHlCQUF5QjtvQkFDMUQsd0NBQXdDLENBQUMsQ0FBQztnQkFDNUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO2dCQUMvQixPQUFPLENBQUMsQ0FBQzthQUNWO1lBRUQsT0FBTyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztRQUMzQixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNILFlBQVksQ0FBQyxJQUFJLEVBQUUsS0FBSztRQUN0QixPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQzVGLENBQUM7SUFFRDs7T0FFRztJQUNILFlBQVksQ0FBQyxFQUFFLEVBQUUsSUFBSTtRQUNuQixPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQ3JFLENBQUM7SUFFRDs7T0FFRztJQUNILE9BQU8sQ0FBQyxPQUFPO1FBQ2IsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUVqQyw2Q0FBNkM7WUFDN0MsSUFBSSxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFO2dCQUN0QyxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDOUMsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFO29CQUFFLE9BQU8sU0FBUyxDQUFDO2lCQUFFO2dCQUUvQyxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUN0QixJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsU0FBUyxDQUFDLEVBQ3BDLEVBQUMsSUFBSSxFQUFFLEtBQUssRUFBQyxFQUNiLENBQUMsR0FBRyxDQUFDLENBQ04sQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLENBQUMsU0FBUyxDQUFDLENBQUM7Z0JBQ3pCLDBEQUEwRDthQUMzRDtpQkFBTTtnQkFDTCxvQ0FBb0M7Z0JBQ3BDLE9BQU8sU0FBUyxDQUFDO2FBQ2xCO1FBQ0gsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFO1lBQ3ZCLElBQUksY0FBYyxFQUFFO2dCQUNsQixPQUFPLGNBQWMsQ0FBQzthQUN2QjtZQUVELE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQy9DLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFBRSxPQUFPLFNBQVMsQ0FBQzthQUFFO1lBRS9DLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQ3RCLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxTQUFTLENBQUMsRUFDcEMsRUFBQyxJQUFJLEVBQUUsS0FBSyxFQUFDLEVBQ2IsQ0FBQyxHQUFHLENBQUMsQ0FDTixDQUFDO1FBQ0osQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQ2YsSUFBSSxNQUFNLEVBQUU7Z0JBQ1YsT0FBTztvQkFDTCxJQUFJLEVBQUUsT0FBTyxDQUFDLElBQUk7b0JBQ2xCLFNBQVMsRUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLO29CQUNqQyxPQUFPLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7aUJBQy9DLENBQUM7YUFDSDtZQUVELE9BQU87Z0JBQ0wsSUFBSSxFQUFFLE9BQU8sQ0FBQyxJQUFJLEVBQUUsU0FBUyxFQUFFLENBQUMsRUFBRSxPQUFPLEVBQUUsRUFBRTthQUM5QyxDQUFDO1FBQ0osQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLGlCQUFpQixDQUFDIn0=