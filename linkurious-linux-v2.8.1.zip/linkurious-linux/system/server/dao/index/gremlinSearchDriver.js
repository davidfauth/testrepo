/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-09-01.
 */
'use strict';
const _ = require('lodash');
const Promise = require('bluebird');
const LKE = require('../../services');
const Utils = LKE.getUtils();
const { IndexDriver } = require('./indexDriver');
class GremlinSearchDriver extends IndexDriver {
    /**
     * Add definitions in the gremlin session and/or perform additional checks.
     *
     * @returns {Bluebird<void>}
     */
    $initGremlinSession() {
        const query = `
      def search(queries, from, size, filters, categories) {
        paginatedResults = [];
        currentQuery = null;

        dedupe = [].toSet();

        while (queries.size > 0 && paginatedResults.size < size) {
          currentQuery = queries.pop();

          while (currentQuery.hasNext() && paginatedResults.size < size) {
            currentItem = currentQuery.next();

            if (filters != null) {
              skipItem = false;
              for (filter in filters) {
                testProperty = currentItem.property(filter[0]);
                testValue = '';
                if (testProperty.isPresent()) {
                  testValue = '' + testProperty.value();
                }

                if (!testValue.toLowerCase().contains(('' + filter[1]).toLowerCase())) {
                  skipItem = true;
                  break;
                }
              }
              if (skipItem) { continue; }
            }

            if (categories != null) {
              skipItem = true;
              for (category in categories) {
                if (currentItem.label() == category) {
                  skipItem = false;
                  break;
                }
              }
              if (skipItem) { continue; }
            }

            if (dedupe.add(currentItem.id())) {
              if (from-- > 0) {
                continue;
              }

              paginatedResults.push(currentItem.id());
            }
          }
        }

        moreResults = queries.size > 0 || (currentQuery != null && currentQuery.hasNext());

        return [moreResults, paginatedResults];
      }
    `;
        return this.connector.$doGremlinQuery(query, { session: 'all', autoCommit: false }).return();
    }
    /**
     * Called at the end of the connect phase for additional initializations.
     *
     * @returns {Bluebird<void>}
     */
    $onAfterConnect() {
        return this.$initGremlinSession().then(() => {
            return this.$checkSearchIndices();
        });
    }
    /**
     * Resolve if there exist indices for search.
     *
     * @returns {Bluebird<void>}
     */
    $checkSearchIndices() {
        return Promise.resolve();
    }
    /**
     * Build the query for $search.
     * - Return undefined if the search query could not be built e.g: Illegal `searchString`
     *
     * @param {string} type         'node' or 'edge'
     * @param {string} searchString Query that will be forwarded to the index. It may be either
     *                              plain text or formatted in a supported query language
     * @param {ISearchOptions}       options
     * @returns {Bluebird<string | undefined>}
     */
    $buildSearchQuery(type, searchString, options) {
        return Utils.NOT_IMPLEMENTED();
    }
    /**
     * Search for nodes or edges using `options.q`.
     * Return the IDs of the items as result.
     *
     * @param {ISearchOptions} options
     * @returns {Bluebird<SearchResponse>}
     */
    $search(options) {
        return this.$buildSearchQuery(options.type, options.q, options).then(searchQuery => {
            if (Utils.noValue(searchQuery)) {
                // There is nothing to search, return an empty search response
                return Promise.resolve({
                    type: options.type,
                    totalHits: 0,
                    results: []
                });
            }
            return this.connector.$doGremlinQuery(searchQuery).spread((moreResults, searchR) => {
                const results = _.map(searchR, rawItemId => {
                    if (options.type === 'node') {
                        return this.graphDAO.driver.$encodeNodeId(rawItemId);
                    }
                    else {
                        return this.graphDAO.driver.$encodeEdgeId(rawItemId);
                    }
                });
                return {
                    type: options.type,
                    moreResults: moreResults,
                    results: results
                };
            });
        });
    }
}
module.exports = GremlinSearchDriver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JlbWxpblNlYXJjaERyaXZlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9kYW8vaW5kZXgvZ3JlbWxpblNlYXJjaERyaXZlci5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7R0FLRztBQUNILFlBQVksQ0FBQztBQUViLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM1QixNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDcEMsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUM7QUFDdEMsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzdCLE1BQU0sRUFBQyxXQUFXLEVBQUMsR0FBRyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUM7QUFFL0MsTUFBTSxtQkFBb0IsU0FBUSxXQUFXO0lBRTNDOzs7O09BSUc7SUFDSCxtQkFBbUI7UUFDakIsTUFBTSxLQUFLLEdBQUc7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7S0F1RGIsQ0FBQztRQUVGLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsS0FBSyxFQUFFLEVBQUMsT0FBTyxFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztJQUM3RixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILGVBQWU7UUFDYixPQUFPLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDMUMsT0FBTyxJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztRQUNwQyxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsbUJBQW1CO1FBQ2pCLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO0lBQzNCLENBQUM7SUFFRDs7Ozs7Ozs7O09BU0c7SUFDSCxpQkFBaUIsQ0FBQyxJQUFJLEVBQUUsWUFBWSxFQUFFLE9BQU87UUFDM0MsT0FBTyxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDakMsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILE9BQU8sQ0FBQyxPQUFPO1FBQ2IsT0FBTyxJQUFJLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUNqRixJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLEVBQUU7Z0JBQzlCLDhEQUE4RDtnQkFDOUQsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDO29CQUNyQixJQUFJLEVBQUUsT0FBTyxDQUFDLElBQUk7b0JBQ2xCLFNBQVMsRUFBRSxDQUFDO29CQUNaLE9BQU8sRUFBRSxFQUFFO2lCQUNaLENBQUMsQ0FBQzthQUNKO1lBRUQsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxXQUFXLEVBQUUsT0FBTyxFQUFFLEVBQUU7Z0JBQ2pGLE1BQU0sT0FBTyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFLFNBQVMsQ0FBQyxFQUFFO29CQUN6QyxJQUFJLE9BQU8sQ0FBQyxJQUFJLEtBQUssTUFBTSxFQUFFO3dCQUMzQixPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQztxQkFDdEQ7eUJBQU07d0JBQ0wsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUM7cUJBQ3REO2dCQUNILENBQUMsQ0FBQyxDQUFDO2dCQUVILE9BQU87b0JBQ0wsSUFBSSxFQUFFLE9BQU8sQ0FBQyxJQUFJO29CQUNsQixXQUFXLEVBQUUsV0FBVztvQkFDeEIsT0FBTyxFQUFFLE9BQU87aUJBQ2pCLENBQUM7WUFDSixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxtQkFBbUIsQ0FBQyJ9