"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2015-01-08.
 */
Object.defineProperty(exports, "__esModule", { value: true });
// TODO TS2019
const rest_client_1 = require("@linkurious/rest-client");
const Bluebird = require("bluebird");
const LKE = require("../../services");
const DAO_1 = require("../DAO");
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
/**
 * IndexFeatures
 *
 * @property external               Whether the index stays in sync with the graph database automatically
 * @property canCount               Whether the index can count nodes and edges
 * @property canIndexEdges          Whether the index can index edges
 * @property searchHitsCount        Whether the search result will contain 'totalHits' or 'moreResults'
 */
/**
 * ISearchOptions
 *
 * @property type                The item type to search
 * @property q                   Search query
 * @property [fuzziness=0.1]     Fuzziness value (`0` means exact match, `1` completely fuzzy)
 * @property [size]              Page size (maximum number of returned items)
 * @property [from=0]            Offset from the first result
 * @property schema              The graph schema to restrict the search on
 * @property [filter]            Array of pairs key-value used to filter the result. The keys represent object properties and the values are what should match for each property
 */
/**
 * SearchResponse
 *
 * @property type            'node' or 'edge'
 * @property [totalHits]     Number of search results matching the search query (available if features.searchHitsCount is true)
 * @property [moreResults]   Whether other results were not returned due to pagination (available if features.searchHitsCount is false)
 * @property results         An array of IDs that matched the search query
 */
class IndexDAO extends DAO_1.DAO {
    /**
     * @param vendor               Name of the vendor for this DAO (e.g.: neo4j, elasticSearch)
     * @param requiredOptions      List of required option properties
     * @param availableOptions     List of available option properties
     * @param options              DAO constructor options
     * @param features             Features of the IndexDAO
     * @param [graphDao]           The connected GraphDAO (TODO #987 optional to support old DAOs, see #634)
     * @param [connectors]         Connectors of the DAO (TODO #987 optional to support old DAOs, see #634)
     * @param [drivers]            Driver to use from a given version (TODO #987 optional to support old DAOs, see #634)
     * @param [supportedGraphDAOs] List of supported graphDAOs (TODO #987 optional to support old DAOs, see #634)
     */
    constructor(vendor, requiredOptions, availableOptions, options, features, graphDao, connectors, drivers, supportedGraphDAOs) {
        super('Index', vendor, requiredOptions.concat(['indexName']), availableOptions.concat(['indexName', 'skipEdgeIndexation']), options, graphDao, connectors, drivers);
        if (!features) {
            throw Errors.technical('bug', 'IndexDAO: "features" is required');
        }
        this.features = features;
        Utils.check.properties('features', this.features, {
            external: { required: true, type: 'boolean' },
            canCount: { required: true, type: 'boolean' },
            canIndexEdges: { required: true, type: 'boolean' },
            searchHitsCount: { required: true, type: 'boolean' }
        });
        if (Utils.hasValue(supportedGraphDAOs) &&
            Utils.hasValue(graphDao) &&
            !supportedGraphDAOs.includes(graphDao.vendor)) {
            throw Errors.business('invalid_parameter', 'Index vendor ' +
                vendor +
                ' is not compatible with the graph vendor "' +
                graphDao.vendor +
                '". Please use one of the following instead: "' +
                supportedGraphDAOs.join('", "') +
                '".');
        }
    }
    /**
     * Create an IndexDAO instance.
     *
     * @param vendor   Vendor name
     * @param options  IndexDAO constructor options
     * @param graphDao The connected Graph DAO
     */
    static createIndexDAOInstance(vendor, options, graphDao) {
        return DAO_1.DAO.createDAOInstance('Index', vendor, options, graphDao);
    }
    // TODO TS2019 refactor above here
    /**
     * Return true if the source must be re-indexed to repair data consistency.
     */
    mustReindex() {
        return this.driver.mustReindex();
    }
    /**
     * Perform a search of nodes or edges based on a search query, a fuzziness value and filters.
     * The list of items that matched the search query is returned.
     */
    async search(options) {
        if (options.schema.size === 0) {
            // nothing to search
            return { type: options.type, totalHits: 0, results: [] };
        }
        if (options.type === rest_client_1.EntityType.EDGE && !this.features.canIndexEdges) {
            // edges are not indexed
            return { type: options.type, totalHits: 0, results: [] };
        }
        return this.$search(options);
    }
    /**
     * Perform a search of nodes or edges based on a search query, a fuzziness value and filters.
     * The list of items that matched the search query is returned.
     */
    async $search(options) {
        // TODO #987 remove these functions from the DAO once there are no more old DAOs
        return this.driver.$search(options);
    }
    /**
     * Run the indexation of the external index.
     *
     * @param progress Instance used to keep track of the progress
     * @param schema   Graph item labels and properties
     */
    async indexSource(progress, schema) {
        if (!this.features.external) {
            return;
        }
        return this.$indexSource(progress, schema);
    }
    /**
     * Run the indexation of the external index.
     *
     * @param progress Instance used to keep track of the progress
     * @param schema   Graph item labels and properties
     */
    $indexSource(progress, schema) {
        return this.driver.$indexSource(progress, schema);
    }
    // TODO TS2019 refactor under here
    /**
     * Get the number of nodes or edges in the search index.
     *
     * @param type 'node' or 'edge'
     */
    getSize(type) {
        if (!this.features.canCount) {
            return Errors.business('not_supported', 'Counting nodes and edges is not supported ' + 'by ' + this.vendor + '.', true);
        }
        else {
            return this.$getSize(type);
        }
    }
    /**
     * Get the number of nodes or edges in the search index.
     *
     * @param type 'node' or 'edge'
     */
    $getSize(type) {
        return this.driver.$getSize(type);
    }
    /**
     * Delete an entry. Do nothing if the entry to delete was not found.
     *
     * @param id   ID of the entry to delete
     * @param type 'node' or 'edge'
     */
    deleteEntry(id, type) {
        return Bluebird.resolve().then(() => {
            if (this.features.external) {
                return;
            }
            return this.$deleteEntry(id, type);
        });
    }
    /**
     * Delete an entry. Do nothing if the entry to delete was not found.
     *
     * @param id   ID of the entry to delete
     * @param type 'node' or 'edge'
     */
    $deleteEntry(id, type) {
        return this.driver.$deleteEntry(id, type);
    }
    /**
     * Index an entry if it doesn't exist or update it if it does.
     *
     * @param type  'node' or 'edge'
     * @param entry Entries to add
     */
    upsertEntry(type, entry) {
        return Bluebird.resolve().then(() => {
            if (this.features.external) {
                return;
            }
            return this.$upsertEntry(type, entry);
        });
    }
    /**
     * Remove all the entries from the index and make a new one.
     */
    clear() {
        if (this.features.external) {
            return Bluebird.resolve();
        }
        return this.$deleteIfExists().then(() => {
            return this.$createIndex();
        });
    }
    /**
     * Index an entry if it doesn't exist or update it if it does.
     *
     * @param type  'node' or 'edge'
     * @param entry Entries to add
     */
    $upsertEntry(type, entry) {
        return this.driver.$upsertEntry(type, entry);
    }
    /**
     * Delete the index if it exists.
     */
    $deleteIfExists() {
        return this.driver.$deleteIfExists();
    }
    /**
     * Create the index.
     */
    $createIndex() {
        return this.driver.$createIndex();
    }
    /**
     * Index nodes or edges.
     *
     * @param type    'node' or 'edge'
     * @param entries Entries to add
     */
    addEntries(type, entries) {
        return Bluebird.resolve().then(() => {
            if (this.features.external) {
                return;
            }
            // nothing to do
            if (entries.length === 0) {
                return;
            }
            return this.$addEntries(type, entries);
        });
    }
    /**
     * Index nodes or edges.
     *
     * @param type    'node' or 'edge'
     * @param entries Entries to add
     */
    $addEntries(type, entries) {
        return this.driver.$addEntries(type, entries);
    }
    /**
     * Commit the changes to the index.
     */
    commit() {
        if (this.features.external) {
            return Bluebird.resolve();
        }
        return this.$commit();
    }
    /**
     * Commit the changes to the index.
     */
    $commit() {
        return Utils.retryPromise('Commit write to search index', () => this.driver.$commit(), {
            delay: 3000,
            retries: 5
        });
    }
}
exports.IndexDAO = IndexDAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXhEQU8uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2luZGV4L2luZGV4REFPLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRzs7QUFFSCxjQUFjO0FBRWQseURBQW1FO0FBQ25FLHFDQUFxQztBQUdyQyxzQ0FBdUM7QUFHdkMsZ0NBQTJCO0FBTTNCLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0I7Ozs7Ozs7R0FPRztBQUVIOzs7Ozs7Ozs7O0dBVUc7QUFFSDs7Ozs7OztHQU9HO0FBRUgsTUFBc0IsUUFBd0QsU0FBUSxTQUFTO0lBRzdGOzs7Ozs7Ozs7O09BVUc7SUFDSCxZQUNFLE1BQWMsRUFDZCxlQUF5QixFQUN6QixnQkFBMEIsRUFDMUIsT0FBK0IsRUFDL0IsUUFBdUIsRUFDdkIsUUFBc0QsRUFDdEQsVUFBMkQsRUFDM0QsT0FBMkUsRUFDM0Usa0JBQTZCO1FBRTdCLEtBQUssQ0FDSCxPQUFPLEVBQ1AsTUFBTSxFQUNOLGVBQWUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxFQUNyQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxXQUFXLEVBQUUsb0JBQW9CLENBQUMsQ0FBQyxFQUM1RCxPQUFPLEVBQ1AsUUFBUSxFQUNSLFVBQVUsRUFDVixPQUFPLENBQ1IsQ0FBQztRQUVGLElBQUksQ0FBQyxRQUFRLEVBQUU7WUFDYixNQUFNLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLGtDQUFrQyxDQUFDLENBQUM7U0FDbkU7UUFFRCxJQUFJLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztRQUN6QixLQUFLLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNoRCxRQUFRLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUM7WUFDM0MsUUFBUSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFDO1lBQzNDLGFBQWEsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBQztZQUNoRCxlQUFlLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUM7U0FDbkQsQ0FBQyxDQUFDO1FBRUgsSUFDRSxLQUFLLENBQUMsUUFBUSxDQUFDLGtCQUFrQixDQUFDO1lBQ2xDLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDO1lBQ3hCLENBQUMsa0JBQWtCLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsRUFDN0M7WUFDQSxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQ25CLG1CQUFtQixFQUNuQixlQUFlO2dCQUNiLE1BQU07Z0JBQ04sNENBQTRDO2dCQUM1QyxRQUFRLENBQUMsTUFBTTtnQkFDZiwrQ0FBK0M7Z0JBQy9DLGtCQUFrQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7Z0JBQy9CLElBQUksQ0FDUCxDQUFDO1NBQ0g7SUFDSCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0ksTUFBTSxDQUFDLHNCQUFzQixDQUNsQyxNQUFjLEVBQ2QsT0FBK0IsRUFDL0IsUUFBcUQ7UUFFckQsT0FBTyxTQUFHLENBQUMsaUJBQWlCLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsUUFBUSxDQUc5RCxDQUFDO0lBQ0osQ0FBQztJQUVELGtDQUFrQztJQUVsQzs7T0FFRztJQUNJLFdBQVc7UUFDaEIsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBRSxDQUFDO0lBQ25DLENBQUM7SUFFRDs7O09BR0c7SUFDSSxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQXlCO1FBQzNDLElBQUksT0FBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEtBQUssQ0FBQyxFQUFFO1lBQzdCLG9CQUFvQjtZQUNwQixPQUFPLEVBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxJQUFJLEVBQUUsU0FBUyxFQUFFLENBQUMsRUFBRSxPQUFPLEVBQUUsRUFBRSxFQUFDLENBQUM7U0FDeEQ7UUFFRCxJQUFJLE9BQU8sQ0FBQyxJQUFJLEtBQUssd0JBQVUsQ0FBQyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsRUFBRTtZQUNwRSx3QkFBd0I7WUFDeEIsT0FBTyxFQUFDLElBQUksRUFBRSxPQUFPLENBQUMsSUFBSSxFQUFFLFNBQVMsRUFBRSxDQUFDLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBQyxDQUFDO1NBQ3hEO1FBRUQsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQy9CLENBQUM7SUFFRDs7O09BR0c7SUFDSSxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQXlCO1FBQzVDLGdGQUFnRjtRQUNoRixPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLEtBQUssQ0FBQyxXQUFXLENBQ3RCLFFBQWtCLEVBQ2xCLE1BQWdEO1FBRWhELElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRTtZQUMzQixPQUFPO1NBQ1I7UUFFRCxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLFlBQVksQ0FDakIsUUFBa0IsRUFDbEIsTUFBZ0Q7UUFFaEQsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFDcEQsQ0FBQztJQUVELGtDQUFrQztJQUVsQzs7OztPQUlHO0lBQ0ksT0FBTyxDQUFDLElBQWM7UUFDM0IsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFO1lBQzNCLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FDcEIsZUFBZSxFQUNmLDRDQUE0QyxHQUFHLEtBQUssR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLEdBQUcsRUFDeEUsSUFBSSxDQUNMLENBQUM7U0FDSDthQUFNO1lBQ0wsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQzVCO0lBQ0gsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxRQUFRLENBQUMsSUFBYztRQUM1QixPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ3BDLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLFdBQVcsQ0FBQyxFQUFVLEVBQUUsSUFBYztRQUMzQyxPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ2xDLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUU7Z0JBQzFCLE9BQU87YUFDUjtZQUVELE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDckMsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxZQUFZLENBQUMsRUFBVSxFQUFFLElBQWM7UUFDNUMsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDNUMsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksV0FBVyxDQUFDLElBQWMsRUFBRSxLQUFzQjtRQUN2RCxPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ2xDLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUU7Z0JBQzFCLE9BQU87YUFDUjtZQUVELE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDeEMsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSSxLQUFLO1FBQ1YsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRTtZQUMxQixPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQztTQUMzQjtRQUVELE9BQU8sSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDdEMsT0FBTyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDN0IsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxZQUFZLENBQUMsSUFBYyxFQUFFLEtBQXNCO1FBQ3hELE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFFRDs7T0FFRztJQUNJLGVBQWU7UUFDcEIsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQ3ZDLENBQUM7SUFFRDs7T0FFRztJQUNJLFlBQVk7UUFDakIsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRSxDQUFDO0lBQ3BDLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLFVBQVUsQ0FBQyxJQUFjLEVBQUUsT0FBNEI7UUFDNUQsT0FBTyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNsQyxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFO2dCQUMxQixPQUFPO2FBQ1I7WUFFRCxnQkFBZ0I7WUFDaEIsSUFBSSxPQUFPLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtnQkFDeEIsT0FBTzthQUNSO1lBRUQsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQztRQUN6QyxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLFdBQVcsQ0FBQyxJQUFjLEVBQUUsT0FBNEI7UUFDN0QsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUVEOztPQUVHO0lBQ0ksTUFBTTtRQUNYLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUU7WUFDMUIsT0FBTyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUM7U0FDM0I7UUFFRCxPQUFPLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztJQUN4QixDQUFDO0lBRUQ7O09BRUc7SUFDSSxPQUFPO1FBQ1osT0FBTyxLQUFLLENBQUMsWUFBWSxDQUFDLDhCQUE4QixFQUFFLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFLEVBQUU7WUFDckYsS0FBSyxFQUFFLElBQUk7WUFDWCxPQUFPLEVBQUUsQ0FBQztTQUNYLENBQUMsQ0FBQztJQUNMLENBQUM7Q0FDRjtBQXBURCw0QkFvVEMifQ==