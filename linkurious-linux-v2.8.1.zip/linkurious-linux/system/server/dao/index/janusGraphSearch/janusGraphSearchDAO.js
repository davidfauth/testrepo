/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-09-01.
 */
'use strict';
const { IndexDAO } = require('../indexDAO');
const JanusGraphConnector = require('../../connector/janusGraphConnector');
const JanusGraphSearchDriver = require('./janusGraphSearchDriver');
class JanusGraphSearchDAO extends IndexDAO {
    /**
     * @param {object}   options
     * @param {boolean}  [options.create]        Whether to create and use a `LKE_INDEX` mixed index
     * @param {boolean}  [options.indexEdges]    Whether to create or use an edge index
     * @param {string}   [options.nodeIndexName] Name of the index to use to search nodes (defaults to the first index created among the available indices)
     * @param {string}   [options.edgeIndexName] Name of the index to use to search edges (defaults to the first index created among the available indices)
     * @param {GraphDAO} graphDao                The connected Graph DAO
     */
    constructor(options, graphDao) {
        super('janusGraphSearch', [], ['create', 'indexEdges', 'nodeIndexName', 'edgeIndexName'], options, {
            external: true,
            canCount: false,
            canIndexEdges: true,
            searchHitsCount: false
        }, graphDao, JanusGraphConnector, [
            { version: '0.2.0', driver: '[latest]' },
            { version: '0.2.0', driver: JanusGraphSearchDriver } // dataTypes are correctly detected from 0.2.0
        ], ['janusGraph']);
    }
}
module.exports = JanusGraphSearchDAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiamFudXNHcmFwaFNlYXJjaERBTy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NlcnZlci9kYW8vaW5kZXgvamFudXNHcmFwaFNlYXJjaC9qYW51c0dyYXBoU2VhcmNoREFPLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBQ2IsTUFBTSxFQUFFLFFBQVEsRUFBRSxHQUFHLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUM1QyxNQUFNLG1CQUFtQixHQUFHLE9BQU8sQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDO0FBQzNFLE1BQU0sc0JBQXNCLEdBQUcsT0FBTyxDQUFDLDBCQUEwQixDQUFDLENBQUM7QUFFbkUsTUFBTSxtQkFBb0IsU0FBUSxRQUFRO0lBRXhDOzs7Ozs7O09BT0c7SUFDSCxZQUFZLE9BQU8sRUFBRSxRQUFRO1FBQzNCLEtBQUssQ0FBQyxrQkFBa0IsRUFDdEIsRUFBRSxFQUNGLENBQUMsUUFBUSxFQUFFLFlBQVksRUFBRSxlQUFlLEVBQUUsZUFBZSxDQUFDLEVBQzFELE9BQU8sRUFBRTtZQUNQLFFBQVEsRUFBRSxJQUFJO1lBQ2QsUUFBUSxFQUFFLEtBQUs7WUFDZixhQUFhLEVBQUUsSUFBSTtZQUNuQixlQUFlLEVBQUUsS0FBSztTQUN2QixFQUNELFFBQVEsRUFDUixtQkFBbUIsRUFDbkI7WUFDRSxFQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLFVBQVUsRUFBQztZQUN0QyxFQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLHNCQUFzQixFQUFDLENBQUMsOENBQThDO1NBQ2xHLEVBQ0QsQ0FBQyxZQUFZLENBQUMsQ0FDZixDQUFDO0lBQ0osQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxtQkFBbUIsQ0FBQyJ9