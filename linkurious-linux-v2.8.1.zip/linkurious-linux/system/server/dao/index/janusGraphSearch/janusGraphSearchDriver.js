/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-09-01.
 */
'use strict';
const _ = require('lodash');
const Promise = require('bluebird');
const LKE = require('../../../services');
const Errors = LKE.getErrors();
const Utils = LKE.getUtils();
const Log = LKE.getLogger(__filename);
const GremlinSearchDriver = require('../gremlinSearchDriver');
const DaoUtils = require('../../utils/daoUtils');
const GremlinUtils = require('../../utils/gremlinUtils');
const INDEX_BACKEND = {
    ELASTICSEARCH: 'elasticsearch',
    SOLR: 'solr',
    LUCENE: 'lucene'
};
const INDEX_TYPE = {
    NODE: 'node',
    EDGE: 'edge'
};
const QUERY_TIMEOUT = 3600000;
class JanusGraphSearchDriver extends GremlinSearchDriver {
    /**
     * @param {Connector}     connector     Connector used by the DAO
     * @param {GraphDAO}      graphDAO      The connected Graph DAO
     * @param {any}           indexOptions  IndexDAO options
     * @param {any}           connectorData Data from the connector
     * @param {IndexFeatures} indexFeatures Features of the Index DAO
     */
    constructor(connector, graphDAO, indexOptions, connectorData, indexFeatures) {
        super(connector, graphDAO, indexOptions, connectorData, indexFeatures);
        this._indexedKeys = new Map();
        this._indexEdges = this.getIndexOption('indexEdges', false);
        this.indexFeatures.canIndexEdges = this._indexEdges;
    }
    /**
     * Add definitions in the gremlin session and/or perform additional checks.
     *
     * @returns {Bluebird<void>}
     */
    $initGremlinSession() {
        return super.$initGremlinSession().then(() => {
            const query = `
        class JanusSearchIterable {
          def it;
          
          JanusSearchIterable(_it) {
            it = _it.iterator();
          }
          
          def hasNext() {
            return it.hasNext();
          }
          
          def next() {
            return it.next().getElement();
          }
        }
      `;
            return this.connector.$doGremlinQuery(query, { session: 'all', autoCommit: false }).return();
        });
    }
    /**
     * Build the query for $search.
     * - Return undefined if the search query could not be built e.g: Illegal `searchString`
     *
     * @param {string} type         'node' or 'edge'
     * @param {string} searchString Query that will be forwarded to the index. It may be either
     *                              plain text or formatted in a supported query language
     * @param {ISearchOptions}       options
     * @returns {Bluebird<string | undefined>}
     */
    $buildSearchQuery(type, searchString, options) {
        const indexName = type === INDEX_TYPE.NODE ? this._nodeIndexName : this._edgeIndexName;
        const identifier = type === INDEX_TYPE.NODE ? 'v' : 'e';
        const resultType = type === INDEX_TYPE.NODE ? 'vertices' : 'edges';
        return Promise.resolve().then(() => {
            // escape the searchString and apply the fuzziness
            if (this._indexBackend !== INDEX_BACKEND.ELASTICSEARCH) {
                return this._getIndexedKeys(indexName).then(indexedKeys => {
                    const searchProperties = indexedKeys.map(key => `${identifier}."${key}"`);
                    return DaoUtils.generateLuceneQuery(searchString, options.fuzziness, { fields: searchProperties });
                });
            }
            const searchQuery = DaoUtils.generateLuceneQuery(searchString, options.fuzziness, { useEditDistance: true });
            if (searchQuery.trim().length === 0) {
                // There is nothing to search
                return;
            }
            return `${identifier}.*:${searchQuery}`;
        }).then(searchQuery => {
            if (Utils.noValue(searchQuery)) {
                // There is nothing to search
                return;
            }
            let sFilters;
            if (Utils.hasValue(options.filter)) {
                sFilters = GremlinUtils.quote(options.filter);
            }
            else {
                sFilters = 'null';
            }
            let sCategories;
            if (options.schema.size > 0) {
                sCategories = GremlinUtils.quote(options.schema.labels);
            }
            else {
                sCategories = 'null';
            }
            return `
      queries = [
        new JanusSearchIterable(graph.indexQuery(${GremlinUtils.quote(indexName)},
         ${GremlinUtils.quote(searchQuery)}).${resultType}())
      ];
      
      search(queries, ${options.from}, ${options.size}, ${sFilters}, ${sCategories});
    `;
        });
    }
    /**
     * Check if the index backend is supported.
     * Additionally, resolve the indices names to be used for nodes and edges.
     * The Linkurious indices will be used unless they cannot be found or created.
     *
     * @returns {Bluebird<void>}
     * @throws {LkError} if `create` option is false and no index exists.
     */
    $checkSearchIndices() {
        const getBackendQuery = `
      def mgmt = graph.openManagement();
      def backend = mgmt.get('index.search.backend');
      mgmt.commit(); graph.tx().commit();
      return backend;
    `;
        return this.connector.$doGremlinQuery(getBackendQuery).then(([currentBackend]) => {
            const supportedBackends = _.values(INDEX_BACKEND);
            if (!supportedBackends.includes(currentBackend)) {
                return Errors.business('source_action_needed', `"index.search.backend" must be set to one of "${supportedBackends}".`, true);
            }
            this._indexBackend = currentBackend;
            Log.info('Index backend in use: ' + this._indexBackend);
            this._linkuriousIndexName = this._getLinkuriousIndexName(currentBackend);
            return Promise.join(this._resolveIndexName(INDEX_TYPE.NODE), this._resolveIndexName(INDEX_TYPE.EDGE), (nodeIndex, edgeIndex) => {
                this._nodeIndexName = nodeIndex;
                Log.info('Node mixed index in use: ' + this._nodeIndexName);
                this._edgeIndexName = edgeIndex;
                Log.info('Edge mixed index in use: ' + this._edgeIndexName);
            });
        }).return();
    }
    /**
     * Resolve the index name to be used for the given type:
     * - Return the Linkurious index for the given type if it exists
     * - Return undefined when the index doesn't exist and `create` is true
     * - Otherwise, return the first mixed index for the given type
     *
     * @param {string} type 'node' or 'edge'
     * @returns {Bluebird<string | undefined>}
     * @private
     */
    _resolveIndexName(type) {
        if (type === 'edge' && !this._indexEdges) {
            return Promise.resolve(undefined);
        }
        return this._checkIfLinkuriousIndexExists(type).then(exists => {
            if (this.getIndexOption('create')) {
                if (exists) {
                    return type === INDEX_TYPE.NODE
                        ? this._linkuriousIndexName.NODE
                        : this._linkuriousIndexName.EDGE;
                }
                else {
                    // Linkurious index doesn't exists, but it can be created by starting the indexation
                    return;
                }
            }
            return this._getSearchIndexName(type).then(indexName => {
                if (Utils.noValue(indexName)) {
                    // No index exists and we can't create one
                    const edgeMessage = type === 'edge'
                        ? ' or disabling edge indices by setting "indexEdges" to "false"'
                        : '';
                    return Errors.business('source_action_needed', 'No mixed index found in JanusGraph for ' + type + 's. ' +
                        'You can automatically create one by setting the index option "create" to "true"' +
                        edgeMessage + '.', true);
                }
                // Linkurious index doesn't exists, but another mixed index exists and we will use it
                return indexName;
            });
        });
    }
    /**
     * Check whether the Linkurious index exists for the given type.
     *
     * @param {string} type 'node' or 'edge'
     * @returns {Bluebird<boolean>}
     * @private
     */
    _checkIfLinkuriousIndexExists(type) {
        const linkuriousIndex = type === INDEX_TYPE.NODE
            ? this._linkuriousIndexName.NODE
            : this._linkuriousIndexName.EDGE;
        const clazz = type === INDEX_TYPE.NODE ? 'Vertex.class' : 'Edge.class';
        const getIndexQuery = `
      def mgmt = graph.openManagement();
      for (index in mgmt.getGraphIndexes(${clazz})) {
        if (
            index.isMixedIndex() &&
            index.getBackingIndex() == 'search' &&
            index.name() == '${linkuriousIndex}'
           ) {
          mgmt.commit(); graph.tx().commit();
          return true;
        }
      }

      mgmt.commit(); graph.tx().commit();
      return false;
    `;
        return this.connector.$doGremlinQuery(getIndexQuery).get('0');
    }
    /**
     * Return the index name of the first mixed search index for the given type if it exists.
     * If `nodeIndexName` or `edgeIndexName` are defined, return only indices with such names if they exists.
     *
     * @param {string} type 'node' or 'edge'
     * @returns {Bluebird<string | undefined>}
     * @private
     */
    _getSearchIndexName(type) {
        const clazz = type === INDEX_TYPE.NODE
            ? 'Vertex.class'
            : 'Edge.class';
        // Index name explicitly set by the user
        const explicitIndexName = type === INDEX_TYPE.NODE
            ? this.getIndexOption('nodeIndexName')
            : this.getIndexOption('edgeIndexName');
        const stmtCheckExplicitIndex = Utils.hasValue(explicitIndexName)
            ? '&& index.name() == ' + GremlinUtils.quote(explicitIndexName)
            : '';
        if (Utils.hasValue(explicitIndexName)) {
            Log.info('Explicit index name for type ' + type + ' has been specified by the user. ' +
                'Linkurious will attempt to use a mixed index named "' + explicitIndexName + '".');
        }
        const getIndexQuery = `
      def mgmt = graph.openManagement();
      for (index in mgmt.getGraphIndexes(${clazz})) {
        if (index.isMixedIndex() && index.getBackingIndex() == 'search'
            ${stmtCheckExplicitIndex}) {
          mgmt.commit(); graph.tx().commit();
          return index.name();
        }
      }

      mgmt.commit(); graph.tx().commit();
    `;
        return this.connector.$doGremlinQuery(getIndexQuery).get('0');
    }
    /**
     * Return the list of properties in the schema with a `String` data type.
     *
     * @returns {Bluebird<string[]>}
     * @private
     */
    _getSearchableProperties() {
        let propertyFilter = 'it.dataType() == java.lang.String';
        if (this._indexBackend === INDEX_BACKEND.LUCENE) {
            // Lucene Index does not support LIST and SET cardinality
            // see https://docs.janusgraph.org/latest/limitations.html#_limited_mixed_index_support
            propertyFilter += ' && it.cardinality() == org.janusgraph.core.Cardinality.SINGLE';
        }
        const getPropertiesQuery = `
      def mgmt = graph.openManagement();
      def stringProperties = [];
      mgmt.getRelationTypes(PropertyKey).each({
        if (${propertyFilter}) {
          stringProperties.add(it.name())
        }
      });
      mgmt.commit(); graph.tx().commit();
      stringProperties;
    `;
        return this.connector.$doGremlinQuery(getPropertiesQuery);
    }
    /**
     * Return the list indexed keys in `indexName`.
     *
     * @param {string}  indexName
     * @param {boolean} [useCache=true]
     * @returns {Bluebird<string[]>}
     * @private
     */
    _getIndexedKeys(indexName, useCache = true) {
        const cachedIndexedKeys = this._indexedKeys.get(indexName);
        if (Utils.hasValue(cachedIndexedKeys) && useCache) {
            return Promise.resolve(cachedIndexedKeys);
        }
        const getIndexedKeysQuery = `
      def mgmt = graph.openManagement();
      return mgmt.getGraphIndex('${indexName}').getFieldKeys()*.name();
    `;
        return this.connector.$doGremlinQuery(getIndexedKeysQuery).then(indexedKeys => {
            this._indexedKeys.set(indexName, indexedKeys);
            return indexedKeys;
        });
    }
    /**
     * Run the indexation of the external index.
     *
     * @param {Progress} progress Instance used to keep track of the progress
     * @returns {Bluebird<void>}
     */
    $indexSource(progress, _schema) {
        // We have as many steps as gremlin queries we execute
        if (this._indexEdges) {
            progress.start(12);
        }
        else {
            progress.start(6);
        }
        return Promise.resolve().then(() => {
            // If an index already exists, we use it
            if (Utils.hasValue(this._nodeIndexName)) {
                Log.info(`A mixed search index "${this._nodeIndexName}" already exists.`);
            }
            else {
                // Otherwise, we create our own index
                this._nodeIndexName = this._linkuriousIndexName.NODE;
                return this._createIndex(INDEX_TYPE.NODE, progress)
                    .catch(error => {
                    // if we fail to create the index we should remove the index name
                    // otherwise the first condition will assume that the index was created successfully
                    this._nodeIndexName = undefined;
                    throw error;
                });
            }
        }).then(() => {
            if (this._indexEdges) {
                if (Utils.hasValue(this._edgeIndexName)) {
                    Log.info(`A mixed search index "${this._edgeIndexName}" already exists.`);
                }
                else {
                    this._edgeIndexName = this._linkuriousIndexName.EDGE;
                    return this._createIndex(INDEX_TYPE.EDGE, progress)
                        .catch(error => {
                        // if we fail to create the index we should remove the index name
                        // otherwise the first condition will assume that the index was created successfully
                        this._edgeIndexName = undefined;
                        throw error;
                    });
                }
            }
        }).return();
    }
    /**
     * Create a new search index.
     *
     * @param {string}   type     'node' or 'edge'
     * @param {Progress} progress Instance used to keep track of the progress
     * @returns {Bluebird<void>}
     * @private
     */
    _createIndex(type, progress) {
        const indexName = type === INDEX_TYPE.NODE ? this._nodeIndexName : this._edgeIndexName;
        const clazz = type === INDEX_TYPE.NODE ? 'Vertex.class' : 'Edge.class';
        const addOneProgressStep = () => {
            progress.add('step', 1);
        };
        // We first retrieve all the properties to index
        return this._getSearchableProperties().then(properties => {
            if (properties.length === 0) {
                // creating a mixed index with no properties will succeed
                // but the indexation will fail and the index is never updated since no properties were added
                // we should fail here so that the user can retry later on when the properties are added.
                return Errors.business('source_action_needed', `Cannot create a mixed index, the graph does not contain any ${type} property.`, true);
            }
            addOneProgressStep();
            let propertiesStmts = '';
            let addStmts = '';
            // see http://docs.janusgraph.org/latest/field-mapping.html#_custom_analyser
            const mappingType = this._indexBackend !== INDEX_BACKEND.ELASTICSEARCH
                ? 'TEXT'
                : 'TEXTSTRING';
            for (let i = 0; i < properties.length; i++) {
                propertiesStmts += 'def property' + i +
                    ' = mgmt.getPropertyKey(' + GremlinUtils.quote(properties[i]) + ');\n';
                addStmts += (`.addKey(property${i}, Mapping.${mappingType}.asParameter())`);
            }
            /**
             * In case it doesn't work, it probably means that there is
             * a pending transaction on another instance.
             * You can terminate all the current JanusGraph instances with the following command:
             *
             * mgmt = graph.openManagement()
             * it=mgmt.getOpenInstances().iterator(); while (it.hasNext()){ nxt=it.next(); if(!nxt.contains("current"))  mgmt.forceCloseInstance(nxt)}
             * mgmt.commit()
             *
             * Check the status of an index with:
             * mgmt = graph.openManagement();
             * mgmt.getGraphIndex('indexName').getIndexStatus(property0)
             * mgmt.commit()
             */
            // We first rollback all the transaction on the current instance, then we create the index
            const query = `
        import org.janusgraph.graphdb.database.management.ManagementSystem;

        def transactionsCount = graph.getOpenTransactions().size();
        for(def i = 0; i < transactionsCount; i++) {
          graph.getOpenTransactions().getAt(0).rollback()
        }

        def mgmt = graph.openManagement();
        ${propertiesStmts}
        mgmt.buildIndex('${indexName}', ${clazz})
          ${addStmts}
          .buildMixedIndex("search");
        mgmt.commit(); graph.tx().commit();
      `;
            Log.info(`Creating a mixed search index index in JanusGraph called "${indexName}".`);
            Log.info('The following properties are indexed: ' + properties.join(', '));
            return this.connector.$doGremlinQuery(query, { timeout: QUERY_TIMEOUT });
        }).then(() => {
            addOneProgressStep();
            Log.info(`Waiting for "${indexName}" to be "REGISTERED".`);
            return this.connector.$doGremlinQuery(`
        import org.janusgraph.graphdb.database.management.ManagementSystem;
        ManagementSystem.awaitGraphIndexStatus(graph, '${indexName}').call()
      `, { timeout: QUERY_TIMEOUT });
        }).then(() => {
            addOneProgressStep();
            Log.info(`Enabling index "${indexName}".`);
            return this.connector.$doGremlinQuery(`
        mgmt = graph.openManagement();
        mgmt.updateIndex(mgmt.getGraphIndex('${indexName}'), SchemaAction.ENABLE_INDEX).get()
        mgmt.commit(); graph.tx().commit();
      `, { timeout: QUERY_TIMEOUT });
        }).then(() => {
            addOneProgressStep();
            Log.info(`Waiting for "${indexName}" to be "ENABLED".`);
            return this.connector.$doGremlinQuery(`
        import org.janusgraph.graphdb.database.management.ManagementSystem;
        ManagementSystem.awaitGraphIndexStatus(graph, '${indexName}')
          .status(SchemaStatus.ENABLED).call()
      `, { timeout: QUERY_TIMEOUT });
        }).then(() => {
            addOneProgressStep();
            Log.info(`Indexing index "${indexName}".`);
            return this.connector.$doGremlinQuery(`
        mgmt = graph.openManagement();
        indexing = mgmt.updateIndex(mgmt.getGraphIndex('${indexName}'), SchemaAction.REINDEX)
        def getIndexJobStatus() {
          return indexing.isCancelled() ? "cancelled" : indexing.isDone() ? "done" : "indexing"
        }
      `, { timeout: QUERY_TIMEOUT });
        }).then(() => {
            const checkIndexJobStatus = () => {
                return this.connector.$doGremlinQuery('return getIndexJobStatus()').then(([status]) => {
                    if (status === 'indexing') {
                        return Promise.reject(new Error(status));
                    }
                    else if (status === 'cancelled') {
                        return Errors.technical('critical', 'Could not complete the indexation', true);
                    }
                });
            };
            return Utils.retryPromise(`Check ${indexName} status`, checkIndexJobStatus, 
            // Retry the promise as long as the error message is `indexing`. We stop if another error occurred
            { delay: 3000, retries: Infinity, decide: error => error.message === 'indexing' });
        }).then(() => {
            return this.connector.$doGremlinQuery('mgmt.commit(); graph.tx().commit();');
        }).then(() => {
            addOneProgressStep();
        });
    }
    /**
     * Return a valid node and edge index name for the `indexBackend`.
     *
     * @param {string} indexBackend
     * @returns {{NODE: string, EDGE: string}}
     * @private
     */
    _getLinkuriousIndexName(indexBackend) {
        // JanusGraph only allows alphanumeric characters as index names for Lucene
        // Since the index name needs to be backward compatible, we create a different index name for Lucene
        if (indexBackend === INDEX_BACKEND.LUCENE) {
            return { NODE: 'linkuriousIndex', EDGE: 'linkuriousIndexEdges' };
        }
        return { NODE: 'linkurious_index', EDGE: 'linkurious_index_edges' };
    }
}
module.exports = JanusGraphSearchDriver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiamFudXNHcmFwaFNlYXJjaERyaXZlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NlcnZlci9kYW8vaW5kZXgvamFudXNHcmFwaFNlYXJjaC9qYW51c0dyYXBoU2VhcmNoRHJpdmVyLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBQ2IsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNwQyxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsbUJBQW1CLENBQUMsQ0FBQztBQUN6QyxNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzdCLE1BQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDdEMsTUFBTSxtQkFBbUIsR0FBRyxPQUFPLENBQUMsd0JBQXdCLENBQUMsQ0FBQztBQUM5RCxNQUFNLFFBQVEsR0FBRyxPQUFPLENBQUMsc0JBQXNCLENBQUMsQ0FBQztBQUNqRCxNQUFNLFlBQVksR0FBRyxPQUFPLENBQUMsMEJBQTBCLENBQUMsQ0FBQztBQUV6RCxNQUFNLGFBQWEsR0FBRztJQUNwQixhQUFhLEVBQUUsZUFBZTtJQUM5QixJQUFJLEVBQUUsTUFBTTtJQUNaLE1BQU0sRUFBRSxRQUFRO0NBQ2pCLENBQUM7QUFFRixNQUFNLFVBQVUsR0FBRztJQUNqQixJQUFJLEVBQUUsTUFBTTtJQUNaLElBQUksRUFBRSxNQUFNO0NBQ2IsQ0FBQztBQUVGLE1BQU0sYUFBYSxHQUFHLE9BQU8sQ0FBQztBQUU5QixNQUFNLHNCQUF1QixTQUFRLG1CQUFtQjtJQUN0RDs7Ozs7O09BTUc7SUFDSCxZQUFZLFNBQVMsRUFBRSxRQUFRLEVBQUUsWUFBWSxFQUFFLGFBQWEsRUFBRSxhQUFhO1FBQ3pFLEtBQUssQ0FBQyxTQUFTLEVBQUUsUUFBUSxFQUFFLFlBQVksRUFBRSxhQUFhLEVBQUUsYUFBYSxDQUFDLENBQUM7UUFDdkUsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBQzlCLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDNUQsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQztJQUN0RCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILG1CQUFtQjtRQUNqQixPQUFPLEtBQUssQ0FBQyxtQkFBbUIsRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDM0MsTUFBTSxLQUFLLEdBQUc7Ozs7Ozs7Ozs7Ozs7Ozs7T0FnQmIsQ0FBQztZQUVGLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsS0FBSyxFQUFFLEVBQUMsT0FBTyxFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUM3RixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7O09BU0c7SUFDSCxpQkFBaUIsQ0FBQyxJQUFJLEVBQUUsWUFBWSxFQUFFLE9BQU87UUFDM0MsTUFBTSxTQUFTLEdBQUcsSUFBSSxLQUFLLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUM7UUFDdkYsTUFBTSxVQUFVLEdBQUcsSUFBSSxLQUFLLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO1FBQ3hELE1BQU0sVUFBVSxHQUFHLElBQUksS0FBSyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztRQUVuRSxPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ2pDLGtEQUFrRDtZQUNsRCxJQUFJLElBQUksQ0FBQyxhQUFhLEtBQUssYUFBYSxDQUFDLGFBQWEsRUFBRTtnQkFDdEQsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTtvQkFDeEQsTUFBTSxnQkFBZ0IsR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxVQUFVLEtBQUssR0FBRyxHQUFHLENBQUMsQ0FBQztvQkFDMUUsT0FBTyxRQUFRLENBQUMsbUJBQW1CLENBQ2pDLFlBQVksRUFBRSxPQUFPLENBQUMsU0FBUyxFQUFFLEVBQUMsTUFBTSxFQUFFLGdCQUFnQixFQUFDLENBQzVELENBQUM7Z0JBQ0osQ0FBQyxDQUFDLENBQUM7YUFDSjtZQUNELE1BQU0sV0FBVyxHQUFHLFFBQVEsQ0FBQyxtQkFBbUIsQ0FDOUMsWUFBWSxFQUFFLE9BQU8sQ0FBQyxTQUFTLEVBQUUsRUFBQyxlQUFlLEVBQUUsSUFBSSxFQUFDLENBQUMsQ0FBQztZQUU1RCxJQUFJLFdBQVcsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO2dCQUNuQyw2QkFBNkI7Z0JBQzdCLE9BQU87YUFDUjtZQUVELE9BQU8sR0FBRyxVQUFVLE1BQU0sV0FBVyxFQUFFLENBQUM7UUFDMUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFO1lBQ3BCLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsRUFBRTtnQkFDOUIsNkJBQTZCO2dCQUM3QixPQUFPO2FBQ1I7WUFFRCxJQUFJLFFBQVEsQ0FBQztZQUViLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUU7Z0JBQ2xDLFFBQVEsR0FBRyxZQUFZLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQzthQUMvQztpQkFBTTtnQkFDTCxRQUFRLEdBQUcsTUFBTSxDQUFDO2FBQ25CO1lBRUQsSUFBSSxXQUFXLENBQUM7WUFFaEIsSUFBSSxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksR0FBRyxDQUFDLEVBQUU7Z0JBQzNCLFdBQVcsR0FBRyxZQUFZLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7YUFDekQ7aUJBQU07Z0JBQ0wsV0FBVyxHQUFHLE1BQU0sQ0FBQzthQUN0QjtZQUNELE9BQU87O21EQUVzQyxZQUFZLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQztXQUNyRSxZQUFZLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxLQUFLLFVBQVU7Ozt3QkFHakMsT0FBTyxDQUFDLElBQUksS0FBSyxPQUFPLENBQUMsSUFBSSxLQUFLLFFBQVEsS0FBSyxXQUFXO0tBQzdFLENBQUM7UUFDRixDQUFDLENBQUMsQ0FBQztJQUVMLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsbUJBQW1CO1FBQ2pCLE1BQU0sZUFBZSxHQUFHOzs7OztLQUt2QixDQUFDO1FBRUYsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxlQUFlLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxFQUFFLEVBQUU7WUFDL0UsTUFBTSxpQkFBaUIsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBQ2xELElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLEVBQUU7Z0JBQy9DLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FDcEIsc0JBQXNCLEVBQ3RCLGlEQUFpRCxpQkFBaUIsSUFBSSxFQUN0RSxJQUFJLENBQ0wsQ0FBQzthQUNIO1lBQ0QsSUFBSSxDQUFDLGFBQWEsR0FBRyxjQUFjLENBQUM7WUFDcEMsR0FBRyxDQUFDLElBQUksQ0FBQyx3QkFBd0IsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7WUFFeEQsSUFBSSxDQUFDLG9CQUFvQixHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxjQUFjLENBQUMsQ0FBQztZQUV6RSxPQUFPLE9BQU8sQ0FBQyxJQUFJLENBQ2pCLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEVBQ3ZDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEVBQ3ZDLENBQUMsU0FBUyxFQUFFLFNBQVMsRUFBRSxFQUFFO2dCQUN2QixJQUFJLENBQUMsY0FBYyxHQUFHLFNBQVMsQ0FBQztnQkFDaEMsR0FBRyxDQUFDLElBQUksQ0FBQywyQkFBMkIsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7Z0JBQzVELElBQUksQ0FBQyxjQUFjLEdBQUcsU0FBUyxDQUFDO2dCQUNoQyxHQUFHLENBQUMsSUFBSSxDQUFDLDJCQUEyQixHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztZQUM5RCxDQUFDLENBQ0YsQ0FBQztRQUNKLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO0lBQ2QsQ0FBQztJQUVEOzs7Ozs7Ozs7T0FTRztJQUNILGlCQUFpQixDQUFDLElBQUk7UUFDcEIsSUFBSSxJQUFJLEtBQUssTUFBTSxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRTtZQUN4QyxPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7U0FDbkM7UUFFRCxPQUFPLElBQUksQ0FBQyw2QkFBNkIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDNUQsSUFBSSxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxFQUFFO2dCQUNqQyxJQUFJLE1BQU0sRUFBRTtvQkFDVixPQUFPLElBQUksS0FBSyxVQUFVLENBQUMsSUFBSTt3QkFDN0IsQ0FBQyxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJO3dCQUNoQyxDQUFDLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQztpQkFDcEM7cUJBQU07b0JBQ0wsb0ZBQW9GO29CQUNwRixPQUFPO2lCQUNSO2FBQ0Y7WUFFRCxPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUU7Z0JBQ3JELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsRUFBRTtvQkFDNUIsMENBQTBDO29CQUMxQyxNQUFNLFdBQVcsR0FBRyxJQUFJLEtBQUssTUFBTTt3QkFDakMsQ0FBQyxDQUFDLCtEQUErRDt3QkFDakUsQ0FBQyxDQUFDLEVBQUUsQ0FBQztvQkFFUCxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsc0JBQXNCLEVBQzNDLHlDQUF5QyxHQUFHLElBQUksR0FBRyxLQUFLO3dCQUN4RCxpRkFBaUY7d0JBQ2pGLFdBQVcsR0FBRyxHQUFHLEVBQ2pCLElBQUksQ0FBQyxDQUFDO2lCQUNUO2dCQUNELHFGQUFxRjtnQkFDckYsT0FBTyxTQUFTLENBQUM7WUFDbkIsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCw2QkFBNkIsQ0FBQyxJQUFJO1FBQ2hDLE1BQU0sZUFBZSxHQUFHLElBQUksS0FBSyxVQUFVLENBQUMsSUFBSTtZQUM5QyxDQUFDLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLElBQUk7WUFDaEMsQ0FBQyxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUM7UUFDbkMsTUFBTSxLQUFLLEdBQUcsSUFBSSxLQUFLLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDO1FBQ3ZFLE1BQU0sYUFBYSxHQUFHOzsyQ0FFaUIsS0FBSzs7OzsrQkFJakIsZUFBZTs7Ozs7Ozs7O0tBU3pDLENBQUM7UUFFRixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLGFBQWEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUNoRSxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILG1CQUFtQixDQUFDLElBQUk7UUFDdEIsTUFBTSxLQUFLLEdBQUcsSUFBSSxLQUFLLFVBQVUsQ0FBQyxJQUFJO1lBQ3BDLENBQUMsQ0FBQyxjQUFjO1lBQ2hCLENBQUMsQ0FBQyxZQUFZLENBQUM7UUFFakIsd0NBQXdDO1FBQ3hDLE1BQU0saUJBQWlCLEdBQUcsSUFBSSxLQUFLLFVBQVUsQ0FBQyxJQUFJO1lBQ2hELENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLGVBQWUsQ0FBQztZQUN0QyxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxlQUFlLENBQUMsQ0FBQztRQUV6QyxNQUFNLHNCQUFzQixHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsaUJBQWlCLENBQUM7WUFDOUQsQ0FBQyxDQUFDLHFCQUFxQixHQUFHLFlBQVksQ0FBQyxLQUFLLENBQUMsaUJBQWlCLENBQUM7WUFDL0QsQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUVQLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFO1lBQ3JDLEdBQUcsQ0FBQyxJQUFJLENBQ04sK0JBQStCLEdBQUcsSUFBSSxHQUFHLG1DQUFtQztnQkFDNUUsc0RBQXNELEdBQUcsaUJBQWlCLEdBQUcsSUFBSSxDQUNsRixDQUFDO1NBQ0g7UUFFRCxNQUFNLGFBQWEsR0FBRzs7MkNBRWlCLEtBQUs7O2NBRWxDLHNCQUFzQjs7Ozs7OztLQU8vQixDQUFDO1FBRUYsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxhQUFhLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDaEUsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsd0JBQXdCO1FBQ3RCLElBQUksY0FBYyxHQUFHLG1DQUFtQyxDQUFDO1FBRXpELElBQUksSUFBSSxDQUFDLGFBQWEsS0FBSyxhQUFhLENBQUMsTUFBTSxFQUFFO1lBQy9DLHlEQUF5RDtZQUN6RCx1RkFBdUY7WUFDdkYsY0FBYyxJQUFJLGdFQUFnRSxDQUFDO1NBQ3BGO1FBQ0QsTUFBTSxrQkFBa0IsR0FBRzs7OztjQUlqQixjQUFjOzs7Ozs7S0FNdkIsQ0FBQztRQUVGLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsa0JBQWtCLENBQUMsQ0FBQztJQUM1RCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILGVBQWUsQ0FBQyxTQUFTLEVBQUUsUUFBUSxHQUFHLElBQUk7UUFDeEMsTUFBTSxpQkFBaUIsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUUzRCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsaUJBQWlCLENBQUMsSUFBSSxRQUFRLEVBQUU7WUFDakQsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLGlCQUFpQixDQUFDLENBQUM7U0FDM0M7UUFFRCxNQUFNLG1CQUFtQixHQUFHOzttQ0FFRyxTQUFTO0tBQ3ZDLENBQUM7UUFFRixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLG1CQUFtQixDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFO1lBQzVFLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBRSxXQUFXLENBQUMsQ0FBQztZQUM5QyxPQUFPLFdBQVcsQ0FBQztRQUNyQixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILFlBQVksQ0FBQyxRQUFRLEVBQUUsT0FBTztRQUM1QixzREFBc0Q7UUFDdEQsSUFBSSxJQUFJLENBQUMsV0FBVyxFQUFFO1lBQ3BCLFFBQVEsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUM7U0FDcEI7YUFBTTtZQUNMLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDbkI7UUFDRCxPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ2pDLHdDQUF3QztZQUN4QyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFO2dCQUN2QyxHQUFHLENBQUMsSUFBSSxDQUFDLHlCQUF5QixJQUFJLENBQUMsY0FBYyxtQkFBbUIsQ0FBQyxDQUFDO2FBQzNFO2lCQUFNO2dCQUNMLHFDQUFxQztnQkFDckMsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDO2dCQUNyRCxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxRQUFRLENBQUM7cUJBQ2hELEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRTtvQkFDYixpRUFBaUU7b0JBQ2pFLG9GQUFvRjtvQkFDcEYsSUFBSSxDQUFDLGNBQWMsR0FBRyxTQUFTLENBQUM7b0JBQ2hDLE1BQU0sS0FBSyxDQUFDO2dCQUNkLENBQUMsQ0FBQyxDQUFDO2FBQ047UUFDSCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1gsSUFBSSxJQUFJLENBQUMsV0FBVyxFQUFFO2dCQUNwQixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFO29CQUN2QyxHQUFHLENBQUMsSUFBSSxDQUFDLHlCQUF5QixJQUFJLENBQUMsY0FBYyxtQkFBbUIsQ0FBQyxDQUFDO2lCQUMzRTtxQkFBTTtvQkFDTCxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUM7b0JBQ3JELE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLFFBQVEsQ0FBQzt5QkFDaEQsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFO3dCQUNiLGlFQUFpRTt3QkFDakUsb0ZBQW9GO3dCQUNwRixJQUFJLENBQUMsY0FBYyxHQUFHLFNBQVMsQ0FBQzt3QkFDaEMsTUFBTSxLQUFLLENBQUM7b0JBQ2QsQ0FBQyxDQUFDLENBQUM7aUJBQ047YUFDRjtRQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO0lBQ2QsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxZQUFZLENBQUMsSUFBSSxFQUFFLFFBQVE7UUFDekIsTUFBTSxTQUFTLEdBQUcsSUFBSSxLQUFLLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUM7UUFDdkYsTUFBTSxLQUFLLEdBQUcsSUFBSSxLQUFLLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDO1FBQ3ZFLE1BQU0sa0JBQWtCLEdBQUcsR0FBRyxFQUFFO1lBQzlCLFFBQVEsQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQzFCLENBQUMsQ0FBQztRQUVGLGdEQUFnRDtRQUNoRCxPQUFPLElBQUksQ0FBQyx3QkFBd0IsRUFBRSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRTtZQUN2RCxJQUFJLFVBQVUsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO2dCQUMzQix5REFBeUQ7Z0JBQ3pELDZGQUE2RjtnQkFDN0YseUZBQXlGO2dCQUN6RixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsc0JBQXNCLEVBQzNDLCtEQUErRCxJQUFJLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQzthQUMxRjtZQUVELGtCQUFrQixFQUFFLENBQUM7WUFDckIsSUFBSSxlQUFlLEdBQUcsRUFBRSxDQUFDO1lBQ3pCLElBQUksUUFBUSxHQUFHLEVBQUUsQ0FBQztZQUVsQiw0RUFBNEU7WUFDNUUsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLGFBQWEsS0FBSyxhQUFhLENBQUMsYUFBYTtnQkFDcEUsQ0FBQyxDQUFDLE1BQU07Z0JBQ1IsQ0FBQyxDQUFDLFlBQVksQ0FBQztZQUNqQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsVUFBVSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDMUMsZUFBZSxJQUFJLGNBQWMsR0FBRyxDQUFDO29CQUNuQyx5QkFBeUIsR0FBRyxZQUFZLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLE1BQU0sQ0FBQztnQkFDekUsUUFBUSxJQUFJLENBQUMsbUJBQW1CLENBQUMsYUFBYSxXQUFXLGlCQUFpQixDQUFDLENBQUM7YUFDN0U7WUFFRDs7Ozs7Ozs7Ozs7OztlQWFHO1lBRUgsMEZBQTBGO1lBQzFGLE1BQU0sS0FBSyxHQUFHOzs7Ozs7Ozs7VUFTVixlQUFlOzJCQUNFLFNBQVMsTUFBTSxLQUFLO1lBQ25DLFFBQVE7OztPQUdiLENBQUM7WUFFRixHQUFHLENBQUMsSUFBSSxDQUFDLDZEQUE2RCxTQUFTLElBQUksQ0FBQyxDQUFDO1lBQ3JGLEdBQUcsQ0FBQyxJQUFJLENBQUMsd0NBQXdDLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1lBQzNFLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsS0FBSyxFQUFFLEVBQUMsT0FBTyxFQUFFLGFBQWEsRUFBQyxDQUFDLENBQUM7UUFDekUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNYLGtCQUFrQixFQUFFLENBQUM7WUFDckIsR0FBRyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsU0FBUyx1QkFBdUIsQ0FBQyxDQUFDO1lBQzNELE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUM7O3lEQUVhLFNBQVM7T0FDM0QsRUFBRSxFQUFDLE9BQU8sRUFBRSxhQUFhLEVBQUMsQ0FBQyxDQUFDO1FBQy9CLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCxrQkFBa0IsRUFBRSxDQUFDO1lBQ3JCLEdBQUcsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLFNBQVMsSUFBSSxDQUFDLENBQUM7WUFDM0MsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQzs7K0NBRUcsU0FBUzs7T0FFakQsRUFBRSxFQUFDLE9BQU8sRUFBRSxhQUFhLEVBQUMsQ0FBQyxDQUFDO1FBQy9CLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCxrQkFBa0IsRUFBRSxDQUFDO1lBQ3JCLEdBQUcsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLFNBQVMsb0JBQW9CLENBQUMsQ0FBQztZQUN4RCxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDOzt5REFFYSxTQUFTOztPQUUzRCxFQUFFLEVBQUMsT0FBTyxFQUFFLGFBQWEsRUFBQyxDQUFDLENBQUM7UUFDL0IsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNYLGtCQUFrQixFQUFFLENBQUM7WUFDckIsR0FBRyxDQUFDLElBQUksQ0FBQyxtQkFBbUIsU0FBUyxJQUFJLENBQUMsQ0FBQztZQUMzQyxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDOzswREFFYyxTQUFTOzs7O09BSTVELEVBQUUsRUFBQyxPQUFPLEVBQUUsYUFBYSxFQUFDLENBQUMsQ0FBQztRQUMvQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1gsTUFBTSxtQkFBbUIsR0FBRyxHQUFHLEVBQUU7Z0JBQy9CLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUU7b0JBQ3BGLElBQUksTUFBTSxLQUFLLFVBQVUsRUFBRTt3QkFDekIsT0FBTyxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7cUJBQzFDO3lCQUFNLElBQUksTUFBTSxLQUFLLFdBQVcsRUFBRTt3QkFDakMsT0FBTyxNQUFNLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxtQ0FBbUMsRUFBRSxJQUFJLENBQUMsQ0FBQztxQkFDaEY7Z0JBQ0gsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDLENBQUM7WUFDRixPQUFPLEtBQUssQ0FBQyxZQUFZLENBQUMsU0FBUyxTQUFTLFNBQVMsRUFBRSxtQkFBbUI7WUFDeEUsa0dBQWtHO1lBQ2xHLEVBQUMsS0FBSyxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxLQUFLLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxPQUFPLEtBQUssVUFBVSxFQUFDLENBQ2hGLENBQUM7UUFDSixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1gsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDO1FBQy9FLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCxrQkFBa0IsRUFBRSxDQUFDO1FBQ3ZCLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILHVCQUF1QixDQUFDLFlBQVk7UUFDbEMsMkVBQTJFO1FBQzNFLG9HQUFvRztRQUNwRyxJQUFJLFlBQVksS0FBSyxhQUFhLENBQUMsTUFBTSxFQUFFO1lBQ3pDLE9BQU8sRUFBQyxJQUFJLEVBQUUsaUJBQWlCLEVBQUUsSUFBSSxFQUFFLHNCQUFzQixFQUFDLENBQUM7U0FDaEU7UUFDRCxPQUFPLEVBQUMsSUFBSSxFQUFFLGtCQUFrQixFQUFFLElBQUksRUFBRSx3QkFBd0IsRUFBQyxDQUFDO0lBQ3BFLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsc0JBQXNCLENBQUMifQ==