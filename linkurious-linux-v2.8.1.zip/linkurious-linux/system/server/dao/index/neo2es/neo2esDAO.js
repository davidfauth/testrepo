/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-06-22.
 */
'use strict';
// libraries
const Promise = require('bluebird');
const _ = require('lodash');
// imports
const AbstractElasticDAO = require('../abstractElasticDAO');
const LKE = require('../../../services/index');
const DaoUtils = require('../../utils/daoUtils');
const Errors = LKE.getErrors();
const Utils = LKE.getUtils();
const Log = LKE.getLogger(__filename);
/**
 * Index DAO to communicate with an index generated bu the "neo4j-to-elasticsearch" plugin
 */
class N2ESPluginDAO extends AbstractElasticDAO {
    constructor(options, graphDao) {
        super('neo2es', [], ['simplifiedSearch'], options, {
            canCount: true,
            canIndexEdges: true,
            searchHitsCount: true,
            external: true
        });
        // check if graph vendor is neo4j
        if (graphDao.vendor !== 'neo4j') {
            throw Errors.technical('critical', `Cannot use "${this.vendor}" with Graph DAO "${graphDao.vendor}".`, true);
        }
        this._simplifiedSearch = options.simplifiedSearch;
        // Note: Neo2es is only for Neo4j > 3.0 (the plugin and the procedures were not available before)
        /**
         * @type {Neo4jDAO}
         */
        this.graph = graphDao;
    }
    mustReindex() {
        return false;
    }
    /**
     * @inheritdoc
     */
    $nodeCategoriesField(raw) {
        return '_labels' + (raw ? '.raw' : '');
    }
    /**
     * @inheritdoc
     */
    $edgeTypeField(raw) {
        return '_relationship' + (raw ? '.raw' : '');
    }
    /**
     * @inheritdoc
     */
    connect() {
        // check that neo4j-to-elasticsearch and graphaware-server-community-all
        // are installed => they should be listed in Neo4j in classpath
        return this.graph.connector.$queryJmx('java.lang', 'type=Runtime', 'ClassPath')
            .then(config => {
            const gaFwkPlugin = /graphaware-server-community-all-(.*?)\.jar/g.exec(config);
            const neo2esPlugin = /graphaware-neo4j-to-elasticsearch-(.*?)\.jar/g.exec(config);
            if (Utils.noValue(gaFwkPlugin)) {
                Log.warn('The GraphAware framework does not seem to be installed.');
                return;
            }
            if (Utils.noValue(neo2esPlugin)) {
                Log.warn('The Neo4j plugin "neo4j-to-elasticsearch" does not seem to be installed.');
                return;
            }
            // Check versions
            const gaFwkVersion = gaFwkPlugin[1];
            const neo2esVersion = neo2esPlugin[1];
            if (neo2esVersion.toLowerCase().includes('snapshot')) {
                // It's safe to assume we gave them the plugin
                Log.warn('"neo4j-to-elasticsearch" SNAPSHOT plugin used: ' + neo2esPlugin[0]);
                return;
            }
            const neo2esMinVersion = '3.1.0.44.7';
            if (Utils.compareSemVer(neo2esVersion, neo2esMinVersion) < 0) {
                Log.warn('The version of Neo4j plugin "neo4j-to-elasticsearch" version ' + neo2esVersion +
                    ' must be above ' + neo2esMinVersion);
                return;
            }
            // We assume that the Neo2ES plugin is always based on the compatible GraphAware version
            if (!neo2esVersion.startsWith(gaFwkVersion)) {
                Log.warn('The Neo4j plugin "neo4j-to-elasticsearch" version ' + neo2esPlugin +
                    'is not compatible with the GraphAware framework version' + gaFwkVersion);
            }
            // check if neo2es plugin is installed
        }).then(() => this._esQuery('ga.es.initialized()', 'status')).catch(Errors.LkError, e => {
            if (e.key === 'bad_graph_request') {
                return Errors.business('index_unreachable', 'The Neo4j plugin "neo4j-to-elasticsearch" does not seem to be installed. ' +
                    'The procedures "ga.*" may not be whitelisted (bad_graph_request).', true);
            }
            return Promise.reject(e);
        }).then(initialized => {
            if (!initialized) {
                return Errors.business('index_unreachable', 'The Neo4j plugin "neo4j-to-elasticsearch" is not initialized.', true);
            }
            // get the current ES version
            return this._esQuery('ga.es.info()', 'json').then(json => global.JSON.parse(json)).then(info => {
                this._version = info.version.number;
                if (Utils.compareSemVer(this._version, '6.0.0') >= 0) {
                    return Errors.business('not_supported', 'ElasticSearch 6.x is not supported yet by Linkurious. Please use ElasticSearch 5.', true);
                }
                return this._version;
            });
        });
    }
    /**
     * @param {string} q
     * @param {string} valueName
     * @returns {Bluebird<Object|LkError>}
     * @private
     */
    _esQuery(q, valueName) {
        const query = 'CALL ' + q + ' YIELD ' + valueName + ' as r RETURN r';
        return this.graph.connector.$doCypherQuery(query).then(response => {
            return response.results[0].rows[0];
        });
    }
    _rawQuery(type, query) {
        const q = global.JSON.stringify(global.JSON.stringify(query));
        return this._esQuery('ga.es.query' + (type === 'node' ? 'Node' : 'Relationship') + 'Raw(' + q + ')', 'json').then(json => global.JSON.parse(json)).then(response => {
            if (response.error) {
                return Promise.reject(response.error);
            }
            return response;
        });
    }
    /**
     * @inheritdoc
     */
    checkUp() { return Promise.resolve(); }
    /**
     * @inheritdoc
     */
    $getSize(type) {
        return this._rawQuery(type, { size: 0 }).then(r => r.hits.total);
    }
    /**
     * @inheritdoc
     */
    $indexExists() {
        return this.$getSize('node').return(true).catch(e => false);
    }
    $resolveESType(itemType) {
        return itemType === 'node' ? 'node' : 'relationship';
    }
    $resolveESIndex(itemType) {
        return undefined;
    }
    _getSimpleSchema(itemType) {
        return this.graph.getSimpleSchema().then(simpleR => {
            const types = itemType === 'node' ? simpleR.nodeCategories : simpleR.edgeTypes;
            const properties = (itemType === 'node' ? simpleR.nodeProperties : simpleR.edgeProperties)
                .map(property => ({ key: property, count: 1 }));
            return types.map(type => ({ name: type, properties: properties, count: 1 }));
        });
    }
    /**
     * @inheritdoc
     */
    $search(options) {
        const failSafeSearchOptions = Utils.clone(options);
        return this._failSafeSearch(failSafeSearchOptions).then(result => {
            const ids = result.hits.hits.map(o => o._id);
            const totalHits = result.hits.total;
            return {
                type: options.type,
                totalHits: totalHits,
                results: ids
            };
        });
    }
    /**
     * @inheritdoc
     */
    $searchPromise(itemType, query) {
        const queryBody = query.body;
        queryBody.from = query.from;
        queryBody.size = query.size;
        queryBody.version = query.version;
        //console.log('QUERY: ' + JSON.stringify(queryBody, null, ' '))
        return this._rawQuery(itemType, queryBody);
    }
    // not needed
    $addEntries() { }
    $commit() { }
    $upsertEntry() { }
    $deleteEntry() { }
    $deleteIfExists() { }
    $createIndex() { }
    $indexSource() { }
}
module.exports = N2ESPluginDAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmVvMmVzREFPLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc2VydmVyL2Rhby9pbmRleC9uZW8yZXMvbmVvMmVzREFPLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsWUFBWTtBQUNaLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNwQyxNQUFNLENBQUMsR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFFNUIsVUFBVTtBQUNWLE1BQU0sa0JBQWtCLEdBQUcsT0FBTyxDQUFDLHVCQUF1QixDQUFDLENBQUM7QUFDNUQsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLHlCQUF5QixDQUFDLENBQUM7QUFFL0MsTUFBTSxRQUFRLEdBQUcsT0FBTyxDQUFDLHNCQUFzQixDQUFDLENBQUM7QUFDakQsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBRXRDOztHQUVHO0FBQ0gsTUFBTSxhQUFjLFNBQVEsa0JBQWtCO0lBRTVDLFlBQVksT0FBTyxFQUFFLFFBQVE7UUFDM0IsS0FBSyxDQUFDLFFBQVEsRUFBRSxFQUFFLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFLE9BQU8sRUFBRTtZQUNqRCxRQUFRLEVBQUUsSUFBSTtZQUNkLGFBQWEsRUFBRSxJQUFJO1lBQ25CLGVBQWUsRUFBRSxJQUFJO1lBRXJCLFFBQVEsRUFBRSxJQUFJO1NBQ2YsQ0FBQyxDQUFDO1FBRUgsaUNBQWlDO1FBQ2pDLElBQUksUUFBUSxDQUFDLE1BQU0sS0FBSyxPQUFPLEVBQUU7WUFDL0IsTUFBTSxNQUFNLENBQUMsU0FBUyxDQUNwQixVQUFVLEVBQUUsZUFBZSxJQUFJLENBQUMsTUFBTSxxQkFBcUIsUUFBUSxDQUFDLE1BQU0sSUFBSSxFQUFFLElBQUksQ0FDckYsQ0FBQztTQUNIO1FBRUQsSUFBSSxDQUFDLGlCQUFpQixHQUFHLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQztRQUVsRCxpR0FBaUc7UUFFakc7O1dBRUc7UUFDSCxJQUFJLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQztJQUN4QixDQUFDO0lBRUQsV0FBVztRQUNULE9BQU8sS0FBSyxDQUFDO0lBQ2YsQ0FBQztJQUVEOztPQUVHO0lBQ0gsb0JBQW9CLENBQUMsR0FBRztRQUN0QixPQUFPLFNBQVMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUN6QyxDQUFDO0lBRUQ7O09BRUc7SUFDSCxjQUFjLENBQUMsR0FBRztRQUNoQixPQUFPLGVBQWUsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBRUQ7O09BRUc7SUFDSCxPQUFPO1FBQ0wsd0VBQXdFO1FBQ3hFLCtEQUErRDtRQUMvRCxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsY0FBYyxFQUFFLFdBQVcsQ0FBQzthQUM1RSxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFFYixNQUFNLFdBQVcsR0FBRyw2Q0FBNkMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7WUFFL0UsTUFBTSxZQUFZLEdBQUcsK0NBQStDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBRWxGLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsRUFBRTtnQkFDOUIsR0FBRyxDQUFDLElBQUksQ0FBQyx5REFBeUQsQ0FBQyxDQUFDO2dCQUNwRSxPQUFPO2FBQ1I7WUFFRCxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLEVBQUU7Z0JBQy9CLEdBQUcsQ0FBQyxJQUFJLENBQUMsMEVBQTBFLENBQUMsQ0FBQztnQkFDckYsT0FBTzthQUNSO1lBRUQsaUJBQWlCO1lBQ2pCLE1BQU0sWUFBWSxHQUFHLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNwQyxNQUFNLGFBQWEsR0FBRyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFdEMsSUFBSSxhQUFhLENBQUMsV0FBVyxFQUFFLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxFQUFFO2dCQUNwRCw4Q0FBOEM7Z0JBQzlDLEdBQUcsQ0FBQyxJQUFJLENBQUMsaURBQWlELEdBQUcsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQzlFLE9BQU87YUFDUjtZQUVELE1BQU0sZ0JBQWdCLEdBQUcsWUFBWSxDQUFDO1lBRXRDLElBQUksS0FBSyxDQUFDLGFBQWEsQ0FBQyxhQUFhLEVBQUUsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQzVELEdBQUcsQ0FBQyxJQUFJLENBQUMsK0RBQStELEdBQUcsYUFBYTtvQkFDdEYsaUJBQWlCLEdBQUcsZ0JBQWdCLENBQUMsQ0FBQztnQkFDeEMsT0FBTzthQUNSO1lBRUQsd0ZBQXdGO1lBQ3hGLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxFQUFFO2dCQUMzQyxHQUFHLENBQUMsSUFBSSxDQUFDLG9EQUFvRCxHQUFHLFlBQVk7b0JBQzFFLHlEQUF5RCxHQUFHLFlBQVksQ0FBQyxDQUFDO2FBQzdFO1lBRUQsc0NBQXNDO1FBQ3hDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLHFCQUFxQixFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLEVBQUU7WUFDdEYsSUFBSSxDQUFDLENBQUMsR0FBRyxLQUFLLG1CQUFtQixFQUFFO2dCQUNqQyxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQ3BCLG1CQUFtQixFQUNuQiwyRUFBMkU7b0JBQzNFLG1FQUFtRSxFQUNuRSxJQUFJLENBQ0wsQ0FBQzthQUNIO1lBQ0QsT0FBTyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzNCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUNwQixJQUFJLENBQUMsV0FBVyxFQUFFO2dCQUNoQixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQ3BCLG1CQUFtQixFQUNuQiwrREFBK0QsRUFDL0QsSUFBSSxDQUNMLENBQUM7YUFDSDtZQUVELDZCQUE2QjtZQUM3QixPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsY0FBYyxFQUFFLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FDL0MsSUFBSSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FDaEMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQ1osSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQztnQkFFcEMsSUFBSSxLQUFLLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFO29CQUNwRCxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQ3BCLGVBQWUsRUFDZixtRkFBbUYsRUFDbkYsSUFBSSxDQUNMLENBQUM7aUJBQ0g7Z0JBRUQsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDO1lBQ3ZCLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxRQUFRLENBQUMsQ0FBQyxFQUFFLFNBQVM7UUFDbkIsTUFBTSxLQUFLLEdBQUcsT0FBTyxHQUFHLENBQUMsR0FBRyxTQUFTLEdBQUcsU0FBUyxHQUFHLGdCQUFnQixDQUFDO1FBRXJFLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUNoRSxPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3JDLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVELFNBQVMsQ0FBQyxJQUFJLEVBQUUsS0FBSztRQUNuQixNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1FBQzlELE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FDbEIsYUFBYSxHQUFHLENBQUMsSUFBSSxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsR0FBRyxNQUFNLEdBQUcsQ0FBQyxHQUFHLEdBQUcsRUFBRSxNQUFNLENBQ3ZGLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDdEQsSUFBSSxRQUFRLENBQUMsS0FBSyxFQUFFO2dCQUNsQixPQUFPLE9BQU8sQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3ZDO1lBQ0QsT0FBTyxRQUFRLENBQUM7UUFDbEIsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxPQUFPLEtBQUssT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBRXZDOztPQUVHO0lBQ0gsUUFBUSxDQUFDLElBQUk7UUFDWCxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLEVBQUMsSUFBSSxFQUFFLENBQUMsRUFBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNqRSxDQUFDO0lBRUQ7O09BRUc7SUFDSCxZQUFZO1FBQ1YsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUM5RCxDQUFDO0lBRUQsY0FBYyxDQUFDLFFBQVE7UUFDckIsT0FBTyxRQUFRLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQztJQUN2RCxDQUFDO0lBRUQsZUFBZSxDQUFDLFFBQVE7UUFDdEIsT0FBTyxTQUFTLENBQUM7SUFDbkIsQ0FBQztJQUVELGdCQUFnQixDQUFDLFFBQVE7UUFDdkIsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUNqRCxNQUFNLEtBQUssR0FBRyxRQUFRLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDO1lBRS9FLE1BQU0sVUFBVSxHQUFHLENBQUMsUUFBUSxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQztpQkFDdkYsR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFDLEdBQUcsRUFBRSxRQUFRLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQztZQUVoRCxPQUFPLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUMsSUFBSSxFQUFFLElBQUksRUFBRSxVQUFVLEVBQUUsVUFBVSxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUM7UUFDN0UsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxPQUFPLENBQUMsT0FBTztRQUNiLE1BQU0scUJBQXFCLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUVuRCxPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMscUJBQXFCLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDL0QsTUFBTSxHQUFHLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQzdDLE1BQU0sU0FBUyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO1lBRXBDLE9BQU87Z0JBQ0wsSUFBSSxFQUFFLE9BQU8sQ0FBQyxJQUFJO2dCQUNsQixTQUFTLEVBQUUsU0FBUztnQkFDcEIsT0FBTyxFQUFFLEdBQUc7YUFDYixDQUFDO1FBQ0osQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxjQUFjLENBQUMsUUFBUSxFQUFFLEtBQUs7UUFDNUIsTUFBTSxTQUFTLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQztRQUM3QixTQUFTLENBQUMsSUFBSSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUM7UUFDNUIsU0FBUyxDQUFDLElBQUksR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDO1FBQzVCLFNBQVMsQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQztRQUVsQywrREFBK0Q7UUFFL0QsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsRUFBRSxTQUFTLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBRUQsYUFBYTtJQUViLFdBQVcsS0FBSSxDQUFDO0lBQ2hCLE9BQU8sS0FBSSxDQUFDO0lBQ1osWUFBWSxLQUFJLENBQUM7SUFDakIsWUFBWSxLQUFJLENBQUM7SUFDakIsZUFBZSxLQUFJLENBQUM7SUFDcEIsWUFBWSxLQUFJLENBQUM7SUFDakIsWUFBWSxLQUFJLENBQUM7Q0FDbEI7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLGFBQWEsQ0FBQyJ9