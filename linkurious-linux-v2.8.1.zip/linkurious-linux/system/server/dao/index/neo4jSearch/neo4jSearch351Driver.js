"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2018
 *
 * - Created on 2019-01-07.
 */
const rest_client_1 = require("@linkurious/rest-client");
const Bluebird = require("bluebird");
const _ = require("lodash");
const BusinessError_1 = require("../../../models/errors/BusinessError");
const LKE = require("../../../services");
const ExternalIndexDriver = require("../externalIndexDriver");
const Utils = LKE.getUtils();
const Log = LKE.getLogger(__filename);
const DaoUtils = require('../../utils/daoUtils');
const CypherUtils = require('../../utils/cypherUtils');
/**
 * From Neo4JSearch 3.5.0 we don't use anymore Neo4j explicit indices
 * but we use Neo4j full text indices:
 *
 * https://neo4j.com/docs/operations-manual/current/performance/index-configuration/fulltext/
 *
 * Available procedures:
 * - db.index.fulltext.awaitEventuallyConsistentIndexRefresh
 *   - () :: VOID
 *   - Wait for the updates from recently committed transactions to be applied to any eventually-consistent fulltext indexes.
 * - db.index.fulltext.createNodeIndex
 *   - (indexName :: STRING?, labels :: LIST? OF STRING?, propertyNames :: LIST? OF STRING?, config = {} :: MAP?) :: VOID
 *   - Create a node fulltext index for the given labels and properties.
 * - db.index.fulltext.createRelationshipIndex
 *   - (indexName :: STRING?, relationshipTypes :: LIST? OF STRING?, propertyNames :: LIST? OF STRING?, config = {} :: MAP?) :: VOID
 *   - Create a relationship fulltext index for the given relationship types and properties.
 * - db.index.fulltext.drop
 *   - (indexName :: STRING?) :: VOID
 *   - Drop the specified index
 * - db.index.fulltext.listAvailableAnalyzers
 *   - () :: (analyzer :: STRING?, description :: STRING?)
 *   - List the available analyzers that the fulltext indexes can be configured with.
 * - db.index.fulltext.queryNodes
 *   - (indexName :: STRING?, queryString :: STRING?) :: (node :: NODE?, score :: FLOAT?)
 *   - Query the given fulltext index. Returns the matching nodes and their lucene query score, ordered by score.
 * - db.index.fulltext.queryRelationships
 *   - (indexName :: STRING?, queryString :: STRING?) :: (relationship :: RELATIONSHIP?, score :: FLOAT?)
 *   - Query the given fulltext index. Returns the matching relationships and their lucene query score, ordered by score.
 */
class Neo4jSearch351Driver extends ExternalIndexDriver {
    /**
     * @param connector     Connector used by the DAO
     * @param graphDAO      The connected GraphDAO
     * @param indexOptions  IndexDAO options
     * @param connectorData Data from the connector
     * @param indexFeatures Features of the IndexDAO
     */
    constructor(connector, graphDAO, indexOptions, connectorData, indexFeatures) {
        super(connector, graphDAO, indexOptions, connectorData, indexFeatures);
        this.initialization = this.getIndexOption('initialization', true);
        this.indexEdges = this.getIndexOption('indexEdges', false);
        this.simplifiedSearch = this.getIndexOption('simplifiedSearch', false);
        this.indexFeatures.canIndexEdges = this.indexEdges;
        this.nodeCountCache = 0;
        this.edgeCountCache = 0;
        this.configuredNodeIndex = new Map();
        this.configuredEdgeIndex = new Map();
    }
    getIndexName(entityType, label) {
        // v1 is a single index name linkurious_fulltext_${entityType}s
        return `linkurious.${entityType}.v2: ${label}`;
    }
    async checkIndices(entityType, schema, existingIndices) {
        const status = {
            progress: 100,
            missing: [],
            inconsistent: []
        };
        for (const [label, schemaType] of schema) {
            const indexName = this.getIndexName(entityType, label);
            const existingIndex = existingIndices.get(indexName);
            if (existingIndex === undefined) {
                if (schemaType.properties.length > 0) {
                    status.missing.push(label);
                }
                else {
                    Log.warn(`The ${entityType} label "${label}" has no defined property, it will not be indexed.`);
                }
            }
            else {
                // select the slowest progress as indication of the overall progress
                status.progress =
                    status.progress > existingIndex.progress ? existingIndex.progress : status.progress;
                for (const schemaProperty of schemaType.properties) {
                    if (!existingIndex.properties.includes(schemaProperty.propertyKey)) {
                        status.inconsistent.push(label);
                        break;
                    }
                }
            }
        }
        return status;
    }
    /**
     * @param type 'node' or 'edge'
     */
    async getFullTextIndices(type) {
        const indexQueryResult = await this.connector.$doCypherQuery('CALL db.indexes()');
        const indices = _.map(indexQueryResult.results, 'rows');
        const fullTextIndices = new Map();
        const expectedType = type === rest_client_1.EntityType.NODE ? 'node_fulltext' : 'relationship_fulltext';
        // Each index is an array of properties:
        // [ "description", "indexName", "tokenNames", "properties", "state", "type", "progress", "provider", "id", "failureMessage"]
        for (const [, name, , properties, , indexType, progress] of indices) {
            // We are interested in the "indexName"(1) "properties"(3)  "type"(5) "progress"(6)
            if (indexType === expectedType) {
                fullTextIndices.set(name, {
                    properties: properties,
                    progress: progress
                });
            }
        }
        return fullTextIndices;
    }
    /**
     * Collect node and edge index configuration.
     */
    async detectIndexConfiguration() {
        const simpleSchema = await this.graphDAO.getSimpleSchema();
        let nodeIndexIsConsistent = false;
        let edgeIndexIsConsistent = !this.indexEdges;
        // if none of the node categories in the simple schema is indexed, we must reindex
        let currentIndices = await this.getFullTextIndices(rest_client_1.EntityType.NODE);
        this.configuredNodeIndex.clear();
        for (const label of simpleSchema.nodeCategories) {
            const index = currentIndices.get(this.getIndexName(rest_client_1.EntityType.NODE, label));
            if (index !== undefined) {
                this.configuredNodeIndex.set(label, index.properties);
                nodeIndexIsConsistent = true;
            }
        }
        if (this.indexEdges) {
            // if none of the edge types in the simple schema is indexed, we must reindex
            currentIndices = await this.getFullTextIndices(rest_client_1.EntityType.EDGE);
            this.configuredEdgeIndex.clear();
            for (const label of simpleSchema.edgeTypes) {
                const index = currentIndices.get(this.getIndexName(rest_client_1.EntityType.EDGE, label));
                if (index !== undefined) {
                    edgeIndexIsConsistent = true;
                    this.configuredEdgeIndex.set(label, index.properties);
                }
            }
        }
        this.indexIsConsistent = nodeIndexIsConsistent && edgeIndexIsConsistent;
    }
    /**
     * Called at the end of the connect phase for additional initializations.
     */
    $onAfterConnect() {
        // We retrieve all the property keys in the schema
        return Bluebird.resolve()
            .then(() => this.detectIndexConfiguration())
            .then(() => {
            return this.graphDAO.getNodeCount(true).then(nodeCount => {
                this.nodeCountCache = nodeCount;
            });
        })
            .then(() => {
            return this.graphDAO.getEdgeCount(true).then(edgeCount => {
                this.edgeCountCache = edgeCount;
            });
        });
    }
    buildIndexQuery(label, properties, options) {
        const sProcedure = options.type === rest_client_1.EntityType.NODE
            ? 'db.index.fulltext.queryNodes'
            : 'db.index.fulltext.queryRelationships';
        const sType = options.type === 'node' ? 'node' : 'relationship';
        const sIndexName = CypherUtils.encodeValue(this.getIndexName(options.type, label));
        let luceneQuery = DaoUtils.generateLuceneQuery(options.q, options.fuzziness, {
            useEditDistance: true,
            minLengthPrefix: this.simplifiedSearch ? 20 : 4,
            fields: properties
        });
        if (Utils.hasValue(options.filter) && options.filter.length > 0) {
            const filterClauses = [];
            for (const [key, value] of options.filter) {
                filterClauses.push(`${DaoUtils.encodeLuceneTerm(key)}:${DaoUtils.encodeLucenePhrase(value)}`);
            }
            luceneQuery = `(${luceneQuery}) AND ${filterClauses.join(' AND ')}`;
        }
        return (`CALL ${sProcedure}(${sIndexName}, ${CypherUtils.encodeValue(luceneQuery)}) ` +
            `YIELD ${sType} as i, score RETURN ID(i), score LIMIT ${options.size + options.from + 1}`);
    }
    /**
     * Search for nodes or edges using `options.q`.
     * Return the IDs of the items as result.
     *
     * @param options
     */
    async $search(options) {
        const configuredIndex = options.type === rest_client_1.EntityType.NODE ? this.configuredNodeIndex : this.configuredEdgeIndex;
        const queries = [];
        for (const label of options.schema.labels) {
            const declaredType = options.schema.get(label);
            const indexedProperties = configuredIndex.get(label);
            if (declaredType !== undefined && indexedProperties !== undefined) {
                const properties = declaredType.properties.map(p => p.propertyKey);
                if (properties.length > 0) {
                    const searchTargets = _.intersection(properties, indexedProperties);
                    queries.push(this.buildIndexQuery(label, searchTargets, options));
                }
            }
        }
        if (queries.length === 0) {
            // queries can be empty if the schema is empty or the schema labels or properties are not indexed
            return {
                type: options.type,
                moreResults: false,
                results: []
            };
        }
        const { results } = await this.connector.$doCypherQuery(queries.join(' union '));
        const rows = results.map(r => r.rows);
        rows.sort((a, b) => b[1] - a[1]);
        const ids = [];
        let j;
        for (j = options.from; j < rows.length && ids.length < options.size; j++) {
            ids.push(rows[j][0] + '');
        }
        // the additional node is used to check if there are more results
        const moreResults = rows[j] !== undefined;
        return {
            type: options.type,
            moreResults: moreResults,
            results: ids
        };
    }
    /**
     *
     * @param entityType 'node' or 'edge'
     * @param schema     `entityType` labels and properties
     * @param progress   Instance used to keep track of the progress
     */
    async indexType(entityType, schema, progress) {
        const countCache = entityType === rest_client_1.EntityType.NODE ? this.nodeCountCache : this.edgeCountCache;
        const getIndexStatus = async () => {
            const existingIndices = await this.getFullTextIndices(entityType);
            return this.checkIndices(entityType, schema, existingIndices);
        };
        const indexStatus = await getIndexStatus();
        if (indexStatus.inconsistent.length === 0 && indexStatus.missing.length === 0) {
            // Skip indexation if all indexes are ready
            Log.warn(`Requested initialization for ${entityType}s full text indexation. ` +
                'All indices are already configured and ready to be used ');
            return Bluebird.resolve();
        }
        const sProcedure = entityType === rest_client_1.EntityType.NODE
            ? 'db.index.fulltext.createNodeIndex'
            : 'db.index.fulltext.createRelationshipIndex';
        const createIndex = async (label) => {
            const indexName = this.getIndexName(entityType, label);
            const sLKIndexName = CypherUtils.encodeValue(indexName);
            const sTypesToIndex = CypherUtils.encodeValue([label]);
            const sPropertiesToIndex = CypherUtils.encodeValue(schema.get(label).properties.map(p => p.propertyKey));
            const createIndexQuery = `
      CALL ${sProcedure}(${sLKIndexName}, ${sTypesToIndex}, ${sPropertiesToIndex})
    `;
            return this.connector.$doCypherQuery(createIndexQuery);
        };
        const deleteIndex = async (label) => {
            const indexName = this.getIndexName(entityType, label);
            const sIndexName = CypherUtils.encodeValue(indexName);
            return this.connector.$doCypherQuery(`CALL db.index.fulltext.drop(${sIndexName})`);
        };
        for (const label of indexStatus.inconsistent) {
            await deleteIndex(label);
        }
        for (const label of indexStatus.missing.concat(...indexStatus.inconsistent)) {
            await createIndex(label);
        }
        let progressAlreadyAdded = 0;
        const checkIndexJobStatus = () => Bluebird.resolve().then(async () => {
            const currentStatus = await getIndexStatus();
            if (currentStatus.progress < 100) {
                const approxItemsAdded = Math.round(((currentStatus.progress - progressAlreadyAdded) * countCache) / 100);
                progressAlreadyAdded = currentStatus.progress;
                progress.add(entityType, approxItemsAdded);
                throw new Error('indexing');
            }
        });
        await Utils.retryPromise(`Check ${entityType} index  status`, checkIndexJobStatus, 
        // Retry the promise as long as the error message is `indexing`. We stop if another error occurred
        { delay: 3000, retries: Infinity, decide: error => error.message === 'indexing' });
    }
    /**
     * Run the indexation of the external index.
     *
     * @param progress Instance used to keep track of the progress
     * @param schema   Graph item labels and properties
     */
    async $indexSource(progress, schema) {
        if (!this.initialization) {
            if (this.indexIsConsistent) {
                return;
            }
            else {
                throw new BusinessError_1.BusinessError('source_action_needed', 'No search index found, please set initialization to `true` ' +
                    'this will allow Linkurious to create a new indices.');
            }
        }
        await this.indexType(rest_client_1.EntityType.NODE, schema.node, progress);
        if (this.indexEdges) {
            await this.indexType(rest_client_1.EntityType.EDGE, schema.edge, progress);
        }
        return this.detectIndexConfiguration();
    }
    /**
     * Not implemented because features.canCount is false.
     *
     * @param type 'node' or 'edge'
     */
    $getSize(type) {
        return Utils.NOT_IMPLEMENTED();
    }
}
module.exports = Neo4jSearch351Driver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmVvNGpTZWFyY2gzNTFEcml2ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2luZGV4L25lbzRqU2VhcmNoL25lbzRqU2VhcmNoMzUxRHJpdmVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRztBQUNILHlEQUFtRDtBQUNuRCxxQ0FBcUM7QUFDckMsNEJBQTRCO0FBRTVCLHdFQUFtRTtBQUVuRSx5Q0FBMEM7QUFNMUMsOERBQStEO0FBRy9ELE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBRXRDLE1BQU0sUUFBUSxHQUFHLE9BQU8sQ0FBQyxzQkFBc0IsQ0FBYSxDQUFDO0FBQzdELE1BQU0sV0FBVyxHQUFHLE9BQU8sQ0FBQyx5QkFBeUIsQ0FBZ0IsQ0FBQztBQWF0RTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQTRCRztBQUNILE1BQU0sb0JBQXFCLFNBQVEsbUJBQW1DO0lBVXBFOzs7Ozs7T0FNRztJQUNILFlBQ0UsU0FBeUIsRUFDekIsUUFBcUQsRUFDckQsWUFBb0MsRUFDcEMsYUFBcUMsRUFDckMsYUFBNEI7UUFFNUIsS0FBSyxDQUFDLFNBQVMsRUFBRSxRQUFRLEVBQUUsWUFBWSxFQUFFLGFBQWEsRUFBRSxhQUFhLENBQUMsQ0FBQztRQUV2RSxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsZ0JBQWdCLEVBQUUsSUFBSSxDQUFZLENBQUM7UUFDN0UsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLFlBQVksRUFBRSxLQUFLLENBQVksQ0FBQztRQUN0RSxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxrQkFBa0IsRUFBRSxLQUFLLENBQVksQ0FBQztRQUNsRixJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDO1FBQ25ELElBQUksQ0FBQyxjQUFjLEdBQUcsQ0FBQyxDQUFDO1FBQ3hCLElBQUksQ0FBQyxjQUFjLEdBQUcsQ0FBQyxDQUFDO1FBQ3hCLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBQ3JDLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDO0lBQ3ZDLENBQUM7SUFFTyxZQUFZLENBQUMsVUFBc0IsRUFBRSxLQUFhO1FBQ3hELCtEQUErRDtRQUMvRCxPQUFPLGNBQWMsVUFBVSxRQUFRLEtBQUssRUFBRSxDQUFDO0lBQ2pELENBQUM7SUFFTyxLQUFLLENBQUMsWUFBWSxDQUN4QixVQUFzQixFQUN0QixNQUFvQixFQUNwQixlQUEyQztRQUUzQyxNQUFNLE1BQU0sR0FBbUI7WUFDN0IsUUFBUSxFQUFFLEdBQUc7WUFDYixPQUFPLEVBQUUsRUFBRTtZQUNYLFlBQVksRUFBRSxFQUFFO1NBQ2pCLENBQUM7UUFFRixLQUFLLE1BQU0sQ0FBQyxLQUFLLEVBQUUsVUFBVSxDQUFDLElBQUksTUFBTSxFQUFFO1lBQ3hDLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsVUFBVSxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQ3ZELE1BQU0sYUFBYSxHQUFHLGVBQWUsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDckQsSUFBSSxhQUFhLEtBQUssU0FBUyxFQUFFO2dCQUMvQixJQUFJLFVBQVUsQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtvQkFDcEMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7aUJBQzVCO3FCQUFNO29CQUNMLEdBQUcsQ0FBQyxJQUFJLENBQ04sT0FBTyxVQUFVLFdBQVcsS0FBSyxvREFBb0QsQ0FDdEYsQ0FBQztpQkFDSDthQUNGO2lCQUFNO2dCQUNMLG9FQUFvRTtnQkFDcEUsTUFBTSxDQUFDLFFBQVE7b0JBQ2IsTUFBTSxDQUFDLFFBQVEsR0FBRyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDO2dCQUN0RixLQUFLLE1BQU0sY0FBYyxJQUFJLFVBQVUsQ0FBQyxVQUFVLEVBQUU7b0JBQ2xELElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLEVBQUU7d0JBQ2xFLE1BQU0sQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO3dCQUNoQyxNQUFNO3FCQUNQO2lCQUNGO2FBQ0Y7U0FDRjtRQUVELE9BQU8sTUFBTSxDQUFDO0lBQ2hCLENBQUM7SUFFRDs7T0FFRztJQUNLLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxJQUFnQjtRQUMvQyxNQUFNLGdCQUFnQixHQUFHLE1BQU0sSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsbUJBQW1CLENBQUMsQ0FBQztRQUVsRixNQUFNLE9BQU8sR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsQ0FBQztRQUN4RCxNQUFNLGVBQWUsR0FBK0IsSUFBSSxHQUFHLEVBQUUsQ0FBQztRQUU5RCxNQUFNLFlBQVksR0FBRyxJQUFJLEtBQUssd0JBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsdUJBQXVCLENBQUM7UUFFMUYsd0NBQXdDO1FBQ3hDLDZIQUE2SDtRQUM3SCxLQUFLLE1BQU0sQ0FBQyxFQUFFLElBQUksRUFBRSxBQUFELEVBQUcsVUFBVSxFQUFFLEFBQUQsRUFBRyxTQUFTLEVBQUUsUUFBUSxDQUFDLElBQUksT0FBTyxFQUFFO1lBQ25FLG1GQUFtRjtZQUNuRixJQUFJLFNBQVMsS0FBSyxZQUFZLEVBQUU7Z0JBQzlCLGVBQWUsQ0FBQyxHQUFHLENBQUMsSUFBYyxFQUFFO29CQUNsQyxVQUFVLEVBQUUsVUFBc0I7b0JBQ2xDLFFBQVEsRUFBRSxRQUFrQjtpQkFDN0IsQ0FBQyxDQUFDO2FBQ0o7U0FDRjtRQUVELE9BQU8sZUFBZSxDQUFDO0lBQ3pCLENBQUM7SUFFRDs7T0FFRztJQUNLLEtBQUssQ0FBQyx3QkFBd0I7UUFDcEMsTUFBTSxZQUFZLEdBQUcsTUFBTSxJQUFJLENBQUMsUUFBUSxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBRTNELElBQUkscUJBQXFCLEdBQUcsS0FBSyxDQUFDO1FBQ2xDLElBQUkscUJBQXFCLEdBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDO1FBRTdDLGtGQUFrRjtRQUNsRixJQUFJLGNBQWMsR0FBRyxNQUFNLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyx3QkFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3BFLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNqQyxLQUFLLE1BQU0sS0FBSyxJQUFJLFlBQVksQ0FBQyxjQUFjLEVBQUU7WUFDL0MsTUFBTSxLQUFLLEdBQUcsY0FBYyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLHdCQUFVLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUM7WUFDNUUsSUFBSSxLQUFLLEtBQUssU0FBUyxFQUFFO2dCQUN2QixJQUFJLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUM7Z0JBQ3RELHFCQUFxQixHQUFHLElBQUksQ0FBQzthQUM5QjtTQUNGO1FBRUQsSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFO1lBQ25CLDZFQUE2RTtZQUM3RSxjQUFjLEdBQUcsTUFBTSxJQUFJLENBQUMsa0JBQWtCLENBQUMsd0JBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNoRSxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDakMsS0FBSyxNQUFNLEtBQUssSUFBSSxZQUFZLENBQUMsU0FBUyxFQUFFO2dCQUMxQyxNQUFNLEtBQUssR0FBRyxjQUFjLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsd0JBQVUsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQztnQkFDNUUsSUFBSSxLQUFLLEtBQUssU0FBUyxFQUFFO29CQUN2QixxQkFBcUIsR0FBRyxJQUFJLENBQUM7b0JBQzdCLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQztpQkFDdkQ7YUFDRjtTQUNGO1FBRUQsSUFBSSxDQUFDLGlCQUFpQixHQUFHLHFCQUFxQixJQUFJLHFCQUFxQixDQUFDO0lBQzFFLENBQUM7SUFFRDs7T0FFRztJQUNJLGVBQWU7UUFDcEIsa0RBQWtEO1FBQ2xELE9BQU8sUUFBUSxDQUFDLE9BQU8sRUFBRTthQUN0QixJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLHdCQUF3QixFQUFFLENBQUM7YUFDM0MsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNULE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFO2dCQUN2RCxJQUFJLENBQUMsY0FBYyxHQUFHLFNBQVMsQ0FBQztZQUNsQyxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQzthQUNELElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDVCxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRTtnQkFDdkQsSUFBSSxDQUFDLGNBQWMsR0FBRyxTQUFTLENBQUM7WUFDbEMsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFTyxlQUFlLENBQUMsS0FBYSxFQUFFLFVBQW9CLEVBQUUsT0FBeUI7UUFDcEYsTUFBTSxVQUFVLEdBQ2QsT0FBTyxDQUFDLElBQUksS0FBSyx3QkFBVSxDQUFDLElBQUk7WUFDOUIsQ0FBQyxDQUFDLDhCQUE4QjtZQUNoQyxDQUFDLENBQUMsc0NBQXNDLENBQUM7UUFDN0MsTUFBTSxLQUFLLEdBQUcsT0FBTyxDQUFDLElBQUksS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDO1FBRWhFLE1BQU0sVUFBVSxHQUFHLFdBQVcsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUM7UUFFbkYsSUFBSSxXQUFXLEdBQUcsUUFBUSxDQUFDLG1CQUFtQixDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLFNBQVMsRUFBRTtZQUMzRSxlQUFlLEVBQUUsSUFBSTtZQUNyQixlQUFlLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDL0MsTUFBTSxFQUFFLFVBQVU7U0FDbkIsQ0FBQyxDQUFDO1FBRUgsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsSUFBSSxPQUFPLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7WUFDL0QsTUFBTSxhQUFhLEdBQWEsRUFBRSxDQUFDO1lBQ25DLEtBQUssTUFBTSxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsSUFBSSxPQUFPLENBQUMsTUFBTSxFQUFFO2dCQUN6QyxhQUFhLENBQUMsSUFBSSxDQUNoQixHQUFHLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsSUFBSSxRQUFRLENBQUMsa0JBQWtCLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FDMUUsQ0FBQzthQUNIO1lBRUQsV0FBVyxHQUFHLElBQUksV0FBVyxTQUFTLGFBQWEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztTQUNyRTtRQUVELE9BQU8sQ0FDTCxRQUFRLFVBQVUsSUFBSSxVQUFVLEtBQUssV0FBVyxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsSUFBSTtZQUM3RSxTQUFTLEtBQUssMENBQTBDLE9BQU8sQ0FBQyxJQUFJLEdBQUcsT0FBTyxDQUFDLElBQUksR0FBRyxDQUFDLEVBQUUsQ0FDMUYsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBeUI7UUFDNUMsTUFBTSxlQUFlLEdBQ25CLE9BQU8sQ0FBQyxJQUFJLEtBQUssd0JBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDO1FBRXpGLE1BQU0sT0FBTyxHQUFHLEVBQUUsQ0FBQztRQUVuQixLQUFLLE1BQU0sS0FBSyxJQUFJLE9BQU8sQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFO1lBQ3pDLE1BQU0sWUFBWSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQy9DLE1BQU0saUJBQWlCLEdBQUcsZUFBZSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNyRCxJQUFJLFlBQVksS0FBSyxTQUFTLElBQUksaUJBQWlCLEtBQUssU0FBUyxFQUFFO2dCQUNqRSxNQUFNLFVBQVUsR0FBRyxZQUFZLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQztnQkFDbkUsSUFBSSxVQUFVLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtvQkFDekIsTUFBTSxhQUFhLEdBQUcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxVQUFVLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztvQkFDcEUsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssRUFBRSxhQUFhLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQztpQkFDbkU7YUFDRjtTQUNGO1FBRUQsSUFBSSxPQUFPLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUN4QixpR0FBaUc7WUFDakcsT0FBTztnQkFDTCxJQUFJLEVBQUUsT0FBTyxDQUFDLElBQUk7Z0JBQ2xCLFdBQVcsRUFBRSxLQUFLO2dCQUNsQixPQUFPLEVBQUUsRUFBRTthQUNaLENBQUM7U0FDSDtRQUVELE1BQU0sRUFBQyxPQUFPLEVBQUMsR0FBRyxNQUFNLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztRQUUvRSxNQUFNLElBQUksR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3RDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBRSxDQUFDLENBQUMsQ0FBQyxDQUFZLEdBQUksQ0FBQyxDQUFDLENBQUMsQ0FBWSxDQUFDLENBQUM7UUFDekQsTUFBTSxHQUFHLEdBQWEsRUFBRSxDQUFDO1FBRXpCLElBQUksQ0FBUyxDQUFDO1FBQ2QsS0FBSyxDQUFDLEdBQUcsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sSUFBSSxHQUFHLENBQUMsTUFBTSxHQUFHLE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDeEUsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7U0FDM0I7UUFFRCxpRUFBaUU7UUFDakUsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQztRQUUxQyxPQUFPO1lBQ0wsSUFBSSxFQUFFLE9BQU8sQ0FBQyxJQUFJO1lBQ2xCLFdBQVcsRUFBRSxXQUFXO1lBQ3hCLE9BQU8sRUFBRSxHQUFHO1NBQ2IsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNLLEtBQUssQ0FBQyxTQUFTLENBQ3JCLFVBQXNCLEVBQ3RCLE1BQW9CLEVBQ3BCLFFBQWtCO1FBRWxCLE1BQU0sVUFBVSxHQUFHLFVBQVUsS0FBSyx3QkFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQztRQUU5RixNQUFNLGNBQWMsR0FBRyxLQUFLLElBQUksRUFBRTtZQUNoQyxNQUFNLGVBQWUsR0FBRyxNQUFNLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUNsRSxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsVUFBVSxFQUFFLE1BQU0sRUFBRSxlQUFlLENBQUMsQ0FBQztRQUNoRSxDQUFDLENBQUM7UUFFRixNQUFNLFdBQVcsR0FBRyxNQUFNLGNBQWMsRUFBRSxDQUFDO1FBRTNDLElBQUksV0FBVyxDQUFDLFlBQVksQ0FBQyxNQUFNLEtBQUssQ0FBQyxJQUFJLFdBQVcsQ0FBQyxPQUFPLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUM3RSwyQ0FBMkM7WUFDM0MsR0FBRyxDQUFDLElBQUksQ0FDTixnQ0FBZ0MsVUFBVSwwQkFBMEI7Z0JBQ2xFLDBEQUEwRCxDQUM3RCxDQUFDO1lBQ0YsT0FBTyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUM7U0FDM0I7UUFFRCxNQUFNLFVBQVUsR0FDZCxVQUFVLEtBQUssd0JBQVUsQ0FBQyxJQUFJO1lBQzVCLENBQUMsQ0FBQyxtQ0FBbUM7WUFDckMsQ0FBQyxDQUFDLDJDQUEyQyxDQUFDO1FBRWxELE1BQU0sV0FBVyxHQUFHLEtBQUssRUFBRSxLQUFhLEVBQUUsRUFBRTtZQUMxQyxNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLFVBQVUsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUN2RCxNQUFNLFlBQVksR0FBRyxXQUFXLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ3hELE1BQU0sYUFBYSxHQUFHLFdBQVcsQ0FBQyxXQUFXLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1lBQ3ZELE1BQU0sa0JBQWtCLEdBQUcsV0FBVyxDQUFDLFdBQVcsQ0FDaEQsTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUUsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUN0RCxDQUFDO1lBQ0YsTUFBTSxnQkFBZ0IsR0FBRzthQUNsQixVQUFVLElBQUksWUFBWSxLQUFLLGFBQWEsS0FBSyxrQkFBa0I7S0FDM0UsQ0FBQztZQUNBLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztRQUN6RCxDQUFDLENBQUM7UUFFRixNQUFNLFdBQVcsR0FBRyxLQUFLLEVBQUUsS0FBYSxFQUFFLEVBQUU7WUFDMUMsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDdkQsTUFBTSxVQUFVLEdBQUcsV0FBVyxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUN0RCxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLCtCQUErQixVQUFVLEdBQUcsQ0FBQyxDQUFDO1FBQ3JGLENBQUMsQ0FBQztRQUVGLEtBQUssTUFBTSxLQUFLLElBQUksV0FBVyxDQUFDLFlBQVksRUFBRTtZQUM1QyxNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUMxQjtRQUVELEtBQUssTUFBTSxLQUFLLElBQUksV0FBVyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsR0FBRyxXQUFXLENBQUMsWUFBWSxDQUFDLEVBQUU7WUFDM0UsTUFBTSxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDMUI7UUFFRCxJQUFJLG9CQUFvQixHQUFHLENBQUMsQ0FBQztRQUU3QixNQUFNLG1CQUFtQixHQUFHLEdBQUcsRUFBRSxDQUMvQixRQUFRLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEtBQUssSUFBSSxFQUFFO1lBQ2pDLE1BQU0sYUFBYSxHQUFHLE1BQU0sY0FBYyxFQUFFLENBQUM7WUFDN0MsSUFBSSxhQUFhLENBQUMsUUFBUSxHQUFHLEdBQUcsRUFBRTtnQkFDaEMsTUFBTSxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUNqQyxDQUFDLENBQUMsYUFBYSxDQUFDLFFBQVEsR0FBRyxvQkFBb0IsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxHQUFHLEdBQUcsQ0FDckUsQ0FBQztnQkFDRixvQkFBb0IsR0FBRyxhQUFhLENBQUMsUUFBUSxDQUFDO2dCQUM5QyxRQUFRLENBQUMsR0FBRyxDQUFDLFVBQVUsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO2dCQUMzQyxNQUFNLElBQUksS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDO2FBQzdCO1FBQ0gsQ0FBQyxDQUFDLENBQUM7UUFFTCxNQUFNLEtBQUssQ0FBQyxZQUFZLENBQ3RCLFNBQVMsVUFBVSxnQkFBZ0IsRUFDbkMsbUJBQW1CO1FBQ25CLGtHQUFrRztRQUNsRyxFQUFDLEtBQUssRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLEVBQUUsS0FBSyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsT0FBTyxLQUFLLFVBQVUsRUFBQyxDQUNoRixDQUFDO0lBQ0osQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksS0FBSyxDQUFDLFlBQVksQ0FDdkIsUUFBa0IsRUFDbEIsTUFBZ0Q7UUFFaEQsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUU7WUFDeEIsSUFBSSxJQUFJLENBQUMsaUJBQWlCLEVBQUU7Z0JBQzFCLE9BQU87YUFDUjtpQkFBTTtnQkFDTCxNQUFNLElBQUksNkJBQWEsQ0FDckIsc0JBQXNCLEVBQ3RCLDZEQUE2RDtvQkFDM0QscURBQXFELENBQ3hELENBQUM7YUFDSDtTQUNGO1FBRUQsTUFBTSxJQUFJLENBQUMsU0FBUyxDQUFDLHdCQUFVLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLENBQUM7UUFFN0QsSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFO1lBQ25CLE1BQU0sSUFBSSxDQUFDLFNBQVMsQ0FBQyx3QkFBVSxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsSUFBSSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1NBQzlEO1FBRUQsT0FBTyxJQUFJLENBQUMsd0JBQXdCLEVBQUUsQ0FBQztJQUN6QyxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNJLFFBQVEsQ0FBQyxJQUFjO1FBQzVCLE9BQU8sS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQ2pDLENBQUM7Q0FDRjtBQUVELGlCQUFTLG9CQUFvQixDQUFDIn0=