/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-10-09.
 */
'use strict';
const { IndexDAO } = require('../indexDAO');
const Neo4jHTTPConnector = require('../../connector/neo4jHTTPConnector');
const Neo4jBoltConnector = require('../../connector/neo4jBoltConnector');
const Neo4jSearch351Driver = require('./neo4jSearch351Driver');
class Neo4jSearch extends IndexDAO {
    /**
     * @param {object}   options
     * @param {boolean}  [options.initialization=true] Whether to perform the actual indexation on "start indexation" or just refresh the schema
     * @param {string[]} [options.categoriesToIndex]   List of node categories to index (empty array means index everything)
     * @param {string[]} [options.edgeTypesToIndex]    List of edge types to index (empty array means index everything)
     * @param {string}   [options.nodeIndexName]       Name of the index to use to search nodes (defaults to the first index created among the available indices)
     * @param {string}   [options.edgeIndexName]       Name of the index to use to search edges (defaults to the first index created among the available indices)
     * @param {boolean}  [options.indexEdges]          Whether to create or use an edge index
     * @param {boolean}  [options.simplifiedSearch]    Whether phrase prefix search is enabled
     * @param {GraphDAO} graphDao                      The connected Graph DAO
     */
    constructor(options, graphDao) {
        const useBolt = graphDao.getOption('url').toLowerCase().startsWith('bolt');
        super('neo4jSearch', [], [
            'initialization',
            'categoriesToIndex',
            'edgeTypesToIndex',
            'nodeIndexName',
            'edgeIndexName',
            'indexEdges',
            'simplifiedSearch',
            // @backward-compatibility (No longer used since Neo4j 3.5 full-text indices)
            'batchSize',
            'numberOfThreads',
            'initialOffsetNodes',
            'initialOffsetEdges'
        ], options, {
            external: true,
            canCount: false,
            canIndexEdges: true,
            searchHitsCount: false
        }, graphDao, useBolt ? Neo4jBoltConnector : [Neo4jBoltConnector, Neo4jHTTPConnector], [
            { version: '3.5.7', driver: '[latest]' },
            { version: '3.5.1', driver: Neo4jSearch351Driver }
        ], ['neo4j']);
    }
}
module.exports = Neo4jSearch;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmVvNGpTZWFyY2hEQU8uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2luZGV4L25lbzRqU2VhcmNoL25lbzRqU2VhcmNoREFPLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBQ2IsTUFBTSxFQUFFLFFBQVEsRUFBRSxHQUFHLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUM1QyxNQUFNLGtCQUFrQixHQUFHLE9BQU8sQ0FBQyxvQ0FBb0MsQ0FBQyxDQUFDO0FBQ3pFLE1BQU0sa0JBQWtCLEdBQUcsT0FBTyxDQUFDLG9DQUFvQyxDQUFDLENBQUM7QUFDekUsTUFBTSxvQkFBb0IsR0FBRyxPQUFPLENBQUMsd0JBQXdCLENBQUMsQ0FBQztBQUUvRCxNQUFNLFdBQVksU0FBUSxRQUFRO0lBRWhDOzs7Ozs7Ozs7O09BVUc7SUFDSCxZQUFZLE9BQU8sRUFBRSxRQUFRO1FBQzNCLE1BQU0sT0FBTyxHQUFHLFFBQVEsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRTNFLEtBQUssQ0FBQyxhQUFhLEVBQ2pCLEVBQUUsRUFDRjtZQUNFLGdCQUFnQjtZQUNoQixtQkFBbUI7WUFDbkIsa0JBQWtCO1lBQ2xCLGVBQWU7WUFDZixlQUFlO1lBQ2YsWUFBWTtZQUNaLGtCQUFrQjtZQUVsQiw2RUFBNkU7WUFDN0UsV0FBVztZQUNYLGlCQUFpQjtZQUNqQixvQkFBb0I7WUFDcEIsb0JBQW9CO1NBQ3JCLEVBQ0QsT0FBTyxFQUNQO1lBQ0UsUUFBUSxFQUFFLElBQUk7WUFDZCxRQUFRLEVBQUUsS0FBSztZQUNmLGFBQWEsRUFBRSxJQUFJO1lBQ25CLGVBQWUsRUFBRSxLQUFLO1NBQ3ZCLEVBQ0QsUUFBUSxFQUNSLE9BQU8sQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLEVBQUUsa0JBQWtCLENBQUMsRUFDdkU7WUFDRSxFQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLFVBQVUsRUFBQztZQUN0QyxFQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLG9CQUFvQixFQUFDO1NBQ2pELEVBQ0QsQ0FBQyxPQUFPLENBQUMsQ0FDVixDQUFDO0lBQ0osQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxXQUFXLENBQUMifQ==