"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-07-02.
 */
Object.defineProperty(exports, "__esModule", { value: true });
const LKE = require("../../services");
const utils_1 = require("./utils");
const Db = LKE.getSqlDb();
class AlertDAO {
    static async createAlertFolder(alertFolder) {
        return Db.models.alertFolder.create(alertFolder);
    }
    static async getAlertFolder(alertFolderId) {
        const byId = { where: { id: alertFolderId } };
        return (await Db.models.alertFolder.findOne(byId)) || undefined;
    }
    static async getAlertFolderByTitle(title, parent) {
        const byTitle = { where: { title: title, parent: parent } };
        return (await Db.models.alertFolder.findOne(byTitle)) || undefined;
    }
    static async updateAlertFolder(alertFolderInstance, values) {
        utils_1.SqlUtils.copyDefinedValues(alertFolderInstance, values);
        await alertFolderInstance.save();
    }
    static async deleteAlertFolder(alertFolderInstance) {
        return alertFolderInstance.destroy();
    }
    static async isAlertFolderEmpty(alertFolderInstance) {
        const alert = await Db.models.alert.findOne({ where: { folder: alertFolderInstance.id } });
        if (alert) {
            return false;
        }
        return true;
    }
    static async getAlertFolders(sourceKey) {
        return await Db.models.alertFolder.findAll({ where: { sourceKey: sourceKey } });
    }
    static async getAlerts(sourceKey) {
        return await Db.models.alert.findAll({ where: { sourceKey: sourceKey } });
    }
    static async getAlert(id) {
        return (await Db.models.alert.findOne({ where: { id: id } })) || undefined;
    }
}
exports.AlertDAO = AlertDAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWxlcnREQU8uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL3NxbC9hbGVydERBTy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7O0dBS0c7O0FBTUgsc0NBQXVDO0FBQ3ZDLG1DQUFpQztBQUVqQyxNQUFNLEVBQUUsR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFFMUIsTUFBYSxRQUFRO0lBQ1osTUFBTSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FDbkMsV0FBa0M7UUFFbEMsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDbkQsQ0FBQztJQUVNLE1BQU0sQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUNoQyxhQUFxQjtRQUVyQixNQUFNLElBQUksR0FBRyxFQUFDLEtBQUssRUFBRSxFQUFDLEVBQUUsRUFBRSxhQUFhLEVBQUMsRUFBQyxDQUFDO1FBRTFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLFNBQVMsQ0FBQztJQUNsRSxDQUFDO0lBRU0sTUFBTSxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsQ0FDdkMsS0FBYSxFQUNiLE1BQWM7UUFFZCxNQUFNLE9BQU8sR0FBRyxFQUFDLEtBQUssRUFBRSxFQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBQyxFQUFDLENBQUM7UUFFeEQsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksU0FBUyxDQUFDO0lBQ3JFLENBQUM7SUFFTSxNQUFNLENBQUMsS0FBSyxDQUFDLGlCQUFpQixDQUNuQyxtQkFBd0MsRUFDeEMsTUFBc0M7UUFFdEMsZ0JBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxtQkFBbUIsRUFBRSxNQUFNLENBQUMsQ0FBQztRQUV4RCxNQUFNLG1CQUFtQixDQUFDLElBQUksRUFBRSxDQUFDO0lBQ25DLENBQUM7SUFFTSxNQUFNLENBQUMsS0FBSyxDQUFDLGlCQUFpQixDQUFDLG1CQUF3QztRQUM1RSxPQUFPLG1CQUFtQixDQUFDLE9BQU8sRUFBRSxDQUFDO0lBQ3ZDLENBQUM7SUFFTSxNQUFNLENBQUMsS0FBSyxDQUFDLGtCQUFrQixDQUNwQyxtQkFBd0M7UUFFeEMsTUFBTSxLQUFLLEdBQUcsTUFBTSxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsRUFBQyxLQUFLLEVBQUUsRUFBQyxNQUFNLEVBQUUsbUJBQW1CLENBQUMsRUFBRSxFQUFDLEVBQUMsQ0FBQyxDQUFDO1FBRXZGLElBQUksS0FBSyxFQUFFO1lBQ1QsT0FBTyxLQUFLLENBQUM7U0FDZDtRQUVELE9BQU8sSUFBSSxDQUFDO0lBQ2QsQ0FBQztJQUVNLE1BQU0sQ0FBQyxLQUFLLENBQUMsZUFBZSxDQUFDLFNBQWlCO1FBQ25ELE9BQU8sTUFBTSxFQUFFLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsRUFBQyxLQUFLLEVBQUUsRUFBQyxTQUFTLEVBQUUsU0FBUyxFQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQzlFLENBQUM7SUFFTSxNQUFNLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxTQUFpQjtRQUM3QyxPQUFPLE1BQU0sRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEVBQUMsS0FBSyxFQUFFLEVBQUMsU0FBUyxFQUFFLFNBQVMsRUFBQyxFQUFDLENBQUMsQ0FBQztJQUN4RSxDQUFDO0lBRU0sTUFBTSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsRUFBVTtRQUNyQyxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsRUFBQyxLQUFLLEVBQUUsRUFBQyxFQUFFLEVBQUUsRUFBRSxFQUFDLEVBQUMsQ0FBQyxDQUFDLElBQUksU0FBUyxDQUFDO0lBQ3pFLENBQUM7Q0FDRjtBQTVERCw0QkE0REMifQ==