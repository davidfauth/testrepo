"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-01-24.
 */
Object.defineProperty(exports, "__esModule", { value: true });
const _ = require("lodash");
const graphQuery_1 = require("../../models/sql/graphQuery");
const LKE = require("../../services");
const Db = LKE.getSqlDb();
const Utils = LKE.getUtils();
class GraphQueryDAO {
    /**
     * Create a graph query and associate it with the user.
     */
    async createGraphQuery(graphQuery, userId) {
        return Promise.resolve().then(() => {
            return Db.models.graphQuery.create(_.merge(graphQuery, {
                version: graphQuery_1.currentGraphQueryVersion,
                userId: userId
            }));
        });
    }
    /**
     * Add an association between each group in groups and the graph query.
     */
    async shareGraphQueryWithGroups(graphQueryInstance, groups) {
        return Promise.resolve().then(() => {
            return graphQueryInstance
                .setGroups(groups)
                .then(() => {
                return graphQueryInstance.save();
            })
                .return();
        });
    }
    /**
     * Remove all the group associations of the graph query.
     */
    async unshareGraphQueryWithAllGroups(graphQueryInstance) {
        return Promise.resolve().then(() => {
            return graphQueryInstance
                .setGroups([])
                .then(() => {
                return graphQueryInstance.save();
            })
                .return();
        });
    }
    /**
     * Get a graph query. Return `undefined` if the query is not found.
     */
    async getGraphQuery(id) {
        return Promise.resolve().then(() => {
            return Db.models.graphQuery
                .findOne({ where: { version: graphQuery_1.currentGraphQueryVersion, id: id } })
                .then(instance => {
                if (Utils.noValue(instance)) {
                    return undefined;
                }
                return instance;
            });
        });
    }
    /**
     * Delete the graph query and all its associations to groups.
     */
    async deleteGraphQuery(graphQueryInstance) {
        return Promise.resolve().then(() => {
            return graphQueryInstance.destroy();
        });
    }
    /**
     * Modify the graph query.
     */
    async updateGraphQuery(graphQueryInstance, graphQuery) {
        return Promise.resolve().then(() => {
            _.forEach(graphQuery, (value, key) => {
                if (Utils.hasValue(value)) {
                    // @ts-ignore a GraphQueryInstance has all the fields of an IGraphQuery
                    graphQueryInstance[key] = value;
                }
            });
            return graphQueryInstance.save();
        });
    }
    /**
     * Check if the graph query is owned by user.
     */
    isOwner(graphQueryInstance, userId) {
        return graphQueryInstance.userId === userId;
    }
    /**
     * Check if the graph query is shared with the data-source.
     */
    isSharedWithDataSource(graphQueryInstance, sourceKey) {
        return graphQueryInstance.sharing === 'source' && graphQueryInstance.sourceKey === sourceKey;
    }
    /**
     * Check if the graph query is shared with the groups.
     */
    async isSharedWithGroups(graphQueryInstance, groupIds) {
        return Promise.resolve().then(() => {
            if (graphQueryInstance.sharing !== 'groups') {
                return false;
            }
            if (Utils.noValue(groupIds)) {
                // if groupIds is not specified, we only check graphQueryInstance.sharing
                return true;
            }
            return graphQueryInstance.getGroups().then(groups => {
                return (graphQueryInstance.sharing === 'groups' &&
                    _.intersection(_.map(groups, 'id'), groupIds).length > 0);
            });
        });
    }
    /**
     * Get the groups which the graph query is shared with.
     */
    async getGraphQueryGroups(graphQueryInstance) {
        return Promise.resolve().then(() => {
            return graphQueryInstance.getGroups();
        });
    }
    /**
     * Get all the graph queries shared with a given data-source.
     */
    async getGraphQueriesSharedWithSource(sourceKey) {
        return Promise.resolve().then(() => {
            return Db.models.graphQuery.findAll({
                where: { version: graphQuery_1.currentGraphQueryVersion, sourceKey: sourceKey, sharing: 'source' }
            });
        });
    }
    /**
     * Get all the graph queries owned by user in a data-source.
     */
    async getGraphQueriesOwnedByUser(sourceKey, userId) {
        return Promise.resolve().then(() => {
            return Db.models.graphQuery.findAll({
                where: { version: graphQuery_1.currentGraphQueryVersion, sourceKey: sourceKey, userId: userId }
            });
        });
    }
    /**
     * Get all the graph queries shared with some groups.
     */
    async getGraphQueriesSharedWithGroups(sourceKey, groupIds) {
        return Promise.resolve().then(() => {
            return Db.models.graphQuery.findAll({
                where: { version: graphQuery_1.currentGraphQueryVersion, sourceKey: sourceKey },
                include: [
                    {
                        model: Db.models.group,
                        through: { where: { groupId: groupIds } },
                        required: true
                    }
                ]
            });
        });
    }
}
exports.GraphQueryDAO = GraphQueryDAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGhRdWVyeURBTy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9kYW8vc3FsL2dyYXBoUXVlcnlEQU8udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7OztHQUtHOztBQUVILDRCQUE0QjtBQUU1Qiw0REFJcUM7QUFDckMsc0NBQXVDO0FBRXZDLE1BQU0sRUFBRSxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUMxQixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFFN0IsTUFBYSxhQUFhO0lBQ3hCOztPQUVHO0lBQ0ksS0FBSyxDQUFDLGdCQUFnQixDQUMzQixVQUF1QixFQUN2QixNQUFjO1FBRWQsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNqQyxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FDaEMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUU7Z0JBQ2xCLE9BQU8sRUFBRSxxQ0FBd0I7Z0JBQ2pDLE1BQU0sRUFBRSxNQUFNO2FBQ2YsQ0FBQyxDQUNILENBQUM7UUFDSixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNJLEtBQUssQ0FBQyx5QkFBeUIsQ0FDcEMsa0JBQXNDLEVBQ3RDLE1BQXVCO1FBRXZCLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDakMsT0FBTyxrQkFBa0I7aUJBQ3RCLFNBQVMsQ0FBQyxNQUFNLENBQUM7aUJBQ2pCLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ1QsT0FBTyxrQkFBa0IsQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNuQyxDQUFDLENBQUM7aUJBQ0QsTUFBTSxFQUFFLENBQUM7UUFDZCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNJLEtBQUssQ0FBQyw4QkFBOEIsQ0FDekMsa0JBQXNDO1FBRXRDLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDakMsT0FBTyxrQkFBa0I7aUJBQ3RCLFNBQVMsQ0FBQyxFQUFFLENBQUM7aUJBQ2IsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDVCxPQUFPLGtCQUFrQixDQUFDLElBQUksRUFBRSxDQUFDO1lBQ25DLENBQUMsQ0FBQztpQkFDRCxNQUFNLEVBQUUsQ0FBQztRQUNkLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0ksS0FBSyxDQUFDLGFBQWEsQ0FBQyxFQUFVO1FBQ25DLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDakMsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLFVBQVU7aUJBQ3hCLE9BQU8sQ0FBQyxFQUFDLEtBQUssRUFBRSxFQUFDLE9BQU8sRUFBRSxxQ0FBd0IsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFDLEVBQUMsQ0FBQztpQkFDN0QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO2dCQUNmLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBRTtvQkFDM0IsT0FBTyxTQUFTLENBQUM7aUJBQ2xCO2dCQUNELE9BQU8sUUFBUSxDQUFDO1lBQ2xCLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSSxLQUFLLENBQUMsZ0JBQWdCLENBQUMsa0JBQXNDO1FBQ2xFLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDakMsT0FBTyxrQkFBa0IsQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUN0QyxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNJLEtBQUssQ0FBQyxnQkFBZ0IsQ0FDM0Isa0JBQXNDLEVBQ3RDLFVBQWdDO1FBRWhDLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDakMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsQ0FBQyxLQUFLLEVBQUUsR0FBRyxFQUFFLEVBQUU7Z0JBQ25DLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsRUFBRTtvQkFDekIsdUVBQXVFO29CQUN2RSxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsR0FBRyxLQUFLLENBQUM7aUJBQ2pDO1lBQ0gsQ0FBQyxDQUFDLENBQUM7WUFDSCxPQUFPLGtCQUFrQixDQUFDLElBQUksRUFBRSxDQUFDO1FBQ25DLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0ksT0FBTyxDQUFDLGtCQUFzQyxFQUFFLE1BQWM7UUFDbkUsT0FBTyxrQkFBa0IsQ0FBQyxNQUFNLEtBQUssTUFBTSxDQUFDO0lBQzlDLENBQUM7SUFFRDs7T0FFRztJQUNJLHNCQUFzQixDQUMzQixrQkFBc0MsRUFDdEMsU0FBaUI7UUFFakIsT0FBTyxrQkFBa0IsQ0FBQyxPQUFPLEtBQUssUUFBUSxJQUFJLGtCQUFrQixDQUFDLFNBQVMsS0FBSyxTQUFTLENBQUM7SUFDL0YsQ0FBQztJQUVEOztPQUVHO0lBQ0ksS0FBSyxDQUFDLGtCQUFrQixDQUM3QixrQkFBc0MsRUFDdEMsUUFBbUI7UUFFbkIsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNqQyxJQUFJLGtCQUFrQixDQUFDLE9BQU8sS0FBSyxRQUFRLEVBQUU7Z0JBQzNDLE9BQU8sS0FBSyxDQUFDO2FBQ2Q7WUFFRCxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEVBQUU7Z0JBQzNCLHlFQUF5RTtnQkFDekUsT0FBTyxJQUFJLENBQUM7YUFDYjtZQUVELE9BQU8sa0JBQWtCLENBQUMsU0FBUyxFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO2dCQUNsRCxPQUFPLENBQ0wsa0JBQWtCLENBQUMsT0FBTyxLQUFLLFFBQVE7b0JBQ3ZDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FDekQsQ0FBQztZQUNKLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSSxLQUFLLENBQUMsbUJBQW1CLENBQzlCLGtCQUFzQztRQUV0QyxPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ2pDLE9BQU8sa0JBQWtCLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDeEMsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSSxLQUFLLENBQUMsK0JBQStCLENBQUMsU0FBaUI7UUFDNUQsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNqQyxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQztnQkFDbEMsS0FBSyxFQUFFLEVBQUMsT0FBTyxFQUFFLHFDQUF3QixFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBQzthQUNwRixDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNJLEtBQUssQ0FBQywwQkFBMEIsQ0FDckMsU0FBaUIsRUFDakIsTUFBYztRQUVkLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDakMsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUM7Z0JBQ2xDLEtBQUssRUFBRSxFQUFDLE9BQU8sRUFBRSxxQ0FBd0IsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUM7YUFDakYsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSSxLQUFLLENBQUMsK0JBQStCLENBQzFDLFNBQWlCLEVBQ2pCLFFBQWtCO1FBRWxCLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDakMsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUM7Z0JBQ2xDLEtBQUssRUFBRSxFQUFDLE9BQU8sRUFBRSxxQ0FBd0IsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFDO2dCQUNoRSxPQUFPLEVBQUU7b0JBQ1A7d0JBQ0UsS0FBSyxFQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSzt3QkFDdEIsT0FBTyxFQUFFLEVBQUMsS0FBSyxFQUFFLEVBQUMsT0FBTyxFQUFFLFFBQVEsRUFBQyxFQUFDO3dCQUNyQyxRQUFRLEVBQUUsSUFBSTtxQkFDZjtpQkFDRjthQUNGLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGO0FBak1ELHNDQWlNQyJ9