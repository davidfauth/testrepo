"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const LKE = require("../../services");
const Db = LKE.getSqlDb();
class GroupDAO {
    /**
     * Get multiple groups that belongs to a data-source.
     */
    async getGroups(sourceKey, ids) {
        return Promise.resolve().then(() => {
            return Db.models.group.findAll({ where: { id: ids, sourceKey: [sourceKey, '*'] } });
        });
    }
}
exports.GroupDAO = GroupDAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JvdXBEQU8uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL3NxbC9ncm91cERBTy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQU9BLHNDQUF1QztBQUN2QyxNQUFNLEVBQUUsR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFFMUIsTUFBYSxRQUFRO0lBQ25COztPQUVHO0lBQ0ksS0FBSyxDQUFDLFNBQVMsQ0FBQyxTQUFpQixFQUFFLEdBQWE7UUFDckQsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNqQyxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxFQUFDLEtBQUssRUFBRSxFQUFDLEVBQUUsRUFBRSxHQUFHLEVBQUUsU0FBUyxFQUFFLENBQUMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxFQUFDLEVBQUMsQ0FBQyxDQUFDO1FBQ2xGLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGO0FBVEQsNEJBU0MifQ==