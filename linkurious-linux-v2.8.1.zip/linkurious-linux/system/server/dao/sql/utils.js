"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-06-21.
 */
Object.defineProperty(exports, "__esModule", { value: true });
// TS2019-DONE
class SqlUtils {
    static copyDefinedValues(original, update) {
        for (const key in update) {
            if (update[key] !== undefined) {
                // @ts-ignore
                original[key] = update[key];
            }
        }
    }
}
exports.SqlUtils = SqlUtils;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXRpbHMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL3NxbC91dGlscy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7O0dBS0c7O0FBRUgsY0FBYztBQUVkLE1BQWEsUUFBUTtJQUNaLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBbUIsUUFBVyxFQUFFLE1BQWtCO1FBQy9FLEtBQUssTUFBTSxHQUFHLElBQUksTUFBTSxFQUFFO1lBQ3hCLElBQUksTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLLFNBQVMsRUFBRTtnQkFDN0IsYUFBYTtnQkFDYixRQUFRLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2FBQzdCO1NBQ0Y7SUFDSCxDQUFDO0NBQ0Y7QUFURCw0QkFTQyJ9