"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-07-29.
 */
Object.defineProperty(exports, "__esModule", { value: true });
// TS2019-DONE
const LKE = require("../../services");
const Db = LKE.getSqlDb();
class VisualizationDAO {
    static async getVisualizations(sourceKey, limit, offset) {
        return await Db.models.visualization.findAll({
            where: { sourceKey: sourceKey },
            limit: limit,
            offset: offset,
            order: [['id', 'desc']] // sort by creation date (latest first)
        });
    }
}
exports.VisualizationDAO = VisualizationDAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmlzdWFsaXphdGlvbkRBTy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9kYW8vc3FsL3Zpc3VhbGl6YXRpb25EQU8udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7OztHQUtHOztBQUVILGNBQWM7QUFFZCxzQ0FBdUM7QUFFdkMsTUFBTSxFQUFFLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBRTFCLE1BQWEsZ0JBQWdCO0lBQ3BCLE1BQU0sQ0FBQyxLQUFLLENBQUMsaUJBQWlCLENBQ25DLFNBQWlCLEVBQ2pCLEtBQWEsRUFDYixNQUFjO1FBRWQsT0FBTyxNQUFNLEVBQUUsQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQztZQUMzQyxLQUFLLEVBQUUsRUFBQyxTQUFTLEVBQUUsU0FBUyxFQUFDO1lBQzdCLEtBQUssRUFBRSxLQUFLO1lBQ1osTUFBTSxFQUFFLE1BQU07WUFDZCxLQUFLLEVBQUUsQ0FBQyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLHVDQUF1QztTQUNoRSxDQUFDLENBQUM7SUFDTCxDQUFDO0NBQ0Y7QUFiRCw0Q0FhQyJ9