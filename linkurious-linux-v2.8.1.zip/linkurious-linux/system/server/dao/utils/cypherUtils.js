/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-11-06.
 */
'use strict';
const { NativeDate, NativeDateTime } = require('linkurious-shared/umd');
const StringUtils = require('./../../../lib/StringUtils').StringUtils;
const LKE = require('../../services');
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
const CYPHER_WRITE_STATEMENTS = [
    'SET', 'CREATE', 'MERGE', 'DELETE', 'REMOVE', 'FOREACH', 'LOAD', 'DROP', 'CALL'
].sort();
const CYPHER_WRITE_RE = new RegExp('(?:\\s|^)(' + CYPHER_WRITE_STATEMENTS.join('|') + ')(?:\\s|\\()', 'i');
class CypherUtils {
    /**
     * Names in Cypher are wrapped in back-ticks ("`").
     * Escape is done with a double back-tick.
     *
     * @param {string} v
     * @returns {string}
     */
    encodeName(v) {
        return '`' + StringUtils.replaceAll(v, '`', '``') + '`';
    }
    /**
     * @param {any} v
     * @returns {string}
     */
    encodeValue(v) {
        if (v instanceof NativeDate) {
            return `date("${v.iso().split('T')[0]}")`;
        }
        else if (v instanceof NativeDateTime) {
            if (v.utc0) {
                return `datetime("${v.iso()}")`;
            }
            else {
                return `localdatetime("${v.iso()}")`;
            }
        }
        if (isFinite(v) && typeof v === 'number') {
            return v.toString().replace('+', '');
        }
        return JSON.stringify(v);
    }
    /**
     * @param {string[]} ids
     * @returns {string}
     */
    encodeIDArray(ids) {
        return '[' + ids.join() + ']';
    }
    /**
     * Return true is query is a write query.
     */
    isWrite(query) {
        // trim, remove trailing ';' from query and
        // remove string literals from the query to avoid most false positives
        const queryStatements = Utils.stripLiterals(query.trim().replace(/[;]+$/, ''));
        return CYPHER_WRITE_RE.test(queryStatements);
    }
    /**
     * Check if a query is correct and if it wants to write data but it can't.
     *
     * @param {string}  query The graph query
     * @returns {boolean} Whether the query will alter the data
     * @throws {LkError} if the query is not valid or not authorized
     */
    checkQuery(query) {
        // trim, remove trailing ';' from query and
        // remove string literals from the query to avoid most false positives
        const queryStatements = Utils.stripLiterals(query.trim().replace(/[;]+$/, ''));
        if (!queryStatements.match(/RETURN/i)) {
            throw Errors.business('invalid_parameter', 'The Cypher query is missing a "RETURN" statement.');
        }
        const match = CYPHER_WRITE_RE.exec(queryStatements);
        const willWrite = match !== null;
        if (willWrite) {
            return true;
        }
        return false;
    }
    /**
     * Enforce an EXPLAIN statement at the beginning of the query.
     *
     * @param {string} query
     * @returns {string}
     */
    enforceExplainStatement(query) {
        if (!query.match(/^\s*EXPLAIN\s/i)) {
            return `EXPLAIN ${query}`;
        }
        return query;
    }
}
module.exports = new CypherUtils();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3lwaGVyVXRpbHMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL3V0aWxzL2N5cGhlclV0aWxzLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBRUgsWUFBWSxDQUFDO0FBRWIsTUFBTSxFQUFFLFVBQVUsRUFBRSxjQUFjLEVBQUUsR0FBRyxPQUFPLENBQUMsdUJBQXVCLENBQUMsQ0FBQztBQUN4RSxNQUFNLFdBQVcsR0FBRyxPQUFPLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxXQUFXLENBQUM7QUFDdEUsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUM7QUFDdEMsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzdCLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUUvQixNQUFNLHVCQUF1QixHQUFHO0lBQzlCLEtBQUssRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTTtDQUNoRixDQUFDLElBQUksRUFBRSxDQUFDO0FBRVQsTUFBTSxlQUFlLEdBQUcsSUFBSSxNQUFNLENBQ2hDLFlBQVksR0FBRyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsY0FBYyxFQUFFLEdBQUcsQ0FDdkUsQ0FBQztBQUVGLE1BQU0sV0FBVztJQUNmOzs7Ozs7T0FNRztJQUNILFVBQVUsQ0FBQyxDQUFDO1FBQ1YsT0FBTyxHQUFHLEdBQUcsV0FBVyxDQUFDLFVBQVUsQ0FBQyxDQUFDLEVBQUUsR0FBRyxFQUFFLElBQUksQ0FBQyxHQUFHLEdBQUcsQ0FBQztJQUMxRCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsV0FBVyxDQUFDLENBQUM7UUFDWCxJQUFJLENBQUMsWUFBWSxVQUFVLEVBQUU7WUFDM0IsT0FBTyxTQUFTLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztTQUMzQzthQUFNLElBQUksQ0FBQyxZQUFZLGNBQWMsRUFBRTtZQUN0QyxJQUFJLENBQUMsQ0FBQyxJQUFJLEVBQUU7Z0JBQ1YsT0FBTyxhQUFhLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDO2FBQ2pDO2lCQUFNO2dCQUNMLE9BQU8sa0JBQWtCLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDO2FBQ3RDO1NBQ0Y7UUFFRCxJQUFJLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxPQUFPLENBQUMsS0FBSyxRQUFRLEVBQUU7WUFDeEMsT0FBTyxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsQ0FBQztTQUN0QztRQUVELE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUMzQixDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsYUFBYSxDQUFDLEdBQUc7UUFDZixPQUFPLEdBQUcsR0FBRyxHQUFHLENBQUMsSUFBSSxFQUFFLEdBQUcsR0FBRyxDQUFDO0lBQ2hDLENBQUM7SUFFRDs7T0FFRztJQUNILE9BQU8sQ0FBQyxLQUFLO1FBQ1gsMkNBQTJDO1FBQzNDLHNFQUFzRTtRQUN0RSxNQUFNLGVBQWUsR0FBRyxLQUFLLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDL0UsT0FBTyxlQUFlLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxVQUFVLENBQUMsS0FBSztRQUNkLDJDQUEyQztRQUMzQyxzRUFBc0U7UUFDdEUsTUFBTSxlQUFlLEdBQUcsS0FBSyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBRS9FLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQ3JDLE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FDbkIsbUJBQW1CLEVBQUUsbURBQW1ELENBQUMsQ0FBQztTQUM3RTtRQUVELE1BQU0sS0FBSyxHQUFHLGVBQWUsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7UUFDcEQsTUFBTSxTQUFTLEdBQUcsS0FBSyxLQUFLLElBQUksQ0FBQztRQUVqQyxJQUFJLFNBQVMsRUFBRTtZQUNiLE9BQU8sSUFBSSxDQUFDO1NBQ2I7UUFFRCxPQUFPLEtBQUssQ0FBQztJQUNmLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILHVCQUF1QixDQUFDLEtBQUs7UUFDM0IsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLENBQUMsRUFBRTtZQUNsQyxPQUFPLFdBQVcsS0FBSyxFQUFFLENBQUM7U0FDM0I7UUFDRCxPQUFPLEtBQUssQ0FBQztJQUNmLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsSUFBSSxXQUFXLEVBQUUsQ0FBQyJ9