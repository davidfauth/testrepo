/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-08-23.
 */
'use strict';
const _ = require('lodash');
const StringUtils = require('../../../lib/StringUtils').StringUtils;
const LKE = require('../../services');
const Utils = LKE.getUtils();
class DaoUtils {
    /**
     * Tokenize `searchString` and apply `fuzziness` to each token if required.
     * Depending on `useEditDistance` we use:
     * - The normalized edit similarity, e.g.: term~0.7
     * - The edit distance, e.g.: term~2
     *
     * The last token is considered as a prefix.
     *
     * If `fields` is defined, repeat the query for every field, e.g.:
     * `"miao" miao~0.7` becomes `field1:("miao" miao~0.7) field2:("miao" miao~0.7)`
     *
     * Reference:
     * http://lucene.apache.org/core/5_3_0/queryparser/org/apache/lucene/queryparser/classic/package-summary.html#package_description
     *
     * @param {string}   searchString
     * @param {number}   fuzziness                 Acceptable normalized edit distance among the query and the result. The edit distance is length(searchToken) * fuzziness
     * @param {object}   options
     * @param {string[]} [options.fields]          If defined, repeat the query for every field
     * @param {boolean}  [options.useEditDistance] Use edit distance in the query instead of normalized edit similarity
     * @param {number}   [options.minLengthPrefix]
     * @returns {string}
     */
    generateLuceneQuery(searchString, fuzziness, options) {
        options = _.defaults(options, { minLengthPrefix: 2 });
        const tokens = StringUtils.uniqTokenize(searchString);
        const searchClauses = [this.encodeLucenePhrase(searchString)];
        const roundedFuzziness = Math.round(fuzziness * 10) / 10;
        const normalizedEditSimilarity = 1 - roundedFuzziness;
        for (let i = 0; i < tokens.length; i++) {
            const maxEditDistance = Math.round(tokens[i].length * fuzziness);
            if (roundedFuzziness === 0) {
                searchClauses.push(tokens[i]);
            }
            else {
                searchClauses.push(tokens[i] + '~' + (options.useEditDistance
                    ? maxEditDistance : normalizedEditSimilarity));
            }
            if (i === tokens.length - 1 && // last token has to be treated differently because it will be used also as a prefix
                (Utils.noValue(options.minLengthPrefix) || options.minLengthPrefix <= tokens[i].length)) {
                searchClauses.push(tokens[i] + '*');
            }
        }
        let query;
        if (Utils.noValue(options.fields)) {
            query = searchClauses.join(' ');
        }
        else {
            query = _.map(options.fields, field => `${this.encodeLuceneTerm(field)}:(${searchClauses.join(' ')})`).join(' ');
        }
        return query;
    }
    /**
     *
     * @param {string} term
     * @returns {string}
     */
    encodeLuceneTerm(term) {
        // special chars:
        // + - & | ! ( ) { } [ ] ^ " ~ * ? : \ /
        // and blank space
        return term.replace(/([\s+\-&|!(){}[\]^"~*?:\\/])/g, '\\$1');
    }
    /**
     *
     * @param {string} value
     * @returns {string}
     */
    encodeLucenePhrase(value) {
        return JSON.stringify(value);
    }
}
module.exports = new DaoUtils();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGFvVXRpbHMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL3V0aWxzL2Rhb1V0aWxzLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBRUgsWUFBWSxDQUFDO0FBQ2IsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVCLE1BQU0sV0FBVyxHQUFHLE9BQU8sQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLFdBQVcsQ0FBQztBQUNwRSxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztBQUN0QyxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFFN0IsTUFBTSxRQUFRO0lBRVo7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQXFCRztJQUNILG1CQUFtQixDQUFDLFlBQVksRUFBRSxTQUFTLEVBQUUsT0FBTztRQUNsRCxPQUFPLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsRUFBQyxlQUFlLEVBQUUsQ0FBQyxFQUFDLENBQUMsQ0FBQztRQUVwRCxNQUFNLE1BQU0sR0FBRyxXQUFXLENBQUMsWUFBWSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBRXRELE1BQU0sYUFBYSxHQUFHLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7UUFFOUQsTUFBTSxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUM7UUFDekQsTUFBTSx3QkFBd0IsR0FBRyxDQUFDLEdBQUcsZ0JBQWdCLENBQUM7UUFFdEQsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDdEMsTUFBTSxlQUFlLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFHLFNBQVMsQ0FBQyxDQUFDO1lBRWpFLElBQUksZ0JBQWdCLEtBQUssQ0FBQyxFQUFFO2dCQUMxQixhQUFhLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQy9CO2lCQUFNO2dCQUNMLGFBQWEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLE9BQU8sQ0FBQyxlQUFlO29CQUMzRCxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDLENBQUM7YUFDbEQ7WUFFRCxJQUNFLENBQUMsS0FBSyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxvRkFBb0Y7Z0JBQy9HLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLElBQUksT0FBTyxDQUFDLGVBQWUsSUFBSSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQ3ZGO2dCQUNBLGFBQWEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDO2FBQ3JDO1NBQ0Y7UUFFRCxJQUFJLEtBQUssQ0FBQztRQUNWLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDakMsS0FBSyxHQUFHLGFBQWEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDakM7YUFBTTtZQUNMLEtBQUssR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLEVBQUUsQ0FDcEMsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLEtBQUssYUFBYSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQzdFO1FBRUQsT0FBTyxLQUFLLENBQUM7SUFDZixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILGdCQUFnQixDQUFDLElBQUk7UUFDbkIsaUJBQWlCO1FBQ2pCLHdDQUF3QztRQUN4QyxrQkFBa0I7UUFDbEIsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLCtCQUErQixFQUFFLE1BQU0sQ0FBQyxDQUFDO0lBQy9ELENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsa0JBQWtCLENBQUMsS0FBSztRQUN0QixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDL0IsQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxJQUFJLFFBQVEsRUFBRSxDQUFDIn0=