/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-02-18.
 */
'use strict';
const stream = require('stream');
const _ = require('lodash');
class GremlinStream extends stream.Readable {
    /**
     * @param {function(): Bluebird<any>} fetchNextPage
     * @param {function(): Bluebird<any>} [cleanup]
     * @constructor
     */
    constructor(fetchNextPage, cleanup) {
        // We maintain our own buffer for paging purposes.
        // It is different from the readable stream internal buffer.
        // That internal buffer fills up due to back-pressure otherwise it is consumed immediately
        // But for the abort signal to be immediate, we do not want anything queued in the internal buffer.
        // So we set highWaterMark to 0 to immediately emit any data pushed in.
        super({ objectMode: true, highWaterMark: 0 });
        this.buffer = [];
        this.fetchNextPage = fetchNextPage;
        this.cleanup = cleanup;
    }
    abort() {
        this.buffer = [null];
        this.cleanup && this.cleanup();
    }
    _read() {
        // The reader reads until the internal buffer is full
        // This method is not called again until `push` is called
        if (_.isEmpty(this.buffer)) {
            this.fetchNextPage().then(page => {
                if (_.isEmpty(page)) {
                    this.buffer.push(null);
                    this.cleanup && this.cleanup();
                }
                else {
                    if (_.isArray(page)) {
                        // Flatten the page
                        _.forEach(page, result => this.buffer.push(result));
                    }
                    else {
                        this.buffer.push(page);
                    }
                }
                // emit the next element in the buffer
                this.push(this.buffer.shift());
            }).catch(error => {
                const message = error.message || '';
                if (message.includes('No signature of method') ||
                    message.includes('Cannot invoke method hasNext()')) {
                    error.message = 'Please submit a gremlin traversal. Error: ' + message;
                }
                this.destroy(error);
            });
        }
        else {
            process.nextTick(() => this.push(this.buffer.shift()));
        }
    }
}
module.exports = GremlinStream;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JlbWxpblN0cmVhbS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9kYW8vdXRpbHMvZ3JlbWxpblN0cmVhbS5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7R0FLRztBQUNILFlBQVksQ0FBQztBQUNiLE1BQU0sTUFBTSxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNqQyxNQUFNLENBQUMsR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFFNUIsTUFBTSxhQUFjLFNBQVEsTUFBTSxDQUFDLFFBQVE7SUFDekM7Ozs7T0FJRztJQUNILFlBQVksYUFBYSxFQUFFLE9BQU87UUFDaEMsa0RBQWtEO1FBQ2xELDREQUE0RDtRQUM1RCwwRkFBMEY7UUFDMUYsbUdBQW1HO1FBQ25HLHVFQUF1RTtRQUN2RSxLQUFLLENBQUMsRUFBQyxVQUFVLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUFDO1FBQzVDLElBQUksQ0FBQyxNQUFNLEdBQUcsRUFBRSxDQUFDO1FBQ2pCLElBQUksQ0FBQyxhQUFhLEdBQUcsYUFBYSxDQUFDO1FBQ25DLElBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO0lBQ3pCLENBQUM7SUFFRCxLQUFLO1FBQ0gsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3JCLElBQUksQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO0lBQ2pDLENBQUM7SUFFRCxLQUFLO1FBQ0gscURBQXFEO1FBQ3JELHlEQUF5RDtRQUN6RCxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQzFCLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQy9CLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRTtvQkFDbkIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQ3ZCLElBQUksQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO2lCQUNoQztxQkFBTTtvQkFDTCxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUU7d0JBQ25CLG1CQUFtQjt3QkFDbkIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO3FCQUNyRDt5QkFBTTt3QkFDTCxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztxQkFDeEI7aUJBQ0Y7Z0JBRUQsc0NBQXNDO2dCQUN0QyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQztZQUNqQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQ2YsTUFBTSxPQUFPLEdBQUcsS0FBSyxDQUFDLE9BQU8sSUFBSSxFQUFFLENBQUM7Z0JBQ3BDLElBQUksT0FBTyxDQUFDLFFBQVEsQ0FBQyx3QkFBd0IsQ0FBQztvQkFDNUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxnQ0FBZ0MsQ0FBQyxFQUFFO29CQUNwRCxLQUFLLENBQUMsT0FBTyxHQUFHLDRDQUE0QyxHQUFHLE9BQU8sQ0FBQztpQkFDeEU7Z0JBQ0QsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUN0QixDQUFDLENBQUMsQ0FBQztTQUNKO2FBQU07WUFDTCxPQUFPLENBQUMsUUFBUSxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7U0FDeEQ7SUFDSCxDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLGFBQWEsQ0FBQyJ9