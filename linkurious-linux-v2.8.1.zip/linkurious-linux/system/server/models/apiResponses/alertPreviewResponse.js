"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * @apiDefine AlertPreviewResponse
 *
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *
 *   }
 */
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWxlcnRQcmV2aWV3UmVzcG9uc2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvbW9kZWxzL2FwaVJlc3BvbnNlcy9hbGVydFByZXZpZXdSZXNwb25zZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQWdCQTs7Ozs7Ozs7R0FRRyJ9