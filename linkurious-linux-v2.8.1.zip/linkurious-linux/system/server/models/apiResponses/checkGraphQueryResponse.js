"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * @apiDefine CheckGraphQueryResponse
 *
 * @apiSuccess {string="static","template"}                 type             Type of the graph query
 * @apiSuccess {boolean}                                    write            Whether the query may write the database
 * @apiSuccess {string="none","1-node","2-nodes","nodeset"} [graphInput]     Type of inputs to the template query (if `type="template"`)
 * @apiSuccess {object}                                     [templateFields] Parsed template fields (if `type="template"`)
 *
 * @apiSuccessExample {none} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *     "write": false,
 *     "graphInput": "2-nodes",
 *     "templateFields": [
 *       {
 *         "key": "src",
 *         "type": "node"
 *       },
 *       {
 *         "key": "dst",
 *         "type": "node"
 *       }
 *     ],
 *     "type": "template"
 *   }
 */
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2hlY2tHcmFwaFF1ZXJ5UmVzcG9uc2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvbW9kZWxzL2FwaVJlc3BvbnNlcy9jaGVja0dyYXBoUXVlcnlSZXNwb25zZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQWlCQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQXlCRyJ9