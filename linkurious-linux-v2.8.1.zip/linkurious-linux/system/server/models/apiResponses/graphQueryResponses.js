"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-01-22.
 */
const umd_1 = require("linkurious-shared/umd");
const _ = require("lodash");
const LKE = require("../../services");
const graphQueryParams_1 = require("../parameters/graphQueryParams");
const Utils = LKE.getUtils();
var RIGHT_VALUES;
(function (RIGHT_VALUES) {
    RIGHT_VALUES["OWNER"] = "owner";
    RIGHT_VALUES["READ"] = "read";
})(RIGHT_VALUES = exports.RIGHT_VALUES || (exports.RIGHT_VALUES = {}));
/**
 * @apiDefine GraphQueryResponse
 *
 * @apiSuccess {number}                                     id                 ID of the graph query
 * @apiSuccess {string}                                     sourceKey          Key of the data-source
 * @apiSuccess {string}                                     name               Name of the graph query
 * @apiSuccess {string}                                     content            Content of the graph query
 * @apiSuccess {string="cypher","gremlin"}                  dialect            Dialect of the graph query
 * @apiSuccess {string}                                     description        Description of the graph query
 * @apiSuccess {string="private","source","groups"}         sharing            Sharing policy of the graph query
 * @apiSuccess {number[]}                                   [sharedWithGroups] IDs of the groups the graph query is shared with (if `sharing="groups"`)
 * @apiSuccess {boolean}                                    write              Whether the query may write the database
 * @apiSuccess {string="none","1-node","2-nodes","nodeset"} [graphInput]       Type of inputs to the template query (if `type="template"`)
 * @apiSuccess {boolean}                                    builtin            Whether the query is builtin
 * @apiSuccess {object}                                     [templateFields]   Parsed template fields (if `type="template"`)
 * @apiSuccess {string="static","template"}                 type               Type of the graph query
 * @apiSuccess {string="owner","read"}                      right              Current user's right on the query
 * @apiSuccess {string}                                     createdAt          Creation date in ISO-8601 format
 * @apiSuccess {string}                                     updatedAt          Last update date in ISO-8601 format
 *
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *
 *   }
 */
/**
 * @apiDefine GetAllGraphQueriesResponse
 * @apiSuccess {object[]}                                   queries                    Graph queries
 * @apiSuccess {number}                                     queries.id                 ID of the graph query
 * @apiSuccess {string}                                     queries.sourceKey          Key of the data-source
 * @apiSuccess {string}                                     queries.name               Name of the graph query
 * @apiSuccess {string}                                     queries.content            Content of the graph query
 * @apiSuccess {string="cypher","gremlin"}                  queries.dialect            Dialect of the graph query
 * @apiSuccess {string}                                     queries.description        Description of the graph query
 * @apiSuccess {string="private","source","groups"}         queries.sharing            Sharing policy of the graph query
 * @apiSuccess {number[]}                                   queries.[sharedWithGroups] IDs of the groups the graph query is shared with (if `sharing="groups"`)
 * @apiSuccess {boolean}                                    queries.write              Whether the query may write the database
 * @apiSuccess {string="none","1-node","2-nodes","nodeset"} queries.[graphInput]       Type of inputs to the template query (if `type="template"`)
 * @apiSuccess {boolean}                                    queries.builtin            Whether the query is builtin
 * @apiSuccess {object}                                     queries.[templateFields]   Parsed template fields (if `type="template"`)
 * @apiSuccess {string="static","template"}                 queries.type               Type of the graph query
 * @apiSuccess {string="owner","read"}                      queries.right              Current user's right on the query
 * @apiSuccess {string}                                     queries.createdAt          Creation date in ISO-8601 format
 * @apiSuccess {string}                                     queries.updatedAt          Last update date in ISO-8601 format
 *
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *
 *   }
 */
class GraphQueryResponse {
    static fromInstance(graphQueryInstance, ownership, isWrite, groupInstances) {
        const graphQuery = graphQueryInstance.toJSON();
        return {
            id: graphQuery.id,
            sourceKey: graphQuery.sourceKey,
            name: graphQuery.name,
            content: graphQuery.content,
            dialect: graphQuery.dialect,
            description: graphQuery.description,
            sharing: graphQuery.sharing,
            sharedWithGroups: Utils.hasValue(groupInstances) ? _.map(groupInstances, 'id') : undefined,
            type: graphQuery.type,
            // fallback to undefined here to avoid returning a null templateFields
            templateFields: graphQuery.templateFields || undefined,
            graphInput: Utils.hasValue(graphQuery.templateFields)
                ? umd_1.QueryTemplateParser.getInputType(graphQuery.templateFields)
                : undefined,
            write: isWrite,
            createdAt: graphQuery.createdAt,
            updatedAt: graphQuery.updatedAt,
            builtin: false,
            right: ownership ? RIGHT_VALUES.OWNER : RIGHT_VALUES.READ
        };
    }
    static fromBuiltin(query) {
        return {
            id: query.id,
            sourceKey: query.sourceKey,
            name: query.name,
            content: query.content,
            dialect: query.dialect,
            description: query.description,
            sharing: graphQueryParams_1.GraphQuerySharingMode.SOURCE,
            type: query.type || graphQueryParams_1.GraphQueryType.STATIC,
            templateFields: query.templateFields,
            graphInput: query.graphInput,
            write: query.write,
            builtin: true,
            right: RIGHT_VALUES.READ
        };
    }
}
exports.GraphQueryResponse = GraphQueryResponse;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGhRdWVyeVJlc3BvbnNlcy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9tb2RlbHMvYXBpUmVzcG9uc2VzL2dyYXBoUXVlcnlSZXNwb25zZXMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQTs7Ozs7R0FLRztBQUNILCtDQUF5RjtBQUN6Riw0QkFBNEI7QUFFNUIsc0NBQXVDO0FBRXZDLHFFQUl3QztBQUV4QyxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFFN0IsSUFBWSxZQUdYO0FBSEQsV0FBWSxZQUFZO0lBQ3RCLCtCQUFlLENBQUE7SUFDZiw2QkFBYSxDQUFBO0FBQ2YsQ0FBQyxFQUhXLFlBQVksR0FBWixvQkFBWSxLQUFaLG9CQUFZLFFBR3ZCO0FBMEJEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBeUJHO0FBRUg7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0F5Qkc7QUFDSCxNQUFhLGtCQUFrQjtJQUN0QixNQUFNLENBQUMsWUFBWSxDQUN4QixrQkFBc0MsRUFDdEMsU0FBa0IsRUFDbEIsT0FBZ0IsRUFDaEIsY0FBZ0M7UUFFaEMsTUFBTSxVQUFVLEdBQUcsa0JBQWtCLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDL0MsT0FBTztZQUNMLEVBQUUsRUFBRSxVQUFVLENBQUMsRUFBRTtZQUNqQixTQUFTLEVBQUUsVUFBVSxDQUFDLFNBQVM7WUFDL0IsSUFBSSxFQUFFLFVBQVUsQ0FBQyxJQUFJO1lBQ3JCLE9BQU8sRUFBRSxVQUFVLENBQUMsT0FBTztZQUMzQixPQUFPLEVBQUUsVUFBVSxDQUFDLE9BQU87WUFDM0IsV0FBVyxFQUFFLFVBQVUsQ0FBQyxXQUFXO1lBQ25DLE9BQU8sRUFBRSxVQUFVLENBQUMsT0FBTztZQUMzQixnQkFBZ0IsRUFBRSxLQUFLLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUztZQUMxRixJQUFJLEVBQUUsVUFBVSxDQUFDLElBQUk7WUFDckIsc0VBQXNFO1lBQ3RFLGNBQWMsRUFBRSxVQUFVLENBQUMsY0FBYyxJQUFJLFNBQVM7WUFDdEQsVUFBVSxFQUFFLEtBQUssQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQztnQkFDbkQsQ0FBQyxDQUFDLHlCQUFtQixDQUFDLFlBQVksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDO2dCQUM3RCxDQUFDLENBQUMsU0FBUztZQUNiLEtBQUssRUFBRSxPQUFPO1lBQ2QsU0FBUyxFQUFFLFVBQVUsQ0FBQyxTQUFTO1lBQy9CLFNBQVMsRUFBRSxVQUFVLENBQUMsU0FBUztZQUMvQixPQUFPLEVBQUUsS0FBSztZQUNkLEtBQUssRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxJQUFJO1NBQzFELENBQUM7SUFDSixDQUFDO0lBRU0sTUFBTSxDQUFDLFdBQVcsQ0FBQyxLQUFtQjtRQUMzQyxPQUFPO1lBQ0wsRUFBRSxFQUFFLEtBQUssQ0FBQyxFQUFFO1lBQ1osU0FBUyxFQUFFLEtBQUssQ0FBQyxTQUFTO1lBQzFCLElBQUksRUFBRSxLQUFLLENBQUMsSUFBSTtZQUNoQixPQUFPLEVBQUUsS0FBSyxDQUFDLE9BQU87WUFDdEIsT0FBTyxFQUFFLEtBQUssQ0FBQyxPQUFPO1lBQ3RCLFdBQVcsRUFBRSxLQUFLLENBQUMsV0FBVztZQUM5QixPQUFPLEVBQUUsd0NBQXFCLENBQUMsTUFBTTtZQUNyQyxJQUFJLEVBQUUsS0FBSyxDQUFDLElBQUksSUFBSSxpQ0FBYyxDQUFDLE1BQU07WUFDekMsY0FBYyxFQUFFLEtBQUssQ0FBQyxjQUFjO1lBQ3BDLFVBQVUsRUFBRSxLQUFLLENBQUMsVUFBVTtZQUM1QixLQUFLLEVBQUUsS0FBSyxDQUFDLEtBQUs7WUFDbEIsT0FBTyxFQUFFLElBQUk7WUFDYixLQUFLLEVBQUUsWUFBWSxDQUFDLElBQUk7U0FDekIsQ0FBQztJQUNKLENBQUM7Q0FDRjtBQWhERCxnREFnREMifQ==