"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * @apiDefine RunGraphQueryResponse
 *
 * @apiSuccess {object[]} nodes            Nodes
 * @apiSuccess {string}   nodes.id         ID of the node
 * @apiSuccess {object}   nodes.data       Properties of the node
 * @apiSuccess {string[]} nodes.categories Categories of the node
 * @apiSuccess {number}   nodes.readAt     Read timestamp in epoch time
 * @apiSuccess {object}                                  [nodes.statistics]                 Statistics of the node
 * @apiSuccess {type:LkDigestItem[]}                     [nodes.statistics.digest]          Statistics of the neighborhood of the node
 * @apiSuccess {number}                                  [nodes.statistics.degree]          Number of neighbors of the node readable by the current user
 * @apiSuccess {type:LkEdgeDigestItem[]}                 [nodes.statistics.supernodeDigest] Simplified statistics of the neighborhood of the node (alternative to `digest` for supernodes)
 * @apiSuccess {number}                                  [nodes.statistics.supernodeDegree] Number of adjacent edges of the node (alternative to `degree` for supernodes)
 * @apiSuccess {object[]} edges            Edges
 * @apiSuccess {string}   edges.id         ID of the edge
 * @apiSuccess {object}   edges.data       Properties of the edge
 * @apiSuccess {string}   edges.type       Type of the edge
 * @apiSuccess {string}   edges.source     ID of the source node
 * @apiSuccess {string}   edges.target     ID of the target node
 * @apiSuccess {number}   edges.readAt     Read timestamp in epoch time
 * @apiSuccess {object}                                  [edges.statistics]                 Statistics of the edge
 *
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *
 *   }
 */
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicnVuR3JhcGhRdWVyeVJlc3BvbnNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL21vZGVscy9hcGlSZXNwb25zZXMvcnVuR3JhcGhRdWVyeVJlc3BvbnNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBZUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQTJCRyJ9