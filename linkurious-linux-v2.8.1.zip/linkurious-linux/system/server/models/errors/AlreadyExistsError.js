"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-06-21.
 */
Object.defineProperty(exports, "__esModule", { value: true });
// TS2019-DONE
const BusinessError_1 = require("./BusinessError");
class AlreadyExistsError extends BusinessError_1.BusinessError {
    constructor(description, item) {
        super('constraint_violation', ` ${description} "${item}" already exists.`);
    }
}
exports.AlreadyExistsError = AlreadyExistsError;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQWxyZWFkeUV4aXN0c0Vycm9yLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL21vZGVscy9lcnJvcnMvQWxyZWFkeUV4aXN0c0Vycm9yLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRzs7QUFFSCxjQUFjO0FBRWQsbURBQThDO0FBRTlDLE1BQWEsa0JBQW1CLFNBQVEsNkJBQWE7SUFDbkQsWUFBWSxXQUFtQixFQUFFLElBQVk7UUFDM0MsS0FBSyxDQUFDLHNCQUFzQixFQUFFLElBQUksV0FBVyxLQUFLLElBQUksbUJBQW1CLENBQUMsQ0FBQztJQUM3RSxDQUFDO0NBQ0Y7QUFKRCxnREFJQyJ9