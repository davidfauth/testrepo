"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-01-25.
 */
const TechnicalError_1 = require("./TechnicalError");
class Bug extends TechnicalError_1.TechnicalError {
    constructor(message) {
        super('bug', message);
    }
}
exports.Bug = Bug;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQnVnLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL21vZGVscy9lcnJvcnMvQnVnLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUE7Ozs7O0dBS0c7QUFDSCxxREFBZ0Q7QUFFaEQsTUFBYSxHQUFJLFNBQVEsK0JBQWM7SUFDckMsWUFBWSxPQUFlO1FBQ3pCLEtBQUssQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFDeEIsQ0FBQztDQUNGO0FBSkQsa0JBSUMifQ==