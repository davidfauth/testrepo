"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-02-01.
 */
Object.defineProperty(exports, "__esModule", { value: true });
// TS2019-DONE
const LkError_1 = require("./LkError");
class BusinessError extends LkError_1.LkError {
    constructor(key, message, data) {
        super(LkError_1.ErrorType.BUSINESS, key, message, data);
    }
}
exports.BusinessError = BusinessError;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQnVzaW5lc3NFcnJvci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9tb2RlbHMvZXJyb3JzL0J1c2luZXNzRXJyb3IudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7OztHQUtHOztBQUVILGNBQWM7QUFFZCx1Q0FBNkM7QUFFN0MsTUFBYSxhQUFjLFNBQVEsaUJBQU87SUFDeEMsWUFBWSxHQUFXLEVBQUUsT0FBZSxFQUFFLElBQWM7UUFDdEQsS0FBSyxDQUFDLG1CQUFTLENBQUMsUUFBUSxFQUFFLEdBQUcsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDaEQsQ0FBQztDQUNGO0FBSkQsc0NBSUMifQ==