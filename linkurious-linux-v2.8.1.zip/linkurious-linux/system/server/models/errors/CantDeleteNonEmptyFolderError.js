"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-06-21.
 */
Object.defineProperty(exports, "__esModule", { value: true });
// TS2019-DONE
const BusinessError_1 = require("./BusinessError");
class CantDeleteNonEmptyFolderError extends BusinessError_1.BusinessError {
    constructor() {
        super('folder_deletion_failed', 'Cannot delete a folder that is not empty,' +
            ' move or delete the content before deleting the folder.');
    }
}
exports.CantDeleteNonEmptyFolderError = CantDeleteNonEmptyFolderError;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQ2FudERlbGV0ZU5vbkVtcHR5Rm9sZGVyRXJyb3IuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvbW9kZWxzL2Vycm9ycy9DYW50RGVsZXRlTm9uRW1wdHlGb2xkZXJFcnJvci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7O0dBS0c7O0FBRUgsY0FBYztBQUVkLG1EQUE4QztBQUU5QyxNQUFhLDZCQUE4QixTQUFRLDZCQUFhO0lBQzlEO1FBQ0UsS0FBSyxDQUNILHdCQUF3QixFQUN4QiwyQ0FBMkM7WUFDekMseURBQXlELENBQzVELENBQUM7SUFDSixDQUFDO0NBQ0Y7QUFSRCxzRUFRQyJ9