"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-01-25.
 */
const AccessError_1 = require("./AccessError");
class CantReadError extends AccessError_1.AccessError {
    constructor(itemType, itemId, userId) {
        super('forbidden', `User #${userId} isn't allowed to read ${itemType} #${itemId}.`);
    }
}
exports.CantReadError = CantReadError;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQ2FudFJlYWRFcnJvci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9tb2RlbHMvZXJyb3JzL0NhbnRSZWFkRXJyb3IudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQTs7Ozs7R0FLRztBQUNILCtDQUEwQztBQUUxQyxNQUFhLGFBQWMsU0FBUSx5QkFBVztJQUM1QyxZQUFZLFFBQWdCLEVBQUUsTUFBYyxFQUFFLE1BQWM7UUFDMUQsS0FBSyxDQUFDLFdBQVcsRUFBRSxTQUFTLE1BQU0sMEJBQTBCLFFBQVEsS0FBSyxNQUFNLEdBQUcsQ0FBQyxDQUFDO0lBQ3RGLENBQUM7Q0FDRjtBQUpELHNDQUlDIn0=