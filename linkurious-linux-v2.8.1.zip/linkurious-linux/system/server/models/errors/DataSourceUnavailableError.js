"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-08-08.
 */
const BusinessError_1 = require("./BusinessError");
class DataSourceUnavailableError extends BusinessError_1.BusinessError {
    constructor(sourceKey) {
        super('dataSource_unavailable', `Data-source ${sourceKey} not found or not connected.`);
    }
}
exports.DataSourceUnavailableError = DataSourceUnavailableError;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiRGF0YVNvdXJjZVVuYXZhaWxhYmxlRXJyb3IuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvbW9kZWxzL2Vycm9ycy9EYXRhU291cmNlVW5hdmFpbGFibGVFcnJvci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBOzs7OztHQUtHO0FBQ0gsbURBQThDO0FBRTlDLE1BQWEsMEJBQTJCLFNBQVEsNkJBQWE7SUFDM0QsWUFBWSxTQUFpQjtRQUMzQixLQUFLLENBQUMsd0JBQXdCLEVBQUUsZUFBZSxTQUFTLDhCQUE4QixDQUFDLENBQUM7SUFDMUYsQ0FBQztDQUNGO0FBSkQsZ0VBSUMifQ==