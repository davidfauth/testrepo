"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const BusinessError_1 = require("./BusinessError");
var Vendor;
(function (Vendor) {
    Vendor["NEO4J"] = "Neo4j";
    Vendor["GREMLIN_SERVER"] = "Gremlin Server";
    Vendor["LINKURIOUS"] = "Linkurious";
})(Vendor = exports.Vendor || (exports.Vendor = {}));
const VendorConfig = {
    NEO4J: 'dbms.transaction.timeout',
    GREMLIN_SERVER: 'scriptEvaluationTimeout',
    LINKURIOUS: 'advanced.rawQueryTimeout'
};
class GraphRequestTimeout extends BusinessError_1.BusinessError {
    constructor(vendor) {
        const key = VendorConfig[vendor];
        const message = 'The query failed to execute within the limit of the timeout';
        const debug = key ? `, Increase the value of "${key}" in the ${vendor} configuration.` : '.';
        super('graph_request_timeout', message + debug);
    }
}
exports.GraphRequestTimeout = GraphRequestTimeout;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiR3JhcGhSZXF1ZXN0VGltZW91dC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9tb2RlbHMvZXJyb3JzL0dyYXBoUmVxdWVzdFRpbWVvdXQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFRQSxtREFBOEM7QUFFOUMsSUFBWSxNQUlYO0FBSkQsV0FBWSxNQUFNO0lBQ2hCLHlCQUFlLENBQUE7SUFDZiwyQ0FBaUMsQ0FBQTtJQUNqQyxtQ0FBeUIsQ0FBQTtBQUMzQixDQUFDLEVBSlcsTUFBTSxHQUFOLGNBQU0sS0FBTixjQUFNLFFBSWpCO0FBRUQsTUFBTSxZQUFZLEdBQTBCO0lBQzFDLEtBQUssRUFBRSwwQkFBMEI7SUFDakMsY0FBYyxFQUFFLHlCQUF5QjtJQUN6QyxVQUFVLEVBQUUsMEJBQTBCO0NBQ3ZDLENBQUM7QUFFRixNQUFhLG1CQUFvQixTQUFRLDZCQUFhO0lBQ3BELFlBQVksTUFBYztRQUN4QixNQUFNLEdBQUcsR0FBRyxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDakMsTUFBTSxPQUFPLEdBQUcsNkRBQTZELENBQUM7UUFDOUUsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyw0QkFBNEIsR0FBRyxZQUFZLE1BQU0saUJBQWlCLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztRQUM3RixLQUFLLENBQUMsdUJBQXVCLEVBQUUsT0FBTyxHQUFHLEtBQUssQ0FBQyxDQUFDO0lBQ2xELENBQUM7Q0FDRjtBQVBELGtEQU9DIn0=