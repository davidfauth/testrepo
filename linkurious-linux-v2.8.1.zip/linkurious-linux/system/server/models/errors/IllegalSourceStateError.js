"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-06-21.
 */
Object.defineProperty(exports, "__esModule", { value: true });
// TS2019-DONE
const BusinessError_1 = require("./BusinessError");
class IllegalSourceStateError extends BusinessError_1.BusinessError {
    constructor(description) {
        super('illegal_source_state', description);
    }
}
exports.IllegalSourceStateError = IllegalSourceStateError;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiSWxsZWdhbFNvdXJjZVN0YXRlRXJyb3IuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvbW9kZWxzL2Vycm9ycy9JbGxlZ2FsU291cmNlU3RhdGVFcnJvci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7O0dBS0c7O0FBRUgsY0FBYztBQUVkLG1EQUE4QztBQUU5QyxNQUFhLHVCQUF3QixTQUFRLDZCQUFhO0lBQ3hELFlBQVksV0FBbUI7UUFDN0IsS0FBSyxDQUFDLHNCQUFzQixFQUFFLFdBQVcsQ0FBQyxDQUFDO0lBQzdDLENBQUM7Q0FDRjtBQUpELDBEQUlDIn0=