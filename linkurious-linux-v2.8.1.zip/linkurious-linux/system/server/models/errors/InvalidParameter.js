"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-01-31.
 */
const BusinessError_1 = require("./BusinessError");
class InvalidParameter extends BusinessError_1.BusinessError {
    constructor(message, data) {
        super('invalid_parameter', message, data);
    }
}
exports.InvalidParameter = InvalidParameter;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiSW52YWxpZFBhcmFtZXRlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9tb2RlbHMvZXJyb3JzL0ludmFsaWRQYXJhbWV0ZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQTs7Ozs7R0FLRztBQUNILG1EQUE4QztBQUU5QyxNQUFhLGdCQUFpQixTQUFRLDZCQUFhO0lBQ2pELFlBQVksT0FBZSxFQUFFLElBQWM7UUFDekMsS0FBSyxDQUFDLG1CQUFtQixFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQztJQUM1QyxDQUFDO0NBQ0Y7QUFKRCw0Q0FJQyJ9