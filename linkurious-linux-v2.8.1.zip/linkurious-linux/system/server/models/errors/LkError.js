"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-11-25.
 */
Object.defineProperty(exports, "__esModule", { value: true });
// TS2019-DONE
var ErrorType;
(function (ErrorType) {
    /**
     * A forbidden action (for business reasons)
     * e.g.:
     * - user A hasn't right to do action B
     */
    ErrorType["ACCESS"] = "ACCESS";
    /**
     * An invalid action (for business reasons)
     * e.g.:
     * - delete a node with an unknown node ID
     */
    ErrorType["BUSINESS"] = "BUSINESS";
    /**
     * Non-business internal errors that we cannot solve
     * e.g.:
     * - the SQLite database file is locked
     * - cannot listen on port 3000: already used
     */
    ErrorType["TECHNICAL"] = "TECHNICAL";
})(ErrorType = exports.ErrorType || (exports.ErrorType = {}));
class LkError extends Error {
    /**
     * @param type      Type of the error
     * @param key       Key of the error
     * @param [message] Human readable description of the error
     * @param [data]    Additional error information
     */
    constructor(type, key, message, data) {
        super(message === null || message === undefined ? '' : message);
        this.type = type;
        this.key = key;
        this.data = data;
        if (!LkError.isTechnicalType(type)) {
            this.stack = undefined;
        }
    }
    static get Type() {
        return ErrorType;
    }
    static isAccessType(type) {
        return type === ErrorType.ACCESS;
    }
    static isBusinessType(type) {
        return type === ErrorType.BUSINESS;
    }
    static isTechnicalType(type) {
        return type === ErrorType.TECHNICAL;
    }
    isAccess() {
        return LkError.isAccessType(this.type);
    }
    isBusiness() {
        return LkError.isBusinessType(this.type);
    }
    isTechnical() {
        return LkError.isTechnicalType(this.type);
    }
}
exports.LkError = LkError;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTGtFcnJvci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9tb2RlbHMvZXJyb3JzL0xrRXJyb3IudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7OztHQUtHOztBQUVILGNBQWM7QUFFZCxJQUFZLFNBc0JYO0FBdEJELFdBQVksU0FBUztJQUNuQjs7OztPQUlHO0lBQ0gsOEJBQWlCLENBQUE7SUFFakI7Ozs7T0FJRztJQUNILGtDQUFxQixDQUFBO0lBRXJCOzs7OztPQUtHO0lBQ0gsb0NBQXVCLENBQUE7QUFDekIsQ0FBQyxFQXRCVyxTQUFTLEdBQVQsaUJBQVMsS0FBVCxpQkFBUyxRQXNCcEI7QUFFRCxNQUFhLE9BQVEsU0FBUSxLQUFLO0lBS2hDOzs7OztPQUtHO0lBQ0gsWUFBWSxJQUFlLEVBQUUsR0FBVyxFQUFFLE9BQWdCLEVBQUUsSUFBYztRQUN4RSxLQUFLLENBQUMsT0FBTyxLQUFLLElBQUksSUFBSSxPQUFPLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRWhFLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ2pCLElBQUksQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDO1FBQ2YsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7UUFFakIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDbEMsSUFBSSxDQUFDLEtBQUssR0FBRyxTQUFTLENBQUM7U0FDeEI7SUFDSCxDQUFDO0lBRU0sTUFBTSxLQUFLLElBQUk7UUFDcEIsT0FBTyxTQUFTLENBQUM7SUFDbkIsQ0FBQztJQUVNLE1BQU0sQ0FBQyxZQUFZLENBQUMsSUFBWTtRQUNyQyxPQUFPLElBQUksS0FBSyxTQUFTLENBQUMsTUFBTSxDQUFDO0lBQ25DLENBQUM7SUFFTSxNQUFNLENBQUMsY0FBYyxDQUFDLElBQVk7UUFDdkMsT0FBTyxJQUFJLEtBQUssU0FBUyxDQUFDLFFBQVEsQ0FBQztJQUNyQyxDQUFDO0lBRU0sTUFBTSxDQUFDLGVBQWUsQ0FBQyxJQUFZO1FBQ3hDLE9BQU8sSUFBSSxLQUFLLFNBQVMsQ0FBQyxTQUFTLENBQUM7SUFDdEMsQ0FBQztJQUVNLFFBQVE7UUFDYixPQUFPLE9BQU8sQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFFTSxVQUFVO1FBQ2YsT0FBTyxPQUFPLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBRU0sV0FBVztRQUNoQixPQUFPLE9BQU8sQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQzVDLENBQUM7Q0FDRjtBQWxERCwwQkFrREMifQ==