"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-01-31.
 */
const InvalidParameter_1 = require("./InvalidParameter");
class MalformedQueryTemplate extends InvalidParameter_1.InvalidParameter {
    constructor(message, highlight) {
        super(message, highlight);
    }
}
exports.MalformedQueryTemplate = MalformedQueryTemplate;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTWFsZm9ybWVkUXVlcnlUZW1wbGF0ZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9tb2RlbHMvZXJyb3JzL01hbGZvcm1lZFF1ZXJ5VGVtcGxhdGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQTs7Ozs7R0FLRztBQUNILHlEQUFvRDtBQUVwRCxNQUFhLHNCQUF1QixTQUFRLG1DQUFnQjtJQUMxRCxZQUFZLE9BQWUsRUFBRSxTQUEwQjtRQUNyRCxLQUFLLENBQUMsT0FBTyxFQUFFLFNBQVMsQ0FBQyxDQUFDO0lBQzVCLENBQUM7Q0FDRjtBQUpELHdEQUlDIn0=