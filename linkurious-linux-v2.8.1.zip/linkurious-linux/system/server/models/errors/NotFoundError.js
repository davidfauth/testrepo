"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-01-25.
 */
Object.defineProperty(exports, "__esModule", { value: true });
// TS2019-DONE
const _ = require("lodash");
const BusinessError_1 = require("./BusinessError");
class NotFoundError extends BusinessError_1.BusinessError {
    constructor(itemType, wantedId) {
        super(itemType + '_not_found', `${_.capitalize(itemType)} #${wantedId} was not found.`);
    }
}
exports.NotFoundError = NotFoundError;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTm90Rm91bmRFcnJvci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9tb2RlbHMvZXJyb3JzL05vdEZvdW5kRXJyb3IudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7OztHQUtHOztBQUVILGNBQWM7QUFFZCw0QkFBNEI7QUFFNUIsbURBQThDO0FBRTlDLE1BQWEsYUFBYyxTQUFRLDZCQUFhO0lBQzlDLFlBQVksUUFBZ0IsRUFBRSxRQUF5QjtRQUNyRCxLQUFLLENBQUMsUUFBUSxHQUFHLFlBQVksRUFBRSxHQUFHLENBQUMsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLEtBQUssUUFBUSxpQkFBaUIsQ0FBQyxDQUFDO0lBQzFGLENBQUM7Q0FDRjtBQUpELHNDQUlDIn0=