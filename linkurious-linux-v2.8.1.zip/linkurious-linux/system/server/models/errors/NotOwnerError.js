"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-01-25.
 */
const _ = require("lodash");
const AccessError_1 = require("./AccessError");
class NotOwnerError extends AccessError_1.AccessError {
    constructor(itemType, itemId, userId) {
        super('forbidden', `${_.capitalize(itemType)} #${itemId} doesn't belong to user #${userId}.`);
    }
}
exports.NotOwnerError = NotOwnerError;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTm90T3duZXJFcnJvci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9tb2RlbHMvZXJyb3JzL05vdE93bmVyRXJyb3IudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQTs7Ozs7R0FLRztBQUNILDRCQUE0QjtBQUU1QiwrQ0FBMEM7QUFFMUMsTUFBYSxhQUFjLFNBQVEseUJBQVc7SUFDNUMsWUFBWSxRQUFnQixFQUFFLE1BQWMsRUFBRSxNQUFjO1FBQzFELEtBQUssQ0FBQyxXQUFXLEVBQUUsR0FBRyxDQUFDLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxLQUFLLE1BQU0sNEJBQTRCLE1BQU0sR0FBRyxDQUFDLENBQUM7SUFDaEcsQ0FBQztDQUNGO0FBSkQsc0NBSUMifQ==