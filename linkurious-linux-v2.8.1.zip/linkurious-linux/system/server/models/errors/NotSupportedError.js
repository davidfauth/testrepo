"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const BusinessError_1 = require("./BusinessError");
class NotSupportedError extends BusinessError_1.BusinessError {
    constructor(functionality, vendor) {
        super('not_supported', `${functionality} is not supported by ${vendor}.`);
    }
}
exports.NotSupportedError = NotSupportedError;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTm90U3VwcG9ydGVkRXJyb3IuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvbW9kZWxzL2Vycm9ycy9Ob3RTdXBwb3J0ZWRFcnJvci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQVFBLG1EQUE4QztBQUU5QyxNQUFhLGlCQUFrQixTQUFRLDZCQUFhO0lBQ2xELFlBQVksYUFBcUIsRUFBRSxNQUFjO1FBQy9DLEtBQUssQ0FBQyxlQUFlLEVBQUUsR0FBRyxhQUFhLHdCQUF3QixNQUFNLEdBQUcsQ0FBQyxDQUFDO0lBQzVFLENBQUM7Q0FDRjtBQUpELDhDQUlDIn0=