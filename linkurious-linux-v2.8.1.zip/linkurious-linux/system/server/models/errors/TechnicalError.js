"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-02-01.
 */
const LkError_1 = require("./LkError");
class TechnicalError extends LkError_1.LkError {
    constructor(key, message) {
        super(LkError_1.ErrorType.TECHNICAL, key, message);
    }
}
exports.TechnicalError = TechnicalError;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiVGVjaG5pY2FsRXJyb3IuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvbW9kZWxzL2Vycm9ycy9UZWNobmljYWxFcnJvci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBOzs7OztHQUtHO0FBQ0gsdUNBQTZDO0FBRTdDLE1BQWEsY0FBZSxTQUFRLGlCQUFPO0lBQ3pDLFlBQVksR0FBVyxFQUFFLE9BQWU7UUFDdEMsS0FBSyxDQUFDLG1CQUFTLENBQUMsU0FBUyxFQUFFLEdBQUcsRUFBRSxPQUFPLENBQUMsQ0FBQztJQUMzQyxDQUFDO0NBQ0Y7QUFKRCx3Q0FJQyJ9