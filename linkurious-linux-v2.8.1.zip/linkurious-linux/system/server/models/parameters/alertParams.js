"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-06-14.
 */
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
const valcheckDecorators_1 = require("../utils/valcheckDecorators");
const apiParams_1 = require("./apiParams");
const dataSourceParams_1 = require("./dataSourceParams");
/**
 * @apiDefine CreateAlertFolderParams
 *
 * @apiParam {-1}     [parent=-1] ID of the parent alert folder
 * @apiParam {string} title       Title
 */
class CreateAlertFolderParams extends dataSourceParams_1.DataSourceParams {
    constructor() {
        super(...arguments);
        // only one level of folder is allowed
        // a value of -1 (also the default value) means the parent folder is the root folder
        this.parent = -1;
    }
}
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.integerBetween({ min: -1, max: -1 })
], CreateAlertFolderParams.prototype, "parent", void 0);
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.required,
    valcheckDecorators_1.nonEmptyString
], CreateAlertFolderParams.prototype, "title", void 0);
exports.CreateAlertFolderParams = CreateAlertFolderParams;
/**
 * @apiDefine UpdateAlertFolderParams
 *
 * @apiParam {number} id       ID of the alert folder to modify
 * @apiParam {-1}     [parent] ID of the parent alert folder
 * @apiParam {string} [title]  Title
 */
class UpdateAlertFolderParams extends dataSourceParams_1.DataSourceParams {
}
__decorate([
    apiParams_1.ApiParam('path', apiParams_1.ApiParamParser.number),
    valcheckDecorators_1.required,
    valcheckDecorators_1.posInt
], UpdateAlertFolderParams.prototype, "id", void 0);
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.integerBetween({ min: -1, max: -1 })
], UpdateAlertFolderParams.prototype, "parent", void 0);
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.nonEmptyString
], UpdateAlertFolderParams.prototype, "title", void 0);
exports.UpdateAlertFolderParams = UpdateAlertFolderParams;
/**
 * @apiDefine DeleteAlertFolderParams
 *
 * @apiParam {number} id ID of the alert folder to delete
 */
class DeleteAlertFolderParams extends dataSourceParams_1.DataSourceParams {
}
__decorate([
    apiParams_1.ApiParam('path', apiParams_1.ApiParamParser.number),
    valcheckDecorators_1.required,
    valcheckDecorators_1.posInt
], DeleteAlertFolderParams.prototype, "id", void 0);
exports.DeleteAlertFolderParams = DeleteAlertFolderParams;
/**
 * @apiDefine GetAlertTreeParams
 */
class GetAlertTreeParams extends dataSourceParams_1.DataSourceParams {
}
exports.GetAlertTreeParams = GetAlertTreeParams;
/**
 * @apiDefine GetAlertParams
 *
 * @apiParam {number} id ID of the alert to get
 */
class GetAlertParams extends dataSourceParams_1.DataSourceParams {
}
__decorate([
    apiParams_1.ApiParam('path', apiParams_1.ApiParamParser.number),
    valcheckDecorators_1.required,
    valcheckDecorators_1.posInt
], GetAlertParams.prototype, "id", void 0);
exports.GetAlertParams = GetAlertParams;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWxlcnRQYXJhbXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvbW9kZWxzL3BhcmFtZXRlcnMvYWxlcnRQYXJhbXMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7OztHQUtHOzs7Ozs7OztBQVlILG9FQUE2RjtBQUU3RiwyQ0FBcUQ7QUFDckQseURBQW9EO0FBRXBEOzs7OztHQUtHO0FBQ0gsTUFBYSx1QkFBd0IsU0FBUSxtQ0FBZ0I7SUFBN0Q7O1FBQ0Usc0NBQXNDO1FBQ3RDLG9GQUFvRjtRQUc3RSxXQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFNckIsQ0FBQztDQUFBO0FBTkM7SUFGQyxvQkFBUSxDQUFDLE1BQU0sQ0FBQztJQUNoQixtQ0FBYyxDQUFDLEVBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBQyxDQUFDO3VEQUNoQjtBQUtuQjtJQUhDLG9CQUFRLENBQUMsTUFBTSxDQUFDO0lBQ2hCLDZCQUFRO0lBQ1IsbUNBQWM7c0RBQ087QUFWeEIsMERBV0M7QUFFRDs7Ozs7O0dBTUc7QUFDSCxNQUFhLHVCQUF3QixTQUFRLG1DQUFnQjtDQWE1RDtBQVRDO0lBSEMsb0JBQVEsQ0FBQyxNQUFNLEVBQUUsMEJBQWMsQ0FBQyxNQUFNLENBQUM7SUFDdkMsNkJBQVE7SUFDUiwyQkFBTTttREFDWTtBQUluQjtJQUZDLG9CQUFRLENBQUMsTUFBTSxDQUFDO0lBQ2hCLG1DQUFjLENBQUMsRUFBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQUUsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUFDLENBQUM7dURBQ1o7QUFJdkI7SUFGQyxvQkFBUSxDQUFDLE1BQU0sQ0FBQztJQUNoQixtQ0FBYztzREFDTztBQVp4QiwwREFhQztBQUVEOzs7O0dBSUc7QUFDSCxNQUFhLHVCQUF3QixTQUFRLG1DQUFnQjtDQUs1RDtBQURDO0lBSEMsb0JBQVEsQ0FBQyxNQUFNLEVBQUUsMEJBQWMsQ0FBQyxNQUFNLENBQUM7SUFDdkMsNkJBQVE7SUFDUiwyQkFBTTttREFDWTtBQUpyQiwwREFLQztBQUVEOztHQUVHO0FBQ0gsTUFBYSxrQkFBbUIsU0FBUSxtQ0FBZ0I7Q0FBa0M7QUFBMUYsZ0RBQTBGO0FBRTFGOzs7O0dBSUc7QUFDSCxNQUFhLGNBQWUsU0FBUSxtQ0FBZ0I7Q0FLbkQ7QUFEQztJQUhDLG9CQUFRLENBQUMsTUFBTSxFQUFFLDBCQUFjLENBQUMsTUFBTSxDQUFDO0lBQ3ZDLDZCQUFRO0lBQ1IsMkJBQU07MENBQ1k7QUFKckIsd0NBS0MifQ==