"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * Created on 2018-12-28.
 */
Object.defineProperty(exports, "__esModule", { value: true });
// TS2019-DONE
const _ = require("lodash");
require("reflect-metadata");
const Bug_1 = require("../errors/Bug");
const InvalidParameter_1 = require("../errors/InvalidParameter");
const valcheck_1 = require("../utils/valcheck");
const valcheckDecorators_1 = require("../utils/valcheckDecorators");
const METADATA_KEY = Symbol('ApiParameterMetadata');
var ApiParamParser;
(function (ApiParamParser) {
    ApiParamParser["number"] = "number";
    ApiParamParser["boolean"] = "boolean";
})(ApiParamParser = exports.ApiParamParser || (exports.ApiParamParser = {}));
const queryParsers = {
    number: (value) => {
        return parseFloat(value);
    },
    boolean: (value) => {
        return value === 'true' || value === 'yes' || value === 'y' || value === '1';
    }
};
/**
 * Annotation.
 */
function ApiParam(source, parser) {
    return (target, propertyKey) => {
        const className = target.constructor.name;
        // check that target inherits from ApiParameters
        if (!(target instanceof ApiParams)) {
            throw new Bug_1.Bug(`Annotation @${ApiParam.name} can only used on instances of ` +
                `class ${ApiParams.name} (${className}.${propertyKey})`);
        }
        // Pull the existing stored metadata (or create an empty object)
        // WARNING: Cloning here is necessary to avoid sharing metadata across several classes
        // that inherit from a shared annotated class.
        const metadata = _.cloneDeep(Reflect.getMetadata(METADATA_KEY, target) || {});
        if (!metadata.apiParameters) {
            metadata.apiParameters = {};
        }
        const newMetadata = {
            source: source,
            parser: parser
        };
        const existingMetadata = metadata.apiParameters[propertyKey];
        if (existingMetadata !== undefined) {
            throw new Bug_1.Bug('Annotation @ApiParam is declared several times for field ' +
                `${className}.${propertyKey}: ${existingMetadata.source}, ${newMetadata.source}`);
        }
        // Update the metadata with anything from updates
        metadata.apiParameters[propertyKey] = newMetadata;
        // Update the stored metadata
        Reflect.defineMetadata(METADATA_KEY, metadata, target);
    };
}
exports.ApiParam = ApiParam;
class ApiParams {
    setFieldsFromHttpRequest(req) {
        const metadata = Reflect.getMetadata(METADATA_KEY, this);
        if (!metadata || !metadata.apiParameters) {
            throw new Bug_1.Bug(`Class ${this.constructor.name} has no @ApiParam annotation.`);
        }
        for (const key of Object.keys(req.params)) {
            this.parseParam(key, req.params[key], 'path', metadata.apiParameters[key]);
        }
        for (const key of Object.keys(req.query)) {
            if (key === '_' || key === 'guest') {
                // we want to ignore the `_` query parameter, used by the frontend to prevent API responses to be cached
                // we also want to ignore the `guest` query parameter, used by the access service to use the API as a guest user
                continue;
            }
            // we convert query parameters in snake_case to camelCase
            const tokens = _.map(key.split('_'));
            let snakeKey = tokens[0];
            for (let i = 1; i < tokens.length; i++) {
                snakeKey += tokens[i].charAt(0).toUpperCase() + tokens[i].slice(1);
            }
            this.parseParam(snakeKey, req.query[key], 'query', metadata.apiParameters[snakeKey]);
        }
        for (const key of Object.keys(req.body)) {
            this.parseParam(key, req.body[key], 'body', metadata.apiParameters[key]);
        }
    }
    parseParam(key, value, source, expected) {
        if (!expected) {
            throw new InvalidParameter_1.InvalidParameter(`Unexpected parameter "${key}" (found in ${source})`);
        }
        const correctSource = (Array.isArray(expected.source) && expected.source.includes(source)) ||
            expected.source === source;
        if (!correctSource) {
            throw new InvalidParameter_1.InvalidParameter(`Parameter "${key}" is expected in ${expected.source} (found in ${source})`);
        }
        // apply the parser if it is defined and the source is query or path
        if (expected.parser && (source === 'query' || source === 'path') && typeof value === 'string') {
            try {
                value = queryParsers[expected.parser](value);
            }
            catch (e) {
                throw new InvalidParameter_1.InvalidParameter(`Parser of ${source} parameter "${key}" failed: ${e.message}`);
            }
        }
        // Not changing the value when it is undefined allows to preserve the default field values
        // defined at the field initialization (e.g. `public foo: number = 12;`).
        if (value === undefined) {
            return;
        }
        // @ts-ignore key is an expected api param
        this[key] = value;
    }
    static parseRequest(apiParamsType, req) {
        const apiParams = new apiParamsType();
        apiParams.setFieldsFromHttpRequest(req);
        apiParams.validate();
        return apiParams;
    }
    fromRequest(req) {
        this.setFieldsFromHttpRequest(req);
        this.validate();
        return this;
    }
    getParamsDefinition() {
        return valcheckDecorators_1.getFieldDefinition(this);
    }
    validate() {
        // policy is inclusive because we don't want to validate additional
        // fields that are set internally and not from an API request
        valcheck_1.valcheck.properties(this.constructor.name, this, this.getParamsDefinition());
    }
}
exports.ApiParams = ApiParams;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBpUGFyYW1zLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL21vZGVscy9wYXJhbWV0ZXJzL2FwaVBhcmFtcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7O0dBS0c7O0FBRUgsY0FBYztBQUVkLDRCQUE0QjtBQUM1Qiw0QkFBMEI7QUFLMUIsdUNBQWtDO0FBQ2xDLGlFQUE0RDtBQUU1RCxnREFBMkM7QUFDM0Msb0VBQStEO0FBRS9ELE1BQU0sWUFBWSxHQUFHLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO0FBSXBELElBQVksY0FHWDtBQUhELFdBQVksY0FBYztJQUN4QixtQ0FBaUIsQ0FBQTtJQUNqQixxQ0FBbUIsQ0FBQTtBQUNyQixDQUFDLEVBSFcsY0FBYyxHQUFkLHNCQUFjLEtBQWQsc0JBQWMsUUFHekI7QUFFRCxNQUFNLFlBQVksR0FBRztJQUNuQixNQUFNLEVBQUUsQ0FBQyxLQUFhLEVBQVUsRUFBRTtRQUNoQyxPQUFPLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUMzQixDQUFDO0lBQ0QsT0FBTyxFQUFFLENBQUMsS0FBYSxFQUFXLEVBQUU7UUFDbEMsT0FBTyxLQUFLLEtBQUssTUFBTSxJQUFJLEtBQUssS0FBSyxLQUFLLElBQUksS0FBSyxLQUFLLEdBQUcsSUFBSSxLQUFLLEtBQUssR0FBRyxDQUFDO0lBQy9FLENBQUM7Q0FDRixDQUFDO0FBY0Y7O0dBRUc7QUFDSCxTQUFnQixRQUFRLENBQ3RCLE1BQXlDLEVBQ3pDLE1BQXVCO0lBRXZCLE9BQU8sQ0FBQyxNQUFjLEVBQUUsV0FBbUIsRUFBRSxFQUFFO1FBQzdDLE1BQU0sU0FBUyxHQUFHLE1BQU0sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDO1FBRTFDLGdEQUFnRDtRQUNoRCxJQUFJLENBQUMsQ0FBQyxNQUFNLFlBQVksU0FBUyxDQUFDLEVBQUU7WUFDbEMsTUFBTSxJQUFJLFNBQUcsQ0FDWCxlQUFlLFFBQVEsQ0FBQyxJQUFJLGlDQUFpQztnQkFDM0QsU0FBUyxTQUFTLENBQUMsSUFBSSxLQUFLLFNBQVMsSUFBSSxXQUFXLEdBQUcsQ0FDMUQsQ0FBQztTQUNIO1FBRUQsZ0VBQWdFO1FBQ2hFLHNGQUFzRjtRQUN0Riw4Q0FBOEM7UUFDOUMsTUFBTSxRQUFRLEdBQW9CLENBQUMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxZQUFZLEVBQUUsTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7UUFFL0YsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLEVBQUU7WUFDM0IsUUFBUSxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUM7U0FDN0I7UUFFRCxNQUFNLFdBQVcsR0FBRztZQUNsQixNQUFNLEVBQUUsTUFBTTtZQUNkLE1BQU0sRUFBRSxNQUFNO1NBQ2YsQ0FBQztRQUVGLE1BQU0sZ0JBQWdCLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUM3RCxJQUFJLGdCQUFnQixLQUFLLFNBQVMsRUFBRTtZQUNsQyxNQUFNLElBQUksU0FBRyxDQUNYLDJEQUEyRDtnQkFDekQsR0FBRyxTQUFTLElBQUksV0FBVyxLQUFLLGdCQUFnQixDQUFDLE1BQU0sS0FBSyxXQUFXLENBQUMsTUFBTSxFQUFFLENBQ25GLENBQUM7U0FDSDtRQUVELGlEQUFpRDtRQUNqRCxRQUFRLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxHQUFHLFdBQVcsQ0FBQztRQUVsRCw2QkFBNkI7UUFDN0IsT0FBTyxDQUFDLGNBQWMsQ0FBQyxZQUFZLEVBQUUsUUFBUSxFQUFFLE1BQU0sQ0FBQyxDQUFDO0lBQ3pELENBQUMsQ0FBQztBQUNKLENBQUM7QUEzQ0QsNEJBMkNDO0FBRUQsTUFBc0IsU0FBUztJQUNyQix3QkFBd0IsQ0FBQyxHQUFvQjtRQUNuRCxNQUFNLFFBQVEsR0FBb0IsT0FBTyxDQUFDLFdBQVcsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFFMUUsSUFBSSxDQUFDLFFBQVEsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLEVBQUU7WUFDeEMsTUFBTSxJQUFJLFNBQUcsQ0FBQyxTQUFTLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSwrQkFBK0IsQ0FBQyxDQUFDO1NBQzlFO1FBRUQsS0FBSyxNQUFNLEdBQUcsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUN6QyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxFQUFFLE1BQU0sRUFBRSxRQUFRLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7U0FDNUU7UUFDRCxLQUFLLE1BQU0sR0FBRyxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ3hDLElBQUksR0FBRyxLQUFLLEdBQUcsSUFBSSxHQUFHLEtBQUssT0FBTyxFQUFFO2dCQUNsQyx3R0FBd0c7Z0JBQ3hHLGdIQUFnSDtnQkFDaEgsU0FBUzthQUNWO1lBRUQseURBQXlEO1lBQ3pELE1BQU0sTUFBTSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1lBQ3JDLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN6QixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDdEMsUUFBUSxJQUFJLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxFQUFFLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUNwRTtZQUVELElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxFQUFFLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsT0FBTyxFQUFFLFFBQVEsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztTQUN0RjtRQUNELEtBQUssTUFBTSxHQUFHLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDdkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxNQUFNLEVBQUUsUUFBUSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1NBQzFFO0lBQ0gsQ0FBQztJQUVPLFVBQVUsQ0FDaEIsR0FBVyxFQUNYLEtBQWMsRUFDZCxNQUFzQixFQUN0QixRQUFvQztRQUVwQyxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ2IsTUFBTSxJQUFJLG1DQUFnQixDQUFDLHlCQUF5QixHQUFHLGVBQWUsTUFBTSxHQUFHLENBQUMsQ0FBQztTQUNsRjtRQUVELE1BQU0sYUFBYSxHQUNqQixDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLFFBQVEsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ3BFLFFBQVEsQ0FBQyxNQUFNLEtBQUssTUFBTSxDQUFDO1FBQzdCLElBQUksQ0FBQyxhQUFhLEVBQUU7WUFDbEIsTUFBTSxJQUFJLG1DQUFnQixDQUN4QixjQUFjLEdBQUcsb0JBQW9CLFFBQVEsQ0FBQyxNQUFNLGNBQWMsTUFBTSxHQUFHLENBQzVFLENBQUM7U0FDSDtRQUVELG9FQUFvRTtRQUNwRSxJQUFJLFFBQVEsQ0FBQyxNQUFNLElBQUksQ0FBQyxNQUFNLEtBQUssT0FBTyxJQUFJLE1BQU0sS0FBSyxNQUFNLENBQUMsSUFBSSxPQUFPLEtBQUssS0FBSyxRQUFRLEVBQUU7WUFDN0YsSUFBSTtnQkFDRixLQUFLLEdBQUcsWUFBWSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUM5QztZQUFDLE9BQU8sQ0FBQyxFQUFFO2dCQUNWLE1BQU0sSUFBSSxtQ0FBZ0IsQ0FBQyxhQUFhLE1BQU0sZUFBZSxHQUFHLGFBQWEsQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7YUFDM0Y7U0FDRjtRQUVELDBGQUEwRjtRQUMxRix5RUFBeUU7UUFDekUsSUFBSSxLQUFLLEtBQUssU0FBUyxFQUFFO1lBQ3ZCLE9BQU87U0FDUjtRQUVELDBDQUEwQztRQUMxQyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFDO0lBQ3BCLENBQUM7SUFFTSxNQUFNLENBQUMsWUFBWSxDQUN4QixhQUFpQyxFQUNqQyxHQUFvQjtRQUVwQixNQUFNLFNBQVMsR0FBRyxJQUFJLGFBQWEsRUFBRSxDQUFDO1FBQ3RDLFNBQVMsQ0FBQyx3QkFBd0IsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUN4QyxTQUFTLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDckIsT0FBTyxTQUFTLENBQUM7SUFDbkIsQ0FBQztJQUVNLFdBQVcsQ0FBQyxHQUFvQjtRQUNyQyxJQUFJLENBQUMsd0JBQXdCLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDbkMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBRWhCLE9BQU8sSUFBSSxDQUFDO0lBQ2QsQ0FBQztJQUVTLG1CQUFtQjtRQUMzQixPQUFPLHVDQUFrQixDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ2xDLENBQUM7SUFFTyxRQUFRO1FBQ2QsbUVBQW1FO1FBQ25FLDZEQUE2RDtRQUM3RCxtQkFBUSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUMsQ0FBQztJQUMvRSxDQUFDO0NBQ0Y7QUFoR0QsOEJBZ0dDIn0=