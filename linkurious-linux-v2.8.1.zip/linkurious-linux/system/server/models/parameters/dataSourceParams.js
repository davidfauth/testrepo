"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-02-02.
 */
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
const valcheckDecorators_1 = require("../utils/valcheckDecorators");
const apiParams_1 = require("./apiParams");
/**
 * @apiDefine DataSourceParams
 *
 * @apiParam {string} sourceKey Key of the data-source
 */
class DataSourceParams extends apiParams_1.ApiParams {
}
__decorate([
    apiParams_1.ApiParam('path'),
    valcheckDecorators_1.required,
    valcheckDecorators_1.check('string', true, true, 8)
], DataSourceParams.prototype, "sourceKey", void 0);
exports.DataSourceParams = DataSourceParams;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGF0YVNvdXJjZVBhcmFtcy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9tb2RlbHMvcGFyYW1ldGVycy9kYXRhU291cmNlUGFyYW1zLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRzs7Ozs7Ozs7QUFNSCxvRUFBNEQ7QUFFNUQsMkNBQWdEO0FBRWhEOzs7O0dBSUc7QUFDSCxNQUFhLGdCQUFpQixTQUFRLHFCQUFTO0NBSzlDO0FBREM7SUFIQyxvQkFBUSxDQUFDLE1BQU0sQ0FBQztJQUNoQiw2QkFBUTtJQUNSLDBCQUFLLENBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDO21EQUNJO0FBSnJDLDRDQUtDIn0=