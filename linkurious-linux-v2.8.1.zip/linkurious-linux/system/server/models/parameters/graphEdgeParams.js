"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-06-28.
 */
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
const valcheckDecorators_1 = require("../utils/valcheckDecorators");
const apiParams_1 = require("./apiParams");
const dataSourceParams_1 = require("./dataSourceParams");
/**
 * @apiDefine CreateEdgeParams
 * @apiParam {string} source     ID of the source node
 * @apiParam {string} target     ID of the target node
 * @apiParam {string} type       Type of the edge
 * @apiParam {object} properties Properties of the edge
 */
class CreateEdgeParams extends dataSourceParams_1.DataSourceParams {
    constructor() {
        super(...arguments);
        this.properties = {};
    }
}
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.check('objectKeys', undefined, undefined, [''])
], CreateEdgeParams.prototype, "properties", void 0);
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.required,
    valcheckDecorators_1.nonEmptyString
], CreateEdgeParams.prototype, "type", void 0);
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.required,
    valcheckDecorators_1.nonEmptyString
], CreateEdgeParams.prototype, "source", void 0);
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.required,
    valcheckDecorators_1.nonEmptyString
], CreateEdgeParams.prototype, "target", void 0);
exports.CreateEdgeParams = CreateEdgeParams;
/**
 * @apiDefine UpdateEdgeParams
 * @apiParam {string}   id                  ID of the edge to update
 * @apiParam {object}   [properties]        Properties to update or create
 * @apiParam {string[]} [deletedProperties] Properties to delete
 * @apiParam {number}   [readAt]            Read timestamp in epoch time
 */
class UpdateEdgeParams extends dataSourceParams_1.DataSourceParams {
    constructor() {
        super(...arguments);
        this.properties = {};
        this.deletedProperties = [];
    }
}
__decorate([
    apiParams_1.ApiParam('path'),
    valcheckDecorators_1.required,
    valcheckDecorators_1.nonEmptyString
], UpdateEdgeParams.prototype, "id", void 0);
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.check('objectKeys', undefined, undefined, [''])
], UpdateEdgeParams.prototype, "properties", void 0);
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.array(valcheckDecorators_1.nonEmptyString)
], UpdateEdgeParams.prototype, "deletedProperties", void 0);
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.posInt
], UpdateEdgeParams.prototype, "readAt", void 0);
exports.UpdateEdgeParams = UpdateEdgeParams;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGhFZGdlUGFyYW1zLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL21vZGVscy9wYXJhbWV0ZXJzL2dyYXBoRWRnZVBhcmFtcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7O0dBS0c7Ozs7Ozs7O0FBT0gsb0VBQTJGO0FBRTNGLDJDQUFxQztBQUNyQyx5REFBb0Q7QUFFcEQ7Ozs7OztHQU1HO0FBQ0gsTUFBYSxnQkFBaUIsU0FBUSxtQ0FBZ0I7SUFBdEQ7O1FBR2tCLGVBQVUsR0FBMkIsRUFBRSxDQUFDO0lBZ0IxRCxDQUFDO0NBQUE7QUFoQkM7SUFGQyxvQkFBUSxDQUFDLE1BQU0sQ0FBQztJQUNoQiwwQkFBSyxDQUFDLFlBQVksRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUM7b0RBQ1E7QUFLeEQ7SUFIQyxvQkFBUSxDQUFDLE1BQU0sQ0FBQztJQUNoQiw2QkFBUTtJQUNSLG1DQUFjOzhDQUNlO0FBSzlCO0lBSEMsb0JBQVEsQ0FBQyxNQUFNLENBQUM7SUFDaEIsNkJBQVE7SUFDUixtQ0FBYztnREFDaUI7QUFLaEM7SUFIQyxvQkFBUSxDQUFDLE1BQU0sQ0FBQztJQUNoQiw2QkFBUTtJQUNSLG1DQUFjO2dEQUNpQjtBQWxCbEMsNENBbUJDO0FBRUQ7Ozs7OztHQU1HO0FBQ0gsTUFBYSxnQkFBaUIsU0FBUSxtQ0FBZ0I7SUFBdEQ7O1FBUWtCLGVBQVUsR0FBMkIsRUFBRSxDQUFDO1FBSXhDLHNCQUFpQixHQUFhLEVBQUUsQ0FBQztJQUtuRCxDQUFDO0NBQUE7QUFiQztJQUhDLG9CQUFRLENBQUMsTUFBTSxDQUFDO0lBQ2hCLDZCQUFRO0lBQ1IsbUNBQWM7NENBQ2E7QUFJNUI7SUFGQyxvQkFBUSxDQUFDLE1BQU0sQ0FBQztJQUNoQiwwQkFBSyxDQUFDLFlBQVksRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUM7b0RBQ1E7QUFJeEQ7SUFGQyxvQkFBUSxDQUFDLE1BQU0sQ0FBQztJQUNoQiwwQkFBSyxDQUFDLG1DQUFjLENBQUM7MkRBQzJCO0FBSWpEO0lBRkMsb0JBQVEsQ0FBQyxNQUFNLENBQUM7SUFDaEIsMkJBQU07Z0RBQ3lCO0FBaEJsQyw0Q0FpQkMifQ==