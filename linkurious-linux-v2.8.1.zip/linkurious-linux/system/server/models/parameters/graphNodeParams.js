"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-06-28.
 */
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
const valcheckDecorators_1 = require("../utils/valcheckDecorators");
const apiParams_1 = require("./apiParams");
const dataSourceParams_1 = require("./dataSourceParams");
/**
 * @apiDefine CreateNodeParams
 * @apiParam {object}   [properties] Properties of the node
 * @apiParam {string[]} [categories] Categories of the node
 */
class CreateNodeParams extends dataSourceParams_1.DataSourceParams {
    constructor() {
        super(...arguments);
        this.properties = {};
    }
}
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.check('objectKeys', undefined, undefined, [''])
], CreateNodeParams.prototype, "properties", void 0);
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.required,
    valcheckDecorators_1.array(valcheckDecorators_1.nonEmptyString)
], CreateNodeParams.prototype, "categories", void 0);
exports.CreateNodeParams = CreateNodeParams;
/**
 * @apiDefine UpdateNodeParams
 * @apiParam {string}   id                  ID of the node to update
 * @apiParam {object}   [properties]        Properties to update or create
 * @apiParam {string[]} [deletedProperties] Properties to delete
 * @apiParam {string[]} [addedCategories]   Categories of the node to add
 * @apiParam {string[]} [deletedCategories] Categories of the node to delete
 * @apiParam {number}   [readAt]            Read timestamp in epoch time
 */
class UpdateNodeParams extends dataSourceParams_1.DataSourceParams {
    constructor() {
        super(...arguments);
        this.properties = {};
        this.deletedProperties = [];
        this.addedCategories = [];
        this.deletedCategories = [];
    }
}
__decorate([
    apiParams_1.ApiParam('path'),
    valcheckDecorators_1.required,
    valcheckDecorators_1.nonEmptyString
], UpdateNodeParams.prototype, "id", void 0);
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.check('objectKeys', undefined, undefined, [''])
], UpdateNodeParams.prototype, "properties", void 0);
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.array(valcheckDecorators_1.nonEmptyString)
], UpdateNodeParams.prototype, "deletedProperties", void 0);
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.array(valcheckDecorators_1.nonEmptyString)
], UpdateNodeParams.prototype, "addedCategories", void 0);
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.array(valcheckDecorators_1.nonEmptyString)
], UpdateNodeParams.prototype, "deletedCategories", void 0);
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.posInt
], UpdateNodeParams.prototype, "readAt", void 0);
exports.UpdateNodeParams = UpdateNodeParams;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGhOb2RlUGFyYW1zLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL21vZGVscy9wYXJhbWV0ZXJzL2dyYXBoTm9kZVBhcmFtcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7O0dBS0c7Ozs7Ozs7O0FBT0gsb0VBQTJGO0FBRTNGLDJDQUFxQztBQUNyQyx5REFBb0Q7QUFFcEQ7Ozs7R0FJRztBQUNILE1BQWEsZ0JBQWlCLFNBQVEsbUNBQWdCO0lBQXREOztRQUdrQixlQUFVLEdBQTJCLEVBQUUsQ0FBQztJQU0xRCxDQUFDO0NBQUE7QUFOQztJQUZDLG9CQUFRLENBQUMsTUFBTSxDQUFDO0lBQ2hCLDBCQUFLLENBQUMsWUFBWSxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztvREFDUTtBQUt4RDtJQUhDLG9CQUFRLENBQUMsTUFBTSxDQUFDO0lBQ2hCLDZCQUFRO0lBQ1IsMEJBQUssQ0FBQyxtQ0FBYyxDQUFDO29EQUNnQjtBQVJ4Qyw0Q0FTQztBQUVEOzs7Ozs7OztHQVFHO0FBQ0gsTUFBYSxnQkFBaUIsU0FBUSxtQ0FBZ0I7SUFBdEQ7O1FBUWtCLGVBQVUsR0FBMkIsRUFBRSxDQUFDO1FBSXhDLHNCQUFpQixHQUFhLEVBQUUsQ0FBQztRQUlqQyxvQkFBZSxHQUFhLEVBQUUsQ0FBQztRQUkvQixzQkFBaUIsR0FBYSxFQUFFLENBQUM7SUFLbkQsQ0FBQztDQUFBO0FBckJDO0lBSEMsb0JBQVEsQ0FBQyxNQUFNLENBQUM7SUFDaEIsNkJBQVE7SUFDUixtQ0FBYzs0Q0FDYTtBQUk1QjtJQUZDLG9CQUFRLENBQUMsTUFBTSxDQUFDO0lBQ2hCLDBCQUFLLENBQUMsWUFBWSxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztvREFDUTtBQUl4RDtJQUZDLG9CQUFRLENBQUMsTUFBTSxDQUFDO0lBQ2hCLDBCQUFLLENBQUMsbUNBQWMsQ0FBQzsyREFDMkI7QUFJakQ7SUFGQyxvQkFBUSxDQUFDLE1BQU0sQ0FBQztJQUNoQiwwQkFBSyxDQUFDLG1DQUFjLENBQUM7eURBQ3lCO0FBSS9DO0lBRkMsb0JBQVEsQ0FBQyxNQUFNLENBQUM7SUFDaEIsMEJBQUssQ0FBQyxtQ0FBYyxDQUFDOzJEQUMyQjtBQUlqRDtJQUZDLG9CQUFRLENBQUMsTUFBTSxDQUFDO0lBQ2hCLDJCQUFNO2dEQUN5QjtBQXhCbEMsNENBeUJDIn0=