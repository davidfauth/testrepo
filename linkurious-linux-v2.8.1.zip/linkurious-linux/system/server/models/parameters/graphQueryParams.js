"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-01-22.
 */
const _ = require("lodash");
const apiParams_1 = require("./apiParams");
const dataSourceParams_1 = require("./dataSourceParams");
var GraphQuerySharingMode;
(function (GraphQuerySharingMode) {
    GraphQuerySharingMode["PRIVATE"] = "private";
    GraphQuerySharingMode["SOURCE"] = "source";
    GraphQuerySharingMode["GROUPS"] = "groups";
})(GraphQuerySharingMode = exports.GraphQuerySharingMode || (exports.GraphQuerySharingMode = {}));
var GraphQueryDialect;
(function (GraphQueryDialect) {
    GraphQueryDialect["CYPHER"] = "cypher";
    GraphQueryDialect["GREMLIN"] = "gremlin";
})(GraphQueryDialect = exports.GraphQueryDialect || (exports.GraphQueryDialect = {}));
var GraphQueryType;
(function (GraphQueryType) {
    GraphQueryType["STATIC"] = "static";
    GraphQueryType["TEMPLATE"] = "template";
})(GraphQueryType = exports.GraphQueryType || (exports.GraphQueryType = {}));
const CREATE_UPDATE_PARAMS_DEFINITION = (onCreate) => {
    const paramsDefinition = {
        name: { required: onCreate, check: ['string', true, undefined, undefined, 200] },
        content: { required: onCreate, check: 'nonEmpty' },
        dialect: { required: false, values: _.values(GraphQueryDialect) },
        description: { required: false, check: 'string' },
        sharing: { required: onCreate, values: _.values(GraphQuerySharingMode) }
    };
    if (!onCreate) {
        paramsDefinition.id = { required: true, check: 'posInt' };
    }
    return paramsDefinition;
};
/**
 * @apiDefine CreateGraphQueryParams
 *
 * @apiParam {string}                             name               Name of the graph query
 * @apiParam {string}                             content            Content of the graph query
 * @apiParam {string="cypher","gremlin"}          [dialect]          Dialect of the graph query
 * @apiParam {string}                             description        Description of the graph query
 * @apiParam {string="private","source","groups"} sharing            Sharing policy of the graph query
 * @apiParam {number[]}                           [sharedWithGroups] IDs of the groups the graph query is shared with (if `sharing="groups"`)
 */
class CreateGraphQueryParams extends dataSourceParams_1.DataSourceParams {
    getParamsDefinition() {
        const rules = CREATE_UPDATE_PARAMS_DEFINITION(true);
        // if sharing is defined, also sharedWithGroups must be defined
        if (this.sharing === GraphQuerySharingMode.GROUPS) {
            rules.sharedWithGroups = { required: true, arrayItem: { check: 'posInt' } };
        }
        return _.merge(super.getParamsDefinition(), rules);
    }
}
__decorate([
    apiParams_1.ApiParam('body')
], CreateGraphQueryParams.prototype, "name", void 0);
__decorate([
    apiParams_1.ApiParam('body')
], CreateGraphQueryParams.prototype, "content", void 0);
__decorate([
    apiParams_1.ApiParam('body')
], CreateGraphQueryParams.prototype, "dialect", void 0);
__decorate([
    apiParams_1.ApiParam('body')
], CreateGraphQueryParams.prototype, "description", void 0);
__decorate([
    apiParams_1.ApiParam('body')
], CreateGraphQueryParams.prototype, "sharing", void 0);
__decorate([
    apiParams_1.ApiParam('body')
], CreateGraphQueryParams.prototype, "sharedWithGroups", void 0);
exports.CreateGraphQueryParams = CreateGraphQueryParams;
/**
 * @apiDefine GetGraphQueryParams
 *
 * @apiParam {number} id ID of the graph query
 */
class GetGraphQueryParams extends dataSourceParams_1.DataSourceParams {
    getParamsDefinition() {
        return _.merge(super.getParamsDefinition(), {
            // negative IDs are allowed and refer to builtin queries
            id: { required: true, check: 'number' }
        });
    }
}
__decorate([
    apiParams_1.ApiParam('path', apiParams_1.ApiParamParser.number)
], GetGraphQueryParams.prototype, "id", void 0);
exports.GetGraphQueryParams = GetGraphQueryParams;
/**
 * @apiDefine DeleteGraphQueryParams
 *
 * @apiParam {number} id ID of the graph query
 */
class DeleteGraphQueryParams extends GetGraphQueryParams {
    getParamsDefinition() {
        return _.merge(super.getParamsDefinition(), {
            // negative IDs refer to builtin queries not allowed on delete
            id: { required: true, check: 'posInt' }
        });
    }
}
exports.DeleteGraphQueryParams = DeleteGraphQueryParams;
/**
 * @apiDefine GetAllGraphQueriesParams
 *
 * @apiParam {string="static","template"} [type=static] Type of the graph queries
 */
class GetAllGraphQueriesParams extends dataSourceParams_1.DataSourceParams {
    getParamsDefinition() {
        return _.merge(super.getParamsDefinition(), {
            type: { required: false, values: _.values(GraphQueryType) }
        });
    }
}
__decorate([
    apiParams_1.ApiParam('query')
], GetAllGraphQueriesParams.prototype, "type", void 0);
exports.GetAllGraphQueriesParams = GetAllGraphQueriesParams;
/**
 * @apiDefine UpdateGraphQueryParams
 *
 * @apiParam {number}                             id                 ID of the graph query
 * @apiParam {string}                             [name]             New name of the graph query
 * @apiParam {string}                             [content]          New content of the graph query
 * @apiParam {string="cypher","gremlin"}          [dialect]          New dialect of the graph query
 * @apiParam {string}                             [description]      New description of the graph query
 * @apiParam {string="private","source","groups"} [sharing]          New sharing policy of the graph query
 * @apiParam {number[]}                           [sharedWithGroups] IDs of the groups the graph query is shared with (if `sharing="groups"`)
 */
class UpdateGraphQueryParams extends dataSourceParams_1.DataSourceParams {
    getParamsDefinition() {
        const rules = CREATE_UPDATE_PARAMS_DEFINITION(false);
        // if sharing is defined, also sharedWithGroups must be defined
        if (this.sharing === 'groups') {
            rules.sharedWithGroups = { required: true, arrayItem: { check: 'posInt' } };
        }
        return _.merge(super.getParamsDefinition(), rules);
    }
}
__decorate([
    apiParams_1.ApiParam('path', apiParams_1.ApiParamParser.number)
], UpdateGraphQueryParams.prototype, "id", void 0);
__decorate([
    apiParams_1.ApiParam('body')
], UpdateGraphQueryParams.prototype, "name", void 0);
__decorate([
    apiParams_1.ApiParam('body')
], UpdateGraphQueryParams.prototype, "content", void 0);
__decorate([
    apiParams_1.ApiParam('body')
], UpdateGraphQueryParams.prototype, "dialect", void 0);
__decorate([
    apiParams_1.ApiParam('body')
], UpdateGraphQueryParams.prototype, "description", void 0);
__decorate([
    apiParams_1.ApiParam('body')
], UpdateGraphQueryParams.prototype, "sharing", void 0);
__decorate([
    apiParams_1.ApiParam('body')
], UpdateGraphQueryParams.prototype, "sharedWithGroups", void 0);
exports.UpdateGraphQueryParams = UpdateGraphQueryParams;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGhRdWVyeVBhcmFtcy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9tb2RlbHMvcGFyYW1ldGVycy9ncmFwaFF1ZXJ5UGFyYW1zLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUE7Ozs7O0dBS0c7QUFDSCw0QkFBNEI7QUFFNUIsMkNBQXVFO0FBQ3ZFLHlEQUFvRDtBQUVwRCxJQUFZLHFCQUlYO0FBSkQsV0FBWSxxQkFBcUI7SUFDL0IsNENBQW1CLENBQUE7SUFDbkIsMENBQWlCLENBQUE7SUFDakIsMENBQWlCLENBQUE7QUFDbkIsQ0FBQyxFQUpXLHFCQUFxQixHQUFyQiw2QkFBcUIsS0FBckIsNkJBQXFCLFFBSWhDO0FBRUQsSUFBWSxpQkFHWDtBQUhELFdBQVksaUJBQWlCO0lBQzNCLHNDQUFpQixDQUFBO0lBQ2pCLHdDQUFtQixDQUFBO0FBQ3JCLENBQUMsRUFIVyxpQkFBaUIsR0FBakIseUJBQWlCLEtBQWpCLHlCQUFpQixRQUc1QjtBQUVELElBQVksY0FHWDtBQUhELFdBQVksY0FBYztJQUN4QixtQ0FBaUIsQ0FBQTtJQUNqQix1Q0FBcUIsQ0FBQTtBQUN2QixDQUFDLEVBSFcsY0FBYyxHQUFkLHNCQUFjLEtBQWQsc0JBQWMsUUFHekI7QUFFRCxNQUFNLCtCQUErQixHQUFHLENBQUMsUUFBaUIsRUFBb0IsRUFBRTtJQUM5RSxNQUFNLGdCQUFnQixHQUFxQjtRQUN6QyxJQUFJLEVBQUUsRUFBQyxRQUFRLEVBQUUsUUFBUSxFQUFFLEtBQUssRUFBRSxDQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxHQUFHLENBQUMsRUFBQztRQUM5RSxPQUFPLEVBQUUsRUFBQyxRQUFRLEVBQUUsUUFBUSxFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUM7UUFDaEQsT0FBTyxFQUFFLEVBQUMsUUFBUSxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxFQUFDO1FBQy9ELFdBQVcsRUFBRSxFQUFDLFFBQVEsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBQztRQUMvQyxPQUFPLEVBQUUsRUFBQyxRQUFRLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLHFCQUFxQixDQUFDLEVBQUM7S0FDdkUsQ0FBQztJQUVGLElBQUksQ0FBQyxRQUFRLEVBQUU7UUFDYixnQkFBZ0IsQ0FBQyxFQUFFLEdBQUcsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUMsQ0FBQztLQUN6RDtJQUVELE9BQU8sZ0JBQWdCLENBQUM7QUFDMUIsQ0FBQyxDQUFDO0FBRUY7Ozs7Ozs7OztHQVNHO0FBQ0gsTUFBYSxzQkFBdUIsU0FBUSxtQ0FBZ0I7SUFtQmhELG1CQUFtQjtRQUMzQixNQUFNLEtBQUssR0FBRywrQkFBK0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUVwRCwrREFBK0Q7UUFDL0QsSUFBSSxJQUFJLENBQUMsT0FBTyxLQUFLLHFCQUFxQixDQUFDLE1BQU0sRUFBRTtZQUNqRCxLQUFLLENBQUMsZ0JBQWdCLEdBQUcsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxFQUFDLEtBQUssRUFBRSxRQUFRLEVBQUMsRUFBQyxDQUFDO1NBQ3pFO1FBRUQsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxtQkFBbUIsRUFBRSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3JELENBQUM7Q0FDRjtBQTNCQztJQURDLG9CQUFRLENBQUMsTUFBTSxDQUFDO29EQUNJO0FBR3JCO0lBREMsb0JBQVEsQ0FBQyxNQUFNLENBQUM7dURBQ087QUFHeEI7SUFEQyxvQkFBUSxDQUFDLE1BQU0sQ0FBQzt1REFDa0I7QUFHbkM7SUFEQyxvQkFBUSxDQUFDLE1BQU0sQ0FBQzsyREFDVztBQUc1QjtJQURDLG9CQUFRLENBQUMsTUFBTSxDQUFDO3VEQUNzQjtBQUd2QztJQURDLG9CQUFRLENBQUMsTUFBTSxDQUFDO2dFQUNrQjtBQWpCckMsd0RBNkJDO0FBRUQ7Ozs7R0FJRztBQUNILE1BQWEsbUJBQW9CLFNBQVEsbUNBQWdCO0lBSTdDLG1CQUFtQjtRQUMzQixPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLG1CQUFtQixFQUFFLEVBQUU7WUFDMUMsd0RBQXdEO1lBQ3hELEVBQUUsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBQztTQUN0QyxDQUFDLENBQUM7SUFDTCxDQUFDO0NBQ0Y7QUFSQztJQURDLG9CQUFRLENBQUMsTUFBTSxFQUFFLDBCQUFjLENBQUMsTUFBTSxDQUFDOytDQUNyQjtBQUZyQixrREFVQztBQUVEOzs7O0dBSUc7QUFDSCxNQUFhLHNCQUF1QixTQUFRLG1CQUFtQjtJQUNuRCxtQkFBbUI7UUFDM0IsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxtQkFBbUIsRUFBRSxFQUFFO1lBQzFDLDhEQUE4RDtZQUM5RCxFQUFFLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUM7U0FDdEMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGO0FBUEQsd0RBT0M7QUFFRDs7OztHQUlHO0FBQ0gsTUFBYSx3QkFBeUIsU0FBUSxtQ0FBZ0I7SUFJbEQsbUJBQW1CO1FBQzNCLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsbUJBQW1CLEVBQUUsRUFBRTtZQUMxQyxJQUFJLEVBQUUsRUFBQyxRQUFRLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxFQUFDO1NBQzFELENBQUMsQ0FBQztJQUNMLENBQUM7Q0FDRjtBQVBDO0lBREMsb0JBQVEsQ0FBQyxPQUFPLENBQUM7c0RBQ1c7QUFGL0IsNERBU0M7QUFFRDs7Ozs7Ozs7OztHQVVHO0FBQ0gsTUFBYSxzQkFBdUIsU0FBUSxtQ0FBZ0I7SUFzQmhELG1CQUFtQjtRQUMzQixNQUFNLEtBQUssR0FBRywrQkFBK0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUVyRCwrREFBK0Q7UUFDL0QsSUFBSSxJQUFJLENBQUMsT0FBTyxLQUFLLFFBQVEsRUFBRTtZQUM3QixLQUFLLENBQUMsZ0JBQWdCLEdBQUcsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxFQUFDLEtBQUssRUFBRSxRQUFRLEVBQUMsRUFBQyxDQUFDO1NBQ3pFO1FBRUQsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxtQkFBbUIsRUFBRSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3JELENBQUM7Q0FDRjtBQTlCQztJQURDLG9CQUFRLENBQUMsTUFBTSxFQUFFLDBCQUFjLENBQUMsTUFBTSxDQUFDO2tEQUNyQjtBQUduQjtJQURDLG9CQUFRLENBQUMsTUFBTSxDQUFDO29EQUNJO0FBR3JCO0lBREMsb0JBQVEsQ0FBQyxNQUFNLENBQUM7dURBQ087QUFHeEI7SUFEQyxvQkFBUSxDQUFDLE1BQU0sQ0FBQzt1REFDa0I7QUFHbkM7SUFEQyxvQkFBUSxDQUFDLE1BQU0sQ0FBQzsyREFDVztBQUc1QjtJQURDLG9CQUFRLENBQUMsTUFBTSxDQUFDO3VEQUNzQjtBQUd2QztJQURDLG9CQUFRLENBQUMsTUFBTSxDQUFDO2dFQUNrQjtBQXBCckMsd0RBZ0NDIn0=