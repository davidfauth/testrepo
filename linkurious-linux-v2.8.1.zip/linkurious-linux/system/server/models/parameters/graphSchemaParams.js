"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-05-20.
 */
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
// TS2019-DONE
const rest_client_1 = require("@linkurious/rest-client");
const _ = require("lodash");
const valcheck_1 = require("../utils/valcheck");
const valcheckDecorators_1 = require("../utils/valcheckDecorators");
const apiParams_1 = require("./apiParams");
const dataSourceParams_1 = require("./dataSourceParams");
class EnumOptions {
}
__decorate([
    valcheckDecorators_1.required,
    valcheckDecorators_1.check('stringArray', 2)
], EnumOptions.prototype, "values", void 0);
class DateOptions {
}
__decorate([
    valcheckDecorators_1.required,
    valcheckDecorators_1.values(rest_client_1.LkDateFormat)
], DateOptions.prototype, "format", void 0);
class DateTimeOptions {
    constructor() {
        this.timezone = true;
    }
}
__decorate([
    valcheckDecorators_1.required,
    valcheckDecorators_1.values(rest_client_1.LkDateTimeFormat)
], DateTimeOptions.prototype, "format", void 0);
__decorate([
    valcheckDecorators_1.boolean
], DateTimeOptions.prototype, "timezone", void 0);
class SimpleType {
}
__decorate([
    valcheckDecorators_1.required,
    valcheckDecorators_1.values([rest_client_1.LkPropertyType.AUTO, rest_client_1.LkPropertyType.NUMBER, rest_client_1.LkPropertyType.BOOLEAN])
], SimpleType.prototype, "name", void 0);
class StringType {
}
__decorate([
    valcheckDecorators_1.required,
    valcheckDecorators_1.values([rest_client_1.LkPropertyType.STRING])
], StringType.prototype, "name", void 0);
__decorate([
    valcheckDecorators_1.properties(EnumOptions)
], StringType.prototype, "options", void 0);
class DateType {
}
__decorate([
    valcheckDecorators_1.required,
    valcheckDecorators_1.values([rest_client_1.LkPropertyType.DATE])
], DateType.prototype, "name", void 0);
__decorate([
    valcheckDecorators_1.required,
    valcheckDecorators_1.properties(DateOptions)
], DateType.prototype, "options", void 0);
class DateTimeType {
}
__decorate([
    valcheckDecorators_1.required,
    valcheckDecorators_1.values([rest_client_1.LkPropertyType.DATETIME])
], DateTimeType.prototype, "name", void 0);
__decorate([
    valcheckDecorators_1.required,
    valcheckDecorators_1.properties(DateTimeOptions)
], DateTimeType.prototype, "options", void 0);
/**
 * @apiDefine StartSchemaSamplingParams
 *
 */
class StartSchemaSamplingParams extends dataSourceParams_1.DataSourceParams {
    constructor() {
        super(...arguments);
        this.reset = false;
    }
}
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.boolean
], StartSchemaSamplingParams.prototype, "reset", void 0);
exports.StartSchemaSamplingParams = StartSchemaSamplingParams;
class StopSchemaSamplingParams extends dataSourceParams_1.DataSourceParams {
}
exports.StopSchemaSamplingParams = StopSchemaSamplingParams;
class GetSamplingStatusParams extends dataSourceParams_1.DataSourceParams {
}
exports.GetSamplingStatusParams = GetSamplingStatusParams;
/**
 * @apiDefine CreateOrUpdateTypeParams
 *
 * @apiParam {string="node","edge"}                 entityType   "node" or "edge"
 * @apiParam {string}                               label        Name of the graph schema type
 * @apiParam {string="visible","searchable","none"} [visibility] Whether the type can be searched, visualized or it is hidden
 */
class CreateTypeParams extends dataSourceParams_1.DataSourceParams {
    constructor() {
        super(...arguments);
        this.visibility = rest_client_1.DataVisibility.SEARCHABLE;
    }
}
__decorate([
    apiParams_1.ApiParam('path'),
    valcheckDecorators_1.required,
    valcheckDecorators_1.values(rest_client_1.EntityType)
], CreateTypeParams.prototype, "entityType", void 0);
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.required,
    valcheckDecorators_1.nonEmptyString
], CreateTypeParams.prototype, "label", void 0);
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.values(rest_client_1.DataVisibility)
], CreateTypeParams.prototype, "visibility", void 0);
exports.CreateTypeParams = CreateTypeParams;
class UpdateTypeParams extends dataSourceParams_1.DataSourceParams {
}
__decorate([
    apiParams_1.ApiParam('path'),
    valcheckDecorators_1.required,
    valcheckDecorators_1.values(rest_client_1.EntityType)
], UpdateTypeParams.prototype, "entityType", void 0);
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.required,
    valcheckDecorators_1.nonEmptyString
], UpdateTypeParams.prototype, "label", void 0);
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.required,
    valcheckDecorators_1.values(rest_client_1.DataVisibility)
], UpdateTypeParams.prototype, "visibility", void 0);
exports.UpdateTypeParams = UpdateTypeParams;
/**
 * @apiDefine CreatePropertyParams
 *
 * @apiParam {string="node","edge"}                                                       entityType                      "node" or "edge"
 * @apiParam {string}                                                                     label                           Name of the graph schema type
 * @apiParam {string}                                                                     propertyKey                     Name of the property
 * @apiParam {string="visible","searchable","none"}                                       visibility                      Whether the property can be searched, visualized or it is hidden
 * @apiParam {object}                                                                     propertyType
 * @apiParam {string="auto","boolean","date","datetime","number","string"}                propertyType.name               Data type of the property
 * @apiParam {object}                                                                     [propertyType.options]          Additional `propertyType` information (required when `propertyType.name` is "date" or "datetime")
 * @apiParam {string[]}                                                                   [propertyType.options.values]   A list of values to restrict the value of the property (only applicable when `propertyType` is "string")
 * @apiParam {string="native","iso","dd/mm/yyyy","mm/dd/yyyy","timestamp","timestamp-ms"} [propertyType.options.format]   Storage format (required and only applicable when `propertyType` is "date" or "datetime")
 * @apiParam {string}                                                                     [propertyType.options.timezone] Timezone (format: "[+-]HH:MM | Z") (only applicable when `propertyType` is "datetime")
 * @apiParam {boolean}                                                                    required                        Whether the property is required on data edition
 */
class CreatePropertyParams extends dataSourceParams_1.DataSourceParams {
    constructor() {
        super(...arguments);
        this.visibility = rest_client_1.DataVisibility.SEARCHABLE;
    }
}
__decorate([
    apiParams_1.ApiParam('path'),
    valcheckDecorators_1.required,
    valcheckDecorators_1.values(rest_client_1.EntityType)
], CreatePropertyParams.prototype, "entityType", void 0);
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.required,
    valcheckDecorators_1.nonEmptyString
], CreatePropertyParams.prototype, "label", void 0);
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.required,
    valcheckDecorators_1.nonEmptyString
], CreatePropertyParams.prototype, "propertyKey", void 0);
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.values(rest_client_1.DataVisibility)
], CreatePropertyParams.prototype, "visibility", void 0);
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.required,
    valcheckDecorators_1.dynamicProperties(resolvePropertyType)
], CreatePropertyParams.prototype, "propertyType", void 0);
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.boolean
], CreatePropertyParams.prototype, "required", void 0);
exports.CreatePropertyParams = CreatePropertyParams;
/**
 * @apiDefine UpdatePropertyParams
 *
 * @apiParam {string="node","edge"}                                                       entityType                      "node" or "edge"
 * @apiParam {string}                                                                     label                           Name of the graph schema type
 * @apiParam {string}                                                                     propertyKey                     Name of the property
 * @apiParam {string="visible","searchable","none"}                                       [visibility]                    Whether the property can be searched, visualized or it is hidden
 * @apiParam {object}                                                                     [propertyType]
 * @apiParam {string="auto","boolean","date","datetime","number","string"}                propertyType.name               Data type of the property
 * @apiParam {object}                                                                     [propertyType.options]          Additional `propertyType` information (required when `propertyType.name` is "date" or "datetime")
 * @apiParam {string[]}                                                                   [propertyType.options.values]   A list of values to restrict the value of the property (only applicable when `propertyType` is "string")
 * @apiParam {string="native","iso","dd/mm/yyyy","mm/dd/yyyy","timestamp","timestamp-ms"} [propertyType.options.format]   Storage format (required and only applicable when `propertyType` is "date" or "datetime")
 * @apiParam {string}                                                                     [propertyType.options.timezone] Timezone (format: "[+-]HH:MM | Z") (only applicable when `propertyType` is "datetime")
 * @apiParam {boolean}                                                                    [required]                      Whether the property is required on data edition
 */
class UpdatePropertyParams extends dataSourceParams_1.DataSourceParams {
}
__decorate([
    apiParams_1.ApiParam('path'),
    valcheckDecorators_1.required,
    valcheckDecorators_1.values(rest_client_1.EntityType)
], UpdatePropertyParams.prototype, "entityType", void 0);
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.required,
    valcheckDecorators_1.nonEmptyString
], UpdatePropertyParams.prototype, "label", void 0);
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.required,
    valcheckDecorators_1.nonEmptyString
], UpdatePropertyParams.prototype, "propertyKey", void 0);
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.values(rest_client_1.DataVisibility)
], UpdatePropertyParams.prototype, "visibility", void 0);
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.dynamicProperties(resolvePropertyType)
], UpdatePropertyParams.prototype, "propertyType", void 0);
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.boolean
], UpdatePropertyParams.prototype, "required", void 0);
exports.UpdatePropertyParams = UpdatePropertyParams;
/**
 * @apiDefine UpdateSchemaSettingsParams
 *
 * @apiParam {object}  settings              Graph schema settings
 * @apiParam {boolean} settings.strictSchema Whether the graph schema is in strict mode
 */
class UpdateSchemaSettingsParams extends dataSourceParams_1.DataSourceParams {
}
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.required,
    valcheckDecorators_1.boolean
], UpdateSchemaSettingsParams.prototype, "strictSchema", void 0);
exports.UpdateSchemaSettingsParams = UpdateSchemaSettingsParams;
/**
 * @apiDefine GetGraphSchemaParams
 *
 * @apiParam {string} entityType "node" or "edge"
 */
class GetGraphSchemaParams extends dataSourceParams_1.DataSourceParams {
}
__decorate([
    apiParams_1.ApiParam('path'),
    valcheckDecorators_1.required,
    valcheckDecorators_1.values(rest_client_1.EntityType)
], GetGraphSchemaParams.prototype, "entityType", void 0);
exports.GetGraphSchemaParams = GetGraphSchemaParams;
class GetGraphSchemaWithAccessParams extends GetGraphSchemaParams {
}
exports.GetGraphSchemaWithAccessParams = GetGraphSchemaWithAccessParams;
class GetSimpleSchemaParams extends dataSourceParams_1.DataSourceParams {
}
exports.GetSimpleSchemaParams = GetSimpleSchemaParams;
function resolvePropertyType(key, value) {
    const propertyTypeName = _.get(value, 'name');
    valcheck_1.valcheck.properties(key, value, { name: { required: true, values: _.values(rest_client_1.LkPropertyType) } }, 'inclusive');
    switch (propertyTypeName) {
        case rest_client_1.LkPropertyType.STRING:
            return StringType;
        case rest_client_1.LkPropertyType.DATE:
            return DateType;
        case rest_client_1.LkPropertyType.DATETIME:
            return DateTimeType;
    }
    return SimpleType;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGhTY2hlbWFQYXJhbXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvbW9kZWxzL3BhcmFtZXRlcnMvZ3JhcGhTY2hlbWFQYXJhbXMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7OztHQUtHOzs7Ozs7OztBQUVILGNBQWM7QUFFZCx5REF3QmlDO0FBQ2pDLDRCQUE0QjtBQUc1QixnREFBMkM7QUFDM0Msb0VBUXFDO0FBRXJDLDJDQUFxQztBQUNyQyx5REFBb0Q7QUFFcEQsTUFBTSxXQUFXO0NBSWhCO0FBREM7SUFGQyw2QkFBUTtJQUNSLDBCQUFLLENBQUMsYUFBYSxFQUFFLENBQUMsQ0FBQzsyQ0FDVTtBQUdwQyxNQUFNLFdBQVc7Q0FJaEI7QUFEQztJQUZDLDZCQUFRO0lBQ1IsMkJBQU0sQ0FBQywwQkFBWSxDQUFDOzJDQUNpQjtBQUd4QyxNQUFNLGVBQWU7SUFBckI7UUFNa0IsYUFBUSxHQUFZLElBQUksQ0FBQztJQUMzQyxDQUFDO0NBQUE7QUFKQztJQUZDLDZCQUFRO0lBQ1IsMkJBQU0sQ0FBQyw4QkFBZ0IsQ0FBQzsrQ0FDaUI7QUFHMUM7SUFEQyw0QkFBTztpREFDaUM7QUFHM0MsTUFBTSxVQUFVO0NBSWY7QUFEQztJQUZDLDZCQUFRO0lBQ1IsMkJBQU0sQ0FBQyxDQUFDLDRCQUFjLENBQUMsSUFBSSxFQUFFLDRCQUFjLENBQUMsTUFBTSxFQUFFLDRCQUFjLENBQUMsT0FBTyxDQUFDLENBQUM7d0NBQ2U7QUFHOUYsTUFBTSxVQUFVO0NBT2Y7QUFKQztJQUZDLDZCQUFRO0lBQ1IsMkJBQU0sQ0FBQyxDQUFDLDRCQUFjLENBQUMsTUFBTSxDQUFDLENBQUM7d0NBQ2E7QUFHN0M7SUFEQywrQkFBVSxDQUFDLFdBQVcsQ0FBQzsyQ0FDYztBQUd4QyxNQUFNLFFBQVE7Q0FRYjtBQUxDO0lBRkMsNkJBQVE7SUFDUiwyQkFBTSxDQUFDLENBQUMsNEJBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQztzQ0FDYTtBQUkzQztJQUZDLDZCQUFRO0lBQ1IsK0JBQVUsQ0FBQyxXQUFXLENBQUM7eUNBQ2M7QUFHeEMsTUFBTSxZQUFZO0NBUWpCO0FBTEM7SUFGQyw2QkFBUTtJQUNSLDJCQUFNLENBQUMsQ0FBQyw0QkFBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDOzBDQUNhO0FBSS9DO0lBRkMsNkJBQVE7SUFDUiwrQkFBVSxDQUFDLGVBQWUsQ0FBQzs2Q0FDYztBQUc1Qzs7O0dBR0c7QUFDSCxNQUFhLHlCQUEwQixTQUFRLG1DQUFnQjtJQUEvRDs7UUFJa0IsVUFBSyxHQUFZLEtBQUssQ0FBQztJQUN6QyxDQUFDO0NBQUE7QUFEQztJQUZDLG9CQUFRLENBQUMsTUFBTSxDQUFDO0lBQ2hCLDRCQUFPO3dEQUMrQjtBQUp6Qyw4REFLQztBQUVELE1BQWEsd0JBQXlCLFNBQVEsbUNBQWdCO0NBQ3JCO0FBRHpDLDREQUN5QztBQUV6QyxNQUFhLHVCQUF3QixTQUFRLG1DQUFnQjtDQUF1QztBQUFwRywwREFBb0c7QUFFcEc7Ozs7OztHQU1HO0FBQ0gsTUFBYSxnQkFBaUIsU0FBUSxtQ0FBZ0I7SUFBdEQ7O1FBYWtCLGVBQVUsR0FBbUIsNEJBQWMsQ0FBQyxVQUFVLENBQUM7SUFDekUsQ0FBQztDQUFBO0FBVkM7SUFIQyxvQkFBUSxDQUFDLE1BQU0sQ0FBQztJQUNoQiw2QkFBUTtJQUNSLDJCQUFNLENBQUMsd0JBQVUsQ0FBQztvREFDcUI7QUFLeEM7SUFIQyxvQkFBUSxDQUFDLE1BQU0sQ0FBQztJQUNoQiw2QkFBUTtJQUNSLG1DQUFjOytDQUNnQjtBQUkvQjtJQUZDLG9CQUFRLENBQUMsTUFBTSxDQUFDO0lBQ2hCLDJCQUFNLENBQUMsNEJBQWMsQ0FBQztvREFDZ0Q7QUFiekUsNENBY0M7QUFFRCxNQUFhLGdCQUFpQixTQUFRLG1DQUFnQjtDQWVyRDtBQVhDO0lBSEMsb0JBQVEsQ0FBQyxNQUFNLENBQUM7SUFDaEIsNkJBQVE7SUFDUiwyQkFBTSxDQUFDLHdCQUFVLENBQUM7b0RBQ3FCO0FBS3hDO0lBSEMsb0JBQVEsQ0FBQyxNQUFNLENBQUM7SUFDaEIsNkJBQVE7SUFDUixtQ0FBYzsrQ0FDZ0I7QUFLL0I7SUFIQyxvQkFBUSxDQUFDLE1BQU0sQ0FBQztJQUNoQiw2QkFBUTtJQUNSLDJCQUFNLENBQUMsNEJBQWMsQ0FBQztvREFDcUI7QUFkOUMsNENBZUM7QUFFRDs7Ozs7Ozs7Ozs7Ozs7R0FjRztBQUNILE1BQWEsb0JBQXFCLFNBQVEsbUNBQWdCO0lBQTFEOztRQWtCa0IsZUFBVSxHQUFtQiw0QkFBYyxDQUFDLFVBQVUsQ0FBQztJQVV6RSxDQUFDO0NBQUE7QUF4QkM7SUFIQyxvQkFBUSxDQUFDLE1BQU0sQ0FBQztJQUNoQiw2QkFBUTtJQUNSLDJCQUFNLENBQUMsd0JBQVUsQ0FBQzt3REFDcUI7QUFLeEM7SUFIQyxvQkFBUSxDQUFDLE1BQU0sQ0FBQztJQUNoQiw2QkFBUTtJQUNSLG1DQUFjO21EQUNnQjtBQUsvQjtJQUhDLG9CQUFRLENBQUMsTUFBTSxDQUFDO0lBQ2hCLDZCQUFRO0lBQ1IsbUNBQWM7eURBQ3NCO0FBSXJDO0lBRkMsb0JBQVEsQ0FBQyxNQUFNLENBQUM7SUFDaEIsMkJBQU0sQ0FBQyw0QkFBYyxDQUFDO3dEQUNnRDtBQUt2RTtJQUhDLG9CQUFRLENBQUMsTUFBTSxDQUFDO0lBQ2hCLDZCQUFRO0lBQ1Isc0NBQWlCLENBQUMsbUJBQW1CLENBQUM7MERBQzhDO0FBSXJGO0lBRkMsb0JBQVEsQ0FBQyxNQUFNLENBQUM7SUFDaEIsNEJBQU87c0RBQzJCO0FBM0JyQyxvREE0QkM7QUFFRDs7Ozs7Ozs7Ozs7Ozs7R0FjRztBQUNILE1BQWEsb0JBQXFCLFNBQVEsbUNBQWdCO0NBMkJ6RDtBQXZCQztJQUhDLG9CQUFRLENBQUMsTUFBTSxDQUFDO0lBQ2hCLDZCQUFRO0lBQ1IsMkJBQU0sQ0FBQyx3QkFBVSxDQUFDO3dEQUNxQjtBQUt4QztJQUhDLG9CQUFRLENBQUMsTUFBTSxDQUFDO0lBQ2hCLDZCQUFRO0lBQ1IsbUNBQWM7bURBQ2dCO0FBSy9CO0lBSEMsb0JBQVEsQ0FBQyxNQUFNLENBQUM7SUFDaEIsNkJBQVE7SUFDUixtQ0FBYzt5REFDc0I7QUFJckM7SUFGQyxvQkFBUSxDQUFDLE1BQU0sQ0FBQztJQUNoQiwyQkFBTSxDQUFDLDRCQUFjLENBQUM7d0RBQ3FCO0FBSTVDO0lBRkMsb0JBQVEsQ0FBQyxNQUFNLENBQUM7SUFDaEIsc0NBQWlCLENBQUMsbUJBQW1CLENBQUM7MERBQzhDO0FBSXJGO0lBRkMsb0JBQVEsQ0FBQyxNQUFNLENBQUM7SUFDaEIsNEJBQU87c0RBQzJCO0FBMUJyQyxvREEyQkM7QUFFRDs7Ozs7R0FLRztBQUNILE1BQWEsMEJBQTJCLFNBQVEsbUNBQWdCO0NBTS9EO0FBREM7SUFIQyxvQkFBUSxDQUFDLE1BQU0sQ0FBQztJQUNoQiw2QkFBUTtJQUNSLDRCQUFPO2dFQUMrQjtBQUx6QyxnRUFNQztBQUVEOzs7O0dBSUc7QUFDSCxNQUFhLG9CQUFxQixTQUFRLG1DQUFnQjtDQUt6RDtBQURDO0lBSEMsb0JBQVEsQ0FBQyxNQUFNLENBQUM7SUFDaEIsNkJBQVE7SUFDUiwyQkFBTSxDQUFDLHdCQUFVLENBQUM7d0RBQ3FCO0FBSjFDLG9EQUtDO0FBRUQsTUFBYSw4QkFBK0IsU0FBUSxvQkFBb0I7Q0FDL0I7QUFEekMsd0VBQ3lDO0FBRXpDLE1BQWEscUJBQXNCLFNBQVEsbUNBQWdCO0NBQXFDO0FBQWhHLHNEQUFnRztBQUVoRyxTQUFTLG1CQUFtQixDQUFDLEdBQVcsRUFBRSxLQUFjO0lBQ3RELE1BQU0sZ0JBQWdCLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFDOUMsbUJBQVEsQ0FBQyxVQUFVLENBQ2pCLEdBQUcsRUFDSCxLQUFlLEVBQ2YsRUFBQyxJQUFJLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLDRCQUFjLENBQUMsRUFBQyxFQUFDLEVBQzFELFdBQVcsQ0FDWixDQUFDO0lBQ0YsUUFBUSxnQkFBZ0IsRUFBRTtRQUN4QixLQUFLLDRCQUFjLENBQUMsTUFBTTtZQUN4QixPQUFPLFVBQVUsQ0FBQztRQUNwQixLQUFLLDRCQUFjLENBQUMsSUFBSTtZQUN0QixPQUFPLFFBQVEsQ0FBQztRQUNsQixLQUFLLDRCQUFjLENBQUMsUUFBUTtZQUMxQixPQUFPLFlBQVksQ0FBQztLQUN2QjtJQUVELE9BQU8sVUFBVSxDQUFDO0FBQ3BCLENBQUMifQ==