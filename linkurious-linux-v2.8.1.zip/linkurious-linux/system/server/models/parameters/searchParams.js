"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-06-20.
 */
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
// TS2019-DONE
const rest_client_1 = require("@linkurious/rest-client");
const LKE = require("../../services");
const valcheckDecorators_1 = require("../utils/valcheckDecorators");
const apiParams_1 = require("./apiParams");
const dataSourceParams_1 = require("./dataSourceParams");
const Config = LKE.getConfig();
const DEFAULT_FUZZINESS = Config.get('advanced.defaultFuzziness', 0.1);
const DEFAULT_PAGE_SIZE = 20; // default number of documents per page
class StartIndexationParams extends dataSourceParams_1.DataSourceParams {
}
exports.StartIndexationParams = StartIndexationParams;
class GetIndexationStatusParams extends dataSourceParams_1.DataSourceParams {
}
exports.GetIndexationStatusParams = GetIndexationStatusParams;
/**
 * @apiDefine SearchParams
 * @apiParam {string="node","edge"} type                The item type to search
 * @apiParam {string}               q                   Search query
 * @apiParam {number{0-1}}          [fuzziness]         Fuzziness value (`0` means exact match, `1` completely fuzzy)
 * @apiParam {number}               [size]              Page size (maximum number of returned items)
 * @apiParam {number}               [from]              Offset from the first result
 * @apiParam {string[]}             [categoriesOrTypes] Exclusive list of edge types or node categories to restrict the search on
 * @apiParam {string[][]}           [filter]            Array of pairs key-value used to filter the result. The keys represent object properties and the values are what should match for each property
 */
class SearchParams extends dataSourceParams_1.DataSourceParams {
    constructor() {
        super(...arguments);
        this.fuzziness = DEFAULT_FUZZINESS;
        this.size = DEFAULT_PAGE_SIZE;
        this.from = 0;
    }
}
__decorate([
    apiParams_1.ApiParam('path'),
    valcheckDecorators_1.required,
    valcheckDecorators_1.values(rest_client_1.EntityType)
], SearchParams.prototype, "type", void 0);
__decorate([
    apiParams_1.ApiParam(['query', 'body']),
    valcheckDecorators_1.required,
    valcheckDecorators_1.nonEmptyString
], SearchParams.prototype, "q", void 0);
__decorate([
    apiParams_1.ApiParam(['query', 'body'], apiParams_1.ApiParamParser.number),
    valcheckDecorators_1.check('number', 0, 1)
], SearchParams.prototype, "fuzziness", void 0);
__decorate([
    apiParams_1.ApiParam(['query', 'body'], apiParams_1.ApiParamParser.number),
    valcheckDecorators_1.posInt
], SearchParams.prototype, "size", void 0);
__decorate([
    apiParams_1.ApiParam(['query', 'body'], apiParams_1.ApiParamParser.number),
    valcheckDecorators_1.posInt
], SearchParams.prototype, "from", void 0);
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.check('stringArray', 1)
], SearchParams.prototype, "categoriesOrTypes", void 0);
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.array(valcheckDecorators_1.check('stringArray', 2, 2))
], SearchParams.prototype, "filter", void 0);
exports.SearchParams = SearchParams;
/**
 * @apiDefine SearchAndAddSubGraphParams
 * @apiParam {string[]} [edgesTo]     IDs of nodes that are already visible (they won't be included in the result, but their adjacent edges will be included in the `edges` field if the other nodes are in `nodes`)
 * @apiParam {boolean}  [withDigest]  Whether to include the adjacency digest in the returned nodes
 * @apiParam {boolean}  [withDegree]  Whether to include the degree in the returned nodes
 */
class SearchAndAddSubGraphParams extends SearchParams {
    constructor() {
        super(...arguments);
        this.edgesTo = [];
        this.withDigest = false;
        this.withDegree = false;
    }
}
__decorate([
    apiParams_1.ApiParam('body'),
    valcheckDecorators_1.array(valcheckDecorators_1.nonEmptyString)
], SearchAndAddSubGraphParams.prototype, "edgesTo", void 0);
__decorate([
    apiParams_1.ApiParam(['query', 'body'], apiParams_1.ApiParamParser.boolean),
    valcheckDecorators_1.boolean
], SearchAndAddSubGraphParams.prototype, "withDigest", void 0);
__decorate([
    apiParams_1.ApiParam(['query', 'body'], apiParams_1.ApiParamParser.boolean),
    valcheckDecorators_1.boolean
], SearchAndAddSubGraphParams.prototype, "withDegree", void 0);
exports.SearchAndAddSubGraphParams = SearchAndAddSubGraphParams;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VhcmNoUGFyYW1zLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL21vZGVscy9wYXJhbWV0ZXJzL3NlYXJjaFBhcmFtcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7O0dBS0c7Ozs7Ozs7O0FBRUgsY0FBYztBQUVkLHlEQU1pQztBQUVqQyxzQ0FBdUM7QUFDdkMsb0VBUXFDO0FBRXJDLDJDQUFxRDtBQUNyRCx5REFBb0Q7QUFFcEQsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBRS9CLE1BQU0saUJBQWlCLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQywyQkFBMkIsRUFBRSxHQUFHLENBQUMsQ0FBQztBQUN2RSxNQUFNLGlCQUFpQixHQUFHLEVBQUUsQ0FBQyxDQUFDLHVDQUF1QztBQUVyRSxNQUFhLHFCQUFzQixTQUFRLG1DQUFnQjtDQUFxQztBQUFoRyxzREFBZ0c7QUFFaEcsTUFBYSx5QkFBMEIsU0FBUSxtQ0FBZ0I7Q0FDckI7QUFEMUMsOERBQzBDO0FBRTFDOzs7Ozs7Ozs7R0FTRztBQUNILE1BQWEsWUFBYSxTQUFRLG1DQUFnQjtJQUFsRDs7UUFha0IsY0FBUyxHQUFXLGlCQUFpQixDQUFDO1FBSXRDLFNBQUksR0FBVyxpQkFBaUIsQ0FBQztRQUlqQyxTQUFJLEdBQVcsQ0FBQyxDQUFDO0lBY25DLENBQUM7Q0FBQTtBQS9CQztJQUhDLG9CQUFRLENBQUMsTUFBTSxDQUFDO0lBQ2hCLDZCQUFRO0lBQ1IsMkJBQU0sQ0FBQyx3QkFBVSxDQUFDOzBDQUNlO0FBS2xDO0lBSEMsb0JBQVEsQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsQ0FBQztJQUMzQiw2QkFBUTtJQUNSLG1DQUFjO3VDQUNZO0FBSTNCO0lBRkMsb0JBQVEsQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsRUFBRSwwQkFBYyxDQUFDLE1BQU0sQ0FBQztJQUNsRCwwQkFBSyxDQUFDLFFBQVEsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDOytDQUNnQztBQUl0RDtJQUZDLG9CQUFRLENBQUMsQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLEVBQUUsMEJBQWMsQ0FBQyxNQUFNLENBQUM7SUFDbEQsMkJBQU07MENBQzBDO0FBSWpEO0lBRkMsb0JBQVEsQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsRUFBRSwwQkFBYyxDQUFDLE1BQU0sQ0FBQztJQUNsRCwyQkFBTTswQ0FDMEI7QUFLakM7SUFIQyxvQkFBUSxDQUFDLE1BQU0sQ0FBQztJQUNoQiwwQkFBSyxDQUFDLGFBQWEsRUFBRSxDQUFDLENBQUM7dURBRVk7QUFJcEM7SUFGQyxvQkFBUSxDQUFDLE1BQU0sQ0FBQztJQUNoQiwwQkFBSyxDQUFDLDBCQUFLLENBQUMsYUFBYSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQzs0Q0FDZTtBQTlCbkQsb0NBbUNDO0FBRUQ7Ozs7O0dBS0c7QUFDSCxNQUFhLDBCQUEyQixTQUFRLFlBQVk7SUFBNUQ7O1FBSWtCLFlBQU8sR0FBYSxFQUFFLENBQUM7UUFJdkIsZUFBVSxHQUFZLEtBQUssQ0FBQztRQUk1QixlQUFVLEdBQVksS0FBSyxDQUFDO0lBSzlDLENBQUM7Q0FBQTtBQWJDO0lBRkMsb0JBQVEsQ0FBQyxNQUFNLENBQUM7SUFDaEIsMEJBQUssQ0FBQyxtQ0FBYyxDQUFDOzJEQUNpQjtBQUl2QztJQUZDLG9CQUFRLENBQUMsQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLEVBQUUsMEJBQWMsQ0FBQyxPQUFPLENBQUM7SUFDbkQsNEJBQU87OERBQ29DO0FBSTVDO0lBRkMsb0JBQVEsQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsRUFBRSwwQkFBYyxDQUFDLE9BQU8sQ0FBQztJQUNuRCw0QkFBTzs4REFDb0M7QUFaOUMsZ0VBaUJDIn0=