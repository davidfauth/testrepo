"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-07-02.
 */
Object.defineProperty(exports, "__esModule", { value: true });
function default_1(sequelize, DataTypes) {
    const alertFolder = sequelize.define('alertFolder', {
        title: {
            type: DataTypes.STRING,
            allowNull: false
        },
        sourceKey: {
            type: DataTypes.STRING(8),
            allowNull: false
        }
    }, {
        charset: 'utf8',
        classMethods: {
            associate: (models) => {
                // no constrains: -1 is legal for root folder
                alertFolder.belongsTo(alertFolder, {
                    foreignKey: 'parent',
                    constraints: false
                });
            }
        }
    });
    return alertFolder;
}
exports.default = default_1;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWxlcnRGb2xkZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvbW9kZWxzL3NxbC9hbGVydEZvbGRlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7O0dBS0c7O0FBc0JILG1CQUNFLFNBQThCLEVBQzlCLFNBQThCO0lBRTlCLE1BQU0sV0FBVyxHQUFHLFNBQVMsQ0FBQyxNQUFNLENBQ2xDLGFBQWEsRUFDYjtRQUNFLEtBQUssRUFBRTtZQUNMLElBQUksRUFBRSxTQUFTLENBQUMsTUFBTTtZQUN0QixTQUFTLEVBQUUsS0FBSztTQUNqQjtRQUNELFNBQVMsRUFBRTtZQUNULElBQUksRUFBRSxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztZQUN6QixTQUFTLEVBQUUsS0FBSztTQUNqQjtLQUNGLEVBQ0Q7UUFDRSxPQUFPLEVBQUUsTUFBTTtRQUNmLFlBQVksRUFBRTtZQUNaLFNBQVMsRUFBRSxDQUFDLE1BQW1CLEVBQUUsRUFBRTtnQkFDakMsNkNBQTZDO2dCQUM3QyxXQUFXLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRTtvQkFDakMsVUFBVSxFQUFFLFFBQVE7b0JBQ3BCLFdBQVcsRUFBRSxLQUFLO2lCQUNuQixDQUFDLENBQUM7WUFDTCxDQUFDO1NBQ0Y7S0FDRixDQUNGLENBQUM7SUFDRixPQUFPLFdBQVcsQ0FBQztBQUNyQixDQUFDO0FBOUJELDRCQThCQyJ9