"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2015-01-22.
 */
Object.defineProperty(exports, "__esModule", { value: true });
const DBFields = require('../../lib/DBFields');
function default_1(sequelize, DataTypes) {
    const dataSourceState = sequelize.define('dataSourceState', {
        /**
         * Created by `DataSource.computeSourceInfo`.
         * Available here for easier debugging as this explicitly contains the graph server info
         */
        info: {
            allowNull: false,
            type: DataTypes.STRING(200),
            unique: true
        },
        /**
         * Created by `DataSource.computeSourceKey`
         */
        key: {
            allowNull: false,
            type: DataTypes.STRING(8),
            unique: true
        },
        /**
         * Last time this data-source was seen online
         */
        lastSeen: {
            allowNull: false,
            type: DataTypes.DATE()
        },
        /**
         * Last time this data-source was fully indexed
         */
        lastIndexed: {
            allowNull: true,
            field: 'indexedDate',
            type: DataTypes.DATE()
        },
        /**
         * Last time this data-source was fully sampled
         */
        lastSampled: {
            allowNull: true,
            type: DataTypes.DATE()
        },
        /**
         * Human-readable name of the data-source (copied from `config.name`)
         */
        name: {
            allowNull: true,
            type: DataTypes.STRING(200)
        },
        /**
         * Machine-readable name of the last used Graph DAO vendor (copied from `config.graphdb.vendor`)
         */
        graphVendor: {
            allowNull: true,
            type: DataTypes.STRING(100)
        },
        /**
         * Machine-readable name of the last used Index DAO vendor (copied from `config.index.vendor`)
         */
        indexVendor: {
            allowNull: true,
            type: DataTypes.STRING(100)
        },
        /**
         * Error message if the last indexation failed or got interrupted, `null` otherwise
         */
        indexationError: {
            allowNull: true,
            type: DataTypes.TEXT()
        },
        /**
         * Error message if the last sampling failed or got interrupted, `null` otherwise
         */
        samplingError: {
            allowNull: true,
            type: DataTypes.TEXT()
        },
        needReindex: {
            allowNull: false,
            type: DataTypes.BOOLEAN,
            defaultValue: false
        },
        options: DBFields.generateJsonField('options', { strictSchema: false }),
        noIndexNodeProperties: DBFields.generateJsonField('noIndexNodeProperties'),
        // @backward-compatibility LKE v2.8.0 hiddenNodeProperties field was deprecated in favor of schema visibility
        hiddenNodeProperties: DBFields.generateJsonField('hiddenNodeProperties'),
        noIndexEdgeProperties: DBFields.generateJsonField('noIndexEdgeProperties'),
        // @backward-compatibility LKE v2.8.0 hiddenEdgeProperties field was deprecated in favor of schema visibility
        hiddenEdgeProperties: DBFields.generateJsonField('hiddenEdgeProperties'),
        defaultCaptions: DBFields.generateJsonField('defaultCaptions'),
        defaultStyles: DBFields.generateJsonField('defaultStyles')
    }, {
        charset: 'utf8'
    });
    return dataSourceState;
}
exports.default = default_1;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGF0YVNvdXJjZVN0YXRlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL21vZGVscy9zcWwvZGF0YVNvdXJjZVN0YXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRzs7QUFRSCxNQUFNLFFBQVEsR0FBRyxPQUFPLENBQUMsb0JBQW9CLENBQUMsQ0FBQztBQW9DL0MsbUJBQ0UsU0FBOEIsRUFDOUIsU0FBOEI7SUFFOUIsTUFBTSxlQUFlLEdBQUcsU0FBUyxDQUFDLE1BQU0sQ0FDdEMsaUJBQWlCLEVBQ2pCO1FBQ0U7OztXQUdHO1FBQ0gsSUFBSSxFQUFFO1lBQ0osU0FBUyxFQUFFLEtBQUs7WUFDaEIsSUFBSSxFQUFFLFNBQVMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO1lBQzNCLE1BQU0sRUFBRSxJQUFJO1NBQ2I7UUFFRDs7V0FFRztRQUNILEdBQUcsRUFBRTtZQUNILFNBQVMsRUFBRSxLQUFLO1lBQ2hCLElBQUksRUFBRSxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztZQUN6QixNQUFNLEVBQUUsSUFBSTtTQUNiO1FBRUQ7O1dBRUc7UUFDSCxRQUFRLEVBQUU7WUFDUixTQUFTLEVBQUUsS0FBSztZQUNoQixJQUFJLEVBQUUsU0FBUyxDQUFDLElBQUksRUFBRTtTQUN2QjtRQUVEOztXQUVHO1FBQ0gsV0FBVyxFQUFFO1lBQ1gsU0FBUyxFQUFFLElBQUk7WUFDZixLQUFLLEVBQUUsYUFBYTtZQUNwQixJQUFJLEVBQUUsU0FBUyxDQUFDLElBQUksRUFBRTtTQUN2QjtRQUVEOztXQUVHO1FBQ0gsV0FBVyxFQUFFO1lBQ1gsU0FBUyxFQUFFLElBQUk7WUFDZixJQUFJLEVBQUUsU0FBUyxDQUFDLElBQUksRUFBRTtTQUN2QjtRQUVEOztXQUVHO1FBQ0gsSUFBSSxFQUFFO1lBQ0osU0FBUyxFQUFFLElBQUk7WUFDZixJQUFJLEVBQUUsU0FBUyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7U0FDNUI7UUFFRDs7V0FFRztRQUNILFdBQVcsRUFBRTtZQUNYLFNBQVMsRUFBRSxJQUFJO1lBQ2YsSUFBSSxFQUFFLFNBQVMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO1NBQzVCO1FBRUQ7O1dBRUc7UUFDSCxXQUFXLEVBQUU7WUFDWCxTQUFTLEVBQUUsSUFBSTtZQUNmLElBQUksRUFBRSxTQUFTLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztTQUM1QjtRQUVEOztXQUVHO1FBQ0gsZUFBZSxFQUFFO1lBQ2YsU0FBUyxFQUFFLElBQUk7WUFDZixJQUFJLEVBQUUsU0FBUyxDQUFDLElBQUksRUFBRTtTQUN2QjtRQUVEOztXQUVHO1FBQ0gsYUFBYSxFQUFFO1lBQ2IsU0FBUyxFQUFFLElBQUk7WUFDZixJQUFJLEVBQUUsU0FBUyxDQUFDLElBQUksRUFBRTtTQUN2QjtRQUVELFdBQVcsRUFBRTtZQUNYLFNBQVMsRUFBRSxLQUFLO1lBQ2hCLElBQUksRUFBRSxTQUFTLENBQUMsT0FBTztZQUN2QixZQUFZLEVBQUUsS0FBSztTQUNwQjtRQUVELE9BQU8sRUFBRSxRQUFRLENBQUMsaUJBQWlCLENBQUMsU0FBUyxFQUFFLEVBQUMsWUFBWSxFQUFFLEtBQUssRUFBQyxDQUFDO1FBRXJFLHFCQUFxQixFQUFFLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyx1QkFBdUIsQ0FBQztRQUUxRSw2R0FBNkc7UUFDN0csb0JBQW9CLEVBQUUsUUFBUSxDQUFDLGlCQUFpQixDQUFDLHNCQUFzQixDQUFDO1FBRXhFLHFCQUFxQixFQUFFLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyx1QkFBdUIsQ0FBQztRQUUxRSw2R0FBNkc7UUFDN0csb0JBQW9CLEVBQUUsUUFBUSxDQUFDLGlCQUFpQixDQUFDLHNCQUFzQixDQUFDO1FBRXhFLGVBQWUsRUFBRSxRQUFRLENBQUMsaUJBQWlCLENBQUMsaUJBQWlCLENBQUM7UUFFOUQsYUFBYSxFQUFFLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxlQUFlLENBQUM7S0FDM0QsRUFDRDtRQUNFLE9BQU8sRUFBRSxNQUFNO0tBQ2hCLENBQ0YsQ0FBQztJQUNGLE9BQU8sZUFBZSxDQUFDO0FBQ3pCLENBQUM7QUF0SEQsNEJBc0hDIn0=