"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-10-08.
 */
Object.defineProperty(exports, "__esModule", { value: true });
// TS2019-DONE
const rest_client_1 = require("@linkurious/rest-client");
const DBFields = require("../../../lib/DBFields");
function default_1(sequelize, DataTypes) {
    const nodeProperty = sequelize.define('nodeProperty', {
        propertyKey: {
            field: 'key',
            type: DataTypes.STRING,
            allowNull: false
        },
        sourceKey: {
            type: DataTypes.STRING(8),
            allowNull: false
        },
        required: {
            type: DataTypes.BOOLEAN,
            allowNull: false
        },
        visibility: {
            type: DataTypes.STRING(20),
            allowNull: false
        },
        propertyType: DBFields.generateJsonField('propertyType', { name: rest_client_1.LkPropertyType.AUTO })
    }, {
        charset: 'utf8',
        timestamps: false,
        classMethods: {
            associate: (models) => {
                // A property is uniquely linked to a node type.
                // Different properties can have the same names but belong to different node types
                models.nodeType.hasMany(nodeProperty, { foreignKey: 'typeId' });
            }
        }
    });
    return nodeProperty;
}
exports.default = default_1;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTm9kZVByb3BlcnR5LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc2VydmVyL21vZGVscy9zcWwvZ3JhcGhTY2hlbWEvTm9kZVByb3BlcnR5LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRzs7QUFFSCxjQUFjO0FBRWQseURBQXVEO0FBR3ZELGtEQUFtRDtBQUtuRCxtQkFDRSxTQUE4QixFQUM5QixTQUE4QjtJQUU5QixNQUFNLFlBQVksR0FBRyxTQUFTLENBQUMsTUFBTSxDQUNuQyxjQUFjLEVBQ2Q7UUFDRSxXQUFXLEVBQUU7WUFDWCxLQUFLLEVBQUUsS0FBSztZQUNaLElBQUksRUFBRSxTQUFTLENBQUMsTUFBTTtZQUN0QixTQUFTLEVBQUUsS0FBSztTQUNqQjtRQUNELFNBQVMsRUFBRTtZQUNULElBQUksRUFBRSxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztZQUN6QixTQUFTLEVBQUUsS0FBSztTQUNqQjtRQUNELFFBQVEsRUFBRTtZQUNSLElBQUksRUFBRSxTQUFTLENBQUMsT0FBTztZQUN2QixTQUFTLEVBQUUsS0FBSztTQUNqQjtRQUNELFVBQVUsRUFBRTtZQUNWLElBQUksRUFBRSxTQUFTLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztZQUMxQixTQUFTLEVBQUUsS0FBSztTQUNqQjtRQUNELFlBQVksRUFBRSxRQUFRLENBQUMsaUJBQWlCLENBQUMsY0FBYyxFQUFFLEVBQUMsSUFBSSxFQUFFLDRCQUFjLENBQUMsSUFBSSxFQUFDLENBQUM7S0FDdEYsRUFDRDtRQUNFLE9BQU8sRUFBRSxNQUFNO1FBQ2YsVUFBVSxFQUFFLEtBQUs7UUFDakIsWUFBWSxFQUFFO1lBQ1osU0FBUyxFQUFFLENBQUMsTUFBbUIsRUFBRSxFQUFFO2dCQUNqQyxnREFBZ0Q7Z0JBQ2hELGtGQUFrRjtnQkFDbEYsTUFBTSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsWUFBWSxFQUFFLEVBQUMsVUFBVSxFQUFFLFFBQVEsRUFBQyxDQUFDLENBQUM7WUFDaEUsQ0FBQztTQUNGO0tBQ0YsQ0FDRixDQUFDO0lBRUYsT0FBTyxZQUFZLENBQUM7QUFDdEIsQ0FBQztBQXhDRCw0QkF3Q0MifQ==