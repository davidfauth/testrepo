"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-10-08.
 */
Object.defineProperty(exports, "__esModule", { value: true });
function default_1(sequelize, DataTypes) {
    return sequelize.define('nodeType', {
        label: {
            field: 'name',
            type: DataTypes.STRING,
            allowNull: false
        },
        sourceKey: {
            type: DataTypes.STRING(8),
            allowNull: false
        },
        visibility: {
            type: DataTypes.STRING(20),
            allowNull: false
        }
    }, {
        charset: 'utf8',
        timestamps: false
    });
}
exports.default = default_1;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTm9kZVR5cGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvbW9kZWxzL3NxbC9ncmFwaFNjaGVtYS9Ob2RlVHlwZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7O0dBS0c7O0FBVUgsbUJBQ0UsU0FBOEIsRUFDOUIsU0FBOEI7SUFFOUIsT0FBTyxTQUFTLENBQUMsTUFBTSxDQUNyQixVQUFVLEVBQ1Y7UUFDRSxLQUFLLEVBQUU7WUFDTCxLQUFLLEVBQUUsTUFBTTtZQUNiLElBQUksRUFBRSxTQUFTLENBQUMsTUFBTTtZQUN0QixTQUFTLEVBQUUsS0FBSztTQUNqQjtRQUNELFNBQVMsRUFBRTtZQUNULElBQUksRUFBRSxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztZQUN6QixTQUFTLEVBQUUsS0FBSztTQUNqQjtRQUNELFVBQVUsRUFBRTtZQUNWLElBQUksRUFBRSxTQUFTLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztZQUMxQixTQUFTLEVBQUUsS0FBSztTQUNqQjtLQUNGLEVBQ0Q7UUFDRSxPQUFPLEVBQUUsTUFBTTtRQUNmLFVBQVUsRUFBRSxLQUFLO0tBQ2xCLENBQ0YsQ0FBQztBQUNKLENBQUM7QUExQkQsNEJBMEJDIn0=