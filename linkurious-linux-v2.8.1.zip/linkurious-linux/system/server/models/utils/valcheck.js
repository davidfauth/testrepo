"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-06-21.
 */
Object.defineProperty(exports, "__esModule", { value: true });
// TS2019-DONE
const ValcheckNode_1 = require("valcheck/lib/valcheck/ValcheckNode");
const Bug_1 = require("../errors/Bug");
const InvalidParameter_1 = require("../errors/InvalidParameter");
exports.valcheck = new ValcheckNode_1.ValcheckNode(validationMessage => {
    throw new InvalidParameter_1.InvalidParameter(validationMessage);
}, bugMessage => {
    throw new Bug_1.Bug(bugMessage);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmFsY2hlY2suanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvbW9kZWxzL3V0aWxzL3ZhbGNoZWNrLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRzs7QUFFSCxjQUFjO0FBRWQscUVBQWdFO0FBRWhFLHVDQUFrQztBQUNsQyxpRUFBNEQ7QUFFL0MsUUFBQSxRQUFRLEdBQXdCLElBQUksMkJBQVksQ0FDM0QsaUJBQWlCLENBQUMsRUFBRTtJQUNsQixNQUFNLElBQUksbUNBQWdCLENBQUMsaUJBQWlCLENBQUMsQ0FBQztBQUNoRCxDQUFDLEVBQ0QsVUFBVSxDQUFDLEVBQUU7SUFDWCxNQUFNLElBQUksU0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQzVCLENBQUMsQ0FDRixDQUFDIn0=