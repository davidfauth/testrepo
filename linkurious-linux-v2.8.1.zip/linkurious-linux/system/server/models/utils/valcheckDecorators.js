"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-03-12.
 */
Object.defineProperty(exports, "__esModule", { value: true });
// TS2019-DONE
const _ = require("lodash");
require("reflect-metadata");
const valcheck_1 = require("./valcheck");
const DEFINITION_KEY = Symbol('Valcheck field definition');
function getFieldDefinition(target) {
    const prototype = typeof target === 'function' ? target.prototype : Object.getPrototypeOf(target);
    return getMetaData(prototype);
}
exports.getFieldDefinition = getFieldDefinition;
function getMetaData(target) {
    return _.cloneDeep(Reflect.getMetadata(DEFINITION_KEY, target) || {});
}
function setMetaData(target, metadata) {
    Reflect.defineMetadata(DEFINITION_KEY, metadata, target);
}
function addRule(target, path, definition) {
    const metadata = getMetaData(target);
    const existingDefinition = _.get(metadata, path, {});
    _.merge(existingDefinition, definition);
    _.set(metadata, path, existingDefinition);
    setMetaData(target, metadata);
}
function genericObject(construct) {
    return (target, propertyKey) => {
        const metadata = getMetaData(construct.prototype);
        addRule(target, propertyKey, { anyProperty: { properties: metadata } });
    };
}
exports.genericObject = genericObject;
function properties(construct) {
    return (target, propertyKey) => {
        const metadata = getMetaData(construct.prototype);
        addRule(target, propertyKey, { properties: metadata });
    };
}
exports.properties = properties;
/**
 * Resolve the property class from the property value.
 *
 * This decorator can be used when the property type is not known statically.
 * The parameter is a type resolver; a function that given the property key and value, returns the correct class.
 *
 * @param typeResolver A method that returns the correct class from the property key and value
 */
function dynamicProperties(typeResolver) {
    return (target, propertyKey) => {
        addRule(target, propertyKey, {
            check: (key, value) => {
                const metadata = getMetaData(typeResolver(key, value).prototype);
                valcheck_1.valcheck.property(key, value, { properties: metadata });
            }
        });
    };
}
exports.dynamicProperties = dynamicProperties;
function required(target, propertyKey) {
    addRule(target, propertyKey, { required: true });
}
exports.required = required;
function unknown(target, propertyKey) {
    addRule(target, propertyKey, {});
}
exports.unknown = unknown;
function excluded(target, propertyKey) {
    const metadata = getMetaData(target);
    delete metadata[propertyKey];
    Reflect.defineMetadata(DEFINITION_KEY, metadata, target);
}
exports.excluded = excluded;
function string(target, propertyKey) {
    addRule(target, propertyKey, { type: 'string' });
}
exports.string = string;
function object(...anyPropertyItemRules) {
    return (target, propertyKey) => {
        addRule(target, propertyKey, { type: 'object' });
        anyPropertyItemRules.forEach(apply => apply(target, `${propertyKey}.anyProperty`));
    };
}
exports.object = object;
function boolean(target, propertyKey) {
    addRule(target, propertyKey, { type: 'boolean' });
}
exports.boolean = boolean;
function posInt(target, propertyKey) {
    addRule(target, propertyKey, { check: 'posInt' });
}
exports.posInt = posInt;
function integer(target, propertyKey) {
    addRule(target, propertyKey, { check: ['integer'] });
}
exports.integer = integer;
function integerBetween(range) {
    return (target, propertyKey) => {
        addRule(target, propertyKey, { check: ['integer', range.min, range.max] });
    };
}
exports.integerBetween = integerBetween;
function values(allowed) {
    return (target, propertyKey) => {
        addRule(target, propertyKey, { values: _.values(allowed) });
    };
}
exports.values = values;
function check(method, ...args) {
    return (target, propertyKey) => {
        addRule(target, propertyKey, { check: [method, ...args] });
    };
}
exports.check = check;
function array(...arrayItemRules) {
    return (target, propertyKey) => {
        addRule(target, propertyKey, { type: 'array' });
        arrayItemRules.forEach(apply => apply(target, `${propertyKey}.arrayItem`));
    };
}
exports.array = array;
function url(target, propertyKey) {
    addRule(target, propertyKey, { check: 'url' });
}
exports.url = url;
function httpUrl(target, propertyKey) {
    addRule(target, propertyKey, { check: 'httpUrl' });
}
exports.httpUrl = httpUrl;
function nonEmptyString(target, propertyKey) {
    addRule(target, propertyKey, { check: ['string', true] });
}
exports.nonEmptyString = nonEmptyString;
function regExp(rx, pattern, ErrorType) {
    return (target, propertyKey) => {
        addRule(target, propertyKey, {
            check: (key, value) => {
                if (!rx.test(value)) {
                    throw new (ErrorType || Error)(`"${key}" must match the format ${pattern}`);
                }
            }
        });
    };
}
exports.regExp = regExp;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmFsY2hlY2tEZWNvcmF0b3JzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL21vZGVscy91dGlscy92YWxjaGVja0RlY29yYXRvcnMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7OztHQUtHOztBQUVILGNBQWM7QUFFZCw0QkFBNEI7QUFDNUIsNEJBQTBCO0FBTzFCLHlDQUFvQztBQUVwQyxNQUFNLGNBQWMsR0FBRyxNQUFNLENBQUMsMkJBQTJCLENBQUMsQ0FBQztBQU0zRCxTQUFnQixrQkFBa0IsQ0FDaEMsTUFBOEI7SUFFOUIsTUFBTSxTQUFTLEdBQUcsT0FBTyxNQUFNLEtBQUssVUFBVSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ2xHLE9BQU8sV0FBVyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQ2hDLENBQUM7QUFMRCxnREFLQztBQUVELFNBQVMsV0FBVyxDQUFDLE1BQWM7SUFDakMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsY0FBYyxFQUFFLE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDO0FBQ3hFLENBQUM7QUFFRCxTQUFTLFdBQVcsQ0FBQyxNQUFjLEVBQUUsUUFBZ0I7SUFDbkQsT0FBTyxDQUFDLGNBQWMsQ0FBQyxjQUFjLEVBQUUsUUFBUSxFQUFFLE1BQU0sQ0FBQyxDQUFDO0FBQzNELENBQUM7QUFFRCxTQUFTLE9BQU8sQ0FBQyxNQUFjLEVBQUUsSUFBWSxFQUFFLFVBQXdCO0lBQ3JFLE1BQU0sUUFBUSxHQUFHLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNyQyxNQUFNLGtCQUFrQixHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQztJQUNyRCxDQUFDLENBQUMsS0FBSyxDQUFDLGtCQUFrQixFQUFFLFVBQVUsQ0FBQyxDQUFDO0lBQ3hDLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxrQkFBa0IsQ0FBQyxDQUFDO0lBQzFDLFdBQVcsQ0FBQyxNQUFNLEVBQUUsUUFBUSxDQUFDLENBQUM7QUFDaEMsQ0FBQztBQUVELFNBQWdCLGFBQWEsQ0FBbUIsU0FBNkI7SUFDM0UsT0FBTyxDQUFDLE1BQWMsRUFBRSxXQUFtQixFQUFFLEVBQUU7UUFDN0MsTUFBTSxRQUFRLEdBQUcsV0FBVyxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUNsRCxPQUFPLENBQUMsTUFBTSxFQUFFLFdBQVcsRUFBRSxFQUFDLFdBQVcsRUFBRSxFQUFDLFVBQVUsRUFBRSxRQUFRLEVBQUMsRUFBQyxDQUFDLENBQUM7SUFDdEUsQ0FBQyxDQUFDO0FBQ0osQ0FBQztBQUxELHNDQUtDO0FBRUQsU0FBZ0IsVUFBVSxDQUFtQixTQUE2QjtJQUN4RSxPQUFPLENBQUMsTUFBYyxFQUFFLFdBQW1CLEVBQUUsRUFBRTtRQUM3QyxNQUFNLFFBQVEsR0FBRyxXQUFXLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ2xELE9BQU8sQ0FBQyxNQUFNLEVBQUUsV0FBVyxFQUFFLEVBQUMsVUFBVSxFQUFFLFFBQVEsRUFBQyxDQUFDLENBQUM7SUFDdkQsQ0FBQyxDQUFDO0FBQ0osQ0FBQztBQUxELGdDQUtDO0FBRUQ7Ozs7Ozs7R0FPRztBQUNILFNBQWdCLGlCQUFpQixDQUFtQixZQUE2QjtJQUMvRSxPQUFPLENBQUMsTUFBYyxFQUFFLFdBQW1CLEVBQUUsRUFBRTtRQUM3QyxPQUFPLENBQUMsTUFBTSxFQUFFLFdBQVcsRUFBRTtZQUMzQixLQUFLLEVBQUUsQ0FBQyxHQUFXLEVBQUUsS0FBYyxFQUFFLEVBQUU7Z0JBQ3JDLE1BQU0sUUFBUSxHQUFHLFdBQVcsQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDO2dCQUNqRSxtQkFBUSxDQUFDLFFBQVEsQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFLEVBQUMsVUFBVSxFQUFFLFFBQVEsRUFBQyxDQUFDLENBQUM7WUFDeEQsQ0FBQztTQUNGLENBQUMsQ0FBQztJQUNMLENBQUMsQ0FBQztBQUNKLENBQUM7QUFURCw4Q0FTQztBQUVELFNBQWdCLFFBQVEsQ0FBQyxNQUFjLEVBQUUsV0FBbUI7SUFDMUQsT0FBTyxDQUFDLE1BQU0sRUFBRSxXQUFXLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFDLENBQUMsQ0FBQztBQUNqRCxDQUFDO0FBRkQsNEJBRUM7QUFFRCxTQUFnQixPQUFPLENBQUMsTUFBYyxFQUFFLFdBQW1CO0lBQ3pELE9BQU8sQ0FBQyxNQUFNLEVBQUUsV0FBVyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQ25DLENBQUM7QUFGRCwwQkFFQztBQUVELFNBQWdCLFFBQVEsQ0FBQyxNQUFjLEVBQUUsV0FBbUI7SUFDMUQsTUFBTSxRQUFRLEdBQUcsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ3JDLE9BQU8sUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQzdCLE9BQU8sQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLFFBQVEsRUFBRSxNQUFNLENBQUMsQ0FBQztBQUMzRCxDQUFDO0FBSkQsNEJBSUM7QUFFRCxTQUFnQixNQUFNLENBQUMsTUFBYyxFQUFFLFdBQW1CO0lBQ3hELE9BQU8sQ0FBQyxNQUFNLEVBQUUsV0FBVyxFQUFFLEVBQUMsSUFBSSxFQUFFLFFBQVEsRUFBQyxDQUFDLENBQUM7QUFDakQsQ0FBQztBQUZELHdCQUVDO0FBRUQsU0FBZ0IsTUFBTSxDQUFDLEdBQUcsb0JBQWlDO0lBQ3pELE9BQU8sQ0FBQyxNQUFjLEVBQUUsV0FBbUIsRUFBRSxFQUFFO1FBQzdDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsV0FBVyxFQUFFLEVBQUMsSUFBSSxFQUFFLFFBQVEsRUFBQyxDQUFDLENBQUM7UUFDL0Msb0JBQW9CLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxHQUFHLFdBQVcsY0FBYyxDQUFDLENBQUMsQ0FBQztJQUNyRixDQUFDLENBQUM7QUFDSixDQUFDO0FBTEQsd0JBS0M7QUFFRCxTQUFnQixPQUFPLENBQUMsTUFBYyxFQUFFLFdBQW1CO0lBQ3pELE9BQU8sQ0FBQyxNQUFNLEVBQUUsV0FBVyxFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQyxDQUFDLENBQUM7QUFDbEQsQ0FBQztBQUZELDBCQUVDO0FBRUQsU0FBZ0IsTUFBTSxDQUFDLE1BQWMsRUFBRSxXQUFtQjtJQUN4RCxPQUFPLENBQUMsTUFBTSxFQUFFLFdBQVcsRUFBRSxFQUFDLEtBQUssRUFBRSxRQUFRLEVBQUMsQ0FBQyxDQUFDO0FBQ2xELENBQUM7QUFGRCx3QkFFQztBQUVELFNBQWdCLE9BQU8sQ0FBQyxNQUFjLEVBQUUsV0FBbUI7SUFDekQsT0FBTyxDQUFDLE1BQU0sRUFBRSxXQUFXLEVBQUUsRUFBQyxLQUFLLEVBQUUsQ0FBQyxTQUFTLENBQUMsRUFBQyxDQUFDLENBQUM7QUFDckQsQ0FBQztBQUZELDBCQUVDO0FBRUQsU0FBZ0IsY0FBYyxDQUFDLEtBQW1DO0lBQ2hFLE9BQU8sQ0FBQyxNQUFjLEVBQUUsV0FBbUIsRUFBRSxFQUFFO1FBQzdDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsV0FBVyxFQUFFLEVBQUMsS0FBSyxFQUFFLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFDLENBQUMsQ0FBQztJQUMzRSxDQUFDLENBQUM7QUFDSixDQUFDO0FBSkQsd0NBSUM7QUFFRCxTQUFnQixNQUFNLENBQUMsT0FBMEI7SUFDL0MsT0FBTyxDQUFDLE1BQWMsRUFBRSxXQUFtQixFQUFFLEVBQUU7UUFDN0MsT0FBTyxDQUFDLE1BQU0sRUFBRSxXQUFXLEVBQUUsRUFBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsRUFBQyxDQUFDLENBQUM7SUFDNUQsQ0FBQyxDQUFDO0FBQ0osQ0FBQztBQUpELHdCQUlDO0FBRUQsU0FBZ0IsS0FBSyxDQUFJLE1BQTZCLEVBQUUsR0FBRyxJQUFlO0lBQ3hFLE9BQU8sQ0FBQyxNQUFjLEVBQUUsV0FBbUIsRUFBRSxFQUFFO1FBQzdDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsV0FBVyxFQUFFLEVBQUMsS0FBSyxFQUFFLENBQUMsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQzNELENBQUMsQ0FBQztBQUNKLENBQUM7QUFKRCxzQkFJQztBQUVELFNBQWdCLEtBQUssQ0FBQyxHQUFHLGNBQTJCO0lBQ2xELE9BQU8sQ0FBQyxNQUFjLEVBQUUsV0FBbUIsRUFBRSxFQUFFO1FBQzdDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsV0FBVyxFQUFFLEVBQUMsSUFBSSxFQUFFLE9BQU8sRUFBQyxDQUFDLENBQUM7UUFDOUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsR0FBRyxXQUFXLFlBQVksQ0FBQyxDQUFDLENBQUM7SUFDN0UsQ0FBQyxDQUFDO0FBQ0osQ0FBQztBQUxELHNCQUtDO0FBRUQsU0FBZ0IsR0FBRyxDQUFDLE1BQWMsRUFBRSxXQUFtQjtJQUNyRCxPQUFPLENBQUMsTUFBTSxFQUFFLFdBQVcsRUFBRSxFQUFDLEtBQUssRUFBRSxLQUFLLEVBQUMsQ0FBQyxDQUFDO0FBQy9DLENBQUM7QUFGRCxrQkFFQztBQUVELFNBQWdCLE9BQU8sQ0FBQyxNQUFjLEVBQUUsV0FBbUI7SUFDekQsT0FBTyxDQUFDLE1BQU0sRUFBRSxXQUFXLEVBQUUsRUFBQyxLQUFLLEVBQUUsU0FBUyxFQUFDLENBQUMsQ0FBQztBQUNuRCxDQUFDO0FBRkQsMEJBRUM7QUFFRCxTQUFnQixjQUFjLENBQUMsTUFBYyxFQUFFLFdBQW1CO0lBQ2hFLE9BQU8sQ0FBQyxNQUFNLEVBQUUsV0FBVyxFQUFFLEVBQUMsS0FBSyxFQUFFLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUMxRCxDQUFDO0FBRkQsd0NBRUM7QUFFRCxTQUFnQixNQUFNLENBQ3BCLEVBQVUsRUFDVixPQUFlLEVBQ2YsU0FBa0M7SUFFbEMsT0FBTyxDQUFDLE1BQWMsRUFBRSxXQUFtQixFQUFFLEVBQUU7UUFDN0MsT0FBTyxDQUFDLE1BQU0sRUFBRSxXQUFXLEVBQUU7WUFDM0IsS0FBSyxFQUFFLENBQUMsR0FBVyxFQUFFLEtBQWMsRUFBRSxFQUFFO2dCQUNyQyxJQUFJLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxLQUFlLENBQUMsRUFBRTtvQkFDN0IsTUFBTSxJQUFJLENBQUMsU0FBUyxJQUFJLEtBQUssQ0FBQyxDQUFDLElBQUksR0FBRywyQkFBMkIsT0FBTyxFQUFFLENBQUMsQ0FBQztpQkFDN0U7WUFDSCxDQUFDO1NBQ0YsQ0FBQyxDQUFDO0lBQ0wsQ0FBQyxDQUFDO0FBQ0osQ0FBQztBQWRELHdCQWNDIn0=