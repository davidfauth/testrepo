"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2015-06-26.
 */
const cla = require("commander");
class Options {
    constructor() {
        this.RESET_OPTION = 'reset-config';
    }
    // TODO #1424 move under models, rename to LKEOptions, parse should call the constructor and return an instance of it
    /**
     * Detect the application runtime mode from the `NODE_ENV` environment variable.
     * If not defined, fallback to the default mode 'production'.
     *
     * The application runtime mode can also be overwritten by command line arguments.
     * Parse also the reset config command line argument if specified.
     *
     * @param LKE
     */
    parse(LKE) {
        // read mode from shell environment
        let mode = process.env.NODE_ENV || '';
        if (!LKE.MODES.includes(mode)) {
            // if the detected mode does not exist in the list of modes, fallback to default mode
            mode = LKE.DEFAULT_MODE;
        }
        // read mode from command line arguments
        cla
            .option('-r, --' + this.RESET_OPTION, 'Reset the configuration to defaults')
            .option('-d, --' + LKE.MODE_DEV, 'Run app in ' + LKE.MODE_DEV + ' mode')
            .option('-p, --' + LKE.MODE_PROD, 'Run app in ' + LKE.MODE_PROD + ' mode')
            .option('-t, --' + LKE.MODE_TEST, 'Run app in ' + LKE.MODE_TEST + ' mode')
            .option('-a, --' + LKE.MODE_PRE_PROD, 'Run app in ' + LKE.MODE_PRE_PROD + ' mode')
            .parse(process.argv);
        LKE.MODES.forEach(m => {
            if (cla[m]) {
                mode = m;
            }
        });
        return {
            mode: mode,
            resetConfig: cla.resetConfig
        };
    }
}
module.exports = new Options();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib3B0aW9ucy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NlcnZlci9vcHRpb25zLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRztBQUNILGlDQUFpQztBQUVqQyxNQUFNLE9BQU87SUFBYjtRQUNrQixpQkFBWSxHQUFHLGNBQWMsQ0FBQztJQXlDaEQsQ0FBQztJQXZDQyxxSEFBcUg7SUFFckg7Ozs7Ozs7O09BUUc7SUFDSSxLQUFLLENBQUMsR0FBbUI7UUFDOUIsbUNBQW1DO1FBQ25DLElBQUksSUFBSSxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxJQUFJLEVBQUUsQ0FBQztRQUN0QyxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDN0IscUZBQXFGO1lBQ3JGLElBQUksR0FBRyxHQUFHLENBQUMsWUFBWSxDQUFDO1NBQ3pCO1FBRUQsd0NBQXdDO1FBQ3hDLEdBQUc7YUFDQSxNQUFNLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxZQUFZLEVBQUUscUNBQXFDLENBQUM7YUFDM0UsTUFBTSxDQUFDLFFBQVEsR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLGFBQWEsR0FBRyxHQUFHLENBQUMsUUFBUSxHQUFHLE9BQU8sQ0FBQzthQUN2RSxNQUFNLENBQUMsUUFBUSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsYUFBYSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEdBQUcsT0FBTyxDQUFDO2FBQ3pFLE1BQU0sQ0FBQyxRQUFRLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxhQUFhLEdBQUcsR0FBRyxDQUFDLFNBQVMsR0FBRyxPQUFPLENBQUM7YUFDekUsTUFBTSxDQUFDLFFBQVEsR0FBRyxHQUFHLENBQUMsYUFBYSxFQUFFLGFBQWEsR0FBRyxHQUFHLENBQUMsYUFBYSxHQUFHLE9BQU8sQ0FBQzthQUNqRixLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBRXZCLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFO1lBQ3BCLElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUNWLElBQUksR0FBRyxDQUFDLENBQUM7YUFDVjtRQUNILENBQUMsQ0FBQyxDQUFDO1FBRUgsT0FBTztZQUNMLElBQUksRUFBRSxJQUFJO1lBQ1YsV0FBVyxFQUFFLEdBQUcsQ0FBQyxXQUFXO1NBQzdCLENBQUM7SUFDSixDQUFDO0NBQ0Y7QUFFRCxpQkFBUyxJQUFJLE9BQU8sRUFBRSxDQUFDIn0=