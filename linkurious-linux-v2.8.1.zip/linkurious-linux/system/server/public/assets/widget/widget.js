/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2018
 *
 * Created by maximeallex on 2018-06-11.
 */

'use strict';

var switchSearch = function(a, b) {
  var c = document.createElement('p');
  (c.className = 'autocomplete_dropdown_item btn'),
    (c.tabIndex = b),
    'nodes' === LK.searchType
      ? (c.appendChild(document.createTextNode('Show edges')),
        (c.onclick = function() {
          LK.search('edges');
        }),
        c.addEventListener('keydown', function(a) {
          switch (e.keyCode) {
            case 13:
              LK.search('edges');
              LK.elements.resultList.focus();
              break;
            case 38:
              this.previousSibling ? this.previousSibling.focus() : this.parentNode.lastChild.focus();
              break;
            case 40:
            case 9:
              this.parentNode.firstChild.focus();
              break;
            default:
              LK.elements.resultList.focus();
          }
          a.preventDefault(), 9 != a.which && a.stopPropagation();
        }))
      : (c.appendChild(document.createTextNode('Show nodes')),
        (c.onclick = function() {
          LK.search('nodes');
        }),
        c.addEventListener('keydown', function(a) {
          switch (e.keyCode) {
            case 13:
              LK.search('nodes');
              LK.elements.resultList.focus();
              break;
            case 38:
              this.previousSibling ? this.previousSibling.focus() : this.parentNode.lastChild.focus();
              break;
            case 40:
            case 9:
              this.parentNode.firstChild.focus();
              break;
            default:
              LK.elements.resultList.focus();
          }
          a.preventDefault(), 9 != a.which && a.stopPropagation();
        })),
    a.appendChild(c);
};
/**
 * Select an item in the widgetPreview
 *
 * @param item
 */
var select = function(item) {
  LK.clearSearch();
  LK.ogma.getNodes().setSelected(false);
  LK.ogma.getEdges().setSelected(false);
  item.locate({ maxNodeSizeOnScreen: 80, duration: 700 }).then(function() {
    openTooltip(item);
    item.setSelected(true);
  });
};

/**
 * Open the tooltip for nodes / edges
 *
 * @param item
 */
var openTooltip = function(item) {
  LK.closeTooltip();
  var position;
  if (item.isNode) {
    position = item.getPositionOnScreen();
  } else {
    position = {
      x: (item.getSource().getPositionOnScreen().x + item.getTarget().getPositionOnScreen().x) / 2,
      y: (item.getSource().getPositionOnScreen().y + item.getTarget().getPositionOnScreen().y) / 2,
    };
  }
  position.autoAdjust = true;
  LK.ogma.tools.tooltip.show(item.isNode ? LK.nodeTooltip(item) : LK.edgeTooltip(item), position);
};
/**
 * Return the sanitized property value
 *
 * @param value
 * @return {*}
 */
var getPropertyValue = function(value) {
  if (typeof value === 'object' && value !== null) {
    if (value.type === 'date') {
      if (value.value) {
        return LK.formatDate(rawValue.value);
      } else {
        return LK.formatDate(rawValue.original);
      }
    } else if (value.type === 'datetime') {
      if (value.value) {
        return LK.formatDate(value.value, true);
      } else {
        return LK.formatDate(value.original, true);
      }
    } else {
      return value.original;
    }
  }
  return value;
};

/**
 * Test if a value is an url
 *
 * @param value
 * @param regEx
 * @return {boolean|*}
 */
var testUrl = function(value, regEx) {
  return typeof value === 'string' && regEx.test(value);
};

/**
 * Test if a value is an image
 *
 * @param value
 * @param regEx
 * @return {*}
 */
var testImage = function(value, regEx) {
  var link = document.createElement('a');
  link.href = value;
  return regEx.test(value);
};

/**
 * Set the score of a search result
 *
 * @param a
 * @param b
 * @param c
 * @return {number}
 */
var setScore = function(a, b, c) {
  var d,
    e,
    f,
    g = b.length,
    h = a.length,
    i = -a.length + 1,
    j = c || 10,
    k = 0.01;
  if (h > g) return Number.POSITIVE_INFINITY;
  if (h === g) return a === b ? -1 : Number.POSITIVE_INFINITY;
  if (1 == h) return (i = b.indexOf(a)), 0 > i ? Number.POSITIVE_INFINITY : i;
  a: for (e = 0, f = 0; h > e; e++) {
    for (d = a.charCodeAt(e); g > f; ) {
      if (((i += k), k && i > j)) return Number.POSITIVE_INFINITY;
      if (b.charCodeAt(f++) === d) {
        k = 1;
        continue a;
      }
    }
    return Number.POSITIVE_INFINITY;
  }
  return i;
};

/**
 * search for an item in the widgetPreview
 *
 * @param query
 * @param items
 */
var search = function(query, items) {
  return (
    (query = query.trim().toLowerCase()),
    items
      .map(function(i) {
        return {
          item: i,
          score: setScore(query, (i.getAttribute('text') || '').trim().toLowerCase(), 3),
        };
      })
      .filter(function(a) {
        return a.score !== Number.POSITIVE_INFINITY;
      })
      .sort(function(a, b) {
        return a.score - b.score;
      })
  );
};

var LK = {
  elements: {
    fullscreen: document.getElementById('viewController-fullscreen'),
    geo: document.getElementById('viewController-geo'),
    legend: document.getElementById('viewController-legend'),
    share: document.getElementById('viewController-share'),
    layout: document.getElementById('viewController-layout'),
    zoom: document.getElementsByClassName('zoom'),
    search: document.getElementById('searchbar'),
    shareModal: document.getElementById('share-overlay'),
    searchForm: document.getElementById('result-list__search'),
    searchInput: document.getElementById('result-list__input'),
    clearSearch: document.getElementById('autocomplete__reset'),
    resultList: document.getElementById('result-list__dropdown'),
    legendWrapper: document.getElementById('legend'),
    closeShare: document.getElementById('close_share_modal'),
    code: document.getElementById('code'),
    url: document.getElementById('url'),
    loader: document.getElementById('loader'),
  },
  searchType: 'nodes',
  layoutRunning: false,
  content: null,
  ogmaOptions: null,
  test: null,
  url: null,

  ogma: new Ogma({
    options: {
      backgroundColor: 'rgba(240, 240, 240, 1)',
    },
    graph: { nodes: [], edges: [] },
    renderer: 'webgl',
    imgCrossOrigin: 'anonymous',
    container: document.getElementById('graph-canvas'),
  }),

  /**
   * Initialize the widgetPreview
   *
   * @param content
   */
  init: function(content) {
    if (content && typeof content === 'object') {
      document.title = 'Linkurious Widget - ' + content.widget.title;
      if (content.widget.url) {
        LK.url = [null, undefined, 'localhost', '127.0.0.1'].some(function(url) {
          return content.widget.url.indexOf(url) >= 0;
        })
          ? location.origin + '/widget/' + content.widget.key
          : content.widget.url;
      } else {
        LK.url = null;
      }
      LK.content = content.widget.content;
      LK.ogmaOptions = content.ogmaOptions;
      LK.setGraph();
      LK.setUI();
    }
  },

  /**
   * Set the graph
   */
  setGraph: function(content) {
    LK.ogma.setGraph(JSON.parse(JSON.stringify(LK.content.graph))).then(function() {
      LK.elements.loader.style.display = 'none';
      if (LK.content.mode === 'geo') {
        LK.toggleGeoMode();
      }
      LK.ogma.getNodes().locate({ duration: 700 });
    });
    LK.ogma.styles.createClass({
      name: 'haloed',
      nodeAttributes: {
        halo: function(node) {
          if (
            node.isSelected() ||
            node
              .getAdjacentEdges()
              .isSelected()
              .includes(true) ||
            node
              .getAdjacentNodes()
              .isSelected()
              .includes(true)
          ) {
            return {
              color: '#FFF',
              size: 30,
              strokeWidth: 0,
            };
          } else {
            return null;
          }
        },
      },
      edgeAttributes: {
        halo: function(edge) {
          if (
            edge.isSelected() ||
            edge
              .getExtremities()
              .isSelected()
              .includes(true)
          ) {
            return {
              color: '#FFF',
              size: 15,
            };
          } else {
            return null;
          }
        },
      },
    });
    LK.ogma.styles.setHoveredNodeAttributes({
      text: { font: 'roboto-bold' },
      outline: { enabled: false },
      outerStroke: { width: 2 },
    });
    LK.ogma.styles.setSelectedNodeAttributes({
      text: { font: 'roboto-bold' },
      outline: { enabled: false },
      outerStroke: { width: 2 },
    });
    LK.ogma.styles.setHoveredEdgeAttributes({
      text: { font: 'roboto-bold' },
      outline: { enabled: false },
    });
    LK.ogma.styles.setSelectedEdgeAttributes({
      text: { font: 'roboto-bold' },
      outline: { enabled: false },
    });
    LK.ogma.styles.addEdgeRule(
      function() {
        return true;
      },
      {
        text: {
          minVisibleSize: LK.ogmaOptions.options.styles.edge.text.minVisibleSize
            ? LK.ogmaOptions.options.styles.edge.text.minVisibleSize
            : 12,
          maxLineLength: LK.ogmaOptions.options.styles.edge.text.maxLineLength
            ? LK.ogmaOptions.options.styles.edge.text.maxLineLength
            : 30,
          backgroundColor: LK.ogmaOptions.options.styles.edge.text.backgroundColor
            ? LK.ogmaOptions.options.styles.edge.text.backgroundColor
            : null,
          font: LK.ogmaOptions.options.styles.edge.text.font
            ? LK.ogmaOptions.options.styles.edge.text.font
            : 'roboto',
          color: LK.ogmaOptions.options.styles.edge.text.color
            ? LK.ogmaOptions.options.styles.edge.text.color
            : '#000',
          style: LK.ogmaOptions.options.styles.edge.text.style
            ? LK.ogmaOptions.options.styles.edge.text.style
            : 'normal',
          size: LK.ogmaOptions.options.styles.edge.text.size
            ? LK.ogmaOptions.options.styles.edge.text.size
            : 14,
        },
      }
    );
    LK.ogma.styles.addNodeRule(
      function() {
        return true;
      },
      {
        text: {
          minVisibleSize: LK.ogmaOptions.options.styles.node.text.minVisibleSize
            ? LK.ogmaOptions.options.styles.node.text.minVisibleSize
            : 12,
          maxLineLength: LK.ogmaOptions.options.styles.node.text.maxLineLength
            ? LK.ogmaOptions.options.styles.node.text.maxLineLength
            : 30,
          position: LK.ogmaOptions.options.styles.node.text.position
            ? LK.ogmaOptions.options.styles.node.text.position
            : 'bottom',
          backgroundColor: LK.ogmaOptions.options.styles.node.text.backgroundColor
            ? LK.ogmaOptions.options.styles.node.text.backgroundColor
            : null,
          font: LK.ogmaOptions.options.styles.node.text.font
            ? LK.ogmaOptions.options.styles.node.text.font
            : 'roboto',
          color: LK.ogmaOptions.options.styles.node.text.color
            ? LK.ogmaOptions.options.styles.node.text.color
            : '#000',
          style: LK.ogmaOptions.options.styles.node.text.style
            ? LK.ogmaOptions.options.styles.node.text.style
            : 'normal',
          size: LK.ogmaOptions.options.styles.node.text.size
            ? LK.ogmaOptions.options.styles.node.text.size
            : 14,
        },
        innerStroke: {
          width: 3,
        },
      }
    );
    LK.ogma.events.onNodesSelected(function(payload) {
      payload.nodes.getAdjacentNodes({ policy: 'include-sources' }).addClass('haloed');
      payload.nodes
        .getAdjacentEdges()
        .addClass('haloed')
        .then(function() {
          openTooltip(payload.nodes.get(0));
        });
    });
    LK.ogma.events.onNodesUnselected(function(payload) {
      payload.nodes.getAdjacentNodes({ policy: 'include-sources' }).removeClass('haloed');
      payload.nodes.getAdjacentEdges().removeClass('haloed');
    });
    LK.ogma.events.onEdgesSelected(function(payload) {
      payload.edges.addClass('haloed').then(function() {
        openTooltip(payload.edges.get(0));
      });
      payload.edges.getExtremities().addClass('haloed');
    });

    LK.ogma.events.onEdgesUnselected(function(payload) {
      payload.edges.removeClass('haloed');
      payload.edges.getExtremities().removeClass('haloed');
    });
    LK.ogma.events.onClick(function(e) {
      if (e.button === 'left') {
        if (e.target) {
          LK.ogma.getNodes().setSelected(false);
          LK.ogma.getEdges().setSelected(false);
          e.target.setSelected(true);
        }
      }
    });
  },

  /**
   * Set the UI element visibility
   */
  setUI: function() {
    // forEach ui element, show or hide depending on options saved
    Object.keys(LK.content.ui).forEach(function(element) {
      if (LK.content.ui[element] === true && LK.elements[element] && !LK.elements[element].length) {
        LK.show(LK.elements[element]);
      } else if (LK.content.ui[element] === true && LK.elements[element] && LK.elements[element].length) {
        for (var i = 0; i < LK.elements[element].length; ++i) {
          LK.show(LK.elements[element][i]);
        }
      }
    });

    // generate the legend
    if (LK.content.ui.legend === true) {
      LK.generateLegend(LK.content.legend);
    }

    // if there's no node with geo coordinates, hide the geo button
    if (
      LK.ogma
        .getNodes('all')
        .toArray()
        .every(function(n) {
          return n.getData('_geo') === undefined;
        })
    ) {
      LK.hide(LK.elements.geo);
    }

    LK.elements.geo.addEventListener('click', LK.toggleGeoMode);
    LK.elements.legend.addEventListener('click', LK.toggleLegend);
    LK.elements.share.addEventListener('click', LK.share);
    LK.elements.fullscreen.addEventListener('click', LK.fullscreen);
    LK.elements.zoom[0].addEventListener('click', LK.zoomIn);
    LK.elements.zoom[1].addEventListener('click', LK.zoomOut);
    LK.elements.closeShare.addEventListener('click', LK.closeShareOverlay);
    LK.elements.clearSearch.addEventListener('click', LK.clearSearch);
    LK.elements.searchInput.addEventListener('input', function() {
      LK.search();
    });
  },

  /**
   * Return the firstChild of the legendWrapper or undefined is the legend is not yet filled
   */
  isLegendAlreadyFilled: function() {
    return LK.elements.legendWrapper.firstChild;
  },

  /**
   * Generate the legend
   *
   * @param rawLegend
   */
  generateLegend: function(rawLegend) {
    Object.keys(rawLegend).forEach(function(entity) {
      Object.keys(rawLegend[entity]).forEach(function(legendStyle) {
        switch (legendStyle) {
          case 'color':
            if (rawLegend[entity][legendStyle].length > 0) {
              LK.elements.legendWrapper.appendChild(LK.generateColorLegend(rawLegend[entity][legendStyle]));
            }
            break;
          case 'icon':
            if (rawLegend[entity][legendStyle].length > 0) {
              LK.elements.legendWrapper.appendChild(LK.generateIconLegend(rawLegend[entity][legendStyle]));
            }
            break;
          case 'size':
            if (rawLegend[entity][legendStyle].length > 0) {
              LK.elements.legendWrapper.appendChild(LK.generateSizeLegend(rawLegend[entity][legendStyle]));
            }
            break;
          case 'width':
            if (rawLegend[entity][legendStyle].length > 0) {
              LK.elements.legendWrapper.appendChild(LK.generateSizeLegend(rawLegend[entity][legendStyle]));
            }
            break;
        }
      });
    });
  },

  /**
   * Generate the color legend
   *
   * @param colors
   * @return {HTMLDivElement}
   */
  generateColorLegend: function(colors) {
    var template = document.createElement('div');
    template.className = 'legend_wrapper';
    var wrapper = document.createElement('ul');
    colors.forEach(function(color) {
      var colorItem = document.createElement('li');
      colorItem.className = 'legend_item';
      var labelEl = document.createElement('label');
      labelEl.appendChild(document.createTextNode(color.label));
      var colorEl = document.createElement('div');
      colorEl.className = 'legend_color';
      colorEl.style.background = color.value;
      colorItem.appendChild(labelEl);
      colorItem.appendChild(colorEl);
      wrapper.appendChild(colorItem);
    });
    template.appendChild(wrapper);
    return template;
  },

  /**
   * Generate the icon legend
   *
   * @param icons
   * @return {HTMLDivElement}
   */
  generateIconLegend: function(icons) {
    var template = document.createElement('div');
    template.className = 'legend_wrapper';
    var wrapper = document.createElement('ul');
    icons.forEach(function(icon) {
      var iconItem = document.createElement('li');
      iconItem.className = 'legend_item';
      var labelEl = document.createElement('label');
      labelEl.appendChild(document.createTextNode(icon.label));
      var iconEl = document.createElement('div');
      iconEl.className = 'legend_icon';
      if ((icon.value.font && icon.value.font === 'FontAwesome') || icon.value.url) {
        iconEl.classList.add('fa');
      }
      if (icon.value.content !== undefined) {
        iconEl.appendChild(document.createTextNode(icon.value.content));
      } else if (icon.value.url !== undefined) {
        var imageSpan = document.createElement('span');
        imageSpan.classList.add('legend_image');
        imageSpan.appendChild(document.createTextNode(''));
        iconEl.appendChild(imageSpan);
      }
      iconItem.appendChild(labelEl);
      iconItem.appendChild(iconEl);
      wrapper.appendChild(iconItem);
    });
    template.appendChild(wrapper);
    return template;
  },

  /**
   * Generate the size legend
   *
   * @param sizes
   * @return {HTMLDivElement}
   */
  generateSizeLegend: function(sizes) {
    var template = document.createElement('div');
    template.className = 'legend_wrapper';
    var wrapper = document.createElement('ul');
    sizes.forEach(function(size) {
      var sizeItem = document.createElement('li');
      sizeItem.className = 'legend_item';
      var labelEl = document.createElement('label');
      labelEl.appendChild(document.createTextNode(size.label));
      var sizeEl = document.createElement('div');
      sizeEl.className = 'legend_size';
      sizeEl.appendChild(document.createTextNode(size.value));
      sizeItem.appendChild(labelEl);
      sizeItem.appendChild(sizeEl);
      wrapper.appendChild(sizeItem);
    });
    template.appendChild(wrapper);
    return template;
  },

  /**
   * Show an element in UI
   *
   * @param el
   */
  show: function(el) {
    if (typeof el === 'string') {
      document.getElementById(el).classList.remove('hidden');
    } else {
      el.classList.remove('hidden');
    }
  },

  /**
   * Hide an element in UI
   *
   * @param el
   */
  hide: function(el) {
    if (typeof el === 'string') {
      document.getElementById(el).classList.add('hidden');
    } else {
      el.classList.add('hidden');
    }
  },

  /**
   * Toggle geo mode
   */
  toggleGeoMode: function() {
    if (LK.ogma.geo.enabled()) {
      LK.ogma.geo.disable();
    } else {
      LK.ogma.geo.enable({
        sizeRatio: 4,
        latitudePath: ['_geo', 'latitude'],
        longitudePath: ['_geo', 'longitude'],
        tileUrlTemplate: LK.content.mapLayers[0].urlTemplate
          .replace('{accessToken}', LK.content.mapLayers[0].accessToken)
          .replace('{id}', LK.content.mapLayers[0].id),
        maxZoomLevel: LK.content.mapLayers[0].maxZoom,
        wrapCoordinates: true,
        detectRetina: false,
        duration: 700,
        disableNodeDragging: true,
      });
    }
  },

  /**
   * Close a tooltip
   */
  closeTooltip: function() {
    LK.ogma.tools.tooltip.hide();
  },

  /**
   * Toggle the legend
   */
  toggleLegend: function() {
    if (LK.elements.legendWrapper.classList.contains('hidden')) {
      LK.show(LK.elements.legendWrapper);
    } else {
      LK.hide(LK.elements.legendWrapper);
    }
  },

  /**
   * Open the share modal
   */
  share: function() {
    LK.show(LK.elements.shareModal);
    if (LK.url !== undefined) {
      LK.elements.code.value =
        '<iframe src="' +
        LK.url +
        '" width="100%" height="330" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe> <p> <a href="' +
        LK.url +
        '" target="_blank">widgetPreview</a>on <a href="https://linkurio.us" target="_blank">Linkurious</a></p>';
      LK.elements.url.value = LK.url;
    }
  },

  /**
   * Close the share modal
   */
  closeShareOverlay: function() {
    LK.hide(LK.elements.shareModal);
  },

  /**
   * Run a layout
   */
  toggleLayout: function() {
    var layoutButton = LK.elements.layout.children[0];
    if (LK.layoutRunning) {
      LK.ogma.layouts.stop();
      layoutButton.classList.remove('fa-pause');
      layoutButton.classList.add('fa-play');
      LK.layoutRunning = false;
    } else {
      layoutButton.classList.remove('fa-play');
      layoutButton.classList.add('fa-pause');
      LK.layoutRunning = true;
      LK.ogma.layouts
        .forceLink({
          autoStop: true,
          maxIterations: 1000,
          avgDistanceThreshold: 0.01,
          nodeMass: function(n) {
            return (n.getDegree() + 1) * (n.getAttribute('layoutable') ? 1 : 5);
          },
          barnesHutOptimize: false,
          scalingRatio: 200,
          gravity: 0.8,
          linLogMode: false,
          alignNodeSiblings: true,
          nodeSiblingsScale: 8,
          nodeSiblingsAngleMin: 0.3,
          useWebWorker: true,
          duration: 700,
        })
        .then(function() {
          layoutButton.classList.remove('fa-pause');
          layoutButton.classList.add('fa-play');
          LK.layoutRunning = false;
        });
    }
  },

  /**
   * Enter fullscreen
   */
  fullscreen: function() {
    LK.ogma.view.setFullScreen(!LK.ogma.view.isFullScreen());
  },

  /**
   * Zoom in the widgetPreview
   */
  zoomIn: function() {
    LK.ogma.view.zoomIn({ duration: 300 });
  },

  /**
   * Zoom out the widgetPreview
   */
  zoomOut: function() {
    LK.ogma.view.zoomOut({ duration: 300 });
  },

  /**
   * Search for a term in items label
   *
   * @param type
   */
  search: function(type) {
    LK.closeTooltip();
    var query = LK.elements.searchInput.value;
    var searchType = type || 'nodes';
    LK.searchType = searchType;
    var rawItems = searchType === 'nodes' ? LK.ogma.getNodes() : LK.ogma.getEdges();
    if (query.length) {
      LK.elements.searchForm.classList.add('active');
      var tabIndex = 100;
      LK.show(LK.elements.resultList);
      LK.show(LK.elements.clearSearch);
      while (LK.elements.resultList.hasChildNodes()) {
        LK.elements.resultList.removeChild(LK.elements.resultList.firstChild);
      }

      for (
        var items = search(query, rawItems)
            .slice(0, 5)
            .map(function(result) {
              var resultEl = document.createElement('p');
              resultEl.dataset.id = result.item.getId();
              resultEl.className = 'autocomplete_dropdown_item';
              resultEl.tabIndex = tabIndex++;
              resultEl.appendChild(document.createTextNode(result.item.getAttribute('text')));
              resultEl.onclick = function() {
                select(result.item);
              };
              resultEl.addEventListener('keydown', function(e) {
                switch (e.keyCode) {
                  case 13:
                    select(result.item);
                    break;
                  case 38:
                    this.previousSibling ? this.previousSibling.focus() : this.parentNode.lastChild.focus();
                    break;
                  case 40:
                    this.nextSibling ? this.nextSibling.focus() : this.parentNode.firstChild.focus();
                    break;
                  case 9:
                    break;
                  default:
                    LK.elements.searchInput.focus();
                }
              });
              return resultEl;
            }),
          i = 0;
        i < items.length;
        i++
      ) {
        LK.elements.resultList.appendChild(items[i]);
      }
      if (!items.length) {
        var noResult = document.createElement('p');
        noResult.className = 'autocomplete_dropdown_item';
        noResult.tabIndex = tabIndex++;
        noResult.appendChild(document.createTextNode('0 ' + searchType + ' found.'));
        LK.elements.resultList.appendChild(noResult);
      }
      switchSearch(LK.elements.resultList, tabIndex);
    } else {
      LK.elements.searchForm.classList.remove('active');
    }
  },

  /**
   * Clear the search
   */
  clearSearch: function() {
    LK.elements.searchInput.focus();
    LK.elements.searchInput.value = '';
    LK.hide(LK.elements.resultList);
    LK.hide(LK.elements.clearSearch);
    LK.elements.searchForm.classList.remove('active');
    while (LK.elements.resultList.hasChildNodes()) {
      LK.elements.resultList.removeChild(LK.elements.resultList.firstChild);
    }
  },

  formatDate: function(isoString, isDatetime) {
    // The date received from the server will be always in seconds
    var dateObject = new Date(isoString);

    if (isNaN(dateObject.getUTCFullYear())) {
      return undefined;
    }
    var formattedDate =
      dateObject.getFullYear() +
      '-' +
      ((dateObject.getUTCMonth() + 1).toString().length === 1
        ? '0' + (dateObject.getUTCMonth() + 1)
        : dateObject.getUTCMonth() + 1) +
      '-' +
      (dateObject.getUTCDate().toString().length === 1
        ? '0' + dateObject.getUTCDate()
        : dateObject.getUTCDate());

    if (isDatetime) {
      formattedDate +=
        ' ' +
        (dateObject.getUTCHours().toString().length === 1
          ? '0' + dateObject.getUTCHours()
          : dateObject.getUTCHours()) +
        ':' +
        (dateObject.getUTCMinutes().toString().length === 1
          ? '0' + dateObject.getUTCMinutes()
          : dateObject.getUTCMinutes()) +
        ':' +
        (dateObject.getUTCSeconds().toString().length === 1
          ? '0' + dateObject.getUTCSeconds()
          : dateObject.getUTCSeconds());
    }
    return formattedDate;
  },

  /**
   * Generate the node tooltip
   *
   * @param node
   * @return {string}
   */
  nodeTooltip: function(node) {
    var urlRegEx = /^(\\\\.+|((https?|ftp|file):)?\/\/[a-z0-9][\.a-z0-9\-]*[a-z0-9](:\d{1,5})?(\/[^\s]*)?)$/i;
    var imgRegEx = /\.(gif|jpe?g|tiff|png|bmp|svg)$/i;
    var template =
      '<div class="sigma-tooltip-node"><div class="arrow"></div><div class="sigma-tooltip-header">' +
      node.getAttribute('text') +
      '<button type="button" class="close" onclick="LK.closeTooltip();"><span aria-hidden="true">&times;</span> <span class="sr-only">Close</span> </button> </div> <div class="sigma-tooltip-body"> <p id="node-categories">';

    node.getData('categories').forEach(function(cat) {
      template += '<span class="label static">' + cat + '</span>';
    });
    template += '</p><ul id="node-properties">';

    Object.keys(node.getData('properties')).forEach(function(prop) {
      var rawValue = node.getData(['properties', prop]);
      var value = getPropertyValue(rawValue);
      var type = testUrl(value, urlRegEx) ? 'url' : testImage(value, imgRegEx) ? 'image' : 'text';
      template +=
        '<li> <span style="text-transform:capitalize;font-weight:bold;color: #999999;">' +
        prop +
        '</span><br /> <span>';

      switch (type) {
        case 'text':
          template += value;
          break;
        case 'url':
          template += '<a href="' + value + '" target="_blank">' + value + '</a>';
          break;
        case 'image':
          template += '<img src="' + value + '"/>';
          break;
      }
      template += '</span></li>';
    });
    template += '</ul></div><div class="sigma-tooltip-footer"></div></div>';
    return template;
  },

  /**
   * Generate the edge tooltip
   *
   * @param edge
   * @return {string}
   */
  edgeTooltip: function(edge) {
    var urlRegEx = /^(\\\\.+|((https?|ftp|file):)?\/\/[a-z0-9][\.a-z0-9\-]*[a-z0-9](:\d{1,5})?(\/[^\s]*)?)$/i;
    var imgRegEx = /\.(gif|jpe?g|tiff|png|bmp|svg)$/i;
    var template =
      '<div class="sigma-tooltip-edge"> <div class="arrow"></div> <div class="sigma-tooltip-header">' +
      edge.getAttribute('text') +
      ' <button type="button" class="close" onclick="LK.closeTooltip();"> <span aria-hidden="true">&times;</span> <span class="sr-only">Close</span> </button> </div> <div class="sigma-tooltip-body"> <p> <span class="label static">' +
      edge.getData('type') +
      ' </span> </p> <ul id="edge-properties">';

    Object.keys(edge.getData('properties')).forEach(function(prop) {
      var rawValue = node.getData(['properties', prop]);
      var value;
      if (typeof rawValue === 'object' && rawValue !== null) {
        if (rawValue.type === 'date') {
          if (rawValue.value) {
            value = LK.formatDate(rawValue.value);
          } else {
            value = LK.formatDate(rawValue.original);
          }
        } else if (rawValue.type === 'datetime') {
          if (rawValue.value) {
            value = LK.formatDate(rawValue.value, true);
          } else {
            value = LK.formatDate(rawValue.original, true);
          }
        } else {
          value = rawValue.original;
        }
      } else {
        value = node.getData(['properties', prop]);
      }
      var type = testUrl(value, urlRegEx) ? 'url' : testImage(value, imgRegEx) ? 'image' : 'text';

      template +=
        '<li><span style="text-transform:capitalize;font-weight:bold;color: #999999;">' +
        prop +
        '</span><br /><span>';

      switch (type) {
        case 'text':
          template += value;
          break;
        case 'url':
          template += '<a href="${value}" target="_blank">' + value + '</a>';
          break;
        case 'image':
          template += '<img src="' + value + '"/>';
          break;
      }
      template += '</span></li>';
    });

    template += '</ul></div><div class="sigma-tooltip-footer"></div></div>';
    return template;
  },
};

LK.init(widgetData);

window.LK = LK;
