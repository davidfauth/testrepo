"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-05-11.
 */
const alertParams_1 = require("../../models/parameters/alertParams");
const apiParams_1 = require("../../models/parameters/apiParams");
const LKE = require("../../services/index");
const api = require("../../services/webServer/api");
const Access = LKE.getAccess();
const Alert = LKE.getAlert();
const Config = LKE.getConfig();
const Errors = LKE.getErrors();
const Utils = LKE.getUtils();
module.exports = (app) => {
    /**
     * @api {post} /api/admin/:sourceKey/alerts/folder Create an alert folder
     * @apiName CreateAlertFolder
     * @apiGroup Alerts
     * @apiPermission authenticated
     * @apiPermission action:admin.alerts
     *
     * @apiDescription Create an alert folder.
     *
     * @apiUse DataSourceParams
     * @apiUse CreateAlertFolderParams
     *
     * @apiSuccess (Success 201) {number} id        ID of the alert folder
     * @apiSuccess (Success 201) {string} createdAt Creation date in ISO-8601 format
     * @apiSuccess (Success 201) {string} updatedAt Last update date in ISO-8601 format
     * @apiSuccess (Success 201) {string} title     Title of the alert folder
     * @apiSuccess (Success 201) {-1}     parent    ID of the parent alert folder
     *
     * @apiSuccessExample {json} Success-Response:
     *   HTTP/1.1 201 OK
     *   {
     *     "id": 1,
     *     "createdAt": "2019-06-14T15:41:26.995Z",
     *     "updatedAt": "2019-06-14T15:41:26.995Z",
     *     "title": "My alert folder",
     *     "parent": -1
     *   }
     */
    app.post('/api/admin/:sourceKey/alerts/folder', api.respond(async (req) => {
        const params = apiParams_1.ApiParams.parseRequest(alertParams_1.CreateAlertFolderParams, req);
        await Access.hasAction(req, 'admin.alerts', params.sourceKey);
        return Alert.createAlertFolder(params);
    }, 201));
    /**
     * @api {patch} /api/admin/:sourceKey/alerts/folder/:id Update an alert folder
     * @apiName UpdateAlertFolder
     * @apiGroup Alerts
     * @apiPermission authenticated
     * @apiPermission action:admin.alerts
     *
     * @apiDescription Update an alert folder.
     *
     * @apiUse DataSourceParams
     * @apiUse UpdateAlertFolderParams
     *
     * @apiSuccessExample {none} Success-Response:
     *   HTTP/1.1 204 No Content
     */
    app.patch('/api/admin/:sourceKey/alerts/folder/:id', api.respond(async (req) => {
        const params = apiParams_1.ApiParams.parseRequest(alertParams_1.UpdateAlertFolderParams, req);
        await Access.hasAction(req, 'admin.alerts', params.sourceKey);
        return Alert.updateAlertFolder(params);
    }, 204));
    /**
     * @api {delete} /api/admin/:sourceKey/alerts/folder/:id Delete an alert folder
     * @apiName DeleteAlertFolder
     * @apiGroup Alerts
     * @apiPermission authenticated
     * @apiPermission action:admin.alerts
     *
     * @apiDescription Delete an alert folder.
     *
     * @apiUse DataSourceParams
     * @apiUse DeleteAlertFolderParams
     *
     * @apiSuccessExample {none} Success-Response:
     *   HTTP/1.1 204 No Content
     */
    app.delete('/api/admin/:sourceKey/alerts/folder/:id', api.respond(async (req) => {
        const params = apiParams_1.ApiParams.parseRequest(alertParams_1.DeleteAlertFolderParams, req);
        await Access.hasAction(req, 'admin.alerts', params.sourceKey);
        return Alert.deleteAlertFolder(params);
    }, 204));
    // TODO TS2019 refactor under here
    app.all('/api/admin/:dataSource/alerts*', api.proxy(async (req) => {
        if (!Config.get('alerts.enabled')) {
            throw Errors.business('feature_disabled', 'Alerts are disabled.');
        }
        await Access.hasAction(req, 'admin.alerts', req.param('dataSource'));
    }));
    /**
     * @apiDefine ReturnCreateAlert
     *
     * @apiSuccess (Success 201) {number}   id                     ID of the alert
     * @apiSuccess (Success 201) {number}   folder                 ID of the alert folder (-1 for root folder)
     * @apiSuccess (Success 201) {string}   title                  Title of the alert
     * @apiSuccess (Success 201) {string}   sourceKey              Key of the data-source
     * @apiSuccess (Success 201) {string}   query                  Graph query that will run periodically
     * @apiSuccess (Success 201) {string}   dialect                Dialect of the graph query
     * @apiSuccess (Success 201) {boolean}  enabled                Whether the query will run periodically or not
     * @apiSuccess (Success 201) {object[]} columns                Columns among the returned values of the query to save in a match as scalar values
     * @apiSuccess (Success 201) {string="number","string"} columns.type        Type of the column
     * @apiSuccess (Success 201) {string}                   columns.columnName  Name of the column in the query
     * @apiSuccess (Success 201) {string}                   columns.columnTitle Name of the column for the UI
     * @apiSuccess (Success 201) {string}   cron                   CRON expression representing the frequency with which the query runs
     * @apiSuccess (Success 201) {number}   matchTTL               Number of days after which the matches of this alert are going to be deleted
     * @apiSuccess (Success 201) {number}   maxMatches             Maximum number of matches after which matches with lower scores are discarded
     * @apiSuccess (Success 201) {number}   userId                 ID of the user that created the alert
     * @apiSuccess (Success 201) {string}   lastRun                Last time the query was executed in ISO-8601 format (`null` it was never executed)
     * @apiSuccess (Success 201) {object}   lastRunProblem         Object representing the problem in the last run (`null` if there wasn't a problem in the last run)
     * @apiSuccess (Success 201) {string}   lastRunProblem.error   Error that identifies the last run problem
     * @apiSuccess (Success 201) {boolean}  lastRunProblem.partial Whether the last run was at least partially executed
     * @apiSuccess (Success 201) {string}   createdAt              Creation date in ISO-8601 format
     * @apiSuccess (Success 201) {string}   updatedAt              Last update date in ISO-8601 format
     * @apiSuccess (Success 201) {string}   nextRun                Date when the alert will be executed next in ISO-8601 format (`null` if it isn't scheduled)
     *
     * @apiSuccessExample {json} Success-Response:
     *   HTTP/1.1 201 OK
     *   {
     *     "id": 8,
     *     "folder": 4,
     *     "title": "alert_title",
     *     "sourceKey": "584f2569",
     *     "query": "MATCH (n1)-[r:DIRECTED]-(n2) RETURN n1, n1.score",
     *     "dialect": "cypher",
     *     "enabled": true,
     *     "columns": [
     *       {"type": "number", "columnName": "n1.score", "columnTitle": "Score"}
     *     ],
     *     "cron": "0 0 * * *",
     *     "matchTTL": 30,
     *     "maxMatches": 20,
     *     "userId": 1,
     *     "lastRun": null,
     *     "lastRunProblem": null,
     *     "updatedAt": "2016-05-16T08:23:35.730Z",
     *     "createdAt": "2016-05-16T08:23:35.730Z",
     *     "nextRun": "2016-08-15T00:00:00.000Z"
     *   }
     */
    /**
     * @api {post} /api/admin/:dataSource/alerts Create an alert
     * @apiName CreateAlert
     * @apiGroup Alerts
     * @apiPermission authenticated
     * @apiPermission action:admin.alerts
     *
     * @apiDescription Create a new alert. If `matchTTL` is set to 0, unconfirmed matches
     * will disappear when they stop matching the alert query.
     *
     * @apiParam {string}   dataSource   Key of the data-source
     * @apiParam {string}   title        Title of the alert
     * @apiParam {string}   query        Graph query that will run periodically
     * @apiParam {string}   dialect      Dialect of the graph query
     * @apiParam {boolean}  enabled      Whether the query will run periodically or not
     * @apiParam {number}   [folder]     ID of the alert folder (-1 for root folder)
     * @apiParam {object[]} [columns]    Columns among the returned values of the query to save in a match as scalar values (**maximum 5**)
     * @apiParam {string="number","string"} columns.type        Type of the column
     * @apiParam {string}                   columns.columnName  Name of the column in the query
     * @apiParam {string}                   columns.columnTitle Name of the column for the UI
     * @apiParam {string}   cron         CRON expression representing the frequency with which the query runs
     * @apiParam {number}   [matchTTL]   Number of days after which the matches of this alert are going to be deleted
     * @apiParam {number}   [maxMatches] Maximum number of matches after which matches with lower scores are discarded
     *
     * @apiUse ReturnCreateAlert
     */
    app.post('/api/admin/:dataSource/alerts', api.respond(req => {
        const maxMatches = Utils.tryParsePosInt(req.param('maxMatches'), 'maxMatches', true);
        const matchTTL = Utils.tryParsePosInt(req.param('matchTTL'), 'matchTTL', true);
        return Alert.createAlert({
            title: req.param('title'),
            sourceKey: req.param('dataSource'),
            query: req.param('query'),
            dialect: req.param('dialect'),
            folder: req.param('folder'),
            enabled: Utils.parseBoolean(req.param('enabled')),
            columns: req.param('columns'),
            cron: req.param('cron'),
            matchTTL: matchTTL,
            maxMatches: maxMatches
        }, Access.getUserCheck(req));
    }, 201));
    /**
     * @api {patch} /api/admin/:dataSource/alerts/:alertId Update an alert
     * @apiName UpdateAlert
     * @apiGroup Alerts
     * @apiPermission authenticated
     * @apiPermission action:admin.alerts
     *
     * @apiDescription Update the alert selected by id.
     * Updating an alert will results in all the previous detected matches deleted.
     *
     * @apiParam {string}   dataSource   Key of the data-source
     * @apiParam {number}   alertId      ID of the alert
     * @apiParam {string}   [title]      New title of the alert
     * @apiParam {string}   [query]      New graph query that will run periodically
     * @apiParam {string}   [dialect]    Dialect of the graph query
     * @apiParam {boolean}  [enabled]    Whether the query will run periodically or not
     * @apiParam {number}   [folder]     ID of the alert folder (-1 for root folder)
     * @apiParam {object[]} [columns]    Columns among the returned values of the query to save in a match as scalar values
     * @apiParam {string="number","string"} columns.type        Type of the column
     * @apiParam {string}                   columns.columnName  Name of the column in the query
     * @apiParam {string}                   columns.columnTitle Name of the column for the UI
     * @apiParam {string}   [cron]       CRON expression representing the frequency with which the query runs
     * @apiParam {number}   [matchTTL]   Number of days after which the matches of this alert are going to be deleted
     * @apiParam {number}   [maxMatches] Maximum number of matches after which matches with lower scores are discarded
     *
     * @apiSuccess {number}   id                     ID of the alert
     * @apiSuccess {number}   folder                 ID of the alert folder (-1 for root folder)
     * @apiSuccess {string}   title                  Title of the alert
     * @apiSuccess {string}   sourceKey              Key of the data-source
     * @apiSuccess {string}   query                  Graph query that will run periodically
     * @apiSuccess {string}   dialect                Dialect of the graph query
     * @apiSuccess {boolean}  enabled                Whether the query will run periodically or not
     * @apiSuccess {object[]} columns                Columns among the returned values of the query to save in a match as scalar values
     * @apiSuccess {string="number","string"} columns.type        Type of the column
     * @apiSuccess {string}                   columns.columnName  Name of the column in the query
     * @apiSuccess {string}                   columns.columnTitle Name of the column for the UI
     * @apiSuccess {string}   cron                   CRON expression representing the frequency with which the query runs
     * @apiSuccess {number}   matchTTL               Number of days after which the matches of this alert are going to be deleted
     * @apiSuccess {number}   maxMatches             Maximum number of matches after which matches with lower scores are discarded
     * @apiSuccess {number}   userId                 ID of the user that created the alert
     * @apiSuccess {string}   lastRun                Last time the query was executed in ISO-8601 format (`null` it was never executed)
     * @apiSuccess {object}   lastRunProblem         Object representing the problem in the last run (`null` if there wasn't a problem in the last run)
     * @apiSuccess {string}   lastRunProblem.error   Error that identifies the last run problem
     * @apiSuccess {boolean}  lastRunProblem.partial Whether the last run was at least partially executed
     * @apiSuccess {string}   createdAt              Creation date in ISO-8601 format
     * @apiSuccess {string}   updatedAt              Last update date in ISO-8601 format
     * @apiSuccess {string}   nextRun                Date when the alert will be executed next in ISO-8601 format (`null` if it isn't scheduled)
     *
     * @apiSuccessExample {json} Success-Response:
     *   HTTP/1.1 200 OK
     *   {
     *     "id": 8,
     *     "folder": 4,
     *     "title": "alert_title",
     *     "sourceKey": "584f2569",
     *     "query": "MATCH (n1)-[r:DIRECTED]-(n2) RETURN n1, n1.score",
     *     "dialect": "cypher",
     *     "enabled": true,
     *     "columns": [
     *       {"type": "number", "columnName": "n1.score", "columnTitle": "Score"}
     *     ],
     *     "cron": "0 0 * * *",
     *     "matchTTL": 30,
     *     "maxMatches": 20,
     *     "userId": 1,
     *     "lastRun": null,
     *     "lastRunProblem": null,
     *     "updatedAt": "2016-05-16T08:23:35.730Z",
     *     "createdAt": "2016-05-16T08:23:35.730Z",
     *     "nextRun": "2016-08-15T00:00:00.000Z"
     *   }
     */
    app.patch('/api/admin/:dataSource/alerts/:alertId', api.respond(req => {
        return Alert.updateAlert(Utils.tryParsePosInt(req.param('alertId'), 'alertId'), req.body, Access.getUserCheck(req));
    }, 200));
    /**
     * @api {delete} /api/admin/:dataSource/alerts/:alertId Delete an alert
     * @apiName DeleteAlert
     * @apiGroup Alerts
     * @apiPermission authenticated
     * @apiPermission action:admin.alerts
     *
     * @apiDescription Delete the alert selected by id and all its matches.
     *
     * @apiParam {string} dataSource Key of the data-source
     * @apiParam {number} alertId    ID of the alert
     *
     * @apiSuccessExample {none} Success-Response:
     *   HTTP/1.1 204 No Content
     */
    app.delete('/api/admin/:dataSource/alerts/:alertId', api.respond(req => {
        return Alert.deleteAlert(Utils.tryParsePosInt(req.param('alertId'), 'alertId'), Access.getUserCheck(req));
    }, 204));
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWxlcnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvcm91dGVzL2FkbWluL2FsZXJ0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRztBQU1ILHFFQUk2QztBQUM3QyxpRUFBNEQ7QUFDNUQsNENBQTZDO0FBQzdDLG9EQUFxRDtBQUdyRCxNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzdCLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBRTdCLGlCQUFTLENBQUMsR0FBd0IsRUFBUSxFQUFFO0lBQzFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0EyQkc7SUFDSCxHQUFHLENBQUMsSUFBSSxDQUNOLHFDQUFxQyxFQUNyQyxHQUFHLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxHQUFvQixFQUFFLEVBQUU7UUFDekMsTUFBTSxNQUFNLEdBQUcscUJBQVMsQ0FBQyxZQUFZLENBQUMscUNBQXVCLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDcEUsTUFBTSxNQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRSxjQUFjLEVBQUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzlELE9BQU8sS0FBSyxDQUFDLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ3pDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FDUixDQUFDO0lBRUY7Ozs7Ozs7Ozs7Ozs7O09BY0c7SUFDSCxHQUFHLENBQUMsS0FBSyxDQUNQLHlDQUF5QyxFQUN6QyxHQUFHLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxHQUFvQixFQUFFLEVBQUU7UUFDekMsTUFBTSxNQUFNLEdBQUcscUJBQVMsQ0FBQyxZQUFZLENBQUMscUNBQXVCLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDcEUsTUFBTSxNQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRSxjQUFjLEVBQUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzlELE9BQU8sS0FBSyxDQUFDLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ3pDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FDUixDQUFDO0lBRUY7Ozs7Ozs7Ozs7Ozs7O09BY0c7SUFDSCxHQUFHLENBQUMsTUFBTSxDQUNSLHlDQUF5QyxFQUN6QyxHQUFHLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxHQUFvQixFQUFFLEVBQUU7UUFDekMsTUFBTSxNQUFNLEdBQUcscUJBQVMsQ0FBQyxZQUFZLENBQUMscUNBQXVCLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDcEUsTUFBTSxNQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRSxjQUFjLEVBQUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzlELE9BQU8sS0FBSyxDQUFDLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ3pDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FDUixDQUFDO0lBRUYsa0NBQWtDO0lBRWxDLEdBQUcsQ0FBQyxHQUFHLENBQ0wsZ0NBQWdDLEVBQ2hDLEdBQUcsQ0FBQyxLQUFLLENBQUMsS0FBSyxFQUFDLEdBQUcsRUFBQyxFQUFFO1FBQ3BCLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLEVBQUU7WUFDakMsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUFDLGtCQUFrQixFQUFFLHNCQUFzQixDQUFDLENBQUM7U0FDbkU7UUFDRCxNQUFNLE1BQU0sQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFLGNBQWMsRUFBRSxHQUFHLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7SUFDdkUsQ0FBQyxDQUFDLENBQ0gsQ0FBQztJQUVGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O09BaURHO0lBRUg7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0F5Qkc7SUFDSCxHQUFHLENBQUMsSUFBSSxDQUNOLCtCQUErQixFQUMvQixHQUFHLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1FBQ2hCLE1BQU0sVUFBVSxHQUFHLEtBQUssQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsRUFBRSxZQUFZLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDckYsTUFBTSxRQUFRLEdBQUcsS0FBSyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxFQUFFLFVBQVUsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUUvRSxPQUFPLEtBQUssQ0FBQyxXQUFXLENBQ3RCO1lBQ0UsS0FBSyxFQUFFLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO1lBQ3pCLFNBQVMsRUFBRSxHQUFHLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQztZQUNsQyxLQUFLLEVBQUUsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7WUFDekIsT0FBTyxFQUFFLEdBQUcsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDO1lBQzdCLE1BQU0sRUFBRSxHQUFHLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQztZQUMzQixPQUFPLEVBQUUsS0FBSyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ2pELE9BQU8sRUFBRSxHQUFHLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQztZQUM3QixJQUFJLEVBQUUsR0FBRyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUM7WUFDdkIsUUFBUSxFQUFFLFFBQVE7WUFDbEIsVUFBVSxFQUFFLFVBQVU7U0FDdkIsRUFDRCxNQUFNLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUN6QixDQUFDO0lBQ0osQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUNSLENBQUM7SUFFRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0F1RUc7SUFDSCxHQUFHLENBQUMsS0FBSyxDQUNQLHdDQUF3QyxFQUN4QyxHQUFHLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1FBQ2hCLE9BQU8sS0FBSyxDQUFDLFdBQVcsQ0FDdEIsS0FBSyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxFQUNyRCxHQUFHLENBQUMsSUFBSSxFQUNSLE1BQU0sQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQ3pCLENBQUM7SUFDSixDQUFDLEVBQUUsR0FBRyxDQUFDLENBQ1IsQ0FBQztJQUVGOzs7Ozs7Ozs7Ozs7OztPQWNHO0lBQ0gsR0FBRyxDQUFDLE1BQU0sQ0FDUix3Q0FBd0MsRUFDeEMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRTtRQUNoQixPQUFPLEtBQUssQ0FBQyxXQUFXLENBQ3RCLEtBQUssQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsRUFBRSxTQUFTLENBQUMsRUFDckQsTUFBTSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FDekIsQ0FBQztJQUNKLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FDUixDQUFDO0FBQ0osQ0FBQyxDQUFDIn0=