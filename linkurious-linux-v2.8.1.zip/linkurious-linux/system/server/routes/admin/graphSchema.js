"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-06-03.
 */
const apiParams_1 = require("../../models/parameters/apiParams");
const graphSchemaParams_1 = require("../../models/parameters/graphSchemaParams");
const LKE = require("../../services/index");
const api = require("../../services/webServer/api");
const Access = LKE.getAccess();
const DataService = LKE.getData();
const GraphSchemaService = LKE.getGraphSchema();
module.exports = (app) => {
    /**
     * @api {post} /api/admin/{sourceKey}/schema/sampling/start Start the schema sampling
     * @apiName StartSchemaSampling
     * @apiGroup Schema
     * @apiPermission authenticated
     * @apiPermission action:admin.schema
     *
     * @apiDescription Start the schema sampling.
     *
     * @apiUse DataSourceParams
     * @apiUse StartSchemaSamplingParams
     *
     * @apiSuccessExample {none} Success-Response:
     *   HTTP/1.1 204 No Content
     */
    app.post('/api/admin/:sourceKey/schema/sampling/start', api.respond(async (req) => {
        const params = apiParams_1.ApiParams.parseRequest(graphSchemaParams_1.StartSchemaSamplingParams, req);
        await Access.hasAction(req, 'admin.schema', params.sourceKey);
        return DataService.startSchemaSampling(params);
    }, 204));
    /**
     * @api {post} /api/admin/{sourceKey}/schema/sampling/stop Stop the schema sampling
     * @apiName StopSchemaSampling
     * @apiGroup Schema
     * @apiPermission authenticated
     * @apiPermission action:admin.schema
     *
     * @apiDescription Stop the schema sampling.
     *
     * @apiUse DataSourceParams
     *
     * @apiSuccessExample {none} Success-Response:
     *   HTTP/1.1 204 No Content
     */
    app.post('/api/admin/:sourceKey/schema/sampling/stop', api.respond(async (req) => {
        const params = apiParams_1.ApiParams.parseRequest(graphSchemaParams_1.StopSchemaSamplingParams, req);
        await Access.hasAction(req, 'admin.schema', params.sourceKey);
        return DataService.stopSchemaSampling(params);
    }, 204));
    /**
     * @api {post} /api/admin/:sourceKey/graph/schema/:entityType/types Create a new graph schema type
     * @apiName CreateGraphSchemaType
     * @apiGroup Schema
     * @apiPermission authenticated
     * @apiPermission action:admin.schema
     *
     * @apiDescription Add a new type to the graph schema.
     *
     * @apiUse DataSourceParams
     * @apiUse CreateOrUpdateTypeParams
     *
     * @apiSuccess {string}                               label      Name of the graph schema type
     * @apiSuccess {string="visible","searchable","none"} visibility Whether the type can be searched, visualized or it is hidden
     *
     * @apiSuccessExample {json} Success-Response:
     *   HTTP/1.1 200 OK
     *   {
     *     "label": "country",
     *     "visibility": "searchable"
     *   }
     */
    app.post('/api/admin/:sourceKey/graph/schema/:entityType/types', api.respond(async (req) => {
        const params = apiParams_1.ApiParams.parseRequest(graphSchemaParams_1.CreateTypeParams, req);
        await Access.hasAction(req, 'admin.schema', params.sourceKey);
        return GraphSchemaService.createType(params);
    }, 200));
    /**
     * @api {patch} /api/admin/:sourceKey/graph/schema/:entityType/types Update a graph schema type
     * @apiName UpdateGraphSchemaType
     * @apiGroup Schema
     * @apiPermission authenticated
     * @apiPermission action:admin.schema
     *
     * @apiDescription Update an existing graph schema type.
     *
     * @apiUse DataSourceParams
     * @apiUse CreateOrUpdateTypeParams
     *
     * @apiSuccessExample {none} Success-Response:
     *   HTTP/1.1 204 No Content
     */
    app.patch('/api/admin/:sourceKey/graph/schema/:entityType/types', api.respond(async (req) => {
        const params = apiParams_1.ApiParams.parseRequest(graphSchemaParams_1.UpdateTypeParams, req);
        await Access.hasAction(req, 'admin.schema', params.sourceKey);
        return GraphSchemaService.updateType(params);
    }, 204));
    /**
     * @api {post} /api/admin/:sourceKey/graph/schema/:entityType/properties Create a new graph schema property
     * @apiName CreateGraphSchemaProperty
     * @apiGroup Schema
     * @apiPermission authenticated
     * @apiPermission action:admin.schema
     *
     * @apiDescription Add a new property for a type on the graph schema.
     *
     * @apiUse DataSourceParams
     * @apiUse CreatePropertyParams
     *
     * @apiSuccess {string}                                                                     propertyKey                     Name of the property
     * @apiSuccess {string="visible","searchable","none"}                                       visibility                      Whether the property can be searched, visualized or it is hidden
     * @apiSuccess {object}                                                                     propertyType
     * @apiSuccess {string="auto","boolean","date","datetime","number","string"}                propertyType.name               Data type of the property
     * @apiSuccess {object}                                                                     [propertyType.options]          Additional `propertyType` information (required when `propertyType.name` is "date" or "datetime")
     * @apiSuccess {string[]}                                                                   [propertyType.options.values]   A list of values to restrict the value of the property (only applicable when `propertyType` is "string")
     * @apiSuccess {string="native","iso","dd/mm/yyyy","mm/dd/yyyy","timestamp","timestamp-ms"} [propertyType.options.format]   Storage format (required and only applicable when `propertyType` is "date" or "datetime")
     * @apiSuccess {string}                                                                     [propertyType.options.timezone] Timezone (format: "[+-]HH:MM | Z") (only applicable when `propertyType` is "datetime")
     * @apiSuccess {boolean}                                                                    required                        Whether the property is required on data edition
     *
     * @apiSuccessExample {json} Success-Response:
     *   HTTP/1.1 200 OK
     *   {
     *     "propertyKey": "nutri-score",
     *     "propertyType": {
     *       "name": "string",
     *       "options": {
     *         "values": ["A", "B", "C", "D", "E"]
     *       }
     *     },
     *     "visibility": "searchable",
     *     "required": true
     *   }
     */
    app.post('/api/admin/:sourceKey/graph/schema/:entityType/properties', api.respond(async (req) => {
        const params = apiParams_1.ApiParams.parseRequest(graphSchemaParams_1.CreatePropertyParams, req);
        await Access.hasAction(req, 'admin.schema', params.sourceKey);
        return GraphSchemaService.createProperty(params);
    }, 200));
    /**
     * @api {patch} /api/admin/:sourceKey/graph/schema/:entityType/properties Update a graph schema property
     * @apiName UpdateGraphSchemaProperty
     * @apiGroup Schema
     * @apiPermission authenticated
     * @apiPermission action:admin.schema
     *
     * @apiDescription Update an existing graph schema property.
     *
     * @apiUse DataSourceParams
     * @apiUse UpdatePropertyParams
     *
     * @apiSuccessExample {none} Success-Response:
     *   HTTP/1.1 204 No Content
     */
    app.patch('/api/admin/:sourceKey/graph/schema/:entityType/properties', api.respond(async (req) => {
        const params = apiParams_1.ApiParams.parseRequest(graphSchemaParams_1.UpdatePropertyParams, req);
        await Access.hasAction(req, 'admin.schema', params.sourceKey);
        return GraphSchemaService.updateProperty(params);
    }, 204));
    /**
     * @api {get} /api/admin/:sourceKey/graph/schema/:entityType/types Get the full graph schema
     * @apiName GetAdminGraphSchema
     * @apiGroup Schema
     * @apiPermission authenticated
     * @apiPermission action:admin.schema
     *
     * @apiDescription List all the types and properties of a data-source.
     *
     * @apiUse DataSourceParams
     * @apiUse GetGraphSchemaParams
     *
     * @apiSuccess {object[]}                                                                   results                                            All existing types in the graph schema
     * @apiSuccess {string}                                                                     results.label                                      Name of the graph schema type
     * @apiSuccess {string="visible","searchable","none"}                                       results.visibility                                 Whether the type can be searched, visualized or it is hidden
     * @apiSuccess {object[]}                                                                   results.properties                                 Properties of `label`
     * @apiSuccess {string}                                                                     results.properties.propertyKey                     Name of the property
     * @apiSuccess {string="visible","searchable","none"}                                       results.properties.visibility                      Whether the property can be searched, visualized or it is hidden
     * @apiSuccess {object}                                                                     results.properties.propertyType
     * @apiSuccess {string="auto","boolean","date","datetime","number","string"}                results.properties.propertyType.name               Data type of the property
     * @apiSuccess {object}                                                                     [results.properties.propertyType.options]          Additional `propertyType` information (required when `propertyType.name` is "date" or "datetime")
     * @apiSuccess {string[]}                                                                   [results.properties.propertyType.options.values]   A list of values to restrict the value of the property (only applicable when `propertyType` is "string")
     * @apiSuccess {string="native","iso","dd/mm/yyyy","mm/dd/yyyy","timestamp","timestamp-ms"} [results.properties.propertyType.options.format]   Storage format (required and only applicable when `propertyType` is "date" or "datetime")
     * @apiSuccess {string}                                                                     [results.properties.propertyType.options.timezone] Timezone (format: "[+-]HH:MM | Z") (only applicable when `propertyType` is "datetime")
     * @apiSuccess {boolean}                                                                    results.properties.required                        Whether the property is required on data edition
     *
     * @apiSuccessExample {json} Success-Response:
     *   HTTP/1.1 200 OK
     *   {
     *     "results": [
     *       {
     *         "label": "country",
     *         "visibility": "searchable",
     *         "properties": [
     *           {
     *             "propertyKey": "GDP",
     *             "propertyType": {"name": "number"},
     *             "visibility": "searchable",
     *             "required": false
     *           },
     *           {
     *             "propertyKey": "capital city",
     *             "propertyType": {"name": "string"},
     *             "visibility": "searchable",
     *             "required": true
     *           }
     *         ]
     *       }
     *     ]
     *   }
     */
    app.get('/api/admin/:sourceKey/graph/schema/:entityType/types', api.respond(async (req) => {
        const params = apiParams_1.ApiParams.parseRequest(graphSchemaParams_1.GetGraphSchemaParams, req);
        await Access.hasAction(req, 'admin.schema', params.sourceKey);
        return await DataService.getGraphSchema(params);
    }, 200));
    /**
     * @api {patch} /api/admin/:sourceKey/graph/schema/settings Update the graph schema settings
     * @apiName UpdateGraphSchemaSettings
     * @apiGroup Schema
     * @apiPermission authenticated
     * @apiPermission action:admin.schema
     *
     * @apiDescription Update the strict schema settings of the data-source.
     *
     * @apiUse DataSourceParams
     * @apiUse UpdateSchemaSettingsParams
     *
     * @apiSuccessExample {none} Success-Response:
     *   HTTP/1.1 204 No Content
     */
    app.patch('/api/admin/:sourceKey/graph/schema/settings', api.respond(async (req) => {
        const params = apiParams_1.ApiParams.parseRequest(graphSchemaParams_1.UpdateSchemaSettingsParams, req);
        await Access.hasAction(req, 'admin.schema', params.sourceKey);
        return DataService.updateGraphSchemaSettings(params);
    }, 204));
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGhTY2hlbWEuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvcm91dGVzL2FkbWluL2dyYXBoU2NoZW1hLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRztBQU1ILGlFQUE0RDtBQUM1RCxpRkFTbUQ7QUFDbkQsNENBQTZDO0FBQzdDLG9EQUFxRDtBQUdyRCxNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxXQUFXLEdBQUcsR0FBRyxDQUFDLE9BQU8sRUFBRSxDQUFDO0FBQ2xDLE1BQU0sa0JBQWtCLEdBQUcsR0FBRyxDQUFDLGNBQWMsRUFBRSxDQUFDO0FBRWhELGlCQUFTLENBQUMsR0FBd0IsRUFBUSxFQUFFO0lBQzFDOzs7Ozs7Ozs7Ozs7OztPQWNHO0lBQ0gsR0FBRyxDQUFDLElBQUksQ0FDTiw2Q0FBNkMsRUFDN0MsR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsR0FBb0IsRUFBRSxFQUFFO1FBQ3pDLE1BQU0sTUFBTSxHQUFHLHFCQUFTLENBQUMsWUFBWSxDQUFDLDZDQUF5QixFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQ3RFLE1BQU0sTUFBTSxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUUsY0FBYyxFQUFFLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUM5RCxPQUFPLFdBQVcsQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNqRCxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQ1IsQ0FBQztJQUVGOzs7Ozs7Ozs7Ozs7O09BYUc7SUFDSCxHQUFHLENBQUMsSUFBSSxDQUNOLDRDQUE0QyxFQUM1QyxHQUFHLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxHQUFvQixFQUFFLEVBQUU7UUFDekMsTUFBTSxNQUFNLEdBQUcscUJBQVMsQ0FBQyxZQUFZLENBQUMsNENBQXdCLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDckUsTUFBTSxNQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRSxjQUFjLEVBQUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzlELE9BQU8sV0FBVyxDQUFDLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ2hELENBQUMsRUFBRSxHQUFHLENBQUMsQ0FDUixDQUFDO0lBRUY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQXFCRztJQUNILEdBQUcsQ0FBQyxJQUFJLENBQ04sc0RBQXNELEVBQ3RELEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLEdBQW9CLEVBQUUsRUFBRTtRQUN6QyxNQUFNLE1BQU0sR0FBRyxxQkFBUyxDQUFDLFlBQVksQ0FBQyxvQ0FBZ0IsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUM3RCxNQUFNLE1BQU0sQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFLGNBQWMsRUFBRSxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDOUQsT0FBTyxrQkFBa0IsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDL0MsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUNSLENBQUM7SUFFRjs7Ozs7Ozs7Ozs7Ozs7T0FjRztJQUNILEdBQUcsQ0FBQyxLQUFLLENBQ1Asc0RBQXNELEVBQ3RELEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLEdBQW9CLEVBQUUsRUFBRTtRQUN6QyxNQUFNLE1BQU0sR0FBRyxxQkFBUyxDQUFDLFlBQVksQ0FBQyxvQ0FBZ0IsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUM3RCxNQUFNLE1BQU0sQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFLGNBQWMsRUFBRSxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDOUQsT0FBTyxrQkFBa0IsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDL0MsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUNSLENBQUM7SUFFRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0FtQ0c7SUFDSCxHQUFHLENBQUMsSUFBSSxDQUNOLDJEQUEyRCxFQUMzRCxHQUFHLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxHQUFvQixFQUFFLEVBQUU7UUFDekMsTUFBTSxNQUFNLEdBQUcscUJBQVMsQ0FBQyxZQUFZLENBQUMsd0NBQW9CLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDakUsTUFBTSxNQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRSxjQUFjLEVBQUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzlELE9BQU8sa0JBQWtCLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ25ELENBQUMsRUFBRSxHQUFHLENBQUMsQ0FDUixDQUFDO0lBRUY7Ozs7Ozs7Ozs7Ozs7O09BY0c7SUFDSCxHQUFHLENBQUMsS0FBSyxDQUNQLDJEQUEyRCxFQUMzRCxHQUFHLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxHQUFvQixFQUFFLEVBQUU7UUFDekMsTUFBTSxNQUFNLEdBQUcscUJBQVMsQ0FBQyxZQUFZLENBQUMsd0NBQW9CLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDakUsTUFBTSxNQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRSxjQUFjLEVBQUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzlELE9BQU8sa0JBQWtCLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ25ELENBQUMsRUFBRSxHQUFHLENBQUMsQ0FDUixDQUFDO0lBRUY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O09Ba0RHO0lBQ0gsR0FBRyxDQUFDLEdBQUcsQ0FDTCxzREFBc0QsRUFDdEQsR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsR0FBb0IsRUFBRSxFQUFFO1FBQ3pDLE1BQU0sTUFBTSxHQUFHLHFCQUFTLENBQUMsWUFBWSxDQUFDLHdDQUFvQixFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQ2pFLE1BQU0sTUFBTSxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUUsY0FBYyxFQUFFLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUM5RCxPQUFPLE1BQU0sV0FBVyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNsRCxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQ1IsQ0FBQztJQUVGOzs7Ozs7Ozs7Ozs7OztPQWNHO0lBQ0gsR0FBRyxDQUFDLEtBQUssQ0FDUCw2Q0FBNkMsRUFDN0MsR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsR0FBb0IsRUFBRSxFQUFFO1FBQ3pDLE1BQU0sTUFBTSxHQUFHLHFCQUFTLENBQUMsWUFBWSxDQUFDLDhDQUEwQixFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQ3ZFLE1BQU0sTUFBTSxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUUsY0FBYyxFQUFFLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUM5RCxPQUFPLFdBQVcsQ0FBQyx5QkFBeUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUN2RCxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQ1IsQ0FBQztBQUNKLENBQUMsQ0FBQyJ9