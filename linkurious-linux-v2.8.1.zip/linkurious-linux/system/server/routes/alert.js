"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-05-11.
 */
// TODO TS2019
const Bluebird = require("bluebird");
const alertParams_1 = require("../models/parameters/alertParams");
const apiParams_1 = require("../models/parameters/apiParams");
const LKE = require("../services/index");
const api = require("../services/webServer/api");
const Access = LKE.getAccess();
const Alert = LKE.getAlert();
const Config = LKE.getConfig();
const Errors = LKE.getErrors();
const Utils = LKE.getUtils();
module.exports = (app) => {
    app.all('/api/:dataSource/alerts*', api.proxy(async (req) => {
        if (!Config.get('alerts.enabled')) {
            throw Errors.business('feature_disabled', 'Alerts are disabled.');
        }
        await Access.isAuthenticated(req);
    }));
    // TODO TS2019 refactor above here
    /**
     * @typedef {object} children
     * @property {number}   id             ID of the alert or of the alert folder
     * @property {string}   type           Type of the item ("alert" or "folder")
     * @property {string}   title          Title of the alert or of the alert folder
     * @property {object[]} [children]     An array of alerts (if type is `"folder"`)
     * @property {number}   children.id    ID of the alert
     * @property {string}   children.type  Type of the item (always "alert")
     * @property {string}   children.title Title of the alert
     */
    /**
     * @api {get} /api/:sourceKey/alerts/tree Get the alert tree
     * @apiName GetAlertTree
     * @apiGroup Alerts
     * @apiPermission authenticated
     * @apiPermission apiright:alert.read
     *
     * @apiDescription Get the alerts and the alert folders in a tree structure.
     *
     * @apiUse DataSourceParams
     * @apiUse GetAlertTreeParams
     *
     * @apiSuccess {number}          id       ID of the root alert folder (always `-1`)
     * @apiSuccess {string="folder"} type     Type of the item
     * @apiSuccess {string}          title    Title of the root alert folder
     * @apiSuccess {type:children[]} children An array of alert folders or alerts
     *
     * @apiSuccessExample {json} Success-Response:
     *   HTTP/1.1 200 OK
     *   {
     *     "id": -1,
     *     "title": "root",
     *     "type": "folder",
     *     "children": [
     *       {
     *         "id": 1,
     *         "title": "my 1st alert folder",
     *         "type": "folder",
     *         "children": []
     *       },
     *       {
     *         "id": 2,
     *         "title": "my 2nd alert folder",
     *         "type": "folder",
     *         "children": [
     *           {
     *             "id": 2,
     *             "title": "another alert",
     *             "type": "alert"
     *           },
     *           {
     *             "id": 3,
     *             "title": "yet another alert",
     *             "type": "alert"
     *           }
     *         ]
     *       },
     *       {
     *         "id": 1,
     *         "title": "my alert",
     *         "type": "alert"
     *       }
     *     ]
     *   }
     */
    app.get('/api/:sourceKey/alerts/tree', api.respond((req) => {
        const params = apiParams_1.ApiParams.parseRequest(alertParams_1.GetAlertTreeParams, req);
        return Alert.getAlertTree(params, Access.getUserCheck(req, 'alert.read'));
    }, 200));
    /**
     * @api {get} /api/:sourceKey/alerts/:alertId Get an alert
     * @apiName GetAlert
     * @apiGroup Alerts
     * @apiPermission authenticated
     * @apiPermission apiright:alert.read
     *
     * @apiDescription Get an alert by id.
     *
     * @apiUse DataSourceParams
     * @apiUse GetAlertParams
     *
     * @apiSuccess {number}   id                     ID of the alert
     * @apiSuccess {number}   folder                 ID of the alert folder (-1 for root folder)
     * @apiSuccess {string}   title                  Title of the alert
     * @apiSuccess {string}   sourceKey              Key of the data-source
     * @apiSuccess {string}   query                  Graph query that will run periodically
     * @apiSuccess {string}   dialect                Dialect of the graph query
     * @apiSuccess {boolean}  enabled                Whether the query will run periodically or not
     * @apiSuccess {object[]} columns                Columns among the returned values of the query to save in a match as scalar values
     * @apiSuccess {string="number","string"} columns.type        Type of the column
     * @apiSuccess {string}                   columns.columnName  Name of the column in the query
     * @apiSuccess {string}                   columns.columnTitle Name of the column for the UI
     * @apiSuccess {string}   cron                   CRON expression representing the frequency with which the query runs
     * @apiSuccess {string}   lastRun                Last time the query was executed in ISO-8601 format (`null` it was never executed)
     * @apiSuccess {object}   lastRunProblem         Object representing the problem in the last run (`null` if there wasn't a problem in the last run)
     * @apiSuccess {string}   lastRunProblem.error   Error that identifies the last run problem
     * @apiSuccess {boolean}  lastRunProblem.partial Whether the last run was at least partially executed
     * @apiSuccess {string}   createdAt              Creation date in ISO-8601 format
     * @apiSuccess {string}   updatedAt              Last update date in ISO-8601 format
     * @apiSuccess {string}   nextRun                Date when the alert will be executed next in ISO-8601 format (`null` if it isn't scheduled)
     *
     * @apiSuccessExample {json} Success-Response:
     *   HTTP/1.1 200 OK
     *   {
     *     "id": 8,
     *     "folder": 4,
     *     "title": "alert_title",
     *     "sourceKey": "584f2569",
     *     "query": "MATCH (n1)-[r:DIRECTED]-(n2) RETURN n1, n1.score",
     *     "dialect": "cypher",
     *     "enabled": true,
     *     "columns": [
     *       {"type": "number", "columnName": "n1.score", "columnTitle": "Score"}
     *     ],
     *     "cron": "0 0 * * *",
     *     "lastRun": null,
     *     "lastRunProblem": null,
     *     "updatedAt": "2016-05-16T08:23:35.730Z",
     *     "createdAt": "2016-05-16T08:23:35.730Z",
     *     "nextRun": "2016-08-15T00:00:00.000Z"
     *   }
     */
    app.get('/api/:sourceKey/alerts/:id', api.respond((req) => {
        const params = apiParams_1.ApiParams.parseRequest(alertParams_1.GetAlertParams, req);
        return Alert.getAlert(params, Access.getUserCheck(req, 'alert.read'));
    }, 200));
    // TODO TS2019 refactor under here
    /**
     * @apiDefine ReturnGetMatch
     *
     * @apiSuccess {number}   id               ID of the match
     * @apiSuccess {string}   sourceKey        Key of the data-source
     * @apiSuccess {number}   alertId          ID of the alert
     * @apiSuccess {string}   hash             Hash of the match
     * @apiSuccess {string="unconfirmed","confirmed","dismissed"} status Status of the match
     * @apiSuccess {object}   user             Last user that changed the status (`null` if it was never changed)
     * @apiSuccess {number}   user.id          ID of the user
     * @apiSuccess {string}   user.username    Username of the user
     * @apiSuccess {string}   user.email       E-mail of the user
     * @apiSuccess {object[]} viewers          Users that viewed the match (ordered by date in decreasing order)
     * @apiSuccess {number}   viewers.id       ID of the user
     * @apiSuccess {string}   viewers.username Username of the user
     * @apiSuccess {string}   viewers.email    E-mail of the user
     * @apiSuccess {string}   viewers.date     Date of the view in ISO-8601 format
     * @apiSuccess {string[]} nodes            IDs of the nodes of the match
     * @apiSuccess {string[]} edges            IDs of the edges of the match
     * @apiSuccess {string}   columns          Scalar value for a given column by index defined in the alert
     * @apiSuccess {string}   expirationDate   Date in ISO-8601 format after which the match is deleted
     * @apiSuccess {string}   createdAt        Creation date in ISO-8601 format
     * @apiSuccess {string}   updatedAt        Last update date in ISO-8601 format
     *
     * @apiSuccessExample {json} Success-Response:
     *   HTTP/1.1 200 OK
     *   {
     *     "id": 1,
     *     "sourceKey": "584f2569",
     *     "alertId": 2,
     *     "hash": "897f54ff366922a4077c78955c77bcdd",
     *     "status": "unconfirmed",
     *     "user": null,
     *     "viewers": [],
     *     "nodes": [5971, 5974],
     *     "edges": [523],
     *     "columns": [
     *       1999
     *     ],
     *     "expirationDate": "2016-05-26T08:23:35.730Z",
     *     "createdAt": "2016-05-16T08:23:35.730Z",
     *     "updatedAt": "2016-05-16T08:23:35.730Z"
     *   }
     */
    /**
     * @apiDefine ReturnGetMatchesArray
     *
     * @apiSuccess {object}   counts                   Match counts
     * @apiSuccess {number}   counts.unconfirmed       Count of unconfirmed matches
     * @apiSuccess {number}   counts.confirmed         Count of confirmed matches
     * @apiSuccess {number}   counts.dismissed         Count of dismissed matches
     * @apiSuccess {object[]} matches                  Matches
     * @apiSuccess {number}   matches.id               ID of the match
     * @apiSuccess {string}   matches.sourceKey        Key of the data-source
     * @apiSuccess {number}   matches.alertId          ID of the alert
     * @apiSuccess {string}   matches.hash             Hash of the match
     * @apiSuccess {string="unconfirmed","confirmed",dismissed"} matches.status Status of the match
     * @apiSuccess {object}   matches.user             Last user that changed the status (`null` if it was never changed)
     * @apiSuccess {number}   matches.user.id          ID of the user
     * @apiSuccess {string}   matches.user.username    Username of the user
     * @apiSuccess {string}   matches.user.email       E-mail of the user
     * @apiSuccess {object[]} matches.viewers          Users that viewed the match (ordered by date in decreasing order)
     * @apiSuccess {number}   matches.viewers.id       ID of the user
     * @apiSuccess {string}   matches.viewers.username Username of the user
     * @apiSuccess {string}   matches.viewers.email    E-mail of the user
     * @apiSuccess {string}   matches.viewers.date     Date of the view in ISO-8601 format
     * @apiSuccess {string[]} matches.nodes            IDs of the nodes of the match
     * @apiSuccess {string[]} matches.edges            IDs of the edges of the match
     * @apiSuccess {string}   matches.columns          Scalar value for a given column by index defined in the alert
     * @apiSuccess {string}   matches.expirationDate   Date in ISO-8601 format after which the match is deleted
     * @apiSuccess {string}   matches.createdAt        Creation date in ISO-8601 format
     * @apiSuccess {string}   matches.updatedAt        Last update date in ISO-8601 format
     *
     * @apiSuccessExample {json} Success-Response:
     *   HTTP/1.1 200 OK
     *   {
     *     "counts": {
     *       "unconfirmed": 1,
     *       "confirmed": 1,
     *       "dismissed": 0
     *     },
     *     "matches": [
     *       {
     *         "id": 1,
     *         "sourceKey": "584f2569",
     *         "alertId": 2,
     *         "hash": "897f54ff366922a4077c78955c77bcdd",
     *         "status": "confirmed",
     *         "user": {
     *           "id": 1,
     *           "username": "alice",
     *           "email": "alice@example.com"
     *         },
     *         "viewers": [
     *           {
     *             "id": 1,
     *             "username": "alice",
     *             "email": "alice@example.com",
     *             "date": "2016-05-16T08:13:35.030Z"
     *           }
     *         ],
     *         "nodes": [5971],
     *         "edges": [],
     *         "columns": [
     *           1999
     *         ],
     *         "expirationDate": "2016-05-26T08:23:35.730Z",
     *         "createdAt": "2016-05-16T08:23:35.730Z",
     *         "updatedAt": "2016-05-16T08:23:35.730Z"
     *       },
     *       {
     *         "id": 2,
     *         "sourceKey": "584f2569",
     *         "alertId": 2,
     *         "hash": "5f221db1e438f2d9b7cdd284364e379b",
     *         "status": "unconfirmed",
     *         "user": null,
     *         "viewers": [],
     *         "nodes": [5976],
     *         "edges": [],
     *         "columns": [
     *           1998
     *         ],
     *         "expirationDate": "2016-05-26T08:23:35.730Z",
     *         "createdAt": "2016-05-16T08:23:35.730Z",
     *         "updatedAt": "2016-05-16T08:23:35.730Z"
     *       }
     *     ]
     *   }
     */
    /**
     * @api {get} /api/:dataSource/alerts/:alertId/matches Get all the matches of an alert
     * @apiName GetMatches
     * @apiGroup Alerts
     * @apiPermission authenticated
     * @apiPermission apiright:alert.read
     *
     * @apiDescription Get all the matches of an alert.
     *
     * @apiParam {string} dataSource                           Key of the data-source
     * @apiParam {number} alertId                              ID the alert
     * @apiParam {string} [offset=0]                           Offset from the first result
     * @apiParam {string} [limit=20]                           Page size (maximum number of returned matches)
     * @apiParam {string="asc","desc"} [sort_direction="desc"] Direction used to sort
     * @apiParam {string="date","0","1","2","3","4"} [sort_by="date"] Sort by date or a given column
     * @apiParam {string="unconfirmed","confirmed","dismissed"} [status] Filter on match status
     *
     * @apiUse ReturnGetMatchesArray
     */
    app.get('/api/:dataSource/alerts/:alertId/matches', api.respond(req => {
        const alertId = Utils.tryParsePosInt(req.param('alertId'), 'alertId');
        const user = Access.getUserCheck(req, 'alert.read');
        return Bluebird.props({
            counts: Alert.getMatchCount(req.param('dataSource'), alertId, user),
            matches: Alert.getMatches(req.param('dataSource'), alertId, {
                sortDirection: req.param('sort_direction'),
                sortBy: req.param('sort_by'),
                offset: Utils.tryParsePosInt(req.param('offset'), 'offset', true),
                limit: Utils.tryParsePosInt(req.param('limit'), 'limit', true),
                status: req.param('status')
            }, user)
        });
    }, 200));
    /**
     * @api {get} /api/:dataSource/alerts/:alertId/matches/:matchId Get a match
     * @apiName GetMatch
     * @apiGroup Alerts
     * @apiPermission authenticated
     * @apiPermission apiright:alert.read
     *
     * @apiDescription Get the match selected by id.
     *
     * @apiParam {string} dataSource Key of the data-source
     * @apiParam {number} alertId    ID of the alert
     * @apiParam {number} matchId    ID of the match
     *
     * @apiUse ReturnGetMatch
     */
    app.get('/api/:dataSource/alerts/:alertId/matches/:matchId', api.respond(req => {
        return Alert.getMatch(Utils.tryParsePosInt(req.param('matchId'), 'matchId'), Access.getUserCheck(req, 'alert.read'), req.param('dataSource'), Utils.tryParsePosInt(req.param('alertId'), 'alertId', true));
    }, 200));
    /**
     * @api {post} /api/:dataSource/alerts/:alertId/matches/:matchId/action Do an action on a match
     * @apiName DoMatchAction
     * @apiGroup Alerts
     * @apiPermission authenticated
     * @apiPermission apiright:alert.doAction
     *
     * @apiDescription Do an action (open, dismiss, confirm, unconfirm) on a match.
     *
     * @apiParam {string} dataSource Key of the data-source
     * @apiParam {number} alertId    ID of the alert
     * @apiParam {number} matchId    ID of the match
     * @apiParam (body) {string="confirm","dismiss","unconfirm","open"} action The action to perform
     *
     * @apiSuccessExample {none} Success-Response:
     *   HTTP/1.1 204 No Content
     */
    app.post('/api/:dataSource/alerts/:alertId/matches/:matchId/action', api.respond(req => {
        return Alert.doMatchAction(req.param('dataSource'), Utils.tryParsePosInt(req.param('alertId'), 'alertId'), Utils.tryParsePosInt(req.param('matchId'), 'matchId'), req.param('action'), Access.getUserCheck(req, 'alert.doAction'));
    }, 204));
    /**
     * @api {get} /api/:dataSource/alerts/:alertId/matches/:matchId/actions Get all the actions of a match
     *
     * @apiName GetMatchActions
     * @apiGroup Alerts
     * @apiPermission authenticated
     * @apiPermission apiright:alert.read
     *
     * @apiDescription Get all the actions of a match ordered by creation date.
     *
     * @apiParam {string} dataSource Key of the data-source
     * @apiParam {number} alertId    ID of the alert
     * @apiParam {number} matchId    ID of the match
     *
     * @apiSuccess {object[]} matchActions               Actions
     * @apiSuccess {number}   matchActions.id            ID of the action
     * @apiSuccess {number}   matchActions.matchId       ID of the match
     * @apiSuccess {object}   matchActions.user          User that did the action
     * @apiSuccess {number}   matchActions.user.id       ID of the user
     * @apiSuccess {string}   matchActions.user.username Username of the user
     * @apiSuccess {string}   matchActions.user.email    E-mail of the user
     * @apiSuccess {string="open","confirm","dismiss","unconfirm"} matchActions.action The action performed
     * @apiSuccess {string}   matchActions.createdAt     Creation date in ISO-8601 format
     * @apiSuccess {string}   matchActions.updatedAt     Last update date in ISO-8601 format
     *
     * @apiSuccessExample {json} Success-Response:
     *   HTTP/1.1 200 OK
     *   [
     *     {
     *       "id": 9,
     *       "matchId": 3,
     *       "user": {
     *         "id": 1,
     *         "username": "alice",
     *         "email": "alice@example.com"
     *       },
     *       "action": "dismiss",
     *       "createdAt": "2016-06-16T08:22:35.730Z",
     *       "updatedAt": "2016-06-16T08:22:35.730Z"
     *     },
     *     {
     *       "id": 8,
     *       "matchId": 4,
     *       "user": {
     *         "id": 2,
     *         "username": "bob",
     *         "email": "bob@example.com"
     *       },
     *       "action": "open",
     *       "createdAt": "2016-05-16T08:23:35.730Z",
     *       "updatedAt": "2016-05-16T08:23:35.730Z"
     *     }
     *   ]
     */
    app.get('/api/:dataSource/alerts/:alertId/matches/:matchId/actions', api.respond(req => {
        return Alert.getMatchActions(req.param('dataSource'), Utils.tryParsePosInt(req.param('alertId'), 'alertId'), Utils.tryParsePosInt(req.param('matchId'), 'matchId'), {
            offset: Utils.tryParsePosInt(req.param('offset'), 'offset', true),
            limit: Utils.tryParsePosInt(req.param('limit'), 'limit', true)
        }, Access.getUserCheck(req, 'alert.read'));
    }, 200));
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWxlcnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zZXJ2ZXIvcm91dGVzL2FsZXJ0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRztBQUVILGNBQWM7QUFFZCxxQ0FBc0M7QUFHdEMsa0VBQW9GO0FBQ3BGLDhEQUF5RDtBQUN6RCx5Q0FBMEM7QUFDMUMsaURBQWtEO0FBR2xELE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFFN0IsaUJBQVMsQ0FBQyxHQUF3QixFQUFRLEVBQUU7SUFDMUMsR0FBRyxDQUFDLEdBQUcsQ0FDTCwwQkFBMEIsRUFDMUIsR0FBRyxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUMsR0FBRyxFQUFDLEVBQUU7UUFDcEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUMsRUFBRTtZQUNqQyxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQUMsa0JBQWtCLEVBQUUsc0JBQXNCLENBQUMsQ0FBQztTQUNuRTtRQUNELE1BQU0sTUFBTSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUNwQyxDQUFDLENBQUMsQ0FDSCxDQUFDO0lBRUYsa0NBQWtDO0lBRWxDOzs7Ozs7Ozs7T0FTRztJQUVIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0FzREc7SUFDSCxHQUFHLENBQUMsR0FBRyxDQUNMLDZCQUE2QixFQUM3QixHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBb0IsRUFBRSxFQUFFO1FBQ25DLE1BQU0sTUFBTSxHQUFHLHFCQUFTLENBQUMsWUFBWSxDQUFDLGdDQUFrQixFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQy9ELE9BQU8sS0FBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsWUFBWSxDQUFDLENBQUMsQ0FBQztJQUM1RSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQ1IsQ0FBQztJQUVGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O09Bb0RHO0lBQ0gsR0FBRyxDQUFDLEdBQUcsQ0FDTCw0QkFBNEIsRUFDNUIsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQW9CLEVBQUUsRUFBRTtRQUNuQyxNQUFNLE1BQU0sR0FBRyxxQkFBUyxDQUFDLFlBQVksQ0FBQyw0QkFBYyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQzNELE9BQU8sS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsWUFBWSxDQUFDLENBQUMsQ0FBQztJQUN4RSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQ1IsQ0FBQztJQUVGLGtDQUFrQztJQUVsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQTJDRztJQUVIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O09BcUZHO0lBRUg7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQWtCRztJQUNILEdBQUcsQ0FBQyxHQUFHLENBQ0wsMENBQTBDLEVBQzFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7UUFDaEIsTUFBTSxPQUFPLEdBQUcsS0FBSyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBQ3RFLE1BQU0sSUFBSSxHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLFlBQVksQ0FBQyxDQUFDO1FBRXBELE9BQU8sUUFBUSxDQUFDLEtBQUssQ0FBQztZQUNwQixNQUFNLEVBQUUsS0FBSyxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUM7WUFDbkUsT0FBTyxFQUFFLEtBQUssQ0FBQyxVQUFVLENBQ3ZCLEdBQUcsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEVBQ3ZCLE9BQU8sRUFDUDtnQkFDRSxhQUFhLEVBQUUsR0FBRyxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQztnQkFDMUMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDO2dCQUM1QixNQUFNLEVBQUUsS0FBSyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLENBQUM7Z0JBQ2pFLEtBQUssRUFBRSxLQUFLLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQztnQkFDOUQsTUFBTSxFQUFFLEdBQUcsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDO2FBQzVCLEVBQ0QsSUFBSSxDQUNMO1NBQ0YsQ0FBQyxDQUFDO0lBQ0wsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUNSLENBQUM7SUFFRjs7Ozs7Ozs7Ozs7Ozs7T0FjRztJQUNILEdBQUcsQ0FBQyxHQUFHLENBQ0wsbURBQW1ELEVBQ25ELEdBQUcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7UUFDaEIsT0FBTyxLQUFLLENBQUMsUUFBUSxDQUNuQixLQUFLLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLEVBQUUsU0FBUyxDQUFDLEVBQ3JELE1BQU0sQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLFlBQVksQ0FBQyxFQUN0QyxHQUFHLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxFQUN2QixLQUFLLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUM1RCxDQUFDO0lBQ0osQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUNSLENBQUM7SUFFRjs7Ozs7Ozs7Ozs7Ozs7OztPQWdCRztJQUNILEdBQUcsQ0FBQyxJQUFJLENBQ04sMERBQTBELEVBQzFELEdBQUcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7UUFDaEIsT0FBTyxLQUFLLENBQUMsYUFBYSxDQUN4QixHQUFHLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxFQUN2QixLQUFLLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLEVBQUUsU0FBUyxDQUFDLEVBQ3JELEtBQUssQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsRUFBRSxTQUFTLENBQUMsRUFDckQsR0FBRyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsRUFDbkIsTUFBTSxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsZ0JBQWdCLENBQUMsQ0FDM0MsQ0FBQztJQUNKLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FDUixDQUFDO0lBRUY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O09BcURHO0lBQ0gsR0FBRyxDQUFDLEdBQUcsQ0FDTCwyREFBMkQsRUFDM0QsR0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRTtRQUNoQixPQUFPLEtBQUssQ0FBQyxlQUFlLENBQzFCLEdBQUcsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEVBQ3ZCLEtBQUssQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsRUFBRSxTQUFTLENBQUMsRUFDckQsS0FBSyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxFQUNyRDtZQUNFLE1BQU0sRUFBRSxLQUFLLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLEVBQUUsUUFBUSxFQUFFLElBQUksQ0FBQztZQUNqRSxLQUFLLEVBQUUsS0FBSyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUM7U0FDL0QsRUFDRCxNQUFNLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxZQUFZLENBQUMsQ0FDdkMsQ0FBQztJQUNKLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FDUixDQUFDO0FBQ0osQ0FBQyxDQUFDIn0=