/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2018-09-20.
 */
'use strict';
const LKE = require('../services/index');
const Access = LKE.getAccess();
const CustomFileService = LKE.getCustomFile();
const api = require('../services/webServer/api');
module.exports = function (app) {
    app.all('/api/customFiles*', api.proxy(req => {
        return Access.isAuthenticated(req);
    }));
    /**
     * @api {get} /api/customFiles Get the list of custom files
     * @apiName CustomFiles
     * @apiGroup Linkurious
     * @apiPermission authenticated
     *
     * @apiDescription List all custom files in the specified root directory.
     *
     * @apiParam {string} [root="."]   Root directory of the files to be listed
     * @apiParam {string} [extensions] Comma separated list of file extensions to filter the results (e.g: `png,gif,jpg,jpeg`)
     *
     * @apiSuccess {object[]} results      The list of custom files
     * @apiSuccess {string}   results.path The URL path of the file
     * @apiSuccess {string}   results.name The path to the file relative to `root` and separated by `>`
     *
     * @apiSuccessExample {json} Success-Response:
     *   HTTP/1.1 200 OK
     *   {
     *     "results": [
     *       {
     *         "path": "/myImages/ball.png",
     *         "name": "ball"
     *       },
     *       {
     *         "path": "/myImages/illustrations/Le_college_fou_fou_fou.jpg",
     *         "name": "illustrations > Le_college_fou_fou_fou"
     *       },
     *       {
     *         "path": "/myImages/illustrations/black-panther.jpg",
     *         "name": "illustrations > black-panther"
     *       },
     *       {
     *         "path": "/myImages/illustrations/house.png",
     *         "name": "illustrations > house"
     *       },
     *       {
     *         "path": "/myImages/illustrations/trump.jpg",
     *         "name": "illustrations > trump"
     *       }
     *      ]
     *    }
     */
    app.get('/api/customFiles', api.respond(req => {
        return CustomFileService.list(req.param('root'), req.param('extensions')).then(customFiles => ({ results: customFiles }));
    }));
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3VzdG9tRmlsZXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zZXJ2ZXIvcm91dGVzL2N1c3RvbUZpbGVzLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBQ2IsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLG1CQUFtQixDQUFDLENBQUM7QUFDekMsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0saUJBQWlCLEdBQUcsR0FBRyxDQUFDLGFBQWEsRUFBRSxDQUFDO0FBQzlDLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQywyQkFBMkIsQ0FBQyxDQUFDO0FBRWpELE1BQU0sQ0FBQyxPQUFPLEdBQUcsVUFBUyxHQUFHO0lBQzNCLEdBQUcsQ0FBQyxHQUFHLENBQUMsbUJBQW1CLEVBQUUsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRTtRQUMzQyxPQUFPLE1BQU0sQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDckMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUVKOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQXlDRztJQUNILEdBQUcsQ0FBQyxHQUFHLENBQUMsa0JBQWtCLEVBQUUsR0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRTtRQUM1QyxPQUFPLGlCQUFpQixDQUFDLElBQUksQ0FDM0IsR0FBRyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsRUFDakIsR0FBRyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FDeEIsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUMsT0FBTyxFQUFFLFdBQVcsRUFBQyxDQUFDLENBQUMsQ0FBQztJQUNsRCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDIn0=