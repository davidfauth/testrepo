/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 */
'use strict';
module.exports = function () {
    /**
     * @api {get} /workspace/new Open a sandbox
     * @apiName OpenSandbox
     * @apiGroup Frontend
     * @apiPermission authenticated
     *
     * @apiDescription Open the visualization sandbox of the current user for a given data-source.
     *
     * @apiParam {string}      [key]                  Key of the data-source (default to the first connected data-source)
     * @apiParam {string="visualizationId","expandNodeId","nodeId","edgeId","queryId","searchNodes","searchEdges","pattern","matchId"} [populate] Describes how the sandbox should be populated
     * @apiParam {string}      [item_id]              ID of the node, edge, query/pattern or visualization to load (required when `populate` is one of  `["visualizationId", "queryId", "nodeId", "edgeId", "expandNodeId"]`)
     * @apiParam {number}      [match_id]             ID of alert match to load (required when `populate` is `"matchId"`)
     * @apiParam {string}      [search_query]         Search query to search for nodes or edges (required when `populate` is one of  `["searchNodes", "searchEdges"]`)
     * @apiParam {number{0-1}} [search_fuzziness=0.1] Search query fuzziness (when `populate` is one of  `["searchNodes", "searchEdges"]`)
     * @apiParam {string}      [pattern_query]        Pattern query to match nodes and/or edges (required when `populate` is `"pattern"`)
     * @apiParam {string}      [pattern_dialect]      Query dialect to use (e.g. "cypher" or "gremlin", required when `populate` is `"pattern"`)
     * @apiParam {string}      [query_parameters]     Template query parameters in JSON format (e.g. `{"param1": "abc", "param2": 123}`, to use when `populate` is `"queryId"` and the query is a template)
     */
    /**
     * @api {get} /workspace/:id Open a visualization
     * @apiName OpenVisualization
     * @apiGroup Frontend
     * @apiPermission authenticated
     *
     * @apiDescription Open a visualization.
     * The current user must have at least read access on the visualization.
     *
     * @apiParam {number} id ID of the visualization
     *
     * @apiSuccessExample {html} Success-Response:
     *   HTTP/1.1 200 OK
     */
    /**
     * @api {get} /guest Open a guest sandbox
     * @apiName OpenGuestSandbox
     * @apiGroup Frontend
     *
     * @apiDescription Open the guest user's workspace for a given data-source.
     *
     * @apiParam {string}      [key]                  Key of the data-source (default to the first connected data-source)
     * @apiParam {string="visualizationId","expandNodeId","nodeId","edgeId","queryId","searchNodes","searchEdges","pattern"} [populate] Describes how the guest workspace should be populated
     * @apiParam {string}      [item_id]              ID of the node, edge, query/pattern or visualization to load (required when `populate` is one of  `["visualizationId", "queryId", "nodeId", "edgeId", "expandNodeId"]`)
     * @apiParam {string}      [search_query]         Search query to search for nodes or edges (required when `populate` is one of  `["searchNodes", "searchEdges"]`)
     * @apiParam {number{0-1}} [search_fuzziness=0.1] Search query fuzziness (when `populate` is one of  `["searchNodes", "searchEdges"]`)
     * @apiParam {string}      [pattern_query]        Pattern query to match nodes and/or edges (required when `populate` is `"pattern"`)
     * @apiParam {string}      [pattern_dialect]      Query dialect to use (e.g. "cypher" or "gremlin", required when `populate` is `"pattern"`)
     * @apiParam {string}      [query_parameters]     Template query parameters in JSON format (e.g. `{"param1": "abc", "param2": 123}`, to use when `populate` is `"queryId"` and the query is a template)
     *
     * @apiSuccessExample {html} Success-Response:
     *   HTTP/1.1 200 OK
     */
    /**
     * @api {get} /guest/:id Open a visualization as a guest
     * @apiName OpenGuestVisualization
     * @apiGroup Frontend
     *
     * @apiDescription Open a visualization shared with the guest user.
     *
     * @apiParam {number} id ID of the visualization
     *
     * @apiSuccessExample {html} Success-Response:
     *   HTTP/1.1 200 OK
     */
    /**
     * @api {get} /widget/:key Open a widget
     * @apiName OpenWidget
     * @apiGroup Frontend
     *
     * @apiDescription Open a widget. A widget can be protected by a password.
     * If the widget is password-protected, use HTTP Basic Authentication to provide
     * the password (the username field is ignored).
     *
     * @apiParam {string} key ID of the widget
     *
     * @apiSuccessExample {html} Success-Response:
     *   HTTP/1.1 200 OK
     */
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZnJvbnRlbmQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zZXJ2ZXIvcm91dGVzL2Zyb250ZW5kLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7R0FHRztBQUNILFlBQVksQ0FBQztBQUViLE1BQU0sQ0FBQyxPQUFPLEdBQUc7SUFDZjs7Ozs7Ozs7Ozs7Ozs7Ozs7T0FpQkc7SUFFSDs7Ozs7Ozs7Ozs7OztPQWFHO0lBRUg7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQWtCRztJQUVIOzs7Ozs7Ozs7OztPQVdHO0lBRUg7Ozs7Ozs7Ozs7Ozs7T0FhRztBQUNMLENBQUMsQ0FBQyJ9