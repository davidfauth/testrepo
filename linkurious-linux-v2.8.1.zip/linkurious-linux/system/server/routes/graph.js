"use strict";
const apiParams_1 = require("../models/parameters/apiParams");
const graphParams_1 = require("../models/parameters/graphParams");
const LKE = require("../services/index");
const api = require("../services/webServer/api");
const DataProxy = LKE.getDataProxy();
const GraphQuery = LKE.getGraphQuery();
const Access = LKE.getAccess();
module.exports = (app) => {
    /**
     * @api {post} /api/:sourceKey/graph/check/query Check a graph query
     * @apiName CheckGraphQuery
     * @apiGroup Graph
     * @apiPermission authenticated
     * @apiPermission action:rawReadQuery
     * @apiPermission apiright:graph.rawRead
     *
     * @apiDescription Check that the given graph query is syntactically correct. Parse the query if it's a template.
     *
     * @apiUse DataSourceParams
     * @apiUse CheckGraphQueryParams
     *
     * @apiUse CheckGraphQueryResponse
     */
    app.post('/api/:sourceKey/graph/check/query', api.respond((req) => {
        const params = apiParams_1.ApiParams.parseRequest(graphParams_1.CheckGraphQueryParams, req);
        return DataProxy.checkGraphQuery(params, Access.getWrappedUser(req));
    }));
    /**
     * @api {post} /api/:sourceKey/graph/run/query Execute a graph query
     * @apiName RunGraphQueryByContent
     * @apiGroup Graph
     * @apiPermission action:raw(Read|Write)Query
     * @apiPermission apiright:graph.raw(Read|Write)
     *
     * @apiDescription Get all the nodes and edges matching the given graph query.
     * A subgraph made of all the nodes and the edges from each subgraph matching the graph query is returned.
     *
     * @apiUse DataSourceParams
     * @apiUse RunGraphQueryByContentParams
     * @apiUse RunGraphQueryParams
     * @apiUse GraphParams
     *
     * @apiUse RunGraphQueryResponse
     */
    app.post('/api/:sourceKey/graph/run/query', api.respond((req) => {
        const params = apiParams_1.ApiParams.parseRequest(graphParams_1.RunGraphQueryByContentParams, req);
        return DataProxy.runGraphQueryByContent(params, Access.getWrappedUser(req));
    }));
    /**
     * @api {post} /api/:sourceKey/graph/run/query/:id Execute a graph query by ID
     * @apiName RunGraphQueryById
     * @apiGroup Graph
     * @apiPermission guest_user
     * @apiPermission action:runQuery
     * @apiPermission apiright:graph.runQuery
     * @apiPermission apiright:savedGraphQuery.read
     *
     * @apiDescription Get all the nodes and edges matching the given saved graph query by ID.
     * A subgraph made of all the nodes and the edges from each subgraph matching the graph query is returned.
     *
     * @apiUse DataSourceParams
     * @apiUse RunGraphQueryByIdParams
     * @apiUse RunGraphQueryParams
     * @apiUse GraphParams
     *
     * @apiUse RunGraphQueryResponse
     */
    app.post('/api/:sourceKey/graph/run/query/:id', api.respond((req) => {
        const params = apiParams_1.ApiParams.parseRequest(graphParams_1.RunGraphQueryByIdParams, req);
        return GraphQuery.runGraphQueryById(params, Access.getWrappedUser(req));
    }));
    /**
     * @api {post} /api/:sourceKey/graph/alertPreview Preview an alert
     * @apiName AlertPreview
     * @apiGroup Graph
     * @apiPermission authenticated
     * @apiPermission action:admin.alerts
     * @apiPermission apiright:admin.alerts
     *
     * @apiDescription Get all the nodes and edges matching the given graph query.
     * An array of subgraphs, one for each subgraph matching the graph query, is returned.
     *
     * @apiUse DataSourceParams
     * @apiUse AlertPreviewParams
     *
     * @apiUse AlertPreviewResponse
     */
    app.post('/api/:sourceKey/graph/alertPreview', api.respond((req) => {
        const params = apiParams_1.ApiParams.parseRequest(graphParams_1.AlertPreviewParams, req);
        return DataProxy.alertPreview(params, Access.getWrappedUser(req));
    }));
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zZXJ2ZXIvcm91dGVzL2dyYXBoLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFRQSw4REFBeUQ7QUFDekQsa0VBSzBDO0FBQzFDLHlDQUEwQztBQUMxQyxpREFBa0Q7QUFHbEQsTUFBTSxTQUFTLEdBQUcsR0FBRyxDQUFDLFlBQVksRUFBRSxDQUFDO0FBQ3JDLE1BQU0sVUFBVSxHQUFHLEdBQUcsQ0FBQyxhQUFhLEVBQUUsQ0FBQztBQUN2QyxNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFFL0IsaUJBQVMsQ0FBQyxHQUF3QixFQUFRLEVBQUU7SUFDMUM7Ozs7Ozs7Ozs7Ozs7O09BY0c7SUFDSCxHQUFHLENBQUMsSUFBSSxDQUNOLG1DQUFtQyxFQUNuQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBb0IsRUFBRSxFQUFFO1FBQ25DLE1BQU0sTUFBTSxHQUFHLHFCQUFTLENBQUMsWUFBWSxDQUFDLG1DQUFxQixFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQ2xFLE9BQU8sU0FBUyxDQUFDLGVBQWUsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQ3ZFLENBQUMsQ0FBQyxDQUNILENBQUM7SUFFRjs7Ozs7Ozs7Ozs7Ozs7OztPQWdCRztJQUNILEdBQUcsQ0FBQyxJQUFJLENBQ04saUNBQWlDLEVBQ2pDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFvQixFQUFFLEVBQUU7UUFDbkMsTUFBTSxNQUFNLEdBQUcscUJBQVMsQ0FBQyxZQUFZLENBQUMsMENBQTRCLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDekUsT0FBTyxTQUFTLENBQUMsc0JBQXNCLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztJQUM5RSxDQUFDLENBQUMsQ0FDSCxDQUFDO0lBRUY7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQWtCRztJQUNILEdBQUcsQ0FBQyxJQUFJLENBQ04scUNBQXFDLEVBQ3JDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFvQixFQUFFLEVBQUU7UUFDbkMsTUFBTSxNQUFNLEdBQUcscUJBQVMsQ0FBQyxZQUFZLENBQUMscUNBQXVCLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDcEUsT0FBTyxVQUFVLENBQUMsaUJBQWlCLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztJQUMxRSxDQUFDLENBQUMsQ0FDSCxDQUFDO0lBRUY7Ozs7Ozs7Ozs7Ozs7OztPQWVHO0lBQ0gsR0FBRyxDQUFDLElBQUksQ0FDTixvQ0FBb0MsRUFDcEMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQW9CLEVBQUUsRUFBRTtRQUNuQyxNQUFNLE1BQU0sR0FBRyxxQkFBUyxDQUFDLFlBQVksQ0FBQyxnQ0FBa0IsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUMvRCxPQUFPLFNBQVMsQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztJQUNwRSxDQUFDLENBQUMsQ0FDSCxDQUFDO0FBQ0osQ0FBQyxDQUFDIn0=