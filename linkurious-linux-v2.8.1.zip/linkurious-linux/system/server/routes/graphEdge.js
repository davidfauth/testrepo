"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 */
const apiParams_1 = require("../models/parameters/apiParams");
const graphEdgeParams_1 = require("../models/parameters/graphEdgeParams");
const LKE = require("../services/index");
const api = require("../services/webServer/api");
const DataProxy = LKE.getDataProxy();
const Utils = LKE.getUtils();
const Access = LKE.getAccess();
module.exports = (app) => {
    /**
     * @api {post} /api/:sourceKey/graph/edges Create an edge
     * @apiName CreateEdge
     * @apiGroup Edges
     * @apiPermission authenticated
     * @apiPermission apiright:graphItem.create
     *
     * @apiDescription Add an edge to the graph.
     *
     * @apiUse DataSourceParams
     * @apiUse CreateEdgeParams
     *
     * @apiSuccess(Success 201) {string} id     ID of the edge
     * @apiSuccess(Success 201) {string} source ID of the source node
     * @apiSuccess(Success 201) {string} target ID of the target node
     * @apiSuccess(Success 201) {string} type   Type of the edge
     * @apiSuccess(Success 201) {object} data   Properties of the edge
     * @apiSuccess(Success 201) {number} readAt Read timestamp in epoch time
     *
     * @apiSuccessExample {json} Success-Response:
     *   HTTP/1.1 201 Created
     *   {
     *     "id": "1",
     *     "source": "1",
     *     "target": "2",
     *     "type": "my_link",
     *     "data": {
     *       "direction": "north"
     *     },
     *     "readAt": 692362800000
     *   }
     */
    app.post('/api/:sourceKey/graph/edges', api.respond(async (req) => {
        const wrappedUser = Access.getUserCheck(req, 'graphItem.create');
        return DataProxy.createEdge(apiParams_1.ApiParams.parseRequest(graphEdgeParams_1.CreateEdgeParams, req), wrappedUser);
    }, 201));
    /**
     * @api {patch} /api/:sourceKey/graph/edges/:id Update an edge
     * @apiName UpdateEdge
     * @apiGroup Edges
     * @apiPermission authenticated
     * @apiPermission apiright:graphItem.edit
     *
     * @apiUse DataSourceParams
     * @apiUse UpdateEdgeParams
     *
     * @apiDescription Update a subset of properties of an edge. Keep every other property of the edge unchanged.
     * It's not possible to update the type of an edge.
     *
     * @apiSuccess {string} id     ID of the edge
     * @apiSuccess {string} source ID of the source node
     * @apiSuccess {string} target ID of the target node
     * @apiSuccess {string} type   Type of the edge
     * @apiSuccess {object} data   Properties of the edge
     * @apiSuccess {number} readAt Read timestamp in epoch time
     *
     * @apiSuccessExample {json} Success-Response:
     *   HTTP/1.1 200 OK
     *   {
     *     "id": "1",
     *     "source": "1",
     *     "target": "2",
     *     "type": "my_link",
     *     "data": {
     *       "direction": "north"
     *     },
     *     "readAt": 692362800000
     *   }
     */
    app.patch('/api/:sourceKey/graph/edges/:id', api.respond(async (req) => {
        const wrappedUser = Access.getUserCheck(req, 'graphItem.edit');
        return DataProxy.updateEdge(apiParams_1.ApiParams.parseRequest(graphEdgeParams_1.UpdateEdgeParams, req), wrappedUser);
    }, 200));
    // TODO TS2019 refactor under here
    /**
     * @api {get} /api/:dataSource/graph/edges/count Get edges count
     * @apiName GetEdgesCount
     * @apiGroup Edges
     * @apiPermission guest_user
     * @apiPermission apiright:graphItem.read
     *
     * @apiDescription Get the number of edges in the graph.
     *
     * @apiParam {string} dataSource Key of the data-source
     *
     * @apiSuccess {number} count The number of edges
     *
     * @apiSuccessExample {json} Success-Response:
     *   HTTP/1.1 200 OK
     *   {
     *     "count": 42
     *   }
     */
    app.get('/api/:dataSource/graph/edges/count', api.respond((req) => {
        return DataProxy.getEdgeCount(req.param('dataSource'), Access.getUserCheck(req, 'graphItem.read', true)).then(count => ({ count: count }));
    }));
    /**
     * @api {get|post} /api/:dataSource/graph/edges/:id Get an edge
     * @apiName GetEdge
     * @apiGroup Edges
     * @apiPermission guest_user
     * @apiPermission apiright:graphItem.read
     *
     * @apiDescription Get an edge of the graph.
     * A subgraph made of the edge and its extremities is returned.
     *
     * @apiParam {string}   dataSource         Key of the data-source
     * @apiParam {string}   id                 ID of the edge
     * @apiParam {string[]} [edgesTo]          IDs of nodes that are already visible (they won't be included in the result, but their adjacent edges will be included in the `edges` field if the other nodes are in `nodes`)
     * @apiParam {boolean}  [withDigest=false] Whether to include the adjacency digest in the returned nodes
     * @apiParam {boolean}  [withDegree=false] Whether to include the degree in the returned nodes
     *
     * @apiUse ReturnSubGraph
     */
    const getEdgeHandler = api.respond((req) => {
        return DataProxy.getEdge({
            sourceKey: req.param('dataSource'),
            id: req.param('id'),
            edgesTo: Utils.parseStringArray(req.param('edgesTo')),
            withDigest: Utils.parseBoolean(req.param('withDigest')),
            withDegree: Utils.parseBoolean(req.param('withDegree'))
        }, Access.getUserCheck(req, 'graphItem.read', true));
    });
    app.get('/api/:dataSource/graph/edges/:id', getEdgeHandler);
    app.post('/api/:dataSource/graph/edges/:id', getEdgeHandler);
    /**
     * @api {delete} /api/:dataSource/graph/edges/:id Delete an edge
     * @apiName DeleteEdge
     * @apiGroup Edges
     * @apiPermission authenticated
     * @apiPermission apiright:graphItem.delete
     *
     * @apiDescription Delete an edge from the graph.
     *
     * @apiParam {string} dataSource Key of the data-source
     * @apiParam {string} id         ID of the edge to delete
     *
     * @apiSuccessExample {none} Success-Response:
     *   HTTP/1.1 204 No Content
     */
    app.delete('/api/:dataSource/graph/edges/:id', api.respond((req) => {
        return DataProxy.deleteEdge(req.param('id'), req.param('dataSource'), Access.getUserCheck(req, 'graphItem.delete'));
    }, 204));
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGhFZGdlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc2VydmVyL3JvdXRlcy9ncmFwaEVkZ2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7R0FHRztBQU1ILDhEQUF5RDtBQUN6RCwwRUFBd0Y7QUFDeEYseUNBQTBDO0FBQzFDLGlEQUFrRDtBQUdsRCxNQUFNLFNBQVMsR0FBRyxHQUFHLENBQUMsWUFBWSxFQUFFLENBQUM7QUFDckMsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzdCLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUUvQixpQkFBUyxDQUFDLEdBQXdCLEVBQVEsRUFBRTtJQUMxQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQStCRztJQUNILEdBQUcsQ0FBQyxJQUFJLENBQ04sNkJBQTZCLEVBQzdCLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLEdBQW9CLEVBQUUsRUFBRTtRQUN6QyxNQUFNLFdBQVcsR0FBRyxNQUFNLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxrQkFBa0IsQ0FBQyxDQUFDO1FBQ2pFLE9BQU8sU0FBUyxDQUFDLFVBQVUsQ0FBQyxxQkFBUyxDQUFDLFlBQVksQ0FBQyxrQ0FBZ0IsRUFBRSxHQUFHLENBQUMsRUFBRSxXQUFXLENBQUMsQ0FBQztJQUMxRixDQUFDLEVBQUUsR0FBRyxDQUFDLENBQ1IsQ0FBQztJQUVGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQWdDRztJQUNILEdBQUcsQ0FBQyxLQUFLLENBQ1AsaUNBQWlDLEVBQ2pDLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLEdBQW9CLEVBQUUsRUFBRTtRQUN6QyxNQUFNLFdBQVcsR0FBRyxNQUFNLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO1FBQy9ELE9BQU8sU0FBUyxDQUFDLFVBQVUsQ0FBQyxxQkFBUyxDQUFDLFlBQVksQ0FBQyxrQ0FBZ0IsRUFBRSxHQUFHLENBQUMsRUFBRSxXQUFXLENBQUMsQ0FBQztJQUMxRixDQUFDLEVBQUUsR0FBRyxDQUFDLENBQ1IsQ0FBQztJQUVGLGtDQUFrQztJQUVsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7O09Ba0JHO0lBQ0gsR0FBRyxDQUFDLEdBQUcsQ0FDTCxvQ0FBb0MsRUFDcEMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQW9CLEVBQUUsRUFBRTtRQUNuQyxPQUFPLFNBQVMsQ0FBQyxZQUFZLENBQzNCLEdBQUcsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEVBQ3ZCLE1BQU0sQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLGdCQUFnQixFQUFFLElBQUksQ0FBQyxDQUNqRCxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBQyxLQUFLLEVBQUUsS0FBSyxFQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3BDLENBQUMsQ0FBQyxDQUNILENBQUM7SUFFRjs7Ozs7Ozs7Ozs7Ozs7Ozs7T0FpQkc7SUFDSCxNQUFNLGNBQWMsR0FBRyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBb0IsRUFBRSxFQUFFO1FBQzFELE9BQU8sU0FBUyxDQUFDLE9BQU8sQ0FDdEI7WUFDRSxTQUFTLEVBQUUsR0FBRyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUM7WUFDbEMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDO1lBQ25CLE9BQU8sRUFBRSxLQUFLLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUNyRCxVQUFVLEVBQUUsS0FBSyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQ3ZELFVBQVUsRUFBRSxLQUFLLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUM7U0FDeEQsRUFDRCxNQUFNLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxnQkFBZ0IsRUFBRSxJQUFJLENBQUMsQ0FDakQsQ0FBQztJQUNKLENBQUMsQ0FBQyxDQUFDO0lBQ0gsR0FBRyxDQUFDLEdBQUcsQ0FBQyxrQ0FBa0MsRUFBRSxjQUFjLENBQUMsQ0FBQztJQUM1RCxHQUFHLENBQUMsSUFBSSxDQUFDLGtDQUFrQyxFQUFFLGNBQWMsQ0FBQyxDQUFDO0lBRTdEOzs7Ozs7Ozs7Ozs7OztPQWNHO0lBQ0gsR0FBRyxDQUFDLE1BQU0sQ0FDUixrQ0FBa0MsRUFDbEMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQW9CLEVBQUUsRUFBRTtRQUNuQyxPQUFPLFNBQVMsQ0FBQyxVQUFVLENBQ3pCLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQ2YsR0FBRyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsRUFDdkIsTUFBTSxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsa0JBQWtCLENBQUMsQ0FDN0MsQ0FBQztJQUNKLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FDUixDQUFDO0FBQ0osQ0FBQyxDQUFDIn0=