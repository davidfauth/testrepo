"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 */
const apiParams_1 = require("../models/parameters/apiParams");
const graphNodeParams_1 = require("../models/parameters/graphNodeParams");
const LKE = require("../services/index");
const api = require("../services/webServer/api");
const Utils = LKE.getUtils();
const Access = LKE.getAccess();
const DataProxy = LKE.getDataProxy();
module.exports = (app) => {
    /**
     * @api {post} /api/:sourceKey/graph/nodes Create a node
     * @apiName CreateNode
     * @apiGroup Nodes
     * @apiPermission authenticated
     * @apiPermission apiright:graphItem.create
     *
     * @apiDescription Add a node to the graph.
     *
     * @apiUse DataSourceParams
     * @apiUse CreateNodeParams
     *
     * @apiSuccess(Success 201) {string}   id         ID of the node
     * @apiSuccess(Success 201) {object}   data       Properties of the node
     * @apiSuccess(Success 201) {string[]} categories Categories of the node
     * @apiSuccess(Success 201) {number}   readAt     Read timestamp in epoch time
     *
     * @apiSuccessExample {json} Success-Response:
     *   HTTP/1.1 201 Created
     *   {
     *     "id": "123",
     *     "data": {
     *       "name": "Keanu Reeves",
     *       "born": {
     *         "type": "date",
     *         "value": "1964-09-02T00:00:00.000Z"
     *       }
     *     },
     *     "categories": [
     *       "Person"
     *     ],
     *     "readAt": 692362800000
     *   }
     */
    app.post('/api/:sourceKey/graph/nodes', api.respond(async (req) => {
        const wrappedUser = Access.getUserCheck(req, 'graphItem.create');
        return DataProxy.createNode(apiParams_1.ApiParams.parseRequest(graphNodeParams_1.CreateNodeParams, req), wrappedUser);
    }, 201));
    /**
     * @api {patch} /api/:sourceKey/graph/nodes/:id Update a node
     * @apiName UpdateNode
     * @apiGroup Nodes
     * @apiPermission authenticated
     * @apiPermission apiright:graphItem.edit
     *
     * @apiUse DataSourceParams
     * @apiUse UpdateNodeParams
     *
     * @apiDescription Update a subset of properties and categories of a node. Keep every other property and category of the node unchanged.
     *
     * @apiSuccess {string}   id         ID of the node
     * @apiSuccess {object}   data       Properties of the node
     * @apiSuccess {string[]} categories Categories of the node
     * @apiSuccess {number}   readAt     Read timestamp in epoch time
     *
     * @apiSuccessExample {json} Success-Response:
     *   HTTP/1.1 200 OK
     *   {
     *     "id": "123",
     *     "data": {
     *       "name": "Keanu Reeves",
     *       "born": {
     *         "type": "date",
     *         "value": "1964-09-02T00:00:00.000Z"
     *       }
     *     },
     *     "categories": [
     *       "Person"
     *     ],
     *     "readAt": 692362800000
     *   }
     */
    app.patch('/api/:sourceKey/graph/nodes/:id', api.respond(async (req) => {
        const wrappedUser = Access.getUserCheck(req, 'graphItem.edit');
        return DataProxy.updateNode(apiParams_1.ApiParams.parseRequest(graphNodeParams_1.UpdateNodeParams, req), wrappedUser);
    }, 200));
    // TODO TS2019 refactor under here
    /**
     * @api {get} /api/:dataSource/graph/nodes/count Get nodes count
     * @apiName GetNodesCount
     * @apiGroup Nodes
     * @apiPermission guest_user
     * @apiPermission apiright:graphItem.read
     *
     * @apiDescription Get the number of nodes in the graph.
     *
     * @apiParam {string} dataSource Key of the data-source
     *
     * @apiSuccess {number} count The number of nodes
     *
     * @apiSuccessExample {json} Success-Response:
     *   HTTP/1.1 200 OK
     *   {
     *     "count": 42
     *   }
     */
    app.get('/api/:dataSource/graph/nodes/count', api.respond((req) => {
        return DataProxy.getNodeCount(req.param('dataSource'), Access.getUserCheck(req, 'graphItem.read', true)).then(count => ({ count: count }));
    }));
    /**
     * @api {get|post} /api/:dataSource/graph/nodes/expand Get adjacent nodes and edges
     *
     * @apiName GetAdjacentGraph
     * @apiGroup Nodes
     * @apiPermission guest_user
     * @apiPermission apiright:graphItem.read
     *
     * @apiDescription Get all the adjacent nodes and edges to one or more source nodes (`ids`).
     * A subgraph made of the items that matched the expand query and the edges between them is returned.
     *
     * @apiParam {string}   dataSource         Key of the data-source
     * @apiParam {string[]} ids                IDs of the nodes to retrieve the neighbors for
     * @apiParam {number}   [limit]            Maximum number of returned nodes
     * @apiParam {string="id","highestDegree","lowestDegree"} [limitType="id"] Order direction used to limit the result
     * @apiParam {string}   [nodeCategories]   Exclusive list of node categories to restrict the result
     * @apiParam {string}   [edgeTypes]        Exclusive list of edge types to restrict the result
     * @apiParam {string[]} [edgesTo]          IDs of nodes that are already visible (they won't be included in the result, but their adjacent edges will be included in the `edges` field if the other nodes are in `nodes`)
     * @apiParam {boolean}  [withDigest=false] Whether to include the adjacency digest in the returned nodes
     * @apiParam {boolean}  [withDegree=false] Whether to include the degree in the returned nodes
     *
     * @apiUse ReturnSubGraph
     */
    const expandHandler = api.respond((req) => {
        return DataProxy.getAdjacentNodes(Utils.tryParseStringArray(req.param('ids'), 'ids'), {
            limit: Utils.parseInt(req.param('limit')),
            limitType: Utils.parseString(req.param('limitType')),
            nodeCategories: Utils.parseStringArray(req.param('nodeCategories')),
            edgeTypes: Utils.parseStringArray(req.param('edgeTypes')),
            edgesTo: Utils.parseStringArray(req.param('edgesTo')),
            withDigest: Utils.parseBoolean(req.param('withDigest')),
            withDegree: Utils.parseBoolean(req.param('withDegree'))
        }, req.param('dataSource'), Access.getUserCheck(req, 'graphItem.read', true));
    });
    app.get('/api/:dataSource/graph/nodes/expand', expandHandler);
    app.post('/api/:dataSource/graph/nodes/expand', expandHandler);
    /**
     * @api {get|post} /api/:dataSource/graph/nodes/:id Get a node
     * @apiName GetNode
     * @apiGroup Nodes
     * @apiPermission guest_user
     * @apiPermission apiright:graphItem.read
     *
     * @apiDescription Get a node of the graph.
     * A subgraph made of the single node is returned.
     *
     * @apiParam {string}   dataSource         Key of the data-source
     * @apiParam {string}   id                 ID of the node
     * @apiParam {string[]} [edgesTo]          IDs of nodes that are already visible (they won't be included in the result, but their adjacent edges will be included in the `edges` field if the other nodes are in `nodes`)
     * @apiParam {boolean}  [withDigest=false] Whether to include the adjacency digest in the returned nodes
     * @apiParam {boolean}  [withDegree=false] Whether to include the degree in the returned nodes
     *
     * @apiUse ReturnSubGraph
     */
    const getNodeHandler = api.respond((req) => {
        return DataProxy.getNode({
            sourceKey: req.param('dataSource'),
            id: req.param('id'),
            edgesTo: Utils.parseStringArray(req.param('edgesTo')),
            withDigest: Utils.parseBoolean(req.param('withDigest')),
            withDegree: Utils.parseBoolean(req.param('withDegree'))
        }, Access.getUserCheck(req, 'graphItem.read', true));
    });
    app.get('/api/:dataSource/graph/nodes/:id', getNodeHandler);
    app.post('/api/:dataSource/graph/nodes/:id', getNodeHandler);
    /**
     * @api {post} /api/:dataSource/graph/neighborhood/statistics Get statistics of adjacent nodes
     * @apiName GetNeighborsStatistics
     * @apiGroup Nodes
     * @apiPermission guest_user
     * @apiPermission apiright:graphItem.read
     *
     * @apiDescription Get the digest (the number of adjacent nodes and edges grouped by node categories and edge types)
     * and/or the degree of a given subset of nodes (`ids`).
     * You can't get aggregated statistics of a subset of nodes containing one or more supernodes.
     * To get the statistics of a supernode invoke the API with only its node ID.
     *
     * @apiParam {string}   dataSource         Key of the data-source
     * @apiParam {string[]} ids                IDs of the nodes
     * @apiParam {boolean}  [withDigest=false] Whether to include the adjacency digest in the returned nodes
     * @apiParam {boolean}  [withDegree=false] Whether to include the degree in the returned nodes
     *
     * @apiSuccess {type:LkDigestItem[]} [digest] Statistics of the neighborhood of the nodes
     * @apiSuccess {number}              [degree] Number of neighbors of the nodes readable by the current user
     *
     * @apiSuccessExample {json} Success-Response:
     *   HTTP/1.1 200 OK
     *   {
     *     "digest": [
     *       {
     *         "edgeType": "ACTED_IN",
     *         "nodeCategories": [
     *           "TheMatrix",
     *           "Movie"
     *         ],
     *         "nodes": 1,
     *         "edges": 1
     *       }
     *     ],
     *     "degree": 1
     *   }
     */
    app.post('/api/:dataSource/graph/neighborhood/statistics', api.respond((req) => {
        return DataProxy.getStatistics(Utils.tryParseStringArray(req.param('ids'), 'ids'), req.param('dataSource'), {
            withDigest: Utils.parseBoolean(req.param('withDigest')),
            withDegree: Utils.parseBoolean(req.param('withDegree'))
        }, Access.getUserCheck(req, 'graphItem.read', true));
    }));
    /**
     * @api {delete} /api/:dataSource/graph/nodes/:id Delete a node
     * @apiName DeleteNode
     * @apiGroup Nodes
     * @apiPermission authenticated
     * @apiPermission apiright:graphItem.delete
     *
     * @apiDescription Delete a node and its adjacent edges from the graph.
     *
     * @apiParam {string} dataSource Key of the data-source
     * @apiParam {string} id         ID of the node to delete
     *
     * @apiSuccessExample {none} Success-Response:
     *   HTTP/1.1 204 No Content
     */
    app.delete('/api/:dataSource/graph/nodes/:id', api.respond((req) => {
        return DataProxy.deleteNode(req.param('id'), req.param('dataSource'), Access.getUserCheck(req, 'graphItem.delete'));
    }, 204));
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGhOb2RlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc2VydmVyL3JvdXRlcy9ncmFwaE5vZGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7R0FHRztBQU1ILDhEQUF5RDtBQUN6RCwwRUFBd0Y7QUFDeEYseUNBQTBDO0FBQzFDLGlEQUFrRDtBQUdsRCxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sU0FBUyxHQUFHLEdBQUcsQ0FBQyxZQUFZLEVBQUUsQ0FBQztBQTRHckMsaUJBQVMsQ0FBQyxHQUF3QixFQUFRLEVBQUU7SUFDMUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQWlDRztJQUNILEdBQUcsQ0FBQyxJQUFJLENBQ04sNkJBQTZCLEVBQzdCLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLEdBQW9CLEVBQUUsRUFBRTtRQUN6QyxNQUFNLFdBQVcsR0FBRyxNQUFNLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxrQkFBa0IsQ0FBQyxDQUFDO1FBQ2pFLE9BQU8sU0FBUyxDQUFDLFVBQVUsQ0FBQyxxQkFBUyxDQUFDLFlBQVksQ0FBQyxrQ0FBZ0IsRUFBRSxHQUFHLENBQUMsRUFBRSxXQUFXLENBQUMsQ0FBQztJQUMxRixDQUFDLEVBQUUsR0FBRyxDQUFDLENBQ1IsQ0FBQztJQUVGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0FpQ0c7SUFDSCxHQUFHLENBQUMsS0FBSyxDQUNQLGlDQUFpQyxFQUNqQyxHQUFHLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxHQUFvQixFQUFFLEVBQUU7UUFDekMsTUFBTSxXQUFXLEdBQUcsTUFBTSxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztRQUMvRCxPQUFPLFNBQVMsQ0FBQyxVQUFVLENBQUMscUJBQVMsQ0FBQyxZQUFZLENBQUMsa0NBQWdCLEVBQUUsR0FBRyxDQUFDLEVBQUUsV0FBVyxDQUFDLENBQUM7SUFDMUYsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUNSLENBQUM7SUFFRixrQ0FBa0M7SUFFbEM7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQWtCRztJQUNILEdBQUcsQ0FBQyxHQUFHLENBQ0wsb0NBQW9DLEVBQ3BDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFvQixFQUFFLEVBQUU7UUFDbkMsT0FBTyxTQUFTLENBQUMsWUFBWSxDQUMzQixHQUFHLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxFQUN2QixNQUFNLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxnQkFBZ0IsRUFBRSxJQUFJLENBQUMsQ0FDakQsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUMsS0FBSyxFQUFFLEtBQUssRUFBQyxDQUFDLENBQUMsQ0FBQztJQUNwQyxDQUFDLENBQUMsQ0FDSCxDQUFDO0lBRUY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0FzQkc7SUFDSCxNQUFNLGFBQWEsR0FBRyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBb0IsRUFBRSxFQUFFO1FBQ3pELE9BQU8sU0FBUyxDQUFDLGdCQUFnQixDQUMvQixLQUFLLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRSxLQUFLLENBQUMsRUFDbEQ7WUFDRSxLQUFLLEVBQUUsS0FBSyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ3pDLFNBQVMsRUFBRSxLQUFLLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDcEQsY0FBYyxFQUFFLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLGdCQUFnQixDQUFDLENBQUM7WUFDbkUsU0FBUyxFQUFFLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQ3pELE9BQU8sRUFBRSxLQUFLLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUNyRCxVQUFVLEVBQUUsS0FBSyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQ3ZELFVBQVUsRUFBRSxLQUFLLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUM7U0FDeEQsRUFDRCxHQUFHLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxFQUV2QixNQUFNLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxnQkFBZ0IsRUFBRSxJQUFJLENBQUMsQ0FDakQsQ0FBQztJQUNKLENBQUMsQ0FBQyxDQUFDO0lBQ0gsR0FBRyxDQUFDLEdBQUcsQ0FBQyxxQ0FBcUMsRUFBRSxhQUFhLENBQUMsQ0FBQztJQUM5RCxHQUFHLENBQUMsSUFBSSxDQUFDLHFDQUFxQyxFQUFFLGFBQWEsQ0FBQyxDQUFDO0lBRS9EOzs7Ozs7Ozs7Ozs7Ozs7OztPQWlCRztJQUNILE1BQU0sY0FBYyxHQUFHLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFvQixFQUFFLEVBQUU7UUFDMUQsT0FBTyxTQUFTLENBQUMsT0FBTyxDQUN0QjtZQUNFLFNBQVMsRUFBRSxHQUFHLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQztZQUNsQyxFQUFFLEVBQUUsR0FBRyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUM7WUFDbkIsT0FBTyxFQUFFLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ3JELFVBQVUsRUFBRSxLQUFLLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDdkQsVUFBVSxFQUFFLEtBQUssQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQztTQUN4RCxFQUNELE1BQU0sQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLGdCQUFnQixFQUFFLElBQUksQ0FBQyxDQUNqRCxDQUFDO0lBQ0osQ0FBQyxDQUFDLENBQUM7SUFDSCxHQUFHLENBQUMsR0FBRyxDQUFDLGtDQUFrQyxFQUFFLGNBQWMsQ0FBQyxDQUFDO0lBQzVELEdBQUcsQ0FBQyxJQUFJLENBQUMsa0NBQWtDLEVBQUUsY0FBYyxDQUFDLENBQUM7SUFFN0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQW9DRztJQUNILEdBQUcsQ0FBQyxJQUFJLENBQ04sZ0RBQWdELEVBQ2hELEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFvQixFQUFFLEVBQUU7UUFDbkMsT0FBTyxTQUFTLENBQUMsYUFBYSxDQUM1QixLQUFLLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRSxLQUFLLENBQUMsRUFDbEQsR0FBRyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsRUFDdkI7WUFDRSxVQUFVLEVBQUUsS0FBSyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQ3ZELFVBQVUsRUFBRSxLQUFLLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUM7U0FDeEQsRUFDRCxNQUFNLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxnQkFBZ0IsRUFBRSxJQUFJLENBQUMsQ0FDakQsQ0FBQztJQUNKLENBQUMsQ0FBQyxDQUNILENBQUM7SUFFRjs7Ozs7Ozs7Ozs7Ozs7T0FjRztJQUNILEdBQUcsQ0FBQyxNQUFNLENBQ1Isa0NBQWtDLEVBQ2xDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFvQixFQUFFLEVBQUU7UUFDbkMsT0FBTyxTQUFTLENBQUMsVUFBVSxDQUN6QixHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUNmLEdBQUcsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEVBQ3ZCLE1BQU0sQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLGtCQUFrQixDQUFDLENBQzdDLENBQUM7SUFDSixDQUFDLEVBQUUsR0FBRyxDQUFDLENBQ1IsQ0FBQztBQUNKLENBQUMsQ0FBQyJ9