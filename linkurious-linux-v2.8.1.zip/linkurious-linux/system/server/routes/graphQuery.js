"use strict";
const apiParams_1 = require("../models/parameters/apiParams");
const graphQueryParams_1 = require("../models/parameters/graphQueryParams");
const LKE = require("../services/index");
const api = require("../services/webServer/api");
const GraphQueryService = LKE.getGraphQuery();
const Access = LKE.getAccess();
module.exports = (app) => {
    /**
     * @api {post} /api/:sourceKey/graph/query Create a graph query
     * @apiName CreateGraphQuery
     * @apiGroup Graph
     * @apiPermission authenticated
     * @apiPermission action:raw(Read|Write)Query
     * @apiPermission apiright:savedGraphQuery.create
     * @apiDescription Create a graph query for the current user.
     *
     * @apiUse DataSourceParams
     * @apiUse CreateGraphQueryParams
     *
     * @apiUse GraphQueryResponse
     */
    app.post('/api/:sourceKey/graph/query', api.respond((req) => {
        const params = apiParams_1.ApiParams.parseRequest(graphQueryParams_1.CreateGraphQueryParams, req);
        return GraphQueryService.createGraphQuery(params, Access.getWrappedUser(req));
    }, 201));
    /**
     * @api {get} /api/:sourceKey/graph/query Get all graph queries
     * @apiName GetAllGraphQueries
     * @apiGroup Graph
     * @apiPermission guest_user
     * @apiPermission action:runQuery
     * @apiPermission apiright:savedGraphQuery.read
     * @apiDescription Get all the graph queries owned by the current user or shared with it.
     *
     * @apiUse DataSourceParams
     * @apiUse GetAllGraphQueriesParams
     *
     * @apiUse GetAllGraphQueriesResponse
     */
    app.get('/api/:sourceKey/graph/query', api.respond((req) => {
        const params = apiParams_1.ApiParams.parseRequest(graphQueryParams_1.GetAllGraphQueriesParams, req);
        return GraphQueryService.getAllGraphQueries(params, Access.getWrappedUser(req));
    }));
    /**
     * @api {get} /api/:sourceKey/graph/query/:id Get a graph query
     * @apiName GetGraphQuery
     * @apiGroup Graph
     * @apiPermission guest_user
     * @apiPermission action:runQuery
     * @apiPermission apiright:savedGraphQuery.read
     * @apiDescription Get a graph query owned by the current user or shared with it.
     *
     * @apiUse DataSourceParams
     * @apiUse GetGraphQueryParams
     *
     * @apiUse GraphQueryResponse
     */
    app.get('/api/:sourceKey/graph/query/:id', api.respond((req) => {
        const params = apiParams_1.ApiParams.parseRequest(graphQueryParams_1.GetGraphQueryParams, req);
        return GraphQueryService.getGraphQuery(params, Access.getWrappedUser(req));
    }));
    /**
     * @api {delete} /api/:sourceKey/graph/query/:id Delete a graph query
     * @apiName DeleteGraphQuery
     * @apiGroup Graph
     * @apiPermission owner
     * @apiPermission apiright:savedGraphQuery.delete
     * @apiDescription Delete a graph query owned by the current user.
     *
     * @apiUse DataSourceParams
     * @apiUse GetGraphQueryParams
     *
     * @apiSuccessExample {none} Success-Response:
     *   HTTP/1.1 204 No Content
     */
    app.delete('/api/:sourceKey/graph/query/:id', api.respond((req) => {
        const params = apiParams_1.ApiParams.parseRequest(graphQueryParams_1.DeleteGraphQueryParams, req);
        return GraphQueryService.deleteGraphQuery(params, Access.getWrappedUser(req));
    }, 204));
    /**
     * @api {patch} /api/:sourceKey/graph/query/:id Update a graph query
     * @apiName UpdateGraphQuery
     * @apiGroup Graph
     * @apiPermission owner
     * @apiPermission action:raw(Read|Write)Query
     * @apiPermission apiright:savedGraphQuery.edit
     * @apiDescription Update a graph query owned by the current user.
     *
     * @apiUse DataSourceParams
     * @apiUse UpdateGraphQueryParams
     *
     * @apiUse GraphQueryResponse
     */
    app.patch('/api/:sourceKey/graph/query/:id', api.respond(async (req) => {
        const params = apiParams_1.ApiParams.parseRequest(graphQueryParams_1.UpdateGraphQueryParams, req);
        return GraphQueryService.updateGraphQuery(params, Access.getWrappedUser(req));
    }));
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGhRdWVyeS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NlcnZlci9yb3V0ZXMvZ3JhcGhRdWVyeS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBUUEsOERBQXlEO0FBQ3pELDRFQU0rQztBQUMvQyx5Q0FBMEM7QUFDMUMsaURBQWtEO0FBR2xELE1BQU0saUJBQWlCLEdBQUcsR0FBRyxDQUFDLGFBQWEsRUFBRSxDQUFDO0FBQzlDLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUUvQixpQkFBUyxDQUFDLEdBQXdCLEVBQVEsRUFBRTtJQUMxQzs7Ozs7Ozs7Ozs7OztPQWFHO0lBQ0gsR0FBRyxDQUFDLElBQUksQ0FDTiw2QkFBNkIsRUFDN0IsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQW9CLEVBQUUsRUFBRTtRQUNuQyxNQUFNLE1BQU0sR0FBRyxxQkFBUyxDQUFDLFlBQVksQ0FBQyx5Q0FBc0IsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNuRSxPQUFPLGlCQUFpQixDQUFDLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFDaEYsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUNSLENBQUM7SUFFRjs7Ozs7Ozs7Ozs7OztPQWFHO0lBQ0gsR0FBRyxDQUFDLEdBQUcsQ0FDTCw2QkFBNkIsRUFDN0IsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQW9CLEVBQUUsRUFBRTtRQUNuQyxNQUFNLE1BQU0sR0FBRyxxQkFBUyxDQUFDLFlBQVksQ0FBQywyQ0FBd0IsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNyRSxPQUFPLGlCQUFpQixDQUFDLGtCQUFrQixDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFDbEYsQ0FBQyxDQUFDLENBQ0gsQ0FBQztJQUVGOzs7Ozs7Ozs7Ozs7O09BYUc7SUFDSCxHQUFHLENBQUMsR0FBRyxDQUNMLGlDQUFpQyxFQUNqQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBb0IsRUFBRSxFQUFFO1FBQ25DLE1BQU0sTUFBTSxHQUFHLHFCQUFTLENBQUMsWUFBWSxDQUFDLHNDQUFtQixFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQ2hFLE9BQU8saUJBQWlCLENBQUMsYUFBYSxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFDN0UsQ0FBQyxDQUFDLENBQ0gsQ0FBQztJQUVGOzs7Ozs7Ozs7Ozs7O09BYUc7SUFDSCxHQUFHLENBQUMsTUFBTSxDQUNSLGlDQUFpQyxFQUNqQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBb0IsRUFBRSxFQUFFO1FBQ25DLE1BQU0sTUFBTSxHQUFHLHFCQUFTLENBQUMsWUFBWSxDQUFDLHlDQUFzQixFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQ25FLE9BQU8saUJBQWlCLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztJQUNoRixDQUFDLEVBQUUsR0FBRyxDQUFDLENBQ1IsQ0FBQztJQUVGOzs7Ozs7Ozs7Ozs7O09BYUc7SUFDSCxHQUFHLENBQUMsS0FBSyxDQUNQLGlDQUFpQyxFQUNqQyxHQUFHLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxHQUFvQixFQUFFLEVBQUU7UUFDekMsTUFBTSxNQUFNLEdBQUcscUJBQVMsQ0FBQyxZQUFZLENBQUMseUNBQXNCLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDbkUsT0FBTyxpQkFBaUIsQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQ2hGLENBQUMsQ0FBQyxDQUNILENBQUM7QUFDSixDQUFDLENBQUMifQ==