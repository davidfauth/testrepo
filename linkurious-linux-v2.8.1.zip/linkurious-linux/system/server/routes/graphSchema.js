"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-10-15.
 */
const apiParams_1 = require("../models/parameters/apiParams");
const graphSchemaParams_1 = require("../models/parameters/graphSchemaParams");
const LKE = require("../services/index");
const api = require("../services/webServer/api");
const Access = LKE.getAccess();
const DataProxy = LKE.getDataProxy();
const DataService = LKE.getData();
module.exports = (app) => {
    /**
     * @api {get} /api/{sourceKey}/schema/sampling/status Get the schema sampling status
     * @apiName GetSamplingStatus
     * @apiGroup Schema
     * @apiPermission guest_user
     * @apiPermission apiright:schema
     *
     * @apiDescription Get the schema sampling status.
     *
     * @apiUse DataSourceParams
     *
     * @apiSuccess {string="ongoing","done","error"} status     The status of the schema sampling
     * @apiSuccess {string}                          [progress] Percentage of the schema sampling
     * @apiSuccess {string}                          [message]  A human readable string describing the schema sampling status
     *
     * @apiSuccessExample {json} Success-Response:
     *   HTTP/1.1 200 OK
     *   {
     *     "status": "ongoing",
     *     "progress": "22.22",
     *     "message": "Sampling nodes with type: \"CITY\""
     *   }
     */
    app.get('/api/:sourceKey/schema/sampling/status', api.respond(async (req) => {
        const user = Access.getUserCheck(req, 'schema', true);
        const params = apiParams_1.ApiParams.parseRequest(graphSchemaParams_1.GetSamplingStatusParams, req);
        user.canSeeDataSource(params.sourceKey);
        return DataService.getSamplingStatus(params);
    }, 200));
    /**
     * @api {get} /api/:sourceKey/graph/schema/simple Get simple schema
     * @apiName GetSimpleSchema
     * @apiGroup Schema
     * @apiPermission guest_user
     * @apiPermission apiright:schema
     *
     * @apiDescription List all `edgeTypes`, `nodeCategories`, `edgeProperties`, `nodeProperties`
     * that exist in the graph database.
     * The user must belongs to at least one group of the data-source to use this API.
     *
     * @apiUse DataSourceParams
     *
     * @apiSuccess {string[]} nodeCategories List of node categories
     * @apiSuccess {string[]} edgeTypes      List of edge types
     * @apiSuccess {string[]} nodeProperties List of node properties
     * @apiSuccess {string[]} edgeProperties List of edge properties
     *
     * @apiSuccessExample {json} Success-Response:
     *   HTTP/1.1 200 OK
     *   {
     *     "nodeCategories": [
     *       "Movie",
     *       "Person"
     *     ],
     *     "edgeTypes": [
     *       "ACTED_IN",
     *       "DIRECTED"
     *     ],
     *     "nodeProperties": [
     *       "title",
     *       "name",
     *       "released"
     *     ],
     *     "edgeProperties": [
     *       "role"
     *     ]
     *   }
     */
    app.get('/api/:sourceKey/graph/schema/simple', api.respond(async (req) => {
        const user = Access.getUserCheck(req, 'schema', true);
        const params = apiParams_1.ApiParams.parseRequest(graphSchemaParams_1.GetSimpleSchemaParams, req);
        user.canSeeDataSource(params.sourceKey);
        return DataService.getSimpleSchema(params);
    }, 200));
    /**
     * @api {get} /api/:sourceKey/graph/:entityType/types Get the readable graph schema with access rights
     * @apiName GetGraphSchema
     * @apiGroup Schema
     * @apiPermission guest_user
     * @apiPermission apiright:schema
     *
     * @apiDescription List all the readable types and properties of a data-source.
     *
     * @apiUse DataSourceParams
     * @apiUse GetGraphSchemaParams
     *
     * @apiSuccess {object}                                                                     any
     * @apiSuccess {string="readable","editable","writable","none"}                             any.access                                         Default access level
     * @apiSuccess {object[]}                                                                   results                                            All readable types in the graph schema
     * @apiSuccess {string="readable","editable","writable"}                                    results.access                                     Access level of the graph schema type
     * @apiSuccess {string}                                                                     results.label                                      Name of the graph schema type
     * @apiSuccess {object[]}                                                                   results.properties                                 Properties of `label`
     * @apiSuccess {string="visible","searchable","none"}                                       results.properties.visibility                      Whether the property can be searched, visualized or it is hidden
     * @apiSuccess {object}                                                                     results.properties.propertyType
     * @apiSuccess {string="auto","boolean","date","datetime","number","string"}                results.properties.propertyType.name               Data type of the property
     * @apiSuccess {object}                                                                     [results.properties.propertyType.options]          Additional `propertyType` information (required when `propertyType.name` is "date" or "datetime")
     * @apiSuccess {string[]}                                                                   [results.properties.propertyType.options.values]   A list of values to restrict the value of the property (only applicable when `propertyType` is "string")
     * @apiSuccess {string="native","iso","dd/mm/yyyy","mm/dd/yyyy","timestamp","timestamp-ms"} [results.properties.propertyType.options.format]   Storage format (required and only applicable when `propertyType` is "date" or "datetime")
     * @apiSuccess {string}                                                                     [results.properties.propertyType.options.timezone] Timezone (format: "[+-]HH:MM | Z") (only applicable when `propertyType` is "datetime")
     * @apiSuccess {boolean}                                                                    results.properties.required                        Whether the property is required on data edition
     *
     * @apiSuccessExample {json} Success-Response:
     *   HTTP/1.1 200 OK
     *   {
     *     "any": {
     *       "access": "writable"
     *     },
     *     "results": [
     *       {
     *         "name": "Movie",
     *         "access": "writable",
     *         "properties": [
     *           {
     *             "propertyKey": "released",
     *             "propertyType": {
     *               "name": "date",
     *               "options": {
     *                 "format": "iso"
     *               }
     *             },
     *             "visibility": "searchable",
     *             "required": false
     *           },
     *           {
     *             "propertyKey": "title",
     *             "propertyType": "string",
     *             "visibility": "searchable",
     *             "required": true
     *           }
     *         ]
     *       }
     *     ]
     *   }
     */
    app.get('/api/:sourceKey/graph/schema/:entityType/types', api.respond(async (req) => {
        const user = Access.getUserCheck(req, 'schema', true);
        const params = apiParams_1.ApiParams.parseRequest(graphSchemaParams_1.GetGraphSchemaWithAccessParams, req);
        user.canSeeDataSource(params.sourceKey);
        return DataProxy.getGraphSchema(params, user);
    }, 200));
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGhTY2hlbWEuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zZXJ2ZXIvcm91dGVzL2dyYXBoU2NoZW1hLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRztBQU1ILDhEQUF5RDtBQUN6RCw4RUFJZ0Q7QUFDaEQseUNBQTBDO0FBQzFDLGlEQUFrRDtBQUdsRCxNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxTQUFTLEdBQUcsR0FBRyxDQUFDLFlBQVksRUFBRSxDQUFDO0FBQ3JDLE1BQU0sV0FBVyxHQUFHLEdBQUcsQ0FBQyxPQUFPLEVBQUUsQ0FBQztBQUVsQyxpQkFBUyxDQUFDLEdBQXdCLEVBQVEsRUFBRTtJQUMxQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQXNCRztJQUNILEdBQUcsQ0FBQyxHQUFHLENBQ0wsd0NBQXdDLEVBQ3hDLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLEdBQW9CLEVBQUUsRUFBRTtRQUN6QyxNQUFNLElBQUksR0FBRyxNQUFNLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxRQUFRLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDdEQsTUFBTSxNQUFNLEdBQUcscUJBQVMsQ0FBQyxZQUFZLENBQUMsMkNBQXVCLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDcEUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUV4QyxPQUFPLFdBQVcsQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUMvQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQ1IsQ0FBQztJQUVGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQXNDRztJQUNILEdBQUcsQ0FBQyxHQUFHLENBQ0wscUNBQXFDLEVBQ3JDLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLEdBQW9CLEVBQUUsRUFBRTtRQUN6QyxNQUFNLElBQUksR0FBRyxNQUFNLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxRQUFRLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDdEQsTUFBTSxNQUFNLEdBQUcscUJBQVMsQ0FBQyxZQUFZLENBQUMseUNBQXFCLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDbEUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUN4QyxPQUFPLFdBQVcsQ0FBQyxlQUFlLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDN0MsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUNSLENBQUM7SUFFRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0EyREc7SUFDSCxHQUFHLENBQUMsR0FBRyxDQUNMLGdEQUFnRCxFQUNoRCxHQUFHLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxHQUFvQixFQUFFLEVBQUU7UUFDekMsTUFBTSxJQUFJLEdBQUcsTUFBTSxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsUUFBUSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3RELE1BQU0sTUFBTSxHQUFHLHFCQUFTLENBQUMsWUFBWSxDQUFDLGtEQUE4QixFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQzNFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDeEMsT0FBTyxTQUFTLENBQUMsY0FBYyxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNoRCxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQ1IsQ0FBQztBQUNKLENBQUMsQ0FBQyJ9