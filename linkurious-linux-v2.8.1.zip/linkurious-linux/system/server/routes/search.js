"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 */
const apiParams_1 = require("../models/parameters/apiParams");
const searchParams_1 = require("../models/parameters/searchParams");
const LKE = require("../services/index");
const api = require("../services/webServer/api");
const Access = LKE.getAccess();
const Data = LKE.getData();
const DataProxy = LKE.getDataProxy();
module.exports = (app) => {
    /**
     * @api {post} /api/:sourceKey/search/index Start the indexation
     * @apiName StartIndexation
     * @apiGroup Search
     * @apiPermission authenticated
     * @apiPermission action:admin.index
     * @apiPermission apiright:admin.index
     *
     * @apiDescription Start the indexation.
     * The API doesn't wait for the indexation to finish.
     *
     * @apiUse DataSourceParams
     *
     * @apiSuccessExample {none} Success-Response:
     *   HTTP/1.1 204 No Content
     */
    app.post('/api/:sourceKey/search/index', api.respond(async (req) => {
        const params = apiParams_1.ApiParams.parseRequest(searchParams_1.StartIndexationParams, req);
        await Access.hasAction(req, 'admin.index', params.sourceKey, 'admin.index');
        return Data.startIndexation(params);
    }, 204));
    /**
     * @api {get} /api/:sourceKey/search/status Get the indexation status
     * @apiName GetIndexationStatus
     * @apiGroup Search
     * @apiPermission authenticated
     * @apiPermission apiright:graphItem.search
     *
     * @apiDescription Get the indexation status for a given data-source.
     *
     * @apiUse DataSourceParams
     *
     * @apiSuccess {string="ongoing","needed","done"} indexing            The status of the indexation
     * @apiSuccess {string}                           [indexing_progress] Percentage of the indexation (defined if indexing is `ongoing`)
     * @apiSuccess {number}                           [node_count]        Number of nodes in the graph database (defined if indexing is `ongoing`)
     * @apiSuccess {number}                           [edge_count]        Number of edges in the graph database (defined if indexing is `ongoing`)
     * @apiSuccess {number}                           [index_size]        Number of nodes and edges in the index (defined if indexing is `ongoing`)
     * @apiSuccess {string}                           indexed_source      Key of the data-source (defined if indexing is `ongoing`)
     * @apiSuccess {string}                           indexing_status     A human readable string describing the indexation status
     *
     * @apiSuccessExample {json} Success-Response:
     *   HTTP/1.1 200 OK
     *   {
     *     "indexing": "ongoing",
     *     "indexing_progress": "62.55",
     *     "indexing_status": "Currently indexing 12375 nodes/s. Time left: 25 seconds.",
     *     "node_count": 10,
     *     "edge_count": 25,
     *     "index_size": 19,
     *     "indexed_source": "c1d3fe"
     *   }
     */
    app.get('/api/:sourceKey/search/status', api.respond(async (req) => {
        Access.getUserCheck(req, 'graphItem.search');
        const params = apiParams_1.ApiParams.parseRequest(searchParams_1.GetIndexationStatusParams, req);
        return Data.getIndexationStatus(params);
    }, 200));
    /**
     * @api {get|post} /api/:sourceKey/search/:type Search nodes or edges
     * @apiName Search
     * @apiGroup Search
     * @apiPermission guest_user
     * @apiPermission apiright:graphItem.search
     *
     * @apiDescription Perform a search of nodes or edges based on a search query, a fuzziness value and filters.
     * The list of items that matched the search query is returned.
     *
     * @apiUse DataSourceParams
     * @apiUse SearchParams
     *
     * @apiSuccess {string="node","edge"} type          The searched item type
     * @apiSuccess {number}               [totalHits]   The total number of matching items (if available)
     * @apiSuccess {boolean}              [moreResults] If `totalHits` is `undefined`, `moreResults` will indicate
     *                                                  if there are more items or not that can be retrieved
     *                                                  (`undefined` if `totalHits` is returned)
     * @apiSuccess {object[]}             results       Nodes or edges that matched the search query
     *
     * @apiSuccessExample {json} Success-Response:
     *   HTTP/1.1 200 OK
     *   {
     *     "type": "node",
     *     "totalHits": 3,
     *     "results": [
     *       {
     *         "id": 123,
     *         "data": {
     *           "name": "Matrix",
     *           "released": 1999
     *         },
     *         "categories": [
     *           "Movie"
     *         ],
     *         "readAt": 692362800000
     *       },
     *       {
     *         "id": 124,
     *         "data": {
     *           "name": "Matrix Reloaded",
     *           "released": 2003
     *         },
     *         "categories": [
     *           "Movie"
     *         ],
     *         "readAt": 692362800000
     *       },
     *       {
     *         "id": 125,
     *         "data": {
     *           "name": "Matrix Revolutions",
     *           "released": 2003
     *         },
     *         "categories": [
     *           "Movie"
     *         ],
     *         "readAt": 692362800000
     *       }
     *     ]
     *   }
     */
    const searchHandler = api.respond(async (req) => {
        const params = apiParams_1.ApiParams.parseRequest(searchParams_1.SearchParams, req);
        const user = Access.getUserCheck(req, 'graphItem.search', true);
        return DataProxy.searchIndex(params, user);
    }, 200);
    app.get('/api/:sourceKey/search/:type', searchHandler);
    app.post('/api/:sourceKey/search/:type', searchHandler);
    /**
     * @api {get|post} /api/:sourceKey/search/:type/full Search subgraph
     * @apiName SearchAndAddSubGraph
     * @apiGroup Search
     * @apiPermission guest_user
     * @apiPermission apiright:graphItem.search
     *
     * @apiDescription Perform a search of nodes or edges based on a search query, a fuzziness value and filters.
     * A subgraph made of the items that matched the search query and the edges between them is returned.
     *
     * @apiUse DataSourceParams
     * @apiUse SearchParams
     * @apiUse SearchAndAddSubGraphParams
     *
     * @apiUse ReturnSubGraph
     */
    const searchFullHandler = api.respond(async (req) => {
        const params = apiParams_1.ApiParams.parseRequest(searchParams_1.SearchAndAddSubGraphParams, req);
        const user = Access.getUserCheck(req, 'graphItem.search', true);
        return DataProxy.searchFull(params, user);
    }, 200);
    app.get('/api/:sourceKey/search/:type/full', searchFullHandler);
    app.post('/api/:sourceKey/search/:type/full', searchFullHandler);
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VhcmNoLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc2VydmVyL3JvdXRlcy9zZWFyY2gudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7R0FHRztBQU1ILDhEQUF5RDtBQUN6RCxvRUFLMkM7QUFDM0MseUNBQTBDO0FBQzFDLGlEQUFrRDtBQUdsRCxNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxJQUFJLEdBQUcsR0FBRyxDQUFDLE9BQU8sRUFBRSxDQUFDO0FBQzNCLE1BQU0sU0FBUyxHQUFHLEdBQUcsQ0FBQyxZQUFZLEVBQUUsQ0FBQztBQUVyQyxpQkFBUyxDQUFDLEdBQXdCLEVBQVEsRUFBRTtJQUMxQzs7Ozs7Ozs7Ozs7Ozs7O09BZUc7SUFDSCxHQUFHLENBQUMsSUFBSSxDQUNOLDhCQUE4QixFQUM5QixHQUFHLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxHQUFvQixFQUFFLEVBQUU7UUFDekMsTUFBTSxNQUFNLEdBQUcscUJBQVMsQ0FBQyxZQUFZLENBQUMsb0NBQXFCLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDbEUsTUFBTSxNQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRSxhQUFhLEVBQUUsTUFBTSxDQUFDLFNBQVMsRUFBRSxhQUFhLENBQUMsQ0FBQztRQUM1RSxPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDdEMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUNSLENBQUM7SUFFRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O09BOEJHO0lBQ0gsR0FBRyxDQUFDLEdBQUcsQ0FDTCwrQkFBK0IsRUFDL0IsR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsR0FBb0IsRUFBRSxFQUFFO1FBQ3pDLE1BQU0sQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLGtCQUFrQixDQUFDLENBQUM7UUFDN0MsTUFBTSxNQUFNLEdBQUcscUJBQVMsQ0FBQyxZQUFZLENBQUMsd0NBQXlCLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDdEUsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDMUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUNSLENBQUM7SUFFRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQTZERztJQUNILE1BQU0sYUFBYSxHQUFHLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLEdBQW9CLEVBQUUsRUFBRTtRQUMvRCxNQUFNLE1BQU0sR0FBRyxxQkFBUyxDQUFDLFlBQVksQ0FBQywyQkFBWSxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQ3pELE1BQU0sSUFBSSxHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLGtCQUFrQixFQUFFLElBQUksQ0FBQyxDQUFDO1FBRWhFLE9BQU8sU0FBUyxDQUFDLFdBQVcsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDN0MsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ1IsR0FBRyxDQUFDLEdBQUcsQ0FBQyw4QkFBOEIsRUFBRSxhQUFhLENBQUMsQ0FBQztJQUN2RCxHQUFHLENBQUMsSUFBSSxDQUFDLDhCQUE4QixFQUFFLGFBQWEsQ0FBQyxDQUFDO0lBRXhEOzs7Ozs7Ozs7Ozs7Ozs7T0FlRztJQUNILE1BQU0saUJBQWlCLEdBQUcsR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsR0FBb0IsRUFBRSxFQUFFO1FBQ25FLE1BQU0sTUFBTSxHQUFHLHFCQUFTLENBQUMsWUFBWSxDQUFDLHlDQUEwQixFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQ3ZFLE1BQU0sSUFBSSxHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLGtCQUFrQixFQUFFLElBQUksQ0FBQyxDQUFDO1FBRWhFLE9BQU8sU0FBUyxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDNUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ1IsR0FBRyxDQUFDLEdBQUcsQ0FBQyxtQ0FBbUMsRUFBRSxpQkFBaUIsQ0FBQyxDQUFDO0lBQ2hFLEdBQUcsQ0FBQyxJQUFJLENBQUMsbUNBQW1DLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztBQUNuRSxDQUFDLENBQUMifQ==