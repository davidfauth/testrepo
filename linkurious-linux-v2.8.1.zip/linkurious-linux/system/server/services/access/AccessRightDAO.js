/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-12-17.
 */
'use strict';
const _ = require('lodash');
const Promise = require('bluebird');
const LKE = require('../index');
const Db = LKE.getSqlDb();
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
const Actions = require('./actions');
const GraphSchemaService = LKE.getGraphSchema();
const { EntityType } = require('@linkurious/rest-client');
class AccessRightDAO {
    /**
     * @type {AccessRightModel}
     */
    get model() {
        return Db.models.accessRight;
    }
    /**
     * List all the possible right types.
     *
     * @returns {string[]}
     */
    listRightTypes() {
        return _.values(this.model.TYPES);
    }
    /**
     * List all the possible target types.
     *
     * @returns {string[]}
     */
    listTargetTypes() {
        return _.values(this.model.TARGET_TYPES);
    }
    /**
     * List all the possible actions for a custom group.
     *
     * @returns {string[]}
     */
    listActions() {
        return Actions.PUBLIC_ACTIONS;
    }
    /**
     * Validate the access rights that can be added to a custom group.
     * - No targetName "*" for targetType "nodeCategory" and "edgeType" (allowed for the builtin groups)
     * - No targetName "x" for targetType "nodeCategory" and "edgeType" if "x" is not in the schema and `validateAgainstSchema` is true
     *
     * @param {AccessRightAttributes[]} rights
     * @param {string}                  sourceKey
     * @param {boolean}                 [validateAgainstSchema] Whether the access rights will be checked to be of node categories or edge types in the schema
     * @returns {Bluebird<void>}
     */
    checkRights(rights, sourceKey, validateAgainstSchema) {
        const schemaPromise = validateAgainstSchema
            ? Promise.props({
                node: GraphSchemaService.getSchema(sourceKey, EntityType.NODE),
                edge: GraphSchemaService.getSchema(sourceKey, EntityType.EDGE)
            })
            : Promise.resolve({ node: { labels: [] }, edge: { labels: [] }
            });
        return schemaPromise.then(schema => {
            return Promise.map(rights, right => {
                Utils.check.properties('right', right, {
                    type: { required: true, values: this.listRightTypes() },
                    targetType: { required: true, values: this.listTargetTypes() },
                    targetName: { required: true, check: 'nonEmpty' },
                    sourceKey: { required: true, check: (key, value) => Utils.checkSourceKey(value) }
                });
                Utils.check.values('right.type', right.type, this.model.LEGAL_RIGHTS_BY_TARGET_TYPE.get(right.targetType));
                if (right.targetType === 'action') {
                    Utils.check.values('right.targetName', right.targetName, Actions.PUBLIC_ACTIONS);
                }
                if (right.targetType === 'nodeCategory' || right.targetType === 'edgeType') {
                    if (right.targetName === '*') {
                        return Errors.business('invalid_parameter', 'It\'s not possible to set "*" as "targetName" in a schema access right.', true);
                    }
                }
                if (validateAgainstSchema) {
                    if (right.targetType === 'nodeCategory') {
                        if (schema.node.labels.length === 0) {
                            return Errors.business('invalid_parameter', 'It\'s not possible to set "nodeCategory" as "targetType" ' +
                                'if no node category is available in the schema.', true);
                        }
                        Utils.check.values('right.targetName', right.targetName, schema.node.labels);
                    }
                    if (right.targetType === 'edgeType') {
                        if (schema.edge.labels.length === 0) {
                            return Errors.business('invalid_parameter', 'It\'s not possible to set "edgeType" as "targetType" ' +
                                'if no edge type is available in the schema.', true);
                        }
                        Utils.check.values('right.targetName', right.targetName, schema.edge.labels);
                    }
                }
            });
        }).return();
    }
    /**
     * Find a matching access right. An access right match with another one if their scopes
     * overlap (except wildcard "*").
     *
     * @param {number}                groupId ID of the group
     * @param {AccessRightAttributes} right   Access right to check
     * @returns {Bluebird<AccessRightInstance>}
     */
    findMatchingRight(groupId, right) {
        return this.model.findOne({
            where: {
                groupId: groupId,
                targetType: right.targetType,
                targetName: [right.targetName],
                sourceKey: right.sourceKey
            }
        });
    }
    /**
     * Get the list of target names (access rights) filtered by sourceKey, targetType and type.
     * If the type is "read" and on a given targetName the user has an higher type,
     * return that targetName in the result as well.
     * A returned value of `["*"]` means all the target names.
     *
     * If sourceKey is undefined it means *any* sourceKey. To not confuse with *all* sourceKey.
     *
     * @param {PublicUser} publicUser  A public user with groups and access rights
     * @param {string}     targetType  Type of the target ("edgeType", "nodeCategory", "action", etc.)
     * @param {string}     type        Type of the right ("read", "write", etc.)
     * @param {string}     [sourceKey] Key of the data-source
     * @returns {Bluebird<string[]>} Matching target names
     */
    getRights(publicUser, targetType, type, sourceKey) {
        // if the type is "read", we also look for "edit" access rights
        const types = Utils.hasValue(this.model.IMPLICIT_RIGHTS.get(type))
            ? this.model.IMPLICIT_RIGHTS.get(type)
            : [type];
        let targetNames = [];
        if (Utils.hasValue(publicUser.groups)) {
            publicUser.groups.forEach(group => {
                // process each access right for each group in the data-source (or the admin group)
                if (Utils.hasValue(group.accessRights) &&
                    (group.sourceKey === sourceKey || group.sourceKey === '*' || Utils.noValue(sourceKey))) {
                    group.accessRights.forEach(accessRight => {
                        if (accessRight.targetType === targetType && types.includes(accessRight.type)) {
                            targetNames.push(accessRight.targetName);
                        }
                    });
                }
            });
        }
        // if targetNames includes the wildcard, return only the wildcard
        targetNames = targetNames.includes('*') ? ['*'] : targetNames;
        return Promise.resolve(targetNames);
    }
}
module.exports = new AccessRightDAO();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQWNjZXNzUmlnaHREQU8uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvYWNjZXNzL0FjY2Vzc1JpZ2h0REFPLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBQ2IsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNwQyxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDaEMsTUFBTSxFQUFFLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzFCLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQ3JDLE1BQU0sa0JBQWtCLEdBQUcsR0FBRyxDQUFDLGNBQWMsRUFBRSxDQUFDO0FBQ2hELE1BQU0sRUFBQyxVQUFVLEVBQUMsR0FBRyxPQUFPLENBQUMseUJBQXlCLENBQUMsQ0FBQztBQUV4RCxNQUFNLGNBQWM7SUFDbEI7O09BRUc7SUFDSCxJQUFJLEtBQUs7UUFDUCxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDO0lBQy9CLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsY0FBYztRQUNaLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3BDLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsZUFBZTtRQUNiLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQzNDLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsV0FBVztRQUNULE9BQU8sT0FBTyxDQUFDLGNBQWMsQ0FBQztJQUNoQyxDQUFDO0lBRUQ7Ozs7Ozs7OztPQVNHO0lBQ0gsV0FBVyxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUscUJBQXFCO1FBRWxELE1BQU0sYUFBYSxHQUFHLHFCQUFxQjtZQUN6QyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztnQkFDZCxJQUFJLEVBQUUsa0JBQWtCLENBQUMsU0FBUyxDQUFDLFNBQVMsRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDO2dCQUM5RCxJQUFJLEVBQUUsa0JBQWtCLENBQUMsU0FBUyxDQUFDLFNBQVMsRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDO2FBQy9ELENBQUM7WUFDRixDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFO2FBQzdELENBQUMsQ0FBQztRQUVMLE9BQU8sYUFBYSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUNqQyxPQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxFQUFFO2dCQUNqQyxLQUFLLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsS0FBSyxFQUFFO29CQUNyQyxJQUFJLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxJQUFJLENBQUMsY0FBYyxFQUFFLEVBQUM7b0JBQ3JELFVBQVUsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLElBQUksQ0FBQyxlQUFlLEVBQUUsRUFBQztvQkFDNUQsVUFBVSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFDO29CQUMvQyxTQUFTLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLEVBQUM7aUJBQ2hGLENBQUMsQ0FBQztnQkFFSCxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDLElBQUksRUFDekMsSUFBSSxDQUFDLEtBQUssQ0FBQywyQkFBMkIsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUM3RCxDQUFDO2dCQUVGLElBQUksS0FBSyxDQUFDLFVBQVUsS0FBSyxRQUFRLEVBQUU7b0JBQ2pDLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLGtCQUFrQixFQUFFLEtBQUssQ0FBQyxVQUFVLEVBQ3JELE9BQU8sQ0FBQyxjQUFjLENBQ3ZCLENBQUM7aUJBQ0g7Z0JBRUQsSUFBSSxLQUFLLENBQUMsVUFBVSxLQUFLLGNBQWMsSUFBSSxLQUFLLENBQUMsVUFBVSxLQUFLLFVBQVUsRUFBRTtvQkFDMUUsSUFBSSxLQUFLLENBQUMsVUFBVSxLQUFLLEdBQUcsRUFBRTt3QkFDNUIsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLG1CQUFtQixFQUN4Qyx5RUFBeUUsRUFBRSxJQUFJLENBQ2hGLENBQUM7cUJBQ0g7aUJBQ0Y7Z0JBRUQsSUFBSSxxQkFBcUIsRUFBRTtvQkFDekIsSUFBSSxLQUFLLENBQUMsVUFBVSxLQUFLLGNBQWMsRUFBRTt3QkFDdkMsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFOzRCQUNuQyxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsbUJBQW1CLEVBQ3hDLDJEQUEyRDtnQ0FDM0QsaURBQWlELEVBQUUsSUFBSSxDQUN4RCxDQUFDO3lCQUNIO3dCQUNELEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLGtCQUFrQixFQUFFLEtBQUssQ0FBQyxVQUFVLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztxQkFDOUU7b0JBRUQsSUFBSSxLQUFLLENBQUMsVUFBVSxLQUFLLFVBQVUsRUFBRTt3QkFDbkMsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFOzRCQUNuQyxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsbUJBQW1CLEVBQ3hDLHVEQUF1RDtnQ0FDdkQsNkNBQTZDLEVBQUUsSUFBSSxDQUNwRCxDQUFDO3lCQUNIO3dCQUNELEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLGtCQUFrQixFQUFFLEtBQUssQ0FBQyxVQUFVLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztxQkFDOUU7aUJBQ0Y7WUFFSCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO0lBQ2QsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsS0FBSztRQUM5QixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO1lBQ3hCLEtBQUssRUFBRTtnQkFDTCxPQUFPLEVBQUUsT0FBTztnQkFDaEIsVUFBVSxFQUFFLEtBQUssQ0FBQyxVQUFVO2dCQUM1QixVQUFVLEVBQUUsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDO2dCQUM5QixTQUFTLEVBQUUsS0FBSyxDQUFDLFNBQVM7YUFDM0I7U0FDRixDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7Ozs7T0FhRztJQUNILFNBQVMsQ0FBQyxVQUFVLEVBQUUsVUFBVSxFQUFFLElBQUksRUFBRSxTQUFTO1FBQy9DLCtEQUErRDtRQUMvRCxNQUFNLEtBQUssR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNoRSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztZQUN0QyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUVYLElBQUksV0FBVyxHQUFHLEVBQUUsQ0FBQztRQUVyQixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQ3JDLFVBQVUsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUNoQyxtRkFBbUY7Z0JBQ25GLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDO29CQUNwQyxDQUFDLEtBQUssQ0FBQyxTQUFTLEtBQUssU0FBUyxJQUFJLEtBQUssQ0FBQyxTQUFTLEtBQUssR0FBRyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRTtvQkFDeEYsS0FBSyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLEVBQUU7d0JBQ3ZDLElBQUksV0FBVyxDQUFDLFVBQVUsS0FBSyxVQUFVLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLEVBQUU7NEJBQzdFLFdBQVcsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxDQUFDO3lCQUMxQztvQkFDSCxDQUFDLENBQUMsQ0FBQztpQkFDSjtZQUNILENBQUMsQ0FBQyxDQUFDO1NBQ0o7UUFFRCxpRUFBaUU7UUFDakUsV0FBVyxHQUFHLFdBQVcsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQztRQUU5RCxPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDdEMsQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxJQUFJLGNBQWMsRUFBRSxDQUFDIn0=