/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-12-05.
 */
'use strict';
const _ = require('lodash');
const Promise = require('bluebird');
const LKE = require('../index');
const Db = LKE.getSqlDb();
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
const Data = LKE.getData();
const AccessRightDAO = LKE.getAccessRightDAO();
const UserCache = require('./UserCache');
const builtinGroups = require('./builtinGroups');
const GraphSchemaService = LKE.getGraphSchema();
const { EntityType } = require('@linkurious/rest-client');
class OldGroupDAO {
    /**
     * @type {GroupModel}
     */
    get model() {
        return Db.models.group;
    }
    /**
     * Given a subset of access rights, the targetType and the node categories or the edge types
     * in the schema, produce the complete access rights set for the targetType:
     * - we expand `*` based on the schema information
     * - we set to `none` everything not in the access rights but in the schema
     *
     * @param {string}              targetType        'nodeCategory' or 'edgeType'
     * @param {PublicAccessRight[]} accessRights      Explicit access rights of a group
     * @param {string[]}            categoriesOrTypes List of node categories or edge types in the schema
     * @returns {PublicAccessRight[]}
     * @private
     */
    _expandAccessRights(targetType, accessRights, categoriesOrTypes) {
        // first we look for the wildcard access right, if present
        // 0 or 1 wildcards can be in the list
        let wildcardValue = Db.models.accessRight.TYPES.NONE;
        for (let i = 0; i < accessRights.length; ++i) {
            const currentRight = accessRights[i];
            if (currentRight.targetName === '*') {
                wildcardValue = currentRight.type;
                accessRights.splice(i, 1); // we remove the wildcard access right
                break;
            }
        }
        // now we set everything in the schema with the wildcardValue
        const missingAccessRightsTargetNames = _.difference(categoriesOrTypes, _.map(accessRights, 'targetName'));
        [].push.apply(accessRights, missingAccessRightsTargetNames.map(targetName => {
            return {
                type: wildcardValue,
                targetType: targetType,
                targetName: targetName
            };
        }));
        return accessRights;
    }
    /**
     * Return the proper access rights for a builtin group based on its name.
     *
     * @param {PublicGroup} group
     * @returns {PublicAccessRight[]}
     * @private
     */
    _getBuiltinAccessRights(group) {
        if (group.builtin) {
            switch (group.name) {
                case Db.models.group.READ_ONLY_GROUP_NAME:
                    return builtinGroups.READ_ONLY_ACCESS_RIGHTS;
                case Db.models.group.READ_GROUP_NAME:
                    return builtinGroups.READ_ACCESS_RIGHTS;
                case Db.models.group.READ_AND_EDIT_GROUP_NAME:
                    return builtinGroups.READ_EDIT_ACCESS_RIGHTS;
                case Db.models.group.READ_EDIT_AND_DELETE_GROUP_NAME:
                    return builtinGroups.READ_EDIT_DELETE_ACCESS_RIGHTS;
                case Db.models.group.SOURCE_MANAGER_GROUP_NAME:
                    return builtinGroups.SOURCE_MANAGER_ACCESS_RIGHTS;
                case Db.models.group.ADMIN_GROUP_NAME:
                    return builtinGroups.ADMIN_ACCESS_RIGHTS;
            }
        }
    }
    /**
     * In this function we do the following:
     * - we turn the groupInstance into group attributes
     * - we add the user-count to the group
     * - if `withAccessRights` we add the access rights for the group
     * - if `expandRights` is true
     *  - we expand `*` based on the schema information
     *  - we set to `none` everything not in the access rights but in the schema
     *
     * @param {GroupInstance} groupInstance               Group instance
     * @param {object}        [options]
     * @param {boolean}       [options.withAccessRights]  Whether to populate the accessRights
     * @param {boolean}       [options.withUserCount]     Whether to populate the userCount
     * @param {boolean}       [options.withDates]         Whether to populate the creation and update dates
     * @param {string}        [options.sourceKey]         Override sourceKey of the groupInstance (used to expand categories on the admin group)
     * @param {boolean}       [options.expandRights=true] Whether to expand the wildcard value on schema access rights
     * @returns {Bluebird<PublicGroup>}
     */
    formatToPublicGroup(groupInstance, options) {
        const group = this.model.instanceToPublicAttributes(groupInstance, options.withDates);
        let publicAccessRights;
        let sourceKey;
        const expandRights = options.expandRights !== false;
        return Promise.resolve().then(() => {
            if (!options.withUserCount) {
                return;
            }
            return Db.models.user.count({
                where: { id: { '$notIn': [Db.models.user.UNIQUE_USER_ID] } },
                include: [{
                        model: Db.models.group, where: { id: groupInstance.id }
                    }]
            }).then(count => {
                group.userCount = count;
            });
        }).then(() => {
            if (!options.withAccessRights) {
                return group;
            }
            // if we format the admin group, the sourceKey is '*' but we want to format it
            // correctly for a given data-source
            sourceKey = Utils.hasValue(options.sourceKey) ? options.sourceKey : groupInstance.sourceKey;
            // order of the statements is important because the admin group could have accessRights
            // saved in the sql db before the upgrade
            publicAccessRights = this._getBuiltinAccessRights(group);
            if (Utils.noValue(publicAccessRights)) {
                if (Utils.hasValue(groupInstance.accessRights)) {
                    publicAccessRights = groupInstance.accessRights.map(right => {
                        return Db.models.accessRight.instanceToPublicAttributes(right);
                    });
                }
                else {
                    publicAccessRights = [];
                }
            }
            if (!expandRights) {
                group.accessRights = publicAccessRights;
                return group;
            }
            return Promise.all([
                GraphSchemaService.getSchema(sourceKey, EntityType.NODE),
                GraphSchemaService.getSchema(sourceKey, EntityType.EDGE)
            ]).spread(({ labels: nodeCategories }, { labels: edgeTypes }) => {
                // we partition the access rights in schema related and non
                const [schemaAccessRights, otherAccessRights] = _.partition(publicAccessRights, right => right.targetType === Db.models.accessRight.TARGET_TYPES.NODE_CATEGORY ||
                    right.targetType === Db.models.accessRight.TARGET_TYPES.EDGE_TYPE);
                group.accessRights = otherAccessRights;
                // all the schema-related access rights will be expanded to the whole schema
                // first we expand the wildcard `*`, then we fill the voids for the missing access rights
                // we partition them again in node category and edge type
                const [nodeAccessRights, edgeAccessRights] = _.partition(schemaAccessRights, right => right.targetType === Db.models.accessRight.TARGET_TYPES.NODE_CATEGORY);
                [].push.apply(group.accessRights, this._expandAccessRights(Db.models.accessRight.TARGET_TYPES.NODE_CATEGORY, nodeAccessRights, nodeCategories));
                [].push.apply(group.accessRights, this._expandAccessRights(Db.models.accessRight.TARGET_TYPES.EDGE_TYPE, edgeAccessRights, edgeTypes));
                return group;
            });
        });
    }
    /**
     * Get multiple group instances by id.
     *
     * @param {number[]} groupIds           IDs of the groups
     * @param {boolean}  [withAccessRights] Whether to include the access rights
     * @returns {Bluebird<GroupInstance[]>}
     */
    getGroupInstances(groupIds, withAccessRights) {
        Utils.check.intArray('groupIds', groupIds);
        const query = { where: { id: groupIds } };
        if (withAccessRights) {
            query.include = [Db.models.accessRight];
        }
        return this.model.findAll(query).then(groups => {
            if (groups.length !== groupIds.length) {
                const missing = _.difference(groupIds, groups.map(g => g.id));
                if (missing.length > 0) {
                    return Errors.business('not_found', `Group #${missing[0]} was not found.`, true);
                }
            }
            return groups;
        });
    }
    /**
     * Retrieve a group instance by ID.
     * Return a rejected promise if the group wasn't found or if the sourceKey don't match.
     *
     * @param {number} groupId   ID of the group
     * @param {string} sourceKey Key of the data-source
     * @returns {Bluebird<GroupInstance>}
     * @private
     */
    _getGroupInstance(groupId, sourceKey) {
        Utils.check.posInt('groupId', groupId);
        // check if the source exists and connected
        Data.resolveSource(sourceKey);
        return this.getGroupInstances([groupId], true).then(groupInstances => {
            // unwrap it from the array
            const group = groupInstances[0];
            if (group.sourceKey !== sourceKey) {
                return Errors.access('forbidden', `Group #${groupId} doesn't belong to data-source "${sourceKey}".`, true);
            }
            return group;
        });
    }
    /**
     * Get a group by id.
     *
     * @param {number} groupId   ID of the group
     * @param {string} sourceKey Key of the data-source
     * @returns {Bluebird<PublicGroup>}
     */
    getGroup(groupId, sourceKey) {
        // it's possible to get also the admin group
        if (groupId === this.model.ADMIN_GROUP.id) {
            return this.formatToPublicGroup(this.model.ADMIN_GROUP, {
                withAccessRights: true,
                withUserCount: true,
                withDates: true,
                sourceKey: sourceKey
            });
        }
        return this._getGroupInstance(groupId, sourceKey).then(groupInstance => {
            return this.formatToPublicGroup(groupInstance, {
                withAccessRights: true,
                withUserCount: true,
                withDates: true
            });
        });
    }
    /**
     * Get all groups within a data-source.
     *
     * @param {string}  sourceKey          Key of the data-source
     * @param {boolean} [withAccessRights] Whether to include the access rights
     *
     * @returns {Bluebird<PublicGroup[]>}
     */
    getGroups(sourceKey, withAccessRights) {
        Data.resolveSource(sourceKey);
        const query = { where: { sourceKey: [sourceKey, '*'] } };
        if (withAccessRights) {
            query.include = [Db.models.accessRight];
        }
        return this.model.findAll(query).map(groupInstance => {
            return this.formatToPublicGroup(groupInstance, {
                withAccessRights: withAccessRights,
                withUserCount: true,
                withDates: true,
                sourceKey: sourceKey
            });
        });
    }
    /**
     * Create a group.
     *
     * @param {string} groupName Name of the group
     * @param {string} sourceKey Key of the data-source
     * @returns {Bluebird<PublicGroup>}
     */
    createGroup(groupName, sourceKey) {
        // check if the group name is legal
        Utils.check.nonEmpty('groupName', groupName);
        Data.resolveSource(sourceKey);
        return this.model.findOrCreate({ where: { name: groupName, sourceKey: sourceKey } })
            .spread((groupInstance, created) => {
            if (!created) {
                return Errors.business('group_exists', 'The group already exists', true);
            }
            return this.formatToPublicGroup(groupInstance, {
                withAccessRights: true,
                withUserCount: true,
                withDates: true
            });
        });
    }
    /**
     * Rename a group.
     *
     * @param {number} groupId   ID of the group
     * @param {string} sourceKey Key of the data-source
     * @param {string} name      New name of the group
     * @returns {Bluebird<PublicGroup>}
     */
    renameGroup(groupId, sourceKey, name) {
        // check if the group name is legal
        Utils.check.nonEmpty('name', name);
        return this._getGroupInstance(groupId, sourceKey).then(groupInstance => {
            if (groupInstance.builtin) {
                return Errors.access('forbidden', 'You can\'t rename a builtin group.', true);
            }
            groupInstance.name = name;
            return groupInstance.save().then(() => {
                UserCache.emptyCache();
                return this.formatToPublicGroup(groupInstance, {
                    withAccessRights: true,
                    withUserCount: true,
                    withDates: true
                });
            });
        });
    }
    /**
     * Delete a group and all the rights linked to that group.
     *
     * @param {number} groupId   ID of the group to delete
     * @param {string} sourceKey Key of the data-source
     * @returns {Bluebird<void>}
     */
    deleteGroup(groupId, sourceKey) {
        return this._getGroupInstance(groupId, sourceKey).then(groupInstance => {
            if (groupInstance.builtin) {
                return Errors.access('forbidden', 'You can\'t delete a builtin group.', true);
            }
            // we delete the access rights associated to the group
            return Db.models.accessRight.destroy({ where: { groupId: groupId } }).then(() => {
                UserCache.emptyCache();
                return groupInstance.destroy();
            });
        });
    }
    /**
     * Set an array of access rights on a group.
     *
     * @param {number}                  groupId                 ID of the group
     * @param {string}                  sourceKey               Key of the data-source
     * @param {AccessRightAttributes[]} rights                  Access rights to set
     * @param {boolean}                 [validateAgainstSchema] Whether the access rights will be checked to be of node categories or edge types in the schema
     * @returns {Bluebird<void>}
     */
    setRightsOnGroup(groupId, sourceKey, rights, validateAgainstSchema) {
        rights = rights.map(right => {
            right.sourceKey = sourceKey;
            return right;
        });
        Utils.check.array('rights', rights, 1);
        Data.resolveSource(sourceKey);
        // check that all the access rights are legit
        return AccessRightDAO.checkRights(rights, sourceKey, validateAgainstSchema).then(() => {
            return this._getGroupInstance(groupId, sourceKey);
        }).then(groupInstance => {
            if (groupInstance.builtin) {
                return Errors.access('forbidden', 'Cannot set access rights for builtin groups.', true);
            }
            return Promise.map(rights, right => {
                // we look for an existing access right with the same scope
                return AccessRightDAO.findMatchingRight(groupInstance.id, right).then(existingRight => {
                    // matching access rights exist
                    if (Utils.hasValue(existingRight)) {
                        // update the existing access right
                        existingRight.type = right.type;
                        return existingRight.save().return();
                    }
                    // no matching access right found, create a new one
                    return Db.models.accessRight.create(right).then(rightInstance => {
                        return groupInstance.addAccessRight(rightInstance);
                    }).return();
                });
            }, { concurrency: 1 });
        }).then(() => {
            UserCache.emptyCache();
        });
    }
    /**
     * Delete an access right from a group.
     *
     * @param {number} groupId    ID of the group
     * @param {string} sourceKey  Key of the data-source
     * @param {string} targetType Type of the target of the access rights to delete
     * @param {string} targetName Name of the target of the access rights to delete
     * @returns {Bluebird<void>}
     */
    deleteRightOnGroup(groupId, sourceKey, targetType, targetName) {
        // we check if the group exists and the sourceKey is valid
        return this._getGroupInstance(groupId, sourceKey).then(groupInstance => {
            if (groupInstance.builtin) {
                return Errors.access('forbidden', 'Cannot set access rights for builtin groups.', true);
            }
            const rightAttributes = {
                targetType,
                targetName,
                sourceKey,
                type: '' // AccessRightDAO.findMatchingRight doesn't care about the type
            };
            return AccessRightDAO.findMatchingRight(groupId, rightAttributes);
        }).then(rightInstance => {
            if (Utils.noValue(rightInstance)) {
                return Errors.business('not_found', 'Access right not found', true);
            }
            return rightInstance.destroy();
        }).then(() => {
            UserCache.emptyCache();
        });
    }
    /**
     * Return all the names of the groups that can perform a given action.
     *
     * @param sourceKey
     * @param [action]
     */
    getGroupNames(sourceKey, action) {
        return this.getGroups(sourceKey, true).then(groups => {
            if (Utils.hasValue(action)) {
                groups = _.filter(groups, group => {
                    let hasAction = false;
                    _.forEach(group.accessRights, accessRight => {
                        if (accessRight.targetType === 'action' &&
                            accessRight.type === 'do' &&
                            accessRight.targetName === action) {
                            hasAction = true;
                        }
                    });
                    return hasAction;
                });
            }
            return _.map(groups, group => ({
                id: group.id,
                name: group.name
            }));
        });
    }
}
module.exports = new OldGroupDAO();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiT2xkR3JvdXBEQU8uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvYWNjZXNzL09sZEdyb3VwREFPLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBQ2IsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNwQyxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDaEMsTUFBTSxFQUFFLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzFCLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxJQUFJLEdBQUcsR0FBRyxDQUFDLE9BQU8sRUFBRSxDQUFDO0FBQzNCLE1BQU0sY0FBYyxHQUFHLEdBQUcsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO0FBQy9DLE1BQU0sU0FBUyxHQUFHLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUN6QyxNQUFNLGFBQWEsR0FBRyxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQztBQUNqRCxNQUFNLGtCQUFrQixHQUFHLEdBQUcsQ0FBQyxjQUFjLEVBQUUsQ0FBQztBQUNoRCxNQUFNLEVBQUMsVUFBVSxFQUFDLEdBQUcsT0FBTyxDQUFDLHlCQUF5QixDQUFDLENBQUM7QUFFeEQsTUFBTSxXQUFXO0lBQ2Y7O09BRUc7SUFDSCxJQUFJLEtBQUs7UUFDUCxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO0lBQ3pCLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7T0FXRztJQUNILG1CQUFtQixDQUFDLFVBQVUsRUFBRSxZQUFZLEVBQUUsaUJBQWlCO1FBQzdELDBEQUEwRDtRQUMxRCxzQ0FBc0M7UUFDdEMsSUFBSSxhQUFhLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQztRQUNyRCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsWUFBWSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtZQUM1QyxNQUFNLFlBQVksR0FBRyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDckMsSUFBSSxZQUFZLENBQUMsVUFBVSxLQUFLLEdBQUcsRUFBRTtnQkFDbkMsYUFBYSxHQUFHLFlBQVksQ0FBQyxJQUFJLENBQUM7Z0JBQ2xDLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsc0NBQXNDO2dCQUNqRSxNQUFNO2FBQ1A7U0FDRjtRQUVELDZEQUE2RDtRQUM3RCxNQUFNLDhCQUE4QixHQUFHLENBQUMsQ0FBQyxVQUFVLENBQ2pELGlCQUFpQixFQUNqQixDQUFDLENBQUMsR0FBRyxDQUFDLFlBQVksRUFBRSxZQUFZLENBQUMsQ0FDbEMsQ0FBQztRQUVGLEVBQUUsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksRUFBRSw4QkFBOEIsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLEVBQUU7WUFDMUUsT0FBTztnQkFDTCxJQUFJLEVBQUUsYUFBYTtnQkFDbkIsVUFBVSxFQUFFLFVBQVU7Z0JBQ3RCLFVBQVUsRUFBRSxVQUFVO2FBQ3ZCLENBQUM7UUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRUosT0FBTyxZQUFZLENBQUM7SUFDdEIsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILHVCQUF1QixDQUFDLEtBQUs7UUFDM0IsSUFBSSxLQUFLLENBQUMsT0FBTyxFQUFFO1lBQ2pCLFFBQVEsS0FBSyxDQUFDLElBQUksRUFBRTtnQkFDbEIsS0FBSyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxvQkFBb0I7b0JBQ3ZDLE9BQU8sYUFBYSxDQUFDLHVCQUF1QixDQUFDO2dCQUMvQyxLQUFLLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLGVBQWU7b0JBQ2xDLE9BQU8sYUFBYSxDQUFDLGtCQUFrQixDQUFDO2dCQUMxQyxLQUFLLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLHdCQUF3QjtvQkFDM0MsT0FBTyxhQUFhLENBQUMsdUJBQXVCLENBQUM7Z0JBQy9DLEtBQUssRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsK0JBQStCO29CQUNsRCxPQUFPLGFBQWEsQ0FBQyw4QkFBOEIsQ0FBQztnQkFDdEQsS0FBSyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyx5QkFBeUI7b0JBQzVDLE9BQU8sYUFBYSxDQUFDLDRCQUE0QixDQUFDO2dCQUNwRCxLQUFLLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLGdCQUFnQjtvQkFDbkMsT0FBTyxhQUFhLENBQUMsbUJBQW1CLENBQUM7YUFDNUM7U0FDRjtJQUNILENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7T0FpQkc7SUFDSCxtQkFBbUIsQ0FBQyxhQUFhLEVBQUUsT0FBTztRQUN4QyxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLDBCQUEwQixDQUFDLGFBQWEsRUFBRSxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDdEYsSUFBSSxrQkFBa0IsQ0FBQztRQUN2QixJQUFJLFNBQVMsQ0FBQztRQUNkLE1BQU0sWUFBWSxHQUFHLE9BQU8sQ0FBQyxZQUFZLEtBQUssS0FBSyxDQUFDO1FBRXBELE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDakMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUU7Z0JBQzFCLE9BQU87YUFDUjtZQUVELE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO2dCQUMxQixLQUFLLEVBQUUsRUFBQyxFQUFFLEVBQUUsRUFBQyxRQUFRLEVBQUUsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsRUFBQyxFQUFDO2dCQUN4RCxPQUFPLEVBQUUsQ0FBQzt3QkFDUixLQUFLLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLEVBQUMsRUFBRSxFQUFFLGFBQWEsQ0FBQyxFQUFFLEVBQUM7cUJBQ3RELENBQUM7YUFDSCxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUNkLEtBQUssQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDO1lBQzFCLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNYLElBQUksQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLEVBQUU7Z0JBQzdCLE9BQU8sS0FBSyxDQUFDO2FBQ2Q7WUFFRCw4RUFBOEU7WUFDOUUsb0NBQW9DO1lBQ3BDLFNBQVMsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQztZQUU1Rix1RkFBdUY7WUFDdkYseUNBQXlDO1lBQ3pDLGtCQUFrQixHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUV6RCxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsa0JBQWtCLENBQUMsRUFBRTtnQkFDckMsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsRUFBRTtvQkFDOUMsa0JBQWtCLEdBQUcsYUFBYSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUU7d0JBQzFELE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsMEJBQTBCLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ2pFLENBQUMsQ0FBQyxDQUFDO2lCQUNKO3FCQUFNO29CQUNMLGtCQUFrQixHQUFHLEVBQUUsQ0FBQztpQkFDekI7YUFDRjtZQUVELElBQUksQ0FBQyxZQUFZLEVBQUU7Z0JBQ2pCLEtBQUssQ0FBQyxZQUFZLEdBQUcsa0JBQWtCLENBQUM7Z0JBRXhDLE9BQU8sS0FBSyxDQUFDO2FBQ2Q7WUFFRCxPQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUM7Z0JBQ2pCLGtCQUFrQixDQUFDLFNBQVMsQ0FBQyxTQUFTLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQztnQkFDeEQsa0JBQWtCLENBQUMsU0FBUyxDQUFDLFNBQVMsRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDO2FBQ3pELENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFDLE1BQU0sRUFBRSxjQUFjLEVBQUMsRUFBRSxFQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUMsRUFBRSxFQUFFO2dCQUMxRCwyREFBMkQ7Z0JBQzNELE1BQU0sQ0FBQyxrQkFBa0IsRUFBRSxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsa0JBQWtCLEVBQzVFLEtBQUssQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLFVBQVUsS0FBSyxFQUFFLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUMsYUFBYTtvQkFDOUUsS0FBSyxDQUFDLFVBQVUsS0FBSyxFQUFFLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLENBQUM7Z0JBRXJFLEtBQUssQ0FBQyxZQUFZLEdBQUcsaUJBQWlCLENBQUM7Z0JBRXZDLDRFQUE0RTtnQkFDNUUseUZBQXlGO2dCQUV6Rix5REFBeUQ7Z0JBQ3pELE1BQU0sQ0FBQyxnQkFBZ0IsRUFBRSxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsa0JBQWtCLEVBQ3pFLEtBQUssQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLFVBQVUsS0FBSyxFQUFFLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUMsYUFBYSxDQUFDLENBQUM7Z0JBRWxGLEVBQUUsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLG1CQUFtQixDQUN4RCxFQUFFLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUMsYUFBYSxFQUFFLGdCQUFnQixFQUFFLGNBQWMsQ0FBQyxDQUFDLENBQUM7Z0JBRXZGLEVBQUUsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLG1CQUFtQixDQUN4RCxFQUFFLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUMsU0FBUyxFQUFFLGdCQUFnQixFQUFFLFNBQVMsQ0FBQyxDQUFDLENBQUM7Z0JBRTlFLE9BQU8sS0FBSyxDQUFDO1lBQ2YsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxpQkFBaUIsQ0FBQyxRQUFRLEVBQUUsZ0JBQWdCO1FBQzFDLEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLFVBQVUsRUFBRSxRQUFRLENBQUMsQ0FBQztRQUUzQyxNQUFNLEtBQUssR0FBRyxFQUFDLEtBQUssRUFBRSxFQUFDLEVBQUUsRUFBRSxRQUFRLEVBQUMsRUFBQyxDQUFDO1FBQ3RDLElBQUksZ0JBQWdCLEVBQUU7WUFDcEIsS0FBSyxDQUFDLE9BQU8sR0FBRyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7U0FDekM7UUFFRCxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUM3QyxJQUFJLE1BQU0sQ0FBQyxNQUFNLEtBQUssUUFBUSxDQUFDLE1BQU0sRUFBRTtnQkFDckMsTUFBTSxPQUFPLEdBQUcsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUM5RCxJQUFJLE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO29CQUN0QixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLFVBQVUsT0FBTyxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsRUFBRSxJQUFJLENBQUMsQ0FBQztpQkFDbEY7YUFDRjtZQUVELE9BQU8sTUFBTSxDQUFDO1FBQ2hCLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsaUJBQWlCLENBQUMsT0FBTyxFQUFFLFNBQVM7UUFDbEMsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBRXZDLDJDQUEyQztRQUMzQyxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBRTlCLE9BQU8sSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFO1lBQ25FLDJCQUEyQjtZQUMzQixNQUFNLEtBQUssR0FBRyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFaEMsSUFBSSxLQUFLLENBQUMsU0FBUyxLQUFLLFNBQVMsRUFBRTtnQkFDakMsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUNsQixXQUFXLEVBQ1gsVUFBVSxPQUFPLG1DQUFtQyxTQUFTLElBQUksRUFDakUsSUFBSSxDQUNMLENBQUM7YUFDSDtZQUNELE9BQU8sS0FBSyxDQUFDO1FBQ2YsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsUUFBUSxDQUFDLE9BQU8sRUFBRSxTQUFTO1FBQ3pCLDRDQUE0QztRQUM1QyxJQUFJLE9BQU8sS0FBSyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxFQUFFLEVBQUU7WUFDekMsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQUU7Z0JBQ3RELGdCQUFnQixFQUFFLElBQUk7Z0JBQ3RCLGFBQWEsRUFBRSxJQUFJO2dCQUNuQixTQUFTLEVBQUUsSUFBSTtnQkFDZixTQUFTLEVBQUUsU0FBUzthQUNyQixDQUFDLENBQUM7U0FDSjtRQUVELE9BQU8sSUFBSSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUU7WUFDckUsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMsYUFBYSxFQUFFO2dCQUM3QyxnQkFBZ0IsRUFBRSxJQUFJO2dCQUN0QixhQUFhLEVBQUUsSUFBSTtnQkFDbkIsU0FBUyxFQUFFLElBQUk7YUFDaEIsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILFNBQVMsQ0FBQyxTQUFTLEVBQUUsZ0JBQWdCO1FBQ25DLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUM7UUFFOUIsTUFBTSxLQUFLLEdBQUcsRUFBQyxLQUFLLEVBQUUsRUFBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLEVBQUUsR0FBRyxDQUFDLEVBQUMsRUFBQyxDQUFDO1FBQ3JELElBQUksZ0JBQWdCLEVBQUU7WUFDcEIsS0FBSyxDQUFDLE9BQU8sR0FBRyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7U0FDekM7UUFFRCxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsRUFBRTtZQUNuRCxPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxhQUFhLEVBQUU7Z0JBQzdDLGdCQUFnQixFQUFFLGdCQUFnQjtnQkFDbEMsYUFBYSxFQUFFLElBQUk7Z0JBQ25CLFNBQVMsRUFBRSxJQUFJO2dCQUNmLFNBQVMsRUFBRSxTQUFTO2FBQ3JCLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILFdBQVcsQ0FBQyxTQUFTLEVBQUUsU0FBUztRQUM5QixtQ0FBbUM7UUFDbkMsS0FBSyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBRTdDLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUM7UUFFOUIsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxFQUFDLEtBQUssRUFBRSxFQUFDLElBQUksRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBQyxFQUFDLENBQUM7YUFDN0UsTUFBTSxDQUFDLENBQUMsYUFBYSxFQUFFLE9BQU8sRUFBRSxFQUFFO1lBQ2pDLElBQUksQ0FBQyxPQUFPLEVBQUU7Z0JBQ1osT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLGNBQWMsRUFBRSwwQkFBMEIsRUFBRSxJQUFJLENBQUMsQ0FBQzthQUMxRTtZQUVELE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLGFBQWEsRUFBRTtnQkFDN0MsZ0JBQWdCLEVBQUUsSUFBSTtnQkFDdEIsYUFBYSxFQUFFLElBQUk7Z0JBQ25CLFNBQVMsRUFBRSxJQUFJO2FBQ2hCLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxXQUFXLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRSxJQUFJO1FBQ2xDLG1DQUFtQztRQUNuQyxLQUFLLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFFbkMsT0FBTyxJQUFJLENBQUMsaUJBQWlCLENBQUMsT0FBTyxFQUFFLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRTtZQUNyRSxJQUFJLGFBQWEsQ0FBQyxPQUFPLEVBQUU7Z0JBQ3pCLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUUsb0NBQW9DLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDL0U7WUFFRCxhQUFhLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztZQUUxQixPQUFPLGFBQWEsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNwQyxTQUFTLENBQUMsVUFBVSxFQUFFLENBQUM7Z0JBQ3ZCLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLGFBQWEsRUFBRTtvQkFDN0MsZ0JBQWdCLEVBQUUsSUFBSTtvQkFDdEIsYUFBYSxFQUFFLElBQUk7b0JBQ25CLFNBQVMsRUFBRSxJQUFJO2lCQUNoQixDQUFDLENBQUM7WUFDTCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILFdBQVcsQ0FBQyxPQUFPLEVBQUUsU0FBUztRQUM1QixPQUFPLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFO1lBQ3JFLElBQUksYUFBYSxDQUFDLE9BQU8sRUFBRTtnQkFDekIsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUNsQixXQUFXLEVBQUUsb0NBQW9DLEVBQUUsSUFBSSxDQUN4RCxDQUFDO2FBQ0g7WUFFRCxzREFBc0Q7WUFDdEQsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsRUFBQyxLQUFLLEVBQUUsRUFBQyxPQUFPLEVBQUUsT0FBTyxFQUFDLEVBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQzFFLFNBQVMsQ0FBQyxVQUFVLEVBQUUsQ0FBQztnQkFDdkIsT0FBTyxhQUFhLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDakMsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILGdCQUFnQixDQUFDLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLHFCQUFxQjtRQUNoRSxNQUFNLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUMxQixLQUFLLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQztZQUM1QixPQUFPLEtBQUssQ0FBQztRQUNmLENBQUMsQ0FBQyxDQUFDO1FBRUgsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQztRQUV2QyxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBRTlCLDZDQUE2QztRQUM3QyxPQUFPLGNBQWMsQ0FBQyxXQUFXLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxxQkFBcUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDcEYsT0FBTyxJQUFJLENBQUMsaUJBQWlCLENBQUMsT0FBTyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBQ3BELENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRTtZQUN0QixJQUFJLGFBQWEsQ0FBQyxPQUFPLEVBQUU7Z0JBQ3pCLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FDbEIsV0FBVyxFQUFFLDhDQUE4QyxFQUFFLElBQUksQ0FDbEUsQ0FBQzthQUNIO1lBRUQsT0FBTyxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsRUFBRTtnQkFDakMsMkRBQTJEO2dCQUMzRCxPQUFPLGNBQWMsQ0FBQyxpQkFBaUIsQ0FBQyxhQUFhLENBQUMsRUFBRSxFQUFFLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRTtvQkFFcEYsK0JBQStCO29CQUMvQixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLEVBQUU7d0JBRWpDLG1DQUFtQzt3QkFDbkMsYUFBYSxDQUFDLElBQUksR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDO3dCQUNoQyxPQUFPLGFBQWEsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQztxQkFDdEM7b0JBRUQsbURBQW1EO29CQUNuRCxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUU7d0JBQzlELE9BQU8sYUFBYSxDQUFDLGNBQWMsQ0FBQyxhQUFhLENBQUMsQ0FBQztvQkFDckQsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7Z0JBQ2QsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDLEVBQUUsRUFBQyxXQUFXLEVBQUUsQ0FBQyxFQUFDLENBQUMsQ0FBQztRQUN2QixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1gsU0FBUyxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ3pCLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsa0JBQWtCLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRSxVQUFVLEVBQUUsVUFBVTtRQUMzRCwwREFBMEQ7UUFDMUQsT0FBTyxJQUFJLENBQUMsaUJBQWlCLENBQUMsT0FBTyxFQUFFLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRTtZQUNyRSxJQUFJLGFBQWEsQ0FBQyxPQUFPLEVBQUU7Z0JBQ3pCLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FDbEIsV0FBVyxFQUFFLDhDQUE4QyxFQUFFLElBQUksQ0FDbEUsQ0FBQzthQUNIO1lBRUQsTUFBTSxlQUFlLEdBQUc7Z0JBQ3RCLFVBQVU7Z0JBQ1YsVUFBVTtnQkFDVixTQUFTO2dCQUNULElBQUksRUFBRSxFQUFFLENBQUMsK0RBQStEO2FBQ3pFLENBQUM7WUFFRixPQUFPLGNBQWMsQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsZUFBZSxDQUFDLENBQUM7UUFDcEUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFO1lBQ3RCLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsRUFBRTtnQkFDaEMsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSx3QkFBd0IsRUFBRSxJQUFJLENBQUMsQ0FBQzthQUNyRTtZQUVELE9BQU8sYUFBYSxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQ2pDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCxTQUFTLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDekIsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxhQUFhLENBQUMsU0FBUyxFQUFFLE1BQU07UUFDN0IsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDbkQsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxFQUFFO2dCQUMxQixNQUFNLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLEVBQUU7b0JBQ2hDLElBQUksU0FBUyxHQUFHLEtBQUssQ0FBQztvQkFDdEIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsWUFBWSxFQUFFLFdBQVcsQ0FBQyxFQUFFO3dCQUMxQyxJQUNFLFdBQVcsQ0FBQyxVQUFVLEtBQUssUUFBUTs0QkFDbkMsV0FBVyxDQUFDLElBQUksS0FBSyxJQUFJOzRCQUN6QixXQUFXLENBQUMsVUFBVSxLQUFLLE1BQU0sRUFBRTs0QkFDbkMsU0FBUyxHQUFHLElBQUksQ0FBQzt5QkFDbEI7b0JBQ0gsQ0FBQyxDQUFDLENBQUM7b0JBRUgsT0FBTyxTQUFTLENBQUM7Z0JBQ25CLENBQUMsQ0FBQyxDQUFDO2FBQ0o7WUFFRCxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFDN0IsRUFBRSxFQUFFLEtBQUssQ0FBQyxFQUFFO2dCQUNaLElBQUksRUFBRSxLQUFLLENBQUMsSUFBSTthQUNqQixDQUFDLENBQUMsQ0FBQztRQUNOLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxJQUFJLFdBQVcsRUFBRSxDQUFDIn0=