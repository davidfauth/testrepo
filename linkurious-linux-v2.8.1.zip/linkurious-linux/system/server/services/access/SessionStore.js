/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-11-30.
 */
'use strict';
const Store = require('express-session').Store;
const LKE = require('../index');
const Utils = LKE.getUtils();
const Config = LKE.getConfig();
const CappedQueue = require('../../../lib/CappedQueue');
const DEFAULT_MAX_LENGTH_QUEUE_2_STAGE_AUTH = 100;
const DEFAULT_FLOATING_LICENSE_RESERVED_TIME_MS = 30 * 60 * 1000; // 30 minutes
/**
 * The following error:
 *
 * error TS2425: Class 'Store' defines instance member property 'all',
 * but extended class 'SessionStore' defines it as instance member function.
 *
 * is due to SessionStore being an ES6 class and Store an ES5 (equivalent) class.
 */
class SessionStore extends Store {
    /**
     * A session store in memory.
     *
     * - The store allows only 1 session per user.
     * - The session is never set if it doesn't contain the user or the `twoStageAuth` flag
     * - `TwoStageAuth`-only sessions are put in a queue with a maxLength of DEFAULT_MAX_LENGTH_QUEUE_2_STAGE_AUTH.
     * - If the queue reaches the maxLength, the latest session is destroyed.
     * - The session is not created if:
     *   - the number of sessions if equal to the floating licenses number, and
     *   - the user is not an admin, and
     *   - all sessions were touched by less than DEFAULT_FLOATING_LICENSE_RESERVED_TIME_MS minutes.
     *
     * @param {number} [floatingLicenses]            Number of floating licenses to allow
     * @param {number} [twoStageSessions]            Number of two-stage sessions to allow to exist concurrently
     * @param {number} [floatingLicenseReservedTime] Number of milliseconds after which a session can be released
     */
    constructor(floatingLicenses, twoStageSessions, floatingLicenseReservedTime) {
        super();
        this.floatingLicensesInUse = floatingLicenses > 0;
        this.floatingLicenseReservedTime = floatingLicenseReservedTime ||
            DEFAULT_FLOATING_LICENSE_RESERVED_TIME_MS;
        this.userIdToSessionId = new Map();
        this.sessions = new Map();
        this.twoStageSessionQueue = new CappedQueue(twoStageSessions ||
            DEFAULT_MAX_LENGTH_QUEUE_2_STAGE_AUTH);
        this.floatingLicensesSessionQueue = new CappedQueue(floatingLicenses);
    }
    /**
     * Get all active sessions.
     *
     * @param {function(void, LkSession[])} callback
     */
    all(callback) {
        callback && callback(null, Array.from(this.sessions.values()));
    }
    /**
     * Clear all sessions.
     *
     * @param {function} callback
     */
    clear(callback) {
        this.userIdToSessionId.clear();
        this.sessions.clear();
        this.twoStageSessionQueue.clear();
        this.floatingLicensesSessionQueue.clear();
        callback && callback();
    }
    /**
     * Destroy the session associated with the given session ID.
     *
     * @param {string}   sessionId
     * @param {function} callback
     */
    destroy(sessionId, callback) {
        if (this.sessions.has(sessionId)) {
            this.userIdToSessionId.delete(this.sessions.get(sessionId).userId);
        }
        this.sessions.delete(sessionId);
        this.twoStageSessionQueue.delete(sessionId);
        this.floatingLicensesSessionQueue.delete(sessionId);
        callback && callback();
    }
    /**
     * Get number of active sessions.
     *
     * @param {function(void, number)} callback
     */
    length(callback) {
        callback && callback(null, this.sessions.size);
    }
    /**
     * Fetch session by the given session ID.
     *
     * @param {string}                    sessionId
     * @param {function(void, LkSession)} callback
     */
    get(sessionId, callback) {
        const session = this.sessions.get(sessionId);
        const loginTimeout = Config.get('access.loginTimeout');
        // is the session older than access.loginTimeout?
        if (Utils.hasValue(session) && Utils.hasValue(loginTimeout) &&
            session.lastVisit + loginTimeout * 1000 < Date.now()) {
            session.error = SessionStore.Errors.EXPIRED;
        }
        callback && callback(null, session);
    }
    /**
     * Commit the given session associated with the given sessionId to the store.
     *
     * @param {string}    sessionId
     * @param {LkSession} session
     * @param {function}  callback
     */
    set(sessionId, session, callback) {
        const userId = session.userId;
        const twoStageAuth = !!session.twoStageAuth;
        // if a user is not specified and the twoStageAuth is not set
        if (Utils.noValue(userId) && !twoStageAuth) {
            // don't do anything
            callback && callback();
            return;
        }
        // are we in the 1st stage of a two-stage auth? (user wasn't yet retrieved)
        if (Utils.noValue(userId) && twoStageAuth) {
            // the queue returns the last element so it can be deleted (if defined)
            this.sessions.delete(this.twoStageSessionQueue.add(sessionId));
            this.sessions.set(sessionId, session);
            callback && callback();
            return;
        }
        // we have a user, let's check if this user was already logged in
        const previousSessionId = this.userIdToSessionId.get(userId);
        if (previousSessionId) {
            // it was, so we delete its previous session
            this.sessions.delete(previousSessionId);
            this.userIdToSessionId.delete(userId);
            this.floatingLicensesSessionQueue.delete(previousSessionId);
        }
        // are we in the 2nd stage of a two-stage auth?
        if (Utils.hasValue(userId) && twoStageAuth) {
            // this session doesn't count anymore within the limit of 100 two-stage auth sessions
            this.twoStageSessionQueue.delete(sessionId);
        }
        // are we using floating licenses?
        if (this.floatingLicensesInUse) {
            // are all floating licenses in use?
            if (this.floatingLicensesSessionQueue.isFull()) {
                // yes and we have to kick another user out if possible
                // it's possible to kick in two case:
                //   - current user is an admin
                //   - the latest floating license was touched at least 30 minutes ago
                const latestFloatingSessionId = this.floatingLicensesSessionQueue.front();
                const latestFloatingSession = this.sessions.get(latestFloatingSessionId);
                if (session.admin ||
                    latestFloatingSession.lastVisit + this.floatingLicenseReservedTime < Date.now()) {
                    // delete the old session and set the error
                    latestFloatingSession.error = session.admin
                        ? SessionStore.Errors.FLOATING_KICKED
                        : SessionStore.Errors.FLOATING_EXPIRED;
                    this.floatingLicensesSessionQueue.delete(latestFloatingSessionId);
                    // add the new session to the reserved licenses queue
                    session.error = undefined;
                    this.floatingLicensesSessionQueue.add(sessionId);
                }
                else {
                    session.error = SessionStore.Errors.FLOATING_FULL;
                }
            }
            else {
                // no, we can easily get one
                session.error = undefined;
                this.floatingLicensesSessionQueue.add(sessionId);
            }
        }
        this._updateLastVisit(session);
        this.sessions.set(sessionId, session);
        this.userIdToSessionId.set(userId, sessionId);
        callback && callback();
    }
    /**
     * Touch the given session object associated with the given session ID.
     *
     * @param {string}    sessionId
     * @param {LkSession} session
     * @param {function}  callback
     */
    touch(sessionId, session, callback) {
        if (this.floatingLicensesInUse) {
            this.floatingLicensesSessionQueue.update(sessionId);
        }
        if (Utils.hasValue(this.sessions.get(sessionId))) {
            this._updateLastVisit(this.sessions.get(sessionId));
        }
        callback && callback();
    }
    /**
     * Update the session `lastVisit`.
     *
     * @param {LkSession} session
     * @private
     */
    _updateLastVisit(session) {
        session.lastVisit = Date.now();
    }
}
SessionStore.Errors = {
    EXPIRED: 'session_expired',
    FLOATING_EXPIRED: 'session_expired',
    FLOATING_KICKED: 'session_evicted',
    FLOATING_FULL: 'server_full'
};
module.exports = SessionStore;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiU2Vzc2lvblN0b3JlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL3NlcnZpY2VzL2FjY2Vzcy9TZXNzaW9uU3RvcmUuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFDYixNQUFNLEtBQUssR0FBRyxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDL0MsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ2hDLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxXQUFXLEdBQUcsT0FBTyxDQUFDLDBCQUEwQixDQUFDLENBQUM7QUFFeEQsTUFBTSxxQ0FBcUMsR0FBRyxHQUFHLENBQUM7QUFDbEQsTUFBTSx5Q0FBeUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQyxDQUFDLGFBQWE7QUFFL0U7Ozs7Ozs7R0FPRztBQUNILE1BQU0sWUFBYSxTQUFRLEtBQUs7SUFDOUI7Ozs7Ozs7Ozs7Ozs7OztPQWVHO0lBQ0gsWUFBWSxnQkFBZ0IsRUFBRSxnQkFBZ0IsRUFBRSwyQkFBMkI7UUFDekUsS0FBSyxFQUFFLENBQUM7UUFFUixJQUFJLENBQUMscUJBQXFCLEdBQUcsZ0JBQWdCLEdBQUcsQ0FBQyxDQUFDO1FBQ2xELElBQUksQ0FBQywyQkFBMkIsR0FBRywyQkFBMkI7WUFDNUQseUNBQXlDLENBQUM7UUFFNUMsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7UUFDbkMsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBQzFCLElBQUksQ0FBQyxvQkFBb0IsR0FBRyxJQUFJLFdBQVcsQ0FBQyxnQkFBZ0I7WUFDMUQscUNBQXFDLENBQUMsQ0FBQztRQUN6QyxJQUFJLENBQUMsNEJBQTRCLEdBQUcsSUFBSSxXQUFXLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztJQUN4RSxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILEdBQUcsQ0FBQyxRQUFRO1FBQ1YsUUFBUSxJQUFJLFFBQVEsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQztJQUNqRSxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILEtBQUssQ0FBQyxRQUFRO1FBQ1osSUFBSSxDQUFDLGlCQUFpQixDQUFDLEtBQUssRUFBRSxDQUFDO1FBQy9CLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDdEIsSUFBSSxDQUFDLG9CQUFvQixDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ2xDLElBQUksQ0FBQyw0QkFBNEIsQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUMxQyxRQUFRLElBQUksUUFBUSxFQUFFLENBQUM7SUFDekIsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsT0FBTyxDQUFDLFNBQVMsRUFBRSxRQUFRO1FBQ3pCLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDaEMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUNwRTtRQUNELElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ2hDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDNUMsSUFBSSxDQUFDLDRCQUE0QixDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUNwRCxRQUFRLElBQUksUUFBUSxFQUFFLENBQUM7SUFDekIsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxNQUFNLENBQUMsUUFBUTtRQUNiLFFBQVEsSUFBSSxRQUFRLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDakQsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsR0FBRyxDQUFDLFNBQVMsRUFBRSxRQUFRO1FBQ3JCLE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzdDLE1BQU0sWUFBWSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMscUJBQXFCLENBQUMsQ0FBQztRQUV2RCxpREFBaUQ7UUFDakQsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDO1lBQ3pELE9BQU8sQ0FBQyxTQUFTLEdBQUcsWUFBWSxHQUFHLElBQUksR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLEVBQ3BEO1lBQ0EsT0FBTyxDQUFDLEtBQUssR0FBRyxZQUFZLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztTQUM3QztRQUVELFFBQVEsSUFBSSxRQUFRLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxHQUFHLENBQUMsU0FBUyxFQUFFLE9BQU8sRUFBRSxRQUFRO1FBQzlCLE1BQU0sTUFBTSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUM7UUFDOUIsTUFBTSxZQUFZLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUM7UUFFNUMsNkRBQTZEO1FBQzdELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRTtZQUMxQyxvQkFBb0I7WUFDcEIsUUFBUSxJQUFJLFFBQVEsRUFBRSxDQUFDO1lBQ3ZCLE9BQU87U0FDUjtRQUVELDJFQUEyRTtRQUMzRSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksWUFBWSxFQUFFO1lBQ3pDLHVFQUF1RTtZQUN2RSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7WUFDL0QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1lBRXRDLFFBQVEsSUFBSSxRQUFRLEVBQUUsQ0FBQztZQUN2QixPQUFPO1NBQ1I7UUFFRCxpRUFBaUU7UUFDakUsTUFBTSxpQkFBaUIsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzdELElBQUksaUJBQWlCLEVBQUU7WUFDckIsNENBQTRDO1lBQzVDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLENBQUM7WUFDeEMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN0QyxJQUFJLENBQUMsNEJBQTRCLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLENBQUM7U0FDN0Q7UUFFRCwrQ0FBK0M7UUFDL0MsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLFlBQVksRUFBRTtZQUMxQyxxRkFBcUY7WUFDckYsSUFBSSxDQUFDLG9CQUFvQixDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQztTQUM3QztRQUVELGtDQUFrQztRQUNsQyxJQUFJLElBQUksQ0FBQyxxQkFBcUIsRUFBRTtZQUM5QixvQ0FBb0M7WUFDcEMsSUFBSSxJQUFJLENBQUMsNEJBQTRCLENBQUMsTUFBTSxFQUFFLEVBQUU7Z0JBQzlDLHVEQUF1RDtnQkFFdkQscUNBQXFDO2dCQUNyQywrQkFBK0I7Z0JBQy9CLHNFQUFzRTtnQkFFdEUsTUFBTSx1QkFBdUIsR0FBRyxJQUFJLENBQUMsNEJBQTRCLENBQUMsS0FBSyxFQUFFLENBQUM7Z0JBQzFFLE1BQU0scUJBQXFCLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsdUJBQXVCLENBQUMsQ0FBQztnQkFDekUsSUFBSSxPQUFPLENBQUMsS0FBSztvQkFDZixxQkFBcUIsQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLDJCQUEyQixHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRTtvQkFDakYsMkNBQTJDO29CQUMzQyxxQkFBcUIsQ0FBQyxLQUFLLEdBQUcsT0FBTyxDQUFDLEtBQUs7d0JBQ3pDLENBQUMsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLGVBQWU7d0JBQ3JDLENBQUMsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDO29CQUN6QyxJQUFJLENBQUMsNEJBQTRCLENBQUMsTUFBTSxDQUFDLHVCQUF1QixDQUFDLENBQUM7b0JBRWxFLHFEQUFxRDtvQkFDckQsT0FBTyxDQUFDLEtBQUssR0FBRyxTQUFTLENBQUM7b0JBQzFCLElBQUksQ0FBQyw0QkFBNEIsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUM7aUJBQ2xEO3FCQUFNO29CQUNMLE9BQU8sQ0FBQyxLQUFLLEdBQUcsWUFBWSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUM7aUJBQ25EO2FBQ0Y7aUJBQU07Z0JBQ0wsNEJBQTRCO2dCQUM1QixPQUFPLENBQUMsS0FBSyxHQUFHLFNBQVMsQ0FBQztnQkFDMUIsSUFBSSxDQUFDLDRCQUE0QixDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQzthQUNsRDtTQUNGO1FBRUQsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRS9CLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUN0QyxJQUFJLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxTQUFTLENBQUMsQ0FBQztRQUU5QyxRQUFRLElBQUksUUFBUSxFQUFFLENBQUM7SUFDekIsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILEtBQUssQ0FBQyxTQUFTLEVBQUUsT0FBTyxFQUFFLFFBQVE7UUFDaEMsSUFBSSxJQUFJLENBQUMscUJBQXFCLEVBQUU7WUFDOUIsSUFBSSxDQUFDLDRCQUE0QixDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQztTQUNyRDtRQUVELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFO1lBQ2hELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO1NBQ3JEO1FBRUQsUUFBUSxJQUFJLFFBQVEsRUFBRSxDQUFDO0lBQ3pCLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILGdCQUFnQixDQUFDLE9BQU87UUFDdEIsT0FBTyxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7SUFDakMsQ0FBQztDQUNGO0FBRUQsWUFBWSxDQUFDLE1BQU0sR0FBRztJQUNwQixPQUFPLEVBQUUsaUJBQWlCO0lBQzFCLGdCQUFnQixFQUFFLGlCQUFpQjtJQUNuQyxlQUFlLEVBQUUsaUJBQWlCO0lBQ2xDLGFBQWEsRUFBRSxhQUFhO0NBQzdCLENBQUM7QUFFRixNQUFNLENBQUMsT0FBTyxHQUFHLFlBQVksQ0FBQyJ9