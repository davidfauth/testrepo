/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-12-05.
 */
'use strict';
const _ = require('lodash');
const Promise = require('bluebird');
const LKE = require('../index');
const Db = LKE.getSqlDb();
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
const Config = LKE.getConfig();
const OldGroupDAO = LKE.getOldGroupDAO();
const Actions = require('./actions');
const UserCache = require('./UserCache');
const MIN_PASSWORD_LENGTH = 3;
class UserDAO {
    /**
     * @type {UserModel}
     */
    get model() {
        return Db.models.user;
    }
    /**
     * @param {SequelizeFindOptions<any>} findOptions
     * @param {boolean}                   [withGroups]
     * @returns {Bluebird<UserInstance | null>}
     * @private
     */
    _getUserByFindOptions(findOptions, withGroups) {
        if (withGroups) {
            findOptions.include = [{ model: Db.models.group, include: [Db.models.accessRight] }];
        }
        return this.model.findOne(findOptions);
    }
    /**
     * Return a user instance matching the username or the email.
     *
     * @param {string}  usernameOrEmail Username or email of the user
     * @param {boolean} [withGroups]    Whether to include groups and access rights
     * @returns {Bluebird<UserInstance | null>}
     * @private
     */
    _getUserInstanceByUsernameOrEmail(usernameOrEmail, withGroups) {
        const findOptions = {
            where: {
                $or: [
                    {
                        email: {
                            $like: usernameOrEmail
                        }
                    },
                    {
                        username: {
                            $like: usernameOrEmail
                        }
                    }
                ]
            }
        };
        return this._getUserByFindOptions(findOptions, withGroups);
    }
    /**
     * Return a user instance matching the username.
     *
     * @param {string}  username     Username of the user
     * @param {boolean} [withGroups] Whether to include groups and access rights
     * @returns {Bluebird<UserInstance | null>}
     * @private
     */
    _getUserInstanceByUsername(username, withGroups) {
        const findOptions = {
            where: {
                username: {
                    $like: username
                }
            }
        };
        return this._getUserByFindOptions(findOptions, withGroups);
    }
    /**
     * Return a user instance matching the email.
     *
     * @param {string}  email        Email of the user
     * @param {boolean} [withGroups] Whether to include groups and access rights
     * @returns {Bluebird<UserInstance | null>}
     */
    getUserInstanceByEmail(email, withGroups) {
        const findOptions = {
            where: {
                email: {
                    $like: email
                }
            }
        };
        return this._getUserByFindOptions(findOptions, withGroups);
    }
    /**
     * Return a user instance by id. Return a rejected promise if the user wasn't found.
     *
     * @param {number}  userId
     * @param {boolean} [withGroups] Whether to include groups and access rights
     * @returns {Bluebird<UserInstance>}
     * @private
     */
    _getUserInstance(userId, withGroups) {
        const findOptions = { where: { id: userId } };
        if (withGroups) {
            findOptions.include = [{ model: Db.models.group, include: [Db.models.accessRight] }];
        }
        return this.model.findOne(findOptions).then(user => {
            if (!user) {
                return Errors.business('user_not_found', 'Could not find user #' + userId + '.', true);
            }
            return user;
        });
    }
    /**
     * Given two Set<string> in input, return a compact representation:
     * - if something is writable is implicitly editable
     * - `*` means any string
     *
     * @param {object} rights
     * @returns {{edit: string[], write: string[]}}
     * @private
     */
    _compactUserAccessRights(rights) {
        let edit = rights.edit.has('*') ? ['*'] : Array.from(rights.edit);
        const write = rights.write.has('*') ? ['*'] : Array.from(rights.write);
        edit = _.difference(edit, write);
        return {
            edit: edit,
            write: write
        };
    }
    /**
     * Return `actions` and `accessRights` of a user given its `groups` populated with access rights.
     *
     * @param {PublicGroup[]} [groups]
     * @returns {{actions: object, accessRights: object}}
     * @private
     */
    _getUserActionsAndAccessRights(groups) {
        // Populate user.actions and user.accessRights. Initially as values we use Set<string> then we turn them into string[]
        /**@type {object}*/
        let actions = { '*': new Set() };
        const accessRights = {
            '*': {
                nodes: { edit: new Set(), write: new Set() },
                edges: { edit: new Set(), write: new Set() },
                alerts: { read: new Set() }
            }
        };
        _.forEach(groups, group => {
            const sourceKey = group.sourceKey;
            if (Utils.noValue(actions[sourceKey])) {
                actions[sourceKey] = new Set();
                accessRights[sourceKey] = {
                    nodes: { edit: new Set(), write: new Set() },
                    edges: { edit: new Set(), write: new Set() },
                    alerts: { read: new Set() }
                };
            }
            _.forEach(group.accessRights, accessRight => {
                if (accessRight.targetType === 'action' && accessRight.type === 'do') {
                    actions[sourceKey].add(accessRight.targetName);
                    // If any explicitly defined action is defined (e.g.: "rawReadQuery")
                    // we add the implicitly defined actions to the API response (e.g.: "runQuery")
                    const implicitActions = Actions.EXPLICIT_ACTIONS.get(accessRight.targetName) || [];
                    for (const implicitAction of implicitActions) {
                        actions[sourceKey].add(implicitAction);
                    }
                }
                else if (['edit', 'write'].includes(accessRight.type)) {
                    if (accessRight.targetType === 'nodeCategory') {
                        accessRights[sourceKey].nodes[accessRight.type].add(accessRight.targetName);
                    }
                    else if (accessRight.targetType === 'edgeType') {
                        accessRights[sourceKey].edges[accessRight.type].add(accessRight.targetName);
                    }
                }
                else if (accessRight.type === 'read' && accessRight.targetType === 'alert') {
                    accessRights[sourceKey].alerts.read.add(accessRight.targetName);
                }
            });
        });
        // we convert the Set<string> to string[]
        actions = _.mapValues(actions, s => Array.from(s));
        // for user.accessRights, we want a compact response (if something is writable is implicitly editable)
        _.forOwn(accessRights, (rights, sourceKey) => {
            accessRights[sourceKey] = {
                nodes: this._compactUserAccessRights(rights.nodes),
                edges: this._compactUserAccessRights(rights.edges),
                alerts: { read: rights.alerts.read.has('*') ? ['*'] : Array.from(rights.alerts.read) }
            };
        });
        return { actions: actions, accessRights: accessRights };
    }
    /**
     * In this function we do the following:
     * - we turn the userInstance into user public attributes
     * - if `userInstance.groups` is populated, format the groupInstances to public groups (without access rights)
     * - if `userInstance.groups[].accessRights` is populated, populate `actions` in the response
     *
     * A public user returned via the API doesn't have the access rights populated for the group.
     * However, we use the public user also to cache the user in the session server side.
     * In that case we populate the access rights but we don't expand them.
     *
     * @param {UserInstance} userInstance       User instance
     * @param {boolean}      [withVisCount]     Whether to populate the visCount
     * @param {boolean}      [withAccessRights] Whether to populate the access rights on groups (not expanded)
     * @returns {Bluebird<PublicUser>}
     */
    formatToPublicUser(userInstance, withVisCount, withAccessRights) {
        const user = /**@type {PublicUser}*/ (this.model.instanceToPublicAttributes(userInstance, true)); // user is a PublicUser only after user.actions is defined
        if (userInstance.id === this.model.GUEST_USER_ID) {
            // populate guest user preferences
            user.preferences = Config.get('guestPreferences');
        }
        else {
            // populate default user preferences
            user.preferences = _.defaults(user.preferences, Config.get('defaultPreferences'));
        }
        return Promise.resolve().then(() => {
            if (Utils.noValue(userInstance.groups)) {
                return;
            }
            return Promise.map(userInstance.groups, group => {
                // if `withAccessRights` is true, we want the access rights but not expanded
                return OldGroupDAO.formatToPublicGroup(group, {
                    withAccessRights: true,
                    expandRights: false
                });
            }).then(publicGroups => {
                user.groups = publicGroups;
            });
        }).then(() => {
            if (!withVisCount) {
                return;
            }
            return Db.models.visualization.count({ where: { userId: userInstance.id, sandbox: false } }).then(_visCount => {
                user.visCount = _visCount;
                return user;
            });
        }).then(() => {
            const actionsAndAccessRights = this._getUserActionsAndAccessRights(user.groups);
            user.actions = actionsAndAccessRights.actions;
            user.accessRights = actionsAndAccessRights.accessRights;
            // we filter the access rights if unwanted
            if (Utils.hasValue(user.groups) && !withAccessRights) {
                user.groups.forEach(group => {
                    delete group.accessRights;
                });
            }
        }).return(user);
    }
    /**
     * Return a public user by id. Return a rejected promise if the user wasn't found.
     *
     * @param {number}  userId
     * @param {boolean} [withAccessRights] Whether to populate the access rights on groups
     * @returns {Bluebird<PublicUser>} Public user with groups and actions
     */
    getUser(userId, withAccessRights) {
        return this._getUserInstance(userId, true).then(user => {
            return this.formatToPublicUser(user, false, withAccessRights);
        });
    }
    /**
     * Return a public user matching the email.
     * Return a rejected promise if the user wasn't found.
     *
     * @param {string}  email              Email of the user
     * @param {boolean} [withAccessRights] Whether to populate the access rights on groups
     * @returns {Bluebird<PublicUser>} Public user with groups and actions
     */
    getUserByEmail(email, withAccessRights) {
        return this.getUserInstanceByEmail(email, true).then(user => {
            if (!user) {
                return Errors.business('user_not_found', 'Could not find user with email: "' + email, true);
            }
            return this.formatToPublicUser(user, false, withAccessRights);
        });
    }
    /**
     * Find a "source=local" user in the database by username or email and check the password.
     * - If the user is not found, return a promise of 'null'.
     * - If the user is found but the passwords don't match, return a rejected promise of an LkError.
     * - If the user is found and the password matches, return a promise of the user.
     *
     * @param {string} usernameOrEmail Username or email of the user
     * @param {string} password        Password of a user
     * @returns {Bluebird<PublicUser>} Public user with groups and actions
     */
    getLocalUserByUsernameAndPassword(usernameOrEmail, password) {
        return this._getUserInstanceByUsernameOrEmail(usernameOrEmail, true).then(user => {
            // no user found, just return null
            if (!user || user.source !== 'local') {
                return null;
            }
            // found a local user, check password
            if (user.comparePassword(password)) {
                return this.formatToPublicUser(user);
            }
            return Errors.access('unauthorized', 'Incorrect username/email or password.', true);
        });
    }
    /**
     * Find users by username, email and groupId.
     * Never return the unique user.
     *
     * @param {object} [options]
     * @param {string} [options.startsWith]    Return only users which username or e-mail starts with this
     * @param {string} [options.contains]      Return only users which username or e-mail contains this
     * @param {number} [options.groupId]       Return only users belongings to this group
     * @param {number} [options.offset]        Offset from the first result
     * @param {number} [options.limit]         Page size (maximum number of returned users)
     * @param {string} [options.sortBy]        Sort by id, username, e-mail
     * @param {string} [options.sortDirection] Direction used to sort the users
     * @returns {Bluebird<{found: number, results: PublicUser[]}>}
     */
    findUsers(options) {
        if (Utils.noValue(options)) {
            options = {};
        }
        if (Utils.noValue(options.offset)) {
            options.offset = 0;
        }
        else {
            Utils.check.posInt('offset', options.offset);
        }
        if (Utils.noValue(options.limit)) {
            options.limit = 10;
        }
        else {
            Utils.check.integer('limit', options.limit, 1);
        }
        if (Utils.noValue(options.sortBy)) {
            options.sortBy = 'id';
        }
        else {
            Utils.check.values('sort_by', options.sortBy, ['id', 'username', 'email']);
        }
        if (Utils.noValue(options.sortDirection)) {
            options.sortDirection = 'asc';
        }
        else {
            Utils.check.values('sort_direction', options.sortDirection, ['asc', 'desc']);
        }
        if (Utils.hasValue(options.startsWith) && Utils.hasValue(options.contains)) {
            return Errors.business('conflict_parameter', '"options.starts_with" and "options.contains" can\'t be specified at the same time.', true);
        }
        let orderOptions;
        if (options.sortBy === 'id') {
            orderOptions = [['id', options.sortDirection]];
        }
        else {
            orderOptions = [[options.sortBy, options.sortDirection], ['id', 'desc']];
        }
        let sqlMatcher;
        if (Utils.hasValue(options.startsWith)) {
            // fix for sql injection
            options.startsWith = options.startsWith.replace(/[^A-Za-z0-9 @_\-.]/g, '');
            sqlMatcher = `${options.startsWith}%`;
        }
        if (Utils.hasValue(options.contains)) {
            options.contains = options.contains.replace(/[^A-Za-z0-9 @_\-.]/g, '');
            sqlMatcher = `%${options.contains}%`;
        }
        sqlMatcher = Utils.hasValue(sqlMatcher) ? sqlMatcher : '%';
        // we never want to return the unique user
        const omittedUserIds = [this.model.UNIQUE_USER_ID];
        if (!Config.get('access.guestMode')) {
            // and we don't want to return the guest user if guest mode is not enabled
            omittedUserIds.push(this.model.GUEST_USER_ID);
        }
        const query = {
            where: {
                id: { '$notIn': omittedUserIds },
                '$or': [
                    ['username like ?', sqlMatcher],
                    ['email like ?', sqlMatcher]
                ]
            },
            order: orderOptions,
            include: [{ model: Db.models.group, include: [Db.models.accessRight] }],
            distinct: true
        };
        if (Utils.hasValue(options.groupId)) {
            // if groupId is defined, only return users in that particular group
            Utils.check.posInt('options.groupId', options.groupId);
            query.include[0].where = { id: options.groupId };
            query.include[0].duplicating = false;
        }
        // 1) Count the number of total matching users
        let totalFoundUsers = 0;
        return Db.models.user.count(query).then(_totalFoundUsers => {
            totalFoundUsers = _totalFoundUsers;
            // https://github.com/sequelize/sequelize/issues/3007
            // TODO in Sequelize pagination with include doesn't work
            //
            // query.offset = options.offset;
            // query.limit = options.limit;
            return Db.models.user.findAll(query);
        }).then(users => {
            return users.splice(options.offset, options.limit);
        }).map(user => {
            return this.formatToPublicUser(user, true);
        }).then(users => {
            return { found: totalFoundUsers, results: users };
        });
    }
    /**
     * Check the username.
     *
     * @param {string} username
     * @private
     */
    _checkUsername(username) {
        Utils.check.string('username', username, true, false, 3, 100);
    }
    /**
     * Check the email.
     *
     * @param {string} email
     * @private
     */
    _checkEmail(email) {
        Utils.check.string('email', email, true, true, 3, 100); // email cannot contain space
    }
    /**
     * Check the password to see if it complies with our password policy.
     *
     * @param {string} password
     * @private
     */
    _checkPasswordPolicy(password) {
        Utils.check.string('password', password);
        if (password.length < MIN_PASSWORD_LENGTH) {
            throw Errors.business('invalid_parameter', 'Password must be longer than ' + MIN_PASSWORD_LENGTH + ' characters.');
        }
    }
    /**
     * Throw an LkError if in `groupInstances` there is more than 1 builtin group per data-source.
     *
     * @param {GroupInstance[]} groupInstances
     * @throws {LkError}
     * @private
     */
    _checkBuiltinGroups(groupInstances) {
        const builtinGroups = _.filter(groupInstances, group => group.builtin);
        const seen = new Set();
        for (let i = 0; i < builtinGroups.length; ++i) {
            const sourceKey = builtinGroups[i].sourceKey;
            if (seen.has(sourceKey) || seen.has('*') || (sourceKey === '*' && seen.size > 0)) {
                throw Errors.access('invalid_parameter', 'It\'s not allowed to have a user with more than one builtin group per data-source.');
            }
            seen.add(sourceKey);
        }
    }
    /**
     * Create a new user.
     *
     * @param {string}        username      The desired username for the new user
     * @param {string}        email         The desired email for the new user
     * @param {string | null} password      The desired password for the new user
     * @param {number[]}      groupIds      List of desired group ids
     * @param {string}        source        Source of the user ('local', 'ldap', 'oauth', etc.)
     * @param {WrappedUser}   [currentUser] Current user
     * @returns {Bluebird<PublicUser>} Public user with groups and actions
     */
    createUser(username, email, password, groupIds, source, currentUser) {
        if (Utils.noValue(username) || Utils.noValue(email) ||
            ((source === 'local') && Utils.noValue(password))) {
            return Errors.business('missing_field', 'Username, email and password are required', true);
        }
        groupIds = Utils.noValue(groupIds) ? [] : groupIds;
        this._checkUsername(username);
        // email is also validated by Sequelize
        this._checkEmail(email);
        Utils.check.array('groupIds', groupIds);
        if (source === 'local') {
            this._checkPasswordPolicy(password);
        }
        else {
            // We don't store the password for strategies other than 'local'
            password = '-';
            if (groupIds.length === 0) {
                // if we don't have any particular group for this user
                // we set the default group for external user to it
                const externalUserDefaultGroupId = Config.get('access.externalUserDefaultGroupId');
                if (Utils.hasValue(externalUserDefaultGroupId)) {
                    if (Array.isArray(externalUserDefaultGroupId)) {
                        groupIds = externalUserDefaultGroupId;
                    }
                    else {
                        groupIds = [externalUserDefaultGroupId];
                    }
                }
            }
        }
        return this._getUserInstanceByUsername(username).then(existingUser => {
            if (existingUser) {
                return Errors.business('user_exists', 'This username is already used.', true);
            }
            return this.getUserInstanceByEmail(email);
        }).then(existingUser => {
            if (existingUser) {
                return Errors.business('user_exists', 'This email is already used.', true);
            }
            return OldGroupDAO.getGroupInstances(groupIds, true);
        }).map(group => {
            // for each group we want to add to the new user
            // we check that the current user, if defined, can manage it
            if (Utils.hasValue(currentUser)) {
                return currentUser.canManageUsers(group.sourceKey).return(group);
            }
            return group;
        }).then(groupInstances => {
            if (groupInstances.length !== groupIds.length) {
                return Errors.business('invalid_parameter', 'Unknown group specified while creating user.', true);
            }
            this._checkBuiltinGroups(groupInstances);
            return this.model.create({
                username: username, email: email, password: password, source: source
            }).catch(err => {
                // handle email validation error from Sequelize
                if (err.name === 'SequelizeValidationError' && err.errors[0].path === 'email') {
                    return Errors.business('email_format', null, true);
                }
                else {
                    return Promise.reject(err);
                }
            }).then(newUserInstance => {
                return Promise.resolve(newUserInstance.setGroups(groupInstances)).then(() => {
                    newUserInstance.groups = groupInstances;
                    return this.formatToPublicUser(newUserInstance);
                });
            });
        });
    }
    /**
     * Given some user preferences and new preferences to apply:
     * - merge the new preferences into the user preferences
     * - remove all the preferences with the default value
     *
     * By doing so, every preference that has the default value is automatically
     * updated when the default preferences are updated.
     *
     * @param {UserPreferences} preferences
     * @param {UserPreferences} newPreferences
     * @returns {UserPreferences}
     * @private
     */
    _setUserPreferences(preferences, newPreferences) {
        const defaultPreferences = Config.get('defaultPreferences');
        let result = _.defaults(newPreferences, preferences);
        result = _.pickBy(result, (value, key) => {
            return defaultPreferences[key] !== value;
        });
        return result;
    }
    /**
     * Update an existing user.
     * No user can edit its own groups.
     *
     * @param {number}               userId      ID of the user to update
     * @param {UserUpdateAttributes} userUpdate  User fields to update
     * @param {WrappedUser}          currentUser Current user
     * @returns {Bluebird<PublicUser>}
     */
    updateUser(userId, userUpdate, currentUser) {
        Utils.check.property('user', userUpdate, {
            required: true,
            properties: {
                username: { check: (key, value) => { return this._checkUsername(value); } },
                password: { check: (key, value) => { return this._checkPasswordPolicy(value); } },
                // email is also validated by Sequelize
                email: { check: (key, value) => { return this._checkEmail(value); } },
                preferences: {
                    properties: {
                        pinOnDrag: { type: 'boolean' },
                        incrementalLayout: { type: 'boolean' },
                        locale: { check: (key, value) => {
                                Utils.check.string(key, value, true, true, 5, 5); // valid example: "en-US"
                                // if 3rd character is not '-' throw an error
                                if (value[2] !== '-') {
                                    throw Errors.business('invalid_parameter', `"${key}" must be a valid locale.`);
                                }
                            } }
                    }
                },
                addedGroups: { arrayItem: { check: 'number' } },
                removedGroups: { arrayItem: { check: 'number' } }
            },
            policy: 'strictExist' // at least one property defined
        });
        return Promise.resolve().then(() => {
            if (Utils.noValue(userUpdate.email)) {
                return;
            }
            // check if the new email is already used
            return this.getUserInstanceByEmail(userUpdate.email).then(userInstance => {
                if (Utils.hasValue(userInstance) && userInstance.id !== userId) {
                    return Errors.business('user_exists', 'This email is already used.', true);
                }
            });
        }).then(() => {
            if (Utils.noValue(userUpdate.username)) {
                return;
            }
            // check if the new username is already used
            return this._getUserInstanceByUsername(userUpdate.username).then(userInstance => {
                if (Utils.hasValue(userInstance) && userInstance.id !== userId) {
                    return Errors.business('user_exists', 'This username is already used.', true);
                }
            });
        }).then(() => {
            return this._getUserInstance(userId, true);
        }).then(userInstance => {
            // if the user is the unique use we can only update the preferences
            if (userInstance.id === this.model.UNIQUE_USER_ID) {
                // list new properties that have a value
                const changed = _.keys(_.pickBy(userUpdate, v => Utils.hasValue(v)));
                if (changed.length !== 1 || changed[0] !== 'preferences') {
                    return Errors.access('forbidden', 'You can only update "preferences" for the unique user.', true);
                }
            }
            // if the user is the guest user we can only modify the groups
            if (userInstance.id === this.model.GUEST_USER_ID) {
                const changed = _.keys(_.pickBy(userUpdate, v => Utils.hasValue(v)));
                if (_.difference(changed, ['addedGroups', 'removedGroups']).length > 0) {
                    return Errors.access('forbidden', 'You can only update the groups for the guest user.', true);
                }
            }
            // if the user is not local we cannot modify username, password and email
            if (userInstance.source !== 'local' && (Utils.hasValue(userUpdate.username) ||
                Utils.hasValue(userUpdate.password) ||
                Utils.hasValue(userUpdate.email))) {
                return Errors.business('not_implemented', 'Cannot edit "username", "email" or "password" of non local user.', true);
            }
            if (Utils.hasValue(userUpdate.username)) {
                userInstance.username = userUpdate.username;
            }
            if (Utils.hasValue(userUpdate.password)) {
                userInstance.password = userUpdate.password;
            }
            if (Utils.hasValue(userUpdate.email)) {
                userInstance.email = userUpdate.email;
            }
            if (Utils.hasValue(userUpdate.preferences)) {
                userInstance.preferences = this._setUserPreferences(userInstance.preferences, userUpdate.preferences);
            }
            return Promise.resolve().then(() => {
                // No group specified, don't touch groups
                if (Utils.noValue(userUpdate.addedGroups) && Utils.noValue(userUpdate.removedGroups)) {
                    UserCache.removeFromCache(userId);
                    return userInstance.save();
                }
                // if the user is not local and `autoRefreshGroupMapping` is true we cannot modify the groups
                const autoRefreshGroupMapping = Config.get('access.autoRefreshGroupMapping', false);
                if (userInstance.source !== 'local' && autoRefreshGroupMapping) {
                    return Errors.business('feature_disabled', 'Cannot edit "groups" of a external user when "access.autoRefreshGroupMapping" ' +
                        'is enabled', true);
                }
                // default to empty arrays
                userUpdate.addedGroups = Utils.hasValue(userUpdate.addedGroups)
                    ? userUpdate.addedGroups : [];
                userUpdate.removedGroups = Utils.hasValue(userUpdate.removedGroups)
                    ? userUpdate.removedGroups : [];
                if (userInstance.id === currentUser.id) {
                    return Errors.access('forbidden', 'No user can edit its own groups.', true);
                }
                const unionGroups = _.union(userUpdate.addedGroups, userUpdate.removedGroups);
                // check if some group ids are both in addedGroups and removedGroups
                if (unionGroups.length < userUpdate.addedGroups.length + userUpdate.removedGroups.length) {
                    return Errors.business('invalid_parameter', 'You can\'t add and remove a group at the same time.', true);
                }
                // check that no group to add is already in userInstance
                const alreadyPresentGroups = _.intersection(_.map(userInstance.groups, 'id'), userUpdate.addedGroups);
                if (alreadyPresentGroups.length > 0) {
                    return Errors.business('invalid_parameter', 'You can\'t add a group already present to a user. IDs: ' +
                        alreadyPresentGroups.join(', '), true);
                }
                // check that all the group to remove are in userInstance
                const notPresentGroups = _.difference(userUpdate.removedGroups, _.map(userInstance.groups, 'id'));
                if (notPresentGroups.length > 0) {
                    return Errors.business('invalid_parameter', 'You can\'t remove a group not present from a user. IDs: ' +
                        notPresentGroups.join(', '), true);
                }
                // for each group to add and remove
                return OldGroupDAO.getGroupInstances(unionGroups, true).map(group => {
                    // we check that the user is authorized to do so
                    return currentUser.canManageUsers(group.sourceKey).return(group);
                }).then(groupInstances => {
                    const [addGroupInstances, rmGroupInstances] = _.partition(groupInstances, g => userUpdate.addedGroups.includes(g.id));
                    userInstance.groups = _.unionBy(userInstance.groups, addGroupInstances, 'id');
                    userInstance.groups = _.differenceBy(userInstance.groups, rmGroupInstances, 'id');
                    // check that the user wouldn't end up with more than 1 builtin group per data-source
                    this._checkBuiltinGroups(userInstance.groups);
                    return userInstance.setGroups(userInstance.groups);
                }).then(() => {
                    UserCache.removeFromCache(userId);
                    return userInstance.save();
                });
            }).then(() => {
                return this.formatToPublicUser(userInstance);
            });
        }).catch(err => {
            // handle email validation error from Sequelize
            if (err.name === 'SequelizeValidationError' && err.errors[0].path === 'email') {
                return Errors.business('email_format', null, true);
            }
            else {
                return Promise.reject(err);
            }
        });
    }
    /**
     * Delete a user and everything it owns.
     *
     * @param {number}      userId      ID of the user to delete
     * @param {WrappedUser} currentUser Current user
     * @returns {Bluebird<void>}
     */
    deleteUser(userId, currentUser) {
        if (userId === this.model.UNIQUE_USER_ID || userId === this.model.GUEST_USER_ID) {
            return Errors.business('invalid_parameter', 'You cannot delete builtin users.', true);
        }
        if (userId === currentUser.id) {
            return Errors.business('invalid_parameter', 'You cannot delete yourself.', true);
        }
        return Db.models.visualizationShare.destroy({ where: { userId: userId } }).then(() => {
            return Db.models.graphQuery.destroy({ where: { userId: userId } });
        }).then(() => {
            return Db.models.widget.destroy({ where: { userId: userId } });
        }).then(() => {
            return Db.models.visualization.destroy({ where: { userId: userId } });
        }).then(() => {
            return Db.models.visualizationFolder.destroy({ where: { userId: userId } });
        }).then(() => {
            UserCache.removeFromCache(userId);
            return Db.models.user.destroy({ where: { id: userId } });
        }).return();
    }
    /**
     * Transfer all the visualizations from a source user to a target user
     *
     * @param [options.from] ID of the source user
     * @param [options.to]   ID of the target user
     * @returns {Promise<void>}
     */
    async mergeVisualizations(options) {
        Utils.check.properties('options', options, {
            from: { required: true, check: 'posInt' },
            to: { required: true, check: 'posInt' }
        });
        const baseOptions = {
            // update only the userId attribute
            fields: ['userId'],
            // don't validate
            validate: false,
            // don't update the 'updatedAt' field
            silent: true
        };
        const updateVisualizationsOptions = _.defaults({ where: {
                userId: options.from,
                // we don't migrate the sandbox
                sandbox: false
            } }, baseOptions);
        await Db.models.visualization.update({ userId: options.to }, updateVisualizationsOptions);
        const updateVisualizationFoldersOptions = _.defaults({ where: {
                userId: options.from
            } }, baseOptions);
        await Db.models.visualizationFolder.update({ userId: options.to }, updateVisualizationFoldersOptions);
    }
}
module.exports = new UserDAO();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiVXNlckRBTy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9zZXJ2aWNlcy9hY2Nlc3MvVXNlckRBTy5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7R0FLRztBQUNILFlBQVksQ0FBQztBQUNiLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM1QixNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDcEMsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ2hDLE1BQU0sRUFBRSxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUMxQixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLFdBQVcsR0FBRyxHQUFHLENBQUMsY0FBYyxFQUFFLENBQUM7QUFDekMsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQ3JDLE1BQU0sU0FBUyxHQUFHLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUV6QyxNQUFNLG1CQUFtQixHQUFHLENBQUMsQ0FBQztBQUU5QixNQUFNLE9BQU87SUFDWDs7T0FFRztJQUNILElBQUksS0FBSztRQUNQLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7SUFDeEIsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gscUJBQXFCLENBQUMsV0FBVyxFQUFFLFVBQVU7UUFDM0MsSUFBSSxVQUFVLEVBQUU7WUFDZCxXQUFXLENBQUMsT0FBTyxHQUFHLENBQUMsRUFBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsRUFBQyxDQUFDLENBQUM7U0FDcEY7UUFFRCxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsaUNBQWlDLENBQUMsZUFBZSxFQUFFLFVBQVU7UUFDM0QsTUFBTSxXQUFXLEdBQUc7WUFDbEIsS0FBSyxFQUFFO2dCQUNMLEdBQUcsRUFBRTtvQkFDSDt3QkFDRSxLQUFLLEVBQUU7NEJBQ0wsS0FBSyxFQUFFLGVBQWU7eUJBQ3ZCO3FCQUNGO29CQUNEO3dCQUNFLFFBQVEsRUFBRTs0QkFDUixLQUFLLEVBQUUsZUFBZTt5QkFDdkI7cUJBQ0Y7aUJBQ0Y7YUFDRjtTQUNGLENBQUM7UUFFRixPQUFPLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxXQUFXLEVBQUUsVUFBVSxDQUFDLENBQUM7SUFDN0QsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCwwQkFBMEIsQ0FBQyxRQUFRLEVBQUUsVUFBVTtRQUM3QyxNQUFNLFdBQVcsR0FBRztZQUNsQixLQUFLLEVBQUU7Z0JBQ0wsUUFBUSxFQUFFO29CQUNSLEtBQUssRUFBRSxRQUFRO2lCQUNoQjthQUNGO1NBQ0YsQ0FBQztRQUVGLE9BQU8sSUFBSSxDQUFDLHFCQUFxQixDQUFDLFdBQVcsRUFBRSxVQUFVLENBQUMsQ0FBQztJQUM3RCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsc0JBQXNCLENBQUMsS0FBSyxFQUFFLFVBQVU7UUFDdEMsTUFBTSxXQUFXLEdBQUc7WUFDbEIsS0FBSyxFQUFFO2dCQUNMLEtBQUssRUFBRTtvQkFDTCxLQUFLLEVBQUUsS0FBSztpQkFDYjthQUNGO1NBQ0YsQ0FBQztRQUVGLE9BQU8sSUFBSSxDQUFDLHFCQUFxQixDQUFDLFdBQVcsRUFBRSxVQUFVLENBQUMsQ0FBQztJQUM3RCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILGdCQUFnQixDQUFDLE1BQU0sRUFBRSxVQUFVO1FBQ2pDLE1BQU0sV0FBVyxHQUFHLEVBQUMsS0FBSyxFQUFFLEVBQUMsRUFBRSxFQUFFLE1BQU0sRUFBQyxFQUFDLENBQUM7UUFFMUMsSUFBSSxVQUFVLEVBQUU7WUFDZCxXQUFXLENBQUMsT0FBTyxHQUFHLENBQUMsRUFBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsRUFBQyxDQUFDLENBQUM7U0FDcEY7UUFFRCxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNqRCxJQUFJLENBQUMsSUFBSSxFQUFFO2dCQUNULE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsRUFBRSx1QkFBdUIsR0FBRyxNQUFNLEdBQUcsR0FBRyxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQ3hGO1lBQ0QsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILHdCQUF3QixDQUFDLE1BQU07UUFDN0IsSUFBSSxJQUFJLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ2xFLE1BQU0sS0FBSyxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUV2RSxJQUFJLEdBQUcsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFakMsT0FBTztZQUNMLElBQUksRUFBRSxJQUFJO1lBQ1YsS0FBSyxFQUFFLEtBQUs7U0FDYixDQUFDO0lBQ0osQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILDhCQUE4QixDQUFDLE1BQU07UUFDbkMsc0hBQXNIO1FBQ3RILG1CQUFtQjtRQUNuQixJQUFJLE9BQU8sR0FBRyxFQUFDLEdBQUcsRUFBRSxJQUFJLEdBQUcsRUFBRSxFQUFDLENBQUM7UUFDL0IsTUFBTSxZQUFZLEdBQUc7WUFDbkIsR0FBRyxFQUFFO2dCQUNILEtBQUssRUFBRSxFQUFDLElBQUksRUFBRSxJQUFJLEdBQUcsRUFBRSxFQUFFLEtBQUssRUFBRSxJQUFJLEdBQUcsRUFBRSxFQUFDO2dCQUMxQyxLQUFLLEVBQUUsRUFBQyxJQUFJLEVBQUUsSUFBSSxHQUFHLEVBQUUsRUFBRSxLQUFLLEVBQUUsSUFBSSxHQUFHLEVBQUUsRUFBQztnQkFDMUMsTUFBTSxFQUFFLEVBQUMsSUFBSSxFQUFFLElBQUksR0FBRyxFQUFFLEVBQUM7YUFDMUI7U0FDRixDQUFDO1FBQ0YsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLEVBQUU7WUFDeEIsTUFBTSxTQUFTLEdBQUcsS0FBSyxDQUFDLFNBQVMsQ0FBQztZQUVsQyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUU7Z0JBQ3JDLE9BQU8sQ0FBQyxTQUFTLENBQUMsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDO2dCQUMvQixZQUFZLENBQUMsU0FBUyxDQUFDLEdBQUc7b0JBQ3hCLEtBQUssRUFBRSxFQUFDLElBQUksRUFBRSxJQUFJLEdBQUcsRUFBRSxFQUFFLEtBQUssRUFBRSxJQUFJLEdBQUcsRUFBRSxFQUFDO29CQUMxQyxLQUFLLEVBQUUsRUFBQyxJQUFJLEVBQUUsSUFBSSxHQUFHLEVBQUUsRUFBRSxLQUFLLEVBQUUsSUFBSSxHQUFHLEVBQUUsRUFBQztvQkFDMUMsTUFBTSxFQUFFLEVBQUMsSUFBSSxFQUFFLElBQUksR0FBRyxFQUFFLEVBQUM7aUJBQzFCLENBQUM7YUFDSDtZQUVELENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLFlBQVksRUFBRSxXQUFXLENBQUMsRUFBRTtnQkFDMUMsSUFBSSxXQUFXLENBQUMsVUFBVSxLQUFLLFFBQVEsSUFBSSxXQUFXLENBQUMsSUFBSSxLQUFLLElBQUksRUFBRTtvQkFDcEUsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDLENBQUM7b0JBQy9DLHFFQUFxRTtvQkFDckUsK0VBQStFO29CQUMvRSxNQUFNLGVBQWUsR0FBRyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ25GLEtBQUssTUFBTSxjQUFjLElBQUksZUFBZSxFQUFFO3dCQUM1QyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxDQUFDO3FCQUN4QztpQkFDRjtxQkFBTSxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLEVBQUU7b0JBQ3ZELElBQUksV0FBVyxDQUFDLFVBQVUsS0FBSyxjQUFjLEVBQUU7d0JBQzdDLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDLENBQUM7cUJBQzdFO3lCQUFNLElBQUksV0FBVyxDQUFDLFVBQVUsS0FBSyxVQUFVLEVBQUU7d0JBQ2hELFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDLENBQUM7cUJBQzdFO2lCQUNGO3FCQUFNLElBQUksV0FBVyxDQUFDLElBQUksS0FBSyxNQUFNLElBQUksV0FBVyxDQUFDLFVBQVUsS0FBSyxPQUFPLEVBQUU7b0JBQzVFLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDLENBQUM7aUJBQ2pFO1lBQ0gsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUVILHlDQUF5QztRQUN6QyxPQUFPLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFbkQsc0dBQXNHO1FBQ3RHLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBWSxFQUFFLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFO1lBQzNDLFlBQVksQ0FBQyxTQUFTLENBQUMsR0FBRztnQkFDeEIsS0FBSyxFQUFFLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO2dCQUNsRCxLQUFLLEVBQUUsSUFBSSxDQUFDLHdCQUF3QixDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7Z0JBQ2xELE1BQU0sRUFBRSxFQUFDLElBQUksRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBQzthQUNyRixDQUFDO1FBQ0osQ0FBQyxDQUFDLENBQUM7UUFFSCxPQUFPLEVBQUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxZQUFZLEVBQUUsWUFBWSxFQUFDLENBQUM7SUFDeEQsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7OztPQWNHO0lBQ0gsa0JBQWtCLENBQUMsWUFBWSxFQUFFLFlBQVksRUFBRSxnQkFBZ0I7UUFDN0QsTUFBTSxJQUFJLEdBQUcsdUJBQXVCLENBQUMsQ0FDbkMsSUFBSSxDQUFDLEtBQUssQ0FBQywwQkFBMEIsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLENBQzFELENBQUMsQ0FBQywwREFBMEQ7UUFFN0QsSUFBSSxZQUFZLENBQUMsRUFBRSxLQUFLLElBQUksQ0FBQyxLQUFLLENBQUMsYUFBYSxFQUFFO1lBQ2hELGtDQUFrQztZQUNsQyxJQUFJLENBQUMsV0FBVyxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUMsQ0FBQztTQUNuRDthQUFNO1lBQ0wsb0NBQW9DO1lBQ3BDLElBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLE1BQU0sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDO1NBQ25GO1FBRUQsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNqQyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxFQUFFO2dCQUN0QyxPQUFPO2FBQ1I7WUFFRCxPQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsRUFBRTtnQkFDOUMsNEVBQTRFO2dCQUM1RSxPQUFPLFdBQVcsQ0FBQyxtQkFBbUIsQ0FDcEMsS0FBSyxFQUFFO29CQUNMLGdCQUFnQixFQUFFLElBQUk7b0JBQ3RCLFlBQVksRUFBRSxLQUFLO2lCQUNwQixDQUFDLENBQUM7WUFDUCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUU7Z0JBQ3JCLElBQUksQ0FBQyxNQUFNLEdBQUcsWUFBWSxDQUFDO1lBQzdCLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNYLElBQUksQ0FBQyxZQUFZLEVBQUU7Z0JBQ2pCLE9BQU87YUFDUjtZQUVELE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUNsQyxFQUFDLEtBQUssRUFBRSxFQUFDLE1BQU0sRUFBRSxZQUFZLENBQUMsRUFBRSxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUMsRUFBQyxDQUNuRCxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRTtnQkFDakIsSUFBSSxDQUFDLFFBQVEsR0FBRyxTQUFTLENBQUM7Z0JBQzFCLE9BQU8sSUFBSSxDQUFDO1lBQ2QsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1gsTUFBTSxzQkFBc0IsR0FBRyxJQUFJLENBQUMsOEJBQThCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBRWhGLElBQUksQ0FBQyxPQUFPLEdBQUcsc0JBQXNCLENBQUMsT0FBTyxDQUFDO1lBQzlDLElBQUksQ0FBQyxZQUFZLEdBQUcsc0JBQXNCLENBQUMsWUFBWSxDQUFDO1lBRXhELDBDQUEwQztZQUMxQyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLEVBQUU7Z0JBQ3BELElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFO29CQUMxQixPQUFPLEtBQUssQ0FBQyxZQUFZLENBQUM7Z0JBQzVCLENBQUMsQ0FBQyxDQUFDO2FBQ0o7UUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDbEIsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILE9BQU8sQ0FBQyxNQUFNLEVBQUUsZ0JBQWdCO1FBQzlCLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDckQsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO1FBQ2hFLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxjQUFjLENBQUMsS0FBSyxFQUFFLGdCQUFnQjtRQUNwQyxPQUFPLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQzFELElBQUksQ0FBQyxJQUFJLEVBQUU7Z0JBQ1QsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLGdCQUFnQixFQUNyQyxtQ0FBbUMsR0FBRyxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDdEQ7WUFFRCxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLGdCQUFnQixDQUFDLENBQUM7UUFDaEUsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7OztPQVNHO0lBQ0gsaUNBQWlDLENBQUMsZUFBZSxFQUFFLFFBQVE7UUFDekQsT0FBTyxJQUFJLENBQUMsaUNBQWlDLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUMvRSxrQ0FBa0M7WUFDbEMsSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsTUFBTSxLQUFLLE9BQU8sRUFBRTtnQkFDcEMsT0FBTyxJQUFJLENBQUM7YUFDYjtZQUVELHFDQUFxQztZQUNyQyxJQUFJLElBQUksQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLEVBQUU7Z0JBQ2xDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3RDO1lBRUQsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDLGNBQWMsRUFBRSx1Q0FBdUMsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUN0RixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7OztPQWFHO0lBQ0gsU0FBUyxDQUFDLE9BQU87UUFDZixJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDMUIsT0FBTyxHQUFHLEVBQUUsQ0FBQztTQUNkO1FBRUQsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUNqQyxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztTQUNwQjthQUFNO1lBQ0wsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUM5QztRQUVELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDaEMsT0FBTyxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUM7U0FDcEI7YUFBTTtZQUNMLEtBQUssQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDO1NBQ2hEO1FBRUQsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUNqQyxPQUFPLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztTQUN2QjthQUFNO1lBQ0wsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxJQUFJLEVBQUUsVUFBVSxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUM7U0FDNUU7UUFFRCxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxFQUFFO1lBQ3hDLE9BQU8sQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO1NBQy9CO2FBQU07WUFDTCxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsRUFBRSxPQUFPLENBQUMsYUFBYSxFQUFFLENBQUMsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUM7U0FDOUU7UUFFRCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQzFFLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxvQkFBb0IsRUFDekMsb0ZBQW9GLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDL0Y7UUFFRCxJQUFJLFlBQVksQ0FBQztRQUNqQixJQUFJLE9BQU8sQ0FBQyxNQUFNLEtBQUssSUFBSSxFQUFFO1lBQzNCLFlBQVksR0FBRyxDQUFDLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDO1NBQ2hEO2FBQU07WUFDTCxZQUFZLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLGFBQWEsQ0FBQyxFQUFFLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUM7U0FDMUU7UUFFRCxJQUFJLFVBQVUsQ0FBQztRQUNmLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLEVBQUU7WUFDdEMsd0JBQXdCO1lBQ3hCLE9BQU8sQ0FBQyxVQUFVLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMscUJBQXFCLEVBQUUsRUFBRSxDQUFDLENBQUM7WUFDM0UsVUFBVSxHQUFHLEdBQUcsT0FBTyxDQUFDLFVBQVUsR0FBRyxDQUFDO1NBQ3ZDO1FBRUQsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUNwQyxPQUFPLENBQUMsUUFBUSxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLHFCQUFxQixFQUFFLEVBQUUsQ0FBQyxDQUFDO1lBQ3ZFLFVBQVUsR0FBRyxJQUFJLE9BQU8sQ0FBQyxRQUFRLEdBQUcsQ0FBQztTQUN0QztRQUNELFVBQVUsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztRQUUzRCwwQ0FBMEM7UUFDMUMsTUFBTSxjQUFjLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDO1FBRW5ELElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLEVBQUU7WUFDbkMsMEVBQTBFO1lBQzFFLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQztTQUMvQztRQUVELE1BQU0sS0FBSyxHQUFHO1lBQ1osS0FBSyxFQUFFO2dCQUNMLEVBQUUsRUFBRSxFQUFDLFFBQVEsRUFBRSxjQUFjLEVBQUM7Z0JBQzlCLEtBQUssRUFBRTtvQkFDTCxDQUFDLGlCQUFpQixFQUFFLFVBQVUsQ0FBQztvQkFDL0IsQ0FBQyxjQUFjLEVBQUUsVUFBVSxDQUFDO2lCQUM3QjthQUNGO1lBQ0QsS0FBSyxFQUFFLFlBQVk7WUFDbkIsT0FBTyxFQUFFLENBQUMsRUFBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsRUFBQyxDQUFDO1lBQ3JFLFFBQVEsRUFBRSxJQUFJO1NBQ2YsQ0FBQztRQUVGLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDbkMsb0VBQW9FO1lBQ3BFLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLGlCQUFpQixFQUFFLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUN2RCxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxFQUFDLEVBQUUsRUFBRSxPQUFPLENBQUMsT0FBTyxFQUFDLENBQUM7WUFDL0MsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDO1NBQ3RDO1FBRUQsOENBQThDO1FBQzlDLElBQUksZUFBZSxHQUFHLENBQUMsQ0FBQztRQUN4QixPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsRUFBRTtZQUN6RCxlQUFlLEdBQUcsZ0JBQWdCLENBQUM7WUFFbkMscURBQXFEO1lBQ3JELHlEQUF5RDtZQUN6RCxFQUFFO1lBQ0YsaUNBQWlDO1lBQ2pDLCtCQUErQjtZQUMvQixPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN2QyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDZCxPQUFPLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDckQsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ1osT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzdDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUNkLE9BQU8sRUFBQyxLQUFLLEVBQUUsZUFBZSxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUMsQ0FBQztRQUNsRCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILGNBQWMsQ0FBQyxRQUFRO1FBQ3JCLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDaEUsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsV0FBVyxDQUFDLEtBQUs7UUFDZixLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsNkJBQTZCO0lBQ3ZGLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILG9CQUFvQixDQUFDLFFBQVE7UUFDM0IsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1FBRXpDLElBQUksUUFBUSxDQUFDLE1BQU0sR0FBRyxtQkFBbUIsRUFBRTtZQUN6QyxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQ25CLG1CQUFtQixFQUFFLCtCQUErQixHQUFHLG1CQUFtQixHQUFHLGNBQWMsQ0FDNUYsQ0FBQztTQUNIO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILG1CQUFtQixDQUFDLGNBQWM7UUFDaEMsTUFBTSxhQUFhLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUUsS0FBSyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdkUsTUFBTSxJQUFJLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQztRQUV2QixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsYUFBYSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtZQUM3QyxNQUFNLFNBQVMsR0FBRyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO1lBQzdDLElBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxLQUFLLEdBQUcsSUFBSSxJQUFJLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQyxFQUFFO2dCQUNoRixNQUFNLE1BQU0sQ0FBQyxNQUFNLENBQUMsbUJBQW1CLEVBQ3JDLG9GQUFvRixDQUFDLENBQUM7YUFDekY7WUFFRCxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1NBQ3JCO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7Ozs7O09BVUc7SUFDSCxVQUFVLENBQUMsUUFBUSxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxXQUFXO1FBQ2pFLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztZQUNqRCxDQUFDLENBQUMsTUFBTSxLQUFLLE9BQU8sQ0FBQyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRTtZQUNuRCxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsZUFBZSxFQUFFLDJDQUEyQyxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQzVGO1FBRUQsUUFBUSxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO1FBRW5ELElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDOUIsdUNBQXVDO1FBQ3ZDLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFeEIsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1FBRXhDLElBQUksTUFBTSxLQUFLLE9BQU8sRUFBRTtZQUN0QixJQUFJLENBQUMsb0JBQW9CLENBQUMsUUFBUSxDQUFDLENBQUM7U0FDckM7YUFBTTtZQUNMLGdFQUFnRTtZQUNoRSxRQUFRLEdBQUcsR0FBRyxDQUFDO1lBRWYsSUFBSSxRQUFRLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtnQkFDekIsc0RBQXNEO2dCQUN0RCxtREFBbUQ7Z0JBQ25ELE1BQU0sMEJBQTBCLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxtQ0FBbUMsQ0FBQyxDQUFDO2dCQUNuRixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsMEJBQTBCLENBQUMsRUFBRTtvQkFDOUMsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLDBCQUEwQixDQUFDLEVBQUU7d0JBQzdDLFFBQVEsR0FBRywwQkFBMEIsQ0FBQztxQkFDdkM7eUJBQU07d0JBQ0wsUUFBUSxHQUFHLENBQUMsMEJBQTBCLENBQUMsQ0FBQztxQkFDekM7aUJBQ0Y7YUFDRjtTQUNGO1FBRUQsT0FBTyxJQUFJLENBQUMsMEJBQTBCLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFO1lBQ25FLElBQUksWUFBWSxFQUFFO2dCQUNoQixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsYUFBYSxFQUFFLGdDQUFnQyxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQy9FO1lBRUQsT0FBTyxJQUFJLENBQUMsc0JBQXNCLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDNUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFO1lBQ3JCLElBQUksWUFBWSxFQUFFO2dCQUNoQixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsYUFBYSxFQUFFLDZCQUE2QixFQUFFLElBQUksQ0FBQyxDQUFDO2FBQzVFO1lBRUQsT0FBTyxXQUFXLENBQUMsaUJBQWlCLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3ZELENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUNiLGdEQUFnRDtZQUNoRCw0REFBNEQ7WUFDNUQsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxFQUFFO2dCQUMvQixPQUFPLFdBQVcsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUNsRTtZQUVELE9BQU8sS0FBSyxDQUFDO1FBQ2YsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFO1lBQ3ZCLElBQUksY0FBYyxDQUFDLE1BQU0sS0FBSyxRQUFRLENBQUMsTUFBTSxFQUFFO2dCQUM3QyxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQ3BCLG1CQUFtQixFQUFFLDhDQUE4QyxFQUFFLElBQUksQ0FDMUUsQ0FBQzthQUNIO1lBRUQsSUFBSSxDQUFDLG1CQUFtQixDQUFDLGNBQWMsQ0FBQyxDQUFDO1lBRXpDLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUM7Z0JBQ3ZCLFFBQVEsRUFBRSxRQUFRLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxNQUFNO2FBQ3JFLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQ2IsK0NBQStDO2dCQUMvQyxJQUFJLEdBQUcsQ0FBQyxJQUFJLEtBQUssMEJBQTBCLElBQUksR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEtBQUssT0FBTyxFQUFFO29CQUM3RSxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsY0FBYyxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztpQkFDcEQ7cUJBQU07b0JBQ0wsT0FBTyxPQUFPLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2lCQUM1QjtZQUNILENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsRUFBRTtnQkFDeEIsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO29CQUMxRSxlQUFlLENBQUMsTUFBTSxHQUFHLGNBQWMsQ0FBQztvQkFFeEMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsZUFBZSxDQUFDLENBQUM7Z0JBQ2xELENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7O09BWUc7SUFDSCxtQkFBbUIsQ0FBQyxXQUFXLEVBQUUsY0FBYztRQUM3QyxNQUFNLGtCQUFrQixHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUMsQ0FBQztRQUM1RCxJQUFJLE1BQU0sR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLGNBQWMsRUFBRSxXQUFXLENBQUMsQ0FBQztRQUVyRCxNQUFNLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxLQUFLLEVBQUUsR0FBRyxFQUFFLEVBQUU7WUFDdkMsT0FBTyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsS0FBSyxLQUFLLENBQUM7UUFDM0MsQ0FBQyxDQUFDLENBQUM7UUFFSCxPQUFPLE1BQU0sQ0FBQztJQUNoQixDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSCxVQUFVLENBQUMsTUFBTSxFQUFFLFVBQVUsRUFBRSxXQUFXO1FBQ3hDLEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxVQUFVLEVBQUU7WUFDdkMsUUFBUSxFQUFFLElBQUk7WUFDZCxVQUFVLEVBQUU7Z0JBQ1YsUUFBUSxFQUFFLEVBQUMsS0FBSyxFQUFFLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRSxFQUFFLEdBQUcsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDO2dCQUN6RSxRQUFRLEVBQUUsRUFBQyxLQUFLLEVBQUUsQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFLEVBQUUsR0FBRyxPQUFPLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQztnQkFDL0UsdUNBQXVDO2dCQUN2QyxLQUFLLEVBQUUsRUFBQyxLQUFLLEVBQUUsQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFLEVBQUUsR0FBRyxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUM7Z0JBQ25FLFdBQVcsRUFBRTtvQkFDWCxVQUFVLEVBQUU7d0JBQ1YsU0FBUyxFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQzt3QkFDNUIsaUJBQWlCLEVBQUUsRUFBQyxJQUFJLEVBQUUsU0FBUyxFQUFDO3dCQUNwQyxNQUFNLEVBQUUsRUFBQyxLQUFLLEVBQUUsQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFLEVBQUU7Z0NBQzdCLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyx5QkFBeUI7Z0NBQzNFLDZDQUE2QztnQ0FDN0MsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxFQUFFO29DQUNwQixNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQUMsbUJBQW1CLEVBQUUsSUFBSSxHQUFHLDJCQUEyQixDQUFDLENBQUM7aUNBQ2hGOzRCQUNILENBQUMsRUFBQztxQkFDSDtpQkFDRjtnQkFDRCxXQUFXLEVBQUUsRUFBQyxTQUFTLEVBQUUsRUFBQyxLQUFLLEVBQUUsUUFBUSxFQUFDLEVBQUM7Z0JBQzNDLGFBQWEsRUFBRSxFQUFDLFNBQVMsRUFBRSxFQUFDLEtBQUssRUFBRSxRQUFRLEVBQUMsRUFBQzthQUM5QztZQUNELE1BQU0sRUFBRSxhQUFhLENBQUMsZ0NBQWdDO1NBQ3ZELENBQUMsQ0FBQztRQUVILE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDakMsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDbkMsT0FBTzthQUNSO1lBRUQseUNBQXlDO1lBQ3pDLE9BQU8sSUFBSSxDQUFDLHNCQUFzQixDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUU7Z0JBQ3ZFLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsSUFBSSxZQUFZLENBQUMsRUFBRSxLQUFLLE1BQU0sRUFBRTtvQkFDOUQsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLGFBQWEsRUFBRSw2QkFBNkIsRUFBRSxJQUFJLENBQUMsQ0FBQztpQkFDNUU7WUFDSCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxFQUFFO2dCQUN0QyxPQUFPO2FBQ1I7WUFFRCw0Q0FBNEM7WUFDNUMsT0FBTyxJQUFJLENBQUMsMEJBQTBCLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRTtnQkFDOUUsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxJQUFJLFlBQVksQ0FBQyxFQUFFLEtBQUssTUFBTSxFQUFFO29CQUM5RCxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsYUFBYSxFQUFFLGdDQUFnQyxFQUFFLElBQUksQ0FBQyxDQUFDO2lCQUMvRTtZQUNILENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNYLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztRQUM3QyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUU7WUFDckIsbUVBQW1FO1lBQ25FLElBQUksWUFBWSxDQUFDLEVBQUUsS0FBSyxJQUFJLENBQUMsS0FBSyxDQUFDLGNBQWMsRUFBRTtnQkFDakQsd0NBQXdDO2dCQUN4QyxNQUFNLE9BQU8sR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3JFLElBQUksT0FBTyxDQUFDLE1BQU0sS0FBSyxDQUFDLElBQUksT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFLLGFBQWEsRUFBRTtvQkFDeEQsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFDOUIsd0RBQXdELEVBQUUsSUFBSSxDQUFDLENBQUM7aUJBQ25FO2FBQ0Y7WUFFRCw4REFBOEQ7WUFDOUQsSUFBSSxZQUFZLENBQUMsRUFBRSxLQUFLLElBQUksQ0FBQyxLQUFLLENBQUMsYUFBYSxFQUFFO2dCQUNoRCxNQUFNLE9BQU8sR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3JFLElBQUksQ0FBQyxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxhQUFhLEVBQUUsZUFBZSxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO29CQUN0RSxPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUM5QixvREFBb0QsRUFBRSxJQUFJLENBQzNELENBQUM7aUJBQ0g7YUFDRjtZQUVELHlFQUF5RTtZQUN6RSxJQUFJLFlBQVksQ0FBQyxNQUFNLEtBQUssT0FBTyxJQUFJLENBQ3JDLEtBQUssQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQztnQkFDakMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDO2dCQUNuQyxLQUFLLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FDbkMsRUFBRTtnQkFDRCxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsaUJBQWlCLEVBQ3RDLGtFQUFrRSxFQUFFLElBQUksQ0FDekUsQ0FBQzthQUNIO1lBRUQsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsRUFBRTtnQkFDdkMsWUFBWSxDQUFDLFFBQVEsR0FBRyxVQUFVLENBQUMsUUFBUSxDQUFDO2FBQzdDO1lBQ0QsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsRUFBRTtnQkFDdkMsWUFBWSxDQUFDLFFBQVEsR0FBRyxVQUFVLENBQUMsUUFBUSxDQUFDO2FBQzdDO1lBQ0QsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDcEMsWUFBWSxDQUFDLEtBQUssR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDO2FBQ3ZDO1lBQ0QsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsRUFBRTtnQkFDMUMsWUFBWSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUMsWUFBWSxDQUFDLFdBQVcsRUFDMUUsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2FBQzNCO1lBRUQsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDakMseUNBQXlDO2dCQUN6QyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxFQUFFO29CQUNwRixTQUFTLENBQUMsZUFBZSxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUNsQyxPQUFPLFlBQVksQ0FBQyxJQUFJLEVBQUUsQ0FBQztpQkFDNUI7Z0JBRUQsNkZBQTZGO2dCQUM3RixNQUFNLHVCQUF1QixHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsZ0NBQWdDLEVBQUUsS0FBSyxDQUFDLENBQUM7Z0JBQ3BGLElBQUksWUFBWSxDQUFDLE1BQU0sS0FBSyxPQUFPLElBQUksdUJBQXVCLEVBQUU7b0JBQzlELE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxrQkFBa0IsRUFDdkMsZ0ZBQWdGO3dCQUNoRixZQUFZLEVBQUUsSUFBSSxDQUNuQixDQUFDO2lCQUNIO2dCQUVELDBCQUEwQjtnQkFDMUIsVUFBVSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUM7b0JBQzdELENBQUMsQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7Z0JBQ2hDLFVBQVUsQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDO29CQUNqRSxDQUFDLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO2dCQUVsQyxJQUFJLFlBQVksQ0FBQyxFQUFFLEtBQUssV0FBVyxDQUFDLEVBQUUsRUFBRTtvQkFDdEMsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBRSxrQ0FBa0MsRUFBRSxJQUFJLENBQUMsQ0FBQztpQkFDN0U7Z0JBRUQsTUFBTSxXQUFXLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLFVBQVUsQ0FBQyxhQUFhLENBQUMsQ0FBQztnQkFFOUUsb0VBQW9FO2dCQUNwRSxJQUFJLFdBQVcsQ0FBQyxNQUFNLEdBQUcsVUFBVSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEdBQUcsVUFBVSxDQUFDLGFBQWEsQ0FBQyxNQUFNLEVBQUU7b0JBQ3hGLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsRUFDeEMscURBQXFELEVBQUUsSUFBSSxDQUFDLENBQUM7aUJBQ2hFO2dCQUVELHdEQUF3RDtnQkFDeEQsTUFBTSxvQkFBb0IsR0FBRyxDQUFDLENBQUMsWUFBWSxDQUN6QyxDQUFDLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLEVBQUUsVUFBVSxDQUFDLFdBQVcsQ0FDekQsQ0FBQztnQkFDRixJQUFJLG9CQUFvQixDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7b0JBQ25DLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsRUFDeEMseURBQXlEO3dCQUN6RCxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7aUJBQzFDO2dCQUVELHlEQUF5RDtnQkFDekQsTUFBTSxnQkFBZ0IsR0FBRyxDQUFDLENBQUMsVUFBVSxDQUNuQyxVQUFVLENBQUMsYUFBYSxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FDM0QsQ0FBQztnQkFDRixJQUFJLGdCQUFnQixDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7b0JBQy9CLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsRUFDeEMsMERBQTBEO3dCQUMxRCxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7aUJBQ3RDO2dCQUVELG1DQUFtQztnQkFDbkMsT0FBTyxXQUFXLENBQUMsaUJBQWlCLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRTtvQkFDbEUsZ0RBQWdEO29CQUNoRCxPQUFPLFdBQVcsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDbkUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFO29CQUN2QixNQUFNLENBQUMsaUJBQWlCLEVBQUUsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLGNBQWMsRUFDdEUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztvQkFFOUMsWUFBWSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLENBQUM7b0JBQzlFLFlBQVksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLGdCQUFnQixFQUFFLElBQUksQ0FBQyxDQUFDO29CQUVsRixxRkFBcUY7b0JBQ3JGLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBRTlDLE9BQU8sWUFBWSxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQ3JELENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7b0JBQ1gsU0FBUyxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDbEMsT0FBTyxZQUFZLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQzdCLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDWCxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUMvQyxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUNiLCtDQUErQztZQUMvQyxJQUFJLEdBQUcsQ0FBQyxJQUFJLEtBQUssMEJBQTBCLElBQUksR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEtBQUssT0FBTyxFQUFFO2dCQUM3RSxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsY0FBYyxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQzthQUNwRDtpQkFBTTtnQkFDTCxPQUFPLE9BQU8sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7YUFDNUI7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxVQUFVLENBQUMsTUFBTSxFQUFFLFdBQVc7UUFDNUIsSUFBSSxNQUFNLEtBQUssSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLElBQUksTUFBTSxLQUFLLElBQUksQ0FBQyxLQUFLLENBQUMsYUFBYSxFQUFFO1lBQy9FLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsRUFBRSxrQ0FBa0MsRUFBRSxJQUFJLENBQUMsQ0FBQztTQUN2RjtRQUVELElBQUksTUFBTSxLQUFLLFdBQVcsQ0FBQyxFQUFFLEVBQUU7WUFDN0IsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLG1CQUFtQixFQUFFLDZCQUE2QixFQUFFLElBQUksQ0FBQyxDQUFDO1NBQ2xGO1FBRUQsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxFQUFDLEtBQUssRUFBRSxFQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUMsRUFBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUMvRSxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxFQUFDLEtBQUssRUFBRSxFQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUMsRUFBQyxDQUFDLENBQUM7UUFDakUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNYLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEVBQUMsS0FBSyxFQUFFLEVBQUMsTUFBTSxFQUFFLE1BQU0sRUFBQyxFQUFDLENBQUMsQ0FBQztRQUM3RCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1gsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsRUFBQyxLQUFLLEVBQUUsRUFBQyxNQUFNLEVBQUUsTUFBTSxFQUFDLEVBQUMsQ0FBQyxDQUFDO1FBQ3BFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsT0FBTyxDQUFDLEVBQUMsS0FBSyxFQUFFLEVBQUMsTUFBTSxFQUFFLE1BQU0sRUFBQyxFQUFDLENBQUMsQ0FBQztRQUMxRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1gsU0FBUyxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNsQyxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFDLEtBQUssRUFBRSxFQUFDLEVBQUUsRUFBRSxNQUFNLEVBQUMsRUFBQyxDQUFDLENBQUM7UUFDdkQsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7SUFDZCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsS0FBSyxDQUFDLG1CQUFtQixDQUFDLE9BQU87UUFDL0IsS0FBSyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLE9BQU8sRUFBRTtZQUN6QyxJQUFJLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUM7WUFDdkMsRUFBRSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFDO1NBQ3RDLENBQUMsQ0FBQztRQUVILE1BQU0sV0FBVyxHQUFHO1lBQ2xCLG1DQUFtQztZQUNuQyxNQUFNLEVBQUUsQ0FBQyxRQUFRLENBQUM7WUFDbEIsaUJBQWlCO1lBQ2pCLFFBQVEsRUFBRSxLQUFLO1lBQ2YscUNBQXFDO1lBQ3JDLE1BQU0sRUFBRSxJQUFJO1NBQ2IsQ0FBQztRQUVGLE1BQU0sMkJBQTJCLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFDLEtBQUssRUFBRTtnQkFDckQsTUFBTSxFQUFFLE9BQU8sQ0FBQyxJQUFJO2dCQUNwQiwrQkFBK0I7Z0JBQy9CLE9BQU8sRUFBRSxLQUFLO2FBQ2YsRUFBQyxFQUFFLFdBQVcsQ0FBQyxDQUFDO1FBQ2pCLE1BQU0sRUFBRSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUNsQyxFQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsRUFBRSxFQUFDLEVBQUUsMkJBQTJCLENBQ2xELENBQUM7UUFFRixNQUFNLGlDQUFpQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBQyxLQUFLLEVBQUU7Z0JBQzNELE1BQU0sRUFBRSxPQUFPLENBQUMsSUFBSTthQUFDLEVBQUMsRUFBRSxXQUFXLENBQUMsQ0FBQztRQUN2QyxNQUFNLEVBQUUsQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsTUFBTSxDQUN4QyxFQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsRUFBRSxFQUFDLEVBQUUsaUNBQWlDLENBQ3hELENBQUM7SUFDSixDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLElBQUksT0FBTyxFQUFFLENBQUMifQ==