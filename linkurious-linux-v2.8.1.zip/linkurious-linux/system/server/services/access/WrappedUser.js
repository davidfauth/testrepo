"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2015-01-30.
 */
const rest_client_1 = require("@linkurious/rest-client");
const Bluebird = require("bluebird");
const _ = require("lodash");
const DataSourceUnavailableError_1 = require("../../models/errors/DataSourceUnavailableError");
const LKE = require("../index");
const Actions = require("./actions");
const Errors = LKE.getErrors();
const Data = LKE.getData();
const Utils = LKE.getUtils();
const Db = LKE.getSqlDb();
const AccessRightDAO = LKE.getAccessRightDAO();
const VisualizationShareDAO = LKE.getVisualizationShareDAO();
const GraphSchemaService = LKE.getGraphSchema();
class WrappedUser {
    /**
     * Create a WrappedUser starting from a PublicUserWithGroups.
     *
     * @param user A user without its private fields, with groups and actions
     */
    constructor(user, application) {
        if (Utils.noValue(user)) {
            throw Errors.technical('bug', 'Can not wrap a user that is null or undefined');
        }
        this.resultCache = new Map();
        // copy basic fields
        this.id = user.id;
        this.username = user.username;
        this.email = user.email;
        this.source = user.source;
        this.preferences = user.preferences;
        this.actions = user.actions;
        this.accessRights = user.accessRights;
        this.groups = user.groups;
        this.createdAt = user.createdAt;
        this.updatedAt = user.updatedAt;
        // if defined, an application is acting on behalf of the user
        this.application = application;
        // builtinAccessRights: quick way to check for access rights on a data-source
        this.builtinAccessRights = {};
        this.admin = false;
        // visibleSourceKeys: used to see if the user belongs to any group of the data-source
        this.visibleSourceKeys = new Set();
        _.forEach(this.groups, group => {
            this.visibleSourceKeys.add(group.sourceKey);
            // skip the group if not builtin
            if (!group.builtin) {
                return;
            }
            // we infer the access rights from the name of the builtin group
            switch (group.name) {
                case Db.models.group.READ_ONLY_GROUP_NAME:
                case Db.models.group.READ_GROUP_NAME:
                    this.builtinAccessRights[group.sourceKey] = 'read';
                    break;
                case Db.models.group.READ_AND_EDIT_GROUP_NAME:
                    this.builtinAccessRights[group.sourceKey] = 'edit';
                    break;
                case Db.models.group.READ_EDIT_AND_DELETE_GROUP_NAME:
                case Db.models.group.SOURCE_MANAGER_GROUP_NAME:
                    this.builtinAccessRights[group.sourceKey] = 'write';
                    break;
                case Db.models.group.ADMIN_GROUP_NAME:
                    this.builtinAccessRights[group.sourceKey] = 'write';
                    this.admin = true;
                    break;
            }
        });
    }
    /**
     * Return a resolved promise if the user can manage users on at least one data-source or
     * on a particular data-source if `sourceKey` is defined.
     *
     * @param [sourceKey]
     */
    canManageUsers(sourceKey) {
        return Bluebird.resolve()
            .then(() => {
            return this.hasAction('admin.users', sourceKey);
        })
            .return();
    }
    /**
     * Return true if the user is an admin.
     */
    isAdmin() {
        return this.admin;
    }
    /**
     * Return true if the user belongs to at least 1 group of the data-source.
     * Throw if the user doesn't belong to any group of the data-source and `throwIfNot` is true.
     *
     * @param sourceKey         Key of the data-source
     * @param [throwIfNot=true] Whether to reject if the condition is not met
     */
    canSeeDataSource(sourceKey, throwIfNot = true) {
        const canSee = this.visibleSourceKeys.has(sourceKey) || this.visibleSourceKeys.has('*');
        if (canSee || !throwIfNot) {
            return canSee;
        }
        throw new DataSourceUnavailableError_1.DataSourceUnavailableError(sourceKey);
    }
    /**
     * Cache of the result of `promiseFunction` indexed by `key`.
     *
     * @param key
     * @param promiseFunction
     */
    cached(key, promiseFunction) {
        if (this.resultCache.has(key)) {
            return Bluebird.resolve(this.resultCache.get(key));
        }
        else {
            return promiseFunction().then(result => {
                this.resultCache.set(key, result);
                return result;
            });
        }
    }
    /**
     * Get the list of target names (access rights) filtered by sourceKey, targetType and type.
     * If `type` is "read", targetNames where "read" is allowed implicitly (e.g. when type is "edit")
     * are returned as well.
     * A returned value of `["*"]` means all the target names.
     * If sourceKey is undefined it means *any* sourceKey. To not confuse with *all* sourceKey.
     *
     * @param [sourceKey] Key of the data-source
     * @param targetType  Type of the target ("edgeType", "nodeCategory", "action", etc.)
     * @param type        Type of the right ("read", "write", etc.)
     */
    accessRightTargetNames(sourceKey, targetType, type) {
        if (Utils.noValue(sourceKey) && targetType !== 'action') {
            // only targetType 'actions' can span over multiple data-sources
            return Errors.technical('bug', "sourceKey can't be null in accessRightTargetNames " +
                'for targetType "nodeCategory", "edgeType" or "alert".', true);
        }
        return this.cached('AR/' + sourceKey + '/' + targetType + '/' + type, () => {
            return AccessRightDAO.getRights(this, targetType, type, sourceKey);
        });
    }
    /**
     * Return true if the current user can read everything on the data-source given by `sourceKey`.
     *
     * @param sourceKey Key of the data-source
     */
    canReadAll(sourceKey) {
        return (this.builtinAccessRights['*'] === 'write' ||
            ['write', 'edit', 'read'].includes(this.builtinAccessRights[sourceKey]));
    }
    /**
     * Return true if the current user can edit everything on the data-source given by `sourceKey`.
     *
     * @param sourceKey Key of the data-source
     */
    canEditAll(sourceKey) {
        return (this.builtinAccessRights['*'] === 'write' ||
            ['write', 'edit'].includes(this.builtinAccessRights[sourceKey]));
    }
    /**
     * Return true if the current user can write everything on the data-source given by `sourceKey`.
     *
     * @param sourceKey Key of the data-source
     */
    canDeleteAll(sourceKey) {
        return (this.builtinAccessRights['*'] === 'write' ||
            ['write'].includes(this.builtinAccessRights[sourceKey]));
    }
    /**
     * Get a list of the node categories readable by the current user.
     * Return `["*"]` if all categories are readable.
     * Categories not in the schema, are considered not readable.
     *
     * @param sourceKey Key of the data-source
     */
    async readableCategories(sourceKey) {
        if (this.canReadAll(sourceKey)) {
            return ['*'];
        }
        const [readableCategories, nodeSchema] = await Promise.all([
            this.accessRightTargetNames(sourceKey, 'nodeCategory', 'read'),
            GraphSchemaService.getSchema(sourceKey, rest_client_1.EntityType.NODE)
        ]);
        let availableCategories = nodeSchema.labels.filter(label => nodeSchema.get(label).visibility !== rest_client_1.DataVisibility.NONE);
        if (readableCategories[0] !== '*') {
            availableCategories = _.intersection(readableCategories, availableCategories);
        }
        return availableCategories;
    }
    /**
     * Check if a list of node categories contains one (or all) readable by the current user.
     *
     * @param sourceKey         Key of the data-source
     * @param nodeCategories    A list of node categories
     * @param [throwIfNot=true] Whether to reject if the condition is not met
     * @param [all]             Must be able to read all categories if true
     */
    hasReadableCategory(sourceKey, nodeCategories, throwIfNot = true, all) {
        if (this.canReadAll(sourceKey)) {
            return Promise.resolve(true);
        }
        // check if the list of node categories contains a least one category readable by the user
        return this.readableCategories(sourceKey).then(readable => {
            if (readable[0] === '*') {
                return true;
            }
            const readableIntersect = _.intersection(nodeCategories, readable);
            const canRead = all
                ? readableIntersect.length === nodeCategories.length
                : readableIntersect.length > 0;
            if (canRead || !throwIfNot) {
                return canRead;
            }
            throw Errors.access('read_forbidden', `Cannot read node (${all ? 'some non-readable categories' : 'no readable category'}).`);
        });
    }
    /**
     * Check if the given node (by node or id) is readable by the current user.
     *
     * @param sourceKey         Key of the data-source
     * @param nodeOrNodeId      A node or the ID of a node
     * @param [throwIfNot=true] Whether to reject if the condition is not met
     */
    canReadNode(sourceKey, nodeOrNodeId, throwIfNot = true) {
        if (this.canReadAll(sourceKey)) {
            return Bluebird.resolve(true);
        }
        return this.cached('RN/' + sourceKey + '/' + WrappedUser.itemId(nodeOrNodeId), () => {
            return WrappedUser.resolveNode(sourceKey, nodeOrNodeId).then(node => {
                return this.hasReadableCategory(sourceKey, node.categories, throwIfNot);
            });
        });
    }
    /**
     * Check if the given nodes (by node or id) are readable by the current user.
     *
     * @param sourceKey      Key of the data-source
     * @param nodesOrNodeIds Nodes or IDs of nodes
     */
    canReadNodes(sourceKey, nodesOrNodeIds) {
        if (this.canReadAll(sourceKey)) {
            return Bluebird.resolve();
        }
        return Bluebird.map(nodesOrNodeIds, nodeOrNodeId => this.canReadNode(sourceKey, nodeOrNodeId)).return();
    }
    /**
     * Map node/edge types to the correct access level.
     *
     * @param sourceKey Key of the data-source
     * @param type      'node' or 'edge'
     */
    getAccessLevelByType(sourceKey, type) {
        return Bluebird.resolve()
            .then(() => {
            if (type === 'node') {
                return Bluebird.props({
                    [rest_client_1.AccessLevel.READABLE]: this.readableCategories(sourceKey),
                    [rest_client_1.AccessLevel.EDITABLE]: this.editableCategories(sourceKey),
                    [rest_client_1.AccessLevel.WRITABLE]: this.deletableCategories(sourceKey)
                });
            }
            else {
                return Bluebird.props({
                    [rest_client_1.AccessLevel.READABLE]: this.readableTypes(sourceKey),
                    [rest_client_1.AccessLevel.EDITABLE]: this.editableTypes(sourceKey),
                    [rest_client_1.AccessLevel.WRITABLE]: this.deletableTypes(sourceKey)
                });
            }
        })
            .then(accessToCategoryOrType => {
            const categoryOrTypeToAccess = new Map();
            for (const accessLevel of [
                rest_client_1.AccessLevel.READABLE,
                rest_client_1.AccessLevel.EDITABLE,
                rest_client_1.AccessLevel.WRITABLE
            ]) {
                // access levels should be populated from readable to writable
                // this ensures that the rights are overwritten correctly
                // @ts-ignore
                const categoriesOrTypes = accessToCategoryOrType[accessLevel];
                if (_.isEqual(categoriesOrTypes, ['*'])) {
                    categoryOrTypeToAccess.set('*', accessLevel);
                }
                else {
                    _.forEach(categoriesOrTypes, categoryOrType => {
                        categoryOrTypeToAccess.set(categoryOrType, accessLevel);
                    });
                }
            }
            return categoryOrTypeToAccess;
        });
    }
    /**
     * Assign the correct access level to node or edge types.
     *
     * @param sourceKey Key of the data-source
     * @param type      'node' or 'edge'
     * @param schema    `type` labels and properties
     */
    addAccessToSchema(sourceKey, type, schema) {
        return this.getAccessLevelByType(sourceKey, type).then(accessLevelByType => {
            const defaultAccess = accessLevelByType.get('*') || rest_client_1.AccessLevel.NONE;
            const schemaWithAccess = [];
            for (const schemaType of schema.results) {
                const access = accessLevelByType.get(schemaType.label) || defaultAccess;
                if (access !== 'none' && schemaType.visibility !== rest_client_1.DataVisibility.NONE) {
                    const properties = schemaType.properties.filter(p => p.visibility !== rest_client_1.DataVisibility.NONE);
                    schemaWithAccess.push({
                        label: schemaType.label,
                        access: access,
                        visibility: schemaType.visibility,
                        properties: properties
                    });
                }
            }
            return {
                any: {
                    access: defaultAccess
                },
                results: schemaWithAccess
            };
        });
    }
    /**
     * Get a list of the node categories editable by the current user.
     * Return `["*"]` if all categories are editable.
     *
     * @param sourceKey Key of the data-source
     */
    editableCategories(sourceKey) {
        if (Data.resolveSource(sourceKey).isReadOnly()) {
            return Bluebird.resolve([]);
        }
        if (this.canEditAll(sourceKey)) {
            return Bluebird.resolve(['*']);
        }
        return this.accessRightTargetNames(sourceKey, 'nodeCategory', 'edit');
    }
    /**
     * Check if a list of node categories contains one (or all) editable by the current user.
     *
     * @param sourceKey         Key of the data-source
     * @param nodeCategories    A list of node categories
     * @param [throwIfNot=true] Whether to reject if the condition is not met
     * @param [all]             Must be able to edit all categories if true
     */
    hasEditableCategory(sourceKey, nodeCategories, throwIfNot = true, all) {
        if (Data.resolveSource(sourceKey).isReadOnly()) {
            return Bluebird.resolve(false);
        }
        if (this.canEditAll(sourceKey)) {
            return Bluebird.resolve(true);
        }
        // check if the list of node categories contains a least one category editable by the user
        return this.editableCategories(sourceKey).then(editable => {
            if (editable[0] === '*') {
                return true;
            }
            const editableIntersect = _.intersection(nodeCategories, editable);
            const canEdit = all
                ? editableIntersect.length === nodeCategories.length
                : editableIntersect.length > 0;
            if (canEdit || !throwIfNot) {
                return canEdit;
            }
            throw Errors.access('write_forbidden', `Cannot edit node (${all ? 'some non-editable categories' : 'no editable category'}).`);
        });
    }
    /**
     * Check if the given node (by node or id) is editable by the current user.
     *
     * @param sourceKey         Key of the data-source
     * @param nodeOrNodeId      A node or the ID of a node
     * @param [throwIfNot=true] Whether to reject if the condition is not met
     */
    canEditNode(sourceKey, nodeOrNodeId, throwIfNot = true) {
        if (Data.resolveSource(sourceKey).isReadOnly()) {
            return Bluebird.resolve(false);
        }
        if (this.canEditAll(sourceKey)) {
            return Bluebird.resolve(true);
        }
        return WrappedUser.resolveNode(sourceKey, nodeOrNodeId).then(node => {
            return this.hasEditableCategory(sourceKey, node.categories, throwIfNot);
        });
    }
    /**
     * Check if a list of node categories are all editable by the current user.
     *
     * @param sourceKey  Key of the data-source
     * @param categories A list of node categories
     */
    canEditCategories(sourceKey, categories) {
        return this.hasEditableCategory(sourceKey, categories, true, true).return();
    }
    /**
     * Get a list of the node categories deletable by the current user.
     * Return `["*"]` if all categories are deletable.
     *
     * @param sourceKey Key of the data-source
     */
    deletableCategories(sourceKey) {
        if (Data.resolveSource(sourceKey).isReadOnly()) {
            return Bluebird.resolve([]);
        }
        if (this.canDeleteAll(sourceKey)) {
            return Bluebird.resolve(['*']);
        }
        return this.accessRightTargetNames(sourceKey, 'nodeCategory', 'write');
    }
    /**
     * Check if a list of node categories contains one (or all) deletable by the current user.
     *
     * @param sourceKey         Key of the data-source
     * @param nodeCategories    A list of node categories
     * @param [throwIfNot=true] Whether to reject if the condition is not met
     * @param [all]             Must be able to delete all categories if true
     */
    hasDeletableCategory(sourceKey, nodeCategories, throwIfNot = true, all) {
        if (Data.resolveSource(sourceKey).isReadOnly()) {
            return Bluebird.resolve(false);
        }
        if (this.canDeleteAll(sourceKey)) {
            return Bluebird.resolve(true);
        }
        // check if the list of node categories contains a least one category deletable by the user
        return this.deletableCategories(sourceKey).then(deletable => {
            if (deletable[0] === '*') {
                return true;
            }
            const deletableIntersect = _.intersection(nodeCategories, deletable);
            const canDelete = all
                ? deletableIntersect.length === nodeCategories.length
                : deletableIntersect.length > 0;
            if (canDelete || !throwIfNot) {
                return canDelete;
            }
            throw Errors.access('write_forbidden', `Cannot delete node (${all ? 'some non-deletable categories' : 'no deletable category'}).`);
        });
    }
    /**
     * Check if the given node (by node or id) is deletable by the current user.
     *
     * @param sourceKey         Key of the data-source
     * @param nodeOrNodeId      A node or the ID of a node
     * @param [throwIfNot=true] Whether to reject if the condition is not met
     */
    canDeleteNode(sourceKey, nodeOrNodeId, throwIfNot = true) {
        if (Data.resolveSource(sourceKey).isReadOnly()) {
            return Bluebird.resolve(false);
        }
        if (this.canDeleteAll(sourceKey)) {
            return Bluebird.resolve(true);
        }
        return WrappedUser.resolveNodeWithEdgeDigest(sourceKey, nodeOrNodeId).then(node => {
            return this.hasDeletableCategory(sourceKey, node.categories, throwIfNot).then(canDeleteCategory => {
                if (!canDeleteCategory) {
                    return false;
                }
                return this.deletableTypes(sourceKey).then(deletableTypes => {
                    if (deletableTypes[0] === '*') {
                        return true;
                    }
                    const canDelete = _.chain(node)
                        .get('statistics.supernodeDigest')
                        // TODO remove ts-ignore (added after update types lodash)
                        // @ts-ignore
                        .map('edgeType')
                        .difference(deletableTypes)
                        .isEmpty()
                        .value();
                    if (!canDelete && throwIfNot) {
                        throw Errors.access('write_forbidden', 'Cannot delete edge.');
                    }
                    return canDelete;
                });
            });
        });
    }
    /**
     * If `nodeOrNodeId` is an LkNode resolve immediately with it.
     * If it's an ID, retrieve and resolve the LkNode.
     *
     * @param sourceKey    Key of the data-source
     * @param nodeOrNodeId A node or the ID of a node
     */
    static resolveNode(sourceKey, nodeOrNodeId) {
        if (typeof nodeOrNodeId === 'string') {
            // it was an ID
            return Data.getNodesByID({
                ids: [nodeOrNodeId],
                sourceKey: sourceKey
            }).get(0);
        }
        else {
            // it was already a node
            return Bluebird.resolve(nodeOrNodeId);
        }
    }
    /**
     * Get a node of the graph with a neighborhood edge digest in statistics.
     *
     * @param sourceKey    Key of the data-source
     * @param nodeOrNodeId A node or the ID of a node
     */
    static resolveNodeWithEdgeDigest(sourceKey, nodeOrNodeId) {
        return WrappedUser.resolveNode(sourceKey, nodeOrNodeId).then(node => {
            return Data.getEdgeDigest(sourceKey, node.id).then(edgeDigest => {
                node.statistics = node.statistics || {};
                node.statistics.supernodeDigest = edgeDigest;
                return node;
            });
        });
    }
    /**
     * Get a list of the edge types readable by the current user.
     * Return `["*"]` if all types are readable.
     * Types not in the schema, are considered not readable.
     *
     * @param sourceKey Key of the data-source
     */
    async readableTypes(sourceKey) {
        if (this.canReadAll(sourceKey)) {
            return ['*'];
        }
        const [readableTypes, edgeSchema] = await Promise.all([
            this.accessRightTargetNames(sourceKey, 'edgeType', 'read'),
            GraphSchemaService.getSchema(sourceKey, rest_client_1.EntityType.EDGE)
        ]);
        let availableTypes = edgeSchema.labels.filter(label => edgeSchema.get(label).visibility !== rest_client_1.DataVisibility.NONE);
        if (readableTypes[0] !== '*') {
            availableTypes = _.intersection(readableTypes, availableTypes);
        }
        return availableTypes;
    }
    /**
     * Check if an edge type is readable by the current user.
     *
     * @param sourceKey         Key of the data-source
     * @param edgeType          An edge type
     * @param [throwIfNot=true] Whether to reject if the condition is not met
     */
    canReadType(sourceKey, edgeType, throwIfNot = true) {
        if (this.canReadAll(sourceKey)) {
            return Promise.resolve(true);
        }
        // check if the type is readable
        return this.readableTypes(sourceKey).then(readableTypes => {
            const canRead = readableTypes[0] === '*' || _.includes(readableTypes, edgeType);
            if (!canRead && throwIfNot) {
                throw Errors.access('read_forbidden', 'Cannot read edge.');
            }
            return canRead;
        });
    }
    /**
     * Check if the given edge (by edge or id) is readable by the current user.
     *
     * @param sourceKey         Key of the data-source
     * @param edgeOrEdgeId      An edge or the ID of an edge
     * @param [throwIfNot=true] Whether to reject if the condition is not met
     */
    canReadEdge(sourceKey, edgeOrEdgeId, throwIfNot = true) {
        if (this.canReadAll(sourceKey)) {
            return Bluebird.resolve(true);
        }
        return this.cached('RE/' + sourceKey + '/' + WrappedUser.itemId(edgeOrEdgeId), () => {
            return WrappedUser.resolveEdge(sourceKey, edgeOrEdgeId).then(edge => {
                return this.canReadType(sourceKey, edge.type, throwIfNot).then(canReadType => {
                    if (!canReadType) {
                        return false;
                    }
                    // we have to be able to read the source and the target nodes to read the edge
                    return this.canReadNode(sourceKey, edge.source, throwIfNot).then(canReadSource => {
                        if (!canReadSource) {
                            return false;
                        }
                        return this.canReadNode(sourceKey, edge.target, throwIfNot);
                    });
                });
            });
        });
    }
    /**
     * Get a list of the edge types editable by the current user.
     * Return `["*"]` if all types are editable.
     *
     * @param sourceKey Key of the data-source
     */
    editableTypes(sourceKey) {
        if (Data.resolveSource(sourceKey).isReadOnly()) {
            return Bluebird.resolve([]);
        }
        if (this.canEditAll(sourceKey)) {
            return Bluebird.resolve(['*']);
        }
        return this.accessRightTargetNames(sourceKey, 'edgeType', 'edit');
    }
    /**
     * Check if an edge type is editable by the current user.
     *
     * @param sourceKey         Key of the data-source
     * @param edgeType          An edge type
     * @param [throwIfNot=true] Whether to reject if the condition is not met
     */
    canEditType(sourceKey, edgeType, throwIfNot = true) {
        if (Data.resolveSource(sourceKey).isReadOnly()) {
            return Bluebird.resolve(false);
        }
        if (this.canEditAll(sourceKey)) {
            return Bluebird.resolve(true);
        }
        // check if the type is editable
        return this.editableTypes(sourceKey).then(editableTypes => {
            const canEdit = editableTypes[0] === '*' || _.includes(editableTypes, edgeType);
            if (!canEdit && throwIfNot) {
                throw Errors.access('write_forbidden', 'Cannot edit edge.');
            }
            return canEdit;
        });
    }
    /**
     * Check if the given edge (by edge or id) is editable by the current user.
     *
     * @param sourceKey         Key of the data-source
     * @param edgeOrEdgeId      An edge or the ID of an edge
     * @param [throwIfNot=true] Whether to reject if the condition is not met
     */
    canEditEdge(sourceKey, edgeOrEdgeId, throwIfNot = true) {
        if (Data.resolveSource(sourceKey).isReadOnly()) {
            return Bluebird.resolve(false);
        }
        if (this.canEditAll(sourceKey)) {
            return Bluebird.resolve(true);
        }
        return WrappedUser.resolveEdge(sourceKey, edgeOrEdgeId).then(edge => {
            return this.canEditType(sourceKey, edge.type, throwIfNot);
        });
    }
    /**
     * Get a list of the edge types deletable by the current user.
     * Return `["*"]` if all types are deletable.
     *
     * @param sourceKey Key of the data-source
     */
    deletableTypes(sourceKey) {
        if (Data.resolveSource(sourceKey).isReadOnly()) {
            return Bluebird.resolve([]);
        }
        if (this.canDeleteAll(sourceKey)) {
            return Bluebird.resolve(['*']);
        }
        return this.accessRightTargetNames(sourceKey, 'edgeType', 'write');
    }
    /**
     * Check if an edge type is deletable by the current user.
     *
     * @param sourceKey         Key of the data-source
     * @param edgeType          An edge type
     * @param [throwIfNot=true] Whether to reject if the condition is not met
     */
    canDeleteType(sourceKey, edgeType, throwIfNot = true) {
        if (Data.resolveSource(sourceKey).isReadOnly()) {
            return Bluebird.resolve(false);
        }
        if (this.canDeleteAll(sourceKey)) {
            return Bluebird.resolve(true);
        }
        // check if the type is deletable
        return this.deletableTypes(sourceKey).then(deletableTypes => {
            const canDelete = deletableTypes[0] === '*' || _.includes(deletableTypes, edgeType);
            if (!canDelete && throwIfNot) {
                throw Errors.access('write_forbidden', 'Cannot delete edge.');
            }
            return canDelete;
        });
    }
    /**
     * Check if the given edge (by edge or id) is deletable by the current user.
     *
     * @param sourceKey         Key of the data-source
     * @param edgeOrEdgeId      An edge or the ID of an edge
     * @param [throwIfNot=true] Whether to reject if the condition is not met
     */
    canDeleteEdge(sourceKey, edgeOrEdgeId, throwIfNot = true) {
        if (Data.resolveSource(sourceKey).isReadOnly()) {
            return Bluebird.resolve(false);
        }
        if (this.canDeleteAll(sourceKey)) {
            return Bluebird.resolve(true);
        }
        return WrappedUser.resolveEdge(sourceKey, edgeOrEdgeId).then(edge => {
            return this.canDeleteType(sourceKey, edge.type, throwIfNot);
        });
    }
    /**
     * Check if the given alert (by id) is readable by the current user.
     *
     * @param sourceKey         Key of the data-source
     * @param alertId           ID of the alert
     * @param [throwIfNot=true] Whether to reject if the condition is not met
     */
    canReadAlert(sourceKey, alertId, throwIfNot = true) {
        if (this.canReadAll(sourceKey)) {
            return Bluebird.resolve(true);
        }
        return this.accessRightTargetNames(sourceKey, 'alert', 'read').then(readableAlertIds => {
            // user can read all alerts => ok
            if (readableAlertIds[0] === '*') {
                return true;
            }
            // alertId (as string) found in readable alert ids => ok
            if (readableAlertIds.includes(alertId + '')) {
                return true;
            }
            if (!throwIfNot) {
                return false;
            }
            throw Errors.access('read_forbidden', `You don't have read access to Alert #${alertId}.`);
        });
    }
    /**
     * Keep only readable nodes with readable digest, readable properties and readable categories.
     * Keep only readable edges with readable properties.
     *
     * @param sourceKey
     * @param result
     * @param options
     * @param [options.discardNodesWithNoEdges]
     * @param [options.allOrNothing]
     */
    filterSubGraph(sourceKey, subgraph, options) {
        return this.filterNodesContent(sourceKey, subgraph.nodes).then(nodes => {
            return this.filterEdgesContent(sourceKey, subgraph.edges).then(edges => {
                if (options.allOrNothing &&
                    (subgraph.nodes.length !== nodes.length || subgraph.edges.length !== edges.length)) {
                    subgraph.nodes = [];
                    subgraph.edges = [];
                    return subgraph;
                }
                subgraph.nodes = nodes;
                subgraph.edges = edges;
                // if we got the subgraph by edge id or edge search, we are interested
                // in keeping the nodes only if the edges are kept as well in the subgraph
                if (options.discardNodesWithNoEdges) {
                    const seenNodeIds = new Set();
                    for (let i = 0; i < edges.length; i++) {
                        seenNodeIds.add(edges[i].source);
                        seenNodeIds.add(edges[i].target);
                    }
                    // we only keep nodes that appear at least once in an edge
                    subgraph.nodes = _.filter(subgraph.nodes, node => seenNodeIds.has(node.id));
                }
                return subgraph;
            });
        });
    }
    /**
     * Filter an array of nodes to return only the ones readable by the current user.
     *
     * @param sourceKey Key of the data-source
     * @param nodes     Nodes
     */
    filterReadableNodes(sourceKey, nodes) {
        if (this.canReadAll(sourceKey)) {
            return Bluebird.resolve(nodes);
        }
        if (Utils.noValue(nodes) || nodes.length === 0) {
            return Bluebird.resolve(nodes);
        }
        return Bluebird.reduce(nodes, (filtered, node) => {
            return this.canReadNode(sourceKey, node, false).then(readable => {
                if (readable) {
                    filtered.push(node);
                }
                return filtered;
            });
        }, []);
    }
    /**
     * Filter an array of edges to return only the ones readable by the current user.
     * (i.e. edges with TYPE, SOURCE and TARGET readable by current user).
     *
     * @param sourceKey Key of the data-source
     * @param edges     Edges
     */
    filterReadableEdges(sourceKey, edges) {
        if (this.canReadAll(sourceKey)) {
            return Bluebird.resolve(edges);
        }
        if (Utils.noValue(edges) || edges.length === 0) {
            return Bluebird.resolve(edges);
        }
        return Bluebird.reduce(edges, (filtered, edge) => {
            return this.canReadEdge(sourceKey, edge, false).then(readable => {
                if (readable) {
                    filtered.push(edge);
                }
                return filtered;
            });
        }, []);
    }
    /**
     * Keep only readable nodes with readable digest, readable properties and readable categories.
     *
     * @param sourceKey Key of the data-source
     * @param nodes     A node array
     */
    filterNodesContent(sourceKey, nodes) {
        return this.filterReadableNodes(sourceKey, nodes).map(readableNode => {
            return this.filterNodeContent(sourceKey, readableNode);
        });
    }
    /**
     * Keep only readable edges with readable properties.
     *
     * @param sourceKey Key of the data-source
     * @param edges     An edge array
     */
    filterEdgesContent(sourceKey, edges) {
        return this.filterReadableEdges(sourceKey, edges).map(readableEdge => {
            return this.filterEdgeProperties(sourceKey, readableEdge);
        });
    }
    /**
     * Filter the categories of a node.
     *
     * @param sourceKey Key of the data-source
     * @param node      A node
     */
    filterNodeCategories(sourceKey, node) {
        if (this.canReadAll(sourceKey)) {
            return Promise.resolve(node);
        }
        return this.readableCategories(sourceKey).then(readable => {
            if (readable[0] === '*') {
                return node;
            }
            node.categories = _.intersection(node.categories, readable);
            return node;
        });
    }
    /**
     * Filter the content of a node.
     *
     * @param sourceKey Key of the data-source
     * @param node      A node
     */
    filterNodeContent(sourceKey, node) {
        return this.filterNodeCategories(sourceKey, node).then(filteredNode => {
            node = this.filterNodeProperties(sourceKey, filteredNode);
            return this.filterNodeDigest(sourceKey, node);
        });
    }
    /**
     * Filter the digest of a node.
     *
     * @param sourceKey Key of the data-source
     * @param node      A node
     */
    filterNodeDigest(sourceKey, node) {
        if (this.canReadAll(sourceKey)) {
            return Bluebird.resolve(node);
        }
        // nothing to do if the digest is not there
        if (!node.statistics || !node.statistics.digest) {
            return Bluebird.resolve(node);
        }
        return this.filterDigest(sourceKey, node.statistics.digest).then(filteredDigest => {
            node.statistics.digest = filteredDigest;
            return node;
        });
    }
    /**
     * Filter the content of an adjacency digest for readable categories and types.
     * Regroup digest items accordingly.
     *
     * @param sourceKey Key of the data-source
     * @param digest    The adjacency digest of a node
     */
    filterDigest(sourceKey, digest) {
        return Bluebird.resolve().then(() => {
            return this.readable(sourceKey).then(readable => {
                return _.chain(digest)
                    .filter(entry => {
                    // filter to readable categories
                    entry.nodeCategories = _.intersection(readable.categories, entry.nodeCategories);
                    return entry.nodeCategories.length > 0 && readable.typeMap[entry.edgeType];
                })
                    .groupBy(entry => {
                    // entry group key
                    return entry.edgeType + '/' + entry.nodeCategories;
                })
                    .values()
                    .map(entryGroup => {
                    const mergedEntry = entryGroup[0];
                    for (let i = 1; i < entryGroup.length; ++i) {
                        mergedEntry.nodes += entryGroup[i].nodes;
                        mergedEntry.edges += entryGroup[i].edges;
                    }
                    return mergedEntry;
                })
                    .value();
            });
        });
    }
    /**
     * Return the readable categories and types.
     *
     * @param sourceKey Key of the data-source
     */
    async readable(sourceKey) {
        const [readableCategories, readableTypes, nodeSchema, edgeSchema] = await Promise.all([
            this.readableCategories(sourceKey),
            this.readableTypes(sourceKey),
            GraphSchemaService.getSchema(sourceKey, rest_client_1.EntityType.NODE),
            GraphSchemaService.getSchema(sourceKey, rest_client_1.EntityType.EDGE)
        ]);
        let availableCategories = nodeSchema.labels.filter(label => nodeSchema.get(label).visibility !== rest_client_1.DataVisibility.NONE);
        let availableTypes = edgeSchema.labels.filter(label => edgeSchema.get(label).visibility !== rest_client_1.DataVisibility.NONE);
        if (readableCategories[0] !== '*') {
            availableCategories = _.intersection(readableCategories, availableCategories);
        }
        if (readableTypes[0] !== '*') {
            availableTypes = _.intersection(readableTypes, availableTypes);
        }
        let i;
        const result = {
            categoryMap: {},
            typeMap: {},
            categories: availableCategories,
            types: availableTypes
        };
        for (i = 0; i < availableCategories.length; ++i) {
            result.categoryMap[availableCategories[i]] = true;
        }
        for (i = 0; i < availableTypes.length; ++i) {
            result.typeMap[availableTypes[i]] = true;
        }
        return result;
    }
    /**
     * Throw a business LkError if the current user can't write the given folder.
     *
     * @param folder
     */
    canWriteFolder(folder) {
        const canWrite = this.id === folder.userId;
        if (!canWrite) {
            throw Errors.access('write_forbidden');
        }
    }
    /**
     * Throw a business LkError if the current user has no right on the visualization.
     * Return 'owner', 'write' or 'read' (reject if no right exists).
     *
     * @param visualization
     */
    getVisualizationRight(visualization) {
        return VisualizationShareDAO.getRight(visualization, this.id);
    }
    /**
     * Throw a business LkError if the current user doesn't have the needed right on the visualization.
     *
     * @param visualization
     * @param neededRight
     */
    hasVisualizationRight(visualization, neededRight) {
        return this.getVisualizationRight(visualization).then(right => {
            if (neededRight === 'read' && !right) {
                throw Errors.access('read_forbidden', 'You need read access to this visualization.');
            }
            if (neededRight === 'write' && right !== 'write' && right !== 'owner') {
                throw Errors.access('write_forbidden', 'You need write or owner access to this visualization.');
            }
            if (neededRight === 'owner' && right !== 'owner') {
                throw Errors.access('write_forbidden', 'You need owner access to this visualization.');
            }
        });
    }
    /**
     * Shorthand method for source.filterNodeProperties.
     *
     * @param sourceKey Key of the data-source
     * @param node      A node or a node array
     */
    filterNodeProperties(sourceKey, node) {
        return Data.resolveSource(sourceKey).filterNodeProperties(node);
    }
    /**
     * Shorthand method for source.filterEdgeProperties.
     *
     * @param sourceKey Key of the data-source
     * @param edge      An edge or an edge array
     */
    filterEdgeProperties(sourceKey, edge) {
        return Data.resolveSource(sourceKey).filterEdgeProperties(edge);
    }
    /**
     * Check if the given action (by action name) is doable by the current user.
     * - If sourceKey is `undefined`, it checks that the user can do the action in *at least one* source.
     * - If sourceKey is '*', it checks that the user can do the action in *all* sources.
     *
     * @param actionName        Name of the action
     * @param [sourceKey]       Key of the data-source
     * @param [throwIfNot=true] Whether to reject if the condition is not met
     */
    async hasAction(actionName, sourceKey, throwIfNot = true) {
        return Promise.resolve().then(() => {
            if (!Actions.exists(actionName)) {
                return Errors.technical('bug', 'action "' + actionName + '" doesn\'t exist.', true);
            }
            return this.accessRightTargetNames(sourceKey, 'action', 'do').then(actions => {
                if (actions[0] === '*') {
                    return true;
                }
                // if the required action is "runQuery"; "rawReadQuery" and "rawWriteQuery" satisfy it
                const actionNames = Utils.hasValue(Actions.IMPLICIT_ACTIONS.get(actionName))
                    ? Actions.IMPLICIT_ACTIONS.get(actionName)
                    : [actionName];
                const hasAction = _.intersection(actions, actionNames).length > 0;
                if (hasAction || !throwIfNot) {
                    return hasAction;
                }
                let dataSourceMsg = '';
                if (sourceKey && sourceKey === '*') {
                    dataSourceMsg = ' on all data-sources.';
                }
                else if (sourceKey) {
                    dataSourceMsg = ' on data-source ' + sourceKey + '.';
                }
                else {
                    dataSourceMsg = ' on any data-source.';
                }
                throw Errors.access('forbidden', 'You can\'t do action "' + actionName + '"' + dataSourceMsg);
            });
        });
    }
    /**
     * If `edgeOrEdgeId` is an LkEdge resolve immediately with it.
     * If it's an ID, retrieve and resolve the LkEdge.
     *
     * @param sourceKey    Key of the data-source
     * @param edgeOrEdgeId An edge or the ID of an edge
     */
    static resolveEdge(sourceKey, edgeOrEdgeId) {
        if (Utils.noValue(edgeOrEdgeId)) {
            return Errors.technical('edge_not_found', 'Edge not found.', true);
        }
        const type = typeof edgeOrEdgeId;
        if (type === 'string') {
            // was an ID
            return Data.getEdgesByID({ ids: [edgeOrEdgeId], sourceKey: sourceKey }).get(0);
        }
        else {
            // was already an edge
            return Bluebird.resolve(edgeOrEdgeId);
        }
    }
    /**
     * If `itemOrItemId` is an object return the property `id`.
     * If it's an ID, return it directly.
     *
     * @param itemOrItemId
     */
    static itemId(itemOrItemId) {
        const type = typeof itemOrItemId;
        if (type === 'string') {
            return itemOrItemId;
        }
        else {
            return itemOrItemId.id;
        }
    }
}
exports.WrappedUser = WrappedUser;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiV3JhcHBlZFVzZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvYWNjZXNzL1dyYXBwZWRVc2VyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUE7Ozs7O0dBS0c7QUFDSCx5REFZaUM7QUFDakMscUNBQXFDO0FBQ3JDLDRCQUE0QjtBQUU1QiwrRkFBMEY7QUFFMUYsZ0NBQWlDO0FBQ2pDLHFDQUFzQztBQUV0QyxNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxJQUFJLEdBQUcsR0FBRyxDQUFDLE9BQU8sRUFBRSxDQUFDO0FBQzNCLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLEVBQUUsR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDMUIsTUFBTSxjQUFjLEdBQUcsR0FBRyxDQUFDLGlCQUFpQixFQUFFLENBQUM7QUFDL0MsTUFBTSxxQkFBcUIsR0FBRyxHQUFHLENBQUMsd0JBQXdCLEVBQUUsQ0FBQztBQUM3RCxNQUFNLGtCQUFrQixHQUFHLEdBQUcsQ0FBQyxjQUFjLEVBQUUsQ0FBQztBQUVoRCxNQUFhLFdBQVc7SUF5QnRCOzs7O09BSUc7SUFDSCxZQUFZLElBQTBCLEVBQUUsV0FBK0I7UUFDckUsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ3ZCLE1BQU0sTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsK0NBQStDLENBQUMsQ0FBQztTQUNoRjtRQUNELElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQztRQUU3QixvQkFBb0I7UUFDcEIsSUFBSSxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUMsRUFBRSxDQUFDO1FBQ2xCLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQztRQUM5QixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDeEIsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO1FBQzFCLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQztRQUNwQyxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUM7UUFDNUIsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDO1FBQ3RDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUMxQixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUM7UUFDaEMsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO1FBRWhDLDZEQUE2RDtRQUM3RCxJQUFJLENBQUMsV0FBVyxHQUFHLFdBQVcsQ0FBQztRQUUvQiw2RUFBNkU7UUFDN0UsSUFBSSxDQUFDLG1CQUFtQixHQUFHLEVBQUUsQ0FBQztRQUM5QixJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztRQUVuQixxRkFBcUY7UUFDckYsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7UUFFbkMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxFQUFFO1lBQzdCLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBRTVDLGdDQUFnQztZQUNoQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sRUFBRTtnQkFDbEIsT0FBTzthQUNSO1lBRUQsZ0VBQWdFO1lBQ2hFLFFBQVEsS0FBSyxDQUFDLElBQUksRUFBRTtnQkFDbEIsS0FBSyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQztnQkFDMUMsS0FBSyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxlQUFlO29CQUNsQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxHQUFHLE1BQU0sQ0FBQztvQkFDbkQsTUFBTTtnQkFDUixLQUFLLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLHdCQUF3QjtvQkFDM0MsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsR0FBRyxNQUFNLENBQUM7b0JBQ25ELE1BQU07Z0JBQ1IsS0FBSyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQywrQkFBK0IsQ0FBQztnQkFDckQsS0FBSyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyx5QkFBeUI7b0JBQzVDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLEdBQUcsT0FBTyxDQUFDO29CQUNwRCxNQUFNO2dCQUNSLEtBQUssRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsZ0JBQWdCO29CQUNuQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxHQUFHLE9BQU8sQ0FBQztvQkFDcEQsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUM7b0JBQ2xCLE1BQU07YUFDVDtRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksY0FBYyxDQUFDLFNBQWtCO1FBQ3RDLE9BQU8sUUFBUSxDQUFDLE9BQU8sRUFBRTthQUN0QixJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1QsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsRUFBRSxTQUFTLENBQUMsQ0FBQztRQUNsRCxDQUFDLENBQUM7YUFDRCxNQUFNLEVBQUUsQ0FBQztJQUNkLENBQUM7SUFFRDs7T0FFRztJQUNJLE9BQU87UUFDWixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUM7SUFDcEIsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLGdCQUFnQixDQUFDLFNBQWlCLEVBQUUsVUFBVSxHQUFHLElBQUk7UUFDMUQsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsSUFBSSxJQUFJLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBRXhGLElBQUksTUFBTSxJQUFJLENBQUMsVUFBVSxFQUFFO1lBQ3pCLE9BQU8sTUFBTSxDQUFDO1NBQ2Y7UUFFRCxNQUFNLElBQUksdURBQTBCLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDbEQsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ssTUFBTSxDQUFJLEdBQVcsRUFBRSxlQUFrQztRQUMvRCxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQzdCLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQU0sQ0FBQyxDQUFDO1NBQ3pEO2FBQU07WUFDTCxPQUFPLGVBQWUsRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtnQkFDckMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLE1BQU0sQ0FBQyxDQUFDO2dCQUNsQyxPQUFPLE1BQU0sQ0FBQztZQUNoQixDQUFDLENBQUMsQ0FBQztTQUNKO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7Ozs7O09BVUc7SUFDSyxzQkFBc0IsQ0FDNUIsU0FBNkIsRUFDN0IsVUFBa0IsRUFDbEIsSUFBWTtRQUVaLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsSUFBSSxVQUFVLEtBQUssUUFBUSxFQUFFO1lBQ3ZELGdFQUFnRTtZQUNoRSxPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQ3JCLEtBQUssRUFDTCxvREFBb0Q7Z0JBQ2xELHVEQUF1RCxFQUN6RCxJQUFJLENBQ0wsQ0FBQztTQUNIO1FBRUQsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssR0FBRyxTQUFTLEdBQUcsR0FBRyxHQUFHLFVBQVUsR0FBRyxHQUFHLEdBQUcsSUFBSSxFQUFFLEdBQUcsRUFBRTtZQUN6RSxPQUFPLGNBQWMsQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLFVBQVUsRUFBRSxJQUFJLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFDckUsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNLLFVBQVUsQ0FBQyxTQUFpQjtRQUNsQyxPQUFPLENBQ0wsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxLQUFLLE9BQU87WUFDekMsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLE1BQU0sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FDeEUsQ0FBQztJQUNKLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ssVUFBVSxDQUFDLFNBQWlCO1FBQ2xDLE9BQU8sQ0FDTCxJQUFJLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLEtBQUssT0FBTztZQUN6QyxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQ2hFLENBQUM7SUFDSixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNLLFlBQVksQ0FBQyxTQUFpQjtRQUNwQyxPQUFPLENBQ0wsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxLQUFLLE9BQU87WUFDekMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQ3hELENBQUM7SUFDSixDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0ksS0FBSyxDQUFDLGtCQUFrQixDQUFDLFNBQWlCO1FBQy9DLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsRUFBRTtZQUM5QixPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDZDtRQUVELE1BQU0sQ0FBQyxrQkFBa0IsRUFBRSxVQUFVLENBQUMsR0FBRyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUM7WUFDekQsSUFBSSxDQUFDLHNCQUFzQixDQUFDLFNBQVMsRUFBRSxjQUFjLEVBQUUsTUFBTSxDQUFDO1lBQzlELGtCQUFrQixDQUFDLFNBQVMsQ0FBQyxTQUFTLEVBQUUsd0JBQVUsQ0FBQyxJQUFJLENBQUM7U0FDekQsQ0FBQyxDQUFDO1FBRUgsSUFBSSxtQkFBbUIsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FDaEQsS0FBSyxDQUFDLEVBQUUsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBRSxDQUFDLFVBQVUsS0FBSyw0QkFBYyxDQUFDLElBQUksQ0FDbkUsQ0FBQztRQUVGLElBQUksa0JBQWtCLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxFQUFFO1lBQ2pDLG1CQUFtQixHQUFHLENBQUMsQ0FBQyxZQUFZLENBQUMsa0JBQWtCLEVBQUUsbUJBQW1CLENBQUMsQ0FBQztTQUMvRTtRQUVELE9BQU8sbUJBQW1CLENBQUM7SUFDN0IsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSyxtQkFBbUIsQ0FDekIsU0FBaUIsRUFDakIsY0FBd0IsRUFDeEIsVUFBVSxHQUFHLElBQUksRUFDakIsR0FBYTtRQUViLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsRUFBRTtZQUM5QixPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDOUI7UUFFRCwwRkFBMEY7UUFDMUYsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ3hELElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRTtnQkFDdkIsT0FBTyxJQUFJLENBQUM7YUFDYjtZQUVELE1BQU0saUJBQWlCLEdBQUcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxjQUFjLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFFbkUsTUFBTSxPQUFPLEdBQUcsR0FBRztnQkFDakIsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLE1BQU0sS0FBSyxjQUFjLENBQUMsTUFBTTtnQkFDcEQsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7WUFFakMsSUFBSSxPQUFPLElBQUksQ0FBQyxVQUFVLEVBQUU7Z0JBQzFCLE9BQU8sT0FBTyxDQUFDO2FBQ2hCO1lBRUQsTUFBTSxNQUFNLENBQUMsTUFBTSxDQUNqQixnQkFBZ0IsRUFDaEIscUJBQXFCLEdBQUcsQ0FBQyxDQUFDLENBQUMsOEJBQThCLENBQUMsQ0FBQyxDQUFDLHNCQUFzQixJQUFJLENBQ3ZGLENBQUM7UUFDSixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSSxXQUFXLENBQ2hCLFNBQWlCLEVBQ2pCLFlBQTZCLEVBQzdCLFVBQVUsR0FBRyxJQUFJO1FBRWpCLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsRUFBRTtZQUM5QixPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDL0I7UUFFRCxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxHQUFHLFNBQVMsR0FBRyxHQUFHLEdBQUcsV0FBVyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsRUFBRSxHQUFHLEVBQUU7WUFDbEYsT0FBTyxXQUFXLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQ2xFLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsVUFBVSxFQUFFLFVBQVUsQ0FBQyxDQUFDO1lBQzFFLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxZQUFZLENBQUMsU0FBaUIsRUFBRSxjQUFzQztRQUMzRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDOUIsT0FBTyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUM7U0FDM0I7UUFFRCxPQUFPLFFBQVEsQ0FBQyxHQUFHLENBQUMsY0FBYyxFQUFFLFlBQVksQ0FBQyxFQUFFLENBQ2pELElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxFQUFFLFlBQVksQ0FBQyxDQUMxQyxDQUFDLE1BQU0sRUFBRSxDQUFDO0lBQ2IsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ssb0JBQW9CLENBQzFCLFNBQWlCLEVBQ2pCLElBQWM7UUFFZCxPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUU7YUFDdEIsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNULElBQUksSUFBSSxLQUFLLE1BQU0sRUFBRTtnQkFDbkIsT0FBTyxRQUFRLENBQUMsS0FBSyxDQUFDO29CQUNwQixDQUFDLHlCQUFXLENBQUMsUUFBUSxDQUFDLEVBQUUsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFNBQVMsQ0FBQztvQkFDMUQsQ0FBQyx5QkFBVyxDQUFDLFFBQVEsQ0FBQyxFQUFFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLENBQUM7b0JBQzFELENBQUMseUJBQVcsQ0FBQyxRQUFRLENBQUMsRUFBRSxJQUFJLENBQUMsbUJBQW1CLENBQUMsU0FBUyxDQUFDO2lCQUM1RCxDQUFDLENBQUM7YUFDSjtpQkFBTTtnQkFDTCxPQUFPLFFBQVEsQ0FBQyxLQUFLLENBQUM7b0JBQ3BCLENBQUMseUJBQVcsQ0FBQyxRQUFRLENBQUMsRUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQztvQkFDckQsQ0FBQyx5QkFBVyxDQUFDLFFBQVEsQ0FBQyxFQUFFLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDO29CQUNyRCxDQUFDLHlCQUFXLENBQUMsUUFBUSxDQUFDLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUM7aUJBQ3ZELENBQUMsQ0FBQzthQUNKO1FBQ0gsQ0FBQyxDQUFDO2FBQ0QsSUFBSSxDQUFDLHNCQUFzQixDQUFDLEVBQUU7WUFDN0IsTUFBTSxzQkFBc0IsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDO1lBQ3pDLEtBQUssTUFBTSxXQUFXLElBQUk7Z0JBQ3hCLHlCQUFXLENBQUMsUUFBUTtnQkFDcEIseUJBQVcsQ0FBQyxRQUFRO2dCQUNwQix5QkFBVyxDQUFDLFFBQVE7YUFDckIsRUFBRTtnQkFDRCw4REFBOEQ7Z0JBQzlELHlEQUF5RDtnQkFDekQsYUFBYTtnQkFDYixNQUFNLGlCQUFpQixHQUFHLHNCQUFzQixDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUM5RCxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFO29CQUN2QyxzQkFBc0IsQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLFdBQVcsQ0FBQyxDQUFDO2lCQUM5QztxQkFBTTtvQkFDTCxDQUFDLENBQUMsT0FBTyxDQUFDLGlCQUFpQixFQUFFLGNBQWMsQ0FBQyxFQUFFO3dCQUM1QyxzQkFBc0IsQ0FBQyxHQUFHLENBQUMsY0FBYyxFQUFFLFdBQVcsQ0FBQyxDQUFDO29CQUMxRCxDQUFDLENBQUMsQ0FBQztpQkFDSjthQUNGO1lBQ0QsT0FBTyxzQkFBc0IsQ0FBQztRQUNoQyxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSSxpQkFBaUIsQ0FDdEIsU0FBaUIsRUFDakIsSUFBYyxFQUNkLE1BQW9CO1FBRXBCLE9BQU8sSUFBSSxDQUFDLG9CQUFvQixDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsRUFBRTtZQUN6RSxNQUFNLGFBQWEsR0FBZ0IsaUJBQWlCLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxJQUFJLHlCQUFXLENBQUMsSUFBSSxDQUFDO1lBQ2xGLE1BQU0sZ0JBQWdCLEdBQWlDLEVBQUUsQ0FBQztZQUUxRCxLQUFLLE1BQU0sVUFBVSxJQUFJLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Z0JBQ3ZDLE1BQU0sTUFBTSxHQUFnQixpQkFBaUIsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxJQUFJLGFBQWEsQ0FBQztnQkFDckYsSUFBSSxNQUFNLEtBQUssTUFBTSxJQUFJLFVBQVUsQ0FBQyxVQUFVLEtBQUssNEJBQWMsQ0FBQyxJQUFJLEVBQUU7b0JBQ3RFLE1BQU0sVUFBVSxHQUFHLFVBQVUsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUM3QyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxVQUFVLEtBQUssNEJBQWMsQ0FBQyxJQUFJLENBQzFDLENBQUM7b0JBQ0YsZ0JBQWdCLENBQUMsSUFBSSxDQUFDO3dCQUNwQixLQUFLLEVBQUUsVUFBVSxDQUFDLEtBQUs7d0JBQ3ZCLE1BQU0sRUFBRSxNQUFNO3dCQUNkLFVBQVUsRUFBRSxVQUFVLENBQUMsVUFBVTt3QkFDakMsVUFBVSxFQUFFLFVBQVU7cUJBQ3ZCLENBQUMsQ0FBQztpQkFDSjthQUNGO1lBRUQsT0FBTztnQkFDTCxHQUFHLEVBQUU7b0JBQ0gsTUFBTSxFQUFFLGFBQWE7aUJBQ3RCO2dCQUNELE9BQU8sRUFBRSxnQkFBZ0I7YUFDMUIsQ0FBQztRQUNKLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksa0JBQWtCLENBQUMsU0FBaUI7UUFDekMsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFVBQVUsRUFBRSxFQUFFO1lBQzlDLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQztTQUM3QjtRQUVELElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsRUFBRTtZQUM5QixPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1NBQ2hDO1FBRUQsT0FBTyxJQUFJLENBQUMsc0JBQXNCLENBQUMsU0FBUyxFQUFFLGNBQWMsRUFBRSxNQUFNLENBQUMsQ0FBQztJQUN4RSxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNLLG1CQUFtQixDQUN6QixTQUFpQixFQUNqQixjQUF3QixFQUN4QixVQUFVLEdBQUcsSUFBSSxFQUNqQixHQUFhO1FBRWIsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFVBQVUsRUFBRSxFQUFFO1lBQzlDLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUNoQztRQUVELElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsRUFBRTtZQUM5QixPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDL0I7UUFFRCwwRkFBMEY7UUFDMUYsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ3hELElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRTtnQkFDdkIsT0FBTyxJQUFJLENBQUM7YUFDYjtZQUVELE1BQU0saUJBQWlCLEdBQUcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxjQUFjLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFFbkUsTUFBTSxPQUFPLEdBQUcsR0FBRztnQkFDakIsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLE1BQU0sS0FBSyxjQUFjLENBQUMsTUFBTTtnQkFDcEQsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7WUFFakMsSUFBSSxPQUFPLElBQUksQ0FBQyxVQUFVLEVBQUU7Z0JBQzFCLE9BQU8sT0FBTyxDQUFDO2FBQ2hCO1lBRUQsTUFBTSxNQUFNLENBQUMsTUFBTSxDQUNqQixpQkFBaUIsRUFDakIscUJBQXFCLEdBQUcsQ0FBQyxDQUFDLENBQUMsOEJBQThCLENBQUMsQ0FBQyxDQUFDLHNCQUFzQixJQUFJLENBQ3ZGLENBQUM7UUFDSixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSSxXQUFXLENBQ2hCLFNBQWlCLEVBQ2pCLFlBQTZCLEVBQzdCLFVBQVUsR0FBRyxJQUFJO1FBRWpCLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxVQUFVLEVBQUUsRUFBRTtZQUM5QyxPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDaEM7UUFFRCxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDOUIsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQy9CO1FBRUQsT0FBTyxXQUFXLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDbEUsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxVQUFVLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFDMUUsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxpQkFBaUIsQ0FBQyxTQUFpQixFQUFFLFVBQW9CO1FBQzlELE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLFNBQVMsRUFBRSxVQUFVLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO0lBQzlFLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLG1CQUFtQixDQUFDLFNBQWlCO1FBQzFDLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxVQUFVLEVBQUUsRUFBRTtZQUM5QyxPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUM7U0FDN0I7UUFFRCxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDaEMsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztTQUNoQztRQUVELE9BQU8sSUFBSSxDQUFDLHNCQUFzQixDQUFDLFNBQVMsRUFBRSxjQUFjLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFDekUsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSyxvQkFBb0IsQ0FDMUIsU0FBaUIsRUFDakIsY0FBd0IsRUFDeEIsVUFBVSxHQUFHLElBQUksRUFDakIsR0FBYTtRQUViLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxVQUFVLEVBQUUsRUFBRTtZQUM5QyxPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDaEM7UUFFRCxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDaEMsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQy9CO1FBRUQsMkZBQTJGO1FBQzNGLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRTtZQUMxRCxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUU7Z0JBQ3hCLE9BQU8sSUFBSSxDQUFDO2FBQ2I7WUFFRCxNQUFNLGtCQUFrQixHQUFHLENBQUMsQ0FBQyxZQUFZLENBQUMsY0FBYyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1lBRXJFLE1BQU0sU0FBUyxHQUFHLEdBQUc7Z0JBQ25CLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxNQUFNLEtBQUssY0FBYyxDQUFDLE1BQU07Z0JBQ3JELENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1lBRWxDLElBQUksU0FBUyxJQUFJLENBQUMsVUFBVSxFQUFFO2dCQUM1QixPQUFPLFNBQVMsQ0FBQzthQUNsQjtZQUVELE1BQU0sTUFBTSxDQUFDLE1BQU0sQ0FDakIsaUJBQWlCLEVBQ2pCLHVCQUF1QixHQUFHLENBQUMsQ0FBQyxDQUFDLCtCQUErQixDQUFDLENBQUMsQ0FBQyx1QkFBdUIsSUFBSSxDQUMzRixDQUFDO1FBQ0osQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0ksYUFBYSxDQUNsQixTQUFpQixFQUNqQixZQUE2QixFQUM3QixVQUFVLEdBQUcsSUFBSTtRQUVqQixJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUMsVUFBVSxFQUFFLEVBQUU7WUFDOUMsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQ2hDO1FBRUQsSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQ2hDLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUMvQjtRQUVELE9BQU8sV0FBVyxDQUFDLHlCQUF5QixDQUFDLFNBQVMsRUFBRSxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDaEYsT0FBTyxJQUFJLENBQUMsb0JBQW9CLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxVQUFVLEVBQUUsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUMzRSxpQkFBaUIsQ0FBQyxFQUFFO2dCQUNsQixJQUFJLENBQUMsaUJBQWlCLEVBQUU7b0JBQ3RCLE9BQU8sS0FBSyxDQUFDO2lCQUNkO2dCQUVELE9BQU8sSUFBSSxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLEVBQUU7b0JBQzFELElBQUksY0FBYyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRTt3QkFDN0IsT0FBTyxJQUFJLENBQUM7cUJBQ2I7b0JBRUQsTUFBTSxTQUFTLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUM7eUJBQzVCLEdBQUcsQ0FBQyw0QkFBNEIsQ0FBQzt3QkFDbEMsMERBQTBEO3dCQUMxRCxhQUFhO3lCQUNaLEdBQUcsQ0FBQyxVQUFVLENBQUM7eUJBQ2YsVUFBVSxDQUFDLGNBQWMsQ0FBQzt5QkFDMUIsT0FBTyxFQUFFO3lCQUNULEtBQUssRUFBRSxDQUFDO29CQUVYLElBQUksQ0FBQyxTQUFTLElBQUksVUFBVSxFQUFFO3dCQUM1QixNQUFNLE1BQU0sQ0FBQyxNQUFNLENBQUMsaUJBQWlCLEVBQUUscUJBQXFCLENBQUMsQ0FBQztxQkFDL0Q7b0JBQ0QsT0FBTyxTQUFTLENBQUM7Z0JBQ25CLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxDQUNGLENBQUM7UUFDSixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSyxNQUFNLENBQUMsV0FBVyxDQUFDLFNBQWlCLEVBQUUsWUFBNkI7UUFDekUsSUFBSSxPQUFPLFlBQVksS0FBSyxRQUFRLEVBQUU7WUFDcEMsZUFBZTtZQUNmLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQztnQkFDdkIsR0FBRyxFQUFFLENBQUMsWUFBWSxDQUFDO2dCQUNuQixTQUFTLEVBQUUsU0FBUzthQUNyQixDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ1g7YUFBTTtZQUNMLHdCQUF3QjtZQUN4QixPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7U0FDdkM7SUFDSCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSyxNQUFNLENBQUMseUJBQXlCLENBQ3RDLFNBQWlCLEVBQ2pCLFlBQTZCO1FBRTdCLE9BQU8sV0FBVyxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ2xFLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRTtnQkFDOUQsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsVUFBVSxJQUFJLEVBQUUsQ0FBQztnQkFDeEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLEdBQUcsVUFBVSxDQUFDO2dCQUM3QyxPQUFPLElBQUksQ0FBQztZQUNkLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0ksS0FBSyxDQUFDLGFBQWEsQ0FBQyxTQUFpQjtRQUMxQyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDOUIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ2Q7UUFFRCxNQUFNLENBQUMsYUFBYSxFQUFFLFVBQVUsQ0FBQyxHQUFHLE1BQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQztZQUNwRCxJQUFJLENBQUMsc0JBQXNCLENBQUMsU0FBUyxFQUFFLFVBQVUsRUFBRSxNQUFNLENBQUM7WUFDMUQsa0JBQWtCLENBQUMsU0FBUyxDQUFDLFNBQVMsRUFBRSx3QkFBVSxDQUFDLElBQUksQ0FBQztTQUN6RCxDQUFDLENBQUM7UUFFSCxJQUFJLGNBQWMsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FDM0MsS0FBSyxDQUFDLEVBQUUsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBRSxDQUFDLFVBQVUsS0FBSyw0QkFBYyxDQUFDLElBQUksQ0FDbkUsQ0FBQztRQUVGLElBQUksYUFBYSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRTtZQUM1QixjQUFjLEdBQUcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxhQUFhLEVBQUUsY0FBYyxDQUFDLENBQUM7U0FDaEU7UUFFRCxPQUFPLGNBQWMsQ0FBQztJQUN4QixDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0ksV0FBVyxDQUFDLFNBQWlCLEVBQUUsUUFBZ0IsRUFBRSxVQUFVLEdBQUcsSUFBSTtRQUN2RSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDOUIsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQzlCO1FBRUQsZ0NBQWdDO1FBQ2hDLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUU7WUFDeEQsTUFBTSxPQUFPLEdBQUcsYUFBYSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLGFBQWEsRUFBRSxRQUFRLENBQUMsQ0FBQztZQUVoRixJQUFJLENBQUMsT0FBTyxJQUFJLFVBQVUsRUFBRTtnQkFDMUIsTUFBTSxNQUFNLENBQUMsTUFBTSxDQUFDLGdCQUFnQixFQUFFLG1CQUFtQixDQUFDLENBQUM7YUFDNUQ7WUFDRCxPQUFPLE9BQU8sQ0FBQztRQUNqQixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSSxXQUFXLENBQ2hCLFNBQWlCLEVBQ2pCLFlBQTZCLEVBQzdCLFVBQVUsR0FBRyxJQUFJO1FBRWpCLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsRUFBRTtZQUM5QixPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDL0I7UUFFRCxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxHQUFHLFNBQVMsR0FBRyxHQUFHLEdBQUcsV0FBVyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsRUFBRSxHQUFHLEVBQUU7WUFDbEYsT0FBTyxXQUFXLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQ2xFLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLElBQUksRUFBRSxVQUFVLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUU7b0JBQzNFLElBQUksQ0FBQyxXQUFXLEVBQUU7d0JBQ2hCLE9BQU8sS0FBSyxDQUFDO3FCQUNkO29CQUVELDhFQUE4RTtvQkFDOUUsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRTt3QkFDL0UsSUFBSSxDQUFDLGFBQWEsRUFBRTs0QkFDbEIsT0FBTyxLQUFLLENBQUM7eUJBQ2Q7d0JBRUQsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLFVBQVUsQ0FBQyxDQUFDO29CQUM5RCxDQUFDLENBQUMsQ0FBQztnQkFDTCxDQUFDLENBQUMsQ0FBQztZQUNMLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxhQUFhLENBQUMsU0FBaUI7UUFDcEMsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFVBQVUsRUFBRSxFQUFFO1lBQzlDLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQztTQUM3QjtRQUVELElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsRUFBRTtZQUM5QixPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1NBQ2hDO1FBRUQsT0FBTyxJQUFJLENBQUMsc0JBQXNCLENBQUMsU0FBUyxFQUFFLFVBQVUsRUFBRSxNQUFNLENBQUMsQ0FBQztJQUNwRSxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0ksV0FBVyxDQUFDLFNBQWlCLEVBQUUsUUFBZ0IsRUFBRSxVQUFVLEdBQUcsSUFBSTtRQUN2RSxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUMsVUFBVSxFQUFFLEVBQUU7WUFDOUMsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQ2hDO1FBRUQsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQzlCLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUMvQjtRQUVELGdDQUFnQztRQUNoQyxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFO1lBQ3hELE1BQU0sT0FBTyxHQUFHLGFBQWEsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxhQUFhLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFFaEYsSUFBSSxDQUFDLE9BQU8sSUFBSSxVQUFVLEVBQUU7Z0JBQzFCLE1BQU0sTUFBTSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsRUFBRSxtQkFBbUIsQ0FBQyxDQUFDO2FBQzdEO1lBQ0QsT0FBTyxPQUFPLENBQUM7UUFDakIsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0ksV0FBVyxDQUNoQixTQUFpQixFQUNqQixZQUE2QixFQUM3QixVQUFVLEdBQUcsSUFBSTtRQUVqQixJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUMsVUFBVSxFQUFFLEVBQUU7WUFDOUMsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQ2hDO1FBRUQsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQzlCLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUMvQjtRQUVELE9BQU8sV0FBVyxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ2xFLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLElBQUksRUFBRSxVQUFVLENBQUMsQ0FBQztRQUM1RCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLGNBQWMsQ0FBQyxTQUFpQjtRQUNyQyxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUMsVUFBVSxFQUFFLEVBQUU7WUFDOUMsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1NBQzdCO1FBRUQsSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQ2hDLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7U0FDaEM7UUFFRCxPQUFPLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxTQUFTLEVBQUUsVUFBVSxFQUFFLE9BQU8sQ0FBQyxDQUFDO0lBQ3JFLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSSxhQUFhLENBQUMsU0FBaUIsRUFBRSxRQUFnQixFQUFFLFVBQVUsR0FBRyxJQUFJO1FBQ3pFLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxVQUFVLEVBQUUsRUFBRTtZQUM5QyxPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDaEM7UUFFRCxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDaEMsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQy9CO1FBRUQsaUNBQWlDO1FBQ2pDLE9BQU8sSUFBSSxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLEVBQUU7WUFDMUQsTUFBTSxTQUFTLEdBQUcsY0FBYyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLGNBQWMsRUFBRSxRQUFRLENBQUMsQ0FBQztZQUVwRixJQUFJLENBQUMsU0FBUyxJQUFJLFVBQVUsRUFBRTtnQkFDNUIsTUFBTSxNQUFNLENBQUMsTUFBTSxDQUFDLGlCQUFpQixFQUFFLHFCQUFxQixDQUFDLENBQUM7YUFDL0Q7WUFDRCxPQUFPLFNBQVMsQ0FBQztRQUNuQixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSSxhQUFhLENBQ2xCLFNBQWlCLEVBQ2pCLFlBQTZCLEVBQzdCLFVBQVUsR0FBRyxJQUFJO1FBRWpCLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxVQUFVLEVBQUUsRUFBRTtZQUM5QyxPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDaEM7UUFFRCxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDaEMsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQy9CO1FBRUQsT0FBTyxXQUFXLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDbEUsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsSUFBSSxFQUFFLFVBQVUsQ0FBQyxDQUFDO1FBQzlELENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLFlBQVksQ0FBQyxTQUFpQixFQUFFLE9BQWUsRUFBRSxVQUFVLEdBQUcsSUFBSTtRQUN2RSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDOUIsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQy9CO1FBRUQsT0FBTyxJQUFJLENBQUMsc0JBQXNCLENBQUMsU0FBUyxFQUFFLE9BQU8sRUFBRSxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsRUFBRTtZQUNyRixpQ0FBaUM7WUFDakMsSUFBSSxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUU7Z0JBQy9CLE9BQU8sSUFBSSxDQUFDO2FBQ2I7WUFFRCx3REFBd0Q7WUFDeEQsSUFBSSxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQyxFQUFFO2dCQUMzQyxPQUFPLElBQUksQ0FBQzthQUNiO1lBRUQsSUFBSSxDQUFDLFVBQVUsRUFBRTtnQkFDZixPQUFPLEtBQUssQ0FBQzthQUNkO1lBQ0QsTUFBTSxNQUFNLENBQUMsTUFBTSxDQUFDLGdCQUFnQixFQUFFLHdDQUF3QyxPQUFPLEdBQUcsQ0FBQyxDQUFDO1FBQzVGLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7T0FTRztJQUNJLGNBQWMsQ0FDbkIsU0FBaUIsRUFDakIsUUFBVyxFQUNYLE9BR0M7UUFFRCxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLEVBQUUsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUNyRSxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLEVBQUUsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDckUsSUFDRSxPQUFPLENBQUMsWUFBWTtvQkFDcEIsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLE1BQU0sS0FBSyxLQUFLLENBQUMsTUFBTSxJQUFJLFFBQVEsQ0FBQyxLQUFLLENBQUMsTUFBTSxLQUFLLEtBQUssQ0FBQyxNQUFNLENBQUMsRUFDbEY7b0JBQ0EsUUFBUSxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUM7b0JBQ3BCLFFBQVEsQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDO29CQUNwQixPQUFPLFFBQVEsQ0FBQztpQkFDakI7Z0JBRUQsUUFBUSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7Z0JBQ3ZCLFFBQVEsQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO2dCQUV2QixzRUFBc0U7Z0JBQ3RFLDBFQUEwRTtnQkFDMUUsSUFBSSxPQUFPLENBQUMsdUJBQXVCLEVBQUU7b0JBQ25DLE1BQU0sV0FBVyxHQUFnQixJQUFJLEdBQUcsRUFBRSxDQUFDO29CQUUzQyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTt3QkFDckMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7d0JBQ2pDLFdBQVcsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO3FCQUNsQztvQkFFRCwwREFBMEQ7b0JBQzFELFFBQVEsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxFQUFFLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztpQkFDN0U7Z0JBRUQsT0FBTyxRQUFRLENBQUM7WUFDbEIsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLG1CQUFtQixDQUFtQixTQUFpQixFQUFFLEtBQVU7UUFDeEUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQzlCLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUNoQztRQUVELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxLQUFLLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUM5QyxPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDaEM7UUFFRCxPQUFPLFFBQVEsQ0FBQyxNQUFNLENBQ3BCLEtBQUssRUFDTCxDQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsRUFBRTtZQUNqQixPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7Z0JBQzlELElBQUksUUFBUSxFQUFFO29CQUNaLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7aUJBQ3JCO2dCQUNELE9BQU8sUUFBUSxDQUFDO1lBQ2xCLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxFQUNELEVBQVMsQ0FDVixDQUFDO0lBQ0osQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLG1CQUFtQixDQUFtQixTQUFpQixFQUFFLEtBQVU7UUFDeEUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQzlCLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUNoQztRQUVELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxLQUFLLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUM5QyxPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDaEM7UUFFRCxPQUFPLFFBQVEsQ0FBQyxNQUFNLENBQ3BCLEtBQUssRUFDTCxDQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsRUFBRTtZQUNqQixPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7Z0JBQzlELElBQUksUUFBUSxFQUFFO29CQUNaLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7aUJBQ3JCO2dCQUNELE9BQU8sUUFBUSxDQUFDO1lBQ2xCLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxFQUNELEVBQVMsQ0FDVixDQUFDO0lBQ0osQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksa0JBQWtCLENBQW1CLFNBQWlCLEVBQUUsS0FBVTtRQUN2RSxPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxFQUFFO1lBQ25FLE9BQU8sSUFBSSxDQUFDLGlCQUFpQixDQUFDLFNBQVMsRUFBRSxZQUFZLENBQUMsQ0FBQztRQUN6RCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLGtCQUFrQixDQUFtQixTQUFpQixFQUFFLEtBQVU7UUFDdkUsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsRUFBRTtZQUNuRSxPQUFPLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxTQUFTLEVBQUUsWUFBWSxDQUFDLENBQUM7UUFDNUQsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSyxvQkFBb0IsQ0FBbUIsU0FBaUIsRUFBRSxJQUFPO1FBQ3ZFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsRUFBRTtZQUM5QixPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDOUI7UUFFRCxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDeEQsSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxFQUFFO2dCQUN2QixPQUFPLElBQUksQ0FBQzthQUNiO1lBRUQsSUFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFDNUQsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLGlCQUFpQixDQUFtQixTQUFpQixFQUFFLElBQU87UUFDbkUsT0FBTyxJQUFJLENBQUMsb0JBQW9CLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRTtZQUNwRSxJQUFJLEdBQUcsSUFBSSxDQUFDLG9CQUFvQixDQUFDLFNBQVMsRUFBRSxZQUFZLENBQUMsQ0FBQztZQUUxRCxPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDaEQsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSyxnQkFBZ0IsQ0FBbUIsU0FBaUIsRUFBRSxJQUFPO1FBQ25FLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsRUFBRTtZQUM5QixPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDL0I7UUFFRCwyQ0FBMkM7UUFDM0MsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRTtZQUMvQyxPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDL0I7UUFFRCxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFO1lBQy9FLElBQUksQ0FBQyxVQUErQixDQUFDLE1BQU0sR0FBRyxjQUFjLENBQUM7WUFDOUQsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSSxZQUFZLENBQUMsU0FBaUIsRUFBRSxNQUFzQjtRQUMzRCxPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ2xDLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7Z0JBQzlDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUM7cUJBQ25CLE1BQU0sQ0FBQyxLQUFLLENBQUMsRUFBRTtvQkFDZCxnQ0FBZ0M7b0JBQ2hDLEtBQUssQ0FBQyxjQUFjLEdBQUcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsVUFBVSxFQUFFLEtBQUssQ0FBQyxjQUFjLENBQUMsQ0FBQztvQkFDakYsT0FBTyxLQUFLLENBQUMsY0FBYyxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUksUUFBUSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQzdFLENBQUMsQ0FBQztxQkFDRCxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUU7b0JBQ2Ysa0JBQWtCO29CQUNsQixPQUFPLEtBQUssQ0FBQyxRQUFRLEdBQUcsR0FBRyxHQUFHLEtBQUssQ0FBQyxjQUFjLENBQUM7Z0JBQ3JELENBQUMsQ0FBQztxQkFDRCxNQUFNLEVBQUU7cUJBQ1IsR0FBRyxDQUFDLFVBQVUsQ0FBQyxFQUFFO29CQUNoQixNQUFNLFdBQVcsR0FBRyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ2xDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxVQUFVLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO3dCQUMxQyxXQUFXLENBQUMsS0FBSyxJQUFJLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7d0JBQ3pDLFdBQVcsQ0FBQyxLQUFLLElBQUksVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztxQkFDMUM7b0JBQ0QsT0FBTyxXQUFXLENBQUM7Z0JBQ3JCLENBQUMsQ0FBQztxQkFDRCxLQUFLLEVBQUUsQ0FBQztZQUNiLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNLLEtBQUssQ0FBQyxRQUFRLENBQ3BCLFNBQWlCO1FBT2pCLE1BQU0sQ0FBQyxrQkFBa0IsRUFBRSxhQUFhLEVBQUUsVUFBVSxFQUFFLFVBQVUsQ0FBQyxHQUFHLE1BQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQztZQUNwRixJQUFJLENBQUMsa0JBQWtCLENBQUMsU0FBUyxDQUFDO1lBQ2xDLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDO1lBQzdCLGtCQUFrQixDQUFDLFNBQVMsQ0FBQyxTQUFTLEVBQUUsd0JBQVUsQ0FBQyxJQUFJLENBQUM7WUFDeEQsa0JBQWtCLENBQUMsU0FBUyxDQUFDLFNBQVMsRUFBRSx3QkFBVSxDQUFDLElBQUksQ0FBQztTQUN6RCxDQUFDLENBQUM7UUFFSCxJQUFJLG1CQUFtQixHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUNoRCxLQUFLLENBQUMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFFLENBQUMsVUFBVSxLQUFLLDRCQUFjLENBQUMsSUFBSSxDQUNuRSxDQUFDO1FBRUYsSUFBSSxjQUFjLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQzNDLEtBQUssQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUUsQ0FBQyxVQUFVLEtBQUssNEJBQWMsQ0FBQyxJQUFJLENBQ25FLENBQUM7UUFFRixJQUFJLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRTtZQUNqQyxtQkFBbUIsR0FBRyxDQUFDLENBQUMsWUFBWSxDQUFDLGtCQUFrQixFQUFFLG1CQUFtQixDQUFDLENBQUM7U0FDL0U7UUFFRCxJQUFJLGFBQWEsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUU7WUFDNUIsY0FBYyxHQUFHLENBQUMsQ0FBQyxZQUFZLENBQUMsYUFBYSxFQUFFLGNBQWMsQ0FBQyxDQUFDO1NBQ2hFO1FBRUQsSUFBSSxDQUFDLENBQUM7UUFDTixNQUFNLE1BQU0sR0FBRztZQUNiLFdBQVcsRUFBRSxFQUF5QjtZQUN0QyxPQUFPLEVBQUUsRUFBeUI7WUFDbEMsVUFBVSxFQUFFLG1CQUFtQjtZQUMvQixLQUFLLEVBQUUsY0FBYztTQUN0QixDQUFDO1FBQ0YsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxtQkFBbUIsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDL0MsTUFBTSxDQUFDLFdBQVcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQztTQUNuRDtRQUNELEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsY0FBYyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtZQUMxQyxNQUFNLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQztTQUMxQztRQUVELE9BQU8sTUFBTSxDQUFDO0lBQ2hCLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ksY0FBYyxDQUFDLE1BQWlDO1FBQ3JELE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxFQUFFLEtBQUssTUFBTSxDQUFDLE1BQU0sQ0FBQztRQUMzQyxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ2IsTUFBTSxNQUFNLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLENBQUM7U0FDeEM7SUFDSCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxxQkFBcUIsQ0FBQyxhQUFrQztRQUM3RCxPQUFPLHFCQUFxQixDQUFDLFFBQVEsQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQ2hFLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLHFCQUFxQixDQUMxQixhQUFrQyxFQUNsQyxXQUFtQjtRQUVuQixPQUFPLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxhQUFhLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDNUQsSUFBSSxXQUFXLEtBQUssTUFBTSxJQUFJLENBQUMsS0FBSyxFQUFFO2dCQUNwQyxNQUFNLE1BQU0sQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsNkNBQTZDLENBQUMsQ0FBQzthQUN0RjtZQUNELElBQUksV0FBVyxLQUFLLE9BQU8sSUFBSSxLQUFLLEtBQUssT0FBTyxJQUFJLEtBQUssS0FBSyxPQUFPLEVBQUU7Z0JBQ3JFLE1BQU0sTUFBTSxDQUFDLE1BQU0sQ0FDakIsaUJBQWlCLEVBQ2pCLHVEQUF1RCxDQUN4RCxDQUFDO2FBQ0g7WUFDRCxJQUFJLFdBQVcsS0FBSyxPQUFPLElBQUksS0FBSyxLQUFLLE9BQU8sRUFBRTtnQkFDaEQsTUFBTSxNQUFNLENBQUMsTUFBTSxDQUFDLGlCQUFpQixFQUFFLDhDQUE4QyxDQUFDLENBQUM7YUFDeEY7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLG9CQUFvQixDQUE4QixTQUFpQixFQUFFLElBQU87UUFDakYsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ2xFLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLG9CQUFvQixDQUE4QixTQUFpQixFQUFFLElBQU87UUFDakYsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ2xFLENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNJLEtBQUssQ0FBQyxTQUFTLENBQ3BCLFVBQWtCLEVBQ2xCLFNBQWtCLEVBQ2xCLFVBQVUsR0FBRyxJQUFJO1FBRWpCLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDakMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLEVBQUU7Z0JBQy9CLE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsVUFBVSxHQUFHLFVBQVUsR0FBRyxtQkFBbUIsRUFBRSxJQUFJLENBQUMsQ0FBQzthQUNyRjtZQUVELE9BQU8sSUFBSSxDQUFDLHNCQUFzQixDQUFDLFNBQVMsRUFBRSxRQUFRLEVBQUUsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFO2dCQUMzRSxJQUFJLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUU7b0JBQ3RCLE9BQU8sSUFBSSxDQUFDO2lCQUNiO2dCQUVELHNGQUFzRjtnQkFDdEYsTUFBTSxXQUFXLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDO29CQUMxRSxDQUFDLENBQUMsT0FBTyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUM7b0JBQzFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDO2dCQUVqQixNQUFNLFNBQVMsR0FBRyxDQUFDLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRSxXQUFXLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO2dCQUVsRSxJQUFJLFNBQVMsSUFBSSxDQUFDLFVBQVUsRUFBRTtvQkFDNUIsT0FBTyxTQUFTLENBQUM7aUJBQ2xCO2dCQUVELElBQUksYUFBYSxHQUFHLEVBQUUsQ0FBQztnQkFDdkIsSUFBSSxTQUFTLElBQUksU0FBUyxLQUFLLEdBQUcsRUFBRTtvQkFDbEMsYUFBYSxHQUFHLHVCQUF1QixDQUFDO2lCQUN6QztxQkFBTSxJQUFJLFNBQVMsRUFBRTtvQkFDcEIsYUFBYSxHQUFHLGtCQUFrQixHQUFHLFNBQVMsR0FBRyxHQUFHLENBQUM7aUJBQ3REO3FCQUFNO29CQUNMLGFBQWEsR0FBRyxzQkFBc0IsQ0FBQztpQkFDeEM7Z0JBRUQsTUFBTSxNQUFNLENBQUMsTUFBTSxDQUNqQixXQUFXLEVBQ1gsd0JBQXdCLEdBQUcsVUFBVSxHQUFHLEdBQUcsR0FBRyxhQUFhLENBQzVELENBQUM7WUFDSixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNLLE1BQU0sQ0FBQyxXQUFXLENBQUMsU0FBaUIsRUFBRSxZQUE2QjtRQUN6RSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLEVBQUU7WUFDL0IsT0FBTyxNQUFNLENBQUMsU0FBUyxDQUFDLGdCQUFnQixFQUFFLGlCQUFpQixFQUFFLElBQUksQ0FBQyxDQUFDO1NBQ3BFO1FBRUQsTUFBTSxJQUFJLEdBQUcsT0FBTyxZQUFZLENBQUM7UUFDakMsSUFBSSxJQUFJLEtBQUssUUFBUSxFQUFFO1lBQ3JCLFlBQVk7WUFDWixPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBQyxHQUFHLEVBQUUsQ0FBQyxZQUFzQixDQUFDLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ3hGO2FBQU07WUFDTCxzQkFBc0I7WUFDdEIsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLFlBQXNCLENBQUMsQ0FBQztTQUNqRDtJQUNILENBQUM7SUFFRDs7Ozs7T0FLRztJQUNLLE1BQU0sQ0FBQyxNQUFNLENBQUMsWUFBc0M7UUFDMUQsTUFBTSxJQUFJLEdBQUcsT0FBTyxZQUFZLENBQUM7UUFDakMsSUFBSSxJQUFJLEtBQUssUUFBUSxFQUFFO1lBQ3JCLE9BQU8sWUFBc0IsQ0FBQztTQUMvQjthQUFNO1lBQ0wsT0FBUSxZQUFnQyxDQUFDLEVBQUUsQ0FBQztTQUM3QztJQUNILENBQUM7Q0FDRjtBQXAwQ0Qsa0NBbzBDQyJ9