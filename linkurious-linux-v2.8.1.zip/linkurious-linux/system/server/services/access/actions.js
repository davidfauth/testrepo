"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2015-06-19.
 */
const _ = require("lodash");
/**
 * Actions that can be set to a custom group.
 */
const PUBLIC_ACTIONS = [
    {
        key: 'admin.connect',
        description: 'Connect the data-source and read the configuration'
    },
    {
        key: 'admin.index',
        description: 'Index the data-source and read the configuration'
    },
    {
        key: 'admin.users',
        description: 'Manage the users in the data-source'
    },
    {
        key: 'admin.alerts',
        description: 'Manage the alerts in the data-source'
    },
    {
        key: 'admin.report',
        description: 'Generate analytics report'
    },
    {
        key: 'runQuery',
        description: 'Execute a saved query'
    },
    {
        key: 'rawReadQuery',
        description: 'Create a read query'
    },
    {
        key: 'rawWriteQuery',
        description: 'Create a read/write query'
    },
    {
        key: 'admin.styles',
        description: 'Reset design and captions of all sandboxes of the given data-source'
    },
    {
        key: 'admin.schema',
        description: 'Edit the schema of a given data-source'
    }
];
/**
 * Actions that can't be set to a custom group.
 */
const PRIVATE_ACTIONS = [
    {
        key: 'admin.app',
        description: 'Manage applications'
    },
    {
        key: 'admin.users.delete',
        description: 'Delete users'
    },
    {
        key: 'admin.config',
        description: 'Set the configuration'
    }
];
const IMPLICIT_ACTIONS = new Map();
// runQuery can be performed by user with action rawReadQuery or rawWriteQuery
IMPLICIT_ACTIONS.set('runQuery', ['runQuery', 'rawReadQuery', 'rawWriteQuery']);
// rawReadQuery can be performed by user with action rawWriteQuery
IMPLICIT_ACTIONS.set('rawReadQuery', ['rawReadQuery', 'rawWriteQuery']);
const EXPLICIT_ACTIONS = new Map();
for (const implicitAction of IMPLICIT_ACTIONS.keys()) {
    for (const explicitAction of IMPLICIT_ACTIONS.get(implicitAction)) {
        if (!EXPLICIT_ACTIONS.get(explicitAction)) {
            EXPLICIT_ACTIONS.set(explicitAction, []);
        }
        EXPLICIT_ACTIONS.get(explicitAction).push(implicitAction);
    }
}
const PUBLIC_MAP = _.keyBy(PUBLIC_ACTIONS, 'key');
const PRIVATE_MAP = _.keyBy(PRIVATE_ACTIONS, 'key');
module.exports = {
    // all action keys for a custom group
    PUBLIC_ACTIONS: _.map(PUBLIC_ACTIONS, 'key'),
    IMPLICIT_ACTIONS: IMPLICIT_ACTIONS,
    EXPLICIT_ACTIONS: EXPLICIT_ACTIONS,
    /**
     * Return true if this action key exists.
     *
     * @param key The action key
     */
    exists: (key) => !!PUBLIC_MAP[key] || !!PRIVATE_MAP[key]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWN0aW9ucy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9zZXJ2aWNlcy9hY2Nlc3MvYWN0aW9ucy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7O0dBS0c7QUFDSCw0QkFBNEI7QUFFNUI7O0dBRUc7QUFDSCxNQUFNLGNBQWMsR0FBRztJQUNyQjtRQUNFLEdBQUcsRUFBRSxlQUFlO1FBQ3BCLFdBQVcsRUFBRSxvREFBb0Q7S0FDbEU7SUFDRDtRQUNFLEdBQUcsRUFBRSxhQUFhO1FBQ2xCLFdBQVcsRUFBRSxrREFBa0Q7S0FDaEU7SUFDRDtRQUNFLEdBQUcsRUFBRSxhQUFhO1FBQ2xCLFdBQVcsRUFBRSxxQ0FBcUM7S0FDbkQ7SUFDRDtRQUNFLEdBQUcsRUFBRSxjQUFjO1FBQ25CLFdBQVcsRUFBRSxzQ0FBc0M7S0FDcEQ7SUFDRDtRQUNFLEdBQUcsRUFBRSxjQUFjO1FBQ25CLFdBQVcsRUFBRSwyQkFBMkI7S0FDekM7SUFDRDtRQUNFLEdBQUcsRUFBRSxVQUFVO1FBQ2YsV0FBVyxFQUFFLHVCQUF1QjtLQUNyQztJQUNEO1FBQ0UsR0FBRyxFQUFFLGNBQWM7UUFDbkIsV0FBVyxFQUFFLHFCQUFxQjtLQUNuQztJQUNEO1FBQ0UsR0FBRyxFQUFFLGVBQWU7UUFDcEIsV0FBVyxFQUFFLDJCQUEyQjtLQUN6QztJQUNEO1FBQ0UsR0FBRyxFQUFFLGNBQWM7UUFDbkIsV0FBVyxFQUFFLHFFQUFxRTtLQUNuRjtJQUNEO1FBQ0UsR0FBRyxFQUFFLGNBQWM7UUFDbkIsV0FBVyxFQUFFLHdDQUF3QztLQUN0RDtDQUNGLENBQUM7QUFFRjs7R0FFRztBQUNILE1BQU0sZUFBZSxHQUFHO0lBQ3RCO1FBQ0UsR0FBRyxFQUFFLFdBQVc7UUFDaEIsV0FBVyxFQUFFLHFCQUFxQjtLQUNuQztJQUNEO1FBQ0UsR0FBRyxFQUFFLG9CQUFvQjtRQUN6QixXQUFXLEVBQUUsY0FBYztLQUM1QjtJQUNEO1FBQ0UsR0FBRyxFQUFFLGNBQWM7UUFDbkIsV0FBVyxFQUFFLHVCQUF1QjtLQUNyQztDQUNGLENBQUM7QUFFRixNQUFNLGdCQUFnQixHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7QUFDbkMsOEVBQThFO0FBQzlFLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxVQUFVLEVBQUUsY0FBYyxFQUFFLGVBQWUsQ0FBQyxDQUFDLENBQUM7QUFDaEYsa0VBQWtFO0FBQ2xFLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxjQUFjLEVBQUUsQ0FBQyxjQUFjLEVBQUUsZUFBZSxDQUFDLENBQUMsQ0FBQztBQUV4RSxNQUFNLGdCQUFnQixHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7QUFDbkMsS0FBSyxNQUFNLGNBQWMsSUFBSSxnQkFBZ0IsQ0FBQyxJQUFJLEVBQUUsRUFBRTtJQUNwRCxLQUFLLE1BQU0sY0FBYyxJQUFJLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsRUFBRTtRQUNqRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxFQUFFO1lBQ3pDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxjQUFjLEVBQUUsRUFBRSxDQUFDLENBQUM7U0FDMUM7UUFDRCxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO0tBQzNEO0NBQ0Y7QUFFRCxNQUFNLFVBQVUsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLGNBQWMsRUFBRSxLQUFLLENBQUMsQ0FBQztBQUNsRCxNQUFNLFdBQVcsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLGVBQWUsRUFBRSxLQUFLLENBQUMsQ0FBQztBQUVwRCxpQkFBUztJQUNQLHFDQUFxQztJQUNyQyxjQUFjLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxjQUFjLEVBQUUsS0FBSyxDQUFDO0lBQzVDLGdCQUFnQixFQUFFLGdCQUFnQjtJQUNsQyxnQkFBZ0IsRUFBRSxnQkFBZ0I7SUFFbEM7Ozs7T0FJRztJQUNILE1BQU0sRUFBRSxDQUFDLEdBQVcsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQztDQUNqRSxDQUFDIn0=