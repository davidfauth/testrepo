/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-12-04.
 */
'use strict';
const _ = require('lodash');
const Promise = require('bluebird');
const basicAuth = require('basic-auth');
const LKE = require('../index');
const OldGroupDAO = LKE.getOldGroupDAO();
const Errors = LKE.getErrors();
const Application = LKE.getApplication();
const Config = LKE.getConfig();
const Db = LKE.getSqlDb();
const Utils = LKE.getUtils();
const Log = LKE.getLogger(__filename);
const UserDAO = LKE.getUserDAO();
const { WrappedUser } = require('./WrappedUser');
const AuthProviderWrapper = require('./provider/AuthProviderWrapper');
const SessionStore = require('./SessionStore');
const API = require('../webServer/api');
const UserCache = require('./UserCache');
/**
 * @dokapi access.groupmapping
 *
 * If an external source already organizes users in groups, it's possible to use this information to map automatically
 * external groups to Linkurious groups. To do so, you have to set the `access.externalUsersGroupMapping` configuration key
 * to be an object with the external group IDs as keys and the internal group IDs as values.
 *
 * For example, if we want to provide group mapping for Microsoft Active Directory:
 * ```json
 * { // under the access configuration key
 *   // ...
 *   "externalUsersGroupMapping": {
 *     "Administrators": 1 // any Active Directory admin is a Linkurious admin
 *   }
 *   // ...
 * }
 * ```
 *
 * For some identity providers the external group IDs is an actual name, for others is an ID:
 * - Azure AD uses the group ID, e.g. `"818b6e03-15dd-4e19-8cb1-a4f434b40a04"`
 * - LDAP uses the content of the field configured in `access.ldap.groupField`
 * - Microsoft Active Directory uses the group common name, e.g. `"Administrators"` or the group distinguished name, e.g. `"CN=Administrators,CN=Users,DC=linkurious,DC=local"`
 *
 * To exclude some groups of users from logging in into Linkurious, set up a list of
 * authorized groups in the configuration key `access.externalUsersAllowedGroups`.
 * ```json
 * { // under the access configuration key
 *   // ...
 *   "externalUsersAllowedGroups": [
 *     "CN=Administrators,CN=Users,DC=linkurious,DC=local",
 *     "CN=Analysts,CN=Users,DC=linkurious,DC=local"
 *   ]
 *   // ...
 * }
 * ```
 */
class AccessService {
    constructor() {
        /**@type {AuthProviderWrapper}*/
        this._oauth2Provider = new AuthProviderWrapper('OAuth2', 'oauth2', 'oauth2/index.js');
        /**@type {AuthProviderWrapper}*/
        this._saml2Provider = new AuthProviderWrapper('SAML2', 'saml2', 'saml2.js');
        if (this._oauth2Provider.enabled && this._saml2Provider.enabled) {
            throw Errors.business('invalid_parameter', 'OAuth2 and SAML2 can\'t be enabled at the same time.');
        }
        this._ssoProvider = this._oauth2Provider.enabled ? this._oauth2Provider : this._saml2Provider;
        /**@type {AuthProviderWrapper[]}*/
        this._providers = [
            new AuthProviderWrapper('LDAP', 'ldap', 'ldapAuth.js'),
            new AuthProviderWrapper('Microsoft Active Directory', 'msActiveDirectory', 'msActiveDirectoryAuth.js'),
            this._oauth2Provider,
            this._saml2Provider
        ];
        /**@type {SessionStore}*/
        this._sessionStore = new SessionStore(Config.get('access.floatingLicenses', 0));
        UserCache.init();
    }
    /**
     * @type {AuthProviderWrapper[]}
     */
    get providers() {
        return this._providers;
    }
    /**
     * @type {SessionStore}
     */
    get sessionStore() {
        return this._sessionStore;
    }
    /**
     * If `req.session.userId` is defined, populate `req.user`.
     *
     * @param {IncomingMessage} req
     * @returns {Bluebird<void>}
     * @private
     */
    _populateReqUser(req) {
        const authRequired = Config.get('access.authRequired');
        const guestModeAllowed = Config.get('access.guestMode');
        let userIdToRetrieve = req.session.userId;
        if (!authRequired) {
            // use the unique user when authRequired is false
            userIdToRetrieve = UserDAO.model.UNIQUE_USER_ID;
        }
        if (req.query.guest === 'true') {
            if (!guestModeAllowed) {
                return Errors.access('guest_disabled', undefined, true);
            }
            userIdToRetrieve = UserDAO.model.GUEST_USER_ID;
        }
        if (Utils.noValue(userIdToRetrieve)) {
            return Promise.resolve();
        }
        return UserCache.getUser(userIdToRetrieve).then(user => {
            req.user = user;
            req.wrappedUser = new WrappedUser(req.user);
        });
    }
    /**
     * Check that there is an authenticated user.
     * Throw an access error if no current user.
     *
     * @param {WrappedUser} [wrappedUser]
     * @param {string}      [apiAction]        An API action the application needs to have to be allowed to perform on behalf of the user
     * @param {boolean}     [guestModeAllowed] Whether the guest user can be returned
     * @returns {WrappedUser}
     */
    checkAuth(wrappedUser, apiAction, guestModeAllowed) {
        if (!wrappedUser) {
            throw Errors.access('unauthorized');
        }
        // if we are an application
        if (Utils.hasValue(wrappedUser.application)) {
            // if API action is not defined, it means that
            // the action can't be performed by an application
            if (Utils.noValue(apiAction)) {
                throw Errors.access('forbidden', 'Application "' + wrappedUser.application.name +
                    '" (#' + wrappedUser.application.id + ') does not have access to this feature.');
            }
            // we check if we have the right to do the intended action
            this._checkAppAction(wrappedUser.application, apiAction);
        }
        if (!guestModeAllowed && wrappedUser.id === UserDAO.model.GUEST_USER_ID) {
            throw Errors.access('forbidden', 'A guest user does not have access to this feature.');
        }
        return wrappedUser;
    }
    /**
     * Express middleware responsible to set `req.user` and to check floating license errors.
     *
     * @param {IncomingMessage} req
     * @param {OutgoingMessage} res
     * @param {function} next
     */
    checkUserSession(req, res, next) {
        this._checkSessionErrors(req).then(() => {
            return this._populateReqUser(req);
        }).then(() => {
            next();
        }).catch(error => {
            API.respondToLkError(res, error);
        });
    }
    /**
     * Check that `req.session` doesn't contain any error.
     * If it does, reject with an LkError and destroy the session.
     *
     * @param {IncomingMessage} req
     * @returns {Bluebird<void>}
     * @private
     */
    _checkSessionErrors(req) {
        if (Utils.noValue(req.session.error)) {
            return Promise.resolve();
        }
        return new Promise((resolve, reject) => {
            const sessionError = req.session.error;
            req.session.destroy(() => {
                let error;
                switch (sessionError) {
                    case SessionStore.Errors.EXPIRED:
                    case SessionStore.Errors.FLOATING_EXPIRED:
                        error = Errors.access('session_expired');
                        break;
                    case SessionStore.Errors.FLOATING_KICKED:
                        error = Errors.access('session_evicted');
                        break;
                    case SessionStore.Errors.FLOATING_FULL:
                        error = Errors.access('server_full');
                        break;
                    default:
                        error = Errors.access('unauthorized', `Session error: "${sessionError}"`);
                }
                reject(error);
            });
        });
    }
    /**
     * Express middleware responsible to set `req.application`.
     *
     * @param {IncomingMessage} req
     * @param {OutgoingMessage} res
     * @param {function} next
     */
    checkApplication(req, res, next) {
        /**@type{{name: string, pass: string}}*/
        const credentials = basicAuth(req);
        // no basic auth, bypass this step
        if (!credentials) {
            next();
            return;
        }
        return Application.checkApplication(credentials.name, credentials.pass).then(userAndApp => {
            // the user which the app can act on behalf of
            req.user = userAndApp.user;
            // the public app itself
            req.application = userAndApp.application;
            req.wrappedUser = new WrappedUser(req.user, req.application);
            next();
        }).catch(error => {
            API.respondToLkError(res, error);
        });
    }
    /**
     * @param {string} usernameOrEmail
     * @param {string} password
     * @returns {Bluebird<ExternalUserProfile> | null} `null` if no external provider is enabled
     * @private
     */
    _getProviderAuthPromise(usernameOrEmail, password) {
        for (const provider of this.providers) {
            if (provider.enabled) {
                return provider.authenticate(usernameOrEmail, password);
            }
        }
        return null;
    }
    /**
     * Use the group mapping to retrieve the desired `internalGroupIds` from the `externalGroupIds`.
     * Each external group id can produce 1 or 0 internal group ids.
     *
     * @param {Array<string | number>} externalGroupIds
     * @returns {number[]} internalGroupIds
     * @private
     */
    _externalGroupsToInternalGroups(externalGroupIds) {
        let internalGroupIds = [];
        _.forEach(externalGroupIds, externalGroupId => {
            const externalUsersGroupMapping = Config.get('access.externalUsersGroupMapping', {});
            const caseSensitiveGroupId = _.findKey(externalUsersGroupMapping, (value, key) => {
                return key.toLowerCase() === ('' + externalGroupId).toLowerCase();
            });
            const mappedValue = externalUsersGroupMapping[caseSensitiveGroupId];
            if (Utils.noValue(mappedValue)) {
                return;
            }
            const newInternalGroupIds = Array.isArray(mappedValue) ? mappedValue : [mappedValue];
            internalGroupIds = internalGroupIds.concat(newInternalGroupIds);
        });
        return internalGroupIds;
    }
    /**
     * Given an external user profile, check if a user with the same email exists in the user database.
     * - If such user exists, but with source=local, the user is migrated (the source is updated to `source`)
     * - If a shadow user already exists, it is returned
     * - Otherwise, a shadow user is created.
     *
     * Shadow user: A user profile in the local database that represents an external user.
     * No password is stored for shadow users, since the authentication is done by the external provider.
     * Username/email of shadow users cannot be edited since they are a cache of the profile stored by the external provider.
     *
     * @param {ExternalUserProfile} profile
     * @param {string} source ("oauth" for OAuth2 or SAML2, "ldap" for LDAP or AD)
     * @returns {Bluebird<PublicUser>}
     * @private
     */
    _getOrCreateShadowExternalUser(profile, source) {
        const externalUsersAllowedGroups = Config.get('access.externalUsersAllowedGroups');
        const autoRefreshGroupMapping = Config.get('access.autoRefreshGroupMapping', false);
        // if only some groups are allowed but none of the current user
        if (Utils.hasValue(externalUsersAllowedGroups) &&
            _.intersectionBy(externalUsersAllowedGroups, profile.externalGroupIds, o => o.toLowerCase()).length === 0) {
            Log.debug('auth(' + profile.username + '): source:' + source + ', group:NOK');
            return Errors.access('unauthorized', 'The user doesn\'t belong to any authorized group.', true);
        }
        let desiredGroupIds = [];
        if (profile.externalGroupIds) {
            desiredGroupIds = this._externalGroupsToInternalGroups(profile.externalGroupIds);
        }
        return UserDAO.getUserInstanceByEmail(profile.email, true).then(user => {
            if (user) {
                Log.debug('auth(' + profile.username + '): source:' + source + ', in-db');
                return Promise.resolve()
                    .then(() => {
                    // if the user source is different, we migrate the user from 'local' to `source`
                    if (user.source !== source) {
                        user.username = profile.username;
                        user.source = source;
                        Log.debug('auth(' + profile.username + '): source:' + source + ', migrating-source');
                        return user.save();
                    }
                    return user;
                })
                    .then(user => {
                    // if autoRefreshGroupMapping is true all user groups are reset according to group mapping
                    if (autoRefreshGroupMapping) {
                        return OldGroupDAO.getGroupInstances(desiredGroupIds, true).then(groupInstances => {
                            if (groupInstances.length !== desiredGroupIds.length) {
                                return Errors.business('invalid_parameter', 'Unknown group specified in access.externalUsersGroupMapping', true);
                            }
                            return user.setGroups(groupInstances).then(() => {
                                user.groups = groupInstances;
                                return user;
                            });
                        });
                    }
                    return user;
                })
                    .then(user => {
                    return UserDAO.formatToPublicUser(user);
                });
            }
            // if the user was not found, we create the user
            Log.debug('auth(' + profile.username + '): source:' + source + ', creating');
            return UserDAO.createUser(profile.username, profile.email, null, desiredGroupIds, source);
        });
    }
    /**
     * @param {string} usernameOrEmail Username or email of the user
     * @param {string} password        Password of the user
     * @returns {Bluebird<PublicUser>}
     * @private
     */
    _authenticate(usernameOrEmail, password) {
        return Promise.resolve().then(() => {
            // strategy 1: try to authenticate with external providers
            const externalUserPromise = this._getProviderAuthPromise(usernameOrEmail, password);
            if (externalUserPromise) {
                return externalUserPromise.then(externalUserProfile => {
                    if (!externalUserProfile) {
                        // user not found or wrong credentials for LDAP/AD user (will try next strategy)
                        Log.debug('auth(' + usernameOrEmail + '): source:external, pass:NOK');
                        return;
                    }
                    return this._getOrCreateShadowExternalUser(externalUserProfile, 'ldap');
                });
            }
        }).then(user => {
            if (Utils.hasValue(user)) {
                // user was authenticated with an external provider
                return user;
            }
            // strategy 2: look for user in local DB
            return UserDAO.getLocalUserByUsernameAndPassword(usernameOrEmail, password).then(dbUser => {
                if (dbUser && dbUser.id === UserDAO.model.UNIQUE_USER_ID) {
                    return Errors.access('unauthorized', 'This user cannot be used when authentication is enabled.', true);
                }
                if (dbUser && dbUser.id === UserDAO.model.GUEST_USER_ID) {
                    return Errors.access('unauthorized', 'This user cannot be used to log in.', true);
                }
                // found user in DB, a local user, password matched
                if (!dbUser) {
                    return Errors.access('unauthorized', 'Incorrect username/email or password.', true);
                }
                Log.debug('auth(' + usernameOrEmail + '): source:local, pass:ok');
                return Promise.resolve(dbUser);
            });
        });
    }
    /**
     * Save the ID of the user in the session.
     *
     * @param {IncomingMessage} req  The current HTTP request
     * @param {PublicUser}      user Public user populated with actions
     * @returns {Bluebird<PublicUser>}
     * @private
     */
    _saveUserSession(req, user) {
        return new Promise((resolve, reject) => {
            req.session.userId = user.id;
            // We also save in the session if the user is admin
            // This is needed to kick out other users if floating licenses are on
            _.forEach(user.groups, group => {
                if (group.builtin && group.name === Db.models.group.ADMIN_GROUP_NAME) {
                    req.session.admin = true;
                }
            });
            req.session.save(err => {
                if (err) {
                    reject(err);
                }
                else {
                    resolve(user);
                }
            });
        }).then(user => {
            return this._checkSessionErrors(req).return(user);
        });
    }
    /**
     * Authenticate a user.
     *
     * @param {string}          usernameOrEmail Username or email of the user
     * @param {string}          password        Password of the user
     * @param {IncomingMessage} req             The current HTTP request
     * @returns {Bluebird<PublicUser>}
     */
    login(usernameOrEmail, password, req) {
        if (Utils.noValue(usernameOrEmail) || Utils.noValue(password)) {
            throw Errors.business('missing_field', 'Username and password are required.');
        }
        return this._authenticate(usernameOrEmail, password).then(user => {
            if (!user) {
                return Errors.access('unauthorized', null, true);
            }
            return this._saveUserSession(req, user);
        }).catch(err => {
            if (err instanceof Errors.LkError) {
                throw err;
            }
            Log.error(err);
            return Errors.technical('critical', err, true);
        });
    }
    /**
     * Return the URL of the OAuth2 authorization endpoint.
     *
     * @param {IncomingMessage} req The current HTTP request (required to access the session)
     * @returns {Bluebird<string>} authenticateURL
     */
    getAuthenticateURLSSO(req) {
        if (!this._ssoProvider.enabled) {
            return Errors.access('feature_disabled', 'No Single Sign-On authentication service is enabled.', true);
        }
        const state = Utils.randomHex(30);
        const isHttps = Utils.isRequestHTTPS(req);
        let requestBaseUrl = (isHttps ? 'https' : 'http') + '://' + req.headers.host;
        const baseFolder = Config.get('server.baseFolder');
        requestBaseUrl += baseFolder !== null && baseFolder !== undefined ? `/${baseFolder}` : '';
        return new Promise((resolve, reject) => {
            // Needed to make the session live in our session store
            req.session.twoStageAuth = true;
            req.session.state = state;
            req.session.save(err => {
                if (err) {
                    reject(err);
                }
                else {
                    resolve();
                }
            });
        }).then(() => {
            return this._ssoProvider.getAuthenticateURLSSO(state, requestBaseUrl);
        });
    }
    /**
     * Authenticate the user via OAuth2/SAML2.
     *
     * @param {string}          code    Response code from OAuth2/SAML2 server
     * @param {string}          [state] Handshake state from OAuth2 server
     * @param {IncomingMessage} req     The current HTTP request (required to access the session)
     * @returns {Bluebird<void>}
     */
    handleAuthenticateURLResponseSSO(code, state, req) {
        if (!this._ssoProvider.enabled) {
            return Errors.access('feature_disabled', 'No Single Sign-On authentication service is enabled.', true);
        }
        Utils.check.exist('code', code);
        // check the state only in OAuth2
        if (this._oauth2Provider.enabled) {
            if (state !== req.session.state) {
                if (Utils.noValue(req.session.state)) {
                    Log.warn('Session state is undefined in OAuth2 response, ' +
                        'redirect domain might not match actual domain.');
                }
                return Errors.access('unauthorized', 'The OAuth2 response state did not match.', true);
            }
        }
        const isHttps = Utils.isRequestHTTPS(req);
        let requestBaseUrl = (isHttps ? 'https' : 'http') + '://' + req.headers.host;
        const baseFolder = Config.get('server.baseFolder');
        requestBaseUrl += baseFolder !== null && baseFolder !== undefined ? `/${baseFolder}` : '';
        return this._ssoProvider.handleAuthenticateURLResponseSSO(code, requestBaseUrl).then(profile => {
            // TODO source for saml2 is "oauth"
            return this._getOrCreateShadowExternalUser(profile, 'oauth');
        }).then(user => {
            return this._saveUserSession(req, user);
        }).return();
    }
    /**
     * Log the current user out of Linkurious.
     *
     * @param {IncomingMessage} req The current HTTP request
     * @returns {Bluebird<void>}
     */
    logout(req) {
        return new Promise((resolve, reject) => {
            req.session.destroy(err => {
                if (err) {
                    reject(err);
                }
                else {
                    // if no user was logged id
                    if (Utils.noValue(req.user)) {
                        return reject(Errors.access('unauthorized'));
                    }
                    resolve();
                }
            });
        });
    }
    /**
     * Return a resolved promise if the user can manage users on at least one data-source or
     * on a particular data-source if `sourceKey` is defined.
     *
     * @param {IncomingMessage} req
     * @param {string}          [sourceKey]
     * @returns {Bluebird<void>}
     */
    canManageUsers(req, sourceKey) {
        return this.getWrappedUser(req).canManageUsers(sourceKey);
    }
    /**
     * Return the current user.
     *
     * @param {IncomingMessage} req                The current HTTP request
     * @param {boolean}         [throwIfNone=true] By default, it will throw an exception if no current user
     * @throws {LkError} if no current user and `throwIfNone` is true
     * @returns {PublicUser} Public user with actions, groups and access rights (with wildcards not expanded)
     */
    getCurrentUser(req, throwIfNone) {
        if (!req.user && throwIfNone !== false) {
            throw Errors.access('unauthorized');
        }
        return req.user;
    }
    /**
     * @param {IncomingMessage} req                The current HTTP request
     * @param {boolean}         [throwIfNone=true] By default, it will throw an exception if no current user
     * @returns {WrappedUser} Wrapped user with actions, groups and access rights (with wildcards not expanded)
     */
    getWrappedUser(req, throwIfNone) {
        if (req.wrappedUser) {
            return req.wrappedUser;
        }
        if (!req.user && throwIfNone !== false) {
            throw Errors.access('unauthorized');
        }
        if (req.user) {
            req.wrappedUser = new WrappedUser(req.user, req.application);
        }
        return req.wrappedUser;
    }
    /**
     * Check if the application has the right perform the action.
     *
     * @param {PublicApplication} application
     * @param {string}            [actionKey]
     * @throws {LkError} if `actionKey` is not allowed
     * @private
     */
    _checkAppAction(application, actionKey) {
        if (actionKey !== undefined) {
            // check that the action is valid
            Utils.check.values('actionKey', actionKey, Db.models.application.APP_ACTIONS, true);
        }
        // action is allowed for the app
        const allowed = application.rights.includes(actionKey);
        if (allowed) {
            return;
        }
        // action is not allowed for the app
        throw Errors.access('forbidden', 'Application "' + application.name +
            '" (#' + application.id + ') is not allowed to do action "' + actionKey + '".');
    }
    /**
     * Get the current user wrapped:
     * - check for application rights (if the user is an app).
     * - check for guest mode (if the user is the guest user).
     *
     * @param {IncomingMessage} req                 The current HTTP request
     * @param {string}          [intendedApiAction] An API action the application needs to be allowed to do
     * @param {boolean}         [guestModeAllowed]  Whether the guest user can be returned
     * @throws {LkError} if req.application is defined and intendedApiAction is not allowed
     * @returns {WrappedUser}
     */
    getUserCheck(req, intendedApiAction, guestModeAllowed) {
        // if we are an application
        if (Utils.hasValue(req.application)) {
            // if the intended action is not defined, it means for sure it can't be performed by an app
            if (Utils.noValue(intendedApiAction)) {
                throw Errors.access('forbidden', 'Application "' + req.application.name +
                    '" (#' + req.application.id + ') does not have access to this feature.');
            }
            // we check if we have the right to do the intended action
            this._checkAppAction(req.application, intendedApiAction);
        }
        const currentWrappedUser = this.getWrappedUser(req);
        if (!guestModeAllowed && currentWrappedUser.id === UserDAO.model.GUEST_USER_ID) {
            throw Errors.access('forbidden', 'A guest user does not have access to this feature.');
        }
        return currentWrappedUser;
    }
    /**
     * Perform startup checks for all enabled auth providers.
     *
     * @returns {Bluebird<void>}
     */
    providersStartupCheck() {
        return Promise.each(this.providers, provider => {
            return provider.startupCheck().catch(e => {
                Log.error(e);
                throw e;
            });
        }).return();
    }
    /**
     * Check that there is an authenticated user.
     * Return a rejected promise if no current user and `throwIfNone` is true.
     *
     * @param {IncomingMessage} req               The current HTTP request
     * @param {boolean}         [throwIfNot=true] Whether to reject if not authenticated
     * @returns {Bluebird<boolean>}
     */
    isAuthenticated(req, throwIfNot) {
        return Promise.resolve().then(() => {
            return !!this.getCurrentUser(req, throwIfNot);
        });
    }
    /**
     * Check if `actionName` is doable by the current user.
     * If `sourceKey` is undefined it means *any* sourceKey. To not confuse with *all* sourceKey.
     *
     * Additionally, if the API is used by an application,
     * check if `intendedApiAction` is doable by the current application on behalf of the user.
     *
     * Note:
     * - all the possible `actionName` are defined in `PUBLIC_ACTIONS` and `PRIVATE_ACTIONS`, and they are actions for users
     * - all the possible `intendedApiAction` are defined in `APP_ACTIONS` and they are actions for applications
     *
     * An application A to act on behalf of a user U needs:
     *  - U to be able to perform `actionName`
     *  - A to be able to perform `intendedApiAction`
     *
     * @param {IncomingMessage} req                 The current HTTP request
     * @param {string}          actionName          Name of the action the user needs to be allowed to do
     * @param {string}          [sourceKey]         Key of the data-source
     * @param {string}          [intendedApiAction] An API action the application needs to be allowed to do
     * @param {boolean}         [guestModeAllowed]  Whether the guest user can be returned
     * @param {boolean}         [throwIfNot=true]   Whether to reject if the condition is not met
     * @returns {Bluebird<boolean>}
     */
    hasAction(req, actionName, sourceKey, intendedApiAction, guestModeAllowed, throwIfNot = true) {
        if (actionName.startsWith('admin') &&
            intendedApiAction !== 'admin.index' &&
            Utils.hasValue(req.application)) {
            return Errors.access('admin_required', 'Applications cannot perform administrator actions.', true); // except `admin.index`
        }
        let wrappedUser;
        try {
            // We get the user and at the same time we check the api action
            wrappedUser = this.getUserCheck(req, intendedApiAction, guestModeAllowed);
        }
        catch (e) {
            if (throwIfNot) {
                throw e;
            }
            return Promise.resolve(false);
        }
        return Promise.resolve().then(() => {
            return wrappedUser.hasAction(actionName, sourceKey, throwIfNot);
        });
    }
    /**
     * Check that builtin groups exists for every existing data-source.
     * Create them if they don't exist.
     *
     * @returns {Bluebird<void>}
     */
    ensureBuiltinGroups() {
        return Db.models.dataSourceState.findAll({ attributes: ['key'] }).map(dataSourceStateInstance => {
            return Db.models.group.ensureBuiltins(dataSourceStateInstance.key);
        }, { concurrency: 1 }).return();
    }
    /**
     * @returns {Bluebird<void>}
     * @private
     */
    _migrateDefaultGroup() {
        // 1) retrieve the default group
        return Db.models.group.findAllByName('default', true).then(defaultGroups => {
            const defaultGroup = defaultGroups[0]; // unwrap it, there is only one
            if (Utils.noValue(defaultGroup)) {
                return; // migration already took place in the past
            }
            /**@type {UserInstance[]}*/
            let defaultUsers;
            /**@type {UserInstance[]}*/
            let adminUsers;
            // 2) look for all the users belonging to the deprecated default group
            return Db.models.user.findAll({
                include: [{
                        model: Db.models.group, where: { id: defaultGroup.id }
                    }]
            }).then(_defaultUsers => {
                defaultUsers = _defaultUsers;
                return Db.models.user.findAll({
                    include: [{
                            model: Db.models.group, where: { id: Db.models.group.ADMIN_GROUP.id }
                        }]
                });
            }).then(_adminUsers => {
                adminUsers = _adminUsers;
                // 3) retrieve all the builtin "read" groups
                return Db.models.group.findAllByName('read', true);
            }).then(readGroups => {
                // 4) to any group in readGroups assign all the users in defaultUsers not in the admin group
                const readUsers = _.differenceBy(defaultUsers, adminUsers, 'id');
                return Promise.map(readGroups, group => {
                    return group.addUsers(readUsers);
                }, { concurrency: 1 });
            }).then(() => {
                // 5) remove all the users from the defaultGroup
                return defaultGroup.removeUsers(defaultUsers);
            }).then(() => {
                // 6) delete the default group
                return defaultGroup.destroy();
            });
        });
    }
    /**
     * @param {GroupInstance} legacyGroup Group instance with access rights
     * @returns {Bluebird<void>}
     * @private
     */
    _migrateLegacyGroup(legacyGroup) {
        const usersWithLegacyGroupQuery = {
            include: [{
                    model: Db.models.group, where: { id: legacyGroup.id }
                }]
        };
        const rightsWithLegacyGroupQuery = {
            where: { groupId: legacyGroup.id }
        };
        /**@type {UserInstance[]}*/
        let legacyUsers;
        // 1) retrieve all the users belonging to this legacy group
        return Db.models.user.findAll(usersWithLegacyGroupQuery).then(_legacyUsers => {
            legacyUsers = _legacyUsers;
            // 2) retrieve all the data-source keys
            return Db.models.dataSourceState.findAll();
        }).map(dataSourceStateInstance => {
            // 3) create a group with the same name in every data-source
            return Db.models.group.create({
                sourceKey: dataSourceStateInstance.key,
                name: legacyGroup.name,
                builtin: false
            }).then(groupInstance => {
                // 4) filter the access rights of the legacy group by sourceKey and turn them in AccessRightAttributes
                /**@type {AccessRightAttributes[]}*/
                const accessRights = _.map(_.filter(legacyGroup.accessRights, accessRight => accessRight.sourceKey === groupInstance.sourceKey), accessRightInstance => {
                    return Db.models.accessRight.instanceToPublicAttributes(accessRightInstance, true);
                });
                // 5) create and assign the new access rights to the new group
                return Promise.map(accessRights, accessRight => {
                    return Db.models.accessRight.create(accessRight).then(rightInstance => {
                        return groupInstance.addAccessRight(rightInstance);
                    });
                }, { concurrency: 1 }).then(() => {
                    // 6) add the new group to any user of the legacy group
                    return groupInstance.addUsers(legacyUsers);
                });
            });
        }, { concurrency: 1 }).then(() => {
            // 7) delete all the access rights of the legacy group
            return Db.models.accessRight.destroy(rightsWithLegacyGroupQuery);
        }).then(() => {
            // 8) remove all the users from the legacy group
            return legacyGroup.removeUsers(legacyUsers);
        }).then(() => {
            // 9) delete the legacy group
            return legacyGroup.destroy();
        });
    }
    /**
     * Legacy groups were groups with sourceKey set to *.
     * This was prior than introducing the builtin groups "read", "read and edit" and so on.
     * Originally every user not belonging to a group belonged to a group called "default".
     *
     * With the release of LKE v2 we migrate all the legacy groups to new groups.
     * - Every user belonging to the "default" group will belong to any "read" builtin group of
     * every data-source.
     * - Every user belonging to a legacy "custom" group will belong to a copy of that custom group
     * specific for the data-source.
     *
     * @returns {Bluebird<void>}
     * @backward-compatibility
     */
    migrateLegacyGroups() {
        // 1) migrate the default group
        return this._migrateDefaultGroup().then(() => {
            // 2) migrate any other legacy group
            const legacyGroupQuery = {
                where: { sourceKey: '*', builtin: false },
                include: [Db.models.accessRight]
            };
            return Db.models.group.findAll(legacyGroupQuery).map(legacyGroup => {
                return this._migrateLegacyGroup(legacyGroup);
            }, { concurrency: 1 });
        }).return();
    }
}
module.exports = new AccessService();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvYWNjZXNzL2luZGV4LmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBQ2IsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNwQyxNQUFNLFNBQVMsR0FBRyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDeEMsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ2hDLE1BQU0sV0FBVyxHQUFHLEdBQUcsQ0FBQyxjQUFjLEVBQUUsQ0FBQztBQUN6QyxNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxXQUFXLEdBQUcsR0FBRyxDQUFDLGNBQWMsRUFBRSxDQUFDO0FBQ3pDLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEVBQUUsR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDMUIsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzdCLE1BQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDdEMsTUFBTSxPQUFPLEdBQUcsR0FBRyxDQUFDLFVBQVUsRUFBRSxDQUFDO0FBQ2pDLE1BQU0sRUFBQyxXQUFXLEVBQUMsR0FBRyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUM7QUFDL0MsTUFBTSxtQkFBbUIsR0FBRyxPQUFPLENBQUMsZ0NBQWdDLENBQUMsQ0FBQztBQUN0RSxNQUFNLFlBQVksR0FBRyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztBQUMvQyxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsa0JBQWtCLENBQUMsQ0FBQztBQUN4QyxNQUFNLFNBQVMsR0FBRyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUM7QUFFekM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBbUNHO0FBRUgsTUFBTSxhQUFhO0lBQ2pCO1FBQ0UsZ0NBQWdDO1FBQ2hDLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxtQkFBbUIsQ0FBQyxRQUFRLEVBQUUsUUFBUSxFQUFFLGlCQUFpQixDQUFDLENBQUM7UUFFdEYsZ0NBQWdDO1FBQ2hDLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxtQkFBbUIsQ0FBQyxPQUFPLEVBQUUsT0FBTyxFQUFFLFVBQVUsQ0FBQyxDQUFDO1FBRTVFLElBQUksSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLEVBQUU7WUFDL0QsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUNuQixtQkFBbUIsRUFDbkIsc0RBQXNELENBQ3ZELENBQUM7U0FDSDtRQUVELElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUM7UUFFOUYsa0NBQWtDO1FBQ2xDLElBQUksQ0FBQyxVQUFVLEdBQUc7WUFDaEIsSUFBSSxtQkFBbUIsQ0FDckIsTUFBTSxFQUFFLE1BQU0sRUFBRSxhQUFhLENBQzlCO1lBQ0QsSUFBSSxtQkFBbUIsQ0FDckIsNEJBQTRCLEVBQUUsbUJBQW1CLEVBQUUsMEJBQTBCLENBQzlFO1lBQ0QsSUFBSSxDQUFDLGVBQWU7WUFDcEIsSUFBSSxDQUFDLGNBQWM7U0FDcEIsQ0FBQztRQUVGLHlCQUF5QjtRQUN6QixJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksWUFBWSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMseUJBQXlCLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVoRixTQUFTLENBQUMsSUFBSSxFQUFFLENBQUM7SUFDbkIsQ0FBQztJQUVEOztPQUVHO0lBQ0gsSUFBSSxTQUFTO1FBQ1gsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDO0lBQ3pCLENBQUM7SUFFRDs7T0FFRztJQUNILElBQUksWUFBWTtRQUNkLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQztJQUM1QixDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsZ0JBQWdCLENBQUMsR0FBRztRQUNsQixNQUFNLFlBQVksR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLHFCQUFxQixDQUFDLENBQUM7UUFDdkQsTUFBTSxnQkFBZ0IsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUM7UUFDeEQsSUFBSSxnQkFBZ0IsR0FBRyxHQUFHLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQztRQUUxQyxJQUFJLENBQUMsWUFBWSxFQUFFO1lBQ2pCLGlEQUFpRDtZQUNqRCxnQkFBZ0IsR0FBRyxPQUFPLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQztTQUNqRDtRQUVELElBQUksR0FBRyxDQUFDLEtBQUssQ0FBQyxLQUFLLEtBQUssTUFBTSxFQUFFO1lBQzlCLElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtnQkFDckIsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDLGdCQUFnQixFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQzthQUN6RDtZQUNELGdCQUFnQixHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDO1NBQ2hEO1FBRUQsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLGdCQUFnQixDQUFDLEVBQUU7WUFDbkMsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7U0FDMUI7UUFFRCxPQUFPLFNBQVMsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDckQsR0FBRyxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7WUFFaEIsR0FBRyxDQUFDLFdBQVcsR0FBRyxJQUFJLFdBQVcsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDOUMsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSCxTQUFTLENBQUMsV0FBVyxFQUFFLFNBQVMsRUFBRSxnQkFBZ0I7UUFDaEQsSUFBSSxDQUFDLFdBQVcsRUFBRTtZQUNoQixNQUFNLE1BQU0sQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLENBQUM7U0FDckM7UUFFRCwyQkFBMkI7UUFDM0IsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUMzQyw4Q0FBOEM7WUFDOUMsa0RBQWtEO1lBQ2xELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsRUFBRTtnQkFDNUIsTUFBTSxNQUFNLENBQUMsTUFBTSxDQUNqQixXQUFXLEVBQ1gsZUFBZSxHQUFHLFdBQVcsQ0FBQyxXQUFXLENBQUMsSUFBSTtvQkFDOUMsTUFBTSxHQUFHLFdBQVcsQ0FBQyxXQUFXLENBQUMsRUFBRSxHQUFHLHlDQUF5QyxDQUNoRixDQUFDO2FBQ0g7WUFFRCwwREFBMEQ7WUFDMUQsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMsV0FBVyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1NBQzFEO1FBRUQsSUFBSSxDQUFDLGdCQUFnQixJQUFJLFdBQVcsQ0FBQyxFQUFFLEtBQUssT0FBTyxDQUFDLEtBQUssQ0FBQyxhQUFhLEVBQUU7WUFDdkUsTUFBTSxNQUFNLENBQUMsTUFBTSxDQUNqQixXQUFXLEVBQ1gsb0RBQW9ELENBQ3JELENBQUM7U0FDSDtRQUVELE9BQU8sV0FBVyxDQUFDO0lBQ3JCLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxnQkFBZ0IsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLElBQUk7UUFDN0IsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDdEMsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDcEMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNYLElBQUksRUFBRSxDQUFDO1FBQ1QsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ2YsR0FBRyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUNuQyxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsbUJBQW1CLENBQUMsR0FBRztRQUNyQixJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUNwQyxPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQztTQUMxQjtRQUVELE9BQU8sSUFBSSxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDckMsTUFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUM7WUFDdkMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFO2dCQUN2QixJQUFJLEtBQUssQ0FBQztnQkFDVixRQUFRLFlBQVksRUFBRTtvQkFDcEIsS0FBSyxZQUFZLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztvQkFDakMsS0FBSyxZQUFZLENBQUMsTUFBTSxDQUFDLGdCQUFnQjt3QkFDdkMsS0FBSyxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsQ0FBQzt3QkFDekMsTUFBTTtvQkFDUixLQUFLLFlBQVksQ0FBQyxNQUFNLENBQUMsZUFBZTt3QkFDdEMsS0FBSyxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsQ0FBQzt3QkFDekMsTUFBTTtvQkFDUixLQUFLLFlBQVksQ0FBQyxNQUFNLENBQUMsYUFBYTt3QkFDcEMsS0FBSyxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLENBQUM7d0JBQ3JDLE1BQU07b0JBQ1I7d0JBQ0UsS0FBSyxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsY0FBYyxFQUFFLG1CQUFtQixZQUFZLEdBQUcsQ0FBQyxDQUFDO2lCQUM3RTtnQkFFRCxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDaEIsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxnQkFBZ0IsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLElBQUk7UUFDN0Isd0NBQXdDO1FBQ3hDLE1BQU0sV0FBVyxHQUFHLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUVuQyxrQ0FBa0M7UUFDbEMsSUFBSSxDQUFDLFdBQVcsRUFBRTtZQUNoQixJQUFJLEVBQUUsQ0FBQztZQUNQLE9BQU87U0FDUjtRQUVELE9BQU8sV0FBVyxDQUFDLGdCQUFnQixDQUNqQyxXQUFXLENBQUMsSUFBSSxFQUNoQixXQUFXLENBQUMsSUFBSSxDQUNqQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRTtZQUNsQiw4Q0FBOEM7WUFDOUMsR0FBRyxDQUFDLElBQUksR0FBRyxVQUFVLENBQUMsSUFBSSxDQUFDO1lBQzNCLHdCQUF3QjtZQUN4QixHQUFHLENBQUMsV0FBVyxHQUFHLFVBQVUsQ0FBQyxXQUFXLENBQUM7WUFDekMsR0FBRyxDQUFDLFdBQVcsR0FBRyxJQUFJLFdBQVcsQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUM3RCxJQUFJLEVBQUUsQ0FBQztRQUNULENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUNmLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDbkMsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCx1QkFBdUIsQ0FBQyxlQUFlLEVBQUUsUUFBUTtRQUMvQyxLQUFLLE1BQU0sUUFBUSxJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7WUFDckMsSUFBSSxRQUFRLENBQUMsT0FBTyxFQUFFO2dCQUNwQixPQUFPLFFBQVEsQ0FBQyxZQUFZLENBQUMsZUFBZSxFQUFFLFFBQVEsQ0FBQyxDQUFDO2FBQ3pEO1NBQ0Y7UUFDRCxPQUFPLElBQUksQ0FBQztJQUNkLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsK0JBQStCLENBQUMsZ0JBQWdCO1FBQzlDLElBQUksZ0JBQWdCLEdBQUcsRUFBRSxDQUFDO1FBRTFCLENBQUMsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLEVBQUUsZUFBZSxDQUFDLEVBQUU7WUFDNUMsTUFBTSx5QkFBeUIsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLGtDQUFrQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1lBRXJGLE1BQU0sb0JBQW9CLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyx5QkFBeUIsRUFBRSxDQUFDLEtBQUssRUFBRSxHQUFHLEVBQUUsRUFBRTtnQkFDL0UsT0FBTyxHQUFHLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxFQUFFLEdBQUcsZUFBZSxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDcEUsQ0FBQyxDQUFDLENBQUM7WUFFSCxNQUFNLFdBQVcsR0FBRyx5QkFBeUIsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1lBQ3BFLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsRUFBRTtnQkFDOUIsT0FBTzthQUNSO1lBRUQsTUFBTSxtQkFBbUIsR0FBRyxLQUFLLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDckYsZ0JBQWdCLEdBQUcsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLENBQUM7UUFDbEUsQ0FBQyxDQUFDLENBQUM7UUFFSCxPQUFPLGdCQUFnQixDQUFDO0lBQzFCLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7T0FjRztJQUNILDhCQUE4QixDQUFDLE9BQU8sRUFBRSxNQUFNO1FBQzVDLE1BQU0sMEJBQTBCLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxtQ0FBbUMsQ0FBQyxDQUFDO1FBQ25GLE1BQU0sdUJBQXVCLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxnQ0FBZ0MsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUVwRiwrREFBK0Q7UUFDL0QsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLDBCQUEwQixDQUFDO1lBQzVDLENBQUMsQ0FBQyxjQUFjLENBQUMsMEJBQTBCLEVBQUUsT0FBTyxDQUFDLGdCQUFnQixFQUNuRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFDdEMsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDLFFBQVEsR0FBRyxZQUFZLEdBQUcsTUFBTSxHQUFHLGFBQWEsQ0FBQyxDQUFDO1lBRTlFLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQ2pDLG1EQUFtRCxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQzlEO1FBRUQsSUFBSSxlQUFlLEdBQUcsRUFBRSxDQUFDO1FBRXpCLElBQUksT0FBTyxDQUFDLGdCQUFnQixFQUFFO1lBQzVCLGVBQWUsR0FBRyxJQUFJLENBQUMsK0JBQStCLENBQUMsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUM7U0FDbEY7UUFFRCxPQUFPLE9BQU8sQ0FBQyxzQkFBc0IsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNyRSxJQUFJLElBQUksRUFBRTtnQkFDUixHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUMsUUFBUSxHQUFHLFlBQVksR0FBRyxNQUFNLEdBQUcsU0FBUyxDQUFDLENBQUM7Z0JBRTFFLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRTtxQkFDckIsSUFBSSxDQUFDLEdBQUcsRUFBRTtvQkFDVCxnRkFBZ0Y7b0JBQ2hGLElBQUksSUFBSSxDQUFDLE1BQU0sS0FBSyxNQUFNLEVBQUU7d0JBQzFCLElBQUksQ0FBQyxRQUFRLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQzt3QkFDakMsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7d0JBQ3JCLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxRQUFRLEdBQUcsWUFBWSxHQUFHLE1BQU0sR0FBRyxvQkFBb0IsQ0FBQyxDQUFDO3dCQUNyRixPQUFPLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztxQkFDcEI7b0JBQ0QsT0FBTyxJQUFJLENBQUM7Z0JBQ2QsQ0FBQyxDQUFDO3FCQUNELElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtvQkFDWCwwRkFBMEY7b0JBQzFGLElBQUksdUJBQXVCLEVBQUU7d0JBQzNCLE9BQU8sV0FBVyxDQUFDLGlCQUFpQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQzlELGNBQWMsQ0FBQyxFQUFFOzRCQUNmLElBQUksY0FBYyxDQUFDLE1BQU0sS0FBSyxlQUFlLENBQUMsTUFBTSxFQUFFO2dDQUNwRCxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQ3BCLG1CQUFtQixFQUNuQiw2REFBNkQsRUFDN0QsSUFBSSxDQUNMLENBQUM7NkJBQ0g7NEJBQ0QsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0NBQzlDLElBQUksQ0FBQyxNQUFNLEdBQUcsY0FBYyxDQUFDO2dDQUM3QixPQUFPLElBQUksQ0FBQzs0QkFDZCxDQUFDLENBQUMsQ0FBQzt3QkFDTCxDQUFDLENBQ0YsQ0FBQztxQkFDSDtvQkFDRCxPQUFPLElBQUksQ0FBQztnQkFDZCxDQUFDLENBQUM7cUJBQ0QsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO29CQUNYLE9BQU8sT0FBTyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUMxQyxDQUFDLENBQUMsQ0FBQzthQUNOO1lBQ0QsZ0RBQWdEO1lBQ2hELEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxRQUFRLEdBQUcsWUFBWSxHQUFHLE1BQU0sR0FBRyxZQUFZLENBQUMsQ0FBQztZQUM3RSxPQUFPLE9BQU8sQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxPQUFPLENBQUMsS0FBSyxFQUFFLElBQUksRUFBRSxlQUFlLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDNUYsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxhQUFhLENBQUMsZUFBZSxFQUFFLFFBQVE7UUFDckMsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNqQywwREFBMEQ7WUFDMUQsTUFBTSxtQkFBbUIsR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUMsZUFBZSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1lBQ3BGLElBQUksbUJBQW1CLEVBQUU7Z0JBQ3ZCLE9BQU8sbUJBQW1CLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEVBQUU7b0JBQ3BELElBQUksQ0FBQyxtQkFBbUIsRUFBRTt3QkFDeEIsZ0ZBQWdGO3dCQUNoRixHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxlQUFlLEdBQUcsOEJBQThCLENBQUMsQ0FBQzt3QkFDdEUsT0FBTztxQkFDUjtvQkFFRCxPQUFPLElBQUksQ0FBQyw4QkFBOEIsQ0FBQyxtQkFBbUIsRUFBRSxNQUFNLENBQUMsQ0FBQztnQkFDMUUsQ0FBQyxDQUFDLENBQUM7YUFDSjtRQUNILENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNiLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRTtnQkFDeEIsbURBQW1EO2dCQUNuRCxPQUFPLElBQUksQ0FBQzthQUNiO1lBRUQsd0NBQXdDO1lBQ3hDLE9BQU8sT0FBTyxDQUFDLGlDQUFpQyxDQUFDLGVBQWUsRUFBRSxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7Z0JBQ3hGLElBQUksTUFBTSxJQUFJLE1BQU0sQ0FBQyxFQUFFLEtBQUssT0FBTyxDQUFDLEtBQUssQ0FBQyxjQUFjLEVBQUU7b0JBQ3hELE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FDbEIsY0FBYyxFQUFFLDBEQUEwRCxFQUFFLElBQUksQ0FDakYsQ0FBQztpQkFDSDtnQkFFRCxJQUFJLE1BQU0sSUFBSSxNQUFNLENBQUMsRUFBRSxLQUFLLE9BQU8sQ0FBQyxLQUFLLENBQUMsYUFBYSxFQUFFO29CQUN2RCxPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQ2xCLGNBQWMsRUFBRSxxQ0FBcUMsRUFBRSxJQUFJLENBQzVELENBQUM7aUJBQ0g7Z0JBRUQsbURBQW1EO2dCQUNuRCxJQUFJLENBQUMsTUFBTSxFQUFFO29CQUNYLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUUsdUNBQXVDLEVBQUUsSUFBSSxDQUFDLENBQUM7aUJBQ3JGO2dCQUVELEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLGVBQWUsR0FBRywwQkFBMEIsQ0FBQyxDQUFDO2dCQUNsRSxPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDakMsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsZ0JBQWdCLENBQUMsR0FBRyxFQUFFLElBQUk7UUFDeEIsT0FBTyxJQUFJLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsRUFBRTtZQUNyQyxHQUFHLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsRUFBRSxDQUFDO1lBRTdCLG1EQUFtRDtZQUNuRCxxRUFBcUU7WUFDckUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxFQUFFO2dCQUM3QixJQUFJLEtBQUssQ0FBQyxPQUFPLElBQUksS0FBSyxDQUFDLElBQUksS0FBSyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsRUFBRTtvQkFDcEUsR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO2lCQUMxQjtZQUNILENBQUMsQ0FBQyxDQUFDO1lBRUgsR0FBRyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQ3JCLElBQUksR0FBRyxFQUFFO29CQUNQLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDYjtxQkFBTTtvQkFDTCxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7aUJBQ2Y7WUFDSCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNiLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNwRCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsS0FBSyxDQUFDLGVBQWUsRUFBRSxRQUFRLEVBQUUsR0FBRztRQUNsQyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUM3RCxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQUMsZUFBZSxFQUFFLHFDQUFxQyxDQUFDLENBQUM7U0FDL0U7UUFFRCxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsZUFBZSxFQUFFLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUMvRCxJQUFJLENBQUMsSUFBSSxFQUFFO2dCQUNULE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQ2xEO1lBRUQsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUNiLElBQUksR0FBRyxZQUFZLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Z0JBQ2pDLE1BQU0sR0FBRyxDQUFDO2FBQ1g7WUFFRCxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ2YsT0FBTyxNQUFNLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDakQsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxxQkFBcUIsQ0FBQyxHQUFHO1FBQ3ZCLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRTtZQUM5QixPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsa0JBQWtCLEVBQ3JDLHNEQUFzRCxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQ2pFO1FBRUQsTUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNsQyxNQUFNLE9BQU8sR0FBRyxLQUFLLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQzFDLElBQUksY0FBYyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEtBQUssR0FBRyxHQUFHLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQztRQUU3RSxNQUFNLFVBQVUsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDLENBQUM7UUFDbkQsY0FBYyxJQUFJLFVBQVUsS0FBSyxJQUFJLElBQUksVUFBVSxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxVQUFVLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1FBRTFGLE9BQU8sSUFBSSxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDckMsdURBQXVEO1lBQ3ZELEdBQUcsQ0FBQyxPQUFPLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQztZQUNoQyxHQUFHLENBQUMsT0FBTyxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7WUFDMUIsR0FBRyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQ3JCLElBQUksR0FBRyxFQUFFO29CQUNQLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDYjtxQkFBTTtvQkFDTCxPQUFPLEVBQUUsQ0FBQztpQkFDWDtZQUNILENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNYLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxxQkFBcUIsQ0FBQyxLQUFLLEVBQUUsY0FBYyxDQUFDLENBQUM7UUFDeEUsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILGdDQUFnQyxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsR0FBRztRQUMvQyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUU7WUFDOUIsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDLGtCQUFrQixFQUNyQyxzREFBc0QsRUFBRSxJQUFJLENBQUMsQ0FBQztTQUNqRTtRQUVELEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztRQUVoQyxpQ0FBaUM7UUFDakMsSUFBSSxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sRUFBRTtZQUNoQyxJQUFJLEtBQUssS0FBSyxHQUFHLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRTtnQkFDL0IsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUU7b0JBQ3BDLEdBQUcsQ0FBQyxJQUFJLENBQ04saURBQWlEO3dCQUNqRCxnREFBZ0QsQ0FDakQsQ0FBQztpQkFDSDtnQkFDRCxPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsY0FBYyxFQUFFLDBDQUEwQyxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQ3hGO1NBQ0Y7UUFFRCxNQUFNLE9BQU8sR0FBRyxLQUFLLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQzFDLElBQUksY0FBYyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEtBQUssR0FBRyxHQUFHLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQztRQUU3RSxNQUFNLFVBQVUsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDLENBQUM7UUFDbkQsY0FBYyxJQUFJLFVBQVUsS0FBSyxJQUFJLElBQUksVUFBVSxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxVQUFVLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1FBRTFGLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxnQ0FBZ0MsQ0FDdkQsSUFBSSxFQUFFLGNBQWMsQ0FDckIsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDZixtQ0FBbUM7WUFDbkMsT0FBTyxJQUFJLENBQUMsOEJBQThCLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQy9ELENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNiLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUMxQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztJQUNkLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILE1BQU0sQ0FBQyxHQUFHO1FBQ1IsT0FBTyxJQUFJLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsRUFBRTtZQUNyQyxHQUFHLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRTtnQkFDeEIsSUFBSSxHQUFHLEVBQUU7b0JBQ1AsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2lCQUNiO3FCQUFNO29CQUNMLDJCQUEyQjtvQkFDM0IsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRTt3QkFDM0IsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDO3FCQUM5QztvQkFFRCxPQUFPLEVBQUUsQ0FBQztpQkFDWDtZQUNILENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILGNBQWMsQ0FBQyxHQUFHLEVBQUUsU0FBUztRQUMzQixPQUFPLElBQUksQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQzVELENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsY0FBYyxDQUFDLEdBQUcsRUFBRSxXQUFXO1FBQzdCLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxJQUFJLFdBQVcsS0FBSyxLQUFLLEVBQUU7WUFDdEMsTUFBTSxNQUFNLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1NBQ3JDO1FBRUQsT0FBTyxHQUFHLENBQUMsSUFBSSxDQUFDO0lBQ2xCLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsY0FBYyxDQUFDLEdBQUcsRUFBRSxXQUFXO1FBQzdCLElBQUksR0FBRyxDQUFDLFdBQVcsRUFBRTtZQUNuQixPQUFPLEdBQUcsQ0FBQyxXQUFXLENBQUM7U0FDeEI7UUFFRCxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksSUFBSSxXQUFXLEtBQUssS0FBSyxFQUFFO1lBQ3RDLE1BQU0sTUFBTSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsQ0FBQztTQUNyQztRQUVELElBQUksR0FBRyxDQUFDLElBQUksRUFBRTtZQUNaLEdBQUcsQ0FBQyxXQUFXLEdBQUcsSUFBSSxXQUFXLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUM7U0FDOUQ7UUFFRCxPQUFPLEdBQUcsQ0FBQyxXQUFXLENBQUM7SUFDekIsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxlQUFlLENBQUMsV0FBVyxFQUFFLFNBQVM7UUFDcEMsSUFBSSxTQUFTLEtBQUssU0FBUyxFQUFFO1lBQzNCLGlDQUFpQztZQUNqQyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUUsU0FBUyxFQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsQ0FBQztTQUNyRjtRQUVELGdDQUFnQztRQUNoQyxNQUFNLE9BQU8sR0FBRyxXQUFXLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUN2RCxJQUFJLE9BQU8sRUFBRTtZQUNYLE9BQU87U0FDUjtRQUVELG9DQUFvQztRQUNwQyxNQUFNLE1BQU0sQ0FBQyxNQUFNLENBQ2pCLFdBQVcsRUFDWCxlQUFlLEdBQUcsV0FBVyxDQUFDLElBQUk7WUFDbEMsTUFBTSxHQUFHLFdBQVcsQ0FBQyxFQUFFLEdBQUcsaUNBQWlDLEdBQUcsU0FBUyxHQUFHLElBQUksQ0FDL0UsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7Ozs7OztPQVVHO0lBQ0gsWUFBWSxDQUFDLEdBQUcsRUFBRSxpQkFBaUIsRUFBRSxnQkFBZ0I7UUFDbkQsMkJBQTJCO1FBQzNCLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDbkMsMkZBQTJGO1lBQzNGLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFO2dCQUNwQyxNQUFNLE1BQU0sQ0FBQyxNQUFNLENBQ2pCLFdBQVcsRUFDWCxlQUFlLEdBQUcsR0FBRyxDQUFDLFdBQVcsQ0FBQyxJQUFJO29CQUN0QyxNQUFNLEdBQUcsR0FBRyxDQUFDLFdBQVcsQ0FBQyxFQUFFLEdBQUcseUNBQXlDLENBQ3hFLENBQUM7YUFDSDtZQUVELDBEQUEwRDtZQUMxRCxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztTQUMxRDtRQUVELE1BQU0sa0JBQWtCLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUVwRCxJQUFJLENBQUMsZ0JBQWdCLElBQUksa0JBQWtCLENBQUMsRUFBRSxLQUFLLE9BQU8sQ0FBQyxLQUFLLENBQUMsYUFBYSxFQUFFO1lBQzlFLE1BQU0sTUFBTSxDQUFDLE1BQU0sQ0FDakIsV0FBVyxFQUNYLG9EQUFvRCxDQUNyRCxDQUFDO1NBQ0g7UUFFRCxPQUFPLGtCQUFrQixDQUFDO0lBQzVCLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gscUJBQXFCO1FBQ25CLE9BQU8sT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLFFBQVEsQ0FBQyxFQUFFO1lBQzdDLE9BQU8sUUFBUSxDQUFDLFlBQVksRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDdkMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDYixNQUFNLENBQUMsQ0FBQztZQUNWLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7SUFDZCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILGVBQWUsQ0FBQyxHQUFHLEVBQUUsVUFBVTtRQUM3QixPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ2pDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsR0FBRyxFQUFFLFVBQVUsQ0FBQyxDQUFDO1FBQ2hELENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O09Bc0JHO0lBQ0gsU0FBUyxDQUFDLEdBQUcsRUFBRSxVQUFVLEVBQUUsU0FBUyxFQUFFLGlCQUFpQixFQUFFLGdCQUFnQixFQUFFLFVBQVUsR0FBRyxJQUFJO1FBQzFGLElBQ0UsVUFBVSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUM7WUFDOUIsaUJBQWlCLEtBQUssYUFBYTtZQUNuQyxLQUFLLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsRUFDL0I7WUFDQSxPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQ2xCLGdCQUFnQixFQUFFLG9EQUFvRCxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsdUJBQXVCO1NBQ3pHO1FBRUQsSUFBSSxXQUFXLENBQUM7UUFDaEIsSUFBSTtZQUNGLCtEQUErRDtZQUMvRCxXQUFXLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsaUJBQWlCLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztTQUMzRTtRQUFDLE9BQU0sQ0FBQyxFQUFFO1lBQ1QsSUFBSSxVQUFVLEVBQUU7Z0JBQ2QsTUFBTSxDQUFDLENBQUM7YUFDVDtZQUVELE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUMvQjtRQUVELE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDakMsT0FBTyxXQUFXLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxTQUFTLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFDbEUsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxtQkFBbUI7UUFDakIsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsRUFBQyxVQUFVLEVBQUUsQ0FBQyxLQUFLLENBQUMsRUFBQyxDQUFDLENBQUMsR0FBRyxDQUFDLHVCQUF1QixDQUFDLEVBQUU7WUFDNUYsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsdUJBQXVCLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDckUsQ0FBQyxFQUFFLEVBQUMsV0FBVyxFQUFFLENBQUMsRUFBQyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7SUFDaEMsQ0FBQztJQUVEOzs7T0FHRztJQUNILG9CQUFvQjtRQUNsQixnQ0FBZ0M7UUFDaEMsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRTtZQUN6RSxNQUFNLFlBQVksR0FBRyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQywrQkFBK0I7WUFDdEUsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxFQUFFO2dCQUMvQixPQUFPLENBQUMsMkNBQTJDO2FBQ3BEO1lBRUQsMkJBQTJCO1lBQzNCLElBQUksWUFBWSxDQUFDO1lBQ2pCLDJCQUEyQjtZQUMzQixJQUFJLFVBQVUsQ0FBQztZQUVmLHNFQUFzRTtZQUN0RSxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztnQkFDNUIsT0FBTyxFQUFFLENBQUM7d0JBQ1IsS0FBSyxFQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxFQUFDLEVBQUUsRUFBRSxZQUFZLENBQUMsRUFBRSxFQUFDO3FCQUNyRCxDQUFDO2FBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRTtnQkFDMUIsWUFBWSxHQUFHLGFBQWEsQ0FBQztnQkFFN0IsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7b0JBQzVCLE9BQU8sRUFBRSxDQUFDOzRCQUNSLEtBQUssRUFBRSxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsRUFBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLEVBQUUsRUFBQzt5QkFDcEUsQ0FBQztpQkFBQyxDQUFDLENBQUM7WUFDVCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUU7Z0JBQ3BCLFVBQVUsR0FBRyxXQUFXLENBQUM7Z0JBRXpCLDRDQUE0QztnQkFDNUMsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQ3JELENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRTtnQkFDbkIsNEZBQTRGO2dCQUM1RixNQUFNLFNBQVMsR0FBRyxDQUFDLENBQUMsWUFBWSxDQUFDLFlBQVksRUFBRSxVQUFVLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBRWpFLE9BQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLEVBQUU7b0JBQ3JDLE9BQU8sS0FBSyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQztnQkFDbkMsQ0FBQyxFQUFFLEVBQUMsV0FBVyxFQUFFLENBQUMsRUFBQyxDQUFDLENBQUM7WUFDdkIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDWCxnREFBZ0Q7Z0JBQ2hELE9BQU8sWUFBWSxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUNoRCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNYLDhCQUE4QjtnQkFDOUIsT0FBTyxZQUFZLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDaEMsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsbUJBQW1CLENBQUMsV0FBVztRQUM3QixNQUFNLHlCQUF5QixHQUFHO1lBQ2hDLE9BQU8sRUFBRSxDQUFDO29CQUNSLEtBQUssRUFBRSxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsRUFBQyxFQUFFLEVBQUUsV0FBVyxDQUFDLEVBQUUsRUFBQztpQkFDcEQsQ0FBQztTQUNILENBQUM7UUFFRixNQUFNLDBCQUEwQixHQUFHO1lBQ2pDLEtBQUssRUFBRSxFQUFDLE9BQU8sRUFBRSxXQUFXLENBQUMsRUFBRSxFQUFDO1NBQ2pDLENBQUM7UUFFRiwyQkFBMkI7UUFDM0IsSUFBSSxXQUFXLENBQUM7UUFFaEIsMkRBQTJEO1FBQzNELE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLHlCQUF5QixDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFO1lBQzNFLFdBQVcsR0FBRyxZQUFZLENBQUM7WUFFM0IsdUNBQXVDO1lBQ3ZDLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDN0MsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLHVCQUF1QixDQUFDLEVBQUU7WUFDL0IsNERBQTREO1lBQzVELE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO2dCQUM1QixTQUFTLEVBQUUsdUJBQXVCLENBQUMsR0FBRztnQkFDdEMsSUFBSSxFQUFFLFdBQVcsQ0FBQyxJQUFJO2dCQUN0QixPQUFPLEVBQUUsS0FBSzthQUNmLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUU7Z0JBQ3RCLHNHQUFzRztnQkFDdEcsb0NBQW9DO2dCQUNwQyxNQUFNLFlBQVksR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLFlBQVksRUFDMUQsV0FBVyxDQUFDLEVBQUUsQ0FBQyxXQUFXLENBQUMsU0FBUyxLQUFLLGFBQWEsQ0FBQyxTQUFTLENBQ2pFLEVBQUUsbUJBQW1CLENBQUMsRUFBRTtvQkFDdkIsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQywwQkFBMEIsQ0FBQyxtQkFBbUIsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDckYsQ0FBQyxDQUFDLENBQUM7Z0JBRUgsOERBQThEO2dCQUM5RCxPQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUMsWUFBWSxFQUFFLFdBQVcsQ0FBQyxFQUFFO29CQUM3QyxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUU7d0JBQ3BFLE9BQU8sYUFBYSxDQUFDLGNBQWMsQ0FBQyxhQUFhLENBQUMsQ0FBQztvQkFDckQsQ0FBQyxDQUFDLENBQUM7Z0JBQ0wsQ0FBQyxFQUFFLEVBQUMsV0FBVyxFQUFFLENBQUMsRUFBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtvQkFDN0IsdURBQXVEO29CQUN2RCxPQUFPLGFBQWEsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBQzdDLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLEVBQUUsRUFBQyxXQUFXLEVBQUUsQ0FBQyxFQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQzdCLHNEQUFzRDtZQUN0RCxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQywwQkFBMEIsQ0FBQyxDQUFDO1FBQ25FLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCxnREFBZ0Q7WUFDaEQsT0FBTyxXQUFXLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQzlDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCw2QkFBNkI7WUFDN0IsT0FBTyxXQUFXLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDL0IsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7Ozs7T0FhRztJQUNILG1CQUFtQjtRQUNqQiwrQkFBK0I7UUFDL0IsT0FBTyxJQUFJLENBQUMsb0JBQW9CLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQzNDLG9DQUFvQztZQUNwQyxNQUFNLGdCQUFnQixHQUFHO2dCQUN2QixLQUFLLEVBQUUsRUFBQyxTQUFTLEVBQUUsR0FBRyxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUM7Z0JBQ3ZDLE9BQU8sRUFBRSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDO2FBQ2pDLENBQUM7WUFFRixPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsRUFBRTtnQkFDakUsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDL0MsQ0FBQyxFQUFFLEVBQUMsV0FBVyxFQUFFLENBQUMsRUFBQyxDQUFDLENBQUM7UUFDdkIsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7SUFDZCxDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLElBQUksYUFBYSxFQUFFLENBQUMifQ==