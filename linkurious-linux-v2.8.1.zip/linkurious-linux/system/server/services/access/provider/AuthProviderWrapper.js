/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-10-25.
 */
'use strict';
const Promise = require('bluebird');
const LKE = require('../../index');
const Errors = LKE.getErrors();
const Config = LKE.getConfig();
const Log = LKE.getLogger(__filename);
class AuthProviderWrapper {
    /**
     * @param {string} name      Human readable name
     * @param {string} configKey Configuration key (under `access` config root)
     * @param {string} className Location of the implementation file (relative to `access/provider` package)
     */
    constructor(name, configKey, className) {
        this.name = name;
        // load config
        this.config = Config.get('access.' + configKey, { enabled: false });
        this.enabled = this.config.enabled;
        // create the provider instance
        this.instance = this.enabled ? new (require('./' + className))() : null;
    }
    /**
     * @param {string} username
     * @param {string} password
     * @returns {Bluebird<ExternalUserProfile | null>} an external user
     */
    authenticate(username, password) {
        if (!this.enabled) {
            return Promise.resolve(null);
        }
        // not all auth providers can authenticate via username and password
        if (!this.instance.authenticate) {
            return Promise.resolve(null);
        }
        return this.instance.authenticate(username, password);
    }
    /**
     * Checked at startup (can be used to check connectivity with the auth server).
     *
     * @returns {Bluebird<void>}
     */
    startupCheck() {
        if (!this.enabled) {
            // Log.info('Auth provider "' + this.name + '": disabled');
            return Promise.resolve();
        }
        if (!this.instance.startupCheck) {
            Log.info('Auth provider "' + this.name + '": enabled');
            return Promise.resolve();
        }
        return this.instance.startupCheck().then(() => {
            Log.info('Auth provider "' + this.name + '": startup check success');
        }).catch(e => {
            Log.error('Auth provider "' + this.name + '": startup check failure');
            return Promise.reject(e);
        });
    }
    /**
     * Return the URL of the OAuth2/SAML2 authorization endpoint.
     *
     * The `state` parameter is only used by OAuth2.
     *
     * @param {string} state            A random string, stored in the current session, to be checked on AuthenticateURL response
     * @param {string} [requestBaseUrl] Base url of Linkurious where the user should be redirected by the authentication provider
     * @returns {Bluebird<string>} authenticateURL
     */
    getAuthenticateURLSSO(state, requestBaseUrl) {
        if (!this.instance.getAuthenticateURLSSO) {
            return Errors.technical('bug', 'getAuthenticateURLSSO() should only be called on the oauth2/saml2 provider.', true);
        }
        if (this.name === 'OAuth2') {
            return this.instance.getAuthenticateURLSSO(state, requestBaseUrl);
        }
        return this.instance.getAuthenticateURLSSO(requestBaseUrl);
    }
    /**
     * Authenticate the user via OAuth2/SAML2.
     *
     * @param {string} code
     * @param {string} [requestBaseUrl] Base url of Linkurious where the user was redirected by the authentication provider (for verification)
     * @returns {Bluebird<ExternalUserProfile>}
     */
    handleAuthenticateURLResponseSSO(code, requestBaseUrl) {
        if (!this.instance.handleAuthenticateURLResponseSSO) {
            return Errors.technical('bug', 'getAuthenticateURLSSO() should only be called on the oauth2/saml2 provider.', true);
        }
        return this.instance.handleAuthenticateURLResponseSSO(code, requestBaseUrl);
    }
}
module.exports = AuthProviderWrapper;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQXV0aFByb3ZpZGVyV3JhcHBlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NlcnZlci9zZXJ2aWNlcy9hY2Nlc3MvcHJvdmlkZXIvQXV0aFByb3ZpZGVyV3JhcHBlci5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7R0FLRztBQUNILFlBQVksQ0FBQztBQUNiLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNwQyxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUM7QUFDbkMsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBRXRDLE1BQU0sbUJBQW1CO0lBRXZCOzs7O09BSUc7SUFDSCxZQUFZLElBQUksRUFBRSxTQUFTLEVBQUUsU0FBUztRQUNwQyxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztRQUVqQixjQUFjO1FBQ2QsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLFNBQVMsR0FBRyxTQUFTLEVBQUUsRUFBQyxPQUFPLEVBQUUsS0FBSyxFQUFDLENBQUMsQ0FBQztRQUNsRSxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO1FBRW5DLCtCQUErQjtRQUMvQixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxHQUFHLFNBQVMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0lBQzFFLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsWUFBWSxDQUFDLFFBQVEsRUFBRSxRQUFRO1FBQzdCLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ2pCLE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUM5QjtRQUVELG9FQUFvRTtRQUNwRSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxZQUFZLEVBQUU7WUFDL0IsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQzlCO1FBRUQsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxRQUFRLEVBQUUsUUFBUSxDQUFDLENBQUM7SUFDeEQsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxZQUFZO1FBQ1YsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDakIsMkRBQTJEO1lBQzNELE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO1NBQzFCO1FBRUQsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsWUFBWSxFQUFFO1lBQy9CLEdBQUcsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLElBQUksR0FBRyxZQUFZLENBQUMsQ0FBQztZQUN2RCxPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQztTQUMxQjtRQUVELE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQzVDLEdBQUcsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLElBQUksR0FBRywwQkFBMEIsQ0FBQyxDQUFDO1FBQ3ZFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUNYLEdBQUcsQ0FBQyxLQUFLLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLElBQUksR0FBRywwQkFBMEIsQ0FBQyxDQUFDO1lBQ3RFLE9BQU8sT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUMzQixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILHFCQUFxQixDQUFDLEtBQUssRUFBRSxjQUFjO1FBQ3pDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLHFCQUFxQixFQUFFO1lBQ3hDLE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQzNCLDZFQUE2RSxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQ3hGO1FBRUQsSUFBSSxJQUFJLENBQUMsSUFBSSxLQUFLLFFBQVEsRUFBRTtZQUMxQixPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMscUJBQXFCLENBQUMsS0FBSyxFQUFFLGNBQWMsQ0FBQyxDQUFDO1NBQ25FO1FBRUQsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLHFCQUFxQixDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBQzdELENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxnQ0FBZ0MsQ0FBQyxJQUFJLEVBQUUsY0FBYztRQUNuRCxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxnQ0FBZ0MsRUFBRTtZQUNuRCxPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUMzQiw2RUFBNkUsRUFBRSxJQUFJLENBQUMsQ0FBQztTQUN4RjtRQUVELE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxnQ0FBZ0MsQ0FBQyxJQUFJLEVBQUUsY0FBYyxDQUFDLENBQUM7SUFDOUUsQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxtQkFBbUIsQ0FBQyJ9