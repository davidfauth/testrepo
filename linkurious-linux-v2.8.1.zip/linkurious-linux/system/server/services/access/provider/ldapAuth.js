/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-05-05.
 */
'use strict';
const _ = require('lodash');
const Promise = require('bluebird');
const ldapjs = require('ldapjs');
const LKE = require('../../index');
const Config = LKE.getConfig();
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
const Log = LKE.getLogger(__filename);
/**
 * @typedef {{url: string, bindDN?: string, bindPassword?: string, baseDN: string[], usernameField: string, emailField?: string, groupField?: string, tls?: {rejectUnauthorized?: boolean}}} LkConfigAccessLdap
 */
const TIMEOUT = 5000;
const CONNECT_TIMEOUT = 5000;
class LDAPClient {
    /**
     * @param {LkConfigAccessLdap} options
     */
    constructor(options) {
        this._options = options;
        this._requiredAttributes = _.compact([
            options.usernameField,
            options.emailField,
            options.groupField
        ]);
        this._connected = false;
    }
    /**
     * Bind the LDAP client to the LDAP server.
     * Return a rejected promise if the bind was unsuccessful.
     *
     * @returns {Bluebird<boolean>}
     * @private
     */
    _bind() {
        return new Promise((resolve, reject) => {
            this._ldapjsClient.bind(this._options.bindDN, this._options.bindPassword, bindError => {
                if (bindError) {
                    this._ldapjsClient.destroy();
                    if (bindError.name === 'InvalidCredentialsError' ||
                        bindError.name === 'NoSuchObjectError') {
                        Log.debug('Bind LDAP client failure (credentials)');
                        resolve(false);
                    }
                    else {
                        reject(bindError);
                    }
                }
                else {
                    this._connected = true;
                    Log.debug('Bind LDAP client success');
                    resolve(true);
                }
            });
        });
    }
    /**
     * Initialize the client and bind the LDAP client to the LDAP server.
     * Return a rejected promise if the bind was unsuccessful.
     *
     * @returns {Bluebird<boolean>}
     */
    bind() {
        if (this._connected) {
            Log.debug('Attempt to bind but the LDAP client was already connected');
            return Promise.resolve(false);
        }
        this._initClient();
        return Utils.retryPromise('Bind to the LDAP server', () => this._bind(), { delay: 2000, retries: 5, fullErrors: false }).catch(error => {
            Log.error('Bind LDAP client failure (error)', error);
            return Errors.technical('ldap_bind_error', 'Could not connect to the LDAP server (' + (error.message ? error.message : error) + ')', true);
        });
    }
    /**
     * Unbind the LDAP client from the LDAP server.
     */
    unbind() {
        this._connected = false;
        this._ldapjsClient.destroy();
        Log.debug('Unbind LDAP client success');
    }
    /**
     * @private
     */
    _initClient() {
        this._ldapjsClient = ldapjs.createClient({
            url: this._options.url,
            maxConnections: 1,
            timeout: TIMEOUT,
            connectTimeout: CONNECT_TIMEOUT,
            tlsOptions: this._options.tls
        });
        const onError = e => {
            Log.error(e);
            this.unbind();
        };
        this._ldapjsClient.on('error', onError);
        this._ldapjsClient.on('timeout', () => onError('Request timed out'));
        this._ldapjsClient.on('connectTimeout', () => onError('Connection timed out'));
        Log.debug('LDAP client created');
    }
    /**
     * Check if the pair `username` and `password` is valid.
     *
     * @param {string} username
     * @param {string} password
     * @param {string} [baseDN]
     *
     * @returns {Bluebird<string | null>} the baseDN where the user is located or null, if the credentials are not valid
     * @private
     */
    _checkCredentials(username, password, baseDN) {
        let baseDNs;
        if (Utils.hasValue(baseDN)) { // if we know already the right baseDN because LDAPClient.findUser knew it already
            baseDNs = [baseDN];
        }
        else { // otherwise we look in all the possible configured baseDN
            baseDNs = this._options.baseDN;
        }
        return Promise.map(baseDNs, baseDN => {
            const bindDN = `${this._options.usernameField}=${username},${baseDN}`;
            const client = new LDAPClient(_.defaults({ bindDN: bindDN, bindPassword: password }, this._options));
            return client.bind().then(validCredentials => {
                if (!validCredentials) {
                    return null;
                }
                client.unbind();
                return baseDN;
            });
        }, { concurrency: 1 }).then(validBaseDNs => _.get(validBaseDNs.filter(Utils.hasValue), 0));
    }
    /**
     * Create an LDAP filter for `username` equality.
     *
     * @param {string} username
     * @private
     */
    _createLDAPFilter(username) {
        return new ldapjs.filters.AndFilter({ filters: [
                new ldapjs.filters.EqualityFilter({
                    attribute: this._options.usernameField,
                    value: username
                })
            ] });
    }
    /**
     * Search for `username` under `baseDN`. Return the LDAP search result.
     *
     * @param {string} username
     * @param {string} baseDN
     * @returns {Bluebird<any>}
     * @private
     */
    _doLDAPSearch(username, baseDN) {
        return new Promise((resolve, reject) => {
            this._ldapjsClient.search(baseDN, {
                scope: 'sub',
                filter: this._createLDAPFilter(username),
                attributes: this._requiredAttributes,
                sizeLimit: 1,
                timeLimit: TIMEOUT
            }, (error, searchEvents) => {
                if (error) {
                    Log.error(error);
                    this.unbind();
                    return reject(Errors.technical('critical', error));
                }
                let result = null;
                searchEvents.on('searchEntry', entry => { result = entry && entry.object; });
                searchEvents.on('error', error => {
                    if (error.name === 'NoSuchObjectError') {
                        return resolve();
                    }
                    Log.error(error);
                    this.unbind();
                    reject(Errors.technical('critical', 'Could not communicate with the LDAP server (' +
                        (error.message ? error.message : error) + ')'));
                });
                searchEvents.on('end', () => resolve(result));
            });
        });
    }
    /**
     * Return the external profile of the user.
     *
     * @param {string} username
     * @param {string} baseDN
     *
     * @returns {Bluebird<ExternalUserProfile | null>}
     * @private
     */
    _retrieveUserProfile(username, baseDN) {
        return this.bind().then(validCredentials => {
            if (!validCredentials) {
                // the credentials for binding were already tested in LDAPClient._checkCredentials or
                // LDAPAuth.startupCheck. this code should be reachable only if the password was changed
                return Errors.technical('ldap_bind_error', 'Could not connect to the LDAP server (Invalid "bindDN", "bindPassword" credentials)', true);
            }
            return this._doLDAPSearch(username, baseDN).then(ldapSearchResult => {
                this.unbind();
                if (Utils.noValue(ldapSearchResult)) {
                    return null;
                }
                // parse the ldapSearchResult to the standard the external profile object
                const externalProfile = {
                    username: ldapSearchResult[this._options.usernameField],
                    email: ldapSearchResult[this._options.emailField] ||
                        Utils.generateRandomEmail(Config.get('customerId')),
                    externalGroupIds: []
                };
                if (Utils.hasValue(this._options.groupField)) {
                    const g = ldapSearchResult[this._options.groupField];
                    if (Utils.noValue(g)) {
                        // no group is set or `groupField` is wrong
                    }
                    else if (Array.isArray(g)) {
                        externalProfile.externalGroupIds = g.map(group => group + '');
                    }
                    else {
                        externalProfile.externalGroupIds.push(g + '');
                    }
                }
                return externalProfile;
            });
        });
    }
    /**
     * Check if the pair `username` and `password` is valid. Return the external profile of the user.
     *
     * @param {string} username
     * @param {string} password
     * @param {string} [baseDN]
     * @returns {Bluebird<ExternalUserProfile | null>}
     */
    findUser(username, password, baseDN) {
        return this._checkCredentials(username, password, baseDN).then(baseDN => {
            if (Utils.noValue(baseDN)) {
                return null;
            }
            // we know that the pair `username` and `password` is valid and that the username can be
            // found under `baseDN`
            return this._retrieveUserProfile(username, baseDN);
        });
    }
}
class LDAPAuth {
    constructor() {
        // whether or not a master LDAP client will be used
        if (Utils.hasValue(this.config.bindDN)) {
            // init LDAP admin client
            this._adminLDAPClient = new LDAPClient(this.config);
        } // else we will lazily create a client for each user trying to authenticate
    }
    /**
     * @type {LkConfigAccessLdap}
     */
    get config() {
        const config = Config.get('access.ldap');
        if (typeof config.baseDN === 'string') {
            config.baseDN = [config.baseDN];
        }
        return config;
    }
    /**
     * Check if `config.bindDN`, if in use, can bind.
     *
     * @returns {Bluebird<void>}
     */
    startupCheck() {
        if (Utils.noValue(this._adminLDAPClient)) {
            return Promise.resolve();
        }
        return this._adminLDAPClient.bind().then(validCredentials => {
            if (!validCredentials) {
                return Errors.business('ldap_bind_error', 'Could not connect to the LDAP server (Invalid "bindDN", "bindPassword" credentials)', true);
            }
            this._adminLDAPClient.unbind();
        });
    }
    /**
     * Check if the pair `username` and `password` is valid. Return the external profile of the user.
     *
     * @param {string} username
     * @param {string} password
     * @returns {Bluebird<ExternalUserProfile | null>}
     */
    authenticate(username, password) {
        if (Utils.hasValue(this._adminLDAPClient)) {
            // if we use the admin ldap client to find the user
            return this._adminLDAPClient.findUser(username, password);
        }
        // if we use the user itself to bind and we have 1 or multiple baseDN
        return Promise.map(this.config.baseDN, baseDN => {
            const bindDN = `${this.config.usernameField}=${username},${baseDN}`;
            const client = new LDAPClient(_.defaults({ bindDN: bindDN, bindPassword: password }, this.config));
            // we know that we have to search the user only in this baseDN
            return client.findUser(username, password, baseDN);
        }, { concurrency: 1 }).then(validExternalProfiles => _.get(validExternalProfiles.filter(Utils.hasValue), 0));
    }
}
module.exports = LDAPAuth;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGRhcEF1dGguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvYWNjZXNzL3Byb3ZpZGVyL2xkYXBBdXRoLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBQ2IsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNwQyxNQUFNLE1BQU0sR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDakMsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDO0FBQ25DLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7QUFFdEM7O0dBRUc7QUFFSCxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUM7QUFDckIsTUFBTSxlQUFlLEdBQUcsSUFBSSxDQUFDO0FBRTdCLE1BQU0sVUFBVTtJQUNkOztPQUVHO0lBQ0gsWUFBWSxPQUFPO1FBQ2pCLElBQUksQ0FBQyxRQUFRLEdBQUcsT0FBTyxDQUFDO1FBRXhCLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDO1lBQ25DLE9BQU8sQ0FBQyxhQUFhO1lBQ3JCLE9BQU8sQ0FBQyxVQUFVO1lBQ2xCLE9BQU8sQ0FBQyxVQUFVO1NBQ25CLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO0lBQzFCLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxLQUFLO1FBQ0gsT0FBTyxJQUFJLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsRUFBRTtZQUNyQyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLFlBQVksRUFBRSxTQUFTLENBQUMsRUFBRTtnQkFDcEYsSUFBSSxTQUFTLEVBQUU7b0JBQ2IsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLEVBQUUsQ0FBQztvQkFDN0IsSUFBSSxTQUFTLENBQUMsSUFBSSxLQUFLLHlCQUF5Qjt3QkFDNUMsU0FBUyxDQUFDLElBQUksS0FBSyxtQkFBbUIsRUFBRTt3QkFDMUMsR0FBRyxDQUFDLEtBQUssQ0FBQyx3Q0FBd0MsQ0FBQyxDQUFDO3dCQUNwRCxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7cUJBQ2hCO3lCQUFNO3dCQUNMLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQztxQkFDbkI7aUJBQ0Y7cUJBQU07b0JBQ0wsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7b0JBQ3ZCLEdBQUcsQ0FBQyxLQUFLLENBQUMsMEJBQTBCLENBQUMsQ0FBQztvQkFDdEMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO2lCQUNmO1lBQ0gsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILElBQUk7UUFDRixJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDbkIsR0FBRyxDQUFDLEtBQUssQ0FBQywyREFBMkQsQ0FBQyxDQUFDO1lBQ3ZFLE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUMvQjtRQUVELElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUVuQixPQUFPLEtBQUssQ0FBQyxZQUFZLENBQ3ZCLHlCQUF5QixFQUFFLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsRUFBRSxFQUFDLEtBQUssRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFDLENBQzVGLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ2QsR0FBRyxDQUFDLEtBQUssQ0FBQyxrQ0FBa0MsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUVyRCxPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQ3JCLGlCQUFpQixFQUNqQix3Q0FBd0MsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLEdBQUcsRUFDeEYsSUFBSSxDQUNMLENBQUM7UUFDSixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNILE1BQU07UUFDSixJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztRQUN4QixJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQzdCLEdBQUcsQ0FBQyxLQUFLLENBQUMsNEJBQTRCLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBRUQ7O09BRUc7SUFDSCxXQUFXO1FBQ1QsSUFBSSxDQUFDLGFBQWEsR0FBRyxNQUFNLENBQUMsWUFBWSxDQUFDO1lBQ3ZDLEdBQUcsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUc7WUFDdEIsY0FBYyxFQUFFLENBQUM7WUFDakIsT0FBTyxFQUFFLE9BQU87WUFDaEIsY0FBYyxFQUFFLGVBQWU7WUFDL0IsVUFBVSxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRztTQUM5QixDQUFDLENBQUM7UUFFSCxNQUFNLE9BQU8sR0FBRyxDQUFDLENBQUMsRUFBRTtZQUNsQixHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2IsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ2hCLENBQUMsQ0FBQztRQUVGLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQztRQUN4QyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsQ0FBQyxTQUFTLEVBQUUsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQztRQUNyRSxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsQ0FBQyxnQkFBZ0IsRUFBRSxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDO1FBRS9FLEdBQUcsQ0FBQyxLQUFLLENBQUMscUJBQXFCLENBQUMsQ0FBQztJQUNuQyxDQUFDO0lBRUQ7Ozs7Ozs7OztPQVNHO0lBQ0gsaUJBQWlCLENBQUMsUUFBUSxFQUFFLFFBQVEsRUFBRSxNQUFNO1FBQzFDLElBQUksT0FBTyxDQUFDO1FBRVosSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsa0ZBQWtGO1lBQzlHLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQ3BCO2FBQU0sRUFBRSwwREFBMEQ7WUFDakUsT0FBTyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDO1NBQ2hDO1FBRUQsT0FBTyxPQUFPLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsRUFBRTtZQUNuQyxNQUFNLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxJQUFJLFFBQVEsSUFBSSxNQUFNLEVBQUUsQ0FBQztZQUN0RSxNQUFNLE1BQU0sR0FBRyxJQUFJLFVBQVUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEVBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxZQUFZLEVBQUUsUUFBUSxFQUFDLEVBQy9FLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO1lBRWxCLE9BQU8sTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFO2dCQUMzQyxJQUFJLENBQUMsZ0JBQWdCLEVBQUU7b0JBQ3JCLE9BQU8sSUFBSSxDQUFDO2lCQUNiO2dCQUVELE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQztnQkFDaEIsT0FBTyxNQUFNLENBQUM7WUFDaEIsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLEVBQUUsRUFBQyxXQUFXLEVBQUUsQ0FBQyxFQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FDdkMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FDOUMsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILGlCQUFpQixDQUFDLFFBQVE7UUFDeEIsT0FBTyxJQUFJLE1BQU0sQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLEVBQUMsT0FBTyxFQUFFO2dCQUM1QyxJQUFJLE1BQU0sQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDO29CQUNoQyxTQUFTLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhO29CQUN0QyxLQUFLLEVBQUUsUUFBUTtpQkFDaEIsQ0FBQzthQUNILEVBQUMsQ0FBQyxDQUFDO0lBQ04sQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxhQUFhLENBQUMsUUFBUSxFQUFFLE1BQU07UUFDNUIsT0FBTyxJQUFJLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsRUFBRTtZQUNyQyxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUU7Z0JBQ2hDLEtBQUssRUFBRSxLQUFLO2dCQUNaLE1BQU0sRUFBRSxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDO2dCQUN4QyxVQUFVLEVBQUUsSUFBSSxDQUFDLG1CQUFtQjtnQkFDcEMsU0FBUyxFQUFFLENBQUM7Z0JBQ1osU0FBUyxFQUFFLE9BQU87YUFDbkIsRUFBRSxDQUFDLEtBQUssRUFBRSxZQUFZLEVBQUUsRUFBRTtnQkFDekIsSUFBSSxLQUFLLEVBQUU7b0JBQ1QsR0FBRyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDakIsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO29CQUNkLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUM7aUJBQ3BEO2dCQUVELElBQUksTUFBTSxHQUFHLElBQUksQ0FBQztnQkFDbEIsWUFBWSxDQUFDLEVBQUUsQ0FBQyxhQUFhLEVBQUUsS0FBSyxDQUFDLEVBQUUsR0FBRyxNQUFNLEdBQUcsS0FBSyxJQUFJLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFN0UsWUFBWSxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLEVBQUU7b0JBQy9CLElBQUksS0FBSyxDQUFDLElBQUksS0FBSyxtQkFBbUIsRUFBRTt3QkFDdEMsT0FBTyxPQUFPLEVBQUUsQ0FBQztxQkFDbEI7b0JBRUQsR0FBRyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDakIsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO29CQUVkLE1BQU0sQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUNyQixVQUFVLEVBQ1YsOENBQThDO3dCQUM5QyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLEdBQUcsQ0FDOUMsQ0FBQyxDQUFDO2dCQUNMLENBQUMsQ0FBQyxDQUFDO2dCQUNILFlBQVksQ0FBQyxFQUFFLENBQUMsS0FBSyxFQUFFLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1lBQ2hELENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSCxvQkFBb0IsQ0FBQyxRQUFRLEVBQUUsTUFBTTtRQUNuQyxPQUFPLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsRUFBRTtZQUN6QyxJQUFJLENBQUMsZ0JBQWdCLEVBQUU7Z0JBQ3JCLHFGQUFxRjtnQkFDckYsd0ZBQXdGO2dCQUN4RixPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQ3JCLGlCQUFpQixFQUNqQixxRkFBcUYsRUFDckYsSUFBSSxDQUNMLENBQUM7YUFDSDtZQUVELE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEVBQUU7Z0JBQ2xFLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztnQkFFZCxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsRUFBRTtvQkFDbkMsT0FBTyxJQUFJLENBQUM7aUJBQ2I7Z0JBRUQseUVBQXlFO2dCQUN6RSxNQUFNLGVBQWUsR0FBRztvQkFDdEIsUUFBUSxFQUFFLGdCQUFnQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDO29CQUN2RCxLQUFLLEVBQUUsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUM7d0JBQy9DLEtBQUssQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxDQUFDO29CQUNyRCxnQkFBZ0IsRUFBRSxFQUFFO2lCQUNyQixDQUFDO2dCQUVGLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxFQUFFO29CQUM1QyxNQUFNLENBQUMsR0FBRyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFDO29CQUNyRCxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7d0JBQ3BCLDJDQUEyQztxQkFDNUM7eUJBQU0sSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFO3dCQUMzQixlQUFlLENBQUMsZ0JBQWdCLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUMsQ0FBQztxQkFDL0Q7eUJBQU07d0JBQ0wsZUFBZSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7cUJBQy9DO2lCQUNGO2dCQUVELE9BQU8sZUFBZSxDQUFDO1lBQ3pCLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILFFBQVEsQ0FBQyxRQUFRLEVBQUUsUUFBUSxFQUFFLE1BQU07UUFDakMsT0FBTyxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxFQUFFLFFBQVEsRUFBRSxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDdEUsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFO2dCQUN6QixPQUFPLElBQUksQ0FBQzthQUNiO1lBRUQsd0ZBQXdGO1lBQ3hGLHVCQUF1QjtZQUV2QixPQUFPLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDckQsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0NBQ0Y7QUFFRCxNQUFNLFFBQVE7SUFDWjtRQUNFLG1EQUFtRDtRQUNuRCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUN0Qyx5QkFBeUI7WUFDekIsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksVUFBVSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUNyRCxDQUFDLDJFQUEyRTtJQUMvRSxDQUFDO0lBRUQ7O09BRUc7SUFDSCxJQUFJLE1BQU07UUFDUixNQUFNLE1BQU0sR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQ3pDLElBQUksT0FBTyxNQUFNLENBQUMsTUFBTSxLQUFLLFFBQVEsRUFBRTtZQUNyQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQ2pDO1FBRUQsT0FBTyxNQUFNLENBQUM7SUFDaEIsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxZQUFZO1FBQ1YsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFO1lBQ3hDLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO1NBQzFCO1FBRUQsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEVBQUU7WUFDMUQsSUFBSSxDQUFDLGdCQUFnQixFQUFFO2dCQUNyQixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQ3BCLGlCQUFpQixFQUNqQixxRkFBcUYsRUFDckYsSUFBSSxDQUNMLENBQUM7YUFDSDtZQUVELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNqQyxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxZQUFZLENBQUMsUUFBUSxFQUFFLFFBQVE7UUFDN0IsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFO1lBQ3pDLG1EQUFtRDtZQUNuRCxPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1NBQzNEO1FBRUQscUVBQXFFO1FBQ3JFLE9BQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsRUFBRTtZQUM5QyxNQUFNLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxJQUFJLFFBQVEsSUFBSSxNQUFNLEVBQUUsQ0FBQztZQUNwRSxNQUFNLE1BQU0sR0FBRyxJQUFJLFVBQVUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEVBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxZQUFZLEVBQUUsUUFBUSxFQUFDLEVBQy9FLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1lBRWhCLDhEQUE4RDtZQUM5RCxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFLFFBQVEsRUFBRSxNQUFNLENBQUMsQ0FBQztRQUNyRCxDQUFDLEVBQUUsRUFBQyxXQUFXLEVBQUUsQ0FBQyxFQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsRUFBRSxDQUNoRCxDQUFDLENBQUMsR0FBRyxDQUFDLHFCQUFxQixDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQ3ZELENBQUM7SUFDSixDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLFFBQVEsQ0FBQyJ9