/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2015-09-16.
 */
'use strict';
const _ = require('lodash');
const ActiveDirectory = require('activedirectory');
const Promise = require('bluebird');
const LKE = require('../../index');
const Config = LKE.getConfig();
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
const Log = LKE.getLogger(__filename);
const find = Promise.promisify(ActiveDirectory.prototype.find);
class MSActiveDirectoryAuth {
    /**
     * Connector to access Microsoft Active Directory users trough LDAP.
     */
    constructor() {
        this._baseDN = Config.get('access.msActiveDirectory.baseDN', undefined, true);
        this._url = Config.get('access.msActiveDirectory.url', undefined, true);
        this._domain = Config.get('access.msActiveDirectory.domain', undefined);
        this._netbiosDomain = Config.get('access.msActiveDirectory.netbiosDomain', undefined);
        this._tlsOptions = Config.get('access.msActiveDirectory.tls', undefined);
    }
    /**
     * Check if the pair `usernameOrEmail` and `password` is valid.
     * Return the external profile of the user.
     * Valid `usernameOrEmail` are:
     * - userPrincipalName, e.g.: "examplePrincipal@linkurio.us"
     * - userPrincipalName without domain, e.g.: "examplePrincipal"
     * - pre-Windows 2000 logon name, e.g.: "LINKURIO\exampleAMA"
     * - pre-Windows 2000 logon name without prefix, also called sAMAccountName, e.g.: "exampleAMA"
     *
     * @param {string} usernameOrEmail
     * @param {string} password
     * @returns {Bluebird<ExternalUserProfile | null>}
     */
    authenticate(usernameOrEmail, password) {
        // We first try to authenticate on 'userPrincipalName'
        let userPrincipalName = usernameOrEmail;
        // If `usernameOrEmail` is not an e-mail the domain that is set in the configuration is used to
        // generate an e-mail address `{username}@{domain}` that will be used as `userPrincipalName`
        if (!userPrincipalName.includes('@') && Utils.hasValue(this._domain)) {
            userPrincipalName += '@' + this._domain;
        }
        return this._authenticate(userPrincipalName, password, 'userPrincipalName', userPrincipalName)
            .then(externalUserProfile => {
            if (Utils.hasValue(externalUserProfile)) {
                return externalUserProfile;
            }
            // As second option, we try to authenticate on 'sAMAccountName'
            // If `usernameOrEmail` is not a pre-Windows 2000 logon name,
            // the NetBios domain that is set in the configuration is used to generate
            // a `{domain}\{username}` that will be used as such
            let userLogonName;
            let sAMAccountName;
            if (!usernameOrEmail.includes('\\')) {
                userLogonName = this._netbiosDomain + '\\' + usernameOrEmail;
                sAMAccountName = usernameOrEmail;
            }
            else {
                userLogonName = usernameOrEmail;
                sAMAccountName = usernameOrEmail.split('\\')[1];
            }
            return this._authenticate(userLogonName, password, 'sAMAccountName', sAMAccountName);
        });
    }
    /**
     * Bind to ActiveDirectory using `bindUser` and `bindPassword`.
     * Then, search a user profile where `ldapPropertyKey` is `ldapPropertyValue`.
     *
     * @param {string} bindUser
     * @param {string} bindPassword
     * @param {string} ldapPropertyKey   'userPrincipalName' or 'sAMAccountName'
     * @param {string} ldapPropertyValue
     * @returns {Bluebird<ExternalUserProfile | null>}
     * @private
     */
    _authenticate(bindUser, bindPassword, ldapPropertyKey, ldapPropertyValue) {
        const ad = new ActiveDirectory({
            url: this._url,
            baseDN: this._baseDN,
            username: bindUser,
            password: bindPassword
        });
        const query = '(&(objectCategory=User)(' + ldapPropertyKey + '=' + ldapPropertyValue + '))';
        const opts = {
            filter: query,
            includeMembership: ['all'],
            includeDeleted: false,
            tlsOptions: this._tlsOptions
        };
        return find.call(ad, opts).then(result => {
            if (result && result.users) {
                const users = result.users, length = users.length;
                let user, i;
                for (i = 0; i < length; ++i) {
                    user = users[i];
                    if (typeof user[ldapPropertyKey] === 'string' &&
                        user[ldapPropertyKey].toLowerCase() === ldapPropertyValue.toLowerCase()) {
                        // userPrincipalName can be empty, sAMAccountName can't. We want both to be defined
                        if (Utils.noValue(user.userPrincipalName)) {
                            throw Errors.business('invalid_parameter', 'This user doesn\' have a "userPrincipalName",' +
                                ' please contact your system administrator.');
                        }
                        return {
                            username: user.sAMAccountName,
                            email: user.userPrincipalName,
                            // user.groups contains both the distinguished name and the common name of a group
                            // CN, e.g.: "Administrators"
                            // DN, e.g.: "CN=Administrators,CN=Users,DC=linkurious,DC=local"
                            // We put both of them, as different groups, in the ExternalUserProfile instance
                            // s.t. our clients can use one or the other
                            externalGroupIds: _.flatten(_.map(user.groups, g => [g.dn, g.cn]))
                        };
                    }
                }
            }
            // no user found matching the query
            return null;
        }).catch(e => {
            if (e instanceof Errors.LkError) {
                throw e;
            }
            if (e.stack && e.stack.startsWith('InvalidCredentialsError')) {
                return null;
            }
            Log.error('ActiveDirectory.find failed', e);
            return Errors.technical('critical', 'Active Directory server returned an error.', true);
        });
    }
}
module.exports = MSActiveDirectoryAuth;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibXNBY3RpdmVEaXJlY3RvcnlBdXRoLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc2VydmVyL3NlcnZpY2VzL2FjY2Vzcy9wcm92aWRlci9tc0FjdGl2ZURpcmVjdG9yeUF1dGguanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFDYixNQUFNLENBQUMsR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDNUIsTUFBTSxlQUFlLEdBQUcsT0FBTyxDQUFDLGlCQUFpQixDQUFDLENBQUM7QUFDbkQsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3BDLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUNuQyxNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzdCLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBRXRDLE1BQU0sSUFBSSxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUUvRCxNQUFNLHFCQUFxQjtJQUV6Qjs7T0FFRztJQUNIO1FBQ0UsSUFBSSxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLGlDQUFpQyxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUM5RSxJQUFJLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsOEJBQThCLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3hFLElBQUksQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsRUFBRSxTQUFTLENBQUMsQ0FBQztRQUN4RSxJQUFJLENBQUMsY0FBYyxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsd0NBQXdDLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFDdEYsSUFBSSxDQUFDLFdBQVcsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLDhCQUE4QixFQUFFLFNBQVMsQ0FBQyxDQUFDO0lBQzNFLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7O09BWUc7SUFDSCxZQUFZLENBQUMsZUFBZSxFQUFFLFFBQVE7UUFFcEMsc0RBQXNEO1FBQ3RELElBQUksaUJBQWlCLEdBQUcsZUFBZSxDQUFDO1FBRXhDLCtGQUErRjtRQUMvRiw0RkFBNEY7UUFDNUYsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUNwRSxpQkFBaUIsSUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQztTQUN6QztRQUVELE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsRUFBRSxRQUFRLEVBQUUsbUJBQW1CLEVBQUUsaUJBQWlCLENBQUM7YUFDM0YsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEVBQUU7WUFDMUIsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLG1CQUFtQixDQUFDLEVBQUU7Z0JBQ3ZDLE9BQU8sbUJBQW1CLENBQUM7YUFDNUI7WUFFRCwrREFBK0Q7WUFFL0QsNkRBQTZEO1lBQzdELDBFQUEwRTtZQUMxRSxvREFBb0Q7WUFDcEQsSUFBSSxhQUFhLENBQUM7WUFDbEIsSUFBSSxjQUFjLENBQUM7WUFDbkIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQ25DLGFBQWEsR0FBRyxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksR0FBRyxlQUFlLENBQUM7Z0JBQzdELGNBQWMsR0FBRyxlQUFlLENBQUM7YUFDbEM7aUJBQU07Z0JBQ0wsYUFBYSxHQUFHLGVBQWUsQ0FBQztnQkFDaEMsY0FBYyxHQUFHLGVBQWUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDakQ7WUFFRCxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsYUFBYSxFQUFFLFFBQVEsRUFBRSxnQkFBZ0IsRUFBRSxjQUFjLENBQUMsQ0FBQztRQUN2RixDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRDs7Ozs7Ozs7OztPQVVHO0lBQ0gsYUFBYSxDQUFDLFFBQVEsRUFBRSxZQUFZLEVBQUUsZUFBZSxFQUFFLGlCQUFpQjtRQUN0RSxNQUFNLEVBQUUsR0FBRyxJQUFJLGVBQWUsQ0FBQztZQUM3QixHQUFHLEVBQUUsSUFBSSxDQUFDLElBQUk7WUFDZCxNQUFNLEVBQUUsSUFBSSxDQUFDLE9BQU87WUFDcEIsUUFBUSxFQUFFLFFBQVE7WUFDbEIsUUFBUSxFQUFFLFlBQVk7U0FDdkIsQ0FBQyxDQUFDO1FBRUgsTUFBTSxLQUFLLEdBQUcsMEJBQTBCLEdBQUcsZUFBZSxHQUFHLEdBQUcsR0FBRyxpQkFBaUIsR0FBRyxJQUFJLENBQUM7UUFDNUYsTUFBTSxJQUFJLEdBQUc7WUFDWCxNQUFNLEVBQUUsS0FBSztZQUNiLGlCQUFpQixFQUFFLENBQUMsS0FBSyxDQUFDO1lBQzFCLGNBQWMsRUFBRSxLQUFLO1lBQ3JCLFVBQVUsRUFBRSxJQUFJLENBQUMsV0FBVztTQUM3QixDQUFDO1FBRUYsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDdkMsSUFBSSxNQUFNLElBQUksTUFBTSxDQUFDLEtBQUssRUFBRTtnQkFDMUIsTUFBTSxLQUFLLEdBQUcsTUFBTSxDQUFDLEtBQUssRUFBRSxNQUFNLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQztnQkFDbEQsSUFBSSxJQUFJLEVBQUUsQ0FBQyxDQUFDO2dCQUVaLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO29CQUMzQixJQUFJLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUVoQixJQUFJLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLFFBQVE7d0JBQzNDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxXQUFXLEVBQUUsS0FBSyxpQkFBaUIsQ0FBQyxXQUFXLEVBQUUsRUFBRTt3QkFFekUsbUZBQW1GO3dCQUNuRixJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEVBQUU7NEJBQ3pDLE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FDbkIsbUJBQW1CLEVBQUUsK0NBQStDO2dDQUNwRSw0Q0FBNEMsQ0FDN0MsQ0FBQzt5QkFDSDt3QkFFRCxPQUFPOzRCQUNMLFFBQVEsRUFBRSxJQUFJLENBQUMsY0FBYzs0QkFDN0IsS0FBSyxFQUFFLElBQUksQ0FBQyxpQkFBaUI7NEJBQzdCLGtGQUFrRjs0QkFDbEYsNkJBQTZCOzRCQUM3QixnRUFBZ0U7NEJBQ2hFLGdGQUFnRjs0QkFDaEYsNENBQTRDOzRCQUM1QyxnQkFBZ0IsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQzt5QkFDbkUsQ0FBQztxQkFDSDtpQkFDRjthQUNGO1lBRUQsbUNBQW1DO1lBQ25DLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFO1lBQ1gsSUFBSSxDQUFDLFlBQVksTUFBTSxDQUFDLE9BQU8sRUFBRTtnQkFDL0IsTUFBTSxDQUFDLENBQUM7YUFDVDtZQUVELElBQUksQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyx5QkFBeUIsQ0FBQyxFQUFFO2dCQUM1RCxPQUFPLElBQUksQ0FBQzthQUNiO1lBRUQsR0FBRyxDQUFDLEtBQUssQ0FBQyw2QkFBNkIsRUFBRSxDQUFDLENBQUMsQ0FBQztZQUM1QyxPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLDRDQUE0QyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzFGLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxxQkFBcUIsQ0FBQyJ9