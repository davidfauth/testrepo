/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-11-28.
 */
'use strict';
const LKE = require('../../../index');
const Errors = LKE.getErrors();
class AbstractOAuth2 {
    /**
     * Parse the response of the tokenURL (including, but not limited to, the `access_token`)
     * to get username and email.
     *
     * @param {{access_token: string, id_token?: string}} response
     * @returns {Bluebird<ExternalUserProfile>}
     */
    getProfileData(response) {
        throw Errors.business('not_implemented', 'getProfileData is not implemented.');
    }
    /**
     * The OAuth2 scope.
     *
     * @returns {string} scope
     */
    getScope() {
        throw Errors.business('not_implemented', 'getScope is not implemented.');
    }
    /**
     * Params to be passed to the tokenURL to acquire the access token.
     *
     * @param {string} code
     * @param {string} clientID
     * @param {string} clientSecret
     * @param {string} redirectURL
     * @returns {any} params
     */
    getTokenURLParams(code, clientID, clientSecret, redirectURL) {
        return {
            code: code,
            'client_id': clientID,
            'client_secret': clientSecret,
            'redirect_uri': redirectURL,
            'grant_type': 'authorization_code'
        };
    }
}
module.exports = AbstractOAuth2;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWJzdHJhY3RvYXV0aDIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvYWNjZXNzL3Byb3ZpZGVyL29hdXRoMi9hYnN0cmFjdG9hdXRoMi5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7R0FLRztBQUNILFlBQVksQ0FBQztBQUViLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0FBQ3RDLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUUvQixNQUFNLGNBQWM7SUFDbEI7Ozs7OztPQU1HO0lBQ0gsY0FBYyxDQUFDLFFBQVE7UUFDckIsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUFDLGlCQUFpQixFQUFFLG9DQUFvQyxDQUFDLENBQUM7SUFDakYsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxRQUFRO1FBQ04sTUFBTSxNQUFNLENBQUMsUUFBUSxDQUFDLGlCQUFpQixFQUFFLDhCQUE4QixDQUFDLENBQUM7SUFDM0UsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsaUJBQWlCLENBQUMsSUFBSSxFQUFFLFFBQVEsRUFBRSxZQUFZLEVBQUUsV0FBVztRQUN6RCxPQUFPO1lBQ0wsSUFBSSxFQUFFLElBQUk7WUFDVixXQUFXLEVBQUUsUUFBUTtZQUNyQixlQUFlLEVBQUUsWUFBWTtZQUM3QixjQUFjLEVBQUUsV0FBVztZQUMzQixZQUFZLEVBQUUsb0JBQW9CO1NBQ25DLENBQUM7SUFDSixDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLGNBQWMsQ0FBQyJ9