/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-11-28.
 */
'use strict';
const AbstractOAuth2 = require('./abstractoauth2');
const LkRequest = require('../../../../lib/LkRequest');
class Github extends AbstractOAuth2 {
    constructor() {
        super();
        this._request = new LkRequest({
            headers: {
                'User-Agent': 'request'
            },
            json: true
        });
    }
    /**
     * The OAuth2 scope.
     *
     * @returns {string} scope
     */
    getScope() {
        return 'user:email';
    }
    /**
     * @param {{access_token: string}} response
     * @returns {Bluebird<ExternalUserProfile>}
     */
    getProfileData(response) {
        return this._request.get('https://api.github.com/user', { qs: { 'access_token': response.access_token } }).then(userR => {
            return { username: userR.body.login, email: userR.body.email };
        });
    }
}
module.exports = Github;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ2l0aHViLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vc2VydmVyL3NlcnZpY2VzL2FjY2Vzcy9wcm92aWRlci9vYXV0aDIvZ2l0aHViLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBQ2IsTUFBTSxjQUFjLEdBQUcsT0FBTyxDQUFDLGtCQUFrQixDQUFDLENBQUM7QUFDbkQsTUFBTSxTQUFTLEdBQUcsT0FBTyxDQUFDLDJCQUEyQixDQUFDLENBQUM7QUFFdkQsTUFBTSxNQUFPLFNBQVEsY0FBYztJQUVqQztRQUNFLEtBQUssRUFBRSxDQUFDO1FBQ1IsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLFNBQVMsQ0FBQztZQUM1QixPQUFPLEVBQUU7Z0JBQ1AsWUFBWSxFQUFFLFNBQVM7YUFDeEI7WUFDRCxJQUFJLEVBQUUsSUFBSTtTQUNYLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsUUFBUTtRQUNOLE9BQU8sWUFBWSxDQUFDO0lBQ3RCLENBQUM7SUFFRDs7O09BR0c7SUFDSCxjQUFjLENBQUMsUUFBUTtRQUNyQixPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLDZCQUE2QixFQUNwRCxFQUFDLEVBQUUsRUFBRSxFQUFDLGNBQWMsRUFBRSxRQUFRLENBQUMsWUFBWSxFQUFDLEVBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUM1RCxPQUFPLEVBQUMsUUFBUSxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBQyxDQUFDO1FBQy9ELENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUMifQ==