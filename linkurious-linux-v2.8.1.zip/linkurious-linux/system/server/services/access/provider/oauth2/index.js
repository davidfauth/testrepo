/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-11-25.
 */
'use strict';
const Promise = require('bluebird');
const url = require('url');
const _ = require('lodash');
const LkRequest = require('../../../../lib/LkRequest');
const LKE = require('../../../index');
const Errors = LKE.getErrors();
const Utils = LKE.getUtils();
const Config = LKE.getConfig();
class OAuth2 {
    startupCheck() {
        // retrieve OAuth2 specific configurations
        this.authorizationURL = Config.get('access.oauth2.authorizationURL');
        this.tokenURL = Config.get('access.oauth2.tokenURL');
        this.clientID = Config.get('access.oauth2.clientID');
        this.clientSecret = Config.get('access.oauth2.clientSecret');
        this.provider = Config.get('access.oauth2.provider');
        this.providerConfig = Config.get(`access.oauth2.${this.provider}`);
        // build the redirectURL based on the configuration
        this.redirectURL = LKE.getBaseURL('/api/auth/sso/return');
        this._request = new LkRequest({ baseUrl: this.tokenURL, json: true });
        // create the provider instance
        try {
            this.instance = new (require('./' + this.provider))(this.providerConfig);
        }
        catch (e) {
            return Errors.access('not_supported', `The provider "${this.provider}" was not initialized correctly: ${e.message}`, true);
        }
        this.scope = this.instance.getScope();
        return Promise.resolve();
    }
    /**
     * Return the URL of the OAuth2 authorization endpoint.
     *
     * @param {string} state            A random string, stored in the current session, to be checked on AuthenticateURL response
     * @param {string} [requestBaseUrl] Base url of Linkurious where the user should be redirected by the authentication provider
     * @returns {Bluebird<string>} authenticateURL
     */
    getAuthenticateURLSSO(state, requestBaseUrl) {
        const redirectURL = Utils.hasValue(requestBaseUrl)
            ? requestBaseUrl + '/api/auth/sso/return'
            : this.redirectURL;
        const parsedAuthUrl = url.parse(this.authorizationURL, true);
        parsedAuthUrl.query = _.assign(parsedAuthUrl.query, {
            'client_id': this.clientID,
            'response_type': 'code',
            scope: this.scope,
            'redirect_uri': redirectURL,
            state: state
        });
        parsedAuthUrl.search = undefined;
        return Promise.resolve(url.format(parsedAuthUrl));
    }
    /**
     * Authenticate the user via OAuth2.
     *
     * @param {string} code
     * @param {string} [requestBaseUrl] Base url of Linkurious where the user was redirected by the authentication provider (for verification)
     * @returns {Bluebird<ExternalUserProfile>}
     */
    handleAuthenticateURLResponseSSO(code, requestBaseUrl) {
        const redirectURL = Utils.hasValue(requestBaseUrl)
            ? requestBaseUrl + '/api/auth/sso/return'
            : this.redirectURL;
        const form = this.instance.getTokenURLParams(code, this.clientID, this.clientSecret, redirectURL);
        return this._request.post('', { form }).then(response => {
            return this.instance.getProfileData(response.body);
        });
    }
}
module.exports = OAuth2;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvYWNjZXNzL3Byb3ZpZGVyL29hdXRoMi9pbmRleC5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7R0FLRztBQUNILFlBQVksQ0FBQztBQUNiLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNwQyxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDM0IsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVCLE1BQU0sU0FBUyxHQUFHLE9BQU8sQ0FBQywyQkFBMkIsQ0FBQyxDQUFDO0FBQ3ZELE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0FBQ3RDLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBRS9CLE1BQU0sTUFBTTtJQUNWLFlBQVk7UUFDViwwQ0FBMEM7UUFDMUMsSUFBSSxDQUFDLGdCQUFnQixHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsZ0NBQWdDLENBQUMsQ0FBQztRQUNyRSxJQUFJLENBQUMsUUFBUSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLENBQUMsQ0FBQztRQUNyRCxJQUFJLENBQUMsUUFBUSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLENBQUMsQ0FBQztRQUNyRCxJQUFJLENBQUMsWUFBWSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsNEJBQTRCLENBQUMsQ0FBQztRQUM3RCxJQUFJLENBQUMsUUFBUSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLENBQUMsQ0FBQztRQUNyRCxJQUFJLENBQUMsY0FBYyxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDO1FBRW5FLG1EQUFtRDtRQUNuRCxJQUFJLENBQUMsV0FBVyxHQUFHLEdBQUcsQ0FBQyxVQUFVLENBQUMsc0JBQXNCLENBQUMsQ0FBQztRQUUxRCxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksU0FBUyxDQUFDLEVBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBQyxDQUFDLENBQUM7UUFFcEUsK0JBQStCO1FBQy9CLElBQUk7WUFDRixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztTQUMxRTtRQUFDLE9BQU0sQ0FBQyxFQUFFO1lBQ1QsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDLGVBQWUsRUFDbEMsaUJBQWlCLElBQUksQ0FBQyxRQUFRLG9DQUFvQyxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDeEY7UUFFRCxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFLENBQUM7UUFFdEMsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7SUFDM0IsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILHFCQUFxQixDQUFDLEtBQUssRUFBRSxjQUFjO1FBQ3pDLE1BQU0sV0FBVyxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDO1lBQ2hELENBQUMsQ0FBQyxjQUFjLEdBQUcsc0JBQXNCO1lBQ3pDLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDO1FBRXJCLE1BQU0sYUFBYSxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLGdCQUFnQixFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzdELGFBQWEsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsS0FBSyxFQUFFO1lBQ2xELFdBQVcsRUFBRSxJQUFJLENBQUMsUUFBUTtZQUMxQixlQUFlLEVBQUUsTUFBTTtZQUN2QixLQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUs7WUFDakIsY0FBYyxFQUFFLFdBQVc7WUFDM0IsS0FBSyxFQUFFLEtBQUs7U0FDYixDQUFDLENBQUM7UUFDSCxhQUFhLENBQUMsTUFBTSxHQUFHLFNBQVMsQ0FBQztRQUNqQyxPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxnQ0FBZ0MsQ0FBQyxJQUFJLEVBQUUsY0FBYztRQUNuRCxNQUFNLFdBQVcsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQztZQUNoRCxDQUFDLENBQUMsY0FBYyxHQUFHLHNCQUFzQjtZQUN6QyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQztRQUVyQixNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLGlCQUFpQixDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsUUFBUSxFQUM5RCxJQUFJLENBQUMsWUFBWSxFQUFFLFdBQVcsQ0FBQyxDQUFDO1FBRWxDLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFFLEVBQUMsSUFBSSxFQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDcEQsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDckQsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQyJ9