/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-11-25.
 */
'use strict';
const Promise = require('bluebird');
const jwt = require('jsonwebtoken');
const _ = require('lodash');
const AbstractOAuth2 = require('./abstractoauth2');
const LkRequest = require('./../../../../lib/LkRequest');
const LKE = require('./../../../index');
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
class OpenIDConnect extends AbstractOAuth2 {
    /**
     * @param {{userinfoURL?: string, scope?: string, groupClaim?: string}} oidcConf
     */
    constructor(oidcConf) {
        super();
        oidcConf = _.defaults(oidcConf, {});
        const userDefinedScope = Utils.hasValue(oidcConf.scope) ? oidcConf.scope.split(' ') : [];
        this._scope = _.union(['openid', 'profile', 'email'], userDefinedScope).join(' ');
        this._userinfoURL = oidcConf.userinfoURL;
        this._groupClaim = oidcConf.groupClaim;
        if (Utils.hasValue(this._groupClaim) && Utils.noValue(this._userinfoURL)) {
            throw Errors.business('invalid_parameter', 'access.oauth2.openidconnect.groupClaim is set ' +
                'but access.oauth2.openidconnect.userinfoURL is missing.');
        }
        if (Utils.hasValue(this._userinfoURL)) {
            this._request = new LkRequest({ baseUrl: this._userinfoURL, json: true });
        }
    }
    /**
     * The OAuth2 scope.
     *
     * @returns {string} scope
     */
    getScope() {
        return this._scope;
    }
    /**
     * Retrieve username and email of the user by parsing the ID token inside response.
     *
     * @param {{access_token: string, id_token: string}} response
     * @returns {Bluebird<ExternalUserProfile>}
     */
    getProfileData(response) {
        const decodedIDToken = jwt.decode(response.id_token);
        // no need to validate the ID token, since it's taken directly from the provider (hopefully) via secure HTTP
        const email = decodedIDToken.email;
        const username = decodedIDToken.name || decodedIDToken.email;
        if (Utils.hasValue(this._groupClaim)) {
            return this._request.get('', {
                headers: {
                    Authorization: 'Bearer ' + response.access_token
                }
            }).then(r => {
                const externalGroupIds = r.body[this._groupClaim] || [];
                return {
                    username: username,
                    email: email,
                    externalGroupIds: externalGroupIds
                };
            });
        }
        else {
            return Promise.resolve({ username: username, email: email });
        }
    }
}
module.exports = OpenIDConnect;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib3BlbmlkY29ubmVjdC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NlcnZlci9zZXJ2aWNlcy9hY2Nlc3MvcHJvdmlkZXIvb2F1dGgyL29wZW5pZGNvbm5lY3QuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFDYixNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDcEMsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDO0FBQ3BDLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM1QixNQUFNLGNBQWMsR0FBRyxPQUFPLENBQUMsa0JBQWtCLENBQUMsQ0FBQztBQUNuRCxNQUFNLFNBQVMsR0FBRyxPQUFPLENBQUMsNkJBQTZCLENBQUMsQ0FBQztBQUN6RCxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsa0JBQWtCLENBQUMsQ0FBQztBQUN4QyxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBRS9CLE1BQU0sYUFBYyxTQUFRLGNBQWM7SUFDeEM7O09BRUc7SUFDSCxZQUFZLFFBQVE7UUFDbEIsS0FBSyxFQUFFLENBQUM7UUFFUixRQUFRLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFFcEMsTUFBTSxnQkFBZ0IsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUN6RixJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLEVBQUUsU0FBUyxFQUFFLE9BQU8sQ0FBQyxFQUFFLGdCQUFnQixDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBRWxGLElBQUksQ0FBQyxZQUFZLEdBQUcsUUFBUSxDQUFDLFdBQVcsQ0FBQztRQUN6QyxJQUFJLENBQUMsV0FBVyxHQUFHLFFBQVEsQ0FBQyxVQUFVLENBQUM7UUFFdkMsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRTtZQUN4RSxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQ25CLG1CQUFtQixFQUNuQixnREFBZ0Q7Z0JBQ2hELHlEQUF5RCxDQUMxRCxDQUFDO1NBQ0g7UUFFRCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFO1lBQ3JDLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxTQUFTLENBQUMsRUFBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLFlBQVksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFDLENBQUMsQ0FBQztTQUN6RTtJQUNILENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsUUFBUTtRQUNOLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQztJQUNyQixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxjQUFjLENBQUMsUUFBUTtRQUNyQixNQUFNLGNBQWMsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNyRCw0R0FBNEc7UUFDNUcsTUFBTSxLQUFLLEdBQUcsY0FBYyxDQUFDLEtBQUssQ0FBQztRQUNuQyxNQUFNLFFBQVEsR0FBRyxjQUFjLENBQUMsSUFBSSxJQUFJLGNBQWMsQ0FBQyxLQUFLLENBQUM7UUFFN0QsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUNwQyxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRTtnQkFDM0IsT0FBTyxFQUFFO29CQUNQLGFBQWEsRUFBRSxTQUFTLEdBQUcsUUFBUSxDQUFDLFlBQVk7aUJBQ2pEO2FBQ0YsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDVixNQUFNLGdCQUFnQixHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDeEQsT0FBTztvQkFDTCxRQUFRLEVBQUUsUUFBUTtvQkFDbEIsS0FBSyxFQUFFLEtBQUs7b0JBQ1osZ0JBQWdCLEVBQUUsZ0JBQWdCO2lCQUNuQyxDQUFDO1lBQ0osQ0FBQyxDQUFDLENBQUM7U0FDSjthQUFNO1lBQ0wsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQUMsUUFBUSxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFDLENBQUMsQ0FBQztTQUM1RDtJQUNILENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsYUFBYSxDQUFDIn0=