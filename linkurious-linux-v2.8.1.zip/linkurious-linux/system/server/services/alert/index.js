"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-05-16.
 */
Object.defineProperty(exports, "__esModule", { value: true });
const Bluebird = require("bluebird");
const _ = require("lodash");
const alertDAO_1 = require("../../dao/sql/alertDAO");
const AlreadyExistsError_1 = require("../../models/errors/AlreadyExistsError");
const CantDeleteNonEmptyFolderError_1 = require("../../models/errors/CantDeleteNonEmptyFolderError");
const NotFoundError_1 = require("../../models/errors/NotFoundError");
const LKE = require('../index');
const Scheduler = LKE.getScheduler();
const Utils = LKE.getUtils();
const Log = LKE.getLogger(__filename);
const Data = LKE.getData();
const Db = LKE.getSqlDb();
const Config = LKE.getConfig();
const Errors = LKE.getErrors();
const OldAlertDAO = require('./OldAlertDAO');
const ALERT_GROUP = 'alert';
const DEFAULT_NUMBER_OF_VIEWERS_IN_GET_MATCHES = 7;
/**
 * It will delete old unconfirmed matches that lived beyond their expiration date.
 */
function cleanUpOldMatches() {
    return OldAlertDAO.cleanUpOldMatches();
}
class AlertService {
    constructor() {
        this.alertIdToSchedulerTaskId = new Map();
        this.semaphores = new Map();
        this.isAlertServiceStarted = false;
    }
    // TODO TS2019 refactor above here
    async createAlertFolder(params) {
        const sameTitleAlertFolder = await alertDAO_1.AlertDAO.getAlertFolderByTitle(params.title, params.parent);
        if (sameTitleAlertFolder) {
            throw new AlreadyExistsError_1.AlreadyExistsError('An alert folder in the same parent folder with title', params.title);
        }
        const alertFolderInstance = await alertDAO_1.AlertDAO.createAlertFolder(params);
        return {
            createdAt: alertFolderInstance.createdAt,
            updatedAt: alertFolderInstance.updatedAt,
            id: alertFolderInstance.id,
            parent: alertFolderInstance.parent,
            title: alertFolderInstance.title
        };
    }
    async updateAlertFolder(params) {
        const alertFolderInstance = await alertDAO_1.AlertDAO.getAlertFolder(params.id);
        if (!alertFolderInstance) {
            throw new NotFoundError_1.NotFoundError('alert_folder', params.id);
        }
        // if we update the title, let's check that no other alert folder
        // in the same parent folder has the same title
        if (Utils.hasValue(params.title)) {
            const sameTitleAlertFolder = await alertDAO_1.AlertDAO.getAlertFolderByTitle(params.title, params.parent || alertFolderInstance.parent);
            if (sameTitleAlertFolder) {
                throw new AlreadyExistsError_1.AlreadyExistsError('An alert folder in the same parent folder with title', params.title);
            }
        }
        // note: since we don't allow folders in folders we don't check that
        // moving the alert folder could result in having two alert folders
        // in the same parent folder with the same title
        const updateProperties = {
            title: params.title,
            parent: params.parent
        };
        await alertDAO_1.AlertDAO.updateAlertFolder(alertFolderInstance, updateProperties);
    }
    async deleteAlertFolder(params) {
        const alertFolderInstance = await alertDAO_1.AlertDAO.getAlertFolder(params.id);
        if (!alertFolderInstance) {
            throw new NotFoundError_1.NotFoundError('alert_folder', params.id);
        }
        if (!(await alertDAO_1.AlertDAO.isAlertFolderEmpty(alertFolderInstance))) {
            throw new CantDeleteNonEmptyFolderError_1.CantDeleteNonEmptyFolderError();
        }
        await alertDAO_1.AlertDAO.deleteAlertFolder(alertFolderInstance);
    }
    toAlertResponse(alertInstance) {
        return {
            id: alertInstance.id,
            folder: alertInstance.folder,
            title: alertInstance.title,
            sourceKey: alertInstance.sourceKey,
            query: alertInstance.query,
            dialect: alertInstance.dialect,
            enabled: alertInstance.enabled,
            columns: alertInstance.columns,
            cron: alertInstance.cron,
            lastRun: alertInstance.lastRun,
            lastRunProblem: alertInstance.lastRunProblem,
            nextRun: alertInstance.nextRun,
            createdAt: alertInstance.createdAt,
            updatedAt: alertInstance.updatedAt
        };
    }
    async getAlertTree(params, user) {
        // note: this version of getAlertTree doesn't support folders in folders other than root
        const folders = await alertDAO_1.AlertDAO.getAlertFolders(params.sourceKey);
        // we get only the readable alerts for a given user
        const alerts = (await alertDAO_1.AlertDAO.getAlerts(params.sourceKey)).filter(alert => user.canReadAlert(params.sourceKey, alert.id, false));
        // we create the children of the root folder
        // we initialize it with an entry for each alert folder
        const children = folders.map(folder => ({
            id: folder.id,
            title: folder.title,
            type: 'folder',
            children: []
        }));
        const childrenById = Utils.indexBy(children, (p) => p.id);
        // we add each alert to the children of its alert folder
        for (const alert of alerts) {
            let alertFolderChildren = children;
            // if the alert folder is different than root
            if (alert.folder !== -1) {
                // we pick the correct list of children
                alertFolderChildren =
                    childrenById.get(alert.folder) && childrenById.get(alert.folder).children;
            }
            if (alertFolderChildren) {
                alertFolderChildren.push(_.merge({ type: 'alert' }, this.toAlertResponse(alert)));
            }
        }
        return {
            id: -1,
            title: 'root',
            type: 'folder',
            children: children
        };
    }
    async getAlert(params, user) {
        await user.canReadAlert(params.sourceKey, params.id);
        const alertInstance = await alertDAO_1.AlertDAO.getAlert(params.id);
        if (!alertInstance) {
            throw new NotFoundError_1.NotFoundError('alert', params.id);
        }
        return this.toAlertResponse(alertInstance);
    }
    // TODO TS2019 refactor under here
    /**
     * Format an alert instance to a public alert:
     * - Add `nextRun` if `isAdmin` is true
     */
    _formatToPublicAlert(alertInstance, isAdmin) {
        const publicAlert = Db.models.alert.instanceToPublicAttributes(alertInstance);
        if (isAdmin) {
            const schedulerTaskId = this.alertIdToSchedulerTaskId.get(alertInstance.id);
            // schedulerTaskId doesn't exist if the alert is not enabled or the alert service is not started
            if (Utils.hasValue(schedulerTaskId)) {
                const nextRun = new Date(Scheduler.getTimeToSchedule(schedulerTaskId));
                const currentTime = new Date();
                // nextRun can be a date of the past, e.g. if the scheduler failed or it has yet to schedule
                if (nextRun < currentTime) {
                    // in that case, we set it as the current time
                    publicAlert.nextRun = currentTime;
                }
                else {
                    publicAlert.nextRun = nextRun;
                }
            }
            else {
                publicAlert.nextRun = null;
            }
        }
        return publicAlert;
    }
    /**
     * Format a match instance to a public match:
     * - Create the `columns` property (if `columnsDescription` is defined)
     * - Filter the `user` property
     * - Create the `viewers` property
     */
    _formatToPublicMatch(matchInstance, columnsDescription) {
        const publicMatch = Db.models.match.instanceToPublicAttributes(matchInstance, columnsDescription);
        // 1) filter the `user` property
        if (Utils.hasValue(matchInstance.user)) {
            publicMatch.user = {
                id: matchInstance.user.id,
                // @ts-ignore alert service to refactor
                username: matchInstance.user.username,
                // @ts-ignore alert service to refactor
                email: matchInstance.user.email
            };
        }
        else {
            publicMatch.user = null;
        }
        // @ts-ignore alert service to refactor
        if (Utils.noValue(matchInstance.matchActions)) {
            publicMatch.viewers = [];
            return publicMatch;
        }
        // 2) discover who are the viewers and their infos
        // viewers are users who performed an "open" match action on the match
        const viewerToDateMap = new Map();
        const viewerToUserObject = new Map();
        // @ts-ignore alert service to refactor
        for (const action of matchInstance.matchActions) {
            const previousTime = viewerToDateMap.get(action.userId);
            if (Utils.noValue(previousTime) || previousTime < action.createdAt) {
                viewerToDateMap.set(action.userId, action.createdAt);
            }
            if (!viewerToUserObject.has(action.userId)) {
                viewerToUserObject.set(action.userId, {
                    id: action.user.id,
                    username: action.user.username,
                    email: action.user.email
                });
            }
        }
        // 3) sort viewers by date and limit the number of viewers
        let viewerToDate = Array.from(viewerToDateMap.entries());
        // @ts-ignore alert service to refactor
        viewerToDate = _.orderBy(viewerToDate, item => item[1], ['desc']);
        viewerToDate.slice(0, DEFAULT_NUMBER_OF_VIEWERS_IN_GET_MATCHES);
        // 4) populate the match object with the viewers
        // @ts-ignore alert service to refactor
        publicMatch.viewers = _.map(viewerToDate, item => {
            const viewer = viewerToUserObject.get(item[0]);
            viewer.date = item[1];
            return viewer;
        });
        return publicMatch;
    }
    /**
     * Format a match action instance to a public match action:
     * - Filter the `user` property
     */
    _formatToPublicMatchAction(matchActionInstance) {
        const publicMatchAction = Db.models.matchAction.instanceToPublicAttributes(matchActionInstance);
        // 1) filter the `user` property
        // @ts-ignore alert service to refactor
        if (Utils.hasValue(matchActionInstance.user)) {
            publicMatchAction.user = {
                // @ts-ignore alert service to refactor
                id: matchActionInstance.user.id,
                // @ts-ignore alert service to refactor
                username: matchActionInstance.user.username,
                // @ts-ignore alert service to refactor
                email: matchActionInstance.user.email
            };
        }
        else {
            publicMatchAction.user = null;
        }
        return publicMatchAction;
    }
    /**
     * Schedule all the alerts in the system.
     * For each enabled alert, if lastRun is null, it will execute the query the next time compatible
     * with `alert.cron`. If lastRun isn't null, it will check if it should have executed in the past.
     * If true, it will execute the query immediately.
     */
    start() {
        if (!Config.get('alerts.enabled')) {
            Log.info('Alerts are disabled');
            return;
        }
        try {
            Scheduler.setGroupConcurrency(ALERT_GROUP, Config.get('alerts.maxConcurrency', 1));
            // cleanup old matches everyday at 00:00 (local timezone)
            Scheduler.scheduleTask(cleanUpOldMatches, '0 0 * * *', { group: ALERT_GROUP });
            // @ts-ignore alert service to refactor
            return OldAlertDAO.getAlerts(null, true).then(alerts => {
                for (const alert of alerts) {
                    if (alert.enabled) {
                        const id = Scheduler.scheduleTask(this.runAlert.bind(this, alert), alert.cron, {
                            group: ALERT_GROUP,
                            lastRun: alert.lastRun ? alert.lastRun : new Date(alert.createdAt)
                        });
                        this.alertIdToSchedulerTaskId.set(alert.id, id);
                    }
                }
                this.isAlertServiceStarted = true;
            });
        }
        catch (err) {
            Log.error("The alert manager couldn't schedule alerts due to invalid arguments.", err);
        }
    }
    /**
     * Run the alert.
     * It will query the db, generate the matches and update `alert.lastRun` to new Date().
     * Return null, if there were no problems.
     */
    runAlert(alert) {
        return (Data.alertQuery({
            // @ts-ignore alert service to refactor
            dialect: alert.dialect,
            // @ts-ignore alert service to refactor
            query: alert.query,
            // @ts-ignore alert service to refactor
            sourceKey: alert.sourceKey,
            // @ts-ignore alert service to refactor
            limit: alert.maxMatches
        })
            // @ts-ignore alert service to refactor
            .then(queryMatchStream => {
            /**
             * If at least one match is created, partial will be set to true so that if we have a problem
             * we know that it depends on some particular matches.
             */
            return this.createMatchesInBulk(queryMatchStream, alert);
        })
            // @ts-ignore alert service to refactor
            .catch(err => {
            if (err instanceof Bluebird.CancellationError) {
                throw err;
            }
            Log.error('RunAlert: Could not create matches in bulk: ', err);
            if (Utils.hasValue(err.message)) {
                return { error: err.message, partial: false };
            }
            return { error: err, partial: false };
        })
            // @ts-ignore alert service to refactor
            .then(problem => {
            // "problem" is null if there wasn't any problem
            // @ts-ignore alert service to refactor
            alert.lastRunProblem = problem;
            // @ts-ignore alert service to refactor
            alert.lastRun = new Date();
            return alert
                .save()
                .catch(err => {
                if (!(err instanceof Bluebird.CancellationError)) {
                    Log.error(`RunAlert: Could not update alert #${alert.id} in the database.`, err);
                }
            })
                .return(problem);
        }));
    }
    /**
     * OldAlertDAO.createMatchesInBulk under semaphore lock for the alert.
     * Return null, if there were no problems
     */
    createMatchesInBulk(queryMatchStream, alert) {
        return this._acquireAlertSemaphore(alert.id)
            .then(() => {
            return OldAlertDAO.createMatchesInBulk(queryMatchStream, alert);
        })
            .finally(() => this._releaseAlertSemaphore(alert.id));
    }
    /**
     * Create a new alert and schedule its first run.
     */
    createAlert(newAlert, currentUser) {
        // @ts-ignore alert service to refactor
        return OldAlertDAO.createAlert(newAlert, currentUser).then(alert => {
            if (alert.enabled && this.isAlertServiceStarted) {
                const id = Scheduler.scheduleTask(this.runAlert.bind(this, alert), alert.cron, { group: ALERT_GROUP, lastRun: new Date(0) } // new alerts will schedule immediately
                );
                this.alertIdToSchedulerTaskId.set(alert.id, id);
            }
            return this._formatToPublicAlert(alert, true);
        });
    }
    /**
     * Create/acquire the semaphore for the given alert.
     */
    _acquireAlertSemaphore(alertId) {
        if (!this.semaphores.has(alertId)) {
            this.semaphores.set(alertId, Utils.semaphore(1));
        }
        // @ts-ignore alert service to refactor
        return this.semaphores.get(alertId).acquire();
    }
    /**
     * Release/destroy the semaphore for the given alert.
     */
    _releaseAlertSemaphore(alertId) {
        const semaphore = this.semaphores.get(alertId);
        // @ts-ignore alert service to refactor
        semaphore.release();
        // @ts-ignore alert service to refactor
        if (semaphore.queue.length === 0 && semaphore.active === 0) {
            this.semaphores.delete(alertId);
        }
    }
    /**
     * Delete an alert.
     */
    deleteAlert(id, currentUser) {
        return this._acquireAlertSemaphore(id)
            .then(() => {
            Utils.check.exist('currentUser', currentUser);
            const schedulerTaskId = this.alertIdToSchedulerTaskId.get(id);
            // schedulerTaskId doesn't exist if the alert is not enabled or the alert service is not started
            if (Utils.hasValue(schedulerTaskId)) {
                Scheduler.cancel(schedulerTaskId);
            }
            return OldAlertDAO.deleteAlert(id).then(() => {
                this.alertIdToSchedulerTaskId.delete(id);
            });
        })
            .finally(() => this._releaseAlertSemaphore(id));
    }
    /**
     * Update an alert.
     *
     * id, sourceKey, userId, lastRun and lastRunProblem cannot be updated and will be silently
     * ignored.
     */
    updateAlert(alertId, newProperties, currentUser) {
        return this._acquireAlertSemaphore(alertId)
            .then(() => {
            Utils.check.exist('currentUser', currentUser);
            // @ts-ignore alert service to refactor
            return OldAlertDAO.updateAlert(alertId, newProperties).then(alert => {
                // if the columns field was changed, all the matches and actions
                // of the update alert are deleted and the alert, if enabled, rescheduled immediately
                // @ts-ignore alert service to refactor
                const needCleanAlert = Utils.hasValue(newProperties.columns);
                // if the cron field was changed, we reschedule immediately
                // @ts-ignore alert service to refactor
                const needReschedule = Utils.hasValue(newProperties.cron);
                return Promise.resolve()
                    .then(() => {
                    if (needCleanAlert) {
                        Log.info(`Update of alert #${alertId} required to delete all previous matches.`);
                        return OldAlertDAO.deleteMatchAndActions(alertId);
                    }
                })
                    .then(() => {
                    const schedulerTaskId = this.alertIdToSchedulerTaskId.get(alert.id);
                    // schedulerTaskId doesn't exist if the alert is not enabled or the alert service is not started
                    if (Utils.hasValue(schedulerTaskId)) {
                        Scheduler.cancel(schedulerTaskId);
                    }
                    if (alert.enabled) {
                        const id = Scheduler.scheduleTask(this.runAlert.bind(this, alert), alert.cron, {
                            group: ALERT_GROUP,
                            lastRun: needCleanAlert || needReschedule ? new Date(0) : alert.lastRun
                        });
                        if (this.isAlertServiceStarted) {
                            this.alertIdToSchedulerTaskId.set(alert.id, id);
                        }
                    }
                    else {
                        this.alertIdToSchedulerTaskId.delete(alert.id);
                    }
                    return this._formatToPublicAlert(alert, true);
                });
            });
        })
            .finally(() => this._releaseAlertSemaphore(alertId));
    }
    /**
     * Get all the matches for a given alert.
     *
     * All the matches have an addition field called 'viewers'.
     * It shows the last `DEFAULT_NUMBER_OF_VIEWERS_IN_GET_MATCHES` unique viewers (excluding the
     * current user) ordered by date.
     */
    getMatches(sourceKey, alertId, options, currentUser) {
        Utils.check.exist('currentUser', currentUser);
        // @ts-ignore alert service to refactor
        let columnsDescription;
        return (currentUser
            .canReadAlert(sourceKey, alertId)
            .then(() => {
            // @ts-ignore alert service to refactor
            return OldAlertDAO.getAlert(alertId, true).then(alert => {
                columnsDescription = alert.columns;
            });
        })
            .then(() => {
            return OldAlertDAO.getMatches(alertId, currentUser, options);
        })
            // @ts-ignore alert service to refactor
            .map(match => this._formatToPublicMatch(match, columnsDescription)));
    }
    /**
     * Get the count for each possible status of all the matches for a given alert.
     */
    getMatchCount(sourceKey, alertId, currentUser) {
        Utils.check.exist('currentUser', currentUser);
        return currentUser.canReadAlert(sourceKey, alertId).then(() => {
            return OldAlertDAO.getMatchCount(alertId);
        });
    }
    _getMatch(matchId, currentUser, sourceKey, alertId) {
        Utils.check.posInt('matchId', matchId);
        Utils.check.exist('currentUser', currentUser);
        // @ts-ignore alert service to refactor
        return OldAlertDAO.getMatch(matchId, currentUser).then(match => {
            if (Utils.hasValue(alertId) && alertId !== match.alertId) {
                return Errors.business('invalid_parameter', `Match #${matchId} doesn't belong to alert #${alertId}.`, true);
            }
            if (Utils.hasValue(sourceKey) && sourceKey !== match.sourceKey) {
                return Errors.business('invalid_parameter', `Match #${matchId} doesn't belong to data-source "${sourceKey}".`, true);
            }
            return currentUser.canReadAlert(match.sourceKey, match.alertId).return(match);
        });
    }
    /**
     * Get a match by id.
     */
    getMatch(matchId, currentUser, sourceKey, alertId) {
        // @ts-ignore alert service to refactor
        let columnsDescription;
        return (Bluebird.resolve()
            .then(() => {
            if (Utils.hasValue(alertId)) {
                // @ts-ignore alert service to refactor
                return OldAlertDAO.getAlert(alertId, true).then(alert => {
                    columnsDescription = alert.columns;
                });
            } // else we don't populate the columns property in the match
            // This case occurs in populate sandbox by match id (where the alert id is not immediately available)
        })
            .then(() => {
            return this._getMatch(matchId, currentUser, sourceKey, alertId);
        })
            // @ts-ignore alert service to refactor
            .then(match => this._formatToPublicMatch(match, columnsDescription)));
    }
    /**
     * Do an action on a match.
     */
    doMatchAction(sourceKey, alertId, matchId, action, currentUser) {
        return this._getMatch(matchId, currentUser, sourceKey, alertId).then(match => {
            return OldAlertDAO.doMatchAction(match, action, currentUser).return();
        });
    }
    /**
     * Get all the actions for a given match.
     */
    getMatchActions(sourceKey, alertId, matchId, options, currentUser) {
        /**
         * _getMatch is used for access control.
         * We need to retrieve the match to be sure that `alertId` is equal to `match.alertId`
         */
        return this._getMatch(matchId, currentUser, sourceKey, alertId).then(() => {
            // @ts-ignore alert service to refactor
            return OldAlertDAO.getMatchActions(matchId, options).map(action => this._formatToPublicMatchAction(action));
        });
    }
    /**
     * Get the promise of the next execution of a given alert by id.
     */
    getPromise(alertId) {
        return Scheduler.getPromise(this.alertIdToSchedulerTaskId.get(alertId)).return();
    }
    /**
     * Delete confirmed duplicate matches.
     * The migration to matches v2 was broken because the hashes were not recomputed.
     * To fix that, we recompute the hashes and we remove duplicate matches.
     *
     * @backward-compatibility
     */
    cleanUpDuplicateMatches() {
        return OldAlertDAO.cleanUpDuplicateMatches();
    }
}
exports.AlertService = AlertService;
module.exports = new AlertService();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvYWxlcnQvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7OztHQUtHOztBQVdILHFDQUFzQztBQUN0Qyw0QkFBNEI7QUFFNUIscURBQWdEO0FBQ2hELCtFQUEwRTtBQUMxRSxxR0FBZ0c7QUFDaEcscUVBQWdFO0FBV2hFLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUVoQyxNQUFNLFNBQVMsR0FBRyxHQUFHLENBQUMsWUFBWSxFQUFFLENBQUM7QUFDckMsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzdCLE1BQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDdEMsTUFBTSxJQUFJLEdBQUcsR0FBRyxDQUFDLE9BQU8sRUFBRSxDQUFDO0FBQzNCLE1BQU0sRUFBRSxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUMxQixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sV0FBVyxHQUFHLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQztBQUU3QyxNQUFNLFdBQVcsR0FBRyxPQUFPLENBQUM7QUFDNUIsTUFBTSx3Q0FBd0MsR0FBRyxDQUFDLENBQUM7QUFFbkQ7O0dBRUc7QUFDSCxTQUFTLGlCQUFpQjtJQUN4QixPQUFPLFdBQVcsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO0FBQ3pDLENBQUM7QUFFRCxNQUFhLFlBQVk7SUFLdkI7UUFDRSxJQUFJLENBQUMsd0JBQXdCLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQztRQUMxQyxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7UUFDNUIsSUFBSSxDQUFDLHFCQUFxQixHQUFHLEtBQUssQ0FBQztJQUNyQyxDQUFDO0lBRUQsa0NBQWtDO0lBRTNCLEtBQUssQ0FBQyxpQkFBaUIsQ0FDNUIsTUFBK0I7UUFFL0IsTUFBTSxvQkFBb0IsR0FBRyxNQUFNLG1CQUFRLENBQUMscUJBQXFCLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDL0YsSUFBSSxvQkFBb0IsRUFBRTtZQUN4QixNQUFNLElBQUksdUNBQWtCLENBQzFCLHNEQUFzRCxFQUN0RCxNQUFNLENBQUMsS0FBSyxDQUNiLENBQUM7U0FDSDtRQUVELE1BQU0sbUJBQW1CLEdBQUcsTUFBTSxtQkFBUSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRXJFLE9BQU87WUFDTCxTQUFTLEVBQUUsbUJBQW1CLENBQUMsU0FBUztZQUN4QyxTQUFTLEVBQUUsbUJBQW1CLENBQUMsU0FBUztZQUN4QyxFQUFFLEVBQUUsbUJBQW1CLENBQUMsRUFBRTtZQUMxQixNQUFNLEVBQUUsbUJBQW1CLENBQUMsTUFBTTtZQUNsQyxLQUFLLEVBQUUsbUJBQW1CLENBQUMsS0FBSztTQUNqQyxDQUFDO0lBQ0osQ0FBQztJQUVNLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxNQUErQjtRQUM1RCxNQUFNLG1CQUFtQixHQUFHLE1BQU0sbUJBQVEsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ3JFLElBQUksQ0FBQyxtQkFBbUIsRUFBRTtZQUN4QixNQUFNLElBQUksNkJBQWEsQ0FBQyxjQUFjLEVBQUUsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1NBQ3BEO1FBRUQsaUVBQWlFO1FBQ2pFLCtDQUErQztRQUMvQyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ2hDLE1BQU0sb0JBQW9CLEdBQUcsTUFBTSxtQkFBUSxDQUFDLHFCQUFxQixDQUMvRCxNQUFNLENBQUMsS0FBTSxFQUNiLE1BQU0sQ0FBQyxNQUFNLElBQUksbUJBQW1CLENBQUMsTUFBTSxDQUM1QyxDQUFDO1lBQ0YsSUFBSSxvQkFBb0IsRUFBRTtnQkFDeEIsTUFBTSxJQUFJLHVDQUFrQixDQUMxQixzREFBc0QsRUFDdEQsTUFBTSxDQUFDLEtBQU0sQ0FDZCxDQUFDO2FBQ0g7U0FDRjtRQUVELG9FQUFvRTtRQUNwRSxtRUFBbUU7UUFDbkUsZ0RBQWdEO1FBRWhELE1BQU0sZ0JBQWdCLEdBQUc7WUFDdkIsS0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO1lBQ25CLE1BQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtTQUN0QixDQUFDO1FBRUYsTUFBTSxtQkFBUSxDQUFDLGlCQUFpQixDQUFDLG1CQUFtQixFQUFFLGdCQUFnQixDQUFDLENBQUM7SUFDMUUsQ0FBQztJQUVNLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxNQUErQjtRQUM1RCxNQUFNLG1CQUFtQixHQUFHLE1BQU0sbUJBQVEsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBRXJFLElBQUksQ0FBQyxtQkFBbUIsRUFBRTtZQUN4QixNQUFNLElBQUksNkJBQWEsQ0FBQyxjQUFjLEVBQUUsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1NBQ3BEO1FBRUQsSUFBSSxDQUFDLENBQUMsTUFBTSxtQkFBUSxDQUFDLGtCQUFrQixDQUFDLG1CQUFtQixDQUFDLENBQUMsRUFBRTtZQUM3RCxNQUFNLElBQUksNkRBQTZCLEVBQUUsQ0FBQztTQUMzQztRQUVELE1BQU0sbUJBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0lBQ3hELENBQUM7SUFFTyxlQUFlLENBQUMsYUFBNEI7UUFDbEQsT0FBTztZQUNMLEVBQUUsRUFBRSxhQUFhLENBQUMsRUFBRTtZQUNwQixNQUFNLEVBQUUsYUFBYSxDQUFDLE1BQU07WUFDNUIsS0FBSyxFQUFFLGFBQWEsQ0FBQyxLQUFLO1lBQzFCLFNBQVMsRUFBRSxhQUFhLENBQUMsU0FBUztZQUNsQyxLQUFLLEVBQUUsYUFBYSxDQUFDLEtBQUs7WUFDMUIsT0FBTyxFQUFFLGFBQWEsQ0FBQyxPQUFPO1lBQzlCLE9BQU8sRUFBRSxhQUFhLENBQUMsT0FBTztZQUM5QixPQUFPLEVBQUUsYUFBYSxDQUFDLE9BQU87WUFDOUIsSUFBSSxFQUFFLGFBQWEsQ0FBQyxJQUFJO1lBQ3hCLE9BQU8sRUFBRSxhQUFhLENBQUMsT0FBTztZQUM5QixjQUFjLEVBQUUsYUFBYSxDQUFDLGNBQWM7WUFDNUMsT0FBTyxFQUFFLGFBQWEsQ0FBQyxPQUFPO1lBQzlCLFNBQVMsRUFBRSxhQUFhLENBQUMsU0FBUztZQUNsQyxTQUFTLEVBQUUsYUFBYSxDQUFDLFNBQVM7U0FDbkMsQ0FBQztJQUNKLENBQUM7SUFFTSxLQUFLLENBQUMsWUFBWSxDQUN2QixNQUEwQixFQUMxQixJQUFpQjtRQUVqQix3RkFBd0Y7UUFDeEYsTUFBTSxPQUFPLEdBQUcsTUFBTSxtQkFBUSxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7UUFFakUsbURBQW1EO1FBQ25ELE1BQU0sTUFBTSxHQUFHLENBQUMsTUFBTSxtQkFBUSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FDekUsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxFQUFFLEVBQUUsS0FBSyxDQUFDLENBQ3JELENBQUM7UUFFRiw0Q0FBNEM7UUFDNUMsdURBQXVEO1FBQ3ZELE1BQU0sUUFBUSxHQUErQyxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUNsRixFQUFFLEVBQUUsTUFBTSxDQUFDLEVBQUU7WUFDYixLQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7WUFDbkIsSUFBSSxFQUFFLFFBQVE7WUFDZCxRQUFRLEVBQUUsRUFBRTtTQUNiLENBQUMsQ0FBQyxDQUFDO1FBRUosTUFBTSxZQUFZLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFvQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7UUFFN0Ysd0RBQXdEO1FBQ3hELEtBQUssTUFBTSxLQUFLLElBQUksTUFBTSxFQUFFO1lBQzFCLElBQUksbUJBQW1CLEdBQUcsUUFBUSxDQUFDO1lBRW5DLDZDQUE2QztZQUM3QyxJQUFJLEtBQUssQ0FBQyxNQUFNLEtBQUssQ0FBQyxDQUFDLEVBQUU7Z0JBQ3ZCLHVDQUF1QztnQkFDdkMsbUJBQW1CO29CQUNqQixZQUFZLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxZQUFZLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxRQUFRLENBQUM7YUFDN0U7WUFFRCxJQUFJLG1CQUFtQixFQUFFO2dCQUN2QixtQkFBbUIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFDLElBQUksRUFBRSxPQUFrQixFQUFDLEVBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDNUY7U0FDRjtRQUVELE9BQU87WUFDTCxFQUFFLEVBQUUsQ0FBQyxDQUFDO1lBQ04sS0FBSyxFQUFFLE1BQU07WUFDYixJQUFJLEVBQUUsUUFBUTtZQUNkLFFBQVEsRUFBRSxRQUFRO1NBQ25CLENBQUM7SUFDSixDQUFDO0lBRU0sS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFzQixFQUFFLElBQWlCO1FBQzdELE1BQU0sSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUVyRCxNQUFNLGFBQWEsR0FBRyxNQUFNLG1CQUFRLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUV6RCxJQUFJLENBQUMsYUFBYSxFQUFFO1lBQ2xCLE1BQU0sSUFBSSw2QkFBYSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7U0FDN0M7UUFFRCxPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUVELGtDQUFrQztJQUVsQzs7O09BR0c7SUFDSyxvQkFBb0IsQ0FBQyxhQUE0QixFQUFFLE9BQWdCO1FBQ3pFLE1BQU0sV0FBVyxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLDBCQUEwQixDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBRTlFLElBQUksT0FBTyxFQUFFO1lBQ1gsTUFBTSxlQUFlLEdBQUcsSUFBSSxDQUFDLHdCQUF3QixDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDLENBQUM7WUFFNUUsZ0dBQWdHO1lBQ2hHLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxlQUFlLENBQUMsRUFBRTtnQkFDbkMsTUFBTSxPQUFPLEdBQUcsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLGlCQUFpQixDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUM7Z0JBQ3ZFLE1BQU0sV0FBVyxHQUFHLElBQUksSUFBSSxFQUFFLENBQUM7Z0JBRS9CLDRGQUE0RjtnQkFDNUYsSUFBSSxPQUFPLEdBQUcsV0FBVyxFQUFFO29CQUN6Qiw4Q0FBOEM7b0JBQzlDLFdBQVcsQ0FBQyxPQUFPLEdBQUcsV0FBVyxDQUFDO2lCQUNuQztxQkFBTTtvQkFDTCxXQUFXLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztpQkFDL0I7YUFDRjtpQkFBTTtnQkFDTCxXQUFXLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQzthQUM1QjtTQUNGO1FBRUQsT0FBTyxXQUFXLENBQUM7SUFDckIsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ssb0JBQW9CLENBQzFCLGFBQTRCLEVBQzVCLGtCQUFtRjtRQUVuRixNQUFNLFdBQVcsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQywwQkFBMEIsQ0FDNUQsYUFBYSxFQUNiLGtCQUFrQixDQUNuQixDQUFDO1FBRUYsZ0NBQWdDO1FBQ2hDLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDdEMsV0FBVyxDQUFDLElBQUksR0FBRztnQkFDakIsRUFBRSxFQUFFLGFBQWEsQ0FBQyxJQUFJLENBQUMsRUFBRTtnQkFDekIsdUNBQXVDO2dCQUN2QyxRQUFRLEVBQUUsYUFBYSxDQUFDLElBQUksQ0FBQyxRQUFRO2dCQUNyQyx1Q0FBdUM7Z0JBQ3ZDLEtBQUssRUFBRSxhQUFhLENBQUMsSUFBSSxDQUFDLEtBQUs7YUFDaEMsQ0FBQztTQUNIO2FBQU07WUFDTCxXQUFXLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztTQUN6QjtRQUVELHVDQUF1QztRQUN2QyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxFQUFFO1lBQzdDLFdBQVcsQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO1lBQ3pCLE9BQU8sV0FBVyxDQUFDO1NBQ3BCO1FBRUQsa0RBQWtEO1FBQ2xELHNFQUFzRTtRQUV0RSxNQUFNLGVBQWUsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBQ2xDLE1BQU0sa0JBQWtCLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQztRQUVyQyx1Q0FBdUM7UUFDdkMsS0FBSyxNQUFNLE1BQU0sSUFBSSxhQUFhLENBQUMsWUFBWSxFQUFFO1lBQy9DLE1BQU0sWUFBWSxHQUFHLGVBQWUsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBRXhELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsSUFBSSxZQUFZLEdBQUcsTUFBTSxDQUFDLFNBQVMsRUFBRTtnQkFDbEUsZUFBZSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQzthQUN0RDtZQUVELElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFO2dCQUMxQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRTtvQkFDcEMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRTtvQkFDbEIsUUFBUSxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUTtvQkFDOUIsS0FBSyxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSztpQkFDekIsQ0FBQyxDQUFDO2FBQ0o7U0FDRjtRQUVELDBEQUEwRDtRQUMxRCxJQUFJLFlBQVksR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1FBQ3pELHVDQUF1QztRQUN2QyxZQUFZLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQ2xFLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLHdDQUF3QyxDQUFDLENBQUM7UUFFaEUsZ0RBQWdEO1FBQ2hELHVDQUF1QztRQUN2QyxXQUFXLENBQUMsT0FBTyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxFQUFFO1lBQy9DLE1BQU0sTUFBTSxHQUFHLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMvQyxNQUFNLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN0QixPQUFPLE1BQU0sQ0FBQztRQUNoQixDQUFDLENBQUMsQ0FBQztRQUVILE9BQU8sV0FBVyxDQUFDO0lBQ3JCLENBQUM7SUFFRDs7O09BR0c7SUFDSywwQkFBMEIsQ0FBQyxtQkFBd0M7UUFDekUsTUFBTSxpQkFBaUIsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQywwQkFBMEIsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1FBRWhHLGdDQUFnQztRQUNoQyx1Q0FBdUM7UUFDdkMsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxFQUFFO1lBQzVDLGlCQUFpQixDQUFDLElBQUksR0FBRztnQkFDdkIsdUNBQXVDO2dCQUN2QyxFQUFFLEVBQUUsbUJBQW1CLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQy9CLHVDQUF1QztnQkFDdkMsUUFBUSxFQUFFLG1CQUFtQixDQUFDLElBQUksQ0FBQyxRQUFRO2dCQUMzQyx1Q0FBdUM7Z0JBQ3ZDLEtBQUssRUFBRSxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsS0FBSzthQUN0QyxDQUFDO1NBQ0g7YUFBTTtZQUNMLGlCQUFpQixDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7U0FDL0I7UUFFRCxPQUFPLGlCQUFpQixDQUFDO0lBQzNCLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLEtBQUs7UUFDVixJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFO1lBQ2pDLEdBQUcsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsQ0FBQztZQUNoQyxPQUFPO1NBQ1I7UUFDRCxJQUFJO1lBQ0YsU0FBUyxDQUFDLG1CQUFtQixDQUFDLFdBQVcsRUFBRSxNQUFNLENBQUMsR0FBRyxDQUFDLHVCQUF1QixFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFbkYseURBQXlEO1lBQ3pELFNBQVMsQ0FBQyxZQUFZLENBQUMsaUJBQWlCLEVBQUUsV0FBVyxFQUFFLEVBQUMsS0FBSyxFQUFFLFdBQVcsRUFBQyxDQUFDLENBQUM7WUFFN0UsdUNBQXVDO1lBQ3ZDLE9BQU8sV0FBVyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO2dCQUNyRCxLQUFLLE1BQU0sS0FBSyxJQUFJLE1BQU0sRUFBRTtvQkFDMUIsSUFBSSxLQUFLLENBQUMsT0FBTyxFQUFFO3dCQUNqQixNQUFNLEVBQUUsR0FBRyxTQUFTLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsRUFBRSxLQUFLLENBQUMsSUFBSSxFQUFFOzRCQUM3RSxLQUFLLEVBQUUsV0FBVzs0QkFDbEIsT0FBTyxFQUFFLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUM7eUJBQ25FLENBQUMsQ0FBQzt3QkFDSCxJQUFJLENBQUMsd0JBQXdCLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7cUJBQ2pEO2lCQUNGO2dCQUNELElBQUksQ0FBQyxxQkFBcUIsR0FBRyxJQUFJLENBQUM7WUFDcEMsQ0FBQyxDQUFDLENBQUM7U0FDSjtRQUFDLE9BQU8sR0FBRyxFQUFFO1lBQ1osR0FBRyxDQUFDLEtBQUssQ0FBQyxzRUFBc0UsRUFBRSxHQUFHLENBQUMsQ0FBQztTQUN4RjtJQUNILENBQUM7SUFFRDs7OztPQUlHO0lBQ0ksUUFBUSxDQUFDLEtBQW9CO1FBQ2xDLE9BQU8sQ0FDTCxJQUFJLENBQUMsVUFBVSxDQUFDO1lBQ2QsdUNBQXVDO1lBQ3ZDLE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBTztZQUN0Qix1Q0FBdUM7WUFDdkMsS0FBSyxFQUFFLEtBQUssQ0FBQyxLQUFLO1lBQ2xCLHVDQUF1QztZQUN2QyxTQUFTLEVBQUUsS0FBSyxDQUFDLFNBQVM7WUFDMUIsdUNBQXVDO1lBQ3ZDLEtBQUssRUFBRSxLQUFLLENBQUMsVUFBVTtTQUN4QixDQUFDO1lBQ0EsdUNBQXVDO2FBQ3RDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFO1lBQ3ZCOzs7ZUFHRztZQUNILE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLGdCQUFnQixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQzNELENBQUMsQ0FBQztZQUNGLHVDQUF1QzthQUN0QyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDWCxJQUFJLEdBQUcsWUFBWSxRQUFRLENBQUMsaUJBQWlCLEVBQUU7Z0JBQzdDLE1BQU0sR0FBRyxDQUFDO2FBQ1g7WUFFRCxHQUFHLENBQUMsS0FBSyxDQUFDLDhDQUE4QyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBRS9ELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLEVBQUU7Z0JBQy9CLE9BQU8sRUFBQyxLQUFLLEVBQUUsR0FBRyxDQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFDLENBQUM7YUFDN0M7WUFFRCxPQUFPLEVBQUMsS0FBSyxFQUFFLEdBQUcsRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFDLENBQUM7UUFDdEMsQ0FBQyxDQUFDO1lBRUYsdUNBQXVDO2FBQ3RDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUNkLGdEQUFnRDtZQUVoRCx1Q0FBdUM7WUFDdkMsS0FBSyxDQUFDLGNBQWMsR0FBRyxPQUFPLENBQUM7WUFDL0IsdUNBQXVDO1lBQ3ZDLEtBQUssQ0FBQyxPQUFPLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQztZQUMzQixPQUFPLEtBQUs7aUJBQ1QsSUFBSSxFQUFFO2lCQUNOLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRTtnQkFDWCxJQUFJLENBQUMsQ0FBQyxHQUFHLFlBQVksUUFBUSxDQUFDLGlCQUFpQixDQUFDLEVBQUU7b0JBQ2hELEdBQUcsQ0FBQyxLQUFLLENBQUMscUNBQXFDLEtBQUssQ0FBQyxFQUFFLG1CQUFtQixFQUFFLEdBQUcsQ0FBQyxDQUFDO2lCQUNsRjtZQUNILENBQUMsQ0FBQztpQkFDRCxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDckIsQ0FBQyxDQUFDLENBQ0wsQ0FBQztJQUNKLENBQUM7SUFFRDs7O09BR0c7SUFDSSxtQkFBbUIsQ0FDeEIsZ0JBQXNDLEVBQ3RDLEtBQW9CO1FBRXBCLE9BQU8sSUFBSSxDQUFDLHNCQUFzQixDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7YUFDekMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNULE9BQU8sV0FBVyxDQUFDLG1CQUFtQixDQUFDLGdCQUFnQixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQ2xFLENBQUMsQ0FBQzthQUNELE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFDMUQsQ0FBQztJQUVEOztPQUVHO0lBQ0ksV0FBVyxDQUFDLFFBQWlCLEVBQUUsV0FBd0I7UUFDNUQsdUNBQXVDO1FBQ3ZDLE9BQU8sV0FBVyxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ2pFLElBQUksS0FBSyxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMscUJBQXFCLEVBQUU7Z0JBQy9DLE1BQU0sRUFBRSxHQUFHLFNBQVMsQ0FBQyxZQUFZLENBQy9CLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsRUFDL0IsS0FBSyxDQUFDLElBQUksRUFDVixFQUFDLEtBQUssRUFBRSxXQUFXLEVBQUUsT0FBTyxFQUFFLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsdUNBQXVDO2lCQUNuRixDQUFDO2dCQUNGLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQzthQUNqRDtZQUNELE9BQU8sSUFBSSxDQUFDLG9CQUFvQixDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNoRCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNLLHNCQUFzQixDQUFDLE9BQWU7UUFDNUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQ2pDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDbEQ7UUFDRCx1Q0FBdUM7UUFDdkMsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQztJQUNoRCxDQUFDO0lBRUQ7O09BRUc7SUFDSyxzQkFBc0IsQ0FBQyxPQUFlO1FBQzVDLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRS9DLHVDQUF1QztRQUN2QyxTQUFTLENBQUMsT0FBTyxFQUFFLENBQUM7UUFFcEIsdUNBQXVDO1FBQ3ZDLElBQUksU0FBUyxDQUFDLEtBQUssQ0FBQyxNQUFNLEtBQUssQ0FBQyxJQUFJLFNBQVMsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1lBQzFELElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1NBQ2pDO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0ksV0FBVyxDQUFDLEVBQVUsRUFBRSxXQUF3QjtRQUNyRCxPQUFPLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxFQUFFLENBQUM7YUFDbkMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNULEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLGFBQWEsRUFBRSxXQUFXLENBQUMsQ0FBQztZQUM5QyxNQUFNLGVBQWUsR0FBRyxJQUFJLENBQUMsd0JBQXdCLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBRTlELGdHQUFnRztZQUNoRyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsZUFBZSxDQUFDLEVBQUU7Z0JBQ25DLFNBQVMsQ0FBQyxNQUFNLENBQUMsZUFBZSxDQUFDLENBQUM7YUFDbkM7WUFDRCxPQUFPLFdBQVcsQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDM0MsSUFBSSxDQUFDLHdCQUF3QixDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUMzQyxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQzthQUNELE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUNwRCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxXQUFXLENBQ2hCLE9BQWUsRUFDZixhQUE4QixFQUM5QixXQUF3QjtRQUV4QixPQUFPLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxPQUFPLENBQUM7YUFDeEMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNULEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLGFBQWEsRUFBRSxXQUFXLENBQUMsQ0FBQztZQUU5Qyx1Q0FBdUM7WUFDdkMsT0FBTyxXQUFXLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQ2xFLGdFQUFnRTtnQkFDaEUscUZBQXFGO2dCQUVyRix1Q0FBdUM7Z0JBQ3ZDLE1BQU0sY0FBYyxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUM3RCwyREFBMkQ7Z0JBQzNELHVDQUF1QztnQkFDdkMsTUFBTSxjQUFjLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBRTFELE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRTtxQkFDckIsSUFBSSxDQUFDLEdBQUcsRUFBRTtvQkFDVCxJQUFJLGNBQWMsRUFBRTt3QkFDbEIsR0FBRyxDQUFDLElBQUksQ0FBQyxvQkFBb0IsT0FBTywyQ0FBMkMsQ0FBQyxDQUFDO3dCQUNqRixPQUFPLFdBQVcsQ0FBQyxxQkFBcUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztxQkFDbkQ7Z0JBQ0gsQ0FBQyxDQUFDO3FCQUNELElBQUksQ0FBQyxHQUFHLEVBQUU7b0JBQ1QsTUFBTSxlQUFlLEdBQUcsSUFBSSxDQUFDLHdCQUF3QixDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUM7b0JBRXBFLGdHQUFnRztvQkFDaEcsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxFQUFFO3dCQUNuQyxTQUFTLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxDQUFDO3FCQUNuQztvQkFDRCxJQUFJLEtBQUssQ0FBQyxPQUFPLEVBQUU7d0JBQ2pCLE1BQU0sRUFBRSxHQUFHLFNBQVMsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxFQUFFLEtBQUssQ0FBQyxJQUFJLEVBQUU7NEJBQzdFLEtBQUssRUFBRSxXQUFXOzRCQUNsQixPQUFPLEVBQUUsY0FBYyxJQUFJLGNBQWMsQ0FBQyxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPO3lCQUN4RSxDQUFDLENBQUM7d0JBQ0gsSUFBSSxJQUFJLENBQUMscUJBQXFCLEVBQUU7NEJBQzlCLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQzt5QkFDakQ7cUJBQ0Y7eUJBQU07d0JBQ0wsSUFBSSxDQUFDLHdCQUF3QixDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUM7cUJBQ2hEO29CQUVELE9BQU8sSUFBSSxDQUFDLG9CQUFvQixDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDaEQsQ0FBQyxDQUFDLENBQUM7WUFDUCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQzthQUNELE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztJQUN6RCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0ksVUFBVSxDQUNmLFNBQWlCLEVBQ2pCLE9BQWUsRUFDZixPQU1DLEVBQ0QsV0FBd0I7UUFFeEIsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsYUFBYSxFQUFFLFdBQVcsQ0FBQyxDQUFDO1FBRTlDLHVDQUF1QztRQUN2QyxJQUFJLGtCQUFrQixDQUFDO1FBQ3ZCLE9BQU8sQ0FDTCxXQUFXO2FBQ1IsWUFBWSxDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUM7YUFDaEMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNULHVDQUF1QztZQUN2QyxPQUFPLFdBQVcsQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDdEQsa0JBQWtCLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQztZQUNyQyxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQzthQUNELElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDVCxPQUFPLFdBQVcsQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLFdBQVcsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUMvRCxDQUFDLENBQUM7WUFDRix1Q0FBdUM7YUFDdEMsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLEtBQUssRUFBRSxrQkFBa0IsQ0FBQyxDQUFDLENBQ3RFLENBQUM7SUFDSixDQUFDO0lBRUQ7O09BRUc7SUFDSSxhQUFhLENBQ2xCLFNBQWlCLEVBQ2pCLE9BQWUsRUFDZixXQUF3QjtRQUV4QixLQUFLLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxhQUFhLEVBQUUsV0FBVyxDQUFDLENBQUM7UUFDOUMsT0FBTyxXQUFXLENBQUMsWUFBWSxDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQzVELE9BQU8sV0FBVyxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUM1QyxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFTyxTQUFTLENBQ2YsT0FBZSxFQUNmLFdBQXdCLEVBQ3hCLFNBQWtCLEVBQ2xCLE9BQWdCO1FBRWhCLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUN2QyxLQUFLLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxhQUFhLEVBQUUsV0FBVyxDQUFDLENBQUM7UUFFOUMsdUNBQXVDO1FBQ3ZDLE9BQU8sV0FBVyxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQzdELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxPQUFPLEtBQUssS0FBSyxDQUFDLE9BQU8sRUFBRTtnQkFDeEQsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUNwQixtQkFBbUIsRUFDbkIsVUFBVSxPQUFPLDZCQUE2QixPQUFPLEdBQUcsRUFDeEQsSUFBSSxDQUNMLENBQUM7YUFDSDtZQUNELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsSUFBSSxTQUFTLEtBQUssS0FBSyxDQUFDLFNBQVMsRUFBRTtnQkFDOUQsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUNwQixtQkFBbUIsRUFDbkIsVUFBVSxPQUFPLG1DQUFtQyxTQUFTLElBQUksRUFDakUsSUFBSSxDQUNMLENBQUM7YUFDSDtZQUNELE9BQU8sV0FBVyxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDaEYsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSSxRQUFRLENBQ2IsT0FBZSxFQUNmLFdBQXdCLEVBQ3hCLFNBQWtCLEVBQ2xCLE9BQWdCO1FBRWhCLHVDQUF1QztRQUN2QyxJQUFJLGtCQUFrQixDQUFDO1FBQ3ZCLE9BQU8sQ0FDTCxRQUFRLENBQUMsT0FBTyxFQUFFO2FBQ2YsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNULElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBRTtnQkFDM0IsdUNBQXVDO2dCQUN2QyxPQUFPLFdBQVcsQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtvQkFDdEQsa0JBQWtCLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQztnQkFDckMsQ0FBQyxDQUFDLENBQUM7YUFDSixDQUFDLDJEQUEyRDtZQUM3RCxxR0FBcUc7UUFDdkcsQ0FBQyxDQUFDO2FBQ0QsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNULE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEVBQUUsV0FBVyxFQUFFLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUNsRSxDQUFDLENBQUM7WUFDRix1Q0FBdUM7YUFDdEMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLEtBQUssRUFBRSxrQkFBa0IsQ0FBQyxDQUFDLENBQ3ZFLENBQUM7SUFDSixDQUFDO0lBRUQ7O09BRUc7SUFDSSxhQUFhLENBQ2xCLFNBQWlCLEVBQ2pCLE9BQWUsRUFDZixPQUFlLEVBQ2YsTUFBYyxFQUNkLFdBQXdCO1FBRXhCLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEVBQUUsV0FBVyxFQUFFLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDM0UsT0FBTyxXQUFXLENBQUMsYUFBYSxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsV0FBVyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDeEUsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSSxlQUFlLENBQ3BCLFNBQWlCLEVBQ2pCLE9BQWUsRUFDZixPQUFlLEVBQ2YsT0FHQyxFQUNELFdBQXdCO1FBRXhCOzs7V0FHRztRQUNILE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEVBQUUsV0FBVyxFQUFFLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ3hFLHVDQUF1QztZQUN2QyxPQUFPLFdBQVcsQ0FBQyxlQUFlLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUNoRSxJQUFJLENBQUMsMEJBQTBCLENBQUMsTUFBTSxDQUFDLENBQ3hDLENBQUM7UUFDSixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNJLFVBQVUsQ0FBQyxPQUFlO1FBQy9CLE9BQU8sU0FBUyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsd0JBQXdCLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7SUFDbkYsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLHVCQUF1QjtRQUM1QixPQUFPLFdBQVcsQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO0lBQy9DLENBQUM7Q0FDRjtBQXRyQkQsb0NBc3JCQztBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsSUFBSSxZQUFZLEVBQUUsQ0FBQyJ9