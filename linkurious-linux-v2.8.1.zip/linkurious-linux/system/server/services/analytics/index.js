/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-03-24.
 */
'use strict';
const path = require('path');
const Promise = require('bluebird');
const rfs = require('rotating-file-stream');
const targz = require('tar.gz');
/**@type {any}*/ // promisifyAll doesn't work well with static typing
const fs = Promise.promisifyAll(require('fs-extra'));
const StringUtils = require('../../../lib/StringUtils').StringUtils;
const LKE = require('../index');
const Utils = LKE.getUtils();
const Config = LKE.getConfig();
const Errors = LKE.getErrors();
const Log = LKE.getLogger(__filename);
const UserDAO = LKE.getUserDAO();
const SUPPORTED_EVENT_TYPES = ['identify', 'track', 'page', 'group'];
// we don't support 'alias' and 'screen' types
const SUPPORTED_EVENT_TYPES_EXTERNAL = ['identify', 'track', 'page'];
// 'group' type can only be triggered internally (not with the API)
const NUMBER_OF_ANALYTICS_FILES = 50;
const MAX_SIZE_UNCOMPRESSED = '5M';
class AnalyticsService {
    constructor() {
        this._logDirPath = LKE.dataFile('logs');
        this._customerId = Config.get('customerId');
        this._stream = rfs('analytics.log', {
            size: MAX_SIZE_UNCOMPRESSED,
            compress: 'gzip',
            maxFiles: NUMBER_OF_ANALYTICS_FILES,
            path: this._logDirPath
        });
        this.enabled = true; // state of the service
        this._reportFilePath = LKE.dataFile(this.reportFileName);
        this._reportTmpDirPath = LKE.dataFile('reportTmp');
        this._cachedReportPromise = null; // we cache the promise to avoid computing the compression concurrently
        this._stream.on('error', err => {
            // the stream is closed automatically if an error occurs
            Log.error('Blocking error in the analytics service: ', err);
            this.enabled = false; // we don't recover from a blocking error, this service will be disabled
        });
    }
    get reportFileName() {
        // TODO include the customer-id and the iso-date in the filename for easier triage
        return 'linkurious-logs.tar.gz';
    }
    /**
     * Validate an event. It has to follow the Segment Spec.
     *
     * @param {any}     event    Event in the the Segment Spec format
     * @param {boolean} external Whether the event comes from the API
     * @private
     * @throws {LkError} if the event doesn't follow the Segment Spec
     */
    static _validateEvent(event, external) {
        Utils.check.object('event', event);
        const supportedEventTypes = external ? SUPPORTED_EVENT_TYPES_EXTERNAL : SUPPORTED_EVENT_TYPES;
        switch (event.type) {
            case 'track':
            case 'page':
                Utils.check.properties('event', event, {
                    event: { required: event.type === 'track', check: 'nonEmpty' },
                    properties: { required: false, check: 'object' },
                    name: { required: event.type === 'page', check: 'nonEmpty' },
                    type: { required: true, values: supportedEventTypes },
                    groupId: { required: event.type === 'group', check: 'nonEmpty' },
                    userId: { required: true, check: 'nonEmpty' },
                    context: { required: false, check: 'object' },
                    timestamp: { required: false, check: ['date', true] }
                });
                break;
            case 'identify':
            case 'group':
            default:
                Utils.check.properties('event', event, {
                    traits: { required: false, check: 'object' },
                    type: { required: true, values: supportedEventTypes },
                    groupId: { required: event.type === 'group', check: 'nonEmpty' },
                    userId: { required: true, check: 'nonEmpty' },
                    context: { required: false, check: 'object' },
                    timestamp: { required: false, check: ['date', true] }
                });
        }
    }
    /**
     * Log the Analytics events to disk. All the events are collected in a queue of
     * `NUMBER_OF_ANALYTICS_FILES` gzipped files with a max size of `MAX_SIZE_UNCOMPRESSED`.
     *
     * @param {any}        event    Event in the the Segment Spec format
     * @param {PublicUser} [user]   The user which the event refers to
     * @param {boolean}    external Whether the event comes from the API
     * @returns {Bluebird<void>}
     */
    postEvent(event, user, external) {
        if (!this.enabled) {
            return Promise.resolve();
        }
        return Promise.resolve().then(() => {
            // set "userId" in event
            let userId = this._customerId + ':';
            if (Utils.hasValue(event.userId)) {
                userId += event.userId;
            }
            else if (Utils.noValue(user)) {
                userId += 'anonymous';
            }
            else if (user.id === UserDAO.model.UNIQUE_USER_ID) {
                userId += 'uniqueUser';
            }
            else {
                userId += StringUtils.cheapHash(user.id);
            }
            event.userId = userId;
            // add "timestamp" in event
            event.timestamp = new Date();
            // clean-up event.properties
            if (event.properties && typeof event.properties === 'object') {
                // hash event.properties.userId for GDPR
                if (event.properties.userId !== undefined) {
                    // userId under properties is the object of the action, not the subject
                    event.properties.userId = StringUtils.cheapHash(event.properties.userId);
                }
                // clean-up error stack traces
                if (event.properties.error && typeof event.properties.error.stack === 'string') {
                    event.properties.error.stack = event.properties.error.stack
                        // remove "webpackJsonp" lines from stack traces
                        // this is purely to remove some noise from the stack trace
                        .replace(/([A-Z][a-zA-Z]*)\.webpackJsonp\.(\.\.\/)*/g, '')
                        // remove URL domain names (with port) from stack traces
                        .replace(/(https?:\/\/)[a-z][a-z0-9.-]*(?::\d+)?\//ig, '$1--/');
                }
            }
            // validate event format
            AnalyticsService._validateEvent(event, external);
            this._stream.write(JSON.stringify(event) + '\n', err => {
                if (err) {
                    Log.warn('Could not write analytics event to file: ', err, event);
                }
            }); // we don't wait for the callback
        });
    }
    /**
     * Create a report containing the analytics and the log files.
     *
     * @param {boolean} [withConfiguration] Whether to include the configuration within the tarball
     * @returns {Bluebird<string>}
     */
    createReport(withConfiguration) {
        if (Utils.hasValue(this._cachedReportPromise)) {
            return this._cachedReportPromise;
        }
        // 1) create a tmp directory
        this._cachedReportPromise = fs.ensureDirAsync(this._reportTmpDirPath).then(() => {
            // 2) copy the content of logDirPath to the tmp directory
            return fs.copyAsync(this._logDirPath, this._reportTmpDirPath);
        }).then(() => {
            // 3) optionally, copy the configuration file to the tmp directory
            if (withConfiguration) {
                return fs.writeJsonSync(path.join(this._reportTmpDirPath, 'production.json'), Config.get(undefined, {}, false, true), { spaces: 2, replacer: null });
            }
        }).then(() => {
            // 4) tar.gz the tmp directory
            return targz().compress(this._reportTmpDirPath, this._reportFilePath);
        }).catch(err => {
            return Errors.technical('critical', err, true);
        }).finally(() => {
            // 5) remove the tmp directory
            return fs.removeAsync(this._reportTmpDirPath).catch(err => {
                Log.error('Can\'t remove report temporary directory: ', err);
            });
        }).then(() => {
            this._cachedReportPromise = null;
            return this._reportFilePath;
        });
        return this._cachedReportPromise;
    }
}
module.exports = new AnalyticsService();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvYW5hbHl0aWNzL2luZGV4LmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBQ2IsTUFBTSxJQUFJLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQzdCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNwQyxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsc0JBQXNCLENBQUMsQ0FBQztBQUM1QyxNQUFNLEtBQUssR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDaEMsZ0JBQWdCLENBQUMsb0RBQW9EO0FBQ3JFLE1BQU0sRUFBRSxHQUFHLE9BQU8sQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7QUFDckQsTUFBTSxXQUFXLEdBQUcsT0FBTyxDQUFDLDBCQUEwQixDQUFDLENBQUMsV0FBVyxDQUFDO0FBQ3BFLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNoQyxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3RDLE1BQU0sT0FBTyxHQUFHLEdBQUcsQ0FBQyxVQUFVLEVBQUUsQ0FBQztBQUVqQyxNQUFNLHFCQUFxQixHQUFHLENBQUMsVUFBVSxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUM7QUFDckUsOENBQThDO0FBQzlDLE1BQU0sOEJBQThCLEdBQUcsQ0FBQyxVQUFVLEVBQUUsT0FBTyxFQUFFLE1BQU0sQ0FBQyxDQUFDO0FBQ3JFLG1FQUFtRTtBQUVuRSxNQUFNLHlCQUF5QixHQUFHLEVBQUUsQ0FBQztBQUNyQyxNQUFNLHFCQUFxQixHQUFHLElBQUksQ0FBQztBQUVuQyxNQUFNLGdCQUFnQjtJQUNwQjtRQUNFLElBQUksQ0FBQyxXQUFXLEdBQUcsR0FBRyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUN4QyxJQUFJLENBQUMsV0FBVyxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDNUMsSUFBSSxDQUFDLE9BQU8sR0FBRyxHQUFHLENBQUMsZUFBZSxFQUFFO1lBQ2xDLElBQUksRUFBRSxxQkFBcUI7WUFDM0IsUUFBUSxFQUFFLE1BQU07WUFDaEIsUUFBUSxFQUFFLHlCQUF5QjtZQUNuQyxJQUFJLEVBQUUsSUFBSSxDQUFDLFdBQVc7U0FDdkIsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsQ0FBQyx1QkFBdUI7UUFFNUMsSUFBSSxDQUFDLGVBQWUsR0FBRyxHQUFHLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztRQUN6RCxJQUFJLENBQUMsaUJBQWlCLEdBQUcsR0FBRyxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUNuRCxJQUFJLENBQUMsb0JBQW9CLEdBQUcsSUFBSSxDQUFDLENBQUMsdUVBQXVFO1FBRXpHLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUMsRUFBRTtZQUM3Qix3REFBd0Q7WUFDeEQsR0FBRyxDQUFDLEtBQUssQ0FBQywyQ0FBMkMsRUFBRSxHQUFHLENBQUMsQ0FBQztZQUU1RCxJQUFJLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQyxDQUFDLHdFQUF3RTtRQUNoRyxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRCxJQUFJLGNBQWM7UUFDaEIsa0ZBQWtGO1FBQ2xGLE9BQU8sd0JBQXdCLENBQUM7SUFDbEMsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxNQUFNLENBQUMsY0FBYyxDQUFDLEtBQUssRUFBRSxRQUFRO1FBQ25DLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQztRQUVuQyxNQUFNLG1CQUFtQixHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsOEJBQThCLENBQUMsQ0FBQyxDQUFDLHFCQUFxQixDQUFDO1FBRTlGLFFBQVEsS0FBSyxDQUFDLElBQUksRUFBRTtZQUNsQixLQUFLLE9BQU8sQ0FBQztZQUNiLEtBQUssTUFBTTtnQkFDVCxLQUFLLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsS0FBSyxFQUFFO29CQUNyQyxLQUFLLEVBQUUsRUFBQyxRQUFRLEVBQUUsS0FBSyxDQUFDLElBQUksS0FBSyxPQUFPLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBQztvQkFDNUQsVUFBVSxFQUFFLEVBQUMsUUFBUSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFDO29CQUM5QyxJQUFJLEVBQUUsRUFBQyxRQUFRLEVBQUUsS0FBSyxDQUFDLElBQUksS0FBSyxNQUFNLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBQztvQkFDMUQsSUFBSSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsbUJBQW1CLEVBQUM7b0JBQ25ELE9BQU8sRUFBRSxFQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsSUFBSSxLQUFLLE9BQU8sRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFDO29CQUM5RCxNQUFNLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUM7b0JBQzNDLE9BQU8sRUFBRSxFQUFDLFFBQVEsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBQztvQkFDM0MsU0FBUyxFQUFFLEVBQUMsUUFBUSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLEVBQUM7aUJBQ3BELENBQUMsQ0FBQztnQkFDSCxNQUFNO1lBQ1IsS0FBSyxVQUFVLENBQUM7WUFDaEIsS0FBSyxPQUFPLENBQUM7WUFDYjtnQkFDRSxLQUFLLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsS0FBSyxFQUFFO29CQUNyQyxNQUFNLEVBQUUsRUFBQyxRQUFRLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUM7b0JBQzFDLElBQUksRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLG1CQUFtQixFQUFDO29CQUNuRCxPQUFPLEVBQUUsRUFBQyxRQUFRLEVBQUUsS0FBSyxDQUFDLElBQUksS0FBSyxPQUFPLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBQztvQkFDOUQsTUFBTSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFDO29CQUMzQyxPQUFPLEVBQUUsRUFBQyxRQUFRLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUM7b0JBQzNDLFNBQVMsRUFBRSxFQUFDLFFBQVEsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxFQUFDO2lCQUNwRCxDQUFDLENBQUM7U0FDTjtJQUVILENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILFNBQVMsQ0FBQyxLQUFLLEVBQUUsSUFBSSxFQUFFLFFBQVE7UUFDN0IsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFBRSxPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQztTQUFFO1FBRWhELE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFFakMsd0JBQXdCO1lBQ3hCLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxXQUFXLEdBQUcsR0FBRyxDQUFDO1lBQ3BDLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEVBQUU7Z0JBQ2hDLE1BQU0sSUFBSSxLQUFLLENBQUMsTUFBTSxDQUFDO2FBQ3hCO2lCQUFNLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRTtnQkFDOUIsTUFBTSxJQUFJLFdBQVcsQ0FBQzthQUN2QjtpQkFBTSxJQUFJLElBQUksQ0FBQyxFQUFFLEtBQUssT0FBTyxDQUFDLEtBQUssQ0FBQyxjQUFjLEVBQUU7Z0JBQ25ELE1BQU0sSUFBSSxZQUFZLENBQUM7YUFDeEI7aUJBQU07Z0JBQ0wsTUFBTSxJQUFJLFdBQVcsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2FBQzFDO1lBQ0QsS0FBSyxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7WUFFdEIsMkJBQTJCO1lBQzNCLEtBQUssQ0FBQyxTQUFTLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQztZQUU3Qiw0QkFBNEI7WUFDNUIsSUFBSSxLQUFLLENBQUMsVUFBVSxJQUFJLE9BQU8sS0FBSyxDQUFDLFVBQVUsS0FBSyxRQUFRLEVBQUU7Z0JBRTVELHdDQUF3QztnQkFDeEMsSUFBSSxLQUFLLENBQUMsVUFBVSxDQUFDLE1BQU0sS0FBSyxTQUFTLEVBQUU7b0JBQ3pDLHVFQUF1RTtvQkFDdkUsS0FBSyxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsV0FBVyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2lCQUMxRTtnQkFFRCw4QkFBOEI7Z0JBQzlCLElBQUksS0FBSyxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksT0FBTyxLQUFLLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxLQUFLLEtBQUssUUFBUSxFQUFFO29CQUM5RSxLQUFLLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsS0FBSzt3QkFDekQsZ0RBQWdEO3dCQUNoRCwyREFBMkQ7eUJBQzFELE9BQU8sQ0FBQyw0Q0FBNEMsRUFBRSxFQUFFLENBQUM7d0JBQzFELHdEQUF3RDt5QkFDdkQsT0FBTyxDQUFDLDRDQUE0QyxFQUFFLE9BQU8sQ0FBQyxDQUFDO2lCQUNuRTthQUNGO1lBRUQsd0JBQXdCO1lBQ3hCLGdCQUFnQixDQUFDLGNBQWMsQ0FBQyxLQUFLLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFFakQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLEVBQUUsR0FBRyxDQUFDLEVBQUU7Z0JBQ3JELElBQUksR0FBRyxFQUFFO29CQUNQLEdBQUcsQ0FBQyxJQUFJLENBQUMsMkNBQTJDLEVBQUUsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDO2lCQUNuRTtZQUNILENBQUMsQ0FBQyxDQUFDLENBQUMsaUNBQWlDO1FBQ3ZDLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsWUFBWSxDQUFDLGlCQUFpQjtRQUM1QixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLEVBQUU7WUFDN0MsT0FBTyxJQUFJLENBQUMsb0JBQW9CLENBQUM7U0FDbEM7UUFFRCw0QkFBNEI7UUFDNUIsSUFBSSxDQUFDLG9CQUFvQixHQUFHLEVBQUUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUM5RSx5REFBeUQ7WUFDekQsT0FBTyxFQUFFLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7UUFDaEUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNYLGtFQUFrRTtZQUNsRSxJQUFJLGlCQUFpQixFQUFFO2dCQUNyQixPQUFPLEVBQUUsQ0FBQyxhQUFhLENBQ3JCLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLGlCQUFpQixDQUFDLEVBQ3BELE1BQU0sQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsSUFBSSxDQUFDLEVBQ3RDLEVBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFDLENBQzVCLENBQUM7YUFDSDtRQUNILENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCw4QkFBOEI7WUFDOUIsT0FBTyxLQUFLLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztRQUN4RSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDYixPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLEdBQUcsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNqRCxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFO1lBQ2QsOEJBQThCO1lBQzlCLE9BQU8sRUFBRSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQ3hELEdBQUcsQ0FBQyxLQUFLLENBQUMsNENBQTRDLEVBQUUsR0FBRyxDQUFDLENBQUM7WUFDL0QsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1gsSUFBSSxDQUFDLG9CQUFvQixHQUFHLElBQUksQ0FBQztZQUNqQyxPQUFPLElBQUksQ0FBQyxlQUFlLENBQUM7UUFDOUIsQ0FBQyxDQUFDLENBQUM7UUFFSCxPQUFPLElBQUksQ0FBQyxvQkFBb0IsQ0FBQztJQUNuQyxDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLElBQUksZ0JBQWdCLEVBQUUsQ0FBQyJ9