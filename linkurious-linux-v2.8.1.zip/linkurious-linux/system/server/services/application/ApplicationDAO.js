/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-11-02.
 */
'use strict';
const Promise = require('bluebird');
const LKE = require('../index');
const Errors = LKE.getErrors();
const Db = LKE.getSqlDb();
const Utils = LKE.getUtils();
class ApplicationDAO {
    /**
     * @type {ApplicationModel}
     */
    get model() {
        return Db.models.application;
    }
    /**
     * Return an application instance by id.
     * Return a rejected promise if the application wasn't found.
     *
     * @param {number} id
     * @returns {Bluebird<ApplicationInstance>}
     */
    _getApplicationInstance(id) {
        Utils.check.posInt('id', id);
        return this.model.findOne({ where: { id: id }, include: [Db.models.group] }).then(instance => {
            if (!instance) {
                return Errors.business('not_found', `Application #${id} was not found.`, true);
            }
            return instance;
        });
    }
    /**
     * @param {ApplicationInstance} appInstance
     * @returns {Bluebird<PublicApplication>}
     */
    formatToPublicApplication(appInstance) {
        const publicApplication = this.model.instanceToPublicAttributes(appInstance);
        return Promise.resolve().then(() => {
            if (Utils.noValue(appInstance.groups)) {
                return;
            }
            return Promise.map(appInstance.groups, group => {
                return Db.models.group.instanceToPublicAttributes(group);
            }).then(publicGroups => {
                publicApplication.groups = publicGroups;
            });
        }).return(publicApplication);
    }
    /**
     * Return an application instance by API key.
     * The application has to be enabled otherwise a rejected promise is returned.
     *
     * @param {string} apiKey
     * @returns {Bluebird<PublicApplication>} ApplicationInstance populated with the groups
     */
    findApplication(apiKey) {
        return this.model.findOne({
            where: { apiKey: apiKey },
            include: [Db.models.group]
        }).then(applicationInstance => {
            if (!applicationInstance) {
                return Errors.access('bad_credentials', 'Wrong API key.', true);
            }
            if (!applicationInstance.enabled) {
                return Errors.access('forbidden', 'The application is not enabled.', true);
            }
            return this.formatToPublicApplication(applicationInstance);
        });
    }
    /**
     * Set the groups of an application and return the populated application.
     *
     * @param {ApplicationInstance} appInstance
     * @param {GroupInstance[]}     groupInstances
     * @returns {Bluebird<ApplicationInstance>}
     * @private
     */
    _setGroups(appInstance, groupInstances) {
        return appInstance.setGroups(groupInstances).then(() => {
            appInstance.groups = groupInstances;
            return appInstance;
        });
    }
    /**
     * Create a new application.
     *
     * @param {ApplicationAttributes} application
     * @param {GroupInstance[]}       groupInstances
     * @returns {Bluebird<ApplicationInstance>}
     */
    createApplication(application, groupInstances) {
        // generate apiKey
        application.apiKey = Utils.randomHex(16);
        // enable by default
        if (Utils.noValue(application.enabled)) {
            application.enabled = true;
        }
        // validation
        Utils.check.properties('application', application, {
            name: { required: true, check: 'nonEmpty' },
            enabled: { required: true, type: 'boolean' },
            apiKey: { required: true, check: ['string', true, true, 32, 32] },
            rights: { required: true, arrayItem: { check: ['values', this.model.APP_ACTIONS, true] } }
        });
        return this.model.create(application).then(appInstance => {
            return this._setGroups(appInstance, groupInstances);
        });
    }
    /**
     * @param {{id: number, name?: string, enabled?: boolean, rights?: string[]}} application
     * @param {GroupInstance[]} [groupInstances]
     * @returns {Bluebird<ApplicationInstance>}
     */
    updateApplication(application, groupInstances) {
        Utils.check.properties('application', application, {
            id: { required: true, check: 'posInt' },
            name: { required: false, check: 'nonEmpty' },
            enabled: { required: false, type: 'boolean' },
            rights: { required: false, arrayItem: { check: ['values', this.model.APP_ACTIONS, true] } }
        });
        return this._getApplicationInstance(application.id).then(appInstance => {
            // update editable fields fields
            let changes = 0;
            ['name', 'enabled', 'rights'].forEach(key => {
                if (Utils.hasValue(application[key])) {
                    appInstance[key] = application[key];
                    changes++;
                }
            });
            if (changes > 0) {
                return appInstance.save();
            }
            else {
                return appInstance;
            }
        }).then(appInstance => {
            // update groups
            if (groupInstances) {
                return this._setGroups(appInstance, groupInstances);
            }
            else {
                return appInstance;
            }
        });
    }
    /**
     * Get all applications (with groups).
     *
     * @returns {Bluebird<ApplicationInstance[]>}
     */
    getApplications() {
        return this.model.findAll({
            include: [Db.models.group]
        });
    }
}
module.exports = new ApplicationDAO();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQXBwbGljYXRpb25EQU8uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvYXBwbGljYXRpb24vQXBwbGljYXRpb25EQU8uanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFDYixNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDcEMsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ2hDLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEVBQUUsR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDMUIsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBRTdCLE1BQU0sY0FBYztJQUNsQjs7T0FFRztJQUNILElBQUksS0FBSztRQUNQLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUM7SUFDL0IsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILHVCQUF1QixDQUFDLEVBQUU7UUFDeEIsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBRTdCLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsRUFBQyxLQUFLLEVBQUUsRUFBQyxFQUFFLEVBQUUsRUFBRSxFQUFDLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsRUFBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ3ZGLElBQUksQ0FBQyxRQUFRLEVBQUU7Z0JBQ2IsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxnQkFBZ0IsRUFBRSxpQkFBaUIsRUFBRSxJQUFJLENBQUMsQ0FBQzthQUNoRjtZQUVELE9BQU8sUUFBUSxDQUFDO1FBQ2xCLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7T0FHRztJQUNILHlCQUF5QixDQUFDLFdBQVc7UUFDbkMsTUFBTSxpQkFBaUIsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLDBCQUEwQixDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBRTdFLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDakMsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsRUFBRTtnQkFDckMsT0FBTzthQUNSO1lBRUQsT0FBTyxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLEVBQUU7Z0JBQzdDLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsMEJBQTBCLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDM0QsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFO2dCQUNyQixpQkFBaUIsQ0FBQyxNQUFNLEdBQUcsWUFBWSxDQUFDO1lBQzFDLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLENBQUM7SUFDL0IsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILGVBQWUsQ0FBQyxNQUFNO1FBQ3BCLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7WUFDeEIsS0FBSyxFQUFFLEVBQUMsTUFBTSxFQUFFLE1BQU0sRUFBQztZQUN2QixPQUFPLEVBQUUsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztTQUMzQixDQUFDLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEVBQUU7WUFDNUIsSUFBSSxDQUFDLG1CQUFtQixFQUFFO2dCQUN4QixPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsaUJBQWlCLEVBQUUsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDakU7WUFFRCxJQUFJLENBQUMsbUJBQW1CLENBQUMsT0FBTyxFQUFFO2dCQUNoQyxPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFFLGlDQUFpQyxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQzVFO1lBRUQsT0FBTyxJQUFJLENBQUMseUJBQXlCLENBQUMsbUJBQW1CLENBQUMsQ0FBQztRQUM3RCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsVUFBVSxDQUFDLFdBQVcsRUFBRSxjQUFjO1FBQ3BDLE9BQU8sV0FBVyxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ3JELFdBQVcsQ0FBQyxNQUFNLEdBQUcsY0FBYyxDQUFDO1lBQ3BDLE9BQU8sV0FBVyxDQUFDO1FBQ3JCLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILGlCQUFpQixDQUFDLFdBQVcsRUFBRSxjQUFjO1FBQzNDLGtCQUFrQjtRQUNsQixXQUFXLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUM7UUFFekMsb0JBQW9CO1FBQ3BCLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFBRSxXQUFXLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztTQUFFO1FBRXZFLGFBQWE7UUFDYixLQUFLLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsV0FBVyxFQUFFO1lBQ2pELElBQUksRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBQztZQUN6QyxPQUFPLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUM7WUFDMUMsTUFBTSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsRUFBRSxDQUFDLEVBQUM7WUFDL0QsTUFBTSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUUsRUFBQyxLQUFLLEVBQUUsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLEVBQUMsRUFBQztTQUN2RixDQUFDLENBQUM7UUFFSCxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUN2RCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLGNBQWMsQ0FBQyxDQUFDO1FBQ3RELENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxpQkFBaUIsQ0FBQyxXQUFXLEVBQUUsY0FBYztRQUMzQyxLQUFLLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsV0FBVyxFQUFFO1lBQ2pELEVBQUUsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBQztZQUNyQyxJQUFJLEVBQUUsRUFBQyxRQUFRLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUM7WUFDMUMsT0FBTyxFQUFFLEVBQUMsUUFBUSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFDO1lBQzNDLE1BQU0sRUFBRSxFQUFDLFFBQVEsRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLEVBQUMsS0FBSyxFQUFFLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxFQUFDLEVBQUM7U0FDeEYsQ0FBQyxDQUFDO1FBRUgsT0FBTyxJQUFJLENBQUMsdUJBQXVCLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUNyRSxnQ0FBZ0M7WUFDaEMsSUFBSSxPQUFPLEdBQUcsQ0FBQyxDQUFDO1lBQ2hCLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxRQUFRLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQzFDLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRTtvQkFDcEMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDcEMsT0FBTyxFQUFFLENBQUM7aUJBQ1g7WUFDSCxDQUFDLENBQUMsQ0FBQztZQUNILElBQUksT0FBTyxHQUFHLENBQUMsRUFBRTtnQkFDZixPQUFPLFdBQVcsQ0FBQyxJQUFJLEVBQUUsQ0FBQzthQUMzQjtpQkFBTTtnQkFDTCxPQUFPLFdBQVcsQ0FBQzthQUNwQjtRQUNILENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUNwQixnQkFBZ0I7WUFDaEIsSUFBSSxjQUFjLEVBQUU7Z0JBQ2xCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsY0FBYyxDQUFDLENBQUM7YUFDckQ7aUJBQU07Z0JBQ0wsT0FBTyxXQUFXLENBQUM7YUFDcEI7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsZUFBZTtRQUNiLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7WUFDeEIsT0FBTyxFQUFFLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7U0FDM0IsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUVGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxJQUFJLGNBQWMsRUFBRSxDQUFDIn0=