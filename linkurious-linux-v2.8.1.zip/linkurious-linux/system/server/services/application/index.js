/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-11-02.
 */
'use strict';
const Promise = require('bluebird');
const _ = require('lodash');
const LKE = require('../index');
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
const OldGroupDAO = LKE.getOldGroupDAO();
const UserDAO = LKE.getUserDAO();
const ApplicationDAO = require('./ApplicationDAO');
class ApplicationService {
    /**
     * Create a new application.
     *
     * @param {object}   application
     * @param {string}   application.name
     * @param {boolean}  [application.enabled=true]
     * @param {number[]} application.groups
     * @param {string[]} application.rights
     * @returns {Bluebird<PublicApplication>}
     */
    createApplication(application) {
        Utils.check.exist('application', application);
        // extract group ids
        const groupIds = application.groups;
        delete application.groups;
        Utils.check.intArray('application.groups', groupIds, 1);
        // resolve the group instances
        return OldGroupDAO.getGroupInstances(groupIds).then(groupInstances => {
            return ApplicationDAO.createApplication(application, groupInstances);
        }).then(appInstance => {
            return ApplicationDAO.formatToPublicApplication(appInstance);
        });
    }
    /**
     * Update an application.
     *
     * @param {object}   application
     * @param {number}   application.id        ID of the application to update
     * @param {string}   [application.name]    The new name
     * @param {boolean}  [application.enabled] The new status
     * @param {number[]} [application.groups]  The new groups
     * @param {string[]} [application.rights]  The new rights
     * @returns {Bluebird<PublicApplication>}
     */
    updateApplication(application) {
        Utils.check.exist('application', application);
        // extract group ids
        const groupIds = application.groups;
        delete application.groups;
        return Promise.resolve().then(() => {
            if (Utils.noValue(groupIds)) {
                return;
            }
            // resolve the new group instances (if specified)
            Utils.check.intArray('application.groups', groupIds, 1);
            return OldGroupDAO.getGroupInstances(groupIds);
        }).then(groupInstances => {
            return ApplicationDAO.updateApplication(application, groupInstances);
        }).then(appInstance => {
            return ApplicationDAO.formatToPublicApplication(appInstance);
        });
    }
    /**
     * @param {string} userEmail
     * @param {string} apiKey
     * @returns {Bluebird<{user: PublicUser, application: PublicApplication}>}
     */
    checkApplication(userEmail, apiKey) {
        return ApplicationDAO.findApplication(apiKey).then(publicApplication => {
            return UserDAO.getUserByEmail(userEmail, true).then(publicUser => {
                const groupIntersection = _.intersectionBy(publicUser.groups, publicApplication.groups, 'id');
                if (groupIntersection.length === 0) {
                    return Errors.access('bad_credentials', 'This application cannot act on behalf of the given user.', true);
                }
                return {
                    user: publicUser,
                    application: publicApplication
                };
            });
        });
    }
    /**
     * List all applications
     *
     * @returns {Bluebird<PublicApplication[]>}
     */
    getApplications() {
        return ApplicationDAO.getApplications().map(appInstance => {
            return ApplicationDAO.formatToPublicApplication(appInstance);
        });
    }
}
module.exports = new ApplicationService();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvYXBwbGljYXRpb24vaW5kZXguanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFDYixNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDcEMsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVCLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNoQyxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sV0FBVyxHQUFHLEdBQUcsQ0FBQyxjQUFjLEVBQUUsQ0FBQztBQUN6QyxNQUFNLE9BQU8sR0FBRyxHQUFHLENBQUMsVUFBVSxFQUFFLENBQUM7QUFDakMsTUFBTSxjQUFjLEdBQUcsT0FBTyxDQUFDLGtCQUFrQixDQUFDLENBQUM7QUFFbkQsTUFBTSxrQkFBa0I7SUFFdEI7Ozs7Ozs7OztPQVNHO0lBQ0gsaUJBQWlCLENBQUMsV0FBVztRQUMzQixLQUFLLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxhQUFhLEVBQUUsV0FBVyxDQUFDLENBQUM7UUFFOUMsb0JBQW9CO1FBQ3BCLE1BQU0sUUFBUSxHQUFHLFdBQVcsQ0FBQyxNQUFNLENBQUM7UUFDcEMsT0FBTyxXQUFXLENBQUMsTUFBTSxDQUFDO1FBQzFCLEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLG9CQUFvQixFQUFFLFFBQVEsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUV4RCw4QkFBOEI7UUFDOUIsT0FBTyxXQUFXLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFO1lBQ25FLE9BQU8sY0FBYyxDQUFDLGlCQUFpQixDQUFDLFdBQVcsRUFBRSxjQUFjLENBQUMsQ0FBQztRQUN2RSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDcEIsT0FBTyxjQUFjLENBQUMseUJBQXlCLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDL0QsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7T0FVRztJQUNILGlCQUFpQixDQUFDLFdBQVc7UUFDM0IsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsYUFBYSxFQUFFLFdBQVcsQ0FBQyxDQUFDO1FBRTlDLG9CQUFvQjtRQUNwQixNQUFNLFFBQVEsR0FBRyxXQUFXLENBQUMsTUFBTSxDQUFDO1FBQ3BDLE9BQU8sV0FBVyxDQUFDLE1BQU0sQ0FBQztRQUUxQixPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ2pDLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBRTtnQkFDM0IsT0FBTzthQUNSO1lBRUQsaURBQWlEO1lBQ2pELEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLG9CQUFvQixFQUFFLFFBQVEsRUFBRSxDQUFDLENBQUMsQ0FBQztZQUN4RCxPQUFPLFdBQVcsQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNqRCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLEVBQUU7WUFDdkIsT0FBTyxjQUFjLENBQUMsaUJBQWlCLENBQUMsV0FBVyxFQUFFLGNBQWMsQ0FBQyxDQUFDO1FBQ3ZFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUNwQixPQUFPLGNBQWMsQ0FBQyx5QkFBeUIsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUMvRCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsZ0JBQWdCLENBQUMsU0FBUyxFQUFFLE1BQU07UUFDaEMsT0FBTyxjQUFjLENBQUMsZUFBZSxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFO1lBQ3JFLE9BQU8sT0FBTyxDQUFDLGNBQWMsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFO2dCQUMvRCxNQUFNLGlCQUFpQixHQUFHLENBQUMsQ0FBQyxjQUFjLENBQ3hDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsaUJBQWlCLENBQUMsTUFBTSxFQUFFLElBQUksQ0FDbEQsQ0FBQztnQkFFRixJQUFJLGlCQUFpQixDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7b0JBQ2xDLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FDbEIsaUJBQWlCLEVBQ2pCLDBEQUEwRCxFQUMxRCxJQUFJLENBQ0wsQ0FBQztpQkFDSDtnQkFFRCxPQUFPO29CQUNMLElBQUksRUFBRSxVQUFVO29CQUNoQixXQUFXLEVBQUUsaUJBQWlCO2lCQUMvQixDQUFDO1lBQ0osQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsZUFBZTtRQUNiLE9BQU8sY0FBYyxDQUFDLGVBQWUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUN4RCxPQUFPLGNBQWMsQ0FBQyx5QkFBeUIsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUMvRCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsSUFBSSxrQkFBa0IsRUFBRSxDQUFDIn0=