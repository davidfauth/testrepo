/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-12-05.
 */
'use strict';
const _ = require('lodash');
const Promise = require('bluebird');
const EphemeralSoftLocks = require('../../../lib/EphemeralSoftLock');
const LKE = require('../index');
const Db = LKE.getSqlDb();
const DataProxy = LKE.getDataProxy();
const Config = LKE.getConfig();
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
const WidgetService = LKE.getWidget();
const Layout = LKE.getLayout();
const Log = LKE.getLogger(__filename);
/**@type {AlertService}*/
const AlertManager = LKE.getAlert();
const VisualizationChecker = require('./VisualizationChecker');
const DesignUtils = require('./designUtils');
const GraphSchemaService = LKE.getGraphSchema();
const { EntityType } = require('@linkurious/rest-client');
// consts
const PUBLIC_FOLDER_FIELDS = ['id', 'title', 'parent', 'sourceKey'];
const VIZ_PUBLIC_FIELDS = [
    'id',
    'title',
    'folder',
    'nodes',
    'edges',
    'nodeFields',
    'edgeFields',
    'design',
    'filters',
    'sourceKey',
    'user',
    'userId',
    'sandbox',
    'createdAt',
    'updatedAt',
    'alternativeIds',
    'mode',
    'layout',
    'geo',
    'timeline'
];
const ADD_ALL_LIMIT = Config.get('advanced.searchAddAllThreshold');
const VisualizationDAO = module.exports = {};
const vizLocks = new EphemeralSoftLocks(60, lock => {
    return Errors.business('visualization_locked', 'This visualization is currently locked by ' +
        lock.owner.username + ' (' + lock.owner.email + '). ' +
        'Your changes will not be saved unless you take over. ' +
        'If you take over, ' + lock.owner.username + ' will be blocked from continuing to edit.' +
        'This lock will expire automatically in ' + Utils.humanDuration(lock.timeLeft) + '.', true);
}, ['email', 'username']);
/**
 * Create a new folder
 *
 * @param {string} title
 * @param {string|number} parent ID of the parent visualizationFolder
 * @param {string} sourceKey Key of the data-source
 * @param {WrappedUser} currentUser the currently connected use (wrapped)
 * @returns {Bluebird<visualizationFolder>}
 */
VisualizationDAO.createFolder = function (title, parent, sourceKey, currentUser) {
    if (Utils.noValue(parent)) {
        parent = -1;
    }
    Utils.check.nonEmpty('title', title);
    Utils.check.nonEmpty('sourceKey', sourceKey);
    Utils.check.exist('currentUser', currentUser);
    Utils.check.integer('parent', parent, -1);
    return _checkFolderCollision(parent, sourceKey, currentUser, title).then(() => {
        return Db.models.visualizationFolder.create({
            title: title,
            parent: parent === null || parent === undefined ? -1 : parent,
            sourceKey: sourceKey,
            userId: currentUser.id
        });
    }).then(_filterFolderFields);
};
function _filterFolderFields(folder) {
    return Promise.resolve(_.pick(folder, PUBLIC_FOLDER_FIELDS));
}
/**
 * Find a folder owned by `user`, with id `id` and sourceKey `sourceKey`.
 *
 * @param {number} folderId
 * @param {string} sourceKey
 * @param {WrappedUser} user
 * @returns {Bluebird<visualizationFolder>} rejected if no folder is found
 * @private
 */
function _findFolder(folderId, sourceKey, user) {
    // root folder explicitly (id=-1) or implicitly (undefined ID)
    if (folderId === -1 || folderId === undefined) {
        // special case for "abstract" root folder
        return Promise.resolve({ id: folderId, userId: user.id, sourceKey: sourceKey });
    }
    return Db.models.visualizationFolder.find({
        where: { id: folderId, sourceKey: sourceKey, userId: user.id }
    }).then(folder => {
        if (!folder) {
            return Errors.business('not_found', `Folder #${folderId} was not found for user #${user.id} in data-source "${sourceKey}".`, true);
        }
        return folder;
    });
}
/**
 * Check for title collision for folders: checks is a folder with title=`title` exists in
 * folder where id=`parentFolderId`.
 *
 * @param {number} parentFolderId
 * @param {string} sourceKey
 * @param {WrappedUser} user
 * @param {string} title
 * @returns {Promise} rejected in case of collision
 * @private
 */
function _checkFolderCollision(parentFolderId, sourceKey, user, title) {
    return Db.models.visualizationFolder.find({
        where: { parent: parentFolderId, sourceKey: sourceKey, userId: user.id, title: title }
    }).then(folder => {
        if (folder) {
            return Errors.business('folder_collision', null, true);
        }
    });
}
/**
 * Update a folder property.
 * Checked in this code:
 * - must the the owner of the folder to edit it
 * - cannot edit properties (id, sourceKey, userId): will fail
 * - cannot move the folder to a folder
 *
 * @param {string|number} folderId ID of the visualizationFolder to update
 * @param {WrappedUser} currentUser the currently connected use (wrapped)
 * @returns {Bluebird<visualizationFolder>}
 */
VisualizationDAO.updateFolder = function (folderId, options, currentUser) {
    if (Utils.noValue(currentUser)) {
        return Errors.business('missing_field', '"currentUser" is required', true);
    }
    Utils.check.object('options', options);
    Utils.check.properties('options', options, {
        title: { check: ['string', true, false, 1, 200] },
        parent: { check: ['integer', -1] }
    });
    // TODO #1818 updateFolder cannot be invoked with both title and parent
    // We need to check if no folder has the same name in the destination folder
    // find folder
    return Db.models.visualizationFolder.findById(folderId).then(folder => {
        if (!folder) {
            return Errors.business('not_found', 'Folder #' + folderId + ' was not found.', true);
        }
        currentUser.canWriteFolder(folder);
        if (Utils.hasValue(options.parent) && options.parent !== folder.parent) {
            const parentId = options.parent;
            // 0) updating parent folder: check that the target folder ID is legal
            Utils.check.integer('parent', parentId, -1);
            // 1) check that the move is structurally correct
            return Promise.resolve().then(() => {
                // 1.a) moving to root: special case shortcut
                if (parentId === -1) {
                    return { id: -1, title: 'root' };
                }
                // 1.b) load folder tree
                return Db.models.visualizationFolder.findAll({ where: {
                        sourceKey: folder.sourceKey,
                        userId: currentUser.id
                    }, attributes: ['id', 'parent', 'title'] }).then(folders => {
                    folders = folders.map(f => f.get());
                    /** @type {Map<String, visualizationFolder>} */
                    const foldersById = Utils.indexBy(folders, folder => folder.id + '');
                    // 2) check if new parent exists
                    const newParent = foldersById.get(parentId + '');
                    if (!newParent) {
                        return Errors.business('not_found', 'Folder #' + parentId + ' was not found.', true);
                    }
                    // 3) check if folder was moved into its own tree
                    let newParentAncestor = newParent;
                    while (newParentAncestor && newParentAncestor.id !== -1) {
                        if (newParentAncestor.id === folder.id) {
                            return Errors.business('invalid_parameter', 'Cannot move a folder into its own subtree.', true);
                        }
                        newParentAncestor = foldersById.get(newParentAncestor.parent + '');
                    }
                    return newParent;
                });
            }).then(newParent => {
                // 4) check for title collisions in the target directory
                return _checkFolderCollision(newParent.id, folder.sourceKey, currentUser, folder.title).return(newParent);
            }).then(newParent => {
                folder.parent = newParent.id;
                return folder;
            });
        }
        else if (Utils.hasValue(options.title) && options.title !== folder.title) {
            const newTitle = options.title;
            // check if this folder name is not already taken in the target folder
            return _checkFolderCollision(folder.parent, folder.sourceKey, currentUser, newTitle).then(() => {
                folder.title = newTitle;
                return folder;
            });
        }
        return folder;
    }).then(updatedFolder => {
        // save and return saved folder
        return updatedFolder.save().then(_filterFolderFields);
    });
};
/**
 * @param {string|number} folderId ID of a visualizationFolder
 * @param {WrappedUser} currentUser the currently connected use (wrapped)
 * @returns {Promise}
 */
VisualizationDAO.removeFolder = function (folderId, currentUser) {
    return Db.models.visualizationFolder.findById(folderId).then(folder => {
        if (folder === null) {
            throw Errors.business('not_found', 'Folder #' + folderId + ' was not found.');
        }
        currentUser.canWriteFolder(folder);
        // Folder has children if any visualisation or folder belongs to it
        return Promise.map([Db.models.visualizationFolder.findOne({ where: { parent: folderId } }),
            Db.models.visualization.findOne({ where: { folder: folderId } })], Utils.hasValue)
            .then(([containsFolders, containsVisualizations]) => {
            if (containsFolders || containsVisualizations) {
                return Errors.business('folder_deletion_failed', 'Cannot delete ' +
                    'a folder that is not empty, move or delete the content ' +
                    'before deleting the folder.', true);
            }
            else {
                return folder.destroy();
            }
        });
    });
};
/**
 * Only attributes 'id', 'folder', 'title', 'updatedAt', 'createdAt' are returned.
 *
 * @param {string} sourceKey Key of the data-source
 * @param {WrappedUser} currentUser the currently connected use (wrapped)
 * @returns {Bluebird<visualization[]>}
 * @private
 */
VisualizationDAO._getAll = function (sourceKey, currentUser) {
    // we load the shares just to add the count to the visualization object
    // if guest mode is not allowed, we don't count the shares towards the guest user
    const guestModeAllowed = Config.get('access.guestMode');
    let guestUserIdFilter;
    if (!guestModeAllowed) {
        guestUserIdFilter = {
            userId: { $ne: Db.models.user.GUEST_USER_ID }
        };
    }
    return Promise.resolve(Db.models.visualization.findAll({
        where: { sourceKey: sourceKey, userId: currentUser.id, sandbox: false },
        attributes: ['id', 'folder', 'title', 'updatedAt', 'createdAt'],
        include: [{
                model: Db.models.visualizationShare,
                required: false,
                where: guestUserIdFilter
            }]
    })).map(visualization => {
        // remove the shares before returning
        visualization = visualization.get();
        visualization.shareCount = visualization.visualizationShares.length;
        delete visualization.visualizationShares;
        return visualization;
    });
};
/**
 *
 * @param {string|number|null} parentId
 * @param {visualizationFolder[]} folders
 * @param {visualization[]} visualizations
 * @param {object} widgetsByViz widgets by visualization ID
 * @returns {visualizationFolder[]}
 */
function buildTree(parentId, folders, visualizations, widgetsByViz) {
    const subTree = [];
    // folders
    folders.forEach(folder => {
        if (folder.parent === parentId) {
            const children = buildTree(folder.id, folders, visualizations, widgetsByViz);
            const newFolder = {
                id: folder.id,
                type: 'folder',
                title: folder.title
            };
            if (children) {
                newFolder.children = children;
            }
            subTree.push(newFolder);
        }
    });
    // files
    let widget;
    visualizations.forEach(visu => {
        if (visu.folder === parentId) {
            widget = widgetsByViz[visu.id];
            subTree.push({
                id: visu.id,
                type: 'visu',
                title: visu.title,
                shareCount: visu.shareCount,
                updatedAt: visu.updatedAt,
                createdAt: visu.createdAt,
                widgetKey: widget ? widget.key : widget
            });
        }
    });
    return subTree;
}
/**
 * Each returned folder has a `children` property containing Visualization and
 * VisualizationFolder objects.
 *
 * @param {string} sourceKey Key of the data-source
 * @param {WrappedUser} currentUser the currently connected use (wrapped)
 * @returns {Bluebird<Array<visualization|visualizationFolder>>}
 */
VisualizationDAO.getTree = function (sourceKey, currentUser) {
    const userId = currentUser.id;
    return Promise.join(this._getAll(sourceKey, currentUser), Db.models.visualizationFolder.findAll({ where: { sourceKey: sourceKey, userId: userId } }), Db.models.widget.findAll({ where: { userId: userId }, attributes: ['visualizationId', 'key'] }), (visualizations, folders, widgets) => {
        const widgetsByViz = _.keyBy(widgets, 'visualizationId');
        return Promise.resolve(buildTree(-1, folders, visualizations, widgetsByViz));
    });
};
/**
 * Migrate nodeFields and edgeFields
 *
 * @param {visualization} viz visualization
 */
VisualizationDAO.migrateFields = function (viz) {
    // #293 migrate nodeFields and edgeFields
    _.forEach(['nodeFields', 'edgeFields'], key => {
        let orgValue = viz[key];
        if (!orgValue) {
            orgValue = [];
        }
        // already migrated
        if (!Array.isArray(orgValue)) {
            return;
        }
        // migrate
        viz[key] = { fields: orgValue, captions: {} };
    });
};
/**
 *
 * @param {string|Number} vizId
 * @param {boolean} populated whether to include resolved nodes and edges in the result
 *                  if false, 'right' and 'user' will not be included in the visualization.
 * @param {WrappedUser} user the currently connected user
 * @param {object} [options]
 * @param {boolean} [options.withDigest=false] Whether to include the digest in the returned nodes
 * @param {boolean} [options.withDegree=false] Whether to include the degree in the returned nodes
 * @returns {Bluebird<PublicVisualization>}
 */
VisualizationDAO.getById = function (vizId, populated, user, options) {
    if (!options) {
        options = {};
    }
    return _findViz(vizId, true).then(viz => {
        // throw an error if the required data-source is not available
        DataProxy.resolveSource(viz.sourceKey).assertReady();
        return user.getVisualizationRight(viz).then(right => {
            // unwrap sequelize object, add right (of current user) and user (owner information)
            viz = _filterVizFields(viz);
            viz.right = right;
            // #293 migrate nodeFields and edgeFields
            VisualizationDAO.migrateFields(viz);
            if (!populated) {
                return viz;
            }
            // in case alternative IDs are used, store the path of effective IDs
            const nodeIdPath = viz.alternativeIds.node === undefined
                ? 'id' : ['data', viz.alternativeIds.node];
            const edgeIdPath = viz.alternativeIds.edge === undefined
                ? 'id' : ['data', viz.alternativeIds.edge];
            // fetch nodes and edges
            return DataProxy.getNodesAndEdgesByID({
                nodeIds: _.map(viz.nodes, 'id'),
                edgeIds: _.map(viz.edges, 'id'),
                sourceKey: viz.sourceKey,
                alternativeNodeId: viz.alternativeIds.node,
                alternativeEdgeId: viz.alternativeIds.edge,
                ignoreMissing: true,
                withDigest: options.withDigest,
                withDegree: options.withDegree
            }, user).then(subgraph => {
                if (subgraph.isFiltered && (viz.right === 'owner' || viz.right === 'write')) {
                    viz.right += '-filtered';
                }
                const vizNodesByID = _.keyBy(viz.nodes, 'id');
                // if node ids returned by getNodesById do not match the visualization ids
                // then the nodes are assigned a random position
                viz.nodes = _.map(subgraph.result.nodes, dbN => _node2VizNode(dbN, vizNodesByID[_.get(dbN, nodeIdPath)]));
                // needed in edge-filter step, in case some vizNodes are not readable by current user or
                // if the viz is using alternative IDs (edge.source and edge.target are native node DB IDs).
                const nodesByDbID = _.keyBy(viz.nodes, 'id');
                const edges = _.filter(subgraph.result.edges, 
                // edge must be defined AND have source and target in the nodes
                edge => !!edge &&
                    nodesByDbID[edge.source] !== undefined &&
                    nodesByDbID[edge.target] !== undefined);
                const vizEdgesByID = _.keyBy(viz.edges, 'id');
                viz.edges = _.map(edges, dbE => _edge2VizEdge(dbE, vizEdgesByID[_.get(dbE, edgeIdPath)]));
                return _cleanVizFilters(viz);
            });
        });
    }).then(viz => {
        // set the widget key
        return WidgetService.getWidgetKeyFromVisualizationId(viz.id).then(key => {
            viz.widgetKey = key || null;
            return viz;
        });
    });
};
/**
 * Remove node and edge filters from `filters` and `timeline` of the visualization when the schema
 * is no longer coherent for a given filter. When a filter is created, its type is based on the
 * type of the property as defined in the schema. When the type of the property in the schema is
 * updated to a new type, the filter is no longer applicable and it must be removed.
 *
 * @param {PublicVisualization} viz
 * @returns {Promise<PublicVisualization>}
 * @private
 */
async function _cleanVizFilters(viz) {
    const nodeSchema = await GraphSchemaService.getSchema(viz.sourceKey, EntityType.NODE);
    const edgeSchema = await GraphSchemaService.getSchema(viz.sourceKey, EntityType.EDGE);
    // Clean filters
    viz.filters.node = _cleanFilters(viz.filters.node, viz.nodeFields.types, nodeSchema);
    viz.filters.edge = _cleanFilters(viz.filters.edge, viz.edgeFields.types, edgeSchema);
    // Clean time filters
    viz.timeline.node = _cleanTimeFilters(viz.timeline.node, nodeSchema);
    viz.timeline.edge = _cleanTimeFilters(viz.timeline.edge, edgeSchema);
    // If node/edge time filters are empty we make sure range and zoomLevel are empty too
    if (Object.keys(viz.timeline.node).length === 0 && Object.keys(viz.timeline.edge).length === 0) {
        viz.timeline = { node: {}, edge: {} };
    }
    return viz;
}
/**
 * Remove the filters whose category is not in the schema, or whose property is not in the schema
 * for such category or whose type of the property used in the schema for such category has been
 * updated to anything but date or datetime.
 *
 * @param {GenericObject<string>} timeFilters
 * @param {EntitySchema}          schema
 * @returns {GenericObject<string>}
 * @private
 */
function _cleanTimeFilters(timeFilters, schema) {
    const newTimeFilters = {};
    for (const category in timeFilters) {
        if (!schema.has(category)) {
            continue;
        }
        const property = timeFilters[category];
        const propertyObj = schema.get(category).properties.find(prop => prop.propertyKey === property);
        if (propertyObj === undefined) {
            continue;
        }
        const { name } = propertyObj.propertyType;
        if (name === 'date' || name === 'datetime') {
            newTimeFilters[category] = property;
        }
    }
    return newTimeFilters;
}
/**
 * Remove the old date filters or the filters that are no longer coherent with the schema.
 *
 * @param {VisualizationFilter[]}                filters
 * @param {GenericObject<GenericObject<string>>} fields
 * @param {EntitySchema}                         schema
 * @returns {VisualizationFilter[]}
 * @private
 */
function _cleanFilters(filters, fields, schema) {
    return filters.filter(filter => {
        const category = filter.itemType;
        const propertyKey = filter.input && filter.input[1];
        const value = filter.value;
        let schemaPropertyType = 'auto';
        let schemaPropertyOptions;
        if (schema.has(category)) {
            const propertyObj = schema.get(category).properties.find(prop => prop.propertyKey === propertyKey);
            if (Utils.hasValue(propertyObj)) {
                schemaPropertyType = propertyObj.propertyType.name;
                schemaPropertyOptions = propertyObj.propertyType.options;
            }
        }
        const filterType = _resolveFilterType(filter, fields);
        switch (filterType) {
            case 'AUTO_STRING': {
                return schemaPropertyType === 'string' || schemaPropertyType === 'auto';
            }
            case 'STRING_OR_ENUM': {
                if (schemaPropertyType !== 'string') {
                    return false;
                }
                else if (schemaPropertyOptions && schemaPropertyOptions.values) {
                    // if schema type is enum, we only keep the filter if the value is a valid value
                    return schemaPropertyOptions.values.includes(value);
                }
                return true;
            }
            case 'AUTO_NUMBER': {
                return schemaPropertyType === 'number' || schemaPropertyType === 'auto';
            }
            case 'NUMBER': {
                return schemaPropertyType === 'number';
            }
            case 'BOOLEAN': {
                return schemaPropertyType === 'boolean';
            }
            case 'DEPRECATED_DATE':
                return false;
            case 'INVALID_FILTER':
                Log.warn('We were not able to determine the filter type of', JSON.stringify(filter));
                return true;
            case 'ANY':
            case 'NOVALUE':
            default: {
                return true;
            }
        }
    });
}
/**
 * @param {VisualizationFilter}                  filter
 * @param {GenericObject<GenericObject<string>>} fields
 * @returns {string}
 * @private
 */
function _resolveFilterType(filter, fields) {
    const filterType = filter.type;
    const value = filter.value;
    if (filterType === 'any') {
        return 'ANY';
    }
    const category = filter.itemType;
    if (Utils.noValue(category) ||
        Utils.noValue(filter.input) ||
        Utils.noValue(filter.input[1]) ||
        filter.input[0] !== 'properties') {
        return 'INVALID_FILTER';
    }
    const propertyKey = filter.input[1];
    const fieldType = fields &&
        fields[category] &&
        fields[category][propertyKey] &&
        fields[category][propertyKey].type;
    if (filterType === 'novalue') {
        return 'NOVALUE';
    }
    // String filters with auto property type in the schema
    if (filterType === 'is' && fieldType === 'string') {
        return 'AUTO_STRING';
    }
    // Number filters with auto property type in the schema
    if (['nan', 'range'].includes(filterType) && fieldType === 'number') {
        return 'AUTO_NUMBER';
    }
    // String or Enum filters with string property type in the schema
    if (filterType === 'is' && typeof value === 'string' && !fieldType) {
        return 'STRING_OR_ENUM';
    }
    // Boolean filters with boolean property type in the schema
    if (filterType === 'is' && typeof value === 'boolean' && !fieldType) {
        return 'BOOLEAN';
    }
    // Number filters with number property type in the schema
    if (['nan', 'range'].includes(filterType) && !fieldType) {
        return 'NUMBER';
    }
    // Old date filters from 2.7
    if (fieldType === 'date-timestamp') {
        return 'DEPRECATED_DATE';
    }
    return 'INVALID_FILTER';
}
/**
 * Get the sandbox for a (data-source, user). Optionally return populated with a node/edge
 *
 * @param {object} options
 * @param {string} options.sourceKey Key of the data-source
 * @param {string} [options.populate] Describes how the sandbox should be populated (must be one of `["visualizationId","expandNodeId","nodeId","edgeId","searchNodes","searchEdges","pattern","matchId"]`)
 * @param {number|string} [options.itemId] ID of the node, or edge to load (when `options.populate` is one of  `["visualizationId", "nodeId", "edgeId", "expandNodeId"]`)
 * @param {number} [options.matchId] ID of the alert match load (when `options.populate` is `"matchId"`)
 * @param {string} [options.searchQuery] Search query to search for nodes or edges (when `options.populate` is one of  `["searchNodes", "searchEdges"]`)
 * @param {number} [options.searchFuzziness] Search query fuzziness (when `options.populate` is one of  `["searchNodes", "searchEdges"]`)
 * @param {string} [options.patternQuery] Pattern query to match nodes and/or edges (when `populate` is `"pattern"`)
 * @param {string} [options.patternDialect] Pattern dialect (when `populate` is `"pattern"`)
 * @param {boolean} [options.doLayout] Whether to apply a server-side layout
 * @param {boolean} [options.withDigest] Whether to include the adjacency digest in the returned nodes
 * @param {boolean} [options.withDegree] Whether to include the degree in the returned nodes
 * @param {WrappedUser} user the user currently logged in
 * @returns {Bluebird<PublicVisualization>} the sandbox visualization
 */
VisualizationDAO.getSandBox = function (options, user) {
    const proxyOptions = user;
    return Promise.resolve().then(() => {
        Utils.check.values('populate', options.populate, [
            undefined,
            'visualizationId',
            'expandNodeId', 'nodeId', 'edgeId',
            'searchNodes', 'searchEdges',
            'pattern',
            'matchId'
        ]);
        switch (options.populate) {
            case 'visualizationId':
            case 'expandNodeId':
            case 'nodeId':
            case 'edgeId':
                Utils.check.exist('itemId', options.itemId);
                break;
            case 'matchId':
                Utils.check.posInt('matchId', options.matchId);
                break;
            case 'searchNode':
            case 'searchEdge':
                Utils.check.string('searchQuery', options.searchQuery, true);
                if (options.searchFuzziness !== undefined) {
                    Utils.check.number('searchFuzziness', options.searchFuzziness, 0, 1);
                }
                break;
            case 'pattern':
                Utils.check.string('patternQuery', options.patternQuery, true);
                Utils.check.string('patternDialect', options.patternDialect, true);
                break;
        }
        return _findSandBox(options.sourceKey, user);
    }).then(sandbox => {
        sandbox = _filterVizFields(sandbox);
        if (!options.populate) {
            return sandbox;
        }
        sandbox.nodes = [];
        sandbox.edges = [];
        // populate the sandbox ...
        if (options.populate === 'visualizationId') {
            // ... with a visualization
            return this.getById(options.itemId, true, user, {
                withDigest: options.withDigest,
                withDegree: options.withDegree
            }).then(visualization => {
                sandbox.nodes = visualization.nodes;
                sandbox.edges = visualization.edges;
                sandbox.design = visualization.design;
                sandbox.nodeFields = visualization.nodeFields;
                sandbox.edgeFields = visualization.edgeFields;
                sandbox.title = visualization.title;
                sandbox.filters = visualization.filters;
                return sandbox;
            });
        }
        else if (options.populate === 'nodeId') {
            // ... with a node
            return DataProxy.getNode({
                id: options.itemId,
                withDigest: options.withDigest,
                withDegree: options.withDegree,
                sourceKey: options.sourceKey
            }, proxyOptions).then(subgraph => {
                sandbox.nodes = [_node2VizNode(subgraph.nodes[0], { x: 0, y: 0 })];
                return sandbox;
            });
        }
        else if (options.populate === 'edgeId') {
            // ... with edge
            const getEdgeOptions = {
                id: options.itemId,
                sourceKey: options.sourceKey,
                withDigest: options.withDigest,
                withDegree: options.withDegree
            };
            return DataProxy.getEdge(getEdgeOptions, proxyOptions).then(subgraph => {
                sandbox.edges = subgraph.edges;
                sandbox.nodes = [
                    _node2VizNode(subgraph.nodes[0], { x: 0, y: 0 }),
                    _node2VizNode(subgraph.nodes[1], { x: 30, y: -1 })
                ];
                return sandbox;
            });
        }
        else if (options.populate === 'expandNodeId') {
            return DataProxy.getNode({
                id: options.itemId,
                withDigest: options.withDigest,
                withDegree: options.withDegree,
                sourceKey: options.sourceKey
            }, proxyOptions).then(subGraph => {
                const sourceNode = _node2VizNode(subGraph.nodes[0]);
                return DataProxy.getAdjacentNodes([options.itemId], {
                    limit: ADD_ALL_LIMIT,
                    withDigest: options.withDigest,
                    withDegree: options.withDegree
                }, options.sourceKey, proxyOptions).then(subGraph => {
                    sandbox.edges = subGraph.edges;
                    sandbox.nodes = _.map(subGraph.nodes, node => _node2VizNode(node));
                    sandbox.nodes.unshift(sourceNode);
                    return sandbox;
                });
            });
        }
        else if (options.populate === 'searchNodes' || options.populate === 'searchEdges') {
            // ... with a search query
            return DataProxy.searchFull({
                type: options.populate === 'searchNodes' ? 'node' : 'edge',
                q: options.searchQuery,
                fuzziness: options.searchFuzziness,
                size: ADD_ALL_LIMIT,
                sourceKey: options.sourceKey,
                withDigest: options.withDigest,
                withDegree: options.withDegree
            }, proxyOptions).then(subgraph => {
                sandbox.edges = subgraph.edges;
                sandbox.nodes = _.map(subgraph.nodes, node => _node2VizNode(node));
                return sandbox;
            });
        }
        else if (options.populate === 'pattern') {
            // ... with a pattern matching query (cypher, gremlin, ...)
            return DataProxy.runGraphQueryByContent({
                sourceKey: options.sourceKey,
                dialect: options.patternDialect,
                query: options.patternQuery,
                withDigest: options.withDigest,
                withDegree: options.withDegree
            }, proxyOptions).then(subgraph => {
                sandbox.edges = subgraph.edges;
                sandbox.nodes = _.map(subgraph.nodes, node => _node2VizNode(node));
                return sandbox;
            });
        }
        else if (options.populate === 'matchId') {
            return AlertManager.getMatch(options.matchId, user).then(match => {
                const nodeOptions = {
                    ids: match.nodes,
                    sourceKey: options.sourceKey,
                    withDigest: options.withDigest,
                    withDegree: options.withDegree
                };
                const edgeOptions = { ids: match.edges, sourceKey: options.sourceKey };
                // TODO 2.6.0 ignore missing?
                return DataProxy.getNodesByID(nodeOptions, proxyOptions).then(nodes => {
                    sandbox.nodes = _.map(nodes, node => _node2VizNode(node));
                    return DataProxy.getEdgesByID(edgeOptions, proxyOptions);
                }).then(edges => {
                    sandbox.edges = edges.map(edge => _edge2VizEdge(edge));
                    return sandbox;
                });
            });
        }
    }).then(sandbox => {
        // note: layout.incremental is persisted and restored, but not layout.algorithm or layout.mode
        if (options.doLayout && sandbox.nodes.length >= 1) {
            return _doLayout(sandbox);
        }
        else {
            // layout not requested or not needed
            sandbox.layout = { incremental: sandbox.layout.incremental };
            return sandbox;
        }
    });
};
/**
 * @param {visualization} visualization
 * @returns {Bluebird<visualization>}
 * @private
 */
function _doLayout(visualization) {
    // server-side layout requested and needed
    visualization.layout = {
        algorithm: 'force',
        incremental: visualization.layout ? visualization.layout.incremental : false
    };
    return Layout.layout(visualization);
}
/**
 *
 * @param {object} viz
 * @param {string} viz.sourceKey Key of the data-source
 * @param {string} viz.title
 * @param {string|number} [viz.folder] ID of visualizationFolder (or null for root)
 *
 * @param {object} viz.nodeFields
 * @param {object} viz.nodeFields.captions Key: nodeCategory:string. Value: {active:boolean, displayName:boolean, properties:string[]}
 *
 * @param {object} viz.edgeFields
 * @param {object} viz.edgeFields.captions Key: edgeType:string. Value: {active:boolean, displayName:boolean, properties:string[]}
 *
 * @param {object[]} viz.nodes
 * @param {string|number} viz.nodes.id Node ID (seen `alternativeIds` to use non-native IDs)
 * @param {boolean} [viz.nodes.selected=false]
 * @param {object} viz.nodes.nodelink
 * @param {number} viz.nodes.nodelink.x
 * @param {number} viz.nodes.nodelink.y
 * @param {boolean} [viz.nodes.nodelink.fixed=false]
 * @param {object} [viz.nodes.geo]
 * @param {number} [viz.nodes.latitude]
 * @param {number} [viz.nodes.latitudeDiff]
 * @param {number} [viz.nodes.longitude]
 * @param {number} [viz.nodes.longitudeDiff]
 *
 * @param {object[]} viz.edges
 * @param {string|number} viz.edges.id Edge IDs (seen `alternativeIds` to use non-native IDs)
 * @param {boolean} [viz.edges.selected=false]
 *
 * @param {object} [viz.design]
 * @param {object} [viz.design.styles]
 * @param {object} [viz.design.palette]
 *
 * @param {{node: object[], edge: object[]}} [viz.filters]
 *
 * @param {object} [viz.alternativeIds]
 * @param {string} [viz.alternativeIds.node] alternative (non-native) node ID
 * @param {string} [viz.alternativeIds.edge] alternative (non-native) edge ID
 *
 * @param {string} viz.mode Current mode ("nodelink" or "geo")
 *
 * @param {object} viz.layout Last used Layout
 * @param {string} viz.layout.algorithm Layout algorithm ("force" or "hierarchical")
 *
 * @param {string} [viz.layout.mode] Layout mode (depends on algorithm)
 * @param {object} [viz.geo]
 * @param {string} [viz.geo.latitudeProperty]
 * @param {string} [viz.geo.longitudeProperty]
 * @param {string[]} [viz.geo.layers] Enabled tiles layers
 *
 *
 * @param {object} [viz.timeline]          Timeline configuration
 * @param {object} viz.timeline.node       Key value pairs representing the node type and property to be included in the timeline
 * @param {object} viz.timeline.edge       Key value pairs representing the node type and property to be included in the timeline
 * @param {object} [viz.timeline.range     The selected time frame to filter the visualization data
 * @param {number} [viz.timeline.range.<=] Less than or equal (date in milliseconds)
 * @param {number} [viz.timeline.range.<]  Less than (date in milliseconds)
 * @param {number} [viz.timeline.range.>]  Greater than (date in milliseconds)
 * @param {number} [viz.timeline.range.>=] Greater than or equal (date in milliseconds)
 *
 * @param {WrappedUser} currentUser the currently connected use (wrapped)
 * @returns {Bluebird<PublicVisualization>}
 */
VisualizationDAO.createVisualization = function (viz, currentUser) {
    if (!currentUser) {
        return Errors.business('missing_field', '"currentUser" is required', true);
    }
    Utils.check.object('visualization', viz);
    const source = DataProxy.resolveSource(viz.sourceKey);
    // default values
    if (Utils.noValue(viz.folder)) {
        viz.folder = -1;
    }
    if (!viz.filters) {
        viz.filters = { node: [], edge: [] };
    }
    if (!viz.mode) {
        viz.mode = 'nodelink';
    }
    if (Utils.noValue(viz.alternativeIds)) {
        viz.alternativeIds = {};
    }
    if (Utils.noValue(viz.layout)) {
        viz.layout = {};
    }
    if (Utils.noValue(viz.geo)) {
        viz.geo = {};
    }
    if (Utils.noValue(viz.geo.layers)) {
        viz.geo.layers = [];
    }
    if (Utils.noValue(viz.nodeFields)) {
        viz.nodeFields = { captions: source.state.defaultCaptions.nodes, types: {} };
    }
    if (Utils.noValue(viz.edgeFields)) {
        viz.edgeFields = { captions: source.state.defaultCaptions.edges, types: {} };
    }
    // validate visualization object
    VisualizationChecker.checkCreation('visualization', viz);
    DataProxy
        .resolveSource(viz.sourceKey)
        .checkAlternativeIdKeys(viz.alternativeIds);
    const getDesign = viz.design
        ? Promise.resolve(viz.design)
        : VisualizationDAO.getSandBox({ sourceKey: viz.sourceKey }, currentUser).get('design');
    return getDesign.then(design => {
        return Db.models.visualization.create({
            title: Utils.noValue(viz.title) ? 'Untitled Visualization' : viz.title,
            sandbox: false,
            folder: viz.folder,
            nodes: viz.nodes,
            edges: viz.edges,
            nodeFields: viz.nodeFields,
            edgeFields: viz.edgeFields,
            alternativeIds: viz.alternativeIds,
            design: design,
            filters: viz.filters,
            sourceKey: viz.sourceKey,
            userId: currentUser.id,
            mode: viz.mode,
            layout: viz.layout,
            geo: viz.geo,
            timeline: viz.timeline,
            version: 4
        });
    }).then(_filterVizFields);
};
/**
 * @param {VisualizationInstance} _viz
 * @returns {PublicVisualization}
 * @private
 */
function _filterVizFields(_viz) {
    const viz = _.pick(_viz.get(), VIZ_PUBLIC_FIELDS);
    const source = DataProxy.resolveSource(viz.sourceKey);
    // default alternative IDs
    if (!viz.alternativeIds) {
        viz.alternativeIds = {};
    }
    // default interaction mode
    if (!viz.mode) {
        viz.mode = 'nodelink';
    }
    // default layout
    if (!viz.layout) {
        viz.layout = { algorithm: 'force', mode: 'fast', incremental: false };
    }
    if (!viz.nodeFields.captions) {
        viz.nodeFields.captions = source.defaultCaptions.nodes;
    }
    if (!viz.edgeFields.captions) {
        viz.edgeFields.captions = source.defaultCaptions.edges;
    }
    // default geo data (read from source config), reset for sandbox
    if (!viz.geo || viz.sandbox) {
        const source = DataProxy.resolveSource(viz.sourceKey);
        viz.geo = {
            latitudeProperty: source.config.graphdb.latitudeProperty,
            longitudeProperty: source.config.graphdb.longitudeProperty,
            // for a sandbox, the layers might be set, don't reset them in that case
            layers: viz.geo ? viz.geo.layers : []
        };
    }
    // filter the owner user (if set)
    if (viz.user) {
        viz.user = _.pick(viz.user, ['id', 'username', 'email']);
    }
    return viz;
}
/**
 * Count visualizations for a user
 *
 * @param {string} sourceKey Key of the data-source
 * @param {boolean} [skipSourceKeyValidation=false] Whether to skip the validation of the sourceKey
 * @returns {Bluebird<number>} the number of visualizations
 */
VisualizationDAO.getVisualizationCount = function (sourceKey, skipSourceKeyValidation) {
    if (!skipSourceKeyValidation) {
        Utils.checkSourceKey(sourceKey);
    }
    return Promise.resolve(Db.models.visualization.count({ where: {
            sourceKey: sourceKey,
            sandbox: false
        } }));
};
/**
 * Duplicates a visualization and saves it in the same folder as the targeted visualization
 *
 * @param {object} options
 * @param {number} options.id ID of the visualization to duplicate
 * @param {number} [options.folderId] ID of the target folder (defaults to same folder if user is not changing, or root folder is user is changing)
 * @param {string} [options.title] title of the target (defaults to `"Copy of [source title]"`)
 * @param {WrappedUser} wUser the currently connected user
 * @returns {Bluebird<number>}
 */
VisualizationDAO.duplicateVisualization = function (options, wUser) {
    Utils.check.properties('options', options, {
        id: { required: true, check: 'posInt' },
        folderId: { check: ['number', -1] },
        title: { check: 'nonEmpty' }
    });
    let vizCopy;
    return _findViz(options.id).then(_visualization => {
        vizCopy = _visualization.get();
        // this will reject if currentUser has not at least read access to the visualization
        return wUser.getVisualizationRight(_visualization);
    }).then(() => {
        // remove instance-specific info
        delete vizCopy.id;
        delete vizCopy.createdAt;
        delete vizCopy.updatedAt;
        // set default folder
        if (Utils.noValue(options.folderId)) {
            if (vizCopy.userId === wUser.id) {
                // the source and target users are the same, keep the viz in the same folder
                options.folderId = vizCopy.folder;
            }
            else {
                // the source and target users are different, set viz at root folder or target user
                options.folderId = -1;
            }
        }
        // set the owner of the viz to the current user
        vizCopy.userId = wUser.id;
        // set the title
        if (Utils.hasValue(options.title)) {
            vizCopy.title = options.title;
        }
        else {
            vizCopy.title = 'Copy of ' + vizCopy.title;
        }
        // set the folder (checks that the folder is owned by the current user in current data-source)
        return _findFolder(options.folderId, vizCopy.sourceKey, wUser);
    }).then(folder => {
        vizCopy.folder = folder.id;
        // save the copy
        return Db.models.visualization.create(vizCopy);
    }).get('id');
};
/**
 * Update a visualization.
 * Checked in this code:
 * - to update the folder, `currentUser` must be the owner
 * - to update any other field, `currentUser` must has write access
 * - field (id, sourceKey, userId, sandbox) cannot be updated and will be silently ignored
 * - updating other fields not included in VIZ_EDITABLE_FIELDS will cause an error
 *
 * @param {number} vizId ID of the visualization to update
 * @param {object} newProperties map of properties to update with new values
 * @param {object} [newProperties.folder]
 * @param {object} [newProperties.title]
 * @param {object} [newProperties.nodes]
 * @param {object} [newProperties.edges]
 * @param {object} [newProperties.design]
 * @param {object} [newProperties.filters]
 * @param {object} [newProperties.nodeFields]
 * @param {object} [newProperties.edgeFields]
 * @param {object} [newProperties.alternativeIds]
 * @param {object} options
 * @param {boolean} [options.forceLock=false] Take the edit-lock by force (if `currentUser` doesn't own it)
 * @param {boolean} [options.doLayout=false] Perform a server-side layout of the visualization graph
 * @param {WrappedUser} currentUser the currently connected use (wrapped)
 * @returns {Bluebird<VisualizationInstance>}
 */
VisualizationDAO.updateVisualization = function (vizId, newProperties, options, currentUser) {
    if (!newProperties && !options.doLayout) {
        throw Errors.business('missing_field');
    }
    newProperties = _.defaults(newProperties);
    if (!currentUser) {
        throw Errors.business('missing_field', '"currentUser" is required');
    }
    if (typeof newProperties !== 'object') {
        throw Errors.business('invalid_parameter', 'new visualization fields must be given as a map');
    }
    Utils.check.objectKeys('options', options, ['forceLock', 'doLayout']);
    // ignore these fields from newProperties (they cannot be changed)
    delete newProperties.id;
    delete newProperties.sourceKey;
    delete newProperties.userId;
    delete newProperties.sandbox;
    // check for unexpected keys
    VisualizationChecker.checkUpdate('visualization', newProperties);
    return vizLocks.take(vizId, currentUser, options.forceLock).then(() => {
        // find the visualization in DB
        return _findViz(vizId);
    }).then(viz => {
        DataProxy.resolveSource(viz.sourceKey).checkAlternativeIdKeys(newProperties.alternativeIds);
        // if the folder is provided but did not change, ignore the change
        if (newProperties.folder !== undefined && viz.folder === newProperties.folder) {
            delete newProperties.folder;
        }
        // if the user wants to change the folder, it needs to be the owner
        const neededRight = newProperties.folder !== undefined ? 'owner' : 'write';
        return currentUser.hasVisualizationRight(viz, neededRight).then(() => {
            let updatePromise = Promise.resolve();
            // update all fields given as parameters
            _.forEach(newProperties, (value, key) => {
                if (key === 'folder') {
                    // check that the folder exists + belongs to user + is in the same sourceKey as the viz
                    updatePromise = _findFolder(value, viz.sourceKey, currentUser).then(folder => {
                        viz.folder = folder.id;
                    });
                }
                else {
                    viz[key] = value;
                }
            });
            return updatePromise;
        }).then(() => {
            // layout not requested/required
            if (!options.doLayout || viz.nodes.length === 0) {
                return;
            }
            // layout visualization
            // 1) load populated viz
            return VisualizationDAO.getById(viz.id, true, currentUser).then(populatedViz => {
                // 2) layout populated viz
                return _doLayout(populatedViz);
            }).then(laidOutViz => {
                // 3) patch current nodes with new coordinates
                const newNodes = new Array(laidOutViz.nodes.length);
                laidOutViz.nodes.forEach((n, i) => {
                    const un = viz.nodes[i];
                    if (!un.nodelink) {
                        un.nodelink = {};
                    }
                    if (un.nodelink.fixed !== true) {
                        un.nodelink.x = n.nodelink.x;
                        un.nodelink.y = n.nodelink.y;
                    }
                    newNodes[i] = un;
                });
                // 4) update "nodes" in updated viz with patched nodes
                viz.nodes = newNodes;
            });
        }).then(() => {
            return viz.save();
        });
    }).then(_filterVizFields);
};
/**
 * Update the sandbox visualization.
 *
 * @param {string} sourceKey Key of the data-source
 * @param {object} newProperties
 * @param {object} [newProperties.design]
 * @param {object} [newProperties.nodeFields]
 * @param {object} [newProperties.edgeFields]
 * @param {WrappedUser} currentUser
 * @returns {Promise}
 */
VisualizationDAO.updateSandBox = function (sourceKey, newProperties, currentUser) {
    Utils.check.object('visualization', newProperties);
    // ignore these fields from newProperties (they cannot be changed)
    delete newProperties.id;
    delete newProperties.sourceKey;
    delete newProperties.userId;
    delete newProperties.sandbox;
    return _findSandBox(sourceKey, currentUser).then(viz => {
        // sandboxes: only edit nodeFields, edgeFields, design
        // #956 Patch sandbox should validate captions
        VisualizationChecker.checkUpdateSandbox('visualisation', newProperties);
        _.forEach(newProperties, (value, key) => {
            viz[key] = value;
        });
        return viz.save();
    }).return(undefined);
};
/**
 * Remove a visualization
 *
 * @param {string|Number} visualizationId
 * @param {WrappedUser} currentUser the currently connected use (wrapped)
 * @returns {Promise}
 */
VisualizationDAO.removeById = function (visualizationId, currentUser) {
    return _findViz(visualizationId).then(visualization => {
        return currentUser.hasVisualizationRight(visualization, 'owner').then(() => {
            return Promise.resolve(visualization.destroy());
        });
    });
};
/**
 * If the visualization is not up to date, update it to the latest version and return it.
 *
 * @param {VisualizationInstance} visualization
 * @returns {Bluebird<VisualizationInstance>}
 * @private
 * @backward-compatibility
 */
function _updateViz(visualization) {
    return _updateVizToVersion2(visualization)
        .then(v2Viz => _updateVizToVersion3(v2Viz))
        .then(v3Viz => _updateVizToVersion4(v3Viz));
}
/**
 * If the visualization is version 1, update it to version 2 and return it.
 *
 * Filters are stored in a different format.
 *
 * @param {VisualizationInstance} visualization
 * @returns {Bluebird<VisualizationInstance>}
 * @private
 * @backward-compatibility
 */
function _updateVizToVersion2(visualization) {
    if (visualization.version > 1) {
        return Promise.resolve(visualization);
    }
    else {
        visualization.filters = visualization.filters.map(filter => {
            // there are 5 types of filters in in visualization v1
            // - filters with key "node.data.categories"
            // - filters with key "node.data.properties.<propertyName>"
            // - filters with key "edge.data.type"
            // - filters with key "edge.data.properties.<propertyName>"
            // - filters with key "geo-coordinates"
            if (filter.key === 'geo-coordinates') {
                // Valid geo filter
                return {
                    key: 'geo-coordinates'
                };
            }
            if (Utils.noValue(filter.options) || Utils.noValue(filter.key)) {
                Log.warn('This v1 filter was invalid: ', JSON.stringify(filter));
                return; // the filter is invalid
            }
            const values = _.keys(_.pickBy(filter.options.values));
            if (values.length === 0) {
                Log.warn('This v1 filter was invalid: ', JSON.stringify(filter));
                return; // the filter is invalid
            }
            if (filter.key === 'node.data.categories' ||
                filter.key.startsWith('node.data.properties.') ||
                filter.key === 'edge.data.type' ||
                filter.key.startsWith('edge.data.properties.')) {
                return {
                    key: filter.key,
                    values
                };
            }
        });
        // remove null filters, filters that were invalid
        visualization.filters = visualization.filters.filter(Utils.hasValue);
        visualization.version = 2;
        return visualization.save();
    }
}
/**
 * If the visualization is version 2, update it to version 3 and return it.
 *
 * Since visualizations v3, node and edge ids are stored exclusively as strings.
 *
 * @param {VisualizationInstance} visualization
 * @returns {Bluebird<VisualizationInstance>}
 * @private
 * @backward-compatibility
 */
function _updateVizToVersion3(visualization) {
    if (visualization.version > 2) {
        return Promise.resolve(visualization);
    }
    else {
        // originally node and edge ids in Linkurious could have been both string and numbers
        // we force them to be string now
        visualization.nodes = _.map(visualization.nodes, node => {
            node.id = '' + node.id;
            return node;
        });
        visualization.edges = _.map(visualization.edges, edge => {
            edge.id = '' + edge.id;
            return edge;
        });
        visualization.version = 3;
        return visualization.save();
    }
}
/**
 * If the visualization is version 3, update it to version 4 and return it.
 *
 * Since visualizations v4,
 * - Design Styles are stored in a different format
 * - Filters are stored in a different format
 * - Fields are removed from node.edge fields
 *
 * @param {VisualizationInstance} visualization
 * @returns {Bluebird<VisualizationInstance>}
 * @private
 * @backward-compatibility
 */
function _updateVizToVersion4(visualization) {
    if (visualization.version > 3) {
        return Promise.resolve(visualization);
    }
    return Promise.props({
        node: GraphSchemaService.getSchema(visualization.sourceKey, EntityType.NODE),
        edge: GraphSchemaService.getSchema(visualization.sourceKey, EntityType.EDGE)
    }).then(schema => {
        const designV4 = {};
        // Auto color only sandboxes
        const autoColor = visualization.sandbox;
        // 1) Migrate visualization.design.styles to the new format
        designV4.styles = DesignUtils.migrateStyles(schema, visualization.design.styles, visualization.design.palette, autoColor);
        // 2) Replace visualization.design.palette with the default palette
        designV4.palette = DesignUtils.PALETTE;
        const nodeFields = visualization.nodeFields || {};
        const edgeFields = visualization.edgeFields || {};
        // Create fields viz.(node|edge)Fields.types
        nodeFields.types = {};
        edgeFields.types = {};
        // Remove fields
        delete nodeFields.fields;
        delete edgeFields.fields;
        // design, nodeFields and edgeFields are getter and setter objects
        // so to update a property we assign the whole object that will be parsed by the setter
        visualization.design = designV4;
        visualization.nodeFields = nodeFields;
        visualization.edgeFields = edgeFields;
        visualization.filters = { node: [], edge: [] };
        visualization.version = 4;
        return visualization.save();
    });
}
/**
 * @param {number} visualizationId
 * @param {boolean} [includeUser=false] whether to fetch the owner of the viz
 * @returns {Bluebird<VisualizationInstance>}
 */
function _findViz(visualizationId, includeUser) {
    const options = { where: { id: visualizationId, sandbox: false } };
    if (includeUser) {
        options.include = [Db.models.user];
    }
    return Db.models.visualization.find(options).then(visualization => {
        if (visualization === null || visualization === undefined) {
            return Errors.business('not_found', 'Visualization #' + visualizationId + ' was not found.', true);
        }
        if (!visualization.alternativeIds) {
            visualization.alternativeIds = {};
        }
        return visualization;
    }).then(_updateViz);
}
/**
 * @param {string} sourceKey
 * @param {WrappedUser} currentUser
 * @returns {Bluebird<PublicVisualization>} sandbox
 * @private
 */
function _findSandBox(sourceKey, currentUser) {
    const source = DataProxy.resolveSource(sourceKey);
    source.assertReady();
    const where = {
        sandbox: true,
        sourceKey: sourceKey,
        userId: currentUser.id
    };
    const values = {
        title: 'SandBox',
        nodes: [],
        edges: [],
        folder: -1,
        nodeFields: { captions: source.state.defaultCaptions.nodes, types: {} },
        edgeFields: { captions: source.state.defaultCaptions.edges, types: {} },
        design: {
            palette: DesignUtils.PALETTE,
            styles: source.state.defaultStyles
        },
        filters: { node: [], edge: [] },
        version: 4
    };
    return Db.models.visualization.findOrCreate({
        where: where,
        defaults: values
    }).spread(sandbox => sandbox).then(_updateViz);
}
/**
 * Resets sandbox styles and captions to the dataSource default values.
 * Resets sandbox palette to the default value.
 *
 * @param {string} sourceKey Data-source of the sandboxes that will be reset
 * @param {object} options
 * @param {boolean} [options.design] Reset sandbox design using the defaultStyles of the data-source
 * @param {boolean} [options.captions] Reset sandbox captions using the defaultCaptions of the data-source
 * @returns {Bluebird<void>}
 */
VisualizationDAO.resetSandboxes = function (sourceKey, options) {
    Utils.checkSourceKey(sourceKey);
    const source = DataProxy.resolveSource(sourceKey);
    const allSandboxesForTheCurrentSource = { where: { sourceKey: sourceKey, sandbox: true } };
    return Promise.resolve().then(() => {
        // reset design?
        if (!options.design) {
            return;
        }
        return Db.models.visualization.update({
            design: {
                palette: DesignUtils.PALETTE,
                styles: source.state.defaultStyles
            }
        }, allSandboxesForTheCurrentSource).then(updateCount => {
            Log.info(`Design reset for ${updateCount} sandboxes (data-source: ${sourceKey}).`);
        });
    }).then(() => {
        // reset captions?
        if (!options.captions) {
            return;
        }
        return Db.models.visualization.update({
            nodeFields: { captions: source.state.defaultCaptions.nodes, types: {} },
            edgeFields: { captions: source.state.defaultCaptions.edges, types: {} }
        }, allSandboxesForTheCurrentSource).then(updateCount => {
            Log.info(`Captions reset for ${updateCount} sandboxes (data-source: ${sourceKey}).`);
        });
    });
};
/**
 * Merge node and vizNode content.
 *
 * @param {LkNode} node
 * @param {object} [vizNode] visualization node
 * @param {number} [vizNode.nodelink.x]
 * @param {number} [vizNode.nodelink.y]
 * @param {boolean} [vizNode.nodelink.fixed]
 * @param {number} [vizNode.geo.latitude]
 * @param {number} [vizNode.geo.longitude]
 * @param {number} [vizNode.geo.latitudeDiff]
 * @param {number} [vizNode.geo.longitudeDiff]
 * @param {boolean} [vizNode.selected]
 * @returns {object}
 * @private
 */
function _node2VizNode(node, vizNode) {
    // generate random position
    if (vizNode === undefined) {
        vizNode = { nodelink: { x: 500 * Math.random(), y: 500 * Math.random() } };
    }
    // migrate old-format to new-format vizNode position info
    if (vizNode.x !== undefined && vizNode.y !== undefined) {
        vizNode = { nodelink: { x: vizNode.x, y: vizNode.y } };
    }
    return {
        id: node.id,
        nodelink: vizNode.nodelink ? vizNode.nodelink : {},
        geo: vizNode && vizNode.geo ? vizNode.geo : {},
        selected: vizNode.selected === true ? true : undefined,
        data: node.data,
        categories: node.categories,
        statistics: node.statistics,
        readAt: node.readAt
    };
}
/**
 * Merge edge and vizEdge content.
 *
 * @param {LkEdge} edge
 * @param {object} [vizEdge]
 * @param {object} vizEdge.selected
 * @returns {object} edge and vizEdge merged
 * @private
 */
function _edge2VizEdge(edge, vizEdge) {
    return {
        id: edge.id,
        type: edge.type,
        data: edge.data,
        source: edge.source,
        target: edge.target,
        selected: vizEdge && vizEdge.selected ? true : undefined,
        statistics: edge.statistics,
        readAt: edge.readAt
    };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiVmlzdWFsaXphdGlvbkRBTy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9zZXJ2aWNlcy9idXNpbmVzcy9WaXN1YWxpemF0aW9uREFPLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBQ2IsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNwQyxNQUFNLGtCQUFrQixHQUFHLE9BQU8sQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFDO0FBQ3JFLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNoQyxNQUFNLEVBQUUsR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDMUIsTUFBTSxTQUFTLEdBQUcsR0FBRyxDQUFDLFlBQVksRUFBRSxDQUFDO0FBQ3JDLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sYUFBYSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUN0QyxNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxHQUFHLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUN0Qyx5QkFBeUI7QUFDekIsTUFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQ3BDLE1BQU0sb0JBQW9CLEdBQUcsT0FBTyxDQUFDLHdCQUF3QixDQUFDLENBQUM7QUFDL0QsTUFBTSxXQUFXLEdBQUcsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDO0FBQzdDLE1BQU0sa0JBQWtCLEdBQUcsR0FBRyxDQUFDLGNBQWMsRUFBRSxDQUFDO0FBQ2hELE1BQU0sRUFBQyxVQUFVLEVBQUMsR0FBRyxPQUFPLENBQUMseUJBQXlCLENBQUMsQ0FBQztBQUV4RCxTQUFTO0FBQ1QsTUFBTSxvQkFBb0IsR0FBRyxDQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDO0FBQ3BFLE1BQU0saUJBQWlCLEdBQUc7SUFDeEIsSUFBSTtJQUNKLE9BQU87SUFDUCxRQUFRO0lBQ1IsT0FBTztJQUNQLE9BQU87SUFDUCxZQUFZO0lBQ1osWUFBWTtJQUNaLFFBQVE7SUFDUixTQUFTO0lBQ1QsV0FBVztJQUNYLE1BQU07SUFDTixRQUFRO0lBQ1IsU0FBUztJQUNULFdBQVc7SUFDWCxXQUFXO0lBQ1gsZ0JBQWdCO0lBQ2hCLE1BQU07SUFDTixRQUFRO0lBQ1IsS0FBSztJQUNMLFVBQVU7Q0FDWCxDQUFDO0FBRUYsTUFBTSxhQUFhLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFDO0FBRW5FLE1BQU0sZ0JBQWdCLEdBQUcsTUFBTSxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7QUFFN0MsTUFBTSxRQUFRLEdBQUcsSUFBSSxrQkFBa0IsQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLEVBQUU7SUFDakQsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUNwQixzQkFBc0IsRUFDdEIsNENBQTRDO1FBQzVDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxHQUFHLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxLQUFLO1FBQ3JELHVEQUF1RDtRQUN2RCxvQkFBb0IsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsR0FBRywyQ0FBMkM7UUFDeEYseUNBQXlDLEdBQUcsS0FBSyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsR0FBRyxFQUNwRixJQUFJLENBQ0wsQ0FBQztBQUNKLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFDO0FBRTFCOzs7Ozs7OztHQVFHO0FBQ0gsZ0JBQWdCLENBQUMsWUFBWSxHQUFHLFVBQVMsS0FBSyxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsV0FBVztJQUM1RSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUU7UUFBRSxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7S0FBRTtJQUMzQyxLQUFLLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDckMsS0FBSyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLFNBQVMsQ0FBQyxDQUFDO0lBQzdDLEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLGFBQWEsRUFBRSxXQUFXLENBQUMsQ0FBQztJQUM5QyxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFFMUMsT0FBTyxxQkFBcUIsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLFdBQVcsRUFBRSxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1FBQzVFLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLENBQUM7WUFDMUMsS0FBSyxFQUFFLEtBQUs7WUFDWixNQUFNLEVBQUUsTUFBTSxLQUFLLElBQUksSUFBSSxNQUFNLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTTtZQUM3RCxTQUFTLEVBQUUsU0FBUztZQUNwQixNQUFNLEVBQUUsV0FBVyxDQUFDLEVBQUU7U0FDdkIsQ0FBQyxDQUFDO0lBQ0wsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDO0FBRUYsU0FBUyxtQkFBbUIsQ0FBQyxNQUFNO0lBQ2pDLE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxvQkFBb0IsQ0FBQyxDQUFDLENBQUM7QUFDL0QsQ0FBQztBQUVEOzs7Ozs7OztHQVFHO0FBQ0gsU0FBUyxXQUFXLENBQUMsUUFBUSxFQUFFLFNBQVMsRUFBRSxJQUFJO0lBQzVDLDhEQUE4RDtJQUM5RCxJQUFJLFFBQVEsS0FBSyxDQUFDLENBQUMsSUFBSSxRQUFRLEtBQUssU0FBUyxFQUFFO1FBQzdDLDBDQUEwQztRQUMxQyxPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsRUFBQyxFQUFFLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxJQUFJLENBQUMsRUFBRSxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUMsQ0FBQyxDQUFDO0tBQy9FO0lBQ0QsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQztRQUN4QyxLQUFLLEVBQUUsRUFBQyxFQUFFLEVBQUUsUUFBUSxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLElBQUksQ0FBQyxFQUFFLEVBQUM7S0FDN0QsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtRQUNmLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDWCxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQ3BCLFdBQVcsRUFDWCxXQUFXLFFBQVEsNEJBQTRCLElBQUksQ0FBQyxFQUFFLG9CQUFvQixTQUFTLElBQUksRUFDdkYsSUFBSSxDQUNMLENBQUM7U0FDSDtRQUNELE9BQU8sTUFBTSxDQUFDO0lBQ2hCLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQztBQUVEOzs7Ozs7Ozs7O0dBVUc7QUFDSCxTQUFTLHFCQUFxQixDQUFDLGNBQWMsRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFLEtBQUs7SUFDbkUsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQztRQUN4QyxLQUFLLEVBQUUsRUFBQyxNQUFNLEVBQUUsY0FBYyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLElBQUksQ0FBQyxFQUFFLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBQztLQUNyRixDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO1FBQ2YsSUFBSSxNQUFNLEVBQUU7WUFDVixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQ3hEO0lBQ0gsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDO0FBRUQ7Ozs7Ozs7Ozs7R0FVRztBQUNILGdCQUFnQixDQUFDLFlBQVksR0FBRyxVQUFTLFFBQVEsRUFBRSxPQUFPLEVBQUUsV0FBVztJQUVyRSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLEVBQUU7UUFDOUIsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLGVBQWUsRUFBRSwyQkFBMkIsRUFBRSxJQUFJLENBQUMsQ0FBQztLQUM1RTtJQUVELEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQztJQUN2QyxLQUFLLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsT0FBTyxFQUFFO1FBQ3pDLEtBQUssRUFBRSxFQUFDLEtBQUssRUFBRSxDQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBQztRQUMvQyxNQUFNLEVBQUUsRUFBQyxLQUFLLEVBQUUsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBQztLQUNqQyxDQUFDLENBQUM7SUFFSCx1RUFBdUU7SUFDdkUsNEVBQTRFO0lBRTVFLGNBQWM7SUFDZCxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtRQUNwRSxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQ1gsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxVQUFVLEdBQUcsUUFBUSxHQUFHLGlCQUFpQixFQUFFLElBQUksQ0FBQyxDQUFDO1NBQ3RGO1FBQ0QsV0FBVyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUVuQyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLE9BQU8sQ0FBQyxNQUFNLEtBQUssTUFBTSxDQUFDLE1BQU0sRUFBRTtZQUN0RSxNQUFNLFFBQVEsR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDO1lBQ2hDLHNFQUFzRTtZQUN0RSxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFNUMsaURBQWlEO1lBQ2pELE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBRWpDLDZDQUE2QztnQkFDN0MsSUFBSSxRQUFRLEtBQUssQ0FBQyxDQUFDLEVBQUU7b0JBQ25CLE9BQU8sRUFBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBQyxDQUFDO2lCQUNoQztnQkFFRCx3QkFBd0I7Z0JBQ3hCLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLENBQUMsRUFBQyxLQUFLLEVBQUU7d0JBQ25ELFNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUzt3QkFDM0IsTUFBTSxFQUFFLFdBQVcsQ0FBQyxFQUFFO3FCQUN2QixFQUFFLFVBQVUsRUFBRSxDQUFDLElBQUksRUFBRSxRQUFRLEVBQUUsT0FBTyxDQUFDLEVBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRTtvQkFDeEQsT0FBTyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztvQkFDcEMsK0NBQStDO29CQUMvQyxNQUFNLFdBQVcsR0FBRyxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUM7b0JBRXJFLGdDQUFnQztvQkFDaEMsTUFBTSxTQUFTLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDLENBQUM7b0JBQ2pELElBQUksQ0FBQyxTQUFTLEVBQUU7d0JBQ2QsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxVQUFVLEdBQUcsUUFBUSxHQUFHLGlCQUFpQixFQUFFLElBQUksQ0FBQyxDQUFDO3FCQUN0RjtvQkFFRCxpREFBaUQ7b0JBQ2pELElBQUksaUJBQWlCLEdBQUcsU0FBUyxDQUFDO29CQUNsQyxPQUFPLGlCQUFpQixJQUFJLGlCQUFpQixDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsRUFBRTt3QkFDdkQsSUFBSSxpQkFBaUIsQ0FBQyxFQUFFLEtBQUssTUFBTSxDQUFDLEVBQUUsRUFBRTs0QkFDdEMsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUNwQixtQkFBbUIsRUFBRSw0Q0FBNEMsRUFBRSxJQUFJLENBQ3hFLENBQUM7eUJBQ0g7d0JBQ0QsaUJBQWlCLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLEdBQUcsRUFBRSxDQUFDLENBQUM7cUJBQ3BFO29CQUVELE9BQU8sU0FBUyxDQUFDO2dCQUNuQixDQUFDLENBQUMsQ0FBQztZQUNMLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRTtnQkFFbEIsd0RBQXdEO2dCQUN4RCxPQUFPLHFCQUFxQixDQUMxQixTQUFTLENBQUMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxTQUFTLEVBQUUsV0FBVyxFQUFFLE1BQU0sQ0FBQyxLQUFLLENBQzFELENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ3RCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRTtnQkFDbEIsTUFBTSxDQUFDLE1BQU0sR0FBRyxTQUFTLENBQUMsRUFBRSxDQUFDO2dCQUM3QixPQUFPLE1BQU0sQ0FBQztZQUNoQixDQUFDLENBQUMsQ0FBQztTQUNKO2FBQU0sSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxPQUFPLENBQUMsS0FBSyxLQUFLLE1BQU0sQ0FBQyxLQUFLLEVBQUU7WUFDMUUsTUFBTSxRQUFRLEdBQUcsT0FBTyxDQUFDLEtBQUssQ0FBQztZQUMvQixzRUFBc0U7WUFDdEUsT0FBTyxxQkFBcUIsQ0FDMUIsTUFBTSxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsU0FBUyxFQUFFLFdBQVcsRUFBRSxRQUFRLENBQ3ZELENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDVixNQUFNLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQztnQkFDeEIsT0FBTyxNQUFNLENBQUM7WUFDaEIsQ0FBQyxDQUFDLENBQUM7U0FDSjtRQUVELE9BQU8sTUFBTSxDQUFDO0lBQ2hCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRTtRQUN0QiwrQkFBK0I7UUFDL0IsT0FBTyxhQUFhLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLENBQUM7SUFDeEQsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUM7QUFFRjs7OztHQUlHO0FBQ0gsZ0JBQWdCLENBQUMsWUFBWSxHQUFHLFVBQVMsUUFBUSxFQUFFLFdBQVc7SUFFNUQsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7UUFDcEUsSUFBSSxNQUFNLEtBQUssSUFBSSxFQUFFO1lBQ25CLE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsVUFBVSxHQUFHLFFBQVEsR0FBRyxpQkFBaUIsQ0FBQyxDQUFDO1NBQy9FO1FBQ0QsV0FBVyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUVuQyxtRUFBbUU7UUFDbkUsT0FBTyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLENBQUMsRUFBQyxLQUFLLEVBQUUsRUFBQyxNQUFNLEVBQUUsUUFBUSxFQUFDLEVBQUMsQ0FBQztZQUNwRixFQUFFLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsRUFBQyxLQUFLLEVBQUUsRUFBQyxNQUFNLEVBQUUsUUFBUSxFQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLFFBQVEsQ0FBQzthQUM3RSxJQUFJLENBQUMsQ0FBQyxDQUFDLGVBQWUsRUFBRSxzQkFBc0IsQ0FBQyxFQUFFLEVBQUU7WUFFbEQsSUFBSSxlQUFlLElBQUksc0JBQXNCLEVBQUU7Z0JBQzdDLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyx3QkFBd0IsRUFBRSxnQkFBZ0I7b0JBQy9ELHlEQUF5RDtvQkFDekQsNkJBQTZCLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFFeEM7aUJBQU07Z0JBQ0wsT0FBTyxNQUFNLENBQUMsT0FBTyxFQUFFLENBQUM7YUFDekI7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUMsQ0FBQyxDQUFDO0FBRUwsQ0FBQyxDQUFDO0FBRUY7Ozs7Ozs7R0FPRztBQUNILGdCQUFnQixDQUFDLE9BQU8sR0FBRyxVQUFTLFNBQVMsRUFBRSxXQUFXO0lBQ3hELHVFQUF1RTtJQUN2RSxpRkFBaUY7SUFDakYsTUFBTSxnQkFBZ0IsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUM7SUFDeEQsSUFBSSxpQkFBaUIsQ0FBQztJQUN0QixJQUFJLENBQUMsZ0JBQWdCLEVBQUU7UUFDckIsaUJBQWlCLEdBQUc7WUFDbEIsTUFBTSxFQUFFLEVBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBQztTQUM1QyxDQUFDO0tBQ0g7SUFFRCxPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDO1FBQ3JELEtBQUssRUFBRSxFQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLFdBQVcsQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBQztRQUNyRSxVQUFVLEVBQUUsQ0FBQyxJQUFJLEVBQUUsUUFBUSxFQUFFLE9BQU8sRUFBRSxXQUFXLEVBQUUsV0FBVyxDQUFDO1FBQy9ELE9BQU8sRUFBRSxDQUFDO2dCQUNSLEtBQUssRUFBRSxFQUFFLENBQUMsTUFBTSxDQUFDLGtCQUFrQjtnQkFDbkMsUUFBUSxFQUFFLEtBQUs7Z0JBQ2YsS0FBSyxFQUFFLGlCQUFpQjthQUN6QixDQUFDO0tBQ0gsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxFQUFFO1FBQ3RCLHFDQUFxQztRQUNyQyxhQUFhLEdBQUcsYUFBYSxDQUFDLEdBQUcsRUFBRSxDQUFDO1FBQ3BDLGFBQWEsQ0FBQyxVQUFVLEdBQUcsYUFBYSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sQ0FBQztRQUNwRSxPQUFPLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQztRQUN6QyxPQUFPLGFBQWEsQ0FBQztJQUN2QixDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQztBQUVGOzs7Ozs7O0dBT0c7QUFDSCxTQUFTLFNBQVMsQ0FBQyxRQUFRLEVBQUUsT0FBTyxFQUFFLGNBQWMsRUFBRSxZQUFZO0lBQ2hFLE1BQU0sT0FBTyxHQUFHLEVBQUUsQ0FBQztJQUVuQixVQUFVO0lBQ1YsT0FBTyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRTtRQUN2QixJQUFJLE1BQU0sQ0FBQyxNQUFNLEtBQUssUUFBUSxFQUFFO1lBQzlCLE1BQU0sUUFBUSxHQUFHLFNBQVMsQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLE9BQU8sRUFBRSxjQUFjLEVBQUUsWUFBWSxDQUFDLENBQUM7WUFDN0UsTUFBTSxTQUFTLEdBQUc7Z0JBQ2hCLEVBQUUsRUFBRSxNQUFNLENBQUMsRUFBRTtnQkFDYixJQUFJLEVBQUUsUUFBUTtnQkFDZCxLQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7YUFDcEIsQ0FBQztZQUVGLElBQUksUUFBUSxFQUFFO2dCQUNaLFNBQVMsQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDO2FBQy9CO1lBQ0QsT0FBTyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztTQUN6QjtJQUNILENBQUMsQ0FBQyxDQUFDO0lBRUgsUUFBUTtJQUNSLElBQUksTUFBTSxDQUFDO0lBQ1gsY0FBYyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRTtRQUM1QixJQUFJLElBQUksQ0FBQyxNQUFNLEtBQUssUUFBUSxFQUFFO1lBQzVCLE1BQU0sR0FBRyxZQUFZLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQy9CLE9BQU8sQ0FBQyxJQUFJLENBQUM7Z0JBQ1gsRUFBRSxFQUFFLElBQUksQ0FBQyxFQUFFO2dCQUNYLElBQUksRUFBRSxNQUFNO2dCQUNaLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSztnQkFDakIsVUFBVSxFQUFFLElBQUksQ0FBQyxVQUFVO2dCQUMzQixTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7Z0JBQ3pCLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztnQkFDekIsU0FBUyxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTTthQUN4QyxDQUFDLENBQUM7U0FDSjtJQUNILENBQUMsQ0FBQyxDQUFDO0lBRUgsT0FBTyxPQUFPLENBQUM7QUFDakIsQ0FBQztBQUVEOzs7Ozs7O0dBT0c7QUFDSCxnQkFBZ0IsQ0FBQyxPQUFPLEdBQUcsVUFBUyxTQUFTLEVBQUUsV0FBVztJQUN4RCxNQUFNLE1BQU0sR0FBRyxXQUFXLENBQUMsRUFBRSxDQUFDO0lBQzlCLE9BQU8sT0FBTyxDQUFDLElBQUksQ0FDakIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsV0FBVyxDQUFDLEVBQ3BDLEVBQUUsQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsT0FBTyxDQUFDLEVBQUMsS0FBSyxFQUFFLEVBQUMsU0FBUyxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFDLEVBQUMsQ0FBQyxFQUN0RixFQUFFLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsRUFBQyxLQUFLLEVBQUUsRUFBQyxNQUFNLEVBQUUsTUFBTSxFQUFDLEVBQUUsVUFBVSxFQUFFLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLEVBQUMsQ0FBQyxFQUMzRixDQUFDLGNBQWMsRUFBRSxPQUFPLEVBQUUsT0FBTyxFQUFFLEVBQUU7UUFDbkMsTUFBTSxZQUFZLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztRQUN6RCxPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFLE9BQU8sRUFBRSxjQUFjLEVBQUUsWUFBWSxDQUFDLENBQUMsQ0FBQztJQUMvRSxDQUFDLENBQ0YsQ0FBQztBQUNKLENBQUMsQ0FBQztBQUVGOzs7O0dBSUc7QUFDSCxnQkFBZ0IsQ0FBQyxhQUFhLEdBQUcsVUFBUyxHQUFHO0lBQzNDLHlDQUF5QztJQUN6QyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsWUFBWSxFQUFFLFlBQVksQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFO1FBQzVDLElBQUksUUFBUSxHQUFHLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUN4QixJQUFJLENBQUMsUUFBUSxFQUFFO1lBQUUsUUFBUSxHQUFHLEVBQUUsQ0FBQztTQUFFO1FBQ2pDLG1CQUFtQjtRQUNuQixJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUFFLE9BQU87U0FBRTtRQUN6QyxVQUFVO1FBQ1YsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUMsTUFBTSxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsRUFBRSxFQUFDLENBQUM7SUFDOUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUM7QUFFRjs7Ozs7Ozs7OztHQVVHO0FBQ0gsZ0JBQWdCLENBQUMsT0FBTyxHQUFHLFVBQVMsS0FBSyxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsT0FBTztJQUNqRSxJQUFJLENBQUMsT0FBTyxFQUFFO1FBQUUsT0FBTyxHQUFHLEVBQUUsQ0FBQztLQUFFO0lBRS9CLE9BQU8sUUFBUSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUU7UUFFdEMsOERBQThEO1FBQzlELFNBQVMsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBRXJELE9BQU8sSUFBSSxDQUFDLHFCQUFxQixDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUNsRCxvRkFBb0Y7WUFDcEYsR0FBRyxHQUFHLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQzVCLEdBQUcsQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO1lBRWxCLHlDQUF5QztZQUN6QyxnQkFBZ0IsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLENBQUM7WUFFcEMsSUFBSSxDQUFDLFNBQVMsRUFBRTtnQkFDZCxPQUFPLEdBQUcsQ0FBQzthQUNaO1lBRUQsb0VBQW9FO1lBQ3BFLE1BQU0sVUFBVSxHQUFHLEdBQUcsQ0FBQyxjQUFjLENBQUMsSUFBSSxLQUFLLFNBQVM7Z0JBQ3RELENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDN0MsTUFBTSxVQUFVLEdBQUcsR0FBRyxDQUFDLGNBQWMsQ0FBQyxJQUFJLEtBQUssU0FBUztnQkFDdEQsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUU3Qyx3QkFBd0I7WUFDeEIsT0FBTyxTQUFTLENBQUMsb0JBQW9CLENBQUM7Z0JBQ3BDLE9BQU8sRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDO2dCQUMvQixPQUFPLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQztnQkFDL0IsU0FBUyxFQUFFLEdBQUcsQ0FBQyxTQUFTO2dCQUN4QixpQkFBaUIsRUFBRSxHQUFHLENBQUMsY0FBYyxDQUFDLElBQUk7Z0JBQzFDLGlCQUFpQixFQUFFLEdBQUcsQ0FBQyxjQUFjLENBQUMsSUFBSTtnQkFDMUMsYUFBYSxFQUFFLElBQUk7Z0JBQ25CLFVBQVUsRUFBRSxPQUFPLENBQUMsVUFBVTtnQkFDOUIsVUFBVSxFQUFFLE9BQU8sQ0FBQyxVQUFVO2FBQy9CLEVBQUUsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO2dCQUN2QixJQUFJLFFBQVEsQ0FBQyxVQUFVLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxLQUFLLE9BQU8sSUFBSSxHQUFHLENBQUMsS0FBSyxLQUFLLE9BQU8sQ0FBQyxFQUFFO29CQUMzRSxHQUFHLENBQUMsS0FBSyxJQUFJLFdBQVcsQ0FBQztpQkFDMUI7Z0JBRUQsTUFBTSxZQUFZLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUU5QywwRUFBMEU7Z0JBQzFFLGdEQUFnRDtnQkFDaEQsR0FBRyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsR0FBRyxDQUNmLFFBQVEsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUNyQixHQUFHLENBQUMsRUFBRSxDQUFDLGFBQWEsQ0FBQyxHQUFHLEVBQUUsWUFBWSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FDaEUsQ0FBQztnQkFFRix3RkFBd0Y7Z0JBQ3hGLDRGQUE0RjtnQkFDNUYsTUFBTSxXQUFXLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUU3QyxNQUFNLEtBQUssR0FBRyxDQUFDLENBQUMsTUFBTSxDQUNwQixRQUFRLENBQUMsTUFBTSxDQUFDLEtBQUs7Z0JBQ3JCLCtEQUErRDtnQkFDL0QsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSTtvQkFDWixXQUFXLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLFNBQVM7b0JBQ3RDLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssU0FBUyxDQUN6QyxDQUFDO2dCQUVGLE1BQU0sWUFBWSxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDOUMsR0FBRyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLGFBQWEsQ0FBQyxHQUFHLEVBQUUsWUFBWSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUUxRixPQUFPLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQy9CLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUU7UUFDWixxQkFBcUI7UUFDckIsT0FBTyxhQUFhLENBQUMsK0JBQStCLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUN0RSxHQUFHLENBQUMsU0FBUyxHQUFHLEdBQUcsSUFBSSxJQUFJLENBQUM7WUFDNUIsT0FBTyxHQUFHLENBQUM7UUFDYixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDO0FBRUY7Ozs7Ozs7OztHQVNHO0FBQ0gsS0FBSyxVQUFVLGdCQUFnQixDQUFDLEdBQUc7SUFFakMsTUFBTSxVQUFVLEdBQUcsTUFBTSxrQkFBa0IsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDdEYsTUFBTSxVQUFVLEdBQUcsTUFBTSxrQkFBa0IsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7SUFFdEYsZ0JBQWdCO0lBQ2hCLEdBQUcsQ0FBQyxPQUFPLENBQUMsSUFBSSxHQUFHLGFBQWEsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsVUFBVSxDQUFDLEtBQUssRUFBRSxVQUFVLENBQUMsQ0FBQztJQUNyRixHQUFHLENBQUMsT0FBTyxDQUFDLElBQUksR0FBRyxhQUFhLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDLFVBQVUsQ0FBQyxLQUFLLEVBQUUsVUFBVSxDQUFDLENBQUM7SUFFckYscUJBQXFCO0lBQ3JCLEdBQUcsQ0FBQyxRQUFRLENBQUMsSUFBSSxHQUFHLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLFVBQVUsQ0FBQyxDQUFDO0lBQ3JFLEdBQUcsQ0FBQyxRQUFRLENBQUMsSUFBSSxHQUFHLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLFVBQVUsQ0FBQyxDQUFDO0lBRXJFLHFGQUFxRjtJQUNyRixJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLEtBQUssQ0FBQyxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1FBQzlGLEdBQUcsQ0FBQyxRQUFRLEdBQUcsRUFBQyxJQUFJLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUMsQ0FBQztLQUNyQztJQUVELE9BQU8sR0FBRyxDQUFDO0FBQ2IsQ0FBQztBQUVEOzs7Ozs7Ozs7R0FTRztBQUNILFNBQVMsaUJBQWlCLENBQUMsV0FBVyxFQUFFLE1BQU07SUFDNUMsTUFBTSxjQUFjLEdBQUcsRUFBRSxDQUFDO0lBQzFCLEtBQUssTUFBTSxRQUFRLElBQUksV0FBVyxFQUFFO1FBQ2xDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ3pCLFNBQVM7U0FDVjtRQUVELE1BQU0sUUFBUSxHQUFHLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUV2QyxNQUFNLFdBQVcsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsV0FBVyxLQUFLLFFBQVEsQ0FBQyxDQUFDO1FBQ2hHLElBQUksV0FBVyxLQUFLLFNBQVMsRUFBRTtZQUM3QixTQUFTO1NBQ1Y7UUFDRCxNQUFNLEVBQUMsSUFBSSxFQUFDLEdBQUcsV0FBVyxDQUFDLFlBQVksQ0FBQztRQUV4QyxJQUFJLElBQUksS0FBSyxNQUFNLElBQUksSUFBSSxLQUFLLFVBQVUsRUFBRTtZQUMxQyxjQUFjLENBQUMsUUFBUSxDQUFDLEdBQUcsUUFBUSxDQUFDO1NBQ3JDO0tBQ0Y7SUFDRCxPQUFPLGNBQWMsQ0FBQztBQUN4QixDQUFDO0FBRUQ7Ozs7Ozs7O0dBUUc7QUFDSCxTQUFTLGFBQWEsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLE1BQU07SUFDNUMsT0FBTyxPQUFPLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFO1FBRTdCLE1BQU0sUUFBUSxHQUFHLE1BQU0sQ0FBQyxRQUFRLENBQUM7UUFDakMsTUFBTSxXQUFXLEdBQUcsTUFBTSxDQUFDLEtBQUssSUFBSSxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3BELE1BQU0sS0FBSyxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUM7UUFFM0IsSUFBSSxrQkFBa0IsR0FBRyxNQUFNLENBQUM7UUFDaEMsSUFBSSxxQkFBcUIsQ0FBQztRQUMxQixJQUFJLE1BQU0sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDeEIsTUFBTSxXQUFXLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUN0RCxJQUFJLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxXQUFXLEtBQUssV0FBVyxDQUN6QyxDQUFDO1lBRUYsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxFQUFFO2dCQUMvQixrQkFBa0IsR0FBRyxXQUFXLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQztnQkFDbkQscUJBQXFCLEdBQUcsV0FBVyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUM7YUFDMUQ7U0FDRjtRQUVELE1BQU0sVUFBVSxHQUFHLGtCQUFrQixDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQztRQUV0RCxRQUFRLFVBQVUsRUFBRTtZQUNsQixLQUFLLGFBQWEsQ0FBQyxDQUFDO2dCQUNsQixPQUFPLGtCQUFrQixLQUFLLFFBQVEsSUFBSSxrQkFBa0IsS0FBSyxNQUFNLENBQUM7YUFDekU7WUFDRCxLQUFLLGdCQUFnQixDQUFDLENBQUM7Z0JBQ3JCLElBQUksa0JBQWtCLEtBQUssUUFBUSxFQUFFO29CQUNuQyxPQUFPLEtBQUssQ0FBQztpQkFDZDtxQkFBTSxJQUFJLHFCQUFxQixJQUFJLHFCQUFxQixDQUFDLE1BQU0sRUFBRTtvQkFDaEUsZ0ZBQWdGO29CQUNoRixPQUFPLHFCQUFxQixDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7aUJBQ3JEO2dCQUNELE9BQU8sSUFBSSxDQUFDO2FBQ2I7WUFDRCxLQUFLLGFBQWEsQ0FBQyxDQUFDO2dCQUNsQixPQUFPLGtCQUFrQixLQUFLLFFBQVEsSUFBSSxrQkFBa0IsS0FBSyxNQUFNLENBQUM7YUFDekU7WUFDRCxLQUFLLFFBQVEsQ0FBQyxDQUFDO2dCQUNiLE9BQU8sa0JBQWtCLEtBQUssUUFBUSxDQUFDO2FBQ3hDO1lBQ0QsS0FBSyxTQUFTLENBQUMsQ0FBQztnQkFDZCxPQUFPLGtCQUFrQixLQUFLLFNBQVMsQ0FBQzthQUN6QztZQUNELEtBQUssaUJBQWlCO2dCQUNwQixPQUFPLEtBQUssQ0FBQztZQUNmLEtBQUssZ0JBQWdCO2dCQUNuQixHQUFHLENBQUMsSUFBSSxDQUFDLGtEQUFrRCxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztnQkFDckYsT0FBTyxJQUFJLENBQUM7WUFDZCxLQUFLLEtBQUssQ0FBQztZQUNYLEtBQUssU0FBUyxDQUFDO1lBQ2YsT0FBTyxDQUFDLENBQUM7Z0JBQ1AsT0FBTyxJQUFJLENBQUM7YUFDYjtTQUNGO0lBQ0gsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDO0FBRUQ7Ozs7O0dBS0c7QUFDSCxTQUFTLGtCQUFrQixDQUFDLE1BQU0sRUFBRSxNQUFNO0lBQ3hDLE1BQU0sVUFBVSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUM7SUFDL0IsTUFBTSxLQUFLLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQztJQUUzQixJQUFJLFVBQVUsS0FBSyxLQUFLLEVBQUU7UUFDeEIsT0FBTyxLQUFLLENBQUM7S0FDZDtJQUVELE1BQU0sUUFBUSxHQUFHLE1BQU0sQ0FBQyxRQUFRLENBQUM7SUFFakMsSUFDRSxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQztRQUN2QixLQUFLLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7UUFDM0IsS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzlCLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssWUFBWSxFQUNoQztRQUNBLE9BQU8sZ0JBQWdCLENBQUM7S0FDekI7SUFFRCxNQUFNLFdBQVcsR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBRXBDLE1BQU0sU0FBUyxHQUNiLE1BQU07UUFDTixNQUFNLENBQUMsUUFBUSxDQUFDO1FBQ2hCLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxXQUFXLENBQUM7UUFDN0IsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQztJQUVyQyxJQUFJLFVBQVUsS0FBSyxTQUFTLEVBQUU7UUFDNUIsT0FBTyxTQUFTLENBQUM7S0FDbEI7SUFFRCx1REFBdUQ7SUFDdkQsSUFBSSxVQUFVLEtBQUssSUFBSSxJQUFJLFNBQVMsS0FBSyxRQUFRLEVBQUU7UUFDakQsT0FBTyxhQUFhLENBQUM7S0FDdEI7SUFFRCx1REFBdUQ7SUFDdkQsSUFBSSxDQUFDLEtBQUssRUFBRSxPQUFPLENBQUMsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLElBQUksU0FBUyxLQUFLLFFBQVEsRUFBRTtRQUNuRSxPQUFPLGFBQWEsQ0FBQztLQUN0QjtJQUVELGlFQUFpRTtJQUNqRSxJQUFJLFVBQVUsS0FBSyxJQUFJLElBQUksT0FBTyxLQUFLLEtBQUssUUFBUSxJQUFJLENBQUMsU0FBUyxFQUFFO1FBQ2xFLE9BQU8sZ0JBQWdCLENBQUM7S0FDekI7SUFFRCwyREFBMkQ7SUFDM0QsSUFBSSxVQUFVLEtBQUssSUFBSSxJQUFJLE9BQU8sS0FBSyxLQUFLLFNBQVMsSUFBSSxDQUFDLFNBQVMsRUFBRTtRQUNuRSxPQUFPLFNBQVMsQ0FBQztLQUNsQjtJQUVELHlEQUF5RDtJQUN6RCxJQUFJLENBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRTtRQUN2RCxPQUFPLFFBQVEsQ0FBQztLQUNqQjtJQUVELDRCQUE0QjtJQUM1QixJQUFJLFNBQVMsS0FBSyxnQkFBZ0IsRUFBRTtRQUNsQyxPQUFPLGlCQUFpQixDQUFDO0tBQzFCO0lBRUQsT0FBTyxnQkFBZ0IsQ0FBQztBQUMxQixDQUFDO0FBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBaUJHO0FBQ0gsZ0JBQWdCLENBQUMsVUFBVSxHQUFHLFVBQVMsT0FBTyxFQUFFLElBQUk7SUFDbEQsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDO0lBQzFCLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7UUFDakMsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQ2hCLFVBQVUsRUFDVixPQUFPLENBQUMsUUFBUSxFQUNoQjtZQUNFLFNBQVM7WUFDVCxpQkFBaUI7WUFDakIsY0FBYyxFQUFFLFFBQVEsRUFBRSxRQUFRO1lBQ2xDLGFBQWEsRUFBRSxhQUFhO1lBQzVCLFNBQVM7WUFDVCxTQUFTO1NBQ1YsQ0FDRixDQUFDO1FBQ0YsUUFBUSxPQUFPLENBQUMsUUFBUSxFQUFFO1lBQ3hCLEtBQUssaUJBQWlCLENBQUM7WUFDdkIsS0FBSyxjQUFjLENBQUM7WUFDcEIsS0FBSyxRQUFRLENBQUM7WUFDZCxLQUFLLFFBQVE7Z0JBQ1gsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxFQUFFLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDNUMsTUFBTTtZQUVSLEtBQUssU0FBUztnQkFDWixLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUMvQyxNQUFNO1lBRVIsS0FBSyxZQUFZLENBQUM7WUFDbEIsS0FBSyxZQUFZO2dCQUNmLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLGFBQWEsRUFBRSxPQUFPLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUM3RCxJQUFJLE9BQU8sQ0FBQyxlQUFlLEtBQUssU0FBUyxFQUFFO29CQUN6QyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsRUFBRSxPQUFPLENBQUMsZUFBZSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztpQkFDdEU7Z0JBQ0QsTUFBTTtZQUVSLEtBQUssU0FBUztnQkFDWixLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUUsT0FBTyxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDL0QsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsT0FBTyxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDbkUsTUFBTTtTQUNUO1FBQ0QsT0FBTyxZQUFZLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUMvQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUU7UUFDaEIsT0FBTyxHQUFHLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3BDLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFO1lBQUUsT0FBTyxPQUFPLENBQUM7U0FBRTtRQUMxQyxPQUFPLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQztRQUNuQixPQUFPLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQztRQUVuQiwyQkFBMkI7UUFFM0IsSUFBSSxPQUFPLENBQUMsUUFBUSxLQUFLLGlCQUFpQixFQUFFO1lBQzFDLDJCQUEyQjtZQUMzQixPQUFPLElBQUksQ0FBQyxPQUFPLENBQ2pCLE9BQU8sQ0FBQyxNQUFNLEVBQ2QsSUFBSSxFQUNKLElBQUksRUFDSjtnQkFDRSxVQUFVLEVBQUUsT0FBTyxDQUFDLFVBQVU7Z0JBQzlCLFVBQVUsRUFBRSxPQUFPLENBQUMsVUFBVTthQUMvQixDQUNGLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFO2dCQUNyQixPQUFPLENBQUMsS0FBSyxHQUFHLGFBQWEsQ0FBQyxLQUFLLENBQUM7Z0JBQ3BDLE9BQU8sQ0FBQyxLQUFLLEdBQUcsYUFBYSxDQUFDLEtBQUssQ0FBQztnQkFDcEMsT0FBTyxDQUFDLE1BQU0sR0FBRyxhQUFhLENBQUMsTUFBTSxDQUFDO2dCQUN0QyxPQUFPLENBQUMsVUFBVSxHQUFHLGFBQWEsQ0FBQyxVQUFVLENBQUM7Z0JBQzlDLE9BQU8sQ0FBQyxVQUFVLEdBQUcsYUFBYSxDQUFDLFVBQVUsQ0FBQztnQkFDOUMsT0FBTyxDQUFDLEtBQUssR0FBRyxhQUFhLENBQUMsS0FBSyxDQUFDO2dCQUNwQyxPQUFPLENBQUMsT0FBTyxHQUFHLGFBQWEsQ0FBQyxPQUFPLENBQUM7Z0JBRXhDLE9BQU8sT0FBTyxDQUFDO1lBQ2pCLENBQUMsQ0FBQyxDQUFDO1NBQ0o7YUFBTSxJQUFJLE9BQU8sQ0FBQyxRQUFRLEtBQUssUUFBUSxFQUFFO1lBQ3hDLGtCQUFrQjtZQUNsQixPQUFPLFNBQVMsQ0FBQyxPQUFPLENBQUM7Z0JBQ3ZCLEVBQUUsRUFBRSxPQUFPLENBQUMsTUFBTTtnQkFDbEIsVUFBVSxFQUFFLE9BQU8sQ0FBQyxVQUFVO2dCQUM5QixVQUFVLEVBQUUsT0FBTyxDQUFDLFVBQVU7Z0JBQzlCLFNBQVMsRUFBRSxPQUFPLENBQUMsU0FBUzthQUM3QixFQUFFLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtnQkFDL0IsT0FBTyxDQUFDLEtBQUssR0FBRyxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNqRSxPQUFPLE9BQU8sQ0FBQztZQUNqQixDQUFDLENBQUMsQ0FBQztTQUVKO2FBQU0sSUFBSSxPQUFPLENBQUMsUUFBUSxLQUFLLFFBQVEsRUFBRTtZQUN4QyxnQkFBZ0I7WUFDaEIsTUFBTSxjQUFjLEdBQUc7Z0JBQ3JCLEVBQUUsRUFBRSxPQUFPLENBQUMsTUFBTTtnQkFDbEIsU0FBUyxFQUFFLE9BQU8sQ0FBQyxTQUFTO2dCQUM1QixVQUFVLEVBQUUsT0FBTyxDQUFDLFVBQVU7Z0JBQzlCLFVBQVUsRUFBRSxPQUFPLENBQUMsVUFBVTthQUMvQixDQUFDO1lBQ0YsT0FBTyxTQUFTLENBQUMsT0FBTyxDQUFDLGNBQWMsRUFBRSxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7Z0JBRXJFLE9BQU8sQ0FBQyxLQUFLLEdBQUcsUUFBUSxDQUFDLEtBQUssQ0FBQztnQkFDL0IsT0FBTyxDQUFDLEtBQUssR0FBRztvQkFDZCxhQUFhLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBQyxDQUFDO29CQUM5QyxhQUFhLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFDLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFDLENBQUM7aUJBQ2pELENBQUM7Z0JBQ0YsT0FBTyxPQUFPLENBQUM7WUFDakIsQ0FBQyxDQUFDLENBQUM7U0FFSjthQUFNLElBQUksT0FBTyxDQUFDLFFBQVEsS0FBSyxjQUFjLEVBQUU7WUFDOUMsT0FBTyxTQUFTLENBQUMsT0FBTyxDQUFDO2dCQUN2QixFQUFFLEVBQUUsT0FBTyxDQUFDLE1BQU07Z0JBQ2xCLFVBQVUsRUFBRSxPQUFPLENBQUMsVUFBVTtnQkFDOUIsVUFBVSxFQUFFLE9BQU8sQ0FBQyxVQUFVO2dCQUM5QixTQUFTLEVBQUUsT0FBTyxDQUFDLFNBQVM7YUFDN0IsRUFBRSxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7Z0JBRS9CLE1BQU0sVUFBVSxHQUFHLGFBQWEsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBRXBELE9BQU8sU0FBUyxDQUFDLGdCQUFnQixDQUMvQixDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRTtvQkFDaEIsS0FBSyxFQUFFLGFBQWE7b0JBQ3BCLFVBQVUsRUFBRSxPQUFPLENBQUMsVUFBVTtvQkFDOUIsVUFBVSxFQUFFLE9BQU8sQ0FBQyxVQUFVO2lCQUMvQixFQUNELE9BQU8sQ0FBQyxTQUFTLEVBQ2pCLFlBQVksQ0FDYixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtvQkFDaEIsT0FBTyxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDO29CQUMvQixPQUFPLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsRUFBRSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO29CQUNuRSxPQUFPLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztvQkFFbEMsT0FBTyxPQUFPLENBQUM7Z0JBQ2pCLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUM7U0FFSjthQUFNLElBQUksT0FBTyxDQUFDLFFBQVEsS0FBSyxhQUFhLElBQUksT0FBTyxDQUFDLFFBQVEsS0FBSyxhQUFhLEVBQUU7WUFDbkYsMEJBQTBCO1lBQzFCLE9BQU8sU0FBUyxDQUFDLFVBQVUsQ0FDekI7Z0JBQ0UsSUFBSSxFQUFFLE9BQU8sQ0FBQyxRQUFRLEtBQUssYUFBYSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU07Z0JBQzFELENBQUMsRUFBRSxPQUFPLENBQUMsV0FBVztnQkFDdEIsU0FBUyxFQUFFLE9BQU8sQ0FBQyxlQUFlO2dCQUNsQyxJQUFJLEVBQUUsYUFBYTtnQkFDbkIsU0FBUyxFQUFFLE9BQU8sQ0FBQyxTQUFTO2dCQUM1QixVQUFVLEVBQUUsT0FBTyxDQUFDLFVBQVU7Z0JBQzlCLFVBQVUsRUFBRSxPQUFPLENBQUMsVUFBVTthQUMvQixFQUNELFlBQVksQ0FDYixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtnQkFDaEIsT0FBTyxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDO2dCQUMvQixPQUFPLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsRUFBRSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUNuRSxPQUFPLE9BQU8sQ0FBQztZQUNqQixDQUFDLENBQUMsQ0FBQztTQUVKO2FBQU0sSUFBSSxPQUFPLENBQUMsUUFBUSxLQUFLLFNBQVMsRUFBRTtZQUN6QywyREFBMkQ7WUFDM0QsT0FBTyxTQUFTLENBQUMsc0JBQXNCLENBQUM7Z0JBQ3RDLFNBQVMsRUFBRSxPQUFPLENBQUMsU0FBUztnQkFDNUIsT0FBTyxFQUFFLE9BQU8sQ0FBQyxjQUFjO2dCQUMvQixLQUFLLEVBQUUsT0FBTyxDQUFDLFlBQVk7Z0JBQzNCLFVBQVUsRUFBRSxPQUFPLENBQUMsVUFBVTtnQkFDOUIsVUFBVSxFQUFFLE9BQU8sQ0FBQyxVQUFVO2FBQy9CLEVBQUUsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO2dCQUMvQixPQUFPLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUM7Z0JBQy9CLE9BQU8sQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBQ25FLE9BQU8sT0FBTyxDQUFDO1lBQ2pCLENBQUMsQ0FBQyxDQUFDO1NBQ0o7YUFBTSxJQUFJLE9BQU8sQ0FBQyxRQUFRLEtBQUssU0FBUyxFQUFFO1lBQ3pDLE9BQU8sWUFBWSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDL0QsTUFBTSxXQUFXLEdBQUc7b0JBQ2xCLEdBQUcsRUFBRSxLQUFLLENBQUMsS0FBSztvQkFDaEIsU0FBUyxFQUFFLE9BQU8sQ0FBQyxTQUFTO29CQUM1QixVQUFVLEVBQUUsT0FBTyxDQUFDLFVBQVU7b0JBQzlCLFVBQVUsRUFBRSxPQUFPLENBQUMsVUFBVTtpQkFDL0IsQ0FBQztnQkFDRixNQUFNLFdBQVcsR0FBRyxFQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsS0FBSyxFQUFFLFNBQVMsRUFBRSxPQUFPLENBQUMsU0FBUyxFQUFDLENBQUM7Z0JBRXJFLDZCQUE2QjtnQkFDN0IsT0FBTyxTQUFTLENBQUMsWUFBWSxDQUFDLFdBQVcsRUFBRSxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7b0JBQ3BFLE9BQU8sQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztvQkFDMUQsT0FBTyxTQUFTLENBQUMsWUFBWSxDQUFDLFdBQVcsRUFBRSxZQUFZLENBQUMsQ0FBQztnQkFDM0QsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO29CQUNkLE9BQU8sQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO29CQUN2RCxPQUFPLE9BQU8sQ0FBQztnQkFDakIsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDLENBQUMsQ0FBQztTQUNKO0lBQ0gsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFO1FBQ2hCLDhGQUE4RjtRQUU5RixJQUFJLE9BQU8sQ0FBQyxRQUFRLElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxNQUFNLElBQUksQ0FBQyxFQUFFO1lBQ2pELE9BQU8sU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1NBQzNCO2FBQU07WUFDTCxxQ0FBcUM7WUFDckMsT0FBTyxDQUFDLE1BQU0sR0FBRyxFQUFDLFdBQVcsRUFBRSxPQUFPLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBQyxDQUFDO1lBQzNELE9BQU8sT0FBTyxDQUFDO1NBQ2hCO0lBQ0gsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUM7QUFFRjs7OztHQUlHO0FBQ0gsU0FBUyxTQUFTLENBQUMsYUFBYTtJQUM5QiwwQ0FBMEM7SUFDMUMsYUFBYSxDQUFDLE1BQU0sR0FBRztRQUNyQixTQUFTLEVBQUUsT0FBTztRQUNsQixXQUFXLEVBQUUsYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEtBQUs7S0FDN0UsQ0FBQztJQUNGLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUN0QyxDQUFDO0FBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQStERztBQUNILGdCQUFnQixDQUFDLG1CQUFtQixHQUFHLFVBQVMsR0FBRyxFQUFFLFdBQVc7SUFDOUQsSUFBSSxDQUFDLFdBQVcsRUFBRTtRQUNoQixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsZUFBZSxFQUFFLDJCQUEyQixFQUFFLElBQUksQ0FBQyxDQUFDO0tBQzVFO0lBRUQsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsZUFBZSxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBRXpDLE1BQU0sTUFBTSxHQUFHLFNBQVMsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBRXRELGlCQUFpQjtJQUNqQixJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFO1FBQUUsR0FBRyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztLQUFFO0lBQ25ELElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFO1FBQUUsR0FBRyxDQUFDLE9BQU8sR0FBRyxFQUFDLElBQUksRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBQyxDQUFDO0tBQUU7SUFDekQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUU7UUFBRSxHQUFHLENBQUMsSUFBSSxHQUFHLFVBQVUsQ0FBQztLQUFFO0lBQ3pDLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLEVBQUU7UUFBRSxHQUFHLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQztLQUFFO0lBQ25FLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUU7UUFBRSxHQUFHLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztLQUFFO0lBQ25ELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUU7UUFBRSxHQUFHLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQztLQUFFO0lBQzdDLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFO1FBQUUsR0FBRyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0tBQUU7SUFDM0QsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsRUFBRTtRQUNqQyxHQUFHLENBQUMsVUFBVSxHQUFHLEVBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxLQUFLLENBQUMsZUFBZSxDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFDLENBQUM7S0FDNUU7SUFDRCxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxFQUFFO1FBQ2pDLEdBQUcsQ0FBQyxVQUFVLEdBQUcsRUFBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLEtBQUssQ0FBQyxlQUFlLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUMsQ0FBQztLQUM1RTtJQUVELGdDQUFnQztJQUNoQyxvQkFBb0IsQ0FBQyxhQUFhLENBQUMsZUFBZSxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBRXpELFNBQVM7U0FDTixhQUFhLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQztTQUM1QixzQkFBc0IsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLENBQUM7SUFFOUMsTUFBTSxTQUFTLEdBQUcsR0FBRyxDQUFDLE1BQU07UUFDMUIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQztRQUM3QixDQUFDLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLEVBQUMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxTQUFTLEVBQUMsRUFBRSxXQUFXLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7SUFFdkYsT0FBTyxTQUFTLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO1FBQzdCLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDO1lBQ3BDLEtBQUssRUFBRSxLQUFLLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsd0JBQXdCLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLO1lBQ3RFLE9BQU8sRUFBRSxLQUFLO1lBQ2QsTUFBTSxFQUFFLEdBQUcsQ0FBQyxNQUFNO1lBQ2xCLEtBQUssRUFBRSxHQUFHLENBQUMsS0FBSztZQUNoQixLQUFLLEVBQUUsR0FBRyxDQUFDLEtBQUs7WUFDaEIsVUFBVSxFQUFFLEdBQUcsQ0FBQyxVQUFVO1lBQzFCLFVBQVUsRUFBRSxHQUFHLENBQUMsVUFBVTtZQUMxQixjQUFjLEVBQUUsR0FBRyxDQUFDLGNBQWM7WUFDbEMsTUFBTSxFQUFFLE1BQU07WUFDZCxPQUFPLEVBQUUsR0FBRyxDQUFDLE9BQU87WUFDcEIsU0FBUyxFQUFFLEdBQUcsQ0FBQyxTQUFTO1lBQ3hCLE1BQU0sRUFBRSxXQUFXLENBQUMsRUFBRTtZQUN0QixJQUFJLEVBQUUsR0FBRyxDQUFDLElBQUk7WUFDZCxNQUFNLEVBQUUsR0FBRyxDQUFDLE1BQU07WUFDbEIsR0FBRyxFQUFFLEdBQUcsQ0FBQyxHQUFHO1lBQ1osUUFBUSxFQUFFLEdBQUcsQ0FBQyxRQUFRO1lBQ3RCLE9BQU8sRUFBRSxDQUFDO1NBQ1gsQ0FBQyxDQUFDO0lBQ0wsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7QUFDNUIsQ0FBQyxDQUFDO0FBRUY7Ozs7R0FJRztBQUNILFNBQVMsZ0JBQWdCLENBQUMsSUFBSTtJQUM1QixNQUFNLEdBQUcsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRSxpQkFBaUIsQ0FBQyxDQUFDO0lBRWxELE1BQU0sTUFBTSxHQUFHLFNBQVMsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBRXRELDBCQUEwQjtJQUMxQixJQUFJLENBQUMsR0FBRyxDQUFDLGNBQWMsRUFBRTtRQUN2QixHQUFHLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQztLQUN6QjtJQUVELDJCQUEyQjtJQUMzQixJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRTtRQUNiLEdBQUcsQ0FBQyxJQUFJLEdBQUcsVUFBVSxDQUFDO0tBQ3ZCO0lBRUQsaUJBQWlCO0lBQ2pCLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFFO1FBQ2YsR0FBRyxDQUFDLE1BQU0sR0FBRyxFQUFDLFNBQVMsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFDLENBQUM7S0FDckU7SUFFRCxJQUFJLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUU7UUFDNUIsR0FBRyxDQUFDLFVBQVUsQ0FBQyxRQUFRLEdBQUcsTUFBTSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUM7S0FDeEQ7SUFDRCxJQUFJLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUU7UUFDNUIsR0FBRyxDQUFDLFVBQVUsQ0FBQyxRQUFRLEdBQUcsTUFBTSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUM7S0FDeEQ7SUFFRCxnRUFBZ0U7SUFDaEUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksR0FBRyxDQUFDLE9BQU8sRUFBRTtRQUMzQixNQUFNLE1BQU0sR0FBRyxTQUFTLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUN0RCxHQUFHLENBQUMsR0FBRyxHQUFHO1lBQ1IsZ0JBQWdCLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsZ0JBQWdCO1lBQ3hELGlCQUFpQixFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLGlCQUFpQjtZQUMxRCx3RUFBd0U7WUFDeEUsTUFBTSxFQUFFLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFO1NBQ3RDLENBQUM7S0FDSDtJQUVELGlDQUFpQztJQUNqQyxJQUFJLEdBQUcsQ0FBQyxJQUFJLEVBQUU7UUFDWixHQUFHLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxDQUFDLElBQUksRUFBRSxVQUFVLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQztLQUMxRDtJQUVELE9BQU8sR0FBRyxDQUFDO0FBQ2IsQ0FBQztBQUVEOzs7Ozs7R0FNRztBQUNILGdCQUFnQixDQUFDLHFCQUFxQixHQUFHLFVBQVMsU0FBUyxFQUFFLHVCQUF1QjtJQUNsRixJQUFJLENBQUMsdUJBQXVCLEVBQUU7UUFDNUIsS0FBSyxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsQ0FBQztLQUNqQztJQUNELE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsRUFBQyxLQUFLLEVBQUU7WUFDM0QsU0FBUyxFQUFFLFNBQVM7WUFDcEIsT0FBTyxFQUFFLEtBQUs7U0FDZixFQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1AsQ0FBQyxDQUFDO0FBRUY7Ozs7Ozs7OztHQVNHO0FBQ0gsZ0JBQWdCLENBQUMsc0JBQXNCLEdBQUcsVUFBUyxPQUFPLEVBQUUsS0FBSztJQUMvRCxLQUFLLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsT0FBTyxFQUFFO1FBQ3pDLEVBQUUsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBQztRQUNyQyxRQUFRLEVBQUUsRUFBQyxLQUFLLEVBQUUsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBQztRQUNqQyxLQUFLLEVBQUUsRUFBQyxLQUFLLEVBQUUsVUFBVSxFQUFDO0tBQzNCLENBQUMsQ0FBQztJQUVILElBQUksT0FBTyxDQUFDO0lBQ1osT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsRUFBRTtRQUNoRCxPQUFPLEdBQUcsY0FBYyxDQUFDLEdBQUcsRUFBRSxDQUFDO1FBRS9CLG9GQUFvRjtRQUNwRixPQUFPLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUNyRCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1FBQ1gsZ0NBQWdDO1FBQ2hDLE9BQU8sT0FBTyxDQUFDLEVBQUUsQ0FBQztRQUNsQixPQUFPLE9BQU8sQ0FBQyxTQUFTLENBQUM7UUFDekIsT0FBTyxPQUFPLENBQUMsU0FBUyxDQUFDO1FBRXpCLHFCQUFxQjtRQUNyQixJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ25DLElBQUksT0FBTyxDQUFDLE1BQU0sS0FBSyxLQUFLLENBQUMsRUFBRSxFQUFFO2dCQUMvQiw0RUFBNEU7Z0JBQzVFLE9BQU8sQ0FBQyxRQUFRLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQzthQUNuQztpQkFBTTtnQkFDTCxtRkFBbUY7Z0JBQ25GLE9BQU8sQ0FBQyxRQUFRLEdBQUcsQ0FBQyxDQUFDLENBQUM7YUFDdkI7U0FDRjtRQUVELCtDQUErQztRQUMvQyxPQUFPLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQyxFQUFFLENBQUM7UUFFMUIsZ0JBQWdCO1FBQ2hCLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDakMsT0FBTyxDQUFDLEtBQUssR0FBRyxPQUFPLENBQUMsS0FBSyxDQUFDO1NBQy9CO2FBQU07WUFDTCxPQUFPLENBQUMsS0FBSyxHQUFHLFVBQVUsR0FBRyxPQUFPLENBQUMsS0FBSyxDQUFDO1NBQzVDO1FBRUQsOEZBQThGO1FBQzlGLE9BQU8sV0FBVyxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsT0FBTyxDQUFDLFNBQVMsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNqRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7UUFDZixPQUFPLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUM7UUFFM0IsZ0JBQWdCO1FBQ2hCLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ2pELENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQztBQUVGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0F3Qkc7QUFDSCxnQkFBZ0IsQ0FBQyxtQkFBbUIsR0FBRyxVQUFTLEtBQUssRUFBRSxhQUFhLEVBQUUsT0FBTyxFQUFFLFdBQVc7SUFDeEYsSUFBSSxDQUFDLGFBQWEsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUU7UUFDdkMsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxDQUFDO0tBQ3hDO0lBRUQsYUFBYSxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLENBQUM7SUFFMUMsSUFBSSxDQUFDLFdBQVcsRUFBRTtRQUNoQixNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQUMsZUFBZSxFQUFFLDJCQUEyQixDQUFDLENBQUM7S0FDckU7SUFDRCxJQUFJLE9BQU8sYUFBYSxLQUFLLFFBQVEsRUFBRTtRQUNyQyxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQUMsbUJBQW1CLEVBQUUsaURBQWlELENBQUMsQ0FBQztLQUMvRjtJQUVELEtBQUssQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxPQUFPLEVBQUUsQ0FBQyxXQUFXLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQztJQUV0RSxrRUFBa0U7SUFDbEUsT0FBTyxhQUFhLENBQUMsRUFBRSxDQUFDO0lBQ3hCLE9BQU8sYUFBYSxDQUFDLFNBQVMsQ0FBQztJQUMvQixPQUFPLGFBQWEsQ0FBQyxNQUFNLENBQUM7SUFDNUIsT0FBTyxhQUFhLENBQUMsT0FBTyxDQUFDO0lBRTdCLDRCQUE0QjtJQUM1QixvQkFBb0IsQ0FBQyxXQUFXLENBQUMsZUFBZSxFQUFFLGFBQWEsQ0FBQyxDQUFDO0lBRWpFLE9BQU8sUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsV0FBVyxFQUFFLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1FBQ3BFLCtCQUErQjtRQUMvQixPQUFPLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUN6QixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUU7UUFDWixTQUFTLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxhQUFhLENBQUMsY0FBYyxDQUFDLENBQUM7UUFFNUYsa0VBQWtFO1FBQ2xFLElBQUksYUFBYSxDQUFDLE1BQU0sS0FBSyxTQUFTLElBQUksR0FBRyxDQUFDLE1BQU0sS0FBSyxhQUFhLENBQUMsTUFBTSxFQUFFO1lBQzdFLE9BQU8sYUFBYSxDQUFDLE1BQU0sQ0FBQztTQUM3QjtRQUVELG1FQUFtRTtRQUNuRSxNQUFNLFdBQVcsR0FBRyxhQUFhLENBQUMsTUFBTSxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7UUFFM0UsT0FBTyxXQUFXLENBQUMscUJBQXFCLENBQUMsR0FBRyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDbkUsSUFBSSxhQUFhLEdBQUcsT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBRXRDLHdDQUF3QztZQUN4QyxDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDLEtBQUssRUFBRSxHQUFHLEVBQUUsRUFBRTtnQkFDdEMsSUFBSSxHQUFHLEtBQUssUUFBUSxFQUFFO29CQUNwQix1RkFBdUY7b0JBQ3ZGLGFBQWEsR0FBRyxXQUFXLENBQUMsS0FBSyxFQUFFLEdBQUcsQ0FBQyxTQUFTLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO3dCQUMzRSxHQUFHLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUM7b0JBQ3pCLENBQUMsQ0FBQyxDQUFDO2lCQUNKO3FCQUFNO29CQUNMLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxLQUFLLENBQUM7aUJBQ2xCO1lBQ0gsQ0FBQyxDQUFDLENBQUM7WUFFSCxPQUFPLGFBQWEsQ0FBQztRQUN2QixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1gsZ0NBQWdDO1lBQ2hDLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxJQUFJLEdBQUcsQ0FBQyxLQUFLLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtnQkFDL0MsT0FBTzthQUNSO1lBRUQsdUJBQXVCO1lBQ3ZCLHdCQUF3QjtZQUN4QixPQUFPLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLElBQUksRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUU7Z0JBQzdFLDBCQUEwQjtnQkFDMUIsT0FBTyxTQUFTLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDakMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFO2dCQUNuQiw4Q0FBOEM7Z0JBQzlDLE1BQU0sUUFBUSxHQUFHLElBQUksS0FBSyxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQ3BELFVBQVUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO29CQUNoQyxNQUFNLEVBQUUsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUN4QixJQUFJLENBQUMsRUFBRSxDQUFDLFFBQVEsRUFBRTt3QkFBRSxFQUFFLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQztxQkFBRTtvQkFDdkMsSUFBSSxFQUFFLENBQUMsUUFBUSxDQUFDLEtBQUssS0FBSyxJQUFJLEVBQUU7d0JBQzlCLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO3dCQUM3QixFQUFFLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztxQkFDOUI7b0JBQ0QsUUFBUSxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQztnQkFDbkIsQ0FBQyxDQUFDLENBQUM7Z0JBQ0gsc0RBQXNEO2dCQUN0RCxHQUFHLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQztZQUN2QixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCxPQUFPLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUNwQixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0FBQzVCLENBQUMsQ0FBQztBQUVGOzs7Ozs7Ozs7O0dBVUc7QUFDSCxnQkFBZ0IsQ0FBQyxhQUFhLEdBQUcsVUFBUyxTQUFTLEVBQUUsYUFBYSxFQUFFLFdBQVc7SUFDN0UsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsZUFBZSxFQUFFLGFBQWEsQ0FBQyxDQUFDO0lBRW5ELGtFQUFrRTtJQUNsRSxPQUFPLGFBQWEsQ0FBQyxFQUFFLENBQUM7SUFDeEIsT0FBTyxhQUFhLENBQUMsU0FBUyxDQUFDO0lBQy9CLE9BQU8sYUFBYSxDQUFDLE1BQU0sQ0FBQztJQUM1QixPQUFPLGFBQWEsQ0FBQyxPQUFPLENBQUM7SUFFN0IsT0FBTyxZQUFZLENBQUMsU0FBUyxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRTtRQUNyRCxzREFBc0Q7UUFDdEQsOENBQThDO1FBQzlDLG9CQUFvQixDQUFDLGtCQUFrQixDQUFDLGVBQWUsRUFBRSxhQUFhLENBQUMsQ0FBQztRQUV4RSxDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDLEtBQUssRUFBRSxHQUFHLEVBQUUsRUFBRTtZQUN0QyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFDO1FBQ25CLENBQUMsQ0FBQyxDQUFDO1FBRUgsT0FBTyxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUM7SUFDcEIsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQztBQUVGOzs7Ozs7R0FNRztBQUNILGdCQUFnQixDQUFDLFVBQVUsR0FBRyxVQUFTLGVBQWUsRUFBRSxXQUFXO0lBQ2pFLE9BQU8sUUFBUSxDQUFDLGVBQWUsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRTtRQUNwRCxPQUFPLFdBQVcsQ0FBQyxxQkFBcUIsQ0FBQyxhQUFhLEVBQUUsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUN6RSxPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7UUFDbEQsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQztBQUVGOzs7Ozs7O0dBT0c7QUFDSCxTQUFTLFVBQVUsQ0FBQyxhQUFhO0lBQy9CLE9BQU8sb0JBQW9CLENBQUMsYUFBYSxDQUFDO1NBQ3ZDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLG9CQUFvQixDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQzFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLG9CQUFvQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7QUFDaEQsQ0FBQztBQUVEOzs7Ozs7Ozs7R0FTRztBQUNILFNBQVMsb0JBQW9CLENBQUMsYUFBYTtJQUN6QyxJQUFJLGFBQWEsQ0FBQyxPQUFPLEdBQUcsQ0FBQyxFQUFFO1FBQzdCLE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztLQUN2QztTQUFNO1FBRUwsYUFBYSxDQUFDLE9BQU8sR0FBRyxhQUFhLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUN6RCxzREFBc0Q7WUFDdEQsNENBQTRDO1lBQzVDLDJEQUEyRDtZQUMzRCxzQ0FBc0M7WUFDdEMsMkRBQTJEO1lBQzNELHVDQUF1QztZQUV2QyxJQUFJLE1BQU0sQ0FBQyxHQUFHLEtBQUssaUJBQWlCLEVBQUU7Z0JBQ3BDLG1CQUFtQjtnQkFDbkIsT0FBTztvQkFDTCxHQUFHLEVBQUUsaUJBQWlCO2lCQUN2QixDQUFDO2FBQ0g7WUFFRCxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxFQUFFO2dCQUM5RCxHQUFHLENBQUMsSUFBSSxDQUFDLDhCQUE4QixFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztnQkFDakUsT0FBTyxDQUFDLHdCQUF3QjthQUNqQztZQUVELE1BQU0sTUFBTSxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7WUFFdkQsSUFBSSxNQUFNLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtnQkFDdkIsR0FBRyxDQUFDLElBQUksQ0FBQyw4QkFBOEIsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7Z0JBQ2pFLE9BQU8sQ0FBQyx3QkFBd0I7YUFDakM7WUFFRCxJQUFJLE1BQU0sQ0FBQyxHQUFHLEtBQUssc0JBQXNCO2dCQUN2QyxNQUFNLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyx1QkFBdUIsQ0FBQztnQkFDOUMsTUFBTSxDQUFDLEdBQUcsS0FBSyxnQkFBZ0I7Z0JBQy9CLE1BQU0sQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLHVCQUF1QixDQUFDLEVBQUU7Z0JBQ2hELE9BQU87b0JBQ0wsR0FBRyxFQUFFLE1BQU0sQ0FBQyxHQUFHO29CQUNmLE1BQU07aUJBQ1AsQ0FBQzthQUNIO1FBQ0gsQ0FBQyxDQUFDLENBQUM7UUFFSCxpREFBaUQ7UUFDakQsYUFBYSxDQUFDLE9BQU8sR0FBRyxhQUFhLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUM7UUFFckUsYUFBYSxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUM7UUFFMUIsT0FBTyxhQUFhLENBQUMsSUFBSSxFQUFFLENBQUM7S0FDN0I7QUFDSCxDQUFDO0FBRUQ7Ozs7Ozs7OztHQVNHO0FBQ0gsU0FBUyxvQkFBb0IsQ0FBQyxhQUFhO0lBQ3pDLElBQUksYUFBYSxDQUFDLE9BQU8sR0FBRyxDQUFDLEVBQUU7UUFDN0IsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDO0tBQ3ZDO1NBQU07UUFDTCxxRkFBcUY7UUFDckYsaUNBQWlDO1FBQ2pDLGFBQWEsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxFQUFFO1lBQ3RELElBQUksQ0FBQyxFQUFFLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQyxFQUFFLENBQUM7WUFDdkIsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDLENBQUMsQ0FBQztRQUNILGFBQWEsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxFQUFFO1lBQ3RELElBQUksQ0FBQyxFQUFFLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQyxFQUFFLENBQUM7WUFDdkIsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDLENBQUMsQ0FBQztRQUVILGFBQWEsQ0FBQyxPQUFPLEdBQUcsQ0FBQyxDQUFDO1FBRTFCLE9BQU8sYUFBYSxDQUFDLElBQUksRUFBRSxDQUFDO0tBQzdCO0FBQ0gsQ0FBQztBQUVEOzs7Ozs7Ozs7Ozs7R0FZRztBQUNILFNBQVMsb0JBQW9CLENBQUMsYUFBYTtJQUN6QyxJQUFJLGFBQWEsQ0FBQyxPQUFPLEdBQUcsQ0FBQyxFQUFFO1FBQzdCLE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztLQUN2QztJQUVELE9BQU8sT0FBTyxDQUFDLEtBQUssQ0FBQztRQUNuQixJQUFJLEVBQUUsa0JBQWtCLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxTQUFTLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQztRQUM1RSxJQUFJLEVBQUUsa0JBQWtCLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxTQUFTLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQztLQUM3RSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO1FBQ2YsTUFBTSxRQUFRLEdBQUcsRUFBRSxDQUFDO1FBQ3BCLDRCQUE0QjtRQUM1QixNQUFNLFNBQVMsR0FBRyxhQUFhLENBQUMsT0FBTyxDQUFDO1FBQ3hDLDJEQUEyRDtRQUMzRCxRQUFRLENBQUMsTUFBTSxHQUFHLFdBQVcsQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUNoRCxhQUFhLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFDM0IsYUFBYSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQzVCLFNBQVMsQ0FBQyxDQUFDO1FBQ2IsbUVBQW1FO1FBQ25FLFFBQVEsQ0FBQyxPQUFPLEdBQUcsV0FBVyxDQUFDLE9BQU8sQ0FBQztRQUN2QyxNQUFNLFVBQVUsR0FBRyxhQUFhLENBQUMsVUFBVSxJQUFJLEVBQUUsQ0FBQztRQUNsRCxNQUFNLFVBQVUsR0FBRyxhQUFhLENBQUMsVUFBVSxJQUFJLEVBQUUsQ0FBQztRQUNsRCw0Q0FBNEM7UUFDNUMsVUFBVSxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUM7UUFDdEIsVUFBVSxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUM7UUFFdEIsZ0JBQWdCO1FBQ2hCLE9BQU8sVUFBVSxDQUFDLE1BQU0sQ0FBQztRQUN6QixPQUFPLFVBQVUsQ0FBQyxNQUFNLENBQUM7UUFFekIsa0VBQWtFO1FBQ2xFLHVGQUF1RjtRQUN2RixhQUFhLENBQUMsTUFBTSxHQUFHLFFBQVEsQ0FBQztRQUNoQyxhQUFhLENBQUMsVUFBVSxHQUFHLFVBQVUsQ0FBQztRQUN0QyxhQUFhLENBQUMsVUFBVSxHQUFHLFVBQVUsQ0FBQztRQUN0QyxhQUFhLENBQUMsT0FBTyxHQUFHLEVBQUMsSUFBSSxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFDLENBQUM7UUFDN0MsYUFBYSxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUM7UUFFMUIsT0FBTyxhQUFhLENBQUMsSUFBSSxFQUFFLENBQUM7SUFDOUIsQ0FBQyxDQUFDLENBQUM7QUFFTCxDQUFDO0FBRUQ7Ozs7R0FJRztBQUNILFNBQVMsUUFBUSxDQUFDLGVBQWUsRUFBRSxXQUFXO0lBQzVDLE1BQU0sT0FBTyxHQUFHLEVBQUMsS0FBSyxFQUFFLEVBQUMsRUFBRSxFQUFFLGVBQWUsRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFDLEVBQUMsQ0FBQztJQUMvRCxJQUFJLFdBQVcsRUFBRTtRQUNmLE9BQU8sQ0FBQyxPQUFPLEdBQUcsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO0tBQ3BDO0lBQ0QsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFO1FBQ2hFLElBQUksYUFBYSxLQUFLLElBQUksSUFBSSxhQUFhLEtBQUssU0FBUyxFQUFFO1lBQ3pELE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FDcEIsV0FBVyxFQUFFLGlCQUFpQixHQUFHLGVBQWUsR0FBRyxpQkFBaUIsRUFBRSxJQUFJLENBQzNFLENBQUM7U0FDSDtRQUVELElBQUksQ0FBQyxhQUFhLENBQUMsY0FBYyxFQUFFO1lBQ2pDLGFBQWEsQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO1NBQ25DO1FBRUQsT0FBTyxhQUFhLENBQUM7SUFDdkIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3RCLENBQUM7QUFFRDs7Ozs7R0FLRztBQUNILFNBQVMsWUFBWSxDQUFDLFNBQVMsRUFBRSxXQUFXO0lBQzFDLE1BQU0sTUFBTSxHQUFHLFNBQVMsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDbEQsTUFBTSxDQUFDLFdBQVcsRUFBRSxDQUFDO0lBRXJCLE1BQU0sS0FBSyxHQUFHO1FBQ1osT0FBTyxFQUFFLElBQUk7UUFDYixTQUFTLEVBQUUsU0FBUztRQUNwQixNQUFNLEVBQUUsV0FBVyxDQUFDLEVBQUU7S0FDdkIsQ0FBQztJQUNGLE1BQU0sTUFBTSxHQUFHO1FBQ2IsS0FBSyxFQUFFLFNBQVM7UUFDaEIsS0FBSyxFQUFFLEVBQUU7UUFDVCxLQUFLLEVBQUUsRUFBRTtRQUNULE1BQU0sRUFBRSxDQUFDLENBQUM7UUFDVixVQUFVLEVBQUUsRUFBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLEtBQUssQ0FBQyxlQUFlLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUM7UUFDckUsVUFBVSxFQUFFLEVBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxLQUFLLENBQUMsZUFBZSxDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFDO1FBQ3JFLE1BQU0sRUFBRTtZQUNOLE9BQU8sRUFBRSxXQUFXLENBQUMsT0FBTztZQUM1QixNQUFNLEVBQUUsTUFBTSxDQUFDLEtBQUssQ0FBQyxhQUFhO1NBQ25DO1FBQ0QsT0FBTyxFQUFFLEVBQUMsSUFBSSxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFDO1FBQzdCLE9BQU8sRUFBRSxDQUFDO0tBQ1gsQ0FBQztJQUNGLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsWUFBWSxDQUFDO1FBQzFDLEtBQUssRUFBRSxLQUFLO1FBQ1osUUFBUSxFQUFFLE1BQU07S0FDakIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNqRCxDQUFDO0FBRUQ7Ozs7Ozs7OztHQVNHO0FBQ0gsZ0JBQWdCLENBQUMsY0FBYyxHQUFHLFVBQVMsU0FBUyxFQUFFLE9BQU87SUFDM0QsS0FBSyxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUNoQyxNQUFNLE1BQU0sR0FBRyxTQUFTLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ2xELE1BQU0sK0JBQStCLEdBQUcsRUFBQyxLQUFLLEVBQUUsRUFBQyxTQUFTLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUMsRUFBQyxDQUFDO0lBRXZGLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7UUFFakMsZ0JBQWdCO1FBQ2hCLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFO1lBQUUsT0FBTztTQUFFO1FBQ2hDLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDO1lBQ3BDLE1BQU0sRUFBRTtnQkFDTixPQUFPLEVBQUUsV0FBVyxDQUFDLE9BQU87Z0JBQzVCLE1BQU0sRUFBRSxNQUFNLENBQUMsS0FBSyxDQUFDLGFBQWE7YUFDbkM7U0FDRixFQUFFLCtCQUErQixDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFO1lBQ3JELEdBQUcsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLFdBQVcsNEJBQTRCLFNBQVMsSUFBSSxDQUFDLENBQUM7UUFDckYsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1FBRVgsa0JBQWtCO1FBQ2xCLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFO1lBQUUsT0FBTztTQUFFO1FBQ2xDLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDO1lBQ3BDLFVBQVUsRUFBRSxFQUFDLFFBQVEsRUFBRSxNQUFNLENBQUMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBQztZQUNyRSxVQUFVLEVBQUUsRUFBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLEtBQUssQ0FBQyxlQUFlLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUM7U0FDdEUsRUFBRSwrQkFBK0IsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUNyRCxHQUFHLENBQUMsSUFBSSxDQUFDLHNCQUFzQixXQUFXLDRCQUE0QixTQUFTLElBQUksQ0FBQyxDQUFDO1FBQ3ZGLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUM7QUFFRjs7Ozs7Ozs7Ozs7Ozs7O0dBZUc7QUFDSCxTQUFTLGFBQWEsQ0FBQyxJQUFJLEVBQUUsT0FBTztJQUNsQywyQkFBMkI7SUFDM0IsSUFBSSxPQUFPLEtBQUssU0FBUyxFQUFFO1FBQ3pCLE9BQU8sR0FBRyxFQUFDLFFBQVEsRUFBRSxFQUFDLENBQUMsRUFBRSxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRSxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxFQUFDLEVBQUMsQ0FBQztLQUN4RTtJQUVELHlEQUF5RDtJQUN6RCxJQUFJLE9BQU8sQ0FBQyxDQUFDLEtBQUssU0FBUyxJQUFJLE9BQU8sQ0FBQyxDQUFDLEtBQUssU0FBUyxFQUFFO1FBQ3RELE9BQU8sR0FBRyxFQUFDLFFBQVEsRUFBRSxFQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQyxFQUFDLEVBQUMsQ0FBQztLQUNwRDtJQUVELE9BQU87UUFDTCxFQUFFLEVBQUUsSUFBSSxDQUFDLEVBQUU7UUFDWCxRQUFRLEVBQUUsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRTtRQUNsRCxHQUFHLEVBQUUsT0FBTyxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUU7UUFDOUMsUUFBUSxFQUFFLE9BQU8sQ0FBQyxRQUFRLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFNBQVM7UUFDdEQsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO1FBQ2YsVUFBVSxFQUFFLElBQUksQ0FBQyxVQUFVO1FBQzNCLFVBQVUsRUFBRSxJQUFJLENBQUMsVUFBVTtRQUMzQixNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU07S0FDcEIsQ0FBQztBQUNKLENBQUM7QUFFRDs7Ozs7Ozs7R0FRRztBQUNILFNBQVMsYUFBYSxDQUFDLElBQUksRUFBRSxPQUFPO0lBQ2xDLE9BQU87UUFDTCxFQUFFLEVBQUUsSUFBSSxDQUFDLEVBQUU7UUFDWCxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUk7UUFDZixJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUk7UUFDZixNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU07UUFDbkIsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNO1FBQ25CLFFBQVEsRUFBRSxPQUFPLElBQUksT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxTQUFTO1FBQ3hELFVBQVUsRUFBRSxJQUFJLENBQUMsVUFBVTtRQUMzQixNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU07S0FDcEIsQ0FBQztBQUNKLENBQUMifQ==