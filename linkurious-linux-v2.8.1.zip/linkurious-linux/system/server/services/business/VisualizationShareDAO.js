/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2015-02-23.
 */
'use strict';
const Promise = require('bluebird');
const _ = require('lodash');
const LKE = require('../index');
const Db = LKE.getSqlDb();
const Errors = LKE.getErrors();
const UserDAO = LKE.getUserDAO();
const VisualizationShareDAO = module.exports = {};
/**
 * Get all visualization shared with current user
 *
 * @param {string} sourceKey Key of the data-source
 * @param {WrappedUser} currentUser
 * @returns {Bluebird<Array<{visualizationId: string, title: string, sourceKey: string, ownerId: number, right: string, ownerUsername: string, updatedAt: string}>>}
 */
VisualizationShareDAO.getSharedWithMe = function (sourceKey, currentUser) {
    const query = {
        where: { userId: currentUser.id },
        include: [{
                model: Db.models.visualization,
                where: { sourceKey: sourceKey },
                include: [Db.models.user]
            }]
    };
    return Promise.resolve(Db.models.visualizationShare.findAll(query)).map(share => {
        return {
            right: share.right,
            visualizationId: share.visualization.id,
            ownerId: share.visualization.userId,
            ownerUsername: share.visualization.user.username,
            sourceKey: share.visualization.sourceKey,
            title: share.visualization.title,
            updatedAt: JSON.parse(JSON.stringify(new Date(share.visualization.updatedAt)))
        };
    });
};
/**
 * Get all shares for a visualization
 *
 * @param {number} visualizationId
 * @returns {Bluebird<{owner: {id: number, username: string, email: string, source: string}, shares:{userId:number, username:string, email:string, visualizationId:number, right:string}[]}>}
 */
VisualizationShareDAO.getShares = function (visualizationId) {
    const query = {
        where: { visualizationId: visualizationId },
        include: [Db.models.user]
    };
    return resolveVisualization(visualizationId).then(viz => {
        return UserDAO.getUser(viz.userId);
    }).then(owner => {
        return Promise.resolve(Db.models.visualizationShare.findAll(query)).map(share => {
            return {
                userId: share.userId,
                username: share.user.username,
                email: share.user.email,
                right: share.right,
                visualizationId: share.visualizationId
            };
        }).then(shares => {
            return {
                owner: owner,
                shares: shares
            };
        });
    });
};
/**
 * Add or update a visualizationShare
 *
 * @param {number} visualizationId
 * @param {number} userId
 * @param {string} right 'read' or 'write'
 * @param {WrappedUser} currentUser
 * @returns {Bluebird<{userId:number, visualizationId:number, right:string, createdAt:string, updatedAt:string}>}
 */
VisualizationShareDAO.shareWithUser = function (visualizationId, userId, right, currentUser) {
    if (!_.includes(Db.models.visualizationShare.RIGHTS, right)) {
        return Errors.business('invalid_parameter', 'Right (' + right + ') must be one of ' + Db.models.visualizationShare.RIGHTS, true);
    }
    return checkOwner(visualizationId, currentUser).then(() => {
        const whereAndDefaults = {
            where: { visualizationId: visualizationId, userId: userId },
            defaults: { right: right }
        };
        return Db.models.visualizationShare.findOrCreate(whereAndDefaults).spread(vizShare => {
            // update the vizShare if the "right" is different
            if (vizShare.right !== right) {
                vizShare.right = right;
                return vizShare.save();
            }
            return vizShare;
        }).then(vizShare => {
            // remove the sequelize wrapper
            vizShare = vizShare.get();
            vizShare.userId = +vizShare.userId;
            vizShare.visualizationId = +vizShare.visualizationId;
            delete vizShare.id;
            return vizShare;
        });
    });
};
/**
 * Get a user's right for a visualization
 *
 * @param {object} visualization
 * @param {number} visualization.userId
 * @param {number} visualization.id
 * @param {number} userId
 * @returns {Bluebird<string>} resolves to 'owner', 'write' or 'read' (or reject if no right exists)
 */
VisualizationShareDAO.getRight = function (visualization, userId) {
    if (visualization.userId === userId) {
        return Promise.resolve('owner');
    }
    return getShare(visualization.id, userId).then(share => {
        if (!share) {
            return Errors.access('read_forbidden', 'You don\'t have access to this visualization', true);
        }
        return share.right;
    });
};
/**
 * Delete a visualizationShare
 *
 * @param {number} visualizationId
 * @param {number} userId
 * @param {WrappedUser} currentUser
 * @returns {Bluebird<void>}
 */
VisualizationShareDAO.unshare = function (visualizationId, userId, currentUser) {
    return checkOwner(visualizationId, currentUser).then(() => {
        return getShare(visualizationId, userId).then(share => {
            if (share) {
                return share.destroy();
            }
        });
    });
};
/**
 * Resolve a visualization
 *
 * @param {number} id a visualization id
 * @returns {Bluebird<PublicVisualization>}
 */
function resolveVisualization(id) {
    const query = { where: { id: id } };
    return Db.models.visualization.find(query).then(viz => {
        if (!viz) {
            return Errors.business('not_found', 'Visualization "' + id + '" was not found', true);
        }
        return Promise.resolve(viz);
    });
}
/**
 * Check if the current user is the owner of a visualization
 *
 * @param {number}      visualizationId
 * @param {WrappedUser} currentUser
 * @returns {Bluebird<void>} resolved if the current user matches the viz' owner
 * @private
 */
function checkOwner(visualizationId, currentUser) {
    return resolveVisualization(visualizationId).then(viz => {
        // user is the original owner
        if (viz.userId === currentUser.id) {
            return;
        }
        return getShare(visualizationId, currentUser.id).then(share => {
            // user has delegated ownership
            if (share && share.right === 'owner') {
                return;
            }
            // user is not owner
            return Errors.access('forbidden', 'You can not change the share settings of a visualization that you don\'t own', true);
        });
    });
}
/**
 * @param {number} visualizationId
 * @param {number} userId
 * @returns {Bluebird<VisualizationShareInstance>}
 * @private
 */
function getShare(visualizationId, userId) {
    const where = { visualizationId: visualizationId, userId: userId };
    return Db.models.visualizationShare.find({ where: where });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiVmlzdWFsaXphdGlvblNoYXJlREFPLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL3NlcnZpY2VzL2J1c2luZXNzL1Zpc3VhbGl6YXRpb25TaGFyZURBTy5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7R0FLRztBQUNILFlBQVksQ0FBQztBQUNiLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNwQyxNQUFNLENBQUMsR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDNUIsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ2hDLE1BQU0sRUFBRSxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUMxQixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxPQUFPLEdBQUcsR0FBRyxDQUFDLFVBQVUsRUFBRSxDQUFDO0FBRWpDLE1BQU0scUJBQXFCLEdBQUcsTUFBTSxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7QUFFbEQ7Ozs7OztHQU1HO0FBQ0gscUJBQXFCLENBQUMsZUFBZSxHQUFHLFVBQVMsU0FBUyxFQUFFLFdBQVc7SUFDckUsTUFBTSxLQUFLLEdBQUc7UUFDWixLQUFLLEVBQUUsRUFBQyxNQUFNLEVBQUUsV0FBVyxDQUFDLEVBQUUsRUFBQztRQUMvQixPQUFPLEVBQUUsQ0FBQztnQkFDUixLQUFLLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxhQUFhO2dCQUM5QixLQUFLLEVBQUUsRUFBQyxTQUFTLEVBQUUsU0FBUyxFQUFDO2dCQUM3QixPQUFPLEVBQUUsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQzthQUMxQixDQUFDO0tBQ0gsQ0FBQztJQUNGLE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRTtRQUM5RSxPQUFPO1lBQ0wsS0FBSyxFQUFFLEtBQUssQ0FBQyxLQUFLO1lBQ2xCLGVBQWUsRUFBRSxLQUFLLENBQUMsYUFBYSxDQUFDLEVBQUU7WUFDdkMsT0FBTyxFQUFFLEtBQUssQ0FBQyxhQUFhLENBQUMsTUFBTTtZQUNuQyxhQUFhLEVBQUUsS0FBSyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsUUFBUTtZQUNoRCxTQUFTLEVBQUUsS0FBSyxDQUFDLGFBQWEsQ0FBQyxTQUFTO1lBQ3hDLEtBQUssRUFBRSxLQUFLLENBQUMsYUFBYSxDQUFDLEtBQUs7WUFDaEMsU0FBUyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7U0FDL0UsQ0FBQztJQUNKLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDO0FBRUY7Ozs7O0dBS0c7QUFDSCxxQkFBcUIsQ0FBQyxTQUFTLEdBQUcsVUFBUyxlQUFlO0lBQ3hELE1BQU0sS0FBSyxHQUFHO1FBQ1osS0FBSyxFQUFFLEVBQUMsZUFBZSxFQUFFLGVBQWUsRUFBQztRQUN6QyxPQUFPLEVBQUUsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztLQUMxQixDQUFDO0lBQ0YsT0FBTyxvQkFBb0IsQ0FBQyxlQUFlLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUU7UUFDdEQsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNyQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7UUFDZCxPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDOUUsT0FBTztnQkFDTCxNQUFNLEVBQUUsS0FBSyxDQUFDLE1BQU07Z0JBQ3BCLFFBQVEsRUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDLFFBQVE7Z0JBQzdCLEtBQUssRUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUs7Z0JBQ3ZCLEtBQUssRUFBRSxLQUFLLENBQUMsS0FBSztnQkFDbEIsZUFBZSxFQUFFLEtBQUssQ0FBQyxlQUFlO2FBQ3ZDLENBQUM7UUFDSixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDZixPQUFPO2dCQUNMLEtBQUssRUFBRSxLQUFLO2dCQUNaLE1BQU0sRUFBRSxNQUFNO2FBQ2YsQ0FBQztRQUNKLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUM7QUFFRjs7Ozs7Ozs7R0FRRztBQUNILHFCQUFxQixDQUFDLGFBQWEsR0FBRyxVQUFTLGVBQWUsRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFLFdBQVc7SUFDeEYsSUFBSSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLEVBQUU7UUFDM0QsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUNwQixtQkFBbUIsRUFDbkIsU0FBUyxHQUFHLEtBQUssR0FBRyxtQkFBbUIsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLE1BQU0sRUFDN0UsSUFBSSxDQUNMLENBQUM7S0FDSDtJQUNELE9BQU8sVUFBVSxDQUFDLGVBQWUsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1FBQ3hELE1BQU0sZ0JBQWdCLEdBQUc7WUFDdkIsS0FBSyxFQUFFLEVBQUMsZUFBZSxFQUFFLGVBQWUsRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFDO1lBQ3pELFFBQVEsRUFBRSxFQUFDLEtBQUssRUFBRSxLQUFLLEVBQUM7U0FDekIsQ0FBQztRQUNGLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxZQUFZLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDbkYsa0RBQWtEO1lBQ2xELElBQUksUUFBUSxDQUFDLEtBQUssS0FBSyxLQUFLLEVBQUU7Z0JBQzVCLFFBQVEsQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO2dCQUN2QixPQUFPLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBQzthQUN4QjtZQUNELE9BQU8sUUFBUSxDQUFDO1FBQ2xCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUNqQiwrQkFBK0I7WUFDL0IsUUFBUSxHQUFHLFFBQVEsQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUMxQixRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztZQUNuQyxRQUFRLENBQUMsZUFBZSxHQUFHLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQztZQUNyRCxPQUFPLFFBQVEsQ0FBQyxFQUFFLENBQUM7WUFDbkIsT0FBTyxRQUFRLENBQUM7UUFDbEIsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQztBQUVGOzs7Ozs7OztHQVFHO0FBQ0gscUJBQXFCLENBQUMsUUFBUSxHQUFHLFVBQVMsYUFBYSxFQUFFLE1BQU07SUFDN0QsSUFBSSxhQUFhLENBQUMsTUFBTSxLQUFLLE1BQU0sRUFBRTtRQUNuQyxPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7S0FDakM7SUFDRCxPQUFPLFFBQVEsQ0FBQyxhQUFhLENBQUMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtRQUNyRCxJQUFJLENBQUMsS0FBSyxFQUFFO1lBQ1YsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDLGdCQUFnQixFQUFFLDhDQUE4QyxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQzlGO1FBQ0QsT0FBTyxLQUFLLENBQUMsS0FBSyxDQUFDO0lBQ3JCLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDO0FBRUY7Ozs7Ozs7R0FPRztBQUNILHFCQUFxQixDQUFDLE9BQU8sR0FBRyxVQUFTLGVBQWUsRUFBRSxNQUFNLEVBQUUsV0FBVztJQUMzRSxPQUFPLFVBQVUsQ0FBQyxlQUFlLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtRQUN4RCxPQUFPLFFBQVEsQ0FBQyxlQUFlLEVBQUUsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ3BELElBQUksS0FBSyxFQUFFO2dCQUNULE9BQU8sS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUFDO2FBQ3hCO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQztBQUVGOzs7OztHQUtHO0FBQ0gsU0FBUyxvQkFBb0IsQ0FBQyxFQUFFO0lBQzlCLE1BQU0sS0FBSyxHQUFHLEVBQUMsS0FBSyxFQUFFLEVBQUMsRUFBRSxFQUFFLEVBQUUsRUFBQyxFQUFDLENBQUM7SUFDaEMsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFO1FBQ3BELElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDUixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLGlCQUFpQixHQUFHLEVBQUUsR0FBRyxpQkFBaUIsRUFBRSxJQUFJLENBQUMsQ0FBQztTQUN2RjtRQUNELE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUM5QixDQUFDLENBQUMsQ0FBQztBQUNMLENBQUM7QUFFRDs7Ozs7OztHQU9HO0FBQ0gsU0FBUyxVQUFVLENBQUMsZUFBZSxFQUFFLFdBQVc7SUFDOUMsT0FBTyxvQkFBb0IsQ0FBQyxlQUFlLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUU7UUFDdEQsNkJBQTZCO1FBQzdCLElBQUksR0FBRyxDQUFDLE1BQU0sS0FBSyxXQUFXLENBQUMsRUFBRSxFQUFFO1lBQ2pDLE9BQU87U0FDUjtRQUVELE9BQU8sUUFBUSxDQUFDLGVBQWUsRUFBRSxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQzVELCtCQUErQjtZQUMvQixJQUFJLEtBQUssSUFBSSxLQUFLLENBQUMsS0FBSyxLQUFLLE9BQU8sRUFBRTtnQkFDcEMsT0FBTzthQUNSO1lBRUQsb0JBQW9CO1lBQ3BCLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FDbEIsV0FBVyxFQUNYLDhFQUE4RSxFQUM5RSxJQUFJLENBQ0wsQ0FBQztRQUNKLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDO0FBRUQ7Ozs7O0dBS0c7QUFDSCxTQUFTLFFBQVEsQ0FBQyxlQUFlLEVBQUUsTUFBTTtJQUN2QyxNQUFNLEtBQUssR0FBRyxFQUFDLGVBQWUsRUFBRSxlQUFlLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBQyxDQUFDO0lBQ2pFLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsRUFBQyxLQUFLLEVBQUUsS0FBSyxFQUFDLENBQUMsQ0FBQztBQUMzRCxDQUFDIn0=