/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2018-04-06.
 */
'use strict';
const crypto = require('crypto');
const _ = require('lodash');
const LKE = require('../index');
const Utils = LKE.getUtils();
const Log = LKE.getLogger(__filename);
class DesignUtils {
    get PALETTE() {
        return {
            'default': [
                // dark colors
                '#9467bd', '#e377c2', '#1f77b4', '#17becf', '#2ca02c',
                '#bcbd22', '#d62728', '#ff7f0e', '#8c564b', '#7f7f7f',
                // light colors
                '#c5b0d5', '#f7b6d2', '#aec7e8', '#9edae5', '#98df8a',
                '#dbdb8d', '#ff9896', '#ffbb78', '#c49c94', '#c7c7c7'
            ]
        };
    }
    get DEFAULT_STYLES() {
        return {
            node: [this.NODE_AUTO_COLOR_RULE],
            edge: []
        };
    }
    get DEFAULT_CAPTIONS() {
        return { nodes: {}, edges: {} };
    }
    get NODE_AUTO_COLOR_RULE() {
        return {
            index: 0,
            type: 'any',
            style: {
                // coloring by category: default node-rule in LKE
                color: { type: 'auto', input: ['categories'] }
            }
        };
    }
    /**
     * Create a auto-color style for a property.
     *
     * @param {string} property
     * @returns {{type: 'any', style: {color: {type: 'auto', input: string[]}}}}
     * @private
     */
    _propertyAutoColorRule(property) {
        return {
            type: 'any',
            style: {
                color: { type: 'auto', input: ['properties', property] }
            }
        };
    }
    /**
     * Create a category style.
     *
     * @param {string} type
     * @param {string} categoryName
     * @param {object} palette
     * @returns {{type: 'any', itemType: string, style: NodeStyle | EdgeStyle}}
     * @private
     */
    _categoryRule(type, categoryName, palette) {
        return {
            type: 'any',
            itemType: categoryName,
            style: {
                [type]: palette[categoryName]
            }
        };
    }
    /**
     * Create a property style.
     *
     * @param {string} type
     * @param {string} itemType
     * @param {string} property
     * @param {string} propertyValue
     * @param {object} palette
     * @returns {{type: 'is', itemType: string, input: string[], value: string, style: NodeStyle | EdgeStyle}}
     * @private
     */
    _propertyRule(type, itemType, property, propertyValue, palette) {
        return {
            type: 'is',
            itemType: itemType,
            input: ['properties', property],
            value: propertyValue,
            style: {
                [type]: palette[propertyValue]
            }
        };
    }
    /**
     * Create style rules for a category based on a palette.
     *
     * @param {string} type
     * @param {object} palette
     * @returns {Array<{type: SelectorType, itemType: string, style: NodeStyle | EdgeStyle}>}
     * @private
     */
    _createCategoryStyle(type, palette) {
        const rules = [];
        for (const categoryName in palette) {
            rules.push(this._categoryRule(type, categoryName, palette));
        }
        return rules;
    }
    /**
     * Create style rules for a property based on a palette.
     *
     * @param {string}   type
     * @param {string[]} itemTypes
     * @param {string}   property
     * @param {object}   palette
     * @returns {Array<Partial<VisualizationStyleRule<NodeStyle | EdgeStyle>>>}
     * @private
     */
    _createPropertyStyle(type, itemTypes, property, palette) {
        const rules = [];
        if (type === 'color') {
            rules.push(this._propertyAutoColorRule(property));
        }
        for (const propertyValue in palette) {
            itemTypes.forEach(itemType => {
                rules.push(this._propertyRule(type, itemType, property, propertyValue, palette));
            });
        }
        return rules;
    }
    /**
     * Create a unified style from a given selector and palette.
     *
     * The `palette` (before LKE v2.5.0) is a collection of styles for nodes or edges.
     * Each style is designated by a `scheme` and indexed by category, type or property name which
     * is specified by the `selector`.
     *
     * @param {string}   type      Style type (color, icon, image, size)
     * @param {string[]} itemTypes The list of all known categories or types
     * @param {string}   selector  Defines which attribute of an item is used to select the style
     *                              e.g: 'data.properties.name": Use the name property to select a style
     * @param {string}   scheme    Path of styles in `palette` to be used for styling e.g: "nodes.icons.crunchbase"
     * @param {object}   palette   Collection of styles designated by all defined `schemes`
     * @returns {Array<Partial<VisualizationStyleRule<NodeStyle | EdgeStyle>>>}
     * @private
     */
    _createStyle(type, itemTypes, selector, scheme, palette) {
        const path = scheme.split('.');
        // The path is always 3 levels deep a longer path means that the propertyName contained dots
        const targetPalette = _.get(palette, [path[0], path[1], path.slice(2).join('.')]);
        if (Utils.noValue(targetPalette)) {
            // There is no guarantee that the palette designated by scheme is defined
            return [];
        }
        // `propertyName` contains dots. We make sure join it back together before a read
        const [, by, ...propertyName] = selector.split('.');
        if (by === 'properties') {
            return this._createPropertyStyle(type, itemTypes, propertyName.join('.'), targetPalette);
        }
        else {
            return this._createCategoryStyle(type, targetPalette);
        }
    }
    /**
     * Migrate a node or edge style to the unified style format.
     *
     * The unified style format unifies the item selector and item styles in a single style object.
     * Previously they were separated as a style selector object (styles)
     * and a styles definition object (palette).
     *
     * @param {string[]} itemTypes
     * @param {object}   nodeOrEdgeStyle
     * @param {object}   palette
     * @returns {Array<Partial<VisualizationStyleRule<NodeStyle | EdgeStyle>>>}
     * @private
     */
    _migrateStyle(itemTypes, nodeOrEdgeStyle, palette) {
        const rules = [];
        for (const type in nodeOrEdgeStyle) {
            const style = nodeOrEdgeStyle[type];
            try {
                Utils.check.values('type', type, ['color', 'icon', 'image', 'size']);
                this._checkStyleDefinition(style);
            }
            catch (error) {
                // We skip styles that are not correctly defined.
                Log.warn('Cannot migrate style with incorrect format. Ignored rule: ' + `${type}: ` +
                    JSON.stringify(style));
                continue;
            }
            if (type === 'size') {
                // We do not migrate size by numeric property rules
                Log.warn('Size by numeric property rules will not be migrated to ' +
                    'the new design format. Ignored rule: ' + JSON.stringify(style));
                continue;
            }
            const { active, by, scheme } = style;
            if (active) {
                // We only migrate active styles
                // A given style by category or type will result in multiple style rules,
                // one for each category found in the palette
                rules.push(this._createStyle(type, itemTypes, by, scheme, palette));
            }
        }
        return _.flatten(rules);
    }
    /**
     * Migrate styles to the unified style format.
     *
     * @param {{node: {labels: string[]}, edge: {labels: string[]}}} schema
     * @param {object}  oldStyle
     * @param {object}  oldPalette
     * @param {boolean} [autoColor=false] Whether to add an auto color rule for nodes
     * @returns {VisualizationStyleSheet}
     */
    migrateStyles(schema, oldStyle, oldPalette, autoColor = false) {
        // The index is carried from node styles to edge styles
        let maxIndex = -1;
        const addIndex = style => {
            style.index = ++maxIndex;
            return style;
        };
        const migratedStyles = this._migrateStyle(schema.node.labels, oldStyle.nodes, oldPalette);
        const nodeStyles = autoColor
            ? [this.NODE_AUTO_COLOR_RULE, ...migratedStyles]
            : migratedStyles;
        const edgeStyles = this._migrateStyle(schema.edge.labels, oldStyle.edges, oldPalette);
        return {
            node: nodeStyles.map(addIndex),
            edge: edgeStyles.map(addIndex)
        };
    }
    /**
     * Pick a color from `palette` based on `input` value.
     *
     * @param {string}   input
     * @param {string[]} palette
     * @returns {string}
     */
    pickFromPalette(input, palette) {
        // Auto color rules can only pick grey colors for nodes with no category
        // so we filter out grey colors.
        const colors = palette.filter(color => color !== '#7f7f7f' && color !== '#c7c7c7');
        return colors[this._sha1Modulo(input, colors.length)];
    }
    /**
     * @param {string} input
     * @returns {string}
     * @private
     */
    _sha1(input) {
        const generator = crypto.createHash('sha1');
        generator.update(input);
        return generator.digest('hex');
    }
    /**
     * @param {string}  input
     * @param {number}  modulo
     * @param {boolean} [ignoreCase]
     * @returns {number}
     * @private
     */
    _sha1Modulo(input, modulo, ignoreCase) {
        if (typeof input === 'string' && ignoreCase) {
            input = input.toLowerCase();
        }
        // 1) get the 4 last hex chars (8 last bytes) for sha1
        // 2) parse to integer
        // 3) compute modulo
        return Number.parseInt('0x' + this._sha1(input).substr(-4), 16) % modulo;
    }
    /**
     * Check style definition (before LKE v2.5.0 format).
     *
     * @param {object} style
     * @private
     */
    _checkStyleDefinition(style) {
        const styleProperties = {
            active: {
                required: true,
                type: 'boolean'
            },
            by: {
                required: true,
                check: (key, value) => Utils.check.regexp(key, value, /^data\.(categories|properties|type)/)
            },
            scheme: {
                required: true,
                check: (key, value) => Utils.check.regexp(key, value, /^(nodes|edges)\.(.+?)\.(.+)/)
            }
        };
        Utils.check.properties('style', style, styleProperties, 'inclusive');
    }
}
module.exports = new DesignUtils();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVzaWduVXRpbHMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvYnVzaW5lc3MvZGVzaWduVXRpbHMuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFDYixNQUFNLE1BQU0sR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDakMsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVCLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNoQyxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxHQUFHLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUV0QyxNQUFNLFdBQVc7SUFDZixJQUFJLE9BQU87UUFDVCxPQUFPO1lBQ0wsU0FBUyxFQUFFO2dCQUNULGNBQWM7Z0JBQ2QsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVM7Z0JBQ3JELFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTO2dCQUNyRCxlQUFlO2dCQUNmLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTO2dCQUNyRCxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUzthQUN0RDtTQUNGLENBQUM7SUFDSixDQUFDO0lBRUQsSUFBSSxjQUFjO1FBQ2hCLE9BQU87WUFDTCxJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUM7WUFDakMsSUFBSSxFQUFFLEVBQUU7U0FDVCxDQUFDO0lBQ0osQ0FBQztJQUVELElBQUksZ0JBQWdCO1FBQ2xCLE9BQU8sRUFBQyxLQUFLLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUMsQ0FBQztJQUNoQyxDQUFDO0lBRUQsSUFBSSxvQkFBb0I7UUFDdEIsT0FBTztZQUNMLEtBQUssRUFBRSxDQUFDO1lBQ1IsSUFBSSxFQUFFLEtBQUs7WUFDWCxLQUFLLEVBQUU7Z0JBQ0wsaURBQWlEO2dCQUNqRCxLQUFLLEVBQUUsRUFBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxDQUFDLFlBQVksQ0FBQyxFQUFDO2FBQzdDO1NBQ0YsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxzQkFBc0IsQ0FBQyxRQUFRO1FBQzdCLE9BQU87WUFDTCxJQUFJLEVBQUUsS0FBSztZQUNYLEtBQUssRUFBRTtnQkFDTCxLQUFLLEVBQUUsRUFBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxDQUFDLFlBQVksRUFBRSxRQUFRLENBQUMsRUFBQzthQUN2RDtTQUNGLENBQUM7SUFDSixDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSCxhQUFhLENBQUMsSUFBSSxFQUFFLFlBQVksRUFBRSxPQUFPO1FBQ3ZDLE9BQU87WUFDTCxJQUFJLEVBQUUsS0FBSztZQUNYLFFBQVEsRUFBRSxZQUFZO1lBQ3RCLEtBQUssRUFBRTtnQkFDTCxDQUFDLElBQUksQ0FBQyxFQUFFLE9BQU8sQ0FBQyxZQUFZLENBQUM7YUFDOUI7U0FDRixDQUFDO0lBQ0osQ0FBQztJQUVEOzs7Ozs7Ozs7O09BVUc7SUFDSCxhQUFhLENBQUMsSUFBSSxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsYUFBYSxFQUFFLE9BQU87UUFDNUQsT0FBTztZQUNMLElBQUksRUFBRSxJQUFJO1lBQ1YsUUFBUSxFQUFFLFFBQVE7WUFDbEIsS0FBSyxFQUFFLENBQUMsWUFBWSxFQUFFLFFBQVEsQ0FBQztZQUMvQixLQUFLLEVBQUUsYUFBYTtZQUNwQixLQUFLLEVBQUU7Z0JBQ0wsQ0FBQyxJQUFJLENBQUMsRUFBRSxPQUFPLENBQUMsYUFBYSxDQUFDO2FBQy9CO1NBQ0YsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsb0JBQW9CLENBQUMsSUFBSSxFQUFFLE9BQU87UUFDaEMsTUFBTSxLQUFLLEdBQUcsRUFBRSxDQUFDO1FBQ2pCLEtBQUssTUFBTSxZQUFZLElBQUksT0FBTyxFQUFFO1lBQ2xDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLEVBQUUsWUFBWSxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUM7U0FDN0Q7UUFDRCxPQUFPLEtBQUssQ0FBQztJQUNmLENBQUM7SUFFRDs7Ozs7Ozs7O09BU0c7SUFDSCxvQkFBb0IsQ0FBQyxJQUFJLEVBQUUsU0FBUyxFQUFFLFFBQVEsRUFBRSxPQUFPO1FBQ3JELE1BQU0sS0FBSyxHQUFHLEVBQUUsQ0FBQztRQUNqQixJQUFJLElBQUksS0FBSyxPQUFPLEVBQUU7WUFDcEIsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsc0JBQXNCLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztTQUNuRDtRQUNELEtBQUssTUFBTSxhQUFhLElBQUksT0FBTyxFQUFFO1lBQ25DLFNBQVMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEVBQUU7Z0JBQzNCLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxhQUFhLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQztZQUNuRixDQUFDLENBQUMsQ0FBQztTQUNKO1FBQ0QsT0FBTyxLQUFLLENBQUM7SUFDZixDQUFDO0lBRUQ7Ozs7Ozs7Ozs7Ozs7OztPQWVHO0lBQ0gsWUFBWSxDQUFDLElBQUksRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxPQUFPO1FBQ3JELE1BQU0sSUFBSSxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDL0IsNEZBQTRGO1FBQzVGLE1BQU0sYUFBYSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDbEYsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxFQUFFO1lBQ2hDLHlFQUF5RTtZQUN6RSxPQUFPLEVBQUUsQ0FBQztTQUNYO1FBQ0QsaUZBQWlGO1FBQ2pGLE1BQU0sQ0FBQyxFQUFFLEVBQUUsRUFBRSxHQUFHLFlBQVksQ0FBQyxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDcEQsSUFBSSxFQUFFLEtBQUssWUFBWSxFQUFFO1lBQ3ZCLE9BQU8sSUFBSSxDQUFDLG9CQUFvQixDQUFDLElBQUksRUFBRSxTQUFTLEVBQUUsWUFBWSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxhQUFhLENBQUMsQ0FBQztTQUMxRjthQUFNO1lBQ0wsT0FBTyxJQUFJLENBQUMsb0JBQW9CLENBQUMsSUFBSSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1NBQ3ZEO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7T0FZRztJQUNILGFBQWEsQ0FBQyxTQUFTLEVBQUUsZUFBZSxFQUFFLE9BQU87UUFDL0MsTUFBTSxLQUFLLEdBQUcsRUFBRSxDQUFDO1FBQ2pCLEtBQUssTUFBTSxJQUFJLElBQUksZUFBZSxFQUFFO1lBQ2xDLE1BQU0sS0FBSyxHQUFHLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNwQyxJQUFJO2dCQUNGLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDO2dCQUNyRSxJQUFJLENBQUMscUJBQXFCLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDbkM7WUFBQyxPQUFNLEtBQUssRUFBRTtnQkFDYixpREFBaUQ7Z0JBQ2pELEdBQUcsQ0FBQyxJQUFJLENBQUMsNERBQTRELEdBQUcsR0FBRyxJQUFJLElBQUk7b0JBQ2pGLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztnQkFDekIsU0FBUzthQUNWO1lBQ0QsSUFBSSxJQUFJLEtBQUssTUFBTSxFQUFFO2dCQUNuQixtREFBbUQ7Z0JBQ25ELEdBQUcsQ0FBQyxJQUFJLENBQUMseURBQXlEO29CQUNoRSx1Q0FBdUMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7Z0JBQ25FLFNBQVM7YUFDVjtZQUNELE1BQU0sRUFBQyxNQUFNLEVBQUUsRUFBRSxFQUFFLE1BQU0sRUFBQyxHQUFHLEtBQUssQ0FBQztZQUNuQyxJQUFJLE1BQU0sRUFBRTtnQkFDVixnQ0FBZ0M7Z0JBQ2hDLHlFQUF5RTtnQkFDekUsNkNBQTZDO2dCQUM3QyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUUsTUFBTSxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUM7YUFDckU7U0FDRjtRQUNELE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUMxQixDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSCxhQUFhLENBQUMsTUFBTSxFQUFFLFFBQVEsRUFBRSxVQUFVLEVBQUUsU0FBUyxHQUFHLEtBQUs7UUFDM0QsdURBQXVEO1FBQ3ZELElBQUksUUFBUSxHQUFHLENBQUMsQ0FBQyxDQUFDO1FBQ2xCLE1BQU0sUUFBUSxHQUFHLEtBQUssQ0FBQyxFQUFFO1lBQ3ZCLEtBQUssQ0FBQyxLQUFLLEdBQUcsRUFBRSxRQUFRLENBQUM7WUFDekIsT0FBTyxLQUFLLENBQUM7UUFDZixDQUFDLENBQUM7UUFDRixNQUFNLGNBQWMsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLFFBQVEsQ0FBQyxLQUFLLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFDMUYsTUFBTSxVQUFVLEdBQUcsU0FBUztZQUMxQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLEVBQUUsR0FBRyxjQUFjLENBQUM7WUFDaEQsQ0FBQyxDQUFDLGNBQWMsQ0FBQztRQUNuQixNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLFFBQVEsQ0FBQyxLQUFLLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFDdEYsT0FBTztZQUNMLElBQUksRUFBRSxVQUFVLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQztZQUM5QixJQUFJLEVBQUUsVUFBVSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUM7U0FDL0IsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxlQUFlLENBQUMsS0FBSyxFQUFFLE9BQU87UUFDNUIsd0VBQXdFO1FBQ3hFLGdDQUFnQztRQUNoQyxNQUFNLE1BQU0sR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsS0FBSyxLQUFLLFNBQVMsSUFBSSxLQUFLLEtBQUssU0FBUyxDQUFDLENBQUM7UUFDbkYsT0FBTyxNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7SUFDeEQsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxLQUFLLENBQUMsS0FBSztRQUNULE1BQU0sU0FBUyxHQUFHLE1BQU0sQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDNUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN4QixPQUFPLFNBQVMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDakMsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILFdBQVcsQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLFVBQVU7UUFDbkMsSUFBSSxPQUFPLEtBQUssS0FBSyxRQUFRLElBQUksVUFBVSxFQUFFO1lBQzNDLEtBQUssR0FBRyxLQUFLLENBQUMsV0FBVyxFQUFFLENBQUM7U0FDN0I7UUFDRCxzREFBc0Q7UUFDdEQsc0JBQXNCO1FBQ3RCLG9CQUFvQjtRQUNwQixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLEdBQUcsTUFBTSxDQUFDO0lBQzNFLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILHFCQUFxQixDQUFDLEtBQUs7UUFDekIsTUFBTSxlQUFlLEdBQUc7WUFDdEIsTUFBTSxFQUFFO2dCQUNOLFFBQVEsRUFBRSxJQUFJO2dCQUNkLElBQUksRUFBRSxTQUFTO2FBQ2hCO1lBQ0QsRUFBRSxFQUFFO2dCQUNGLFFBQVEsRUFBRSxJQUFJO2dCQUNkLEtBQUssRUFBRSxDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQ2xELHFDQUFxQyxDQUFDO2FBQ3pDO1lBQ0QsTUFBTSxFQUFFO2dCQUNOLFFBQVEsRUFBRSxJQUFJO2dCQUNkLEtBQUssRUFBRSxDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQ2xELDZCQUE2QixDQUFDO2FBQ2pDO1NBQ0YsQ0FBQztRQUNGLEtBQUssQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxLQUFLLEVBQUUsZUFBZSxFQUFFLFdBQVcsQ0FBQyxDQUFDO0lBQ3ZFLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsSUFBSSxXQUFXLEVBQUUsQ0FBQyJ9