/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-04-20.
 */
'use strict';
const _ = require('lodash');
const LKE = require('../index');
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
const VisualizationChecker = require('../business/VisualizationChecker');
/**
 * @backward-compatibility Pre v2.5 design palette
 */
const OLD_PALETTE_PROPERTIES = {
    nodes: {
        properties: {
            qualitative: {
                // keys: name of qualitative palette
                anyProperty: {
                    // keys: size of the palette
                    anyProperty: {
                        // color OR array of hex colors
                        check: (key, value) => {
                            if (typeof value === 'string') {
                                return Utils.check.cssColor(key, value);
                            }
                            else {
                                return Utils.check.property(key, value, {
                                    arrayItem: { check: 'hexColor' }
                                });
                            }
                        }
                    }
                }
            },
            sequential: {
                // keys: size of the palette
                anyProperty: {
                    // array of hex colors
                    arrayItem: { check: 'hexColor' }
                }
            },
            icons: {
                // keys: name of the property on which the icon is mapped
                anyProperty: {
                    // keys: value of the property for this icon
                    anyProperty: {
                        properties: {
                            font: { check: 'nonEmpty' },
                            color: { check: 'hexColor' },
                            scale: { check: ['number', 0] },
                            content: { check: 'nonEmpty' }
                        }
                    }
                }
            },
            images: {
                // by image palette name (.e.g. "crunchbase")
                anyProperty: {
                    // by property/node-category/edge-type value (e.g. "CITY" for a node-category scheme, or "Paris" for a property scheme)
                    anyProperty: {
                        properties: {
                            // URL of the image
                            url: { required: true, type: 'string' },
                            // scaling ratio of the image
                            scale: { type: 'number' },
                            // clip ratio of the image (?)
                            clip: { type: 'number' }
                        }
                    }
                }
            }
        }
    },
    edges: {
        properties: {
            qualitative: {
                // keys: name of qualitative palette
                anyProperty: {
                    // keys: size of the palette
                    anyProperty: {
                        // color OR array of hex colors
                        check: (key, value) => {
                            if (typeof value === 'string') {
                                return Utils.check.cssColor(key, value);
                            }
                            else {
                                return Utils.check.property(key, value, {
                                    arrayItem: { check: 'hexColor' }
                                });
                            }
                        }
                        //arrayItem: {check: 'hexColor'}
                    }
                }
            },
            sequential: {
                // keys: size of the palette
                anyProperty: {
                    // array of hex colors
                    arrayItem: { check: 'hexColor' }
                }
            }
        }
    }
};
const CONFIG_PROPERTIES = {
    // data-source array
    dataSources: {
        required: true,
        arrayItem: {
            required: true,
            properties: {
                deleted: { type: 'boolean' },
                name: { type: 'string' },
                manualSourceKey: { check: (key, value) => Utils.checkSourceKey(value) },
                readOnly: { type: 'boolean' },
                graphdb: {
                    required: true,
                    type: 'object',
                    check: (key, value) => ConfigChecker.checkGraph(key, value)
                },
                index: {
                    required: true,
                    type: 'object',
                    check: (key, value) => ConfigChecker.checkIndex(key, value)
                }
            }
        }
    },
    // cross-sources parameters
    advanced: {
        required: true,
        properties: {
            supernodeThreshold: { required: true, check: ['integer', 1] },
            expandThreshold: { required: true, check: ['integer', 1] },
            rawQueryLimit: { required: true, check: ['integer', 1] },
            searchAddAllThreshold: { required: true, check: ['integer', 1] },
            minSearchQueryLength: { required: true, check: ['integer', 1] },
            rawQueryTimeout: { required: true, check: ['integer', 1] },
            sampledItemsPerType: { required: true, check: ['posInt'] },
            sampledVisualizationItems: { required: true, check: ['posInt'] },
            defaultTimezone: { required: true, check: ['regexp', /^([+-])(\d{2}):(\d{2})$|^(Z)$/] },
            timeline: { required: true, type: 'boolean' },
            connectionRetries: { check: ['posInt'] },
            pollInterval: { check: ['integer', 1] },
            indexationChunkSize: { check: ['integer', 1] },
            layoutWorkers: { check: 'posInt' },
            defaultFuzziness: { check: ['number', 0, 1] },
            extraCertificateAuthorities: { check: 'file' },
            obfuscation: { type: 'boolean' },
            edgesBetweenSupernodes: { type: 'boolean' }
        }
    },
    // internal database config
    db: {
        required: true,
        properties: {
            name: { required: true, check: 'nonEmpty' },
            username: { check: 'nonEmpty' },
            password: { check: 'nonEmpty' },
            connectionRetries: { check: ['posInt', 1] },
            options: {
                type: 'object',
                check: (key, value) => ConfigChecker.checkDbOptions(key, value)
            }
        }
    },
    // backend http server configuration
    server: {
        required: true,
        properties: {
            listenPort: { required: true, check: 'port' },
            clientFolder: { required: true, check: 'nonEmpty' },
            cookieSecret: { check: 'nonEmpty' },
            allowOrigin: { type: ['string', 'array'] },
            domain: { check: 'nonEmpty' },
            baseFolder: { check: ['regexp', /^[a-zA-Z0-9\-_]+$/] },
            publicPortHttp: { check: 'integer' },
            publicPortHttps: { check: 'integer' },
            cookieDomain: { check: 'nonEmpty' },
            // https
            listenPortHttps: { check: 'port' },
            useHttps: { type: 'boolean' },
            forceHttps: { type: 'boolean' },
            certificateFile: { check: 'nonEmpty' },
            certificateKeyFile: { check: 'nonEmpty' },
            certificatePassphrase: { check: 'nonEmpty' } // custom certificate pass-phrase
        }
    },
    defaultPreferences: {
        required: true,
        type: 'object',
        check: (key, value) => ConfigChecker.checkPreferences(key, value)
    },
    guestPreferences: {
        required: true,
        type: 'object',
        check: (key, value) => ConfigChecker.checkPreferences(key, value, true)
    },
    // Captions used by default in visualizations
    // @backward-compatibility default captions removed in LKE v2.5.0
    defaultCaptions: { check: (key, value) => VisualizationChecker.checkCaptions(key, value) },
    alerts: {
        properties: {
            enabled: { type: 'boolean' },
            maxMatchTTL: { check: ['integer', 0] },
            maxMatchesLimit: { check: ['integer', 1] },
            maxRuntimeLimit: { check: ['integer', 1] },
            maxConcurrency: { check: ['integer', 1] }
        }
    },
    // audit-trail configuration
    auditTrail: {
        required: true,
        properties: {
            enabled: { type: 'boolean' },
            logFolder: { check: 'nonEmpty' },
            fileSizeLimit: { check: ['integer', 100 * 1024] },
            strictMode: { type: 'boolean' },
            logResult: { type: 'boolean' },
            mode: { values: ['r', 'w', 'rw'] }
        }
    },
    // authentication configuration
    access: {
        required: true,
        properties: {
            floatingLicenses: { check: ['integer', 1] },
            authRequired: { type: 'boolean' },
            guestMode: { type: 'boolean' },
            defaultPage: { type: 'string' },
            defaultPageParams: { type: 'object' },
            dataEdition: { type: 'boolean' },
            widget: { type: 'boolean' },
            loginTimeout: { check: ['integer', 60] },
            externalUsersAllowedGroups: { arrayItem: { type: ['string', 'number'] } },
            externalUserDefaultGroupId: { check: (key, value) => {
                    Utils.check.type(key, value, ['number', 'array']);
                    if (Array.isArray(value)) {
                        Utils.check.intArray(key, value);
                    }
                    else {
                        Utils.check.integer(key, value);
                    }
                } },
            externalUsersGroupMapping: {
                anyProperty: {
                    check: (key, value) => {
                        Utils.check.type(key, value, ['number', 'array']);
                        if (Array.isArray(value)) {
                            Utils.check.intArray(key, value);
                        }
                        else {
                            Utils.check.integer(key, value);
                        }
                    }
                }
            },
            autoRefreshGroupMapping: { required: false, type: 'boolean' },
            // @backward-compatibility old Azure AD configuration
            azureActiveDirectory: {
                deprecated: 'Use "access.oauth2" with provider "azure" instead'
            },
            // Microsoft AD configuration
            msActiveDirectory: {
                properties: {
                    enabled: { type: 'boolean' },
                    url: { check: 'nonEmpty' },
                    baseDN: { check: 'nonEmpty' },
                    domain: { check: 'nonEmpty' },
                    netbiosDomain: { check: 'nonEmpty' },
                    tls: {
                        required: false,
                        policy: 'inclusive',
                        // actually accepts for all `tls.connect` options
                        // see https://nodejs.org/api/tls.html#tls_tls_connect_options_callback
                        properties: {
                            // whether to reject servers with self signed certificates
                            rejectUnauthorized: { type: 'boolean' }
                        }
                    }
                }
            },
            // OpenLDAP configuration
            ldap: {
                properties: {
                    enabled: { required: true, type: 'boolean' },
                    url: { required: true, check: 'nonEmpty' },
                    bindDN: { requiredIf: 'bindPassword', type: 'string' },
                    bindPassword: { requiredIf: 'bindDN', type: 'string' },
                    baseDN: { required: true,
                        check: (key, value) => {
                            if (typeof value === 'string') {
                                Utils.check.nonEmpty(key, value);
                            }
                            else {
                                Utils.check.stringArray(key, value, 1, undefined, true);
                            }
                        }
                    },
                    usernameField: { required: true, check: 'nonEmpty' },
                    emailField: { check: 'nonEmpty' },
                    groupField: { check: 'nonEmpty' },
                    // @backward-compatibility old way to filter authorized groups in LDAP
                    authorizedGroups: { deprecated: 'Use "access.externalUsersAllowedGroups" instead' },
                    tls: {
                        required: false,
                        policy: 'inclusive',
                        // actually accepts for all `tls.connect` options
                        // see https://nodejs.org/api/tls.html#tls_tls_connect_options_callback
                        properties: {
                            // whether to reject servers with self signed certificates
                            rejectUnauthorized: { type: 'boolean' }
                        }
                    }
                }
            },
            // saml2 configuration
            saml2: {
                properties: {
                    enabled: { required: true, type: 'boolean' },
                    url: { required: true, check: 'nonEmpty' },
                    identityProviderCertificate: { required: true, check: 'nonEmpty' },
                    groupAttribute: { check: 'nonEmpty' },
                    emailAttribute: { check: 'nonEmpty' }
                }
            },
            // oauth2 configuration
            oauth2: {
                properties: {
                    enabled: { required: true, type: 'boolean' },
                    provider: { required: true, check: 'nonEmpty' },
                    authorizationURL: { required: true, check: 'url' },
                    tokenURL: { required: true, check: 'url' },
                    clientID: { required: true, check: 'nonEmpty' },
                    clientSecret: { required: true, check: 'nonEmpty' },
                    openidconnect: {
                        properties: {
                            userinfoURL: { requiredIf: 'groupClaim', check: 'url' },
                            scope: { requiredIf: 'groupClaim', check: 'nonEmpty' },
                            groupClaim: { check: 'nonEmpty' }
                        }
                    },
                    azure: {
                        properties: {
                            tenantID: { check: 'nonEmpty' }
                        }
                    }
                }
            }
        }
    },
    // leaflet tile layers configuration
    leaflet: {
        required: true,
        arrayItem: {
            required: true,
            properties: {
                name: { required: true, check: 'nonEmpty' },
                urlTemplate: { required: true, check: 'httpUrl' },
                attribution: { required: true, check: 'nonEmpty' },
                minZoom: { required: true, check: ['integer', 1] },
                maxZoom: { required: true, check: ['integer', 1, 60] },
                thumbnail: { required: true, check: 'string' },
                subdomains: { check: 'nonEmpty' },
                id: { check: 'nonEmpty' },
                accessToken: { check: 'nonEmpty' },
                overlay: { type: 'boolean' } // whether this layer is an overlay
            }
        }
    },
    // ogma configuration
    ogma: {
        required: true,
        properties: {
            renderer: { values: ['webgl', 'canvas'] },
            webglOptions: {
                properties: {
                    antiAliasing: { values: ['super-sampling', 'native', 'none'] },
                    fontSamplingSize: { check: ['integer', 1] }
                }
            },
            imgCrossOrigin: { values: ['anonymous', 'use-credentials'] },
            options: { type: 'object' }
        }
    },
    // @backward-compatibility default styles removed in LKE v2.5.0
    defaultStyles: {
        required: false,
        properties: {
            nodes: { type: 'object' },
            edges: { type: 'object' }
        }
    },
    // palettes config
    palette: {
        check: (key, value) => {
            // @backward-compatibility palette removed in LKE v2.5.0
            Utils.check.properties(key, value, OLD_PALETTE_PROPERTIES);
        }
    },
    // first run flag
    firstRun: { type: 'boolean' },
    // config version
    version: { type: 'string' },
    // Unique Id of the customer in Linkurious
    customerId: {
        type: 'string',
        check: Utils.validateCustomerId
    },
    // used in tests
    testSetting: {}
};
class ConfigChecker {
    /**
     * @param {any} config
     * @throws {LkError} the configuration validation error, if any.
     */
    static check(config) {
        Utils.check.properties('configuration', config, CONFIG_PROPERTIES);
    }
    /**
     * @param {string} key
     * @param {any}    dbOptions
     */
    static checkDbOptions(key, dbOptions) {
        Utils.check.values(key + '.dialect', dbOptions.dialect, ['sqlite', 'mysql', 'mariadb', 'mssql']);
        if (dbOptions.dialect === 'sqlite') {
            Utils.check.properties(key, dbOptions, {
                dialect: { values: [dbOptions.dialect] },
                storage: { check: 'nonEmpty' }
            });
        }
        else {
            Utils.check.properties(key, dbOptions, {
                dialect: { values: [dbOptions.dialect] },
                host: { check: 'nonEmpty' },
                port: { check: 'port' }
            });
        }
    }
    /**
     * @param {string}  key
     * @param {any}     preferences
     * @param {boolean} [isGuestPreferences]
     */
    static checkPreferences(key, preferences, isGuestPreferences) {
        let properties = {
            locale: { required: true, check: (key, value) => {
                    Utils.check.string(key, value, true, true, 5, 5); // valid example: "en-US"
                    // if 3rd character is not '-' throw an error
                    if (value[2] !== '-') {
                        throw Errors.business('invalid_parameter', `"${key}" must be a valid locale.`);
                    }
                } }
        };
        if (isGuestPreferences) {
            properties = _.merge(properties, {
                uiWorkspaceSearch: { required: true, type: 'boolean' },
                uiExport: { required: true, type: 'boolean' },
                uiLayout: { required: true, values: ['regular', 'simple', 'none'] },
                uiDesign: { required: true, type: 'boolean' },
                uiFilter: { required: true, type: 'boolean' }
            });
        }
        else {
            // User preferences
            properties = _.merge(properties, {
                pinOnDrag: { required: true, type: 'boolean' },
                incrementalLayout: { required: true, type: 'boolean' }
            });
        }
        Utils.check.properties('configuration', preferences, properties);
    }
    /**
     * @param {string} key
     * @param {any}    graphdb
     */
    static checkGraph(key, graphdb) {
        Utils.check.values(key + '.vendor', graphdb.vendor, [
            'neo4j', 'janusGraph', 'janusGraphForCompose', 'cosmosDb'
        ]);
        let properties = {
            vendor: { required: true, values: [graphdb.vendor] },
            latitudeProperty: { check: 'nonEmpty' },
            longitudeProperty: { check: 'nonEmpty' },
            // Every GraphDAO "should" allowSelfSigned
            allowSelfSigned: { type: 'boolean' }
        };
        const alternativeIdsProperties = {
            alternativeEdgeId: { check: 'nonEmpty' },
            alternativeNodeId: { check: 'nonEmpty' }
        };
        const userPasswordAuthProperties = {
            user: { check: 'nonEmpty' },
            password: { check: 'nonEmpty' }
        };
        // These options are applicable when the GraphDAO uses a session to communicate with gremlin server
        const gremlinSessionProperties = {
            maxStale: { check: 'posInt' },
            sessionPool: { check: ['integer', 1] }
        };
        const disableIndexExistCheckProperties = {
            disableIndexExistCheck: { type: 'boolean' }
        };
        switch (graphdb.vendor) {
            case 'neo4j':
                properties = _.merge(properties, {
                    url: { required: true, check: 'url' },
                    proxy: { check: 'nonEmpty' },
                    writeURL: { check: 'httpUrl' }
                });
                properties = _.merge(properties, userPasswordAuthProperties);
                properties = _.merge(properties, alternativeIdsProperties);
                break;
            case 'janusGraph':
                properties = _.merge(properties, {
                    url: { required: true, check: 'url' },
                    // At least one of the three has to be defined
                    graphAlias: { check: 'nonEmpty' },
                    traversalSourceAlias: { check: 'nonEmpty' },
                    configurationPath: { check: 'nonEmpty' },
                    configuration: { type: 'object' }
                });
                properties = _.merge(properties, userPasswordAuthProperties);
                properties = _.merge(properties, alternativeIdsProperties);
                properties = _.merge(properties, disableIndexExistCheckProperties);
                properties = _.merge(properties, gremlinSessionProperties);
                Utils.check.exclusive(key, graphdb, ['graphAlias', 'configurationPath', 'configuration'], true);
                break;
            case 'janusGraphForCompose':
                properties = _.merge(properties, {
                    url: { required: true, check: 'url' },
                    graphName: { required: true, check: 'nonEmpty' },
                    create: { type: 'boolean' }
                });
                properties = _.merge(properties, userPasswordAuthProperties);
                properties = _.merge(properties, alternativeIdsProperties);
                properties = _.merge(properties, disableIndexExistCheckProperties);
                properties = _.merge(properties, gremlinSessionProperties);
                break;
            case 'cosmosDb':
                properties = _.merge(properties, {
                    url: { required: true, check: 'url' },
                    database: { required: true, check: 'nonEmpty' },
                    collection: { required: true, check: 'nonEmpty' },
                    primaryKey: { required: true, check: 'nonEmpty' },
                    '.NET SDK URI': { required: false, check: 'url' }
                });
                break;
        }
        Utils.check.properties(key, graphdb, properties);
    }
    /**
     * @param {string} key
     * @param {any}    index
     */
    static checkIndex(key, index) {
        Utils.check.values(key + '.vendor', index.vendor, [
            'elasticSearch', 'elasticSearch2', 'neo2es',
            'neo4jSearch', 'janusGraphSearch', 'azureSearch'
        ]);
        let properties = {
            vendor: { required: true, values: [index.vendor] }
        };
        switch (index.vendor) {
            case 'elasticSearch':
                properties = _.merge(properties, {
                    host: { required: true, check: 'nonEmpty' },
                    port: { required: true, check: 'port' },
                    forceReindex: { type: 'boolean' },
                    skipEdgeIndexation: { type: 'boolean' },
                    dynamicMapping: { type: 'boolean' },
                    dateDetection: { type: 'boolean' },
                    //url: {check: 'httpUrl'},
                    https: { type: 'boolean' },
                    indexName: { type: 'string' },
                    mapping: { type: 'object' },
                    analyzer: { type: 'string' },
                    user: { check: 'nonEmpty' },
                    password: { check: 'nonEmpty' }
                });
                break;
            case 'elasticSearch2':
                properties = _.merge(properties, {
                    host: { required: true, check: 'nonEmpty' },
                    port: { required: true, check: 'port' },
                    forceReindex: { type: 'boolean' },
                    https: { type: 'boolean' },
                    user: { check: 'nonEmpty' },
                    password: { check: 'nonEmpty' },
                    dynamicMapping: { type: 'boolean' },
                    forceStringMapping: { arrayItem: { check: 'nonEmpty' } },
                    analyzer: { type: 'string' },
                    // "indexName" is a internal option of the DAO, it should never be in the configuration
                    skipEdgeIndexation: { type: 'boolean' },
                    caCert: { type: 'string' },
                    simplifiedSearch: { type: 'boolean' }
                });
                break;
            case 'neo2es':
                properties = _.merge(properties, {
                    simplifiedSearch: { type: 'boolean' }
                });
                break;
            case 'neo4jSearch':
                properties = _.merge(properties, {
                    initialization: { check: 'boolean' },
                    indexEdges: { type: 'boolean' },
                    simplifiedSearch: { type: 'boolean' },
                    // @backward-compatibility
                    nodeIndexName: {
                        deprecated: 'User defined indexes are no longer supported and they will be ignored.'
                    },
                    edgeIndexName: {
                        deprecated: 'User defined indexes are no longer supported and they will be ignored.'
                    },
                    categoriesToIndex: {
                        deprecated: 'List of node categories to index is now defined by the schema.'
                    },
                    edgeTypesToIndex: {
                        deprecated: 'List of edge types to index is now defined by the schema.'
                    },
                    batchSize: {
                        deprecated: 'No longer used by Neo4jSearch after Neo4j 3.5.1.'
                    },
                    numberOfThreads: {
                        deprecated: 'No longer used by Neo4jSearch after Neo4j 3.5.1.'
                    },
                    initialOffsetNodes: {
                        deprecated: 'No longer used by Neo4jSearch after Neo4j 3.5.1.'
                    },
                    initialOffsetEdges: {
                        deprecated: 'No longer used by Neo4jSearch after Neo4j 3.5.1.'
                    }
                });
                break;
            case 'janusGraphSearch':
                properties = _.merge(properties, {
                    create: { type: 'boolean' },
                    indexEdges: { type: 'boolean' },
                    nodeIndexName: { type: 'string' },
                    edgeIndexName: { type: 'string' }
                });
                break;
            case 'azureSearch':
                properties = _.merge(properties, {
                    url: { required: true, check: 'url' },
                    apiKey: { required: true, check: 'nonEmpty' },
                    nodeIndexName: { required: true, check: 'nonEmpty' },
                    edgeIndexName: { check: 'nonEmpty' }
                });
                break;
        }
        Utils.check.properties(key, index, properties);
    }
}
module.exports = ConfigChecker;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQ29uZmlnQ2hlY2tlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9zZXJ2aWNlcy9jb25maWd1cmF0aW9uL0NvbmZpZ0NoZWNrZXIuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFFYixNQUFNLENBQUMsR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDNUIsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ2hDLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxvQkFBb0IsR0FBRyxPQUFPLENBQUMsa0NBQWtDLENBQUMsQ0FBQztBQUV6RTs7R0FFRztBQUNILE1BQU0sc0JBQXNCLEdBQUc7SUFDN0IsS0FBSyxFQUFFO1FBQ0wsVUFBVSxFQUFFO1lBQ1YsV0FBVyxFQUFFO2dCQUNYLG9DQUFvQztnQkFDcEMsV0FBVyxFQUFFO29CQUNYLDRCQUE0QjtvQkFDNUIsV0FBVyxFQUFFO3dCQUNYLCtCQUErQjt3QkFDL0IsS0FBSyxFQUFFLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRSxFQUFFOzRCQUNwQixJQUFJLE9BQU8sS0FBSyxLQUFLLFFBQVEsRUFBRTtnQ0FDN0IsT0FBTyxLQUFLLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUM7NkJBQ3pDO2lDQUFNO2dDQUNMLE9BQU8sS0FBSyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRTtvQ0FDdEMsU0FBUyxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztpQ0FDL0IsQ0FBQyxDQUFDOzZCQUNKO3dCQUNILENBQUM7cUJBQ0Y7aUJBQ0Y7YUFDRjtZQUNELFVBQVUsRUFBRTtnQkFDViw0QkFBNEI7Z0JBQzVCLFdBQVcsRUFBRTtvQkFDWCxzQkFBc0I7b0JBQ3RCLFNBQVMsRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7aUJBQy9CO2FBQ0Y7WUFDRCxLQUFLLEVBQUU7Z0JBQ0wseURBQXlEO2dCQUN6RCxXQUFXLEVBQUU7b0JBQ1gsNENBQTRDO29CQUM1QyxXQUFXLEVBQUU7d0JBQ1gsVUFBVSxFQUFFOzRCQUNWLElBQUksRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7NEJBQ3pCLEtBQUssRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7NEJBQzFCLEtBQUssRUFBRSxFQUFDLEtBQUssRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsRUFBQzs0QkFDN0IsT0FBTyxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQzt5QkFDN0I7cUJBQ0Y7aUJBQ0Y7YUFDRjtZQUNELE1BQU0sRUFBRTtnQkFDTiw2Q0FBNkM7Z0JBQzdDLFdBQVcsRUFBRTtvQkFDWCx1SEFBdUg7b0JBQ3ZILFdBQVcsRUFBRTt3QkFDWCxVQUFVLEVBQUU7NEJBQ1YsbUJBQW1COzRCQUNuQixHQUFHLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUM7NEJBQ3JDLDZCQUE2Qjs0QkFDN0IsS0FBSyxFQUFFLEVBQUMsSUFBSSxFQUFFLFFBQVEsRUFBQzs0QkFDdkIsOEJBQThCOzRCQUM5QixJQUFJLEVBQUUsRUFBQyxJQUFJLEVBQUUsUUFBUSxFQUFDO3lCQUN2QjtxQkFDRjtpQkFDRjthQUNGO1NBQ0Y7S0FDRjtJQUNELEtBQUssRUFBRTtRQUNMLFVBQVUsRUFBRTtZQUNWLFdBQVcsRUFBRTtnQkFDWCxvQ0FBb0M7Z0JBQ3BDLFdBQVcsRUFBRTtvQkFDWCw0QkFBNEI7b0JBQzVCLFdBQVcsRUFBRTt3QkFDWCwrQkFBK0I7d0JBQy9CLEtBQUssRUFBRSxDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQUUsRUFBRTs0QkFDcEIsSUFBSSxPQUFPLEtBQUssS0FBSyxRQUFRLEVBQUU7Z0NBQzdCLE9BQU8sS0FBSyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDOzZCQUN6QztpQ0FBTTtnQ0FDTCxPQUFPLEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQUU7b0NBQ3RDLFNBQVMsRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7aUNBQy9CLENBQUMsQ0FBQzs2QkFDSjt3QkFDSCxDQUFDO3dCQUNELGdDQUFnQztxQkFDakM7aUJBQ0Y7YUFDRjtZQUNELFVBQVUsRUFBRTtnQkFDViw0QkFBNEI7Z0JBQzVCLFdBQVcsRUFBRTtvQkFDWCxzQkFBc0I7b0JBQ3RCLFNBQVMsRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7aUJBQy9CO2FBQ0Y7U0FDRjtLQUNGO0NBQ0YsQ0FBQztBQUVGLE1BQU0saUJBQWlCLEdBQUc7SUFDeEIsb0JBQW9CO0lBQ3BCLFdBQVcsRUFBRTtRQUNYLFFBQVEsRUFBRSxJQUFJO1FBQ2QsU0FBUyxFQUFFO1lBQ1QsUUFBUSxFQUFFLElBQUk7WUFDZCxVQUFVLEVBQUU7Z0JBQ1YsT0FBTyxFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQztnQkFDMUIsSUFBSSxFQUFFLEVBQUMsSUFBSSxFQUFFLFFBQVEsRUFBQztnQkFDdEIsZUFBZSxFQUFFLEVBQUMsS0FBSyxFQUFFLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRSxFQUFFLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsRUFBQztnQkFDckUsUUFBUSxFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQztnQkFDM0IsT0FBTyxFQUFFO29CQUNQLFFBQVEsRUFBRSxJQUFJO29CQUNkLElBQUksRUFBRSxRQUFRO29CQUNkLEtBQUssRUFBRSxDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQztpQkFDNUQ7Z0JBQ0QsS0FBSyxFQUFFO29CQUNMLFFBQVEsRUFBRSxJQUFJO29CQUNkLElBQUksRUFBRSxRQUFRO29CQUNkLEtBQUssRUFBRSxDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQztpQkFDNUQ7YUFDRjtTQUNGO0tBQ0Y7SUFFRCwyQkFBMkI7SUFDM0IsUUFBUSxFQUFFO1FBQ1IsUUFBUSxFQUFFLElBQUk7UUFDZCxVQUFVLEVBQUU7WUFDVixrQkFBa0IsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxFQUFDO1lBQzNELGVBQWUsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxFQUFDO1lBQ3hELGFBQWEsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxFQUFDO1lBQ3RELHFCQUFxQixFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLEVBQUM7WUFDOUQsb0JBQW9CLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsRUFBQztZQUM3RCxlQUFlLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsRUFBQztZQUN4RCxtQkFBbUIsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsUUFBUSxDQUFDLEVBQUM7WUFDeEQseUJBQXlCLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLFFBQVEsQ0FBQyxFQUFDO1lBQzlELGVBQWUsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsUUFBUSxFQUFFLCtCQUErQixDQUFDLEVBQUM7WUFDckYsUUFBUSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFDO1lBQzNDLGlCQUFpQixFQUFFLEVBQUMsS0FBSyxFQUFFLENBQUMsUUFBUSxDQUFDLEVBQUM7WUFDdEMsWUFBWSxFQUFFLEVBQUMsS0FBSyxFQUFFLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxFQUFDO1lBQ3JDLG1CQUFtQixFQUFFLEVBQUMsS0FBSyxFQUFFLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxFQUFDO1lBQzVDLGFBQWEsRUFBRSxFQUFDLEtBQUssRUFBRSxRQUFRLEVBQUM7WUFDaEMsZ0JBQWdCLEVBQUUsRUFBQyxLQUFLLEVBQUUsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFDO1lBQzNDLDJCQUEyQixFQUFFLEVBQUMsS0FBSyxFQUFFLE1BQU0sRUFBQztZQUM1QyxXQUFXLEVBQUUsRUFBQyxJQUFJLEVBQUUsU0FBUyxFQUFDO1lBQzlCLHNCQUFzQixFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQztTQUMxQztLQUNGO0lBRUQsMkJBQTJCO0lBQzNCLEVBQUUsRUFBRTtRQUNGLFFBQVEsRUFBRSxJQUFJO1FBQ2QsVUFBVSxFQUFFO1lBQ1YsSUFBSSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFDO1lBQ3pDLFFBQVEsRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7WUFDN0IsUUFBUSxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztZQUM3QixpQkFBaUIsRUFBRSxFQUFDLEtBQUssRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsRUFBQztZQUN6QyxPQUFPLEVBQUU7Z0JBQ1AsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsS0FBSyxFQUFFLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRSxFQUFFLENBQUMsYUFBYSxDQUFDLGNBQWMsQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDO2FBQ2hFO1NBQ0Y7S0FDRjtJQUVELG9DQUFvQztJQUNwQyxNQUFNLEVBQUU7UUFDTixRQUFRLEVBQUUsSUFBSTtRQUNkLFVBQVUsRUFBRTtZQUNWLFVBQVUsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBQztZQUUzQyxZQUFZLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUM7WUFDakQsWUFBWSxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztZQUNqQyxXQUFXLEVBQUUsRUFBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUUsT0FBTyxDQUFDLEVBQUM7WUFFeEMsTUFBTSxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztZQUMzQixVQUFVLEVBQUUsRUFBQyxLQUFLLEVBQUUsQ0FBQyxRQUFRLEVBQUUsbUJBQW1CLENBQUMsRUFBQztZQUNwRCxjQUFjLEVBQUUsRUFBQyxLQUFLLEVBQUUsU0FBUyxFQUFDO1lBQ2xDLGVBQWUsRUFBRSxFQUFDLEtBQUssRUFBRSxTQUFTLEVBQUM7WUFDbkMsWUFBWSxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztZQUVqQyxRQUFRO1lBQ1IsZUFBZSxFQUFFLEVBQUMsS0FBSyxFQUFFLE1BQU0sRUFBQztZQUNoQyxRQUFRLEVBQUUsRUFBQyxJQUFJLEVBQUUsU0FBUyxFQUFDO1lBQzNCLFVBQVUsRUFBRSxFQUFDLElBQUksRUFBRSxTQUFTLEVBQUM7WUFDN0IsZUFBZSxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztZQUNwQyxrQkFBa0IsRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7WUFDdkMscUJBQXFCLEVBQUUsRUFBQyxLQUFLLEVBQUUsVUFBVSxFQUFDLENBQUMsaUNBQWlDO1NBQzdFO0tBQ0Y7SUFFRCxrQkFBa0IsRUFBRTtRQUNsQixRQUFRLEVBQUUsSUFBSTtRQUNkLElBQUksRUFBRSxRQUFRO1FBQ2QsS0FBSyxFQUFFLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRSxFQUFFLENBQUMsYUFBYSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUM7S0FDbEU7SUFDRCxnQkFBZ0IsRUFBRTtRQUNoQixRQUFRLEVBQUUsSUFBSTtRQUNkLElBQUksRUFBRSxRQUFRO1FBQ2QsS0FBSyxFQUFFLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRSxFQUFFLENBQUMsYUFBYSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQUUsSUFBSSxDQUFDO0tBQ3hFO0lBRUQsNkNBQTZDO0lBQzdDLGlFQUFpRTtJQUNqRSxlQUFlLEVBQUUsRUFBQyxLQUFLLEVBQUUsQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFLEVBQUUsQ0FBQyxvQkFBb0IsQ0FBQyxhQUFhLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxFQUFDO0lBRXhGLE1BQU0sRUFBRTtRQUNOLFVBQVUsRUFBRTtZQUNWLE9BQU8sRUFBRSxFQUFDLElBQUksRUFBRSxTQUFTLEVBQUM7WUFDMUIsV0FBVyxFQUFFLEVBQUMsS0FBSyxFQUFFLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxFQUFDO1lBQ3BDLGVBQWUsRUFBRSxFQUFDLEtBQUssRUFBRSxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsRUFBQztZQUN4QyxlQUFlLEVBQUUsRUFBQyxLQUFLLEVBQUUsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLEVBQUM7WUFDeEMsY0FBYyxFQUFFLEVBQUMsS0FBSyxFQUFFLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxFQUFDO1NBQ3hDO0tBQ0Y7SUFFRCw0QkFBNEI7SUFDNUIsVUFBVSxFQUFFO1FBQ1YsUUFBUSxFQUFFLElBQUk7UUFDZCxVQUFVLEVBQUU7WUFDVixPQUFPLEVBQUUsRUFBQyxJQUFJLEVBQUUsU0FBUyxFQUFDO1lBQzFCLFNBQVMsRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7WUFDOUIsYUFBYSxFQUFFLEVBQUMsS0FBSyxFQUFFLENBQUMsU0FBUyxFQUFFLEdBQUcsR0FBRyxJQUFJLENBQUMsRUFBQztZQUMvQyxVQUFVLEVBQUUsRUFBQyxJQUFJLEVBQUUsU0FBUyxFQUFDO1lBQzdCLFNBQVMsRUFBRSxFQUFDLElBQUksRUFBRSxTQUFTLEVBQUM7WUFDNUIsSUFBSSxFQUFFLEVBQUMsTUFBTSxFQUFFLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxJQUFJLENBQUMsRUFBQztTQUNqQztLQUNGO0lBRUQsK0JBQStCO0lBQy9CLE1BQU0sRUFBRTtRQUNOLFFBQVEsRUFBRSxJQUFJO1FBQ2QsVUFBVSxFQUFFO1lBQ1YsZ0JBQWdCLEVBQUUsRUFBQyxLQUFLLEVBQUUsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLEVBQUM7WUFDekMsWUFBWSxFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQztZQUMvQixTQUFTLEVBQUUsRUFBQyxJQUFJLEVBQUUsU0FBUyxFQUFDO1lBQzVCLFdBQVcsRUFBRSxFQUFDLElBQUksRUFBRSxRQUFRLEVBQUM7WUFDN0IsaUJBQWlCLEVBQUUsRUFBQyxJQUFJLEVBQUUsUUFBUSxFQUFDO1lBQ25DLFdBQVcsRUFBRSxFQUFDLElBQUksRUFBRSxTQUFTLEVBQUM7WUFDOUIsTUFBTSxFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQztZQUN6QixZQUFZLEVBQUUsRUFBQyxLQUFLLEVBQUUsQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUFDLEVBQUM7WUFDdEMsMEJBQTBCLEVBQUUsRUFBQyxTQUFTLEVBQUUsRUFBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUUsUUFBUSxDQUFDLEVBQUMsRUFBQztZQUNyRSwwQkFBMEIsRUFBRSxFQUFDLEtBQUssRUFBRSxDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQUUsRUFBRTtvQkFDakQsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRSxDQUFDLFFBQVEsRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDO29CQUNsRCxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUU7d0JBQ3hCLEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQztxQkFDbEM7eUJBQU07d0JBQ0wsS0FBSyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDO3FCQUNqQztnQkFDSCxDQUFDLEVBQUM7WUFFRix5QkFBeUIsRUFBRTtnQkFDekIsV0FBVyxFQUFFO29CQUNYLEtBQUssRUFBRSxDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQUUsRUFBRTt3QkFDcEIsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRSxDQUFDLFFBQVEsRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDO3dCQUNsRCxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUU7NEJBQ3hCLEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQzt5QkFDbEM7NkJBQU07NEJBQ0wsS0FBSyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDO3lCQUNqQztvQkFDSCxDQUFDO2lCQUNGO2FBQ0Y7WUFDRCx1QkFBdUIsRUFBRSxFQUFDLFFBQVEsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBQztZQUUzRCxxREFBcUQ7WUFDckQsb0JBQW9CLEVBQUU7Z0JBQ3BCLFVBQVUsRUFBRSxtREFBbUQ7YUFDaEU7WUFFRCw2QkFBNkI7WUFDN0IsaUJBQWlCLEVBQUU7Z0JBQ2pCLFVBQVUsRUFBRTtvQkFDVixPQUFPLEVBQUUsRUFBQyxJQUFJLEVBQUUsU0FBUyxFQUFDO29CQUMxQixHQUFHLEVBQUUsRUFBQyxLQUFLLEVBQUUsVUFBVSxFQUFDO29CQUN4QixNQUFNLEVBQUUsRUFBQyxLQUFLLEVBQUUsVUFBVSxFQUFDO29CQUMzQixNQUFNLEVBQUUsRUFBQyxLQUFLLEVBQUUsVUFBVSxFQUFDO29CQUMzQixhQUFhLEVBQUUsRUFBQyxLQUFLLEVBQUUsVUFBVSxFQUFDO29CQUNsQyxHQUFHLEVBQUU7d0JBQ0gsUUFBUSxFQUFFLEtBQUs7d0JBQ2YsTUFBTSxFQUFFLFdBQVc7d0JBQ25CLGlEQUFpRDt3QkFDakQsdUVBQXVFO3dCQUN2RSxVQUFVLEVBQUU7NEJBQ1YsMERBQTBEOzRCQUMxRCxrQkFBa0IsRUFBRSxFQUFDLElBQUksRUFBRSxTQUFTLEVBQUM7eUJBQ3RDO3FCQUNGO2lCQUNGO2FBQ0Y7WUFFRCx5QkFBeUI7WUFDekIsSUFBSSxFQUFFO2dCQUNKLFVBQVUsRUFBRTtvQkFDVixPQUFPLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUM7b0JBQzFDLEdBQUcsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBQztvQkFDeEMsTUFBTSxFQUFFLEVBQUMsVUFBVSxFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFDO29CQUNwRCxZQUFZLEVBQUUsRUFBQyxVQUFVLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUM7b0JBQ3BELE1BQU0sRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJO3dCQUNyQixLQUFLLEVBQUUsQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFLEVBQUU7NEJBQ3BCLElBQUksT0FBTyxLQUFLLEtBQUssUUFBUSxFQUFFO2dDQUM3QixLQUFLLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUM7NkJBQ2xDO2lDQUFNO2dDQUNMLEtBQUssQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQzs2QkFDekQ7d0JBQ0gsQ0FBQztxQkFDRjtvQkFDRCxhQUFhLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUM7b0JBQ2xELFVBQVUsRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7b0JBQy9CLFVBQVUsRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7b0JBQy9CLHNFQUFzRTtvQkFDdEUsZ0JBQWdCLEVBQUUsRUFBQyxVQUFVLEVBQUUsaURBQWlELEVBQUM7b0JBQ2pGLEdBQUcsRUFBRTt3QkFDSCxRQUFRLEVBQUUsS0FBSzt3QkFDZixNQUFNLEVBQUUsV0FBVzt3QkFDbkIsaURBQWlEO3dCQUNqRCx1RUFBdUU7d0JBQ3ZFLFVBQVUsRUFBRTs0QkFDViwwREFBMEQ7NEJBQzFELGtCQUFrQixFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQzt5QkFDdEM7cUJBQ0Y7aUJBQ0Y7YUFDRjtZQUVELHNCQUFzQjtZQUN0QixLQUFLLEVBQUU7Z0JBQ0wsVUFBVSxFQUFFO29CQUNWLE9BQU8sRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBQztvQkFDMUMsR0FBRyxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFDO29CQUN4QywyQkFBMkIsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBQztvQkFDaEUsY0FBYyxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztvQkFDbkMsY0FBYyxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztpQkFDcEM7YUFDRjtZQUVELHVCQUF1QjtZQUN2QixNQUFNLEVBQUU7Z0JBQ04sVUFBVSxFQUFFO29CQUNWLE9BQU8sRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBQztvQkFDMUMsUUFBUSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFDO29CQUM3QyxnQkFBZ0IsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBQztvQkFDaEQsUUFBUSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFDO29CQUN4QyxRQUFRLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUM7b0JBQzdDLFlBQVksRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBQztvQkFDakQsYUFBYSxFQUFFO3dCQUNiLFVBQVUsRUFBRTs0QkFDVixXQUFXLEVBQUUsRUFBQyxVQUFVLEVBQUUsWUFBWSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUM7NEJBQ3JELEtBQUssRUFBRSxFQUFDLFVBQVUsRUFBRSxZQUFZLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBQzs0QkFDcEQsVUFBVSxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQzt5QkFDaEM7cUJBQ0Y7b0JBQ0QsS0FBSyxFQUFFO3dCQUNMLFVBQVUsRUFBRTs0QkFDVixRQUFRLEVBQUUsRUFBQyxLQUFLLEVBQUUsVUFBVSxFQUFDO3lCQUM5QjtxQkFDRjtpQkFDRjthQUNGO1NBQ0Y7S0FDRjtJQUVELG9DQUFvQztJQUNwQyxPQUFPLEVBQUU7UUFDUCxRQUFRLEVBQUUsSUFBSTtRQUNkLFNBQVMsRUFBRTtZQUNULFFBQVEsRUFBRSxJQUFJO1lBQ2QsVUFBVSxFQUFFO2dCQUNWLElBQUksRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBQztnQkFDekMsV0FBVyxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFDO2dCQUMvQyxXQUFXLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUM7Z0JBQ2hELE9BQU8sRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxFQUFDO2dCQUNoRCxPQUFPLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLFNBQVMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUM7Z0JBQ3BELFNBQVMsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBQztnQkFDNUMsVUFBVSxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztnQkFDL0IsRUFBRSxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztnQkFDdkIsV0FBVyxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztnQkFDaEMsT0FBTyxFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQyxDQUFDLG1DQUFtQzthQUMvRDtTQUNGO0tBQ0Y7SUFFRCxxQkFBcUI7SUFDckIsSUFBSSxFQUFFO1FBQ0osUUFBUSxFQUFFLElBQUk7UUFDZCxVQUFVLEVBQUU7WUFDVixRQUFRLEVBQUUsRUFBQyxNQUFNLEVBQUUsQ0FBQyxPQUFPLEVBQUUsUUFBUSxDQUFDLEVBQUM7WUFDdkMsWUFBWSxFQUFFO2dCQUNaLFVBQVUsRUFBRTtvQkFDVixZQUFZLEVBQUUsRUFBQyxNQUFNLEVBQUUsQ0FBQyxnQkFBZ0IsRUFBRSxRQUFRLEVBQUUsTUFBTSxDQUFDLEVBQUM7b0JBQzVELGdCQUFnQixFQUFFLEVBQUMsS0FBSyxFQUFFLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxFQUFDO2lCQUMxQzthQUNGO1lBQ0QsY0FBYyxFQUFFLEVBQUMsTUFBTSxFQUFFLENBQUMsV0FBVyxFQUFFLGlCQUFpQixDQUFDLEVBQUM7WUFDMUQsT0FBTyxFQUFFLEVBQUMsSUFBSSxFQUFFLFFBQVEsRUFBQztTQUMxQjtLQUNGO0lBRUQsK0RBQStEO0lBQy9ELGFBQWEsRUFBRTtRQUNiLFFBQVEsRUFBRSxLQUFLO1FBQ2YsVUFBVSxFQUFFO1lBQ1YsS0FBSyxFQUFFLEVBQUMsSUFBSSxFQUFFLFFBQVEsRUFBQztZQUN2QixLQUFLLEVBQUUsRUFBQyxJQUFJLEVBQUUsUUFBUSxFQUFDO1NBQ3hCO0tBQ0Y7SUFFRCxrQkFBa0I7SUFDbEIsT0FBTyxFQUFFO1FBQ1AsS0FBSyxFQUFFLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRSxFQUFFO1lBQ3BCLHdEQUF3RDtZQUN4RCxLQUFLLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFLHNCQUFzQixDQUFDLENBQUM7UUFDN0QsQ0FBQztLQUNGO0lBRUQsaUJBQWlCO0lBQ2pCLFFBQVEsRUFBRSxFQUFDLElBQUksRUFBRSxTQUFTLEVBQUM7SUFFM0IsaUJBQWlCO0lBQ2pCLE9BQU8sRUFBRSxFQUFDLElBQUksRUFBRSxRQUFRLEVBQUM7SUFFekIsMENBQTBDO0lBQzFDLFVBQVUsRUFBRTtRQUNWLElBQUksRUFBRSxRQUFRO1FBQ2QsS0FBSyxFQUFFLEtBQUssQ0FBQyxrQkFBa0I7S0FDaEM7SUFFRCxnQkFBZ0I7SUFDaEIsV0FBVyxFQUFFLEVBQUU7Q0FDaEIsQ0FBQztBQUVGLE1BQU0sYUFBYTtJQUVqQjs7O09BR0c7SUFDSCxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU07UUFDakIsS0FBSyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsZUFBZSxFQUFFLE1BQU0sRUFBRSxpQkFBaUIsQ0FBQyxDQUFDO0lBQ3JFLENBQUM7SUFFRDs7O09BR0c7SUFDSCxNQUFNLENBQUMsY0FBYyxDQUFDLEdBQUcsRUFBRSxTQUFTO1FBQ2xDLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRyxVQUFVLEVBQUUsU0FBUyxDQUFDLE9BQU8sRUFDcEQsQ0FBQyxRQUFRLEVBQUUsT0FBTyxFQUFFLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDO1FBRTNDLElBQUksU0FBUyxDQUFDLE9BQU8sS0FBSyxRQUFRLEVBQUU7WUFDbEMsS0FBSyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsR0FBRyxFQUFFLFNBQVMsRUFBRTtnQkFDckMsT0FBTyxFQUFFLEVBQUMsTUFBTSxFQUFFLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxFQUFDO2dCQUN0QyxPQUFPLEVBQUUsRUFBQyxLQUFLLEVBQUUsVUFBVSxFQUFDO2FBQzdCLENBQUMsQ0FBQztTQUNKO2FBQU07WUFDTCxLQUFLLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxHQUFHLEVBQUUsU0FBUyxFQUFFO2dCQUNyQyxPQUFPLEVBQUUsRUFBQyxNQUFNLEVBQUUsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLEVBQUM7Z0JBQ3RDLElBQUksRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7Z0JBQ3pCLElBQUksRUFBRSxFQUFDLEtBQUssRUFBRSxNQUFNLEVBQUM7YUFDdEIsQ0FBQyxDQUFDO1NBQ0o7SUFDSCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLEVBQUUsV0FBVyxFQUFFLGtCQUFrQjtRQUMxRCxJQUFJLFVBQVUsR0FBRztZQUNmLE1BQU0sRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRSxFQUFFO29CQUM3QyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMseUJBQXlCO29CQUMzRSw2Q0FBNkM7b0JBQzdDLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRTt3QkFDcEIsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUFDLG1CQUFtQixFQUFFLElBQUksR0FBRywyQkFBMkIsQ0FBQyxDQUFDO3FCQUNoRjtnQkFDSCxDQUFDLEVBQUM7U0FDSCxDQUFDO1FBRUYsSUFBSSxrQkFBa0IsRUFBRTtZQUN0QixVQUFVLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUU7Z0JBQy9CLGlCQUFpQixFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFDO2dCQUNwRCxRQUFRLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUM7Z0JBQzNDLFFBQVEsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLENBQUMsU0FBUyxFQUFFLFFBQVEsRUFBRSxNQUFNLENBQUMsRUFBQztnQkFDakUsUUFBUSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFDO2dCQUMzQyxRQUFRLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUM7YUFDNUMsQ0FBQyxDQUFDO1NBQ0o7YUFBTTtZQUNMLG1CQUFtQjtZQUNuQixVQUFVLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUU7Z0JBQy9CLFNBQVMsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBQztnQkFDNUMsaUJBQWlCLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUM7YUFDckQsQ0FBQyxDQUFDO1NBQ0o7UUFFRCxLQUFLLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxlQUFlLEVBQUUsV0FBVyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0lBQ25FLENBQUM7SUFFRDs7O09BR0c7SUFDSCxNQUFNLENBQUMsVUFBVSxDQUFDLEdBQUcsRUFBRSxPQUFPO1FBQzVCLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRyxTQUFTLEVBQUUsT0FBTyxDQUFDLE1BQU0sRUFBRTtZQUNsRCxPQUFPLEVBQUUsWUFBWSxFQUFFLHNCQUFzQixFQUFFLFVBQVU7U0FDMUQsQ0FBQyxDQUFDO1FBRUgsSUFBSSxVQUFVLEdBQUc7WUFDZixNQUFNLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBQztZQUNsRCxnQkFBZ0IsRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7WUFDckMsaUJBQWlCLEVBQUUsRUFBQyxLQUFLLEVBQUUsVUFBVSxFQUFDO1lBRXRDLDBDQUEwQztZQUMxQyxlQUFlLEVBQUUsRUFBQyxJQUFJLEVBQUUsU0FBUyxFQUFDO1NBQ25DLENBQUM7UUFFRixNQUFNLHdCQUF3QixHQUFHO1lBQy9CLGlCQUFpQixFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztZQUN0QyxpQkFBaUIsRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7U0FDdkMsQ0FBQztRQUVGLE1BQU0sMEJBQTBCLEdBQUc7WUFDakMsSUFBSSxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztZQUN6QixRQUFRLEVBQUUsRUFBQyxLQUFLLEVBQUUsVUFBVSxFQUFDO1NBQzlCLENBQUM7UUFFRixtR0FBbUc7UUFDbkcsTUFBTSx3QkFBd0IsR0FBRztZQUMvQixRQUFRLEVBQUUsRUFBQyxLQUFLLEVBQUUsUUFBUSxFQUFDO1lBQzNCLFdBQVcsRUFBRSxFQUFDLEtBQUssRUFBRSxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsRUFBQztTQUNyQyxDQUFDO1FBRUYsTUFBTSxnQ0FBZ0MsR0FBRztZQUN2QyxzQkFBc0IsRUFBRSxFQUFDLElBQUksRUFBRSxTQUFTLEVBQUM7U0FDMUMsQ0FBQztRQUVGLFFBQVEsT0FBTyxDQUFDLE1BQU0sRUFBRTtZQUN0QixLQUFLLE9BQU87Z0JBQ1YsVUFBVSxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFO29CQUMvQixHQUFHLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUM7b0JBQ25DLEtBQUssRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7b0JBQzFCLFFBQVEsRUFBRSxFQUFDLEtBQUssRUFBRSxTQUFTLEVBQUM7aUJBQzdCLENBQUMsQ0FBQztnQkFDSCxVQUFVLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUUsMEJBQTBCLENBQUMsQ0FBQztnQkFDN0QsVUFBVSxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFLHdCQUF3QixDQUFDLENBQUM7Z0JBQzNELE1BQU07WUFFUixLQUFLLFlBQVk7Z0JBQ2YsVUFBVSxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFO29CQUMvQixHQUFHLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUM7b0JBRW5DLDhDQUE4QztvQkFDOUMsVUFBVSxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztvQkFDL0Isb0JBQW9CLEVBQUUsRUFBQyxLQUFLLEVBQUUsVUFBVSxFQUFDO29CQUN6QyxpQkFBaUIsRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7b0JBQ3RDLGFBQWEsRUFBRSxFQUFDLElBQUksRUFBRSxRQUFRLEVBQUM7aUJBQ2hDLENBQUMsQ0FBQztnQkFDSCxVQUFVLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUUsMEJBQTBCLENBQUMsQ0FBQztnQkFDN0QsVUFBVSxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFLHdCQUF3QixDQUFDLENBQUM7Z0JBQzNELFVBQVUsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRSxnQ0FBZ0MsQ0FBQyxDQUFDO2dCQUNuRSxVQUFVLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUUsd0JBQXdCLENBQUMsQ0FBQztnQkFDM0QsS0FBSyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFLE9BQU8sRUFDaEMsQ0FBQyxZQUFZLEVBQUUsbUJBQW1CLEVBQUUsZUFBZSxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQzlELE1BQU07WUFFUixLQUFLLHNCQUFzQjtnQkFDekIsVUFBVSxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFO29CQUMvQixHQUFHLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUM7b0JBQ25DLFNBQVMsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBQztvQkFDOUMsTUFBTSxFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQztpQkFDMUIsQ0FBQyxDQUFDO2dCQUNILFVBQVUsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRSwwQkFBMEIsQ0FBQyxDQUFDO2dCQUM3RCxVQUFVLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUUsd0JBQXdCLENBQUMsQ0FBQztnQkFDM0QsVUFBVSxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFLGdDQUFnQyxDQUFDLENBQUM7Z0JBQ25FLFVBQVUsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRSx3QkFBd0IsQ0FBQyxDQUFDO2dCQUMzRCxNQUFNO1lBRVIsS0FBSyxVQUFVO2dCQUNiLFVBQVUsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRTtvQkFDL0IsR0FBRyxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFDO29CQUNuQyxRQUFRLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUM7b0JBQzdDLFVBQVUsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBQztvQkFDL0MsVUFBVSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFDO29CQUMvQyxjQUFjLEVBQUUsRUFBQyxRQUFRLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUM7aUJBQ2hELENBQUMsQ0FBQztnQkFDSCxNQUFNO1NBQ1Q7UUFFRCxLQUFLLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxHQUFHLEVBQUUsT0FBTyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0lBQ25ELENBQUM7SUFFRDs7O09BR0c7SUFDSCxNQUFNLENBQUMsVUFBVSxDQUFDLEdBQUcsRUFBRSxLQUFLO1FBQzFCLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRyxTQUFTLEVBQUUsS0FBSyxDQUFDLE1BQU0sRUFBRTtZQUNoRCxlQUFlLEVBQUUsZ0JBQWdCLEVBQUUsUUFBUTtZQUMzQyxhQUFhLEVBQUUsa0JBQWtCLEVBQUUsYUFBYTtTQUNqRCxDQUFDLENBQUM7UUFDSCxJQUFJLFVBQVUsR0FBRztZQUNmLE1BQU0sRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxFQUFDO1NBQ2pELENBQUM7UUFFRixRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUU7WUFDcEIsS0FBSyxlQUFlO2dCQUNsQixVQUFVLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUU7b0JBQy9CLElBQUksRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBQztvQkFDekMsSUFBSSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFDO29CQUNyQyxZQUFZLEVBQUUsRUFBQyxJQUFJLEVBQUUsU0FBUyxFQUFDO29CQUMvQixrQkFBa0IsRUFBRSxFQUFDLElBQUksRUFBRSxTQUFTLEVBQUM7b0JBQ3JDLGNBQWMsRUFBRSxFQUFDLElBQUksRUFBRSxTQUFTLEVBQUM7b0JBQ2pDLGFBQWEsRUFBRSxFQUFDLElBQUksRUFBRSxTQUFTLEVBQUM7b0JBQ2hDLDBCQUEwQjtvQkFDMUIsS0FBSyxFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQztvQkFDeEIsU0FBUyxFQUFFLEVBQUMsSUFBSSxFQUFFLFFBQVEsRUFBQztvQkFDM0IsT0FBTyxFQUFFLEVBQUMsSUFBSSxFQUFFLFFBQVEsRUFBQztvQkFDekIsUUFBUSxFQUFFLEVBQUMsSUFBSSxFQUFFLFFBQVEsRUFBQztvQkFDMUIsSUFBSSxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztvQkFDekIsUUFBUSxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztpQkFDOUIsQ0FBQyxDQUFDO2dCQUNILE1BQU07WUFFUixLQUFLLGdCQUFnQjtnQkFDbkIsVUFBVSxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFO29CQUMvQixJQUFJLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUM7b0JBQ3pDLElBQUksRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBQztvQkFDckMsWUFBWSxFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQztvQkFDL0IsS0FBSyxFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQztvQkFDeEIsSUFBSSxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztvQkFDekIsUUFBUSxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztvQkFDN0IsY0FBYyxFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQztvQkFDakMsa0JBQWtCLEVBQUUsRUFBQyxTQUFTLEVBQUUsRUFBQyxLQUFLLEVBQUUsVUFBVSxFQUFDLEVBQUM7b0JBQ3BELFFBQVEsRUFBRSxFQUFDLElBQUksRUFBRSxRQUFRLEVBQUM7b0JBQzFCLHVGQUF1RjtvQkFDdkYsa0JBQWtCLEVBQUUsRUFBQyxJQUFJLEVBQUUsU0FBUyxFQUFDO29CQUNyQyxNQUFNLEVBQUUsRUFBQyxJQUFJLEVBQUUsUUFBUSxFQUFDO29CQUN4QixnQkFBZ0IsRUFBRSxFQUFDLElBQUksRUFBRSxTQUFTLEVBQUM7aUJBQ3BDLENBQUMsQ0FBQztnQkFDSCxNQUFNO1lBRVIsS0FBSyxRQUFRO2dCQUNYLFVBQVUsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRTtvQkFDL0IsZ0JBQWdCLEVBQUUsRUFBQyxJQUFJLEVBQUUsU0FBUyxFQUFDO2lCQUNwQyxDQUFDLENBQUM7Z0JBQ0gsTUFBTTtZQUVSLEtBQUssYUFBYTtnQkFDaEIsVUFBVSxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFO29CQUMvQixjQUFjLEVBQUUsRUFBQyxLQUFLLEVBQUUsU0FBUyxFQUFDO29CQUNsQyxVQUFVLEVBQUUsRUFBQyxJQUFJLEVBQUUsU0FBUyxFQUFDO29CQUM3QixnQkFBZ0IsRUFBRSxFQUFDLElBQUksRUFBRSxTQUFTLEVBQUM7b0JBRW5DLDBCQUEwQjtvQkFDMUIsYUFBYSxFQUFFO3dCQUNiLFVBQVUsRUFBRSx3RUFBd0U7cUJBQ3JGO29CQUNELGFBQWEsRUFBRTt3QkFDYixVQUFVLEVBQUUsd0VBQXdFO3FCQUNyRjtvQkFDRCxpQkFBaUIsRUFBRTt3QkFDakIsVUFBVSxFQUFFLGdFQUFnRTtxQkFDN0U7b0JBQ0QsZ0JBQWdCLEVBQUU7d0JBQ2hCLFVBQVUsRUFBRSwyREFBMkQ7cUJBQ3hFO29CQUNELFNBQVMsRUFBRTt3QkFDVCxVQUFVLEVBQUUsa0RBQWtEO3FCQUMvRDtvQkFDRCxlQUFlLEVBQUU7d0JBQ2YsVUFBVSxFQUFFLGtEQUFrRDtxQkFDL0Q7b0JBQ0Qsa0JBQWtCLEVBQUU7d0JBQ2xCLFVBQVUsRUFBRSxrREFBa0Q7cUJBQy9EO29CQUNELGtCQUFrQixFQUFFO3dCQUNsQixVQUFVLEVBQUUsa0RBQWtEO3FCQUMvRDtpQkFDRixDQUFDLENBQUM7Z0JBQ0gsTUFBTTtZQUVSLEtBQUssa0JBQWtCO2dCQUNyQixVQUFVLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUU7b0JBQy9CLE1BQU0sRUFBRSxFQUFDLElBQUksRUFBRSxTQUFTLEVBQUM7b0JBQ3pCLFVBQVUsRUFBRSxFQUFDLElBQUksRUFBRSxTQUFTLEVBQUM7b0JBQzdCLGFBQWEsRUFBRSxFQUFDLElBQUksRUFBRSxRQUFRLEVBQUM7b0JBQy9CLGFBQWEsRUFBRSxFQUFDLElBQUksRUFBRSxRQUFRLEVBQUM7aUJBQ2hDLENBQUMsQ0FBQztnQkFDSCxNQUFNO1lBRVIsS0FBSyxhQUFhO2dCQUNoQixVQUFVLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUU7b0JBQy9CLEdBQUcsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBQztvQkFDbkMsTUFBTSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFDO29CQUMzQyxhQUFhLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUM7b0JBQ2xELGFBQWEsRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7aUJBQ25DLENBQUMsQ0FBQztnQkFDSCxNQUFNO1NBQ1Q7UUFFRCxLQUFLLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0lBQ2pELENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsYUFBYSxDQUFDIn0=