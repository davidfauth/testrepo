/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2018
 *
 * - Created on 2014-11-05.
 */
'use strict';
// internal libs
const crypto = require('crypto');
// external libs
const Promise = require('bluebird');
const fs = require('fs-extra');
// services
const LKE = require('../index');
const Log = LKE.getLogger(__filename);
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
// locals
const Options = require('../../options');
const ConfigChecker = require('./ConfigChecker');
const UserCache = require('../access/UserCache');
const ObjectUpdater = require('../../../lib/ObjectUpdater');
const OBFUSCATED_STRING_PREFIX = '$LKPW$';
const OBFUSCATION_KEY = 'for obfuscation purposes';
const OBFUSCATION_ALGORITHM = 'aes-256-ctr';
const ASTERISK_PASSWORD = '********';
const PASSWORD_RE = /[Pp]assword|[Ss]ecret|certificatePassphrase|primaryKey|apiKey/;
/**
 * All the following configuration keys, when modified, require a restart:
 * - "db" and "db.*"
 *   - Any change to the SQL DB
 * - "access" and "access.*" except "access.authRequired" and "access.guestMode"
 *   - Any change to LDAP, SAML, OAuth2 etc.
 *   - Authentication and guest mode can be enabled without restart
 * - "server" and "server.*" except "server.cookieSecret"
 *   - Any change to the HTTP server, certificates etc.
 *   - cookieSecret is set on first run (we can't require restart)
 * - "advanced" and "advanced.layoutWorkers"
 *   - It requires to fork processes at start so we need to restart
 * - "alerts" and "alerts.enabled"
 *   - On disable, we would need to stop every alert scheduled so we need to restart
 */
const NEED_RESTART_FIELDS = [
    /^db.*$/,
    /(^server\.(?!cookieSecret).*$)|(^server$)/,
    /(^access\.(?!(authRequired|guestMode)).*$)|(^access$)/,
    /(^advanced\.layoutWorkers$)|(^advanced\.extraCertificateAuthorities$)|(^advanced$)/,
    /(^alerts\.enabled)|(^alerts)/
];
/**
 * All the following configuration keys, when modified, require to free the user cache.
 */
const EMPTY_USER_CACHE_FIELDS = [
    /(^defaultPreferences$)/,
    /(^guestPreferences$)/
];
class ConfigurationService {
    constructor() {
        this.mode = LKE.options.mode;
        this.data = {};
        this.defaultConfig = {};
        this.needRestart = false;
    }
    /**
     * Load the default configuration and the user configuration files. Depending on the mode
     * we are running, reset the user configuration file with the default one.
     *
     * @returns {boolean} true if the JS configuration file could be loaded, false otherwise
     */
    load() {
        // load default config (JS file)
        this.defaultConfig = this._readDefaultConfig();
        // In DEV mode we delete user configuration on startup
        // In TEST mode we don't because we need a patched test.json file
        // for each configuration in the CI (runMocha.js will do it)
        const file = this.getUserConfigPath();
        if (LKE.isDevMode() || LKE.options.resetConfig) {
            Log.warn('Resetting user configuration file (' + (LKE.options.resetConfig
                ? 'requested by user'
                : ('automatic in ' + this.mode + ' mode')) + ')');
            if (fs.existsSync(file)) {
                fs.unlinkSync(file);
            }
        }
        // load user config (JSON file)
        this.data = this._readUserConfig();
        const currentVersion = this.data.version;
        const targetVersion = LKE.getVersion();
        if (Utils.noValue(currentVersion)) {
            throw Errors.technical('critical', 'Version should always be specified in the configuration file.');
        }
        if (Utils.compareSemVer(targetVersion, currentVersion) > 0) {
            // If the configuration was not migrated by the update script, migrate it here.
            this.data = this._migrateConfig(this.data, targetVersion);
        }
        try {
            ConfigChecker.check(this.data);
        }
        catch (e) {
            throw Errors.business('invalid_configuration', 'The configuration file has errors: ' + e.message + ' (in ' + file + '). ' +
                'To reset to defaults, use the --' + Options.RESET_OPTION + ' option');
        }
        return true;
    }
    /**
     * @private
     * @returns {any} default configuration data
     */
    _readDefaultConfig() {
        const fileJS = this._getDefaultConfigPath();
        const data = require(fileJS);
        if (!data) {
            throw Errors.technical('critical', 'Default configuration file is empty: "' + fileJS + '"');
        }
        // Ensure that the default config has the current version
        data.version = LKE.getVersion();
        return data;
    }
    /**
     * @private
     * @returns {string} the path of the DEFAULT configuration file for the current mode
     */
    _getDefaultConfigPath() {
        return LKE.systemFile('server/config/defaults/' + this.mode + '.js');
    }
    /**
     * Return true if `str` is a string made of any amount of '*' characters.
     *
     * @param {any} str
     * @returns {boolean}
     * @private
     */
    _isOnlyAsterisks(str) {
        return Utils.isNEString(str) && str.match(/^\**$/) !== null;
    }
    /**
     * @param {string} text
     * @returns {string}
     * @private
     */
    _obfuscateString(text) {
        const cipher = crypto.createCipher(OBFUSCATION_ALGORITHM, OBFUSCATION_KEY);
        const encodedPwd = Buffer.from(OBFUSCATED_STRING_PREFIX + text).toString('base64');
        const invertedPwd = encodedPwd.split('').reverse().join('');
        const encryptedPwd = Buffer.concat([
            cipher.update(Buffer.from(invertedPwd, 'ascii')),
            cipher.final()
        ]).toString('base64');
        return OBFUSCATED_STRING_PREFIX + encryptedPwd;
    }
    /**
     * @param {string} obfuscatedString
     * @param {string} propertyPath
     * @returns {string}
     * @private
     */
    _deobfuscateString(obfuscatedString, propertyPath) {
        const decipher = crypto.createDecipher(OBFUSCATION_ALGORITHM, OBFUSCATION_KEY);
        const dePrefixedPwd = obfuscatedString.slice(OBFUSCATED_STRING_PREFIX.length);
        const decryptedPwd = Buffer.concat([
            decipher.update(Buffer.from(dePrefixedPwd, 'base64')),
            decipher.final()
        ]).toString('ascii');
        const deInvertedPwd = decryptedPwd.split('').reverse().join('');
        const decodedPwd = Buffer.from(deInvertedPwd, 'base64').toString('ascii');
        if (decodedPwd.slice(0, OBFUSCATED_STRING_PREFIX.length) !== OBFUSCATED_STRING_PREFIX) {
            // someone modified an obfuscated string manually but left the "$LKPW$" prefix
            throw Errors.technical('invalid_parameter', 'The obfuscated string at ' + propertyPath + ' is not valid.');
        }
        return decodedPwd.slice(OBFUSCATED_STRING_PREFIX.length);
    }
    /**
     * Look in every property key of `config` for fields matching PASSWORD_RE.
     * Apply `passwordTransformation` to any of these password fields.
     * If `passwordTransformation` returns `undefined` or `null`, do not erase the original value.
     *
     * @param {any}                              config                 The configuration
     * @param {function(string, string): string} passwordTransformation Map function to apply to every password field
     * @param {string}                           [propertyPath]         Used in the recursion to carry the path information
     * @private
     */
    _transformPasswords(config, passwordTransformation, propertyPath) {
        if (Utils.isObject(config)) {
            for (const key of Object.keys(config)) {
                const subPropertyPath = Utils.hasValue(propertyPath) ? propertyPath + '.' + key : key;
                // this allows to iterate over arrays and objects and nothing else
                if (typeof config[key] === 'object' && config[key] !== null) {
                    this._transformPasswords(config[key], passwordTransformation, subPropertyPath);
                }
                else if (typeof config[key] === 'string' && key.match(PASSWORD_RE)) {
                    const transformedValue = passwordTransformation(config[key], subPropertyPath);
                    if (Utils.hasValue(transformedValue)) {
                        config[key] = transformedValue;
                    }
                }
            }
        }
    }
    /**
     * Look in every property key of `config` for fields matching PASSWORD_RE.
     * Apply the obfuscation algorithm to any of the password fields.
     *
     * @param {any} config The configuration
     * @private
     */
    _obfuscateAllPasswords(config) {
        this._transformPasswords(config, password => {
            if (!password.startsWith(OBFUSCATED_STRING_PREFIX)) {
                return this._obfuscateString(password);
            }
        });
    }
    /**
     * Look in every property key of `config` for fields matching PASSWORD_RE.
     * Apply the de-obfuscation algorithm to any of the password fields.
     *
     * @param {any} config The configuration
     * @private
     */
    _deobfuscateAllPasswords(config) {
        this._transformPasswords(config, (password, propertyPath) => {
            if (password.startsWith(OBFUSCATED_STRING_PREFIX)) {
                return this._deobfuscateString(password, propertyPath);
            }
        });
    }
    /**
     * Look in every property key of `data` for fields matching PASSWORD_RE.
     * Replace the value of any of the password fields with asterisks.
     *
     * @param {any} config The configuration
     * @private
     */
    _asteriskAllPasswords(config) {
        this._transformPasswords(config, () => ASTERISK_PASSWORD);
    }
    /**
     * Load the user configuration file. If the file is not found or it's empty,
     * reset the user configuration file with the default one.
     *
     * @private
     * @throws {LkError} if the configuration is not valid
     * @returns {any} user configuration data
     */
    _readUserConfig() {
        if (!this.defaultConfig) {
            throw Errors.technical('bug', 'Default config must be loaded before reading the user config');
        }
        // if user config file is missing, create a new one from defaults
        const configFile = this.getUserConfigPath();
        if (!fs.existsSync(configFile)) {
            const defaultConfigData = Utils.clone(this.defaultConfig);
            this._persistUserConfig(defaultConfigData);
        }
        let data = this._getConfigData(configFile);
        // if the JSON file was empty
        if (!data) {
            // clone the default config
            data = Utils.clone(this.defaultConfig);
            // the JSON file is empty, fill it with defaults
            this._persistUserConfig(data);
        }
        else if (Utils.hasValue(data.advanced) && data.advanced.obfuscation) {
            // every time we read the user config, we persist it as well to ensure
            // that every field to obfuscate is obfuscated
            this._persistUserConfig(data);
        }
        // if the advanced.obfuscation flag is set to false, obfuscated passwords still get de-obfuscated
        this._deobfuscateAllPasswords(data);
        Log.info('Loaded configuration from file (' + this.mode + ')');
        return data;
    }
    /**
     * Read the configuration file.
     *
     * @param {string} configFile Configuration file path
     * @returns {any}
     * @throws {LkError} if the configuration could not be read.
     * @private
     */
    _getConfigData(configFile) {
        // read the user config
        const json = fs.readFileSync(configFile).toString();
        try {
            return JSON.parse(json);
        }
        catch (e) {
            const error = Utils.getJSONParseError(json);
            throw Errors.business('invalid_configuration', 'The configuration file "' + configFile + '" ' +
                'has errors (' + error.message + ') ' +
                'at line ' + error.line + ' ' +
                '(column ' + error.column + '' + '): ' + error.snippet);
        }
    }
    /**
     * @returns {string} the path of the USER configuration file for the current mode
     */
    getUserConfigPath() {
        return LKE.dataFile('config/' + this.mode + '.json');
    }
    /**
     * @private
     * @param {any} config configuration data
     */
    _persistUserConfig(config) {
        const data = Utils.clone(config);
        if (Utils.hasValue(data.advanced) && data.advanced.obfuscation) {
            this._obfuscateAllPasswords(data);
        }
        fs.ensureFileSync(this.getUserConfigPath());
        fs.writeFileSync(this.getUserConfigPath(), JSON.stringify(data, null, ' '));
    }
    /**
     * @param {any}     [data]          Configuration data to be used
     * @param {string}  [propertyPath]  Path of the property to read (use '.' as separator) or undefined for the whole config object
     * @param {any}     [defaultValue]  The default value to return if no value is found
     * @param {boolean} [required]      Throw an LkError if the property is not found
     * @param {boolean} [hidePasswords] Whether password fields should be protected with asterisks
     * @returns {any}
     * @private
     */
    _get(data, propertyPath, defaultValue, required, hidePasswords) {
        if (propertyPath !== undefined && !Utils.isNEString(propertyPath)) {
            throw Errors.technical('bug', 'Could not get an empty property key in the configuration');
        }
        const keyChain = propertyPath === undefined ? [] : propertyPath.split('.', 10);
        const doHidePasswords = object => {
            if (!Utils.isObject(object)) {
                return object;
            }
            // we clone the object here so that we can asterisk the password
            // but we clone it deep even if `hidePasswords` is false
            // so that we can return its son safely later
            object = Utils.clone(object);
            // if passwords have to be hidden, we call the function on the last object in the tree
            if (hidePasswords) {
                this._asteriskAllPasswords(object);
            }
            return object;
        };
        let value = data;
        if (keyChain.length === 0) {
            value = doHidePasswords(value);
        }
        else {
            while (keyChain.length > 0 && value !== null && value !== undefined) {
                if (keyChain.length === 1) {
                    value = doHidePasswords(value);
                }
                value = value[keyChain.shift()];
            }
        }
        if (value === null || value === undefined) {
            if (required) {
                throw Errors.business('missing_field', '"' + propertyPath + '" is required');
            }
            else {
                value = defaultValue;
            }
        }
        return value;
    }
    /**
     * Read a configuration property.
     *
     * @param {string}  [propertyPath]  Path of the property to read (use '.' as separator) or undefined for the whole config object
     * @param {any}     [defaultValue]  The default value to return if no value is found
     * @param {boolean} [required]      Throw an LkError if the property is not found
     * @param {boolean} [hidePasswords] Whether password fields should be protected with asterisks
     * @returns {any}
     */
    get(propertyPath, defaultValue, required, hidePasswords) {
        return this._get(this.data, propertyPath, defaultValue, required, hidePasswords);
    }
    /**
     * Read a default configuration property.
     *
     * @param {string}  [propertyPath]  Path of the property to read (use '.' as separator) or undefined for the whole config object
     * @param {any}     [defaultValue]  The default value to return if no value is found
     * @param {boolean} [required]      Throw an LkError if the property is not found
     * @param {boolean} [hidePasswords] Whether password fields should be protected with asterisks
     * @returns {any}
     */
    getDefault(propertyPath, defaultValue, required, hidePasswords) {
        return this._get(this.defaultConfig, propertyPath, defaultValue, required, hidePasswords);
    }
    /**
     * Override a configuration property with the object passed as the value argument.
     * This replaces all the child object properties and values.
     *
     * @param {string}  propertyPath            Path of the property to set (use '.' as separator)
     * @param {any}     value                   The value to set
     * @param {boolean} [ignoreHiddenPasswords] Whether password fields should be ignored if made exclusively of asterisks
     * @returns {Bluebird<void>}
     */
    set(propertyPath, value, ignoreHiddenPasswords) {
        if (!Utils.isNEString(propertyPath)) {
            return Errors.business('invalid_parameter', 'The path of a configuration property must be a non-empty string', true);
        }
        if (ignoreHiddenPasswords && propertyPath.match(PASSWORD_RE) && this._isOnlyAsterisks(value)) {
            // nothing to do, we don't set a password made of asterisks if `ignoreHiddenPasswords` is true
            return Promise.resolve();
        }
        const keyChain = propertyPath.split('.', 10);
        // clone current config
        const newData = JSON.parse(JSON.stringify(this.data));
        // we check the propertyPath and if we modify a field containing
        // a NEED_RESTART_FIELDS we mark `candidateForNeedRestart` as true
        // if the configuration is still valid, we actually set `needRestart` to true
        let candidateForNeedRestart = false;
        if (!this.needRestart) {
            for (const needRestartField of NEED_RESTART_FIELDS) {
                if (propertyPath.match(needRestartField)) {
                    candidateForNeedRestart = true;
                }
            }
        }
        for (const field of EMPTY_USER_CACHE_FIELDS) {
            if (propertyPath.match(field)) {
                UserCache.emptyCache();
            }
        }
        // resolve parent of the update
        let i, newDataChangeParent = newData;
        for (i = 0; i < keyChain.length - 1; i++) {
            newDataChangeParent = newDataChangeParent[keyChain[i]];
        }
        if (ignoreHiddenPasswords) {
            // every password in `value` that is made exclusively of asterisks
            // it's replaced with the original value
            this._transformPasswords(value, (password, propertyPath) => {
                if (this._isOnlyAsterisks(password)) {
                    return Utils.safeGet(newDataChangeParent[keyChain[i]], propertyPath);
                }
                return password;
            });
        }
        // update the cloned config (updates `newData`)
        newDataChangeParent[keyChain[i]] = value;
        // check that the cloned updated config is valid
        try {
            ConfigChecker.check(newData);
        }
        catch (e) {
            return Errors.business('invalid_parameter', 'Invalid configuration structure: ' + e.message, true);
        }
        this._deobfuscateAllPasswords(newData);
        this.data = newData;
        this._persistUserConfig(this.data);
        this.needRestart = this.needRestart || candidateForNeedRestart;
        return Promise.resolve();
    }
    /**
     * Add a value to a configuration property that is an array.
     *
     * @param {string} propertyPath Path of the property
     * @param {any}    value        Value to add
     * @returns {Bluebird<number>} resolved with the new size of the array
     */
    add(propertyPath, value) {
        return Promise.resolve().then(() => {
            const array = this.get(propertyPath, []);
            Utils.check.array(propertyPath, array);
            array.push(value);
            return this.set(propertyPath, array).return(array.length);
        });
    }
    /**
     * Remove a value from a configuration property that is an array.
     *
     * @param {string} propertyPath Path of the property
     * @param {number} valueIndex   The index to remove from the array
     * @returns {Bluebird<void>}
     */
    remove(propertyPath, valueIndex) {
        return Promise.resolve().then(() => {
            let array = this.get(propertyPath, []);
            Utils.check.array(propertyPath, array, valueIndex - 1);
            array = array.slice(0, valueIndex).concat(array.slice(valueIndex + 1));
            return this.set(propertyPath, array);
        });
    }
    /**
     * Reset the configuration to the default values.
     *
     * If no property path is specified, reset the whole configuration.
     *
     * If the property path is specified then the default value is retrieved from the configuration
     * and set as the current configuration value. The other configuration keys are not modified.
     *
     * @param {string} [propertyPath] Path of the property
     * @returns {Bluebird<void>}
     */
    reset(propertyPath) {
        // reset the whole file
        if (!propertyPath) {
            const userConfigFile = this.getUserConfigPath();
            if (fs.existsSync(userConfigFile)) {
                fs.removeSync(userConfigFile);
            }
            this._persistUserConfig(this.defaultConfig);
            return Promise.resolve(this.load()).return();
        }
        else { // reset only one property
            // validate keyChain
            const keyChain = propertyPath.split('.', 10);
            if (keyChain.length === 0) {
                return Errors.business('invalid_parameter', 'Could not reset \'\' property  key in the configuration', true);
            }
            // resolve property to reset
            let defaultData = this.defaultConfig;
            while (keyChain.length > 0) {
                const k = keyChain.shift();
                defaultData = defaultData[k];
            }
            // reset
            return this.set(propertyPath, Utils.clone(defaultData));
        }
    }
    /**
     * Migrate the Linkurious configuration (uses manager/configUpdates.json).
     *
     * @param {any}    config
     * @param {string} targetVersion
     * @returns {any} updated config data
     * @private
     */
    _migrateConfig(config, targetVersion) {
        // backup config
        Utils.backupFile(LKE.dataFile('config'), `${this.mode}.json`, true);
        const configUpdates = fs.readJsonSync(LKE.systemFile('manager/configUpdates.json'));
        let currentVersion = config.version;
        // migrate config
        /**@type {object}**/
        const configUpdater = new ObjectUpdater(config, Log.warn.bind(this));
        configUpdater.applyUpdates(configUpdates, targetVersion).forEach(update => {
            Log.info(`Migrated configuration from v${currentVersion} to v${update.version}.`);
            currentVersion = update.version;
        });
        this._persistUserConfig(config);
        // Ignore undefined properties removed by the updater
        return JSON.parse(JSON.stringify(config));
    }
}
module.exports = new ConfigurationService();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvY29uZmlndXJhdGlvbi9pbmRleC5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7R0FLRztBQUNILFlBQVksQ0FBQztBQUViLGdCQUFnQjtBQUNoQixNQUFNLE1BQU0sR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFFakMsZ0JBQWdCO0FBQ2hCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNwQyxNQUFNLEVBQUUsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFFL0IsV0FBVztBQUNYLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNoQyxNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3RDLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFFL0IsU0FBUztBQUNULE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQztBQUN6QyxNQUFNLGFBQWEsR0FBRyxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQztBQUNqRCxNQUFNLFNBQVMsR0FBRyxPQUFPLENBQUMscUJBQXFCLENBQUMsQ0FBQztBQUNqRCxNQUFNLGFBQWEsR0FBRyxPQUFPLENBQUMsNEJBQTRCLENBQUMsQ0FBQztBQUU1RCxNQUFNLHdCQUF3QixHQUFHLFFBQVEsQ0FBQztBQUMxQyxNQUFNLGVBQWUsR0FBRywwQkFBMEIsQ0FBQztBQUNuRCxNQUFNLHFCQUFxQixHQUFHLGFBQWEsQ0FBQztBQUU1QyxNQUFNLGlCQUFpQixHQUFHLFVBQVUsQ0FBQztBQUNyQyxNQUFNLFdBQVcsR0FBRywrREFBK0QsQ0FBQztBQUVwRjs7Ozs7Ozs7Ozs7Ozs7R0FjRztBQUNILE1BQU0sbUJBQW1CLEdBQUc7SUFDMUIsUUFBUTtJQUNSLDJDQUEyQztJQUMzQyx1REFBdUQ7SUFDdkQsb0ZBQW9GO0lBQ3BGLDhCQUE4QjtDQUMvQixDQUFDO0FBRUY7O0dBRUc7QUFDSCxNQUFNLHVCQUF1QixHQUFHO0lBQzlCLHdCQUF3QjtJQUN4QixzQkFBc0I7Q0FDdkIsQ0FBQztBQUVGLE1BQU0sb0JBQW9CO0lBRXhCO1FBQ0UsSUFBSSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQztRQUM3QixJQUFJLENBQUMsSUFBSSxHQUFHLEVBQUUsQ0FBQztRQUNmLElBQUksQ0FBQyxhQUFhLEdBQUcsRUFBRSxDQUFDO1FBRXhCLElBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDO0lBQzNCLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILElBQUk7UUFDRixnQ0FBZ0M7UUFDaEMsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztRQUUvQyxzREFBc0Q7UUFDdEQsaUVBQWlFO1FBQ2pFLDREQUE0RDtRQUM1RCxNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztRQUN0QyxJQUFJLEdBQUcsQ0FBQyxTQUFTLEVBQUUsSUFBSSxHQUFHLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRTtZQUM5QyxHQUFHLENBQUMsSUFBSSxDQUFDLHFDQUFxQyxHQUFHLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxXQUFXO2dCQUN2RSxDQUFDLENBQUMsbUJBQW1CO2dCQUNyQixDQUFDLENBQUMsQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLElBQUksR0FBRyxPQUFPLENBQUMsQ0FDMUMsR0FBRyxHQUFHLENBQUMsQ0FBQztZQUNULElBQUksRUFBRSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBRTtnQkFBRSxFQUFFLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQUU7U0FDbEQ7UUFFRCwrQkFBK0I7UUFDL0IsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7UUFFbkMsTUFBTSxjQUFjLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7UUFDekMsTUFBTSxhQUFhLEdBQUcsR0FBRyxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBRXZDLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsRUFBRTtZQUNqQyxNQUFNLE1BQU0sQ0FBQyxTQUFTLENBQ3BCLFVBQVUsRUFDViwrREFBK0QsQ0FBQyxDQUFDO1NBQ3BFO1FBRUQsSUFBSSxLQUFLLENBQUMsYUFBYSxDQUFDLGFBQWEsRUFBRSxjQUFjLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDMUQsK0VBQStFO1lBQy9FLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1NBQzNEO1FBRUQsSUFBSTtZQUNGLGFBQWEsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ2hDO1FBQUMsT0FBTSxDQUFDLEVBQUU7WUFDVCxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQ25CLHVCQUF1QixFQUN2QixxQ0FBcUMsR0FBRyxDQUFDLENBQUMsT0FBTyxHQUFHLE9BQU8sR0FBRyxJQUFJLEdBQUcsS0FBSztnQkFDMUUsa0NBQWtDLEdBQUcsT0FBTyxDQUFDLFlBQVksR0FBRyxTQUFTLENBQ3RFLENBQUM7U0FDSDtRQUVELE9BQU8sSUFBSSxDQUFDO0lBQ2QsQ0FBQztJQUVEOzs7T0FHRztJQUNILGtCQUFrQjtRQUNoQixNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQztRQUM1QyxNQUFNLElBQUksR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDN0IsSUFBSSxDQUFDLElBQUksRUFBRTtZQUNULE1BQU0sTUFBTSxDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUUsd0NBQXdDLEdBQUcsTUFBTSxHQUFHLEdBQUcsQ0FBQyxDQUFDO1NBQzdGO1FBRUQseURBQXlEO1FBQ3pELElBQUksQ0FBQyxPQUFPLEdBQUcsR0FBRyxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ2hDLE9BQU8sSUFBSSxDQUFDO0lBQ2QsQ0FBQztJQUVEOzs7T0FHRztJQUNILHFCQUFxQjtRQUNuQixPQUFPLEdBQUcsQ0FBQyxVQUFVLENBQUMseUJBQXlCLEdBQUcsSUFBSSxDQUFDLElBQUksR0FBRyxLQUFLLENBQUMsQ0FBQztJQUN2RSxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsZ0JBQWdCLENBQUMsR0FBRztRQUNsQixPQUFPLEtBQUssQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLElBQUksR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxJQUFJLENBQUM7SUFDOUQsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxnQkFBZ0IsQ0FBQyxJQUFJO1FBQ25CLE1BQU0sTUFBTSxHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUMscUJBQXFCLEVBQUUsZUFBZSxDQUFDLENBQUM7UUFFM0UsTUFBTSxVQUFVLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyx3QkFBd0IsR0FBRyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDbkYsTUFBTSxXQUFXLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDNUQsTUFBTSxZQUFZLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQztZQUNqQyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1lBQ2hELE1BQU0sQ0FBQyxLQUFLLEVBQUU7U0FBQyxDQUNoQixDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNyQixPQUFPLHdCQUF3QixHQUFHLFlBQVksQ0FBQztJQUNqRCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxrQkFBa0IsQ0FBQyxnQkFBZ0IsRUFBRSxZQUFZO1FBQy9DLE1BQU0sUUFBUSxHQUFHLE1BQU0sQ0FBQyxjQUFjLENBQUMscUJBQXFCLEVBQUUsZUFBZSxDQUFDLENBQUM7UUFFL0UsTUFBTSxhQUFhLEdBQUcsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLHdCQUF3QixDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzlFLE1BQU0sWUFBWSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUM7WUFDakMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxRQUFRLENBQUMsQ0FBQztZQUNyRCxRQUFRLENBQUMsS0FBSyxFQUFFO1NBQUMsQ0FDbEIsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDcEIsTUFBTSxhQUFhLEdBQUcsWUFBWSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDaEUsTUFBTSxVQUFVLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUUsUUFBUSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRTFFLElBQUksVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsd0JBQXdCLENBQUMsTUFBTSxDQUFDLEtBQUssd0JBQXdCLEVBQUU7WUFDckYsOEVBQThFO1lBQzlFLE1BQU0sTUFBTSxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsRUFDeEMsMkJBQTJCLEdBQUcsWUFBWSxHQUFHLGdCQUFnQixDQUFDLENBQUM7U0FDbEU7UUFFRCxPQUFPLFVBQVUsQ0FBQyxLQUFLLENBQUMsd0JBQXdCLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDM0QsQ0FBQztJQUVEOzs7Ozs7Ozs7T0FTRztJQUNILG1CQUFtQixDQUFDLE1BQU0sRUFBRSxzQkFBc0IsRUFBRSxZQUFZO1FBQzlELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUMxQixLQUFLLE1BQU0sR0FBRyxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7Z0JBQ3JDLE1BQU0sZUFBZSxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7Z0JBQ3RGLGtFQUFrRTtnQkFDbEUsSUFBSSxPQUFPLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxRQUFRLElBQUksTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLLElBQUksRUFBRTtvQkFDM0QsSUFBSSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsRUFBRSxzQkFBc0IsRUFBRSxlQUFlLENBQUMsQ0FBQztpQkFDaEY7cUJBQU0sSUFBSSxPQUFPLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxRQUFRLElBQUksR0FBRyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsRUFBRTtvQkFDcEUsTUFBTSxnQkFBZ0IsR0FBRyxzQkFBc0IsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEVBQUUsZUFBZSxDQUFDLENBQUM7b0JBQzlFLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFO3dCQUNwQyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsZ0JBQWdCLENBQUM7cUJBQ2hDO2lCQUNGO2FBQ0Y7U0FDRjtJQUNILENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxzQkFBc0IsQ0FBQyxNQUFNO1FBQzNCLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLEVBQUUsUUFBUSxDQUFDLEVBQUU7WUFDMUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsd0JBQXdCLENBQUMsRUFBRTtnQkFDbEQsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLENBQUM7YUFDeEM7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCx3QkFBd0IsQ0FBQyxNQUFNO1FBQzdCLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxRQUFRLEVBQUUsWUFBWSxFQUFFLEVBQUU7WUFDMUQsSUFBSSxRQUFRLENBQUMsVUFBVSxDQUFDLHdCQUF3QixDQUFDLEVBQUU7Z0JBQ2pELE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLFFBQVEsRUFBRSxZQUFZLENBQUMsQ0FBQzthQUN4RDtRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILHFCQUFxQixDQUFDLE1BQU07UUFDMUIsSUFBSSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sRUFBRSxHQUFHLEVBQUUsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0lBQzVELENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsZUFBZTtRQUNiLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFO1lBQ3ZCLE1BQU0sTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsOERBQThELENBQUMsQ0FBQztTQUMvRjtRQUVELGlFQUFpRTtRQUNqRSxNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztRQUM1QyxJQUFJLENBQUMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsRUFBRTtZQUM5QixNQUFNLGlCQUFpQixHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBQzFELElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1NBQzVDO1FBQ0QsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUUzQyw2QkFBNkI7UUFDN0IsSUFBSSxDQUFDLElBQUksRUFBRTtZQUNULDJCQUEyQjtZQUMzQixJQUFJLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7WUFDdkMsZ0RBQWdEO1lBQ2hELElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUMvQjthQUFNLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUU7WUFDckUsc0VBQXNFO1lBQ3RFLDhDQUE4QztZQUM5QyxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDL0I7UUFFRCxpR0FBaUc7UUFDakcsSUFBSSxDQUFDLHdCQUF3QixDQUFDLElBQUksQ0FBQyxDQUFDO1FBRXBDLEdBQUcsQ0FBQyxJQUFJLENBQUMsa0NBQWtDLEdBQUcsSUFBSSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUMsQ0FBQztRQUMvRCxPQUFPLElBQUksQ0FBQztJQUNkLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsY0FBYyxDQUFDLFVBQVU7UUFDdkIsdUJBQXVCO1FBQ3ZCLE1BQU0sSUFBSSxHQUFHLEVBQUUsQ0FBQyxZQUFZLENBQUMsVUFBVSxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUM7UUFFcEQsSUFBSTtZQUNGLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUN6QjtRQUFDLE9BQU0sQ0FBQyxFQUFFO1lBQ1QsTUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzVDLE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FBQyx1QkFBdUIsRUFDM0MsMEJBQTBCLEdBQUcsVUFBVSxHQUFHLElBQUk7Z0JBQzlDLGNBQWMsR0FBRyxLQUFLLENBQUMsT0FBTyxHQUFHLElBQUk7Z0JBQ3JDLFVBQVUsR0FBRyxLQUFLLENBQUMsSUFBSSxHQUFHLEdBQUc7Z0JBQzdCLFVBQVUsR0FBRyxLQUFLLENBQUMsTUFBTSxHQUFHLEVBQUUsR0FBRyxLQUFLLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FDdkQsQ0FBQztTQUNIO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0gsaUJBQWlCO1FBQ2YsT0FBTyxHQUFHLENBQUMsUUFBUSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsSUFBSSxHQUFHLE9BQU8sQ0FBQyxDQUFDO0lBQ3ZELENBQUM7SUFFRDs7O09BR0c7SUFDSCxrQkFBa0IsQ0FBQyxNQUFNO1FBQ3ZCLE1BQU0sSUFBSSxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDakMsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRTtZQUM5RCxJQUFJLENBQUMsc0JBQXNCLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDbkM7UUFFRCxFQUFFLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDLENBQUM7UUFDNUMsRUFBRSxDQUFDLGFBQWEsQ0FDZCxJQUFJLENBQUMsaUJBQWlCLEVBQUUsRUFDeEIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFLEdBQUcsQ0FBQyxDQUNoQyxDQUFDO0lBQ0osQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsSUFBSSxDQUFDLElBQUksRUFBRSxZQUFZLEVBQUUsWUFBWSxFQUFFLFFBQVEsRUFBRSxhQUFhO1FBQzVELElBQUksWUFBWSxLQUFLLFNBQVMsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLEVBQUU7WUFDakUsTUFBTSxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSwwREFBMEQsQ0FBQyxDQUFDO1NBQzNGO1FBRUQsTUFBTSxRQUFRLEdBQUcsWUFBWSxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUUvRSxNQUFNLGVBQWUsR0FBRyxNQUFNLENBQUMsRUFBRTtZQUMvQixJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRTtnQkFDM0IsT0FBTyxNQUFNLENBQUM7YUFDZjtZQUVELGdFQUFnRTtZQUNoRSx3REFBd0Q7WUFDeEQsNkNBQTZDO1lBQzdDLE1BQU0sR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBRTdCLHNGQUFzRjtZQUN0RixJQUFJLGFBQWEsRUFBRTtnQkFDakIsSUFBSSxDQUFDLHFCQUFxQixDQUFDLE1BQU0sQ0FBQyxDQUFDO2FBQ3BDO1lBRUQsT0FBTyxNQUFNLENBQUM7UUFDaEIsQ0FBQyxDQUFDO1FBRUYsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDO1FBQ2pCLElBQUksUUFBUSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFDekIsS0FBSyxHQUFHLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUNoQzthQUFNO1lBQ0wsT0FBTyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLEtBQUssS0FBSyxTQUFTLEVBQUU7Z0JBQ25FLElBQUksUUFBUSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7b0JBQ3pCLEtBQUssR0FBRyxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUM7aUJBQ2hDO2dCQUVELEtBQUssR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUM7YUFDakM7U0FDRjtRQUVELElBQUksS0FBSyxLQUFLLElBQUksSUFBSSxLQUFLLEtBQUssU0FBUyxFQUFFO1lBQ3pDLElBQUksUUFBUSxFQUFFO2dCQUNaLE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FBQyxlQUFlLEVBQUUsR0FBRyxHQUFHLFlBQVksR0FBRyxlQUFlLENBQUMsQ0FBQzthQUM5RTtpQkFBTTtnQkFDTCxLQUFLLEdBQUcsWUFBWSxDQUFDO2FBQ3RCO1NBQ0Y7UUFFRCxPQUFPLEtBQUssQ0FBQztJQUNmLENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILEdBQUcsQ0FBQyxZQUFZLEVBQUUsWUFBWSxFQUFFLFFBQVEsRUFBRSxhQUFhO1FBQ3JELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLFlBQVksRUFBRSxZQUFZLEVBQUUsUUFBUSxFQUFFLGFBQWEsQ0FBQyxDQUFDO0lBQ25GLENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILFVBQVUsQ0FBQyxZQUFZLEVBQUUsWUFBWSxFQUFFLFFBQVEsRUFBRSxhQUFhO1FBQzVELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFLFlBQVksRUFBRSxZQUFZLEVBQUUsUUFBUSxFQUFFLGFBQWEsQ0FBQyxDQUFDO0lBQzVGLENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILEdBQUcsQ0FBQyxZQUFZLEVBQUUsS0FBSyxFQUFFLHFCQUFxQjtRQUM1QyxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsRUFBRTtZQUNuQyxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsbUJBQW1CLEVBQ3hDLGlFQUFpRSxFQUFFLElBQUksQ0FDeEUsQ0FBQztTQUNIO1FBRUQsSUFBSSxxQkFBcUIsSUFBSSxZQUFZLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUM1Riw4RkFBOEY7WUFDOUYsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7U0FDMUI7UUFFRCxNQUFNLFFBQVEsR0FBRyxZQUFZLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUU3Qyx1QkFBdUI7UUFDdkIsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBRXRELGdFQUFnRTtRQUNoRSxrRUFBa0U7UUFDbEUsNkVBQTZFO1FBQzdFLElBQUksdUJBQXVCLEdBQUcsS0FBSyxDQUFDO1FBQ3BDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFO1lBQ3JCLEtBQUssTUFBTSxnQkFBZ0IsSUFBSSxtQkFBbUIsRUFBRTtnQkFDbEQsSUFBSSxZQUFZLENBQUMsS0FBSyxDQUFDLGdCQUFnQixDQUFDLEVBQUU7b0JBQ3hDLHVCQUF1QixHQUFHLElBQUksQ0FBQztpQkFDaEM7YUFDRjtTQUNGO1FBQ0QsS0FBSyxNQUFNLEtBQUssSUFBSSx1QkFBdUIsRUFBRTtZQUMzQyxJQUFJLFlBQVksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQzdCLFNBQVMsQ0FBQyxVQUFVLEVBQUUsQ0FBQzthQUN4QjtTQUNGO1FBRUQsK0JBQStCO1FBQy9CLElBQUksQ0FBQyxFQUFFLG1CQUFtQixHQUFHLE9BQU8sQ0FBQztRQUNyQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3hDLG1CQUFtQixHQUFHLG1CQUFtQixDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ3hEO1FBRUQsSUFBSSxxQkFBcUIsRUFBRTtZQUN6QixrRUFBa0U7WUFDbEUsd0NBQXdDO1lBQ3hDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxRQUFRLEVBQUUsWUFBWSxFQUFFLEVBQUU7Z0JBQ3pELElBQUksSUFBSSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxFQUFFO29CQUNuQyxPQUFPLEtBQUssQ0FBQyxPQUFPLENBQUMsbUJBQW1CLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsWUFBWSxDQUFDLENBQUM7aUJBQ3RFO2dCQUNELE9BQU8sUUFBUSxDQUFDO1lBQ2xCLENBQUMsQ0FBQyxDQUFDO1NBQ0o7UUFFRCwrQ0FBK0M7UUFDL0MsbUJBQW1CLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDO1FBRXpDLGdEQUFnRDtRQUNoRCxJQUFJO1lBQ0YsYUFBYSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztTQUM5QjtRQUFDLE9BQU0sQ0FBQyxFQUFFO1lBQ1QsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUNwQixtQkFBbUIsRUFBRSxtQ0FBbUMsR0FBRyxDQUFDLENBQUMsT0FBTyxFQUFFLElBQUksQ0FDM0UsQ0FBQztTQUNIO1FBRUQsSUFBSSxDQUFDLHdCQUF3QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3ZDLElBQUksQ0FBQyxJQUFJLEdBQUcsT0FBTyxDQUFDO1FBQ3BCLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFbkMsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsV0FBVyxJQUFJLHVCQUF1QixDQUFDO1FBRS9ELE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO0lBQzNCLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxHQUFHLENBQUMsWUFBWSxFQUFFLEtBQUs7UUFDckIsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNqQyxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFlBQVksRUFBRSxFQUFFLENBQUMsQ0FBQztZQUN6QyxLQUFLLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDdkMsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNsQixPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsWUFBWSxFQUFFLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDNUQsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsTUFBTSxDQUFDLFlBQVksRUFBRSxVQUFVO1FBQzdCLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDakMsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxZQUFZLEVBQUUsRUFBRSxDQUFDLENBQUM7WUFDdkMsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsWUFBWSxFQUFFLEtBQUssRUFBRSxVQUFVLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDdkQsS0FBSyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3ZFLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDdkMsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7T0FVRztJQUNILEtBQUssQ0FBQyxZQUFZO1FBQ2hCLHVCQUF1QjtRQUN2QixJQUFJLENBQUMsWUFBWSxFQUFFO1lBQ2pCLE1BQU0sY0FBYyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1lBQ2hELElBQUksRUFBRSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsRUFBRTtnQkFDakMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsQ0FBQzthQUMvQjtZQUNELElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7WUFDNUMsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO1NBQzlDO2FBQU0sRUFBRSwwQkFBMEI7WUFDakMsb0JBQW9CO1lBQ3BCLE1BQU0sUUFBUSxHQUFHLFlBQVksQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1lBQzdDLElBQUksUUFBUSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7Z0JBQ3pCLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsRUFDeEMseURBQXlELEVBQUUsSUFBSSxDQUNoRSxDQUFDO2FBQ0g7WUFDRCw0QkFBNEI7WUFDNUIsSUFBSSxXQUFXLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztZQUNyQyxPQUFPLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO2dCQUMxQixNQUFNLENBQUMsR0FBRyxRQUFRLENBQUMsS0FBSyxFQUFFLENBQUM7Z0JBQzNCLFdBQVcsR0FBRyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDOUI7WUFDRCxRQUFRO1lBQ1IsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLFlBQVksRUFBRSxLQUFLLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7U0FDekQ7SUFDSCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILGNBQWMsQ0FBQyxNQUFNLEVBQUUsYUFBYTtRQUNsQyxnQkFBZ0I7UUFDaEIsS0FBSyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEdBQUcsSUFBSSxDQUFDLElBQUksT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3BFLE1BQU0sYUFBYSxHQUFHLEVBQUUsQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDLENBQUM7UUFFcEYsSUFBSSxjQUFjLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQztRQUVwQyxpQkFBaUI7UUFDakIsb0JBQW9CO1FBQ3BCLE1BQU0sYUFBYSxHQUFHLElBQUksYUFBYSxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQ3JFLGFBQWEsQ0FBQyxZQUFZLENBQUMsYUFBYSxFQUFFLGFBQWEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUN4RSxHQUFHLENBQUMsSUFBSSxDQUFDLGdDQUFnQyxjQUFjLFFBQVEsTUFBTSxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUM7WUFDbEYsY0FBYyxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUM7UUFDbEMsQ0FBQyxDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDaEMscURBQXFEO1FBQ3JELE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7SUFDNUMsQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxJQUFJLG9CQUFvQixFQUFFLENBQUMifQ==