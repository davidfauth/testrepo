/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2018-09-20.
 */
'use strict';
const fs = require('fs');
const path = require('path');
const Promise = require('bluebird');
const LKE = require('../../services');
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
const RESERVED_DIRS = ['api', 'widget'];
const MAX_DEPTH = 5;
class CustomFile {
    constructor() {
        this._customFilesPath = LKE.dataFile('server/customFiles');
    }
    /**
     * List all the files in the custom `root` folder.
     *
     * @param {string} [root]       Path from the custom folder directory
     * @param {string} [extensions] Valid extensions to filter the results (e.g. "png,gif,jpg,jpeg")
     * @returns {Bluebird<CustomFile[]>}
     */
    list(root = '.', extensions) {
        return Promise.resolve().then(() => {
            if (Utils.hasValue(extensions)) {
                Utils.check.string('extensions', extensions, true);
            }
            const absoluteRootPath = path.resolve(this._customFilesPath, root);
            const rootPathFragments = root.split(path.step);
            if (rootPathFragments.includes('..') || !absoluteRootPath.startsWith(this._customFilesPath)) {
                // trying to list a directory outside of `customFiles`
                // parent folder path fragments (i.e. ..) are forbidden in root
                // to prevent the ability to list files outside of customFiles
                return Errors.business('invalid_parameter', 'The usage of ".." in "root" is forbidden.', true);
            }
            const pathFromCustomFiles = absoluteRootPath.substring(this._customFilesPath.length + 1);
            const [rootDir] = pathFromCustomFiles.split(path.step);
            if (RESERVED_DIRS.includes(rootDir)) {
                return Errors.business('invalid_parameter', `"/${rootDir}" is a reserved folder name, please use another.`, true);
            }
            const results = [];
            const extensionFilter = extensions && extensions.split(',').map(e => e.toLowerCase());
            try {
                this._walk(results, pathFromCustomFiles, [], extensionFilter);
            }
            catch (error) {
                if (error.code === 'ENOENT') {
                    return Errors.business('not_found', `Could not find directory "${root}".`, true);
                }
                return Errors.technical('critical', 'Could not read customs files: ' + error.message, true);
            }
            return results;
        });
    }
    /**
     * Recursively navigate customs files from root and collect them in `acc`.
     *
     * @param {CustomFile[]} acc               Result accumulator
     * @param {string}       root              Root path
     * @param {string[]}     currentPath       Current path from root
     * @param {string[]}     [extensionFilter] Extensions to filter the listed files
     * @private
     */
    _walk(acc, root, currentPath, extensionFilter) {
        const absoluteFilePath = path.resolve(this._customFilesPath, root, ...currentPath);
        const [customDir] = absoluteFilePath
            .substring(this._customFilesPath.length + 1)
            .split(path.step);
        if (RESERVED_DIRS.includes(customDir)) {
            // Ignore reserved folders.
            return;
        }
        const currentFileStats = fs.lstatSync(absoluteFilePath);
        if (currentFileStats.isFile()) {
            const currentFile = path.parse(absoluteFilePath);
            const extension = currentFile.ext.substring(1).toLowerCase();
            const ignored = Utils.hasValue(extensionFilter) && !extensionFilter.includes(extension);
            if (!ignored) {
                acc.push({
                    // Relative URL of the file (i.e. domain + path is the absolute URL of the file)
                    path: `${root.length ? '/' + root : ''}/${currentPath.join('/')}`,
                    // root prefix removed && folder separators replaced by " > "
                    name: [...(currentPath.slice(0, -1)), currentFile.name].join(' > ')
                });
            }
        }
        if (currentFileStats.isDirectory() && MAX_DEPTH > currentPath.length) {
            for (const file of fs.readdirSync(absoluteFilePath)) {
                this._walk(acc, root, [...currentPath, file], extensionFilter);
            }
        }
    }
}
module.exports = new CustomFile();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvY3VzdG9tRmlsZS9pbmRleC5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7R0FLRztBQUNILFlBQVksQ0FBQztBQUNiLE1BQU0sRUFBRSxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUN6QixNQUFNLElBQUksR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDN0IsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3BDLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0FBQ3RDLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFFL0IsTUFBTSxhQUFhLEdBQUcsQ0FBQyxLQUFLLEVBQUUsUUFBUSxDQUFDLENBQUM7QUFDeEMsTUFBTSxTQUFTLEdBQUcsQ0FBQyxDQUFDO0FBRXBCLE1BQU0sVUFBVTtJQUNkO1FBQ0UsSUFBSSxDQUFDLGdCQUFnQixHQUFHLEdBQUcsQ0FBQyxRQUFRLENBQUMsb0JBQW9CLENBQUMsQ0FBQztJQUM3RCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsSUFBSSxDQUFDLElBQUksR0FBRyxHQUFHLEVBQUUsVUFBVTtRQUN6QixPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ2pDLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsRUFBRTtnQkFDOUIsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxJQUFJLENBQUMsQ0FBQzthQUNwRDtZQUVELE1BQU0sZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDbkUsTUFBTSxpQkFBaUIsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUVoRCxJQUFJLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsRUFBRTtnQkFDM0Ysc0RBQXNEO2dCQUN0RCwrREFBK0Q7Z0JBQy9ELDhEQUE4RDtnQkFDOUQsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLG1CQUFtQixFQUN4QywyQ0FBMkMsRUFBRSxJQUFJLENBQUMsQ0FBQzthQUN0RDtZQUVELE1BQU0sbUJBQW1CLEdBQUcsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDekYsTUFBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7WUFFdkQsSUFBSSxhQUFhLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFO2dCQUNuQyxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsbUJBQW1CLEVBQ3hDLEtBQUssT0FBTyxrREFBa0QsRUFBRSxJQUFJLENBQUMsQ0FBQzthQUN6RTtZQUVELE1BQU0sT0FBTyxHQUFHLEVBQUUsQ0FBQztZQUVuQixNQUFNLGVBQWUsR0FBRyxVQUFVLElBQUksVUFBVSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQztZQUV0RixJQUFJO2dCQUNGLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFLG1CQUFtQixFQUFFLEVBQUUsRUFBRSxlQUFlLENBQUMsQ0FBQzthQUMvRDtZQUFDLE9BQU0sS0FBSyxFQUFFO2dCQUNiLElBQUksS0FBSyxDQUFDLElBQUksS0FBSyxRQUFRLEVBQUU7b0JBQzNCLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsNkJBQTZCLElBQUksSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO2lCQUNsRjtnQkFDRCxPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLGdDQUFnQyxHQUFHLEtBQUssQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDN0Y7WUFDRCxPQUFPLE9BQU8sQ0FBQztRQUNqQixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILEtBQUssQ0FBQyxHQUFHLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxlQUFlO1FBQzNDLE1BQU0sZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsSUFBSSxFQUFFLEdBQUcsV0FBVyxDQUFDLENBQUM7UUFDbkYsTUFBTSxDQUFDLFNBQVMsQ0FBQyxHQUFHLGdCQUFnQjthQUNqQyxTQUFTLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7YUFDM0MsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUVwQixJQUFJLGFBQWEsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDckMsMkJBQTJCO1lBQzNCLE9BQU87U0FDUjtRQUVELE1BQU0sZ0JBQWdCLEdBQUcsRUFBRSxDQUFDLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1FBRXhELElBQUksZ0JBQWdCLENBQUMsTUFBTSxFQUFFLEVBQUU7WUFDN0IsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1lBQ2pELE1BQU0sU0FBUyxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQzdELE1BQU0sT0FBTyxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ3hGLElBQUksQ0FBQyxPQUFPLEVBQUU7Z0JBQ1osR0FBRyxDQUFDLElBQUksQ0FBQztvQkFDUCxnRkFBZ0Y7b0JBQ2hGLElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFO29CQUNqRSw2REFBNkQ7b0JBQzdELElBQUksRUFBRSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7aUJBQ3BFLENBQUMsQ0FBQzthQUNKO1NBQ0Y7UUFFRCxJQUFJLGdCQUFnQixDQUFDLFdBQVcsRUFBRSxJQUFJLFNBQVMsR0FBRyxXQUFXLENBQUMsTUFBTSxFQUFFO1lBQ3BFLEtBQUssTUFBTSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFO2dCQUNuRCxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxJQUFJLEVBQUUsQ0FBQyxHQUFHLFdBQVcsRUFBRSxJQUFJLENBQUMsRUFBRSxlQUFlLENBQUMsQ0FBQzthQUNoRTtTQUNGO0lBQ0gsQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxJQUFJLFVBQVUsRUFBRSxDQUFDIn0=