/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * Used to manage a dataSource (graph server info + searchIndex server info).
 * - to connect to graph server and searchIndex server
 *
 * - Created on 2015-01-09.
 */
'use strict';
const { SchemaSampler } = require('../graphSchema/sampler');
const { EntityType } = require('@linkurious/rest-client');
const crypto = require('crypto');
const _ = require('lodash');
const Promise = require('bluebird');
const LKE = require('../index');
const Config = LKE.getConfig();
const Utils = LKE.getUtils();
const Log = LKE.getLogger(__filename);
const Db = LKE.getSqlDb();
const Errors = LKE.getErrors();
const GraphSchemaService = LKE.getGraphSchema();
const { GraphDAO } = require('../../dao/graph/graphDAO');
const { IndexDAO } = require('../../dao/index/indexDAO');
const { SchemaBuilder } = require('../graphSchema/builder');
const Progress = require('./progress');
const CappedMap = require('../../../lib/CappedMap');
const VisualizationChecker = require('../business/VisualizationChecker');
const DesignUtils = require('../business/designUtils');
const { LkError } = require('../../models/errors/LkError');
// default size of the progress bar when the counts of nodes and edges are not available
const DEFAULT_PROGRESS_BAR_SIZE = 100000;
// number of edited items (nodes and edges) of which we keep the last edit date in memory
const LAST_EDIT_DATE_MAP_SIZE = 200;
/**
 * Data-source features
 *
 * @typedef {object} LkDataSourceFeatures
 * @property {boolean} edgeProperties          whether edge properties are supported
 * @property {boolean} immutableNodeCategories true if node categories are immutable
 * @property {number} maxNodeCategories        the maximum number of categories for a node
 * @property {boolean} canCount                whether one among the graph or the index can count nodes and edges
 * @property {boolean} alerts                  whether alerts are supported
 * @property {string[]} dialects               list of supported graph-query dialects
 * @property {boolean} externalIndex           whether the index is external
 * @property {boolean} alternativeIds          whether alternative IDs are supported by the Graph DAO
 * @property {boolean} canIndexEdges           whether the index can index edges
 * @property {boolean} searchHitsCount         whether the search result will contain 'totalHits' or 'moreResults'
 */
/**
 * Create a DataSource
 *
 * @param {number} sourceId index of the source configuration in the dataSources config array
 * @param {Data} dataService the data service
 * @constructor
 */
function DataSource(sourceId, dataService) {
    if (typeof sourceId !== 'number' || isNaN(sourceId)) {
        throw Errors.technical('bug', '"sourceId" is required');
    }
    this.sourceId = sourceId;
    this.dataService = dataService;
    this.pollIntervalMillis = Config.get('advanced.pollInterval', 10) * 1000;
    this._pollGraphState = { timer: null, promise: null };
    this._pollIndexState = { timer: null, promise: null };
    this.indexationRetries = 10;
    // Map of dates indexed by node/edge IDs refering to the last time a given item was edited
    this._lastEditDateMap = new CappedMap(LAST_EDIT_DATE_MAP_SIZE);
    this._resetSource();
}
/**
 * Computes the information of a data-source by concatenating
 * "[graphServerHost]:[graphServerPort]:[graphStoreId]".
 *
 * @param {string} graphServerHost hostname of the source graph server
 * @param {string|number} graphServerPort port of the source graph server
 * @param {string} graphStoreId unique identifier of the database-store in the source graph server
 * @returns {string} the information of the data-source
 */
DataSource.computeSourceInfo = function (graphServerHost, graphServerPort, graphStoreId) {
    return graphServerHost + ':' + graphServerPort + ':' + graphStoreId;
};
/**
 * @param {string} sourceInfo a data-source identification key
 * @returns {string|undefined} an 8 characters HEX string (truncated from full SHA256 HEX of sourceInfo)
 */
DataSource.computeSourceKey = function (sourceInfo) {
    if (sourceInfo === undefined) {
        return undefined;
    }
    const sha256Hash = crypto.createHash('sha256');
    sha256Hash.update(sourceInfo, 'utf8');
    return sha256Hash.digest('hex').substr(0, 8);
};
DataSource.prototype = {
    config: undefined,
    storeId: undefined,
    /**
     * Set manually when we should not interact with this source anymore:
     * - will stop polling graph/index servers
     * - can be removed from sources list
     *
     * @type boolean
     */
    destroyed: false,
    _connecting: false,
    /**
     * The progress of the indexation of null if the source is not currently indexing.
     *
     * @type Progress
     */
    indexingProgress: null,
    /**
     * The GraphDAO of this data-source
     *
     * @type GraphDAO
     */
    graph: undefined,
    graphConnected: false,
    graphConnectPromise: null,
    graphConnectError: null,
    /**
     * The IndexDAO of this data-source
     *
     * @type IndexDAO
     */
    index: undefined,
    indexConnected: false,
    indexConnectPromise: null,
    indexConnectError: null,
    /**
     * @returns {boolean} true if the data-source is currently connected
     */
    isConnected: function () {
        return this.graphConnected && this.indexConnected;
    },
    /**
     * codes: offline, connecting, needConfig, needFirstIndex, needReindex, indexing, ready
     *
     * return {{code:string, reason:string, error?: string}}
     */
    getState: function () {
        if (this.destroyed) {
            return {
                code: 'offline',
                reason: 'Data-source is invalid (please restart Linkurious).'
            };
        }
        // connecting
        if (this.graphConnectPromise) {
            return {
                code: 'connecting',
                reason: 'Trying to connect to graph database ...',
                error: this.graphConnectError
            };
        }
        if (this.indexConnectPromise) {
            return {
                code: 'connecting',
                reason: 'Trying to connect to search index ...',
                error: this.indexConnectError
            };
        }
        if (this._connecting) {
            return {
                code: 'connecting',
                reason: 'Trying to connect to data-source ...',
                error: null
            };
        }
        // offline
        if (!this.graphConnected || !this.indexConnected) {
            if (!this.graphConnected && this.graphConnectError) {
                return {
                    code: 'offline',
                    reason: 'Could not connect to graph database server.',
                    error: this.graphConnectError
                };
            }
            if (!this.indexConnected && this.indexConnectError) {
                return {
                    code: 'offline',
                    reason: 'Could not connect to index server.',
                    error: this.indexConnectError
                };
            }
            return {
                code: 'offline',
                reason: 'Disconnected from data-source.'
            };
        }
        // online:
        // indexing
        if (this.isIndexing()) {
            const p = this.indexingProgress;
            return {
                code: 'indexing',
                reason: 'Currently indexing ' + p.getRate() +
                    '. Progress: ' + p.getPercent() + '%. Time left: ' + p.getTimeLeft()
            };
        }
        // sampling
        if (this.isSampling()) {
            const p = this.schemaSampler;
            return {
                code: 'discoveringSchema',
                reason: p.status
            };
        }
        // needConfig (source was never configured and never indexed)
        if (this.needConfig()) {
            return {
                code: 'needConfig',
                reason: 'An administrator needs to configure this data-source for indexation.'
            };
        }
        // needFirstIndex (source was configured, but was NEVER indexed)
        if (this.needFirstIndex()) {
            return {
                code: 'needFirstIndex',
                reason: 'The data-source needs to be indexed at least once.',
                error: this.state.indexationError
            };
        }
        // needReindex:
        // source was already indexed but
        // a) configuration changed, re-index is required
        // or
        // b) index data is no longer consistent, re-index is required
        if (this.needReindex() || this.index.mustReindex()) {
            return {
                code: 'needReindex',
                reason: 'The data-source needs to be re-indexed',
                error: this.state.indexationError
            };
        }
        // ready :)
        return { code: 'ready', reason: 'The data-source is ready.' };
    },
    sourceInfoCache: undefined,
    sourceKeyCache: undefined,
    /**
     * @returns {boolean} true if this source is currently indexing
     */
    isIndexing: function () {
        return !!this.indexingProgress;
    },
    /**
     * @returns {boolean} true if this source is currently sampling
     */
    isSampling: function () {
        return !!this.schemaSampler;
    },
    /**
     * Sample the data-source and resolve when the sampling is done.
     *
     * @param {boolean}  reset
     * @param {function} [onProgressChange]
     */
    sampleSource: async function (reset, onProgressChange) {
        // we can only start the sampling if the data-source is ready
        await this._checkState('Sampling', ['ready']);
        return this._sampleSource(reset, onProgressChange);
    },
    _sampleSource: async function (reset, onProgressChange) {
        this.schemaSampler = new SchemaSampler(this.getSourceKey(), this.graph, onProgressChange);
        const schemaBuilders = await this.schemaSampler.sample();
        if (this.schemaSampler.isStopped) {
            // if sampling was stopped, we remove the reference to the schemaSampler and return
            this.schemaSampler = null;
            return;
        }
        await GraphSchemaService.updateSchema(this.getSourceKey(), EntityType.NODE, schemaBuilders.nodeSchemaBuilder, reset);
        await GraphSchemaService.updateSchema(this.getSourceKey(), EntityType.EDGE, schemaBuilders.edgeSchemaBuilder, reset);
        // sampling was successful
        this.state.samplingError = null;
        this.state.lastSampled = new Date();
        await this.state.save();
        this.schemaSampler = null;
    },
    /**
     * Sample the data-source.
     * Don't wait for the sampling to finish.
     *
     * @param {boolean} reset
     */
    asyncSampleSource: async function (reset) {
        // we can only start the sampling if the data-source is ready
        await this._checkState('Sampling', ['ready']);
        // note: we don't wait for the sampling to finish, we don't return this promise on purpose
        this.sampleSource(reset).catch(async (e) => {
            this.state.samplingError = e.message;
            await this.state.save();
            this.schemaSampler = null;
        }).catch(e => {
            Log.error('Couldn\'t save sampling error in data-source state', e.message);
        });
    },
    stopSampling: async function () {
        // we can only stop the sampling if the data-source is sampling
        await this._checkState('Stopping the sampling', ['discoveringSchema']);
        this.schemaSampler.stop();
    },
    /**
     * The hashed version of the value returned by `getSourceInfo`, shorter and non-human readable.
     * Used for API communication.
     *
     * The sourceKey actually identifies the data-source (a graph database on a specific server/port).
     * This ID is used to make accessRights and visualizations relative to a data-source.
     *
     * @param {boolean} [ignoreOffline] If true, won't throw an error if we cannot read the source info
     * @returns {string} an 8 char HEX string identifying a data-source uniquely.
     */
    getSourceKey: function (ignoreOffline) {
        if (this.sourceKeyCache === undefined) {
            if (Utils.hasValue(this.config.manualSourceKey)) {
                Utils.checkSourceKey(this.config.manualSourceKey, 'manualSourceKey');
                this.sourceKeyCache = this.config.manualSourceKey;
            }
            else {
                this.sourceKeyCache = DataSource.computeSourceKey(this.getSourceInfo(ignoreOffline));
            }
        }
        return this.sourceKeyCache;
    },
    /**
     * A string describing the data-source uniquely, as returned by DataSource.computeSourceInfo.
     *
     * @param {boolean} [ignoreOffline=false] If true, won't throw an error if we cannot read the source info
     * @returns {string|undefined} the long version of this data-source's unique identifier
     */
    getSourceInfo: function (ignoreOffline) {
        if (!this.storeId) {
            if (ignoreOffline) {
                return undefined;
            }
            throw Errors.technical('bug', 'DataSource.getSourceInfo called before storeId is set');
        }
        if (this.sourceInfoCache === undefined) {
            const hp = Utils.extractHostPort(this.config.graphdb.url);
            if (!hp) {
                throw Errors.business('invalid_parameter', 'Cannot extract host and port from graph URL (' + this.getSourceName() + ')');
            }
            this.sourceInfoCache = DataSource.computeSourceInfo(hp.host, hp.port, this.storeId);
        }
        return this.sourceInfoCache;
    },
    /**
     * Returns the name of the source (or a default generated name if config.name if not set).
     *
     * @returns {string}
     */
    getSourceName: function () {
        return 'data-source ' + (this.config.name
            ? ('"' + this.config.name + '"')
            : ('#' + this.sourceId));
    },
    /**
     * A display name for this source.
     *
     * @returns {string}
     */
    getDisplayName: function () {
        if (this.state && this.state.name) {
            return this.state.name;
        }
        else if (this.config.name) {
            return this.config.name;
        }
        else {
            return 'Database #' + this.sourceId;
        }
    },
    /**
     * @private
     * @param {boolean} initial whether this event is the initial connection or not
     * @param {boolean} good true if this is good news
     * @param {string} message
     */
    _onConnectionEvent: function (initial, good, message) {
        if (initial) {
            return;
        }
        Log[good ? 'info' : 'error'](message);
    },
    /**
     * @returns {Promise}
     * @private
     */
    _connectGraph: function () {
        const self = this;
        const name = self.getSourceName();
        const connect = () => {
            self.graphConnectError = null;
            return self.graph.connect().then(version => {
                self.graphVersion = version;
                // if a storeId is already set (reconnecting), check that it has not changed
                if (!self.storeId) {
                    return;
                }
                return self.getStoreId().then(storeId => {
                    if (self.storeId !== storeId) {
                        // reset also cancels the current graph connection promise
                        self._resetSource();
                        const message = 'Please retry connecting the data-source (the database has changed).';
                        return Errors.business('critical', message, true);
                    }
                });
            }).then(() => {
                self.graphConnected = true;
                self._onConnectionEvent(true, true, 'Connected to graph database (' + name + ')');
            }).catch(e => {
                self.graphConnectError = e.message ? e.message : 'Unknown error';
                return Promise.reject(e);
            });
        };
        const actionName = 'connecting to graph database (' + name + ')';
        const maxRetries = Config.get('advanced.connectionRetries', 5);
        const giveUp = error => (
        // used for bad credentials, inconsistent parameters
        error.key === 'invalid_parameter' ||
            // this version of the graph server is not supported: give up
            error.key === 'not_supported' ||
            // a user action is needed to allow this graph server to be used: give up
            error.key === 'source_action_needed' ||
            // there was a credentials error: give up
            error.message.includes('username and password') ||
            // the storeId has changed: give up
            error.message.includes('database has changed'));
        if (self.graphConnectPromise) {
            self.graphConnectPromise.cancel();
            self.graphConnectPromise = null;
        }
        return self.graphConnectPromise = Utils.retryPromise(actionName, connect, { delay: 5000, retries: maxRetries, giveUp: giveUp }).finally(() => {
            self.graphConnectPromise = null;
        });
    },
    /**
     * @returns {Promise}
     * @private
     */
    _connectIndex: function () {
        const self = this;
        const name = self.getSourceName();
        const connect = () => {
            self.indexConnectError = null;
            return self.index.connect().then(version => {
                self.indexVersion = version;
                self.indexConnected = true;
                self._onConnectionEvent(true, true, 'Connected to search index (' + name + ')');
                return Promise.resolve();
            }).catch(e => {
                self.indexConnectError = e.message ? e.message : 'Unknown error';
                return Promise.reject(e);
            });
        };
        const actionName = 'connecting to search index (' + name + ')';
        const retries = Config.get('advanced.connectionRetries', 5);
        if (self.indexConnectPromise) {
            self.indexConnectPromise.cancel();
            self.indexConnectPromise = null;
        }
        return self.indexConnectPromise = Utils.retryPromise(actionName, connect, {
            delay: 5000,
            retries: retries,
            giveUp: error => (
            // used for bad credentials, inconsistent parameters
            error.key === 'invalid_parameter' ||
                // this version of the index server is not supported: give up
                error.key === 'not_supported' ||
                // a user action is needed to allow this index server to be used: give up
                error.key === 'source_action_needed')
        }).finally(() => {
            self.indexConnectPromise = null;
        });
    },
    /**
     * Detect the store ID.
     * Can be called only once the Graph DAO is connected.
     *
     * @returns {Bluebird<String|LkError>}
     */
    getStoreId: function () {
        return this.graph.getStoreId();
    },
    /**
     * Check if a set of alternative IDs is legal for this data-source
     *
     * @param {object} alternativeIds
     * @param {string} [alternativeIds.node]
     * @param {string} [alternativeIds.edge]
     */
    checkAlternativeIdKeys: function (alternativeIds) {
        if (!alternativeIds) {
            return;
        }
        // if an alternative node ID was provided
        if (Utils.hasValue(alternativeIds.node)) {
            const configAltNodeId = this.config.graphdb.alternativeNodeId;
            if (Utils.noValue(configAltNodeId)) {
                // no alternative node ID is authorized
                throw Errors.business('invalid_parameter', `No alternative node ID is authorised for data-source #${this.sourceId}.`);
            }
            else if (configAltNodeId !== alternativeIds.node) {
                // wrong alternative node id
                throw Errors.business('invalid_parameter', `Alternative node ID "${alternativeIds.node}" should be "${configAltNodeId}".`);
            }
        }
        else {
            // todo: might not be needed, adding just be to sure
            // needed to prevent having an "null" value as alternative Node Id
            alternativeIds.node = undefined;
        }
        // if an alternative edge ID was provided
        if (Utils.hasValue(alternativeIds.edge)) {
            const configAltEdgeId = this.config.graphdb.alternativeEdgeId;
            if (Utils.noValue(configAltEdgeId)) {
                // no alternative edge ID is authorized
                throw Errors.business('invalid_parameter', `No alternative edge ID is authorised for data-source #${this.sourceId}.`);
            }
            else if (configAltEdgeId !== alternativeIds.edge) {
                // wrong alternative node id
                throw Errors.business('invalid_parameter', `Alternative edge ID "${alternativeIds.edge}" should be "${configAltEdgeId}".`);
            }
        }
        else {
            // todo: might not be needed, adding just be to sure
            // needed to prevent having an "null" value as alternative Edge Id
            alternativeIds.edge = undefined;
        }
    },
    /**
     * Since LKE v2.5.0, the styles format has been changed and the default styles and
     * captions have been moved from the configuration file to the data-source states so that they
     * can be configured per data-source.
     *
     * The `palette`, `defaultStyles`, `defaultCaptions` from the pre v2.5.0 configuration file
     * were temporarly saved in the `defaultStyles` field at the first boot of Linkurious 2.5.2.
     * This was done because to migrate the styles the data-source has to be connected.
     *
     * The `PreV2.5.0Config` flag indicates that the source state has still the old styles.
     * If the `PreV2.5.0Config` flag is there, migrate the styles to the new format and save
     * them in the source state.
     *
     * @param {SequelizeInstance<object>} sourceState
     * @returns {Bluebird<DataSourceState>}
     * @private
     */
    _migrateSourceStateStyles: function (sourceState) {
        if (Utils.noValue(sourceState.defaultStyles['PreV2.5.0Config'])) {
            return Promise.resolve(sourceState);
        }
        const { defaultStyles, defaultCaptions, palette } = sourceState.defaultStyles;
        return Promise.props({
            node: GraphSchemaService.getSchema(sourceState.key, EntityType.NODE),
            edge: GraphSchemaService.getSchema(sourceState.key, EntityType.EDGE)
        }).then(schema => {
            // 1) Migrate current styles
            // Auto color nodes by default
            return DesignUtils.migrateStyles(schema, defaultStyles, palette, true);
        }).then(migratedStyles => {
            // 2) Populate dataSourceState.defaultCaptions with current defaultCaptions
            //  - Populate dataSourceState.defaultStyles with the migrated styles
            sourceState.defaultCaptions = defaultCaptions;
            sourceState.defaultStyles = migratedStyles;
            return sourceState.save();
        });
    },
    /**
     * Called once the graph-provider is online, just before connecting to the index-provider.
     *
     * Detects/reads the store ID, then load the state of the current store.
     * Updates the 'lastSeen' field of the state.
     *
     * @returns {Promise}
     * @private
     */
    _initSource: function () {
        const self = this;
        return self.getStoreId().then(storeId => {
            self.storeId = storeId;
            // compute the sourceKey (caches the value)
            const sourceKey = self.getSourceKey();
            return Db.models.group.ensureBuiltins(sourceKey);
        }).then(() => {
            const sourceKey = self.getSourceKey();
            // check for other sources with the same key
            for (const source of this.dataService.sources) {
                if (source.sourceId === this.sourceId) {
                    continue;
                }
                if (source.isConnected() && source.getSourceKey() === sourceKey) {
                    // a different source with the same key exists
                    this._resetSource();
                    const message = 'This data-source is already configured once.';
                    this.graphConnectError = message;
                    return Promise.reject({ message: message });
                }
            }
            const whereAndValues = {
                where: { key: sourceKey },
                defaults: {
                    lastIndexed: null,
                    lastSampled: null,
                    info: self.getSourceInfo(),
                    lastSeen: new Date(),
                    name: self.config.name,
                    graphVendor: this.config.graphdb.vendor,
                    indexVendor: this.config.index.vendor,
                    needReindex: false,
                    defaultCaptions: DesignUtils.DEFAULT_CAPTIONS,
                    defaultStyles: DesignUtils.DEFAULT_STYLES
                }
            };
            // find (or create if never seen before) the data-source state entry in DB
            return Db.models.dataSourceState.findOrCreate(whereAndValues).spread((state, isNew) => {
                self.state = state;
                // if the state is not new
                if (!isNew) {
                    const update = {};
                    // update the lastSeen field
                    update.lastSeen = new Date();
                    // update the data-source name
                    if (self.config.name) {
                        update.name = self.config.name;
                    }
                    // if the index vendor has changed, require a re-index
                    const currentIndexVendor = state.indexVendor || 'elasticSearch';
                    if (currentIndexVendor !== this.config.index.vendor) {
                        update.needReindex = true;
                        update.indexationError = 'The index vendor was changed, please re-index.';
                    }
                    // remember vendors
                    update.indexVendor = this.config.index.vendor;
                    update.graphVendor = this.config.graphdb.vendor;
                    return state.updateAttributes(update);
                }
            });
        }).catch(Errors.LkError, error => {
            // keep the error message for client display
            this.indexConnectError = error.message;
            return Promise.reject(error);
        });
    },
    /**
     * Update the source options.
     *
     * @param {DataSourceOptions} options
     * @returns {Bluebird<void>}
     */
    updateOptions: function (options) {
        this.state.options = options;
        return this.state.save().return();
    },
    /**
     * Return the source options.
     *
     * @returns {DataSourceOptions}
     */
    getOptions: function () {
        return this.state.options;
    },
    /**
     * Returns true if the source's index-mapping has changed since last indexation
     *
     * @returns {boolean} true if the source needs to be re-indexed.
     */
    needReindex: function () {
        return this.state.needReindex;
    },
    /**
     * Returns true if the source has NEVER been indexed before.
     *
     * @returns {boolean} true if this source has never been indexed before
     */
    needFirstIndex: function () {
        return !this.state.lastIndexed;
    },
    /**
     * Check if no index mapping has been configured.
     *
     * @returns {boolean} true if none of the index mapping has been set
     */
    needConfig: function () {
        if (this.index.features.external) {
            return false;
        }
        return Utils.noValue(this.state.noIndexNodeProperties) &&
            Utils.noValue(this.state.noIndexEdgeProperties);
    },
    /**
     * - Sets an index mapping field (if unset), in order to disable the `needConfig` check.
     * - Sets needReindex to true if already indexed before
     * - Save the state
     *
     * @returns {Promise}
     * @private
     */
    _setStateBeforeIndexing: function () {
        // disable needConfig
        if (Utils.noValue(this.state.noIndexNodeProperties)) {
            this.state.noIndexNodeProperties = [];
        }
        // if not indexing for the first time, remember that indexing is unfinished
        if (!this.needFirstIndex()) {
            // Set need-reindex to true here, set to false when the indexation is done.
            // This persist the fact that an indexation is needed, even if the indexation fails.
            this.state.needReindex = true;
        }
        this.state.indexationError = 'The indexation was launched but did not complete.';
        return this.state.save();
    },
    /**
     * Set the 'lastIndexed' of this dataSource state to now and 'needReindex' to false.
     *
     * @returns {Promise}
     * @private
     */
    _setIndexationSuccess: function () {
        this.state.lastIndexed = new Date();
        this.state.needReindex = false;
        this.state.indexationError = null;
        return this.state.save();
    },
    /**
     * Persist the indexation error in the state and save the state
     *
     * @param {*} error
     * @returns {Promise}
     * @private
     */
    _setIndexationError: function (error) {
        if (error === undefined || null) {
            error = 'Unknown error';
        }
        else if (typeof (error) !== 'string') {
            if (error.message) {
                error = error.message;
            }
            else if (typeof (error) === 'object') {
                error = JSON.stringify(error);
            }
            else {
                error = error + '';
            }
        }
        this.state.indexationError = error
            ? (error.message ? error.message : error + '')
            : 'Unknown error during indexation.';
        return this.state.save();
    },
    /**
     * @returns {string[]}
     */
    getNoIndexNodeProperties: function () {
        let noIndex = this.state.noIndexNodeProperties;
        if (Utils.noValue(noIndex)) {
            noIndex = [];
        }
        return _.sortedUniq(noIndex.sort());
    },
    /**
     * @param {string[]} noIndex
     * @returns {Promise}
     */
    setNoIndexNodeProperties: function (noIndex) {
        const self = this;
        if (this.index.features.external) {
            return Promise.resolve();
        }
        return self._checkNeedReindex('node', noIndex).then(() => {
            self.state.noIndexNodeProperties = noIndex;
            return self.state.save();
        });
    },
    /**
     * @returns {string[]}
     */
    getNoIndexEdgeProperties: function () {
        let noIndex = this.state.noIndexEdgeProperties;
        if (Utils.noValue(noIndex)) {
            noIndex = [];
        }
        return _.sortedUniq(noIndex.sort());
    },
    /**
     * @param {string[]} noIndex
     * @returns {Promise}
     */
    setNoIndexEdgeProperties: function (noIndex) {
        const self = this;
        if (this.index.features.external) {
            return Promise.resolve();
        }
        return self._checkNeedReindex('edge', noIndex).then(() => {
            self.state.noIndexEdgeProperties = noIndex;
            return self.state.save();
        });
    },
    /**
     * Check if the current state if one of the legal states. Returns a rejected promise if not.
     *
     * @param {string} actionName the name oif the action (to create the error message)
     * @param {string[]} legalStates the list of states that are allowed
     * @param {boolean} [justWarn=false] if true, will no reject the promise but just log a warning
     * @returns {Bluebird<boolean|LkError>}
     * @private
     */
    _checkState: function (actionName, legalStates, justWarn) {
        const state = this.getState().code;
        let message = '';
        let ok = true;
        if (!_.includes(legalStates, state)) {
            message = '"' + actionName + '" requires the data-source to be in one of these states: ' +
                legalStates + ' (current state: ' + state + ')';
            ok = false;
        }
        if (!ok) {
            if (justWarn) {
                Log.warn(message);
            }
            else {
                return Errors.business('illegal_source_state', message, true);
            }
        }
        return Promise.resolve(ok);
    },
    /**
     * Detect actual changes in the index mapping and request a re-index when changes happen.
     *
     * @param {string} type (node or edge)
     * @param {string[]|null} newNoIndex new no-index values (or null if no changes were made)
     * @returns {Bluebird<undefined|LkError>}
     *
     * @private
     */
    _checkNeedReindex: function (type, newNoIndex) {
        // check if the source state allow this change right now
        const self = this;
        const legalStates = ['ready', 'needConfig', 'needFirstIndex', 'needReindex'];
        return self._checkState('Updating the index-mapping', legalStates).then(() => {
            if (newNoIndex !== null && !Array.isArray(newNoIndex)) {
                return Errors.business('invalid_parameter', 'Not-indexed ' + type + ' properties must be an array', true);
            }
            // compute the changes that will happen
            const t = _.startCase(type);
            const currentSkipIndex = self['getNoIndex' + t + 'Properties'](true);
            const nextSkipIndex = newNoIndex || self['getNoIndex' + t + 'Properties'](false);
            // differences = added + removed
            const differences = _.union(_.difference(currentSkipIndex, nextSkipIndex), // added
            _.difference(nextSkipIndex, currentSkipIndex) // removed
            );
            // set the re-index flag if the mapping is going to change
            if (differences.length > 0) {
                self.state.needReindex = true;
            }
        });
    },
    /**
     * Filter hidden properties from a node or an array of nodes
     *
     * @param {LkNode|LkNode[]} nodeOrNodes Node (or array thereof)
     * @param {boolean} [filterNoIndex=false] filter NoIndex properties as well
     * @returns {LkNode|LkNode[]}
     */
    filterNodeProperties: function (nodeOrNodes, filterNoIndex) {
        nodeOrNodes = Utils.clone(nodeOrNodes);
        if (!nodeOrNodes) {
            return nodeOrNodes;
        }
        const filter = filterNoIndex ? this.getNoIndexNodeProperties() : [];
        if (Array.isArray(nodeOrNodes)) {
            for (let i = 0; i < nodeOrNodes.length; ++i) {
                nodeOrNodes[i].data = _.omit(nodeOrNodes[i].data, filter);
            }
        }
        else {
            nodeOrNodes.data = _.omit(nodeOrNodes.data, filter);
        }
        return nodeOrNodes;
    },
    /**
     * Filter hidden properties from an edge or an array of edges
     *
     * @param {LkEdge|LkEdge[]} edgeOrEdges Edge (or array thereof)
     * @param {boolean} [filterNoIndex=false] filter NoIndex properties as well
     * @returns {LkEdge|LkEdge[]}
     */
    filterEdgeProperties: function (edgeOrEdges, filterNoIndex) {
        edgeOrEdges = Utils.clone(edgeOrEdges);
        if (!edgeOrEdges) {
            return edgeOrEdges;
        }
        const filter = filterNoIndex ? this.getNoIndexEdgeProperties() : [];
        if (Array.isArray(edgeOrEdges)) {
            for (let i = 0; i < edgeOrEdges.length; ++i) {
                edgeOrEdges[i].data = _.omit(edgeOrEdges[i].data, filter);
            }
        }
        else {
            edgeOrEdges.data = _.omit(edgeOrEdges.data, filter);
        }
        return edgeOrEdges;
    },
    /**
     * @private
     */
    _initGraphDAO: function () {
        if (this.graph) {
            return;
        }
        try {
            this.graph = GraphDAO.createGraphDAOInstance(this.config.graphdb.vendor, this.config.graphdb);
        }
        catch (e) {
            if (e instanceof Errors.LkError) {
                Log.error(e.message);
                this.graphConnectError = e.message;
            }
            throw e;
        }
    },
    /**
     * Called once the graphDAO is initialized and connected.
     *
     * @private
     */
    _initIndexDAO: function () {
        if (this.index) {
            return;
        }
        try {
            this.index = IndexDAO.createIndexDAOInstance(this.config.index.vendor, this.config.index, this.graph);
        }
        catch (e) {
            if (e instanceof Errors.LkError) {
                this.indexConnectError = e.message;
            }
            throw e;
        }
    },
    /**
     * @throws {LkError} if the source is not ready
     */
    assertReady: function () {
        if (this.getState().code !== 'ready') {
            throw Errors.business('dataSource_unavailable', 'Data-source #' + this.sourceId + ' is not ready.');
        }
    },
    /**
     * Checks if the graph or index config have changed
     *
     * @returns {boolean} whether the graph or index config have changed
     * @private
     */
    _configChanged: function () {
        const original = _.pick(this.config, ['index', 'graphdb']);
        const current = Config.get('dataSources.' + this.sourceId);
        const diff = Utils.objectDiff(original, current, { 'root.index.indexName': true });
        if (diff.length > 0) {
            Log.info('configuration of data-source #' + this.sourceId + ' has changed.');
        }
        return diff.length > 0;
    },
    isReadOnly: function () {
        return !!this.config.readOnly;
    },
    /**
     * Inverse of _initSource (more or less):
     * - forget StoreID
     * - forget state
     * - unset Graph DAO instance
     * - unset Index DAO instance
     *
     * @param {boolean} [forceDestroy=false] Force destroying (don't rebuild)
     * @private
     */
    _resetSource: function (forceDestroy) {
        this.config = Config.get('dataSources.' + this.sourceId);
        this.sourceInfoCache = undefined;
        this.sourceKeyCache = undefined;
        this.destroyed = false;
        // stop polling
        this._pollGraphState.promise = null;
        if (this._pollGraphState.timer) {
            clearTimeout(this._pollGraphState.timer);
        }
        this._pollIndexState.promise = null;
        if (this._pollIndexState.timer) {
            clearTimeout(this._pollIndexState.timer);
        }
        // disconnect graph and/or index
        this.disconnect();
        // reset connection state
        this.graphConnected = false;
        if (this.graphConnectPromise) {
            this.graphConnectPromise.cancel();
            this.graphConnectPromise = null;
        }
        this.graphConnectError = null;
        this.indexConnected = false;
        if (this.indexConnectPromise) {
            this.indexConnectPromise.cancel();
            this.indexConnectPromise = null;
        }
        this.indexConnectError = null;
        // forget DAOs
        this.graph = undefined;
        this.index = undefined;
        // set after connection
        this.indexVersion = 'unknown';
        this.graphVersion = 'unknown';
        this.storeId = undefined;
        this.state = undefined;
        this.indexingProgress = null;
        this.schemaSampler = null;
        if (forceDestroy) {
            this.destroyed = true;
        }
        else if (!this.config) {
            this.destroyed = true;
            throw Errors.business('invalid_parameter', 'data-source #' + this.sourceId + ' does not exists anymore (missing configuration).');
        }
    },
    /**
     * Destroy this data-source
     */
    destroy: function () {
        this._resetSource(true);
    },
    /**
     * Will safely disconnect what needs to be disconnected.
     * Don't worry, this does not throw in case of failure.
     */
    disconnect() {
        if (this.graph) {
            this.graph.disconnect();
        }
        if (this.index) {
            this.index.disconnect();
        }
    },
    /**
     * Connect (or reconnect) to a disconnected data-source
     *
     * @param {boolean} [ignoreErrors=false] whether to catch promise rejections and ignore them
     * @returns {Promise}
     */
    connect: function (ignoreErrors) {
        const self = this;
        const configChanged = this._configChanged();
        // offline, connecting, needConfig, needFirstIndex, needReindex, ready
        const legalStates = configChanged
            ? ['offline', 'connecting', 'needConfig', 'needFirstIndex', 'needReindex', 'ready']
            : ['offline'];
        return self._checkState('Connecting', legalStates, true).then(ok => {
            if (!ok) {
                return;
            }
            if (configChanged) {
                // make the data-source new and fresh again
                self._resetSource();
            }
            return Promise.resolve().then(() => {
                self._initGraphDAO();
                self._connecting = true;
            }).then(() => {
                return self._connectGraph();
            }).then(() => {
                /**
                 * we must init the source _after_ connecting to the graph but _before_ connecting to the
                 * index because we need to detect the storeId from the graph in some cases, and the store Id
                 * is needed to decide to which index we will to connect to.
                 */
                return self._initSource();
            }).then(() => {
                // set the name of the index to connect to in IndexDAO configuration
                self.config.index.indexName = 'linkurious_' + self.getSourceKey();
                self._initIndexDAO();
                return self._connectIndex();
            }).then(() => {
                // start polling graph and index regularly once the both are connected
                self._onConnect();
            }).then(() => {
                return this._migrateSourceStateStyles(self.state);
            }).then(() => {
                // source connected successfully
                Log.info('Data-source #%s connected successfully (graph:%s v%s - index:%s v%s)', self.sourceId, self.config.graphdb.vendor, self.graphVersion, self.config.index.vendor, self.indexVersion);
            }).catch(error => {
                const indexConfig = self.config.index;
                const graphConfig = self.config.graphdb;
                // source could not connect
                const indexURL = Utils.hasValue(indexConfig.host)
                    ? `http${indexConfig.https ? 's' : ''}://${indexConfig.host}:${indexConfig.port}`
                    : '-';
                const message = error instanceof LkError ? error.message : error;
                // print the stack only if it's a technical error
                const stack = error instanceof LkError && error.isTechnical() ? error.stack : undefined;
                Log.warn('Data-source #%s could not connect (%s: %s / %s: %s): %s', self.sourceId, graphConfig.vendor, graphConfig.url, indexConfig.vendor, indexURL, message, stack);
                Log.debug('Data-source connection error: ', error);
                if (ignoreErrors) {
                    return;
                }
                return Promise.reject(error);
            }).finally(() => {
                self._connecting = false;
            });
        });
    },
    /**
     * Get the status of the search for this data-source.
     * State: "ongoing", "needed", "done", "unknown".
     *
     * @returns {Bluebird<{
     *   indexing:string,
     *   indexing_progress:string,
     *   indexing_status:string,
     *   node_count:number,
     *   edge_count:number,
     *   index_size:number,
     *   indexed_source:string
     * }>}
     */
    getSearchStatus: function () {
        const indexedSourceKey = this.dataService.getIndexedSource();
        // offline, connecting, needConfig, needFirstIndex, needReindex, ready
        const stateCode = this.getState().code;
        // ongoing
        if (stateCode === 'indexing') {
            return Promise.resolve({
                indexing: 'ongoing',
                'indexing_progress': this.indexingProgress.getPercent(),
                'indexing_status': this.indexingProgress.getStatus(),
                'node_count': this.nodeCountCache,
                'edge_count': this.edgeCountCache,
                'index_size': this.indexingProgress.getTotalIndexedItems(),
                'indexed_source': indexedSourceKey
            });
        }
        // needed
        if (stateCode === 'needConfig' || stateCode === 'needFirstIndex' || stateCode === 'needReindex') {
            return Promise.resolve({
                indexing: 'needed',
                'indexing_progress': null,
                'indexing_status': 'The database needs to be indexed.',
                'node_count': null,
                'edge_count': null,
                'index_size': null,
                'indexed_source': indexedSourceKey
            });
        }
        // done
        if (stateCode === 'ready') {
            return Promise.resolve({
                indexing: 'done',
                'indexing_progress': null,
                'indexing_status': 'The database is fully indexed.',
                'node_count': null,
                'edge_count': null,
                'index_size': null,
                'indexed_source': indexedSourceKey
            });
        }
        // unknown
        return Promise.resolve({
            indexing: 'unknown',
            'indexing_progress': null,
            'indexing_status': 'Unknown indexation status.',
            'node_count': null,
            'edge_count': null,
            'index_size': null,
            'indexed_source': indexedSourceKey
        });
    },
    /**
     * @type {LkDataSourceFeatures}
     */
    get features() {
        if (!this.graph || !this.index) {
            return {};
        }
        //noinspection PointlessBooleanExpressionJS
        return {
            // look at the typedef of LkDataSourceFeatures for the meaning of these features
            edgeProperties: !!this.graph.features.edgeProperties,
            immutableNodeCategories: !!this.graph.features.immutableNodeCategories,
            maxNodeCategories: this.graph.features.maxNodeCategories,
            canCount: !!this.graph.features.canCount || !!this.index.features.canCount,
            canCountBeforeIndexation: !!this.graph.features.canCount,
            alerts: !!this.graph.features.alerts,
            dialects: this.graph.features.dialects,
            externalIndex: !!this.index.features.external,
            alternativeIds: !!this.graph.features.alternativeIds,
            canIndexEdges: !!this.index.features.canIndexEdges,
            searchHitsCount: this.index.features.searchHitsCount,
            canDryRun: this.graph.features.canDryRun,
            supportNativeDate: this.graph.features.supportNativeDate
        };
    },
    /**
     * Start polling the graph and Index DAO to detect source disconnection.
     *
     * @private
     */
    _onConnect: function () {
        this._pollGraph();
        this._pollIndex();
    },
    /**
     * Checks the state of the index:
     * - if already checking, uses the promise of the ongoing check
     * - schedules the next check
     * - returns a promise of the check
     *
     * @param {boolean} [pollIfIndexing=false]
     * @returns {Promise}
     * @private
     */
    _pollGraph: function (pollIfIndexing) {
        const self = this;
        // stop polling if we are currently connecting (poll will restart after connect)
        if (self.graphConnectPromise) {
            return Promise.resolve();
        }
        if (self.destroyed || !self.graph) {
            self.graphConnected = false;
            return Promise.resolve();
        }
        // return the existing promise if we are already checking the state
        if (self._pollGraphState.promise) {
            return self._pollGraphState.promise;
        }
        // already scheduled, un-schedule
        if (self._pollGraphState.timer) {
            clearTimeout(self._pollGraphState.timer);
        }
        const reschedule = () => {
            self._pollGraphState.timer = setTimeout(() => {
                self._pollGraph();
            }, self.pollIntervalMillis);
        };
        // don't check the state of the graph/index while indexing
        if (self.isIndexing() && !pollIfIndexing) {
            reschedule();
            return Promise.resolve();
        }
        const name = self.getSourceName();
        Log.debug('polling graph database: ' + name);
        self._pollGraphState.promise = self.graph.checkUp().then(() => {
            reschedule();
        }).catch(() => {
            self.graphConnected = false;
            self._onConnectionEvent(false, false, `Lost connection to graph database ${name}`);
            return self._connectGraph().then(() => {
                self._onConnectionEvent(false, true, `Restored connection to graph database ${name}`);
                reschedule();
            }).catch(() => {
                // swallow error when reconnect fails and we give up
            });
        }).finally(() => {
            self._pollGraphState.promise = null;
        });
        return self._pollGraphState.promise;
    },
    /**
     * Checks the state of the index:
     * - if already checking, uses the promise of the ongoing check
     * - schedules the next check
     * - returns a promise of the check
     *
     * @param {boolean} [pollIfIndexing=false]
     * @returns {Promise}
     * @private
     */
    _pollIndex: function (pollIfIndexing) {
        const self = this;
        // stop polling if we are currently connecting (poll will restart after connect)
        if (self.indexConnectPromise) {
            return Promise.resolve();
        }
        if (self.destroyed || !self.index) {
            self.indexConnected = false;
            return Promise.resolve();
        }
        // return the existing promise if we are already checking the state
        if (self._pollIndexState.promise) {
            return self._pollIndexState.promise;
        }
        // already scheduled, un-schedule
        if (self._pollIndexState.timer) {
            clearTimeout(self._pollIndexState.timer);
        }
        const reschedule = () => {
            self._pollIndexState.timer = setTimeout(() => {
                self._pollIndex();
            }, self.pollIntervalMillis);
        };
        // don't check the state of the index while indexing
        if (self.isIndexing() && !pollIfIndexing) {
            reschedule();
            return Promise.resolve();
        }
        const name = self.getSourceName();
        Log.debug('polling search index: ' + name);
        self._pollIndexState.promise = self.index.checkUp().then(() => {
            reschedule();
        }).catch(() => {
            self.indexConnected = false;
            self._onConnectionEvent(false, false, 'Lost connection to search index (' + name + ')');
            return self._connectIndex().then(() => {
                self._onConnectionEvent(false, true, 'Restored connection to search index (' + name + ')');
                reschedule();
            }).catch(() => {
                // swallow error when reconnect fails and we give up
            });
        }).finally(() => {
            self._pollIndexState.promise = null;
        });
        return self._pollIndexState.promise;
    },
    /**
     * Update the source index/schema.
     *
     * @returns {Promise}
     */
    indexSource: function () {
        return Promise.resolve().then(() => {
            if (!this.index.features.external) {
                return this._indexSource();
            }
            else {
                return this._externalIndexSource();
            }
        });
    },
    /**
     * Get the last edit date of a node/edge if available.
     * Otherwise, return `undefined`.
     *
     * @param {string} itemType "node" or "edge"
     * @param {string} itemId   ID of the node/edge
     * @returns {number | undefined}
     */
    getLastEditDate: function (itemType, itemId) {
        return this._lastEditDateMap.get(itemType + ':' + itemId);
    },
    /**
     * Update the last edit date of a node/edge to the current time.
     *
     * @param {string} itemType   "node" or "edge"
     * @param {string} itemId     ID of the node/edge
     * @returns {number} The date at which the data was changed
     */
    updateLastEditDate: function (itemType, itemId) {
        const changeDate = Date.now();
        this._lastEditDateMap.set(itemType + ':' + itemId, changeDate);
        return changeDate;
    },
    /**
     * Set defaultStyles and defaultCaptions of the current DataSource.
     *
     * @param {VisualizationStyleSheet} [defaultStyles]
     * @param {VisualizationCaptions}   [defaultCaptions]
     * @returns {Bluebird<void>}
     */
    setDesignDefaults: function (defaultStyles, defaultCaptions) {
        if (Utils.hasValue(defaultStyles)) {
            VisualizationChecker.checkStyles('styles', defaultStyles);
            this.state.defaultStyles = defaultStyles;
        }
        if (Utils.hasValue(defaultCaptions)) {
            VisualizationChecker.checkCaptions('captions', defaultCaptions);
            this.state.defaultCaptions = defaultCaptions;
        }
        return this.state.save().return();
    },
    /**
     * Update the graph schema from the index.
     *
     * @returns {Promise}
     * @private
     */
    _externalIndexSource: function () {
        const states = ['needFirstIndex', 'needReindex', 'ready'];
        return this._checkState('Indexing', states).then(() => {
            // create the indexing progress reporter
            this.indexingProgress = new Progress(Log, this.getSourceName() + ':');
            return this._setStateBeforeIndexing();
        }).then(() => {
            // don't index edges if not supported by the index or if explicitly skipped in the index options
            const skipEdges = this.index.getOption('skipEdgeIndexation', false) ||
                this.index.features.canIndexEdges === false;
            return Promise.props({
                // count the nodes in graph
                nodeCount: this.graph.features.canCount
                    ? this.graph.getNodeCount(true)
                    : Promise.resolve(DEFAULT_PROGRESS_BAR_SIZE),
                // count the edges in graph
                edgeCount: skipEdges
                    ? 0
                    : this.graph.features.canCount
                        ? this.graph.getEdgeCount(true)
                        : Promise.resolve(DEFAULT_PROGRESS_BAR_SIZE)
            });
        }).then(async (results) => {
            this.indexingProgress.start(results.nodeCount + results.edgeCount, true);
            this.nodeCountCache = results.nodeCount;
            this.edgeCountCache = results.edgeCount;
            Log.info('Start sampling.');
            await this._sampleSource(false, samplingProgress => {
                this.indexingProgress.setSamplingPercentage(samplingProgress);
            });
            this.indexingProgress.endSampling();
            const strict = this.getOptions().strictSchema;
            const freshSchema = {
                node: await GraphSchemaService.getSearchableSchema(this.getSourceKey(), EntityType.NODE, strict),
                edge: await GraphSchemaService.getSearchableSchema(this.getSourceKey(), EntityType.EDGE, strict)
            };
            Log.info(`Refreshing source ${this.getSourceName()} external index (if required)`);
            return this.index.indexSource(this.indexingProgress, freshSchema);
        }).then(() => {
            this.indexingProgress.end();
        }).then(() => {
            // we signal the GraphDAO and the IndexDAO that the indexation is at the end, so it can perform additional tasks
            return this.graph.onAfterIndexation();
        }).then(() => {
            return this.index.onAfterIndexation();
        }).then(() => {
            // set the indexation date in state
            return this._setIndexationSuccess();
        }).catch(error => {
            // capture the indexation error
            return this._setIndexationError(error).then(() => {
                return Promise.reject(error);
            });
        }).finally(() => {
            this.indexingProgress = null;
        });
    },
    /**
     * Cleans the search-index, reads the whole graph database and writes it to search-index.
     *
     * @returns {Promise}
     */
    _indexSource: function () {
        const self = this;
        // initialize some useful variables
        let sourceKey;
        /**
         * @type {GraphDAO}
         */
        const graph = self.graph;
        /**
         * @type {IndexDAO}
         */
        const index = self.index;
        const nodeSchemaBuilder = new SchemaBuilder();
        const edgeSchemaBuilder = new SchemaBuilder();
        // don't index edges if not supported by the index or if explicitly skipped in the index options
        const skipEdges = this.index.getOption('skipEdgeIndexation', false);
        const chunkSize = Config.get('advanced.indexationChunkSize', 5000);
        const isBusinessError = err => {
            return Errors.LkError.isBusinessType(err.type) && err.key !== 'graph_request_timeout';
        };
        const legalStates = ['ready', 'needConfig', 'needFirstIndex', 'needReindex'];
        return self._checkState('Indexing', legalStates).then(() => {
            // create the indexing progress reporter
            self.indexingProgress = new Progress(Log, self.getSourceName() + ':');
            // initialize some useful variables
            sourceKey = self.getSourceKey();
            return graph.onInternalIndexation();
        }).then(() => {
            return self._setStateBeforeIndexing();
        }).then(() => {
            return Promise.props({
                // empty the ES index
                clear: index.clear(),
                // count the nodes in graph
                nodeCount: graph.features.canCount
                    ? graph.getNodeCount(true)
                    : Promise.resolve(DEFAULT_PROGRESS_BAR_SIZE),
                // count the edges in graph
                edgeCount: skipEdges
                    ? 0
                    : graph.features.canCount
                        ? graph.getEdgeCount(true)
                        : Promise.resolve(DEFAULT_PROGRESS_BAR_SIZE)
            });
        }).then(results => {
            Log.info(`Start indexation of ${results.nodeCount} nodes and ${results.edgeCount} edges.`);
            self.indexingProgress.start(results.nodeCount + results.edgeCount);
            self.nodeCountCache = results.nodeCount;
            self.edgeCountCache = results.edgeCount;
            // Index Nodes
            let indexedNodes = 0;
            const ingestNodesChunk = nodes => {
                // add to index (we first filter away properties we don't want to index)
                nodes = nodes.map(node => {
                    nodeSchemaBuilder.addItem(node.categories, node.data);
                    return this.filterNodeProperties(node, true);
                });
                return index.addEntries('node', nodes).then(() => {
                    indexedNodes += nodes.length;
                    self.indexingProgress.add('node', nodes);
                });
            };
            const indexNodes = () => {
                if (indexedNodes > 0) {
                    Log.info('Trying to resume nodes indexation at offset ' + indexedNodes);
                }
                // stream nodes and ingest them into the index
                return streamNodes(graph, ingestNodesChunk, chunkSize, indexedNodes);
            };
            return Utils.retryPromise('Index nodes', indexNodes, {
                delay: 15 * 1000,
                retries: self.indexationRetries,
                giveUp: isBusinessError
            }).then(() => {
                // reset the node schema
                return GraphSchemaService.updateSchema(sourceKey, EntityType.NODE, nodeSchemaBuilder);
            });
        }).then(() => {
            if (skipEdges) {
                // skip edge indexation
                return;
                // TODO #918 we need edge schema also with internal indices when edges are not indexed
            }
            // Index edges
            let indexedEdges = 0;
            const ingestEdgesChunk = edges => {
                // add to index (we first filter away properties we don't want to index)
                edges = edges.map(edge => {
                    // add to schema builder
                    edgeSchemaBuilder.addItem([edge.type], edge.data);
                    return this.filterEdgeProperties(edge, true);
                });
                return index.addEntries('edge', edges).then(() => {
                    indexedEdges += edges.length;
                    self.indexingProgress.add('edge', edges);
                });
            };
            const indexEdges = () => {
                if (indexedEdges > 0) {
                    Log.info('Trying to resume edges indexation at offset ' + indexedEdges);
                }
                // stream edges and ingest them into the index
                return streamEdges(graph, ingestEdgesChunk, chunkSize, indexedEdges);
            };
            return Utils.retryPromise('Index edges', indexEdges, {
                delay: 15 * 1000,
                retries: self.indexationRetries,
                giveUp: isBusinessError
            }).then(() => {
                // reset the edge schema
                return GraphSchemaService.updateSchema(sourceKey, EntityType.EDGE, edgeSchemaBuilder);
            });
        }).then(() => {
            self.indexingProgress.end();
        }).then(() => {
            // commit the updated index
            Log.info('Flushing index data to disk ...');
            return index.commit();
        }).then(() => {
            // we signal the IndexDAO that the indexation is at the end, so it can perform additional tasks
            return this.index.onAfterIndexation();
        }).then(() => {
            return self._setIndexationSuccess();
        }).catch(error => {
            // capture the indexation error
            return self._setIndexationError(error).then(() => {
                // if the indexation failed, recheck the state of the graph and index
                // in case then went offline (polling never rejects)
                return self._pollGraph(true);
            }).then(() => {
                return self._pollIndex(true);
            }).then(() => {
                // then, reject the indexation promise with the indexation error
                return Promise.reject(error);
            });
        }).finally(() => {
            self.indexingProgress = null;
        });
    }
};
// private static methods
/**
 * Read nodes stream and ingest them (write them to index)
 *
 * @param {object} graph
 * @param {function} ingestNodes
 * @param {number} chunkSize
 * @param {number} offset
 * @returns {Promise}
 * @private
 */
function streamNodes(graph, ingestNodes, chunkSize, offset) {
    return graph.getNodeStream({ offset: offset, chunkSize: chunkSize }).then(nodeStream => {
        return new Promise((resolve, reject) => {
            let nodesBuffer = [];
            const purgeBufferAndResume = () => {
                nodesBuffer = [];
                nodeStream.resume();
            };
            nodeStream.on('data', lkNode => {
                // add node to buffer
                nodesBuffer.push(lkNode);
                // if the buffer is full, write to elasticSearch
                if (nodesBuffer.length >= chunkSize) {
                    nodeStream.pause();
                    ingestNodes(nodesBuffer).then(purgeBufferAndResume, error => {
                        Log.error('Indexing nodes: ingest failed.', error);
                        reject(error);
                    });
                }
            }).on('end', () => {
                ingestNodes(nodesBuffer).then(resolve, error => {
                    Log.error('Indexing nodes: last ingest failed.', error);
                    reject(error);
                });
            }).on('error', error => {
                Log.error('Indexing nodes: stream error.', error);
                reject(error);
            }).resume();
        });
    });
}
/**
 * Read the edge stream and ingest it
 *
 * @param {object} graph
 * @param {function} ingestEdges
 * @param {number} chunkSize
 * @param {number} offset (to start indexing edges at a given offset from first edge)
 * @returns {Promise}
 * @private
 */
function streamEdges(graph, ingestEdges, chunkSize, offset) {
    return graph.getEdgeStream({ offset: offset, chunkSize: chunkSize }).then(edgeStream => {
        return new Promise((resolve, reject) => {
            let edgesBuffer = [];
            const purgeBufferAndResume = () => {
                edgesBuffer = [];
                edgeStream.resume();
            };
            edgeStream.on('data', lkEdge => {
                // add edge to buffer
                edgesBuffer.push(lkEdge);
                // if the buffer is full, write to elasticSearch
                if (edgesBuffer.length >= chunkSize) {
                    edgeStream.pause();
                    ingestEdges(edgesBuffer).then(purgeBufferAndResume, error => {
                        Log.error('Indexing edges: ingest failed.', error);
                        reject(error);
                    });
                }
            }).on('end', () => {
                ingestEdges(edgesBuffer).then(resolve, error => {
                    Log.error('Indexing edges: last ingest failed.', error);
                    reject(error);
                });
            }).on('error', error => {
                Log.error('Indexing edges: stream error.', error);
                reject(error);
            }).resume();
        });
    });
}
// export DataSource object
Object.seal(DataSource);
module.exports = DataSource;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGF0YVNvdXJjZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9zZXJ2aWNlcy9kYXRhL2RhdGFTb3VyY2UuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7O0dBUUc7QUFDSCxZQUFZLENBQUM7QUFFYixNQUFNLEVBQUUsYUFBYSxFQUFFLEdBQUcsT0FBTyxDQUFDLHdCQUF3QixDQUFDLENBQUM7QUFDNUQsTUFBTSxFQUFDLFVBQVUsRUFBQyxHQUFHLE9BQU8sQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO0FBQ3hELE1BQU0sTUFBTSxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNqQyxNQUFNLENBQUMsR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDNUIsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3BDLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNoQyxNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzdCLE1BQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDdEMsTUFBTSxFQUFFLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzFCLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLGtCQUFrQixHQUFHLEdBQUcsQ0FBQyxjQUFjLEVBQUUsQ0FBQztBQUNoRCxNQUFNLEVBQUUsUUFBUSxFQUFFLEdBQUcsT0FBTyxDQUFDLDBCQUEwQixDQUFDLENBQUM7QUFDekQsTUFBTSxFQUFFLFFBQVEsRUFBRSxHQUFHLE9BQU8sQ0FBQywwQkFBMEIsQ0FBQyxDQUFDO0FBQ3pELE1BQU0sRUFBRSxhQUFhLEVBQUUsR0FBRyxPQUFPLENBQUMsd0JBQXdCLENBQUMsQ0FBQztBQUM1RCxNQUFNLFFBQVEsR0FBRyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDdkMsTUFBTSxTQUFTLEdBQUcsT0FBTyxDQUFDLHdCQUF3QixDQUFDLENBQUM7QUFDcEQsTUFBTSxvQkFBb0IsR0FBRyxPQUFPLENBQUMsa0NBQWtDLENBQUMsQ0FBQztBQUN6RSxNQUFNLFdBQVcsR0FBRyxPQUFPLENBQUMseUJBQXlCLENBQUMsQ0FBQztBQUN2RCxNQUFNLEVBQUMsT0FBTyxFQUFDLEdBQUcsT0FBTyxDQUFDLDZCQUE2QixDQUFDLENBQUM7QUFFekQsd0ZBQXdGO0FBQ3hGLE1BQU0seUJBQXlCLEdBQUcsTUFBTSxDQUFDO0FBRXpDLHlGQUF5RjtBQUN6RixNQUFNLHVCQUF1QixHQUFHLEdBQUcsQ0FBQztBQUVwQzs7Ozs7Ozs7Ozs7Ozs7R0FjRztBQUVIOzs7Ozs7R0FNRztBQUNILFNBQVMsVUFBVSxDQUFDLFFBQVEsRUFBRSxXQUFXO0lBQ3ZDLElBQUksT0FBTyxRQUFRLEtBQUssUUFBUSxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsRUFBRTtRQUNuRCxNQUFNLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLHdCQUF3QixDQUFDLENBQUM7S0FDekQ7SUFFRCxJQUFJLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztJQUN6QixJQUFJLENBQUMsV0FBVyxHQUFHLFdBQVcsQ0FBQztJQUMvQixJQUFJLENBQUMsa0JBQWtCLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsRUFBRSxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUM7SUFDekUsSUFBSSxDQUFDLGVBQWUsR0FBRyxFQUFDLEtBQUssRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBQyxDQUFDO0lBQ3BELElBQUksQ0FBQyxlQUFlLEdBQUcsRUFBQyxLQUFLLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUMsQ0FBQztJQUVwRCxJQUFJLENBQUMsaUJBQWlCLEdBQUcsRUFBRSxDQUFDO0lBRTVCLDBGQUEwRjtJQUMxRixJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxTQUFTLENBQUMsdUJBQXVCLENBQUMsQ0FBQztJQUUvRCxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7QUFDdEIsQ0FBQztBQUVEOzs7Ozs7OztHQVFHO0FBQ0gsVUFBVSxDQUFDLGlCQUFpQixHQUFHLFVBQVMsZUFBZSxFQUFFLGVBQWUsRUFBRSxZQUFZO0lBQ3BGLE9BQU8sZUFBZSxHQUFHLEdBQUcsR0FBRyxlQUFlLEdBQUcsR0FBRyxHQUFHLFlBQVksQ0FBQztBQUN0RSxDQUFDLENBQUM7QUFFRjs7O0dBR0c7QUFDSCxVQUFVLENBQUMsZ0JBQWdCLEdBQUcsVUFBUyxVQUFVO0lBQy9DLElBQUksVUFBVSxLQUFLLFNBQVMsRUFBRTtRQUFFLE9BQU8sU0FBUyxDQUFDO0tBQUU7SUFDbkQsTUFBTSxVQUFVLEdBQUcsTUFBTSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUMvQyxVQUFVLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBRSxNQUFNLENBQUMsQ0FBQztJQUN0QyxPQUFPLFVBQVUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUMvQyxDQUFDLENBQUM7QUFFRixVQUFVLENBQUMsU0FBUyxHQUFHO0lBQ3JCLE1BQU0sRUFBRSxTQUFTO0lBQ2pCLE9BQU8sRUFBRSxTQUFTO0lBRWxCOzs7Ozs7T0FNRztJQUNILFNBQVMsRUFBRSxLQUFLO0lBQ2hCLFdBQVcsRUFBRSxLQUFLO0lBRWxCOzs7O09BSUc7SUFDSCxnQkFBZ0IsRUFBRSxJQUFJO0lBRXRCOzs7O09BSUc7SUFDSCxLQUFLLEVBQUUsU0FBUztJQUNoQixjQUFjLEVBQUUsS0FBSztJQUNyQixtQkFBbUIsRUFBRSxJQUFJO0lBQ3pCLGlCQUFpQixFQUFFLElBQUk7SUFFdkI7Ozs7T0FJRztJQUNILEtBQUssRUFBRSxTQUFTO0lBQ2hCLGNBQWMsRUFBRSxLQUFLO0lBQ3JCLG1CQUFtQixFQUFFLElBQUk7SUFDekIsaUJBQWlCLEVBQUUsSUFBSTtJQUV2Qjs7T0FFRztJQUNILFdBQVcsRUFBRTtRQUNYLE9BQU8sSUFBSSxDQUFDLGNBQWMsSUFBSSxJQUFJLENBQUMsY0FBYyxDQUFDO0lBQ3BELENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsUUFBUSxFQUFFO1FBQ1IsSUFBSSxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ2xCLE9BQU87Z0JBQ0wsSUFBSSxFQUFFLFNBQVM7Z0JBQ2YsTUFBTSxFQUFFLHFEQUFxRDthQUM5RCxDQUFDO1NBQ0g7UUFFRCxhQUFhO1FBQ2IsSUFBSSxJQUFJLENBQUMsbUJBQW1CLEVBQUU7WUFDNUIsT0FBTztnQkFDTCxJQUFJLEVBQUUsWUFBWTtnQkFDbEIsTUFBTSxFQUFFLHlDQUF5QztnQkFDakQsS0FBSyxFQUFFLElBQUksQ0FBQyxpQkFBaUI7YUFDOUIsQ0FBQztTQUNIO1FBQ0QsSUFBSSxJQUFJLENBQUMsbUJBQW1CLEVBQUU7WUFDNUIsT0FBTztnQkFDTCxJQUFJLEVBQUUsWUFBWTtnQkFDbEIsTUFBTSxFQUFFLHVDQUF1QztnQkFDL0MsS0FBSyxFQUFFLElBQUksQ0FBQyxpQkFBaUI7YUFDOUIsQ0FBQztTQUNIO1FBQ0QsSUFBSSxJQUFJLENBQUMsV0FBVyxFQUFFO1lBQ3BCLE9BQU87Z0JBQ0wsSUFBSSxFQUFFLFlBQVk7Z0JBQ2xCLE1BQU0sRUFBRSxzQ0FBc0M7Z0JBQzlDLEtBQUssRUFBRSxJQUFJO2FBQ1osQ0FBQztTQUNIO1FBRUQsVUFBVTtRQUNWLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRTtZQUNoRCxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsSUFBSSxJQUFJLENBQUMsaUJBQWlCLEVBQUU7Z0JBQ2xELE9BQU87b0JBQ0wsSUFBSSxFQUFFLFNBQVM7b0JBQ2YsTUFBTSxFQUFFLDZDQUE2QztvQkFDckQsS0FBSyxFQUFFLElBQUksQ0FBQyxpQkFBaUI7aUJBQzlCLENBQUM7YUFDSDtZQUVELElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxJQUFJLElBQUksQ0FBQyxpQkFBaUIsRUFBRTtnQkFDbEQsT0FBTztvQkFDTCxJQUFJLEVBQUUsU0FBUztvQkFDZixNQUFNLEVBQUUsb0NBQW9DO29CQUM1QyxLQUFLLEVBQUUsSUFBSSxDQUFDLGlCQUFpQjtpQkFDOUIsQ0FBQzthQUNIO1lBRUQsT0FBTztnQkFDTCxJQUFJLEVBQUUsU0FBUztnQkFDZixNQUFNLEVBQUUsZ0NBQWdDO2FBQ3pDLENBQUM7U0FDSDtRQUVELFVBQVU7UUFFVixXQUFXO1FBQ1gsSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFLEVBQUU7WUFDckIsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDO1lBQ2hDLE9BQU87Z0JBQ0wsSUFBSSxFQUFFLFVBQVU7Z0JBQ2hCLE1BQU0sRUFBRSxxQkFBcUIsR0FBRyxDQUFDLENBQUMsT0FBTyxFQUFFO29CQUMzQyxjQUFjLEdBQUcsQ0FBQyxDQUFDLFVBQVUsRUFBRSxHQUFHLGdCQUFnQixHQUFHLENBQUMsQ0FBQyxXQUFXLEVBQUU7YUFDckUsQ0FBQztTQUNIO1FBRUQsV0FBVztRQUNYLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRSxFQUFFO1lBQ3JCLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUM7WUFDN0IsT0FBTztnQkFDTCxJQUFJLEVBQUUsbUJBQW1CO2dCQUN6QixNQUFNLEVBQUUsQ0FBQyxDQUFDLE1BQU07YUFDakIsQ0FBQztTQUNIO1FBRUQsNkRBQTZEO1FBQzdELElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRSxFQUFFO1lBQ3JCLE9BQU87Z0JBQ0wsSUFBSSxFQUFFLFlBQVk7Z0JBQ2xCLE1BQU0sRUFBRSxzRUFBc0U7YUFDL0UsQ0FBQztTQUNIO1FBRUQsZ0VBQWdFO1FBQ2hFLElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRSxFQUFFO1lBQ3pCLE9BQU87Z0JBQ0wsSUFBSSxFQUFFLGdCQUFnQjtnQkFDdEIsTUFBTSxFQUFFLG9EQUFvRDtnQkFDNUQsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsZUFBZTthQUNsQyxDQUFDO1NBQ0g7UUFFRCxlQUFlO1FBQ2YsaUNBQWlDO1FBQ2pDLGlEQUFpRDtRQUNqRCxLQUFLO1FBQ0wsOERBQThEO1FBQzlELElBQUksSUFBSSxDQUFDLFdBQVcsRUFBRSxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFLEVBQUU7WUFDbEQsT0FBTztnQkFDTCxJQUFJLEVBQUUsYUFBYTtnQkFDbkIsTUFBTSxFQUFFLHdDQUF3QztnQkFDaEQsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsZUFBZTthQUNsQyxDQUFDO1NBQ0g7UUFFRCxXQUFXO1FBQ1gsT0FBTyxFQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLDJCQUEyQixFQUFDLENBQUM7SUFDOUQsQ0FBQztJQUVELGVBQWUsRUFBRSxTQUFTO0lBQzFCLGNBQWMsRUFBRSxTQUFTO0lBRXpCOztPQUVHO0lBQ0gsVUFBVSxFQUFFO1FBQ1YsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDO0lBQ2pDLENBQUM7SUFFRDs7T0FFRztJQUNILFVBQVUsRUFBRTtRQUNWLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUM7SUFDOUIsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsWUFBWSxFQUFFLEtBQUssV0FBVSxLQUFLLEVBQUUsZ0JBQWdCO1FBQ2xELDZEQUE2RDtRQUM3RCxNQUFNLElBQUksQ0FBQyxXQUFXLENBQUMsVUFBVSxFQUFFLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztRQUU5QyxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxFQUFFLGdCQUFnQixDQUFDLENBQUM7SUFDckQsQ0FBQztJQUVELGFBQWEsRUFBRSxLQUFLLFdBQVUsS0FBSyxFQUFFLGdCQUFnQjtRQUNuRCxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksYUFBYSxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsRUFBRSxJQUFJLENBQUMsS0FBSyxFQUFFLGdCQUFnQixDQUFDLENBQUM7UUFDMUYsTUFBTSxjQUFjLEdBQUcsTUFBTSxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBRXpELElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLEVBQUU7WUFDaEMsbUZBQW1GO1lBQ25GLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO1lBQzFCLE9BQU87U0FDUjtRQUVELE1BQU0sa0JBQWtCLENBQUMsWUFBWSxDQUNuQyxJQUFJLENBQUMsWUFBWSxFQUFFLEVBQUUsVUFBVSxDQUFDLElBQUksRUFBRSxjQUFjLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxDQUM5RSxDQUFDO1FBRUYsTUFBTSxrQkFBa0IsQ0FBQyxZQUFZLENBQ25DLElBQUksQ0FBQyxZQUFZLEVBQUUsRUFBRSxVQUFVLENBQUMsSUFBSSxFQUFFLGNBQWMsQ0FBQyxpQkFBaUIsRUFBRSxLQUFLLENBQzlFLENBQUM7UUFFRiwwQkFBMEI7UUFDMUIsSUFBSSxDQUFDLEtBQUssQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO1FBQ2hDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxHQUFHLElBQUksSUFBSSxFQUFFLENBQUM7UUFDcEMsTUFBTSxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO1FBQ3hCLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO0lBQzVCLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILGlCQUFpQixFQUFFLEtBQUssV0FBVSxLQUFLO1FBQ3JDLDZEQUE2RDtRQUM3RCxNQUFNLElBQUksQ0FBQyxXQUFXLENBQUMsVUFBVSxFQUFFLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztRQUU5QywwRkFBMEY7UUFDMUYsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxFQUFDLENBQUMsRUFBQyxFQUFFO1lBQ3ZDLElBQUksQ0FBQyxLQUFLLENBQUMsYUFBYSxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUM7WUFDckMsTUFBTSxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ3hCLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO1FBQzVCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUNYLEdBQUcsQ0FBQyxLQUFLLENBQUMsb0RBQW9ELEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQzdFLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVELFlBQVksRUFBRSxLQUFLO1FBQ2pCLCtEQUErRDtRQUMvRCxNQUFNLElBQUksQ0FBQyxXQUFXLENBQUMsdUJBQXVCLEVBQUUsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUM7UUFFdkUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUM1QixDQUFDO0lBRUQ7Ozs7Ozs7OztPQVNHO0lBQ0gsWUFBWSxFQUFFLFVBQVMsYUFBYTtRQUNsQyxJQUFJLElBQUksQ0FBQyxjQUFjLEtBQUssU0FBUyxFQUFFO1lBQ3JDLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxFQUFFO2dCQUMvQyxLQUFLLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsZUFBZSxFQUFFLGlCQUFpQixDQUFDLENBQUM7Z0JBQ3JFLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUM7YUFDbkQ7aUJBQU07Z0JBQ0wsSUFBSSxDQUFDLGNBQWMsR0FBRyxVQUFVLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDO2FBQ3RGO1NBQ0Y7UUFDRCxPQUFPLElBQUksQ0FBQyxjQUFjLENBQUM7SUFDN0IsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsYUFBYSxFQUFFLFVBQVMsYUFBYTtRQUNuQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNqQixJQUFJLGFBQWEsRUFBRTtnQkFBRSxPQUFPLFNBQVMsQ0FBQzthQUFFO1lBQ3hDLE1BQU0sTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsdURBQXVELENBQUMsQ0FBQztTQUN4RjtRQUNELElBQUksSUFBSSxDQUFDLGVBQWUsS0FBSyxTQUFTLEVBQUU7WUFDdEMsTUFBTSxFQUFFLEdBQUcsS0FBSyxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUMxRCxJQUFJLENBQUMsRUFBRSxFQUFFO2dCQUNQLE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsRUFDdkMsK0NBQStDLEdBQUcsSUFBSSxDQUFDLGFBQWEsRUFBRSxHQUFHLEdBQUcsQ0FDN0UsQ0FBQzthQUNIO1lBQ0QsSUFBSSxDQUFDLGVBQWUsR0FBRyxVQUFVLENBQUMsaUJBQWlCLENBQUMsRUFBRSxDQUFDLElBQUksRUFBRSxFQUFFLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztTQUNyRjtRQUNELE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQztJQUM5QixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILGFBQWEsRUFBRTtRQUNiLE9BQU8sY0FBYyxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJO1lBQ3ZDLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7WUFDaEMsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FDeEIsQ0FBQztJQUNKLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsY0FBYyxFQUFFO1FBQ2QsSUFBSSxJQUFJLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFO1lBQ2pDLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUM7U0FDeEI7YUFBTSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFO1lBQzNCLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7U0FDekI7YUFBTTtZQUNMLE9BQU8sWUFBWSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUM7U0FDckM7SUFDSCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxrQkFBa0IsRUFBRSxVQUFTLE9BQU8sRUFBRSxJQUFJLEVBQUUsT0FBTztRQUNqRCxJQUFJLE9BQU8sRUFBRTtZQUFFLE9BQU87U0FBRTtRQUN4QixHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFFRDs7O09BR0c7SUFDSCxhQUFhLEVBQUU7UUFDYixNQUFNLElBQUksR0FBRyxJQUFJLENBQUM7UUFDbEIsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBRWxDLE1BQU0sT0FBTyxHQUFHLEdBQUcsRUFBRTtZQUNuQixJQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDO1lBQzlCLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUU7Z0JBQ3pDLElBQUksQ0FBQyxZQUFZLEdBQUcsT0FBTyxDQUFDO2dCQUU1Qiw0RUFBNEU7Z0JBQzVFLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFO29CQUFFLE9BQU87aUJBQUU7Z0JBQzlCLE9BQU8sSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRTtvQkFDdEMsSUFBSSxJQUFJLENBQUMsT0FBTyxLQUFLLE9BQU8sRUFBRTt3QkFDNUIsMERBQTBEO3dCQUMxRCxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7d0JBQ3BCLE1BQU0sT0FBTyxHQUFHLHFFQUFxRSxDQUFDO3dCQUN0RixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsVUFBVSxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQztxQkFDbkQ7Z0JBQ0gsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNYLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDO2dCQUMzQixJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxFQUFFLElBQUksRUFBRSwrQkFBK0IsR0FBRyxJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUM7WUFDcEYsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUNYLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUM7Z0JBQ2pFLE9BQU8sT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMzQixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQztRQUVGLE1BQU0sVUFBVSxHQUFHLGdDQUFnQyxHQUFHLElBQUksR0FBRyxHQUFHLENBQUM7UUFDakUsTUFBTSxVQUFVLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyw0QkFBNEIsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUMvRCxNQUFNLE1BQU0sR0FBRyxLQUFLLENBQUMsRUFBRSxDQUFDO1FBQ3RCLG9EQUFvRDtRQUNwRCxLQUFLLENBQUMsR0FBRyxLQUFLLG1CQUFtQjtZQUVqQyw2REFBNkQ7WUFDN0QsS0FBSyxDQUFDLEdBQUcsS0FBSyxlQUFlO1lBRTdCLHlFQUF5RTtZQUN6RSxLQUFLLENBQUMsR0FBRyxLQUFLLHNCQUFzQjtZQUVwQyx5Q0FBeUM7WUFDekMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsdUJBQXVCLENBQUM7WUFFL0MsbUNBQW1DO1lBQ25DLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLHNCQUFzQixDQUFDLENBQy9DLENBQUM7UUFFRixJQUFJLElBQUksQ0FBQyxtQkFBbUIsRUFBRTtZQUM1QixJQUFJLENBQUMsbUJBQW1CLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDbEMsSUFBSSxDQUFDLG1CQUFtQixHQUFHLElBQUksQ0FBQztTQUNqQztRQUNELE9BQU8sSUFBSSxDQUFDLG1CQUFtQixHQUFHLEtBQUssQ0FBQyxZQUFZLENBQ2xELFVBQVUsRUFDVixPQUFPLEVBQ1AsRUFBQyxLQUFLLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBQyxDQUNuRCxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUU7WUFDYixJQUFJLENBQUMsbUJBQW1CLEdBQUcsSUFBSSxDQUFDO1FBQ2xDLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7T0FHRztJQUNILGFBQWEsRUFBRTtRQUNiLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQztRQUNsQixNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFFbEMsTUFBTSxPQUFPLEdBQUcsR0FBRyxFQUFFO1lBQ25CLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUM7WUFDOUIsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRTtnQkFDekMsSUFBSSxDQUFDLFlBQVksR0FBRyxPQUFPLENBQUM7Z0JBQzVCLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDO2dCQUMzQixJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxFQUFFLElBQUksRUFBRSw2QkFBNkIsR0FBRyxJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUM7Z0JBQ2hGLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQzNCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDWCxJQUFJLENBQUMsaUJBQWlCLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDO2dCQUNqRSxPQUFPLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDM0IsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUM7UUFFRixNQUFNLFVBQVUsR0FBRyw4QkFBOEIsR0FBRyxJQUFJLEdBQUcsR0FBRyxDQUFDO1FBQy9ELE1BQU0sT0FBTyxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsNEJBQTRCLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFFNUQsSUFBSSxJQUFJLENBQUMsbUJBQW1CLEVBQUU7WUFDNUIsSUFBSSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ2xDLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxJQUFJLENBQUM7U0FDakM7UUFFRCxPQUFPLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxLQUFLLENBQUMsWUFBWSxDQUFDLFVBQVUsRUFBRSxPQUFPLEVBQUU7WUFDeEUsS0FBSyxFQUFFLElBQUk7WUFDWCxPQUFPLEVBQUUsT0FBTztZQUNoQixNQUFNLEVBQUUsS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUNmLG9EQUFvRDtZQUNwRCxLQUFLLENBQUMsR0FBRyxLQUFLLG1CQUFtQjtnQkFFakMsNkRBQTZEO2dCQUM3RCxLQUFLLENBQUMsR0FBRyxLQUFLLGVBQWU7Z0JBRTdCLHlFQUF5RTtnQkFDekUsS0FBSyxDQUFDLEdBQUcsS0FBSyxzQkFBc0IsQ0FDckM7U0FDRixDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRTtZQUNkLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxJQUFJLENBQUM7UUFDbEMsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxVQUFVLEVBQUU7UUFDVixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFLENBQUM7SUFDakMsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILHNCQUFzQixFQUFFLFVBQVMsY0FBYztRQUM3QyxJQUFJLENBQUMsY0FBYyxFQUFFO1lBQUUsT0FBTztTQUFFO1FBRWhDLHlDQUF5QztRQUN6QyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ3ZDLE1BQU0sZUFBZSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLGlCQUFpQixDQUFDO1lBQzlELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsRUFBRTtnQkFDbEMsdUNBQXVDO2dCQUN2QyxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQ25CLG1CQUFtQixFQUNuQix5REFBeUQsSUFBSSxDQUFDLFFBQVEsR0FBRyxDQUMxRSxDQUFDO2FBQ0g7aUJBQU0sSUFBSSxlQUFlLEtBQUssY0FBYyxDQUFDLElBQUksRUFBRTtnQkFDbEQsNEJBQTRCO2dCQUM1QixNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQ25CLG1CQUFtQixFQUNuQix3QkFBd0IsY0FBYyxDQUFDLElBQUksZ0JBQWdCLGVBQWUsSUFBSSxDQUMvRSxDQUFDO2FBQ0g7U0FDRjthQUFNO1lBQ0wsb0RBQW9EO1lBQ3BELGtFQUFrRTtZQUNsRSxjQUFjLENBQUMsSUFBSSxHQUFHLFNBQVMsQ0FBQztTQUNqQztRQUVELHlDQUF5QztRQUN6QyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ3ZDLE1BQU0sZUFBZSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLGlCQUFpQixDQUFDO1lBQzlELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsRUFBRTtnQkFDbEMsdUNBQXVDO2dCQUN2QyxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQ25CLG1CQUFtQixFQUNuQix5REFBeUQsSUFBSSxDQUFDLFFBQVEsR0FBRyxDQUMxRSxDQUFDO2FBQ0g7aUJBQU0sSUFBSSxlQUFlLEtBQUssY0FBYyxDQUFDLElBQUksRUFBRTtnQkFDbEQsNEJBQTRCO2dCQUM1QixNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQ25CLG1CQUFtQixFQUNuQix3QkFBd0IsY0FBYyxDQUFDLElBQUksZ0JBQWdCLGVBQWUsSUFBSSxDQUMvRSxDQUFDO2FBQ0g7U0FDRjthQUFNO1lBQ0wsb0RBQW9EO1lBQ3BELGtFQUFrRTtZQUNsRSxjQUFjLENBQUMsSUFBSSxHQUFHLFNBQVMsQ0FBQztTQUNqQztJQUNILENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7OztPQWdCRztJQUNILHlCQUF5QixFQUFFLFVBQVMsV0FBVztRQUM3QyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLEVBQUU7WUFDL0QsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1NBQ3JDO1FBRUQsTUFBTSxFQUFDLGFBQWEsRUFBRSxlQUFlLEVBQUUsT0FBTyxFQUFDLEdBQUcsV0FBVyxDQUFDLGFBQWEsQ0FBQztRQUU1RSxPQUFPLE9BQU8sQ0FBQyxLQUFLLENBQUM7WUFDbkIsSUFBSSxFQUFFLGtCQUFrQixDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsR0FBRyxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUM7WUFDcEUsSUFBSSxFQUFFLGtCQUFrQixDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsR0FBRyxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUM7U0FDckUsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUNmLDRCQUE0QjtZQUM1Qiw4QkFBOEI7WUFDOUIsT0FBTyxXQUFXLENBQUMsYUFBYSxDQUFDLE1BQU0sRUFBRSxhQUFhLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3pFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsRUFBRTtZQUN2QiwyRUFBMkU7WUFDM0UscUVBQXFFO1lBQ3JFLFdBQVcsQ0FBQyxlQUFlLEdBQUcsZUFBZSxDQUFDO1lBQzlDLFdBQVcsQ0FBQyxhQUFhLEdBQUcsY0FBYyxDQUFDO1lBQzNDLE9BQU8sV0FBVyxDQUFDLElBQUksRUFBRSxDQUFDO1FBQzVCLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsV0FBVyxFQUFFO1FBQ1gsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ2xCLE9BQU8sSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUN0QyxJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztZQUV2QiwyQ0FBMkM7WUFDM0MsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBRXRDLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ25ELENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCxNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7WUFFdEMsNENBQTRDO1lBQzVDLEtBQUssTUFBTSxNQUFNLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEVBQUU7Z0JBQzdDLElBQUksTUFBTSxDQUFDLFFBQVEsS0FBSyxJQUFJLENBQUMsUUFBUSxFQUFFO29CQUFFLFNBQVM7aUJBQUU7Z0JBQ3BELElBQUksTUFBTSxDQUFDLFdBQVcsRUFBRSxJQUFJLE1BQU0sQ0FBQyxZQUFZLEVBQUUsS0FBSyxTQUFTLEVBQUU7b0JBQy9ELDhDQUE4QztvQkFDOUMsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO29CQUNwQixNQUFNLE9BQU8sR0FBRyw4Q0FBOEMsQ0FBQztvQkFDL0QsSUFBSSxDQUFDLGlCQUFpQixHQUFHLE9BQU8sQ0FBQztvQkFDakMsT0FBTyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUMsT0FBTyxFQUFFLE9BQU8sRUFBQyxDQUFDLENBQUM7aUJBQzNDO2FBQ0Y7WUFFRCxNQUFNLGNBQWMsR0FBRztnQkFDckIsS0FBSyxFQUFFLEVBQUMsR0FBRyxFQUFFLFNBQVMsRUFBQztnQkFDdkIsUUFBUSxFQUFFO29CQUNSLFdBQVcsRUFBRSxJQUFJO29CQUNqQixXQUFXLEVBQUUsSUFBSTtvQkFDakIsSUFBSSxFQUFFLElBQUksQ0FBQyxhQUFhLEVBQUU7b0JBQzFCLFFBQVEsRUFBRSxJQUFJLElBQUksRUFBRTtvQkFDcEIsSUFBSSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSTtvQkFDdEIsV0FBVyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU07b0JBQ3ZDLFdBQVcsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNO29CQUNyQyxXQUFXLEVBQUUsS0FBSztvQkFDbEIsZUFBZSxFQUFFLFdBQVcsQ0FBQyxnQkFBZ0I7b0JBQzdDLGFBQWEsRUFBRSxXQUFXLENBQUMsY0FBYztpQkFDMUM7YUFDRixDQUFDO1lBQ0YsMEVBQTBFO1lBQzFFLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDLGNBQWMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsRUFBRTtnQkFDcEYsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7Z0JBRW5CLDBCQUEwQjtnQkFDMUIsSUFBSSxDQUFDLEtBQUssRUFBRTtvQkFDVixNQUFNLE1BQU0sR0FBRyxFQUFFLENBQUM7b0JBRWxCLDRCQUE0QjtvQkFDNUIsTUFBTSxDQUFDLFFBQVEsR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDO29CQUU3Qiw4QkFBOEI7b0JBQzlCLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUU7d0JBQUUsTUFBTSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztxQkFBRTtvQkFFekQsc0RBQXNEO29CQUN0RCxNQUFNLGtCQUFrQixHQUFHLEtBQUssQ0FBQyxXQUFXLElBQUksZUFBZSxDQUFDO29CQUNoRSxJQUFJLGtCQUFrQixLQUFLLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRTt3QkFDbkQsTUFBTSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7d0JBQzFCLE1BQU0sQ0FBQyxlQUFlLEdBQUcsZ0RBQWdELENBQUM7cUJBQzNFO29CQUVELG1CQUFtQjtvQkFDbkIsTUFBTSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUM7b0JBQzlDLE1BQU0sQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDO29CQUVoRCxPQUFPLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsQ0FBQztpQkFDdkM7WUFDSCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxFQUFFO1lBQy9CLDRDQUE0QztZQUM1QyxJQUFJLENBQUMsaUJBQWlCLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQztZQUN2QyxPQUFPLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDL0IsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxhQUFhLEVBQUUsVUFBUyxPQUFPO1FBQzdCLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztRQUM3QixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsTUFBTSxFQUFFLENBQUM7SUFDcEMsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxVQUFVLEVBQUU7UUFDVixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO0lBQzVCLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsV0FBVyxFQUFFO1FBQ1gsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQztJQUNoQyxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILGNBQWMsRUFBRTtRQUNkLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQztJQUNqQyxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILFVBQVUsRUFBRTtRQUNWLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFO1lBQUUsT0FBTyxLQUFLLENBQUM7U0FBRTtRQUNuRCxPQUFPLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQztZQUNwRCxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMscUJBQXFCLENBQUMsQ0FBQztJQUNwRCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILHVCQUF1QixFQUFFO1FBQ3ZCLHFCQUFxQjtRQUNyQixJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFO1lBQ25ELElBQUksQ0FBQyxLQUFLLENBQUMscUJBQXFCLEdBQUcsRUFBRSxDQUFDO1NBQ3ZDO1FBRUQsMkVBQTJFO1FBQzNFLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLEVBQUU7WUFDMUIsMkVBQTJFO1lBQzNFLG9GQUFvRjtZQUNwRixJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7U0FDL0I7UUFFRCxJQUFJLENBQUMsS0FBSyxDQUFDLGVBQWUsR0FBRyxtREFBbUQsQ0FBQztRQUVqRixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7SUFDM0IsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gscUJBQXFCLEVBQUU7UUFDckIsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQztRQUNwQyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUM7UUFDL0IsSUFBSSxDQUFDLEtBQUssQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDO1FBQ2xDLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUMzQixDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsbUJBQW1CLEVBQUUsVUFBUyxLQUFLO1FBQ2pDLElBQUksS0FBSyxLQUFLLFNBQVMsSUFBSSxJQUFJLEVBQUU7WUFDL0IsS0FBSyxHQUFHLGVBQWUsQ0FBQztTQUN6QjthQUFNLElBQUksT0FBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLFFBQVEsRUFBRTtZQUNyQyxJQUFJLEtBQUssQ0FBQyxPQUFPLEVBQUU7Z0JBQ2pCLEtBQUssR0FBRyxLQUFLLENBQUMsT0FBTyxDQUFDO2FBQ3ZCO2lCQUFNLElBQUksT0FBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLFFBQVEsRUFBRTtnQkFDckMsS0FBSyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDL0I7aUJBQU07Z0JBQ0wsS0FBSyxHQUFHLEtBQUssR0FBRyxFQUFFLENBQUM7YUFDcEI7U0FDRjtRQUVELElBQUksQ0FBQyxLQUFLLENBQUMsZUFBZSxHQUFHLEtBQUs7WUFDaEMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQztZQUM5QyxDQUFDLENBQUMsa0NBQWtDLENBQUM7UUFDdkMsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO0lBQzNCLENBQUM7SUFFRDs7T0FFRztJQUNILHdCQUF3QixFQUFFO1FBQ3hCLElBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMscUJBQXFCLENBQUM7UUFDL0MsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQUUsT0FBTyxHQUFHLEVBQUUsQ0FBQztTQUFFO1FBRTdDLE9BQU8sQ0FBQyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsd0JBQXdCLEVBQUUsVUFBUyxPQUFPO1FBQ3hDLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQztRQUNsQixJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRTtZQUFFLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO1NBQUU7UUFDL0QsT0FBTyxJQUFJLENBQUMsaUJBQWlCLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDdkQsSUFBSSxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsR0FBRyxPQUFPLENBQUM7WUFDM0MsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO1FBQzNCLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0gsd0JBQXdCLEVBQUU7UUFDeEIsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQztRQUMvQyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFBRSxPQUFPLEdBQUcsRUFBRSxDQUFDO1NBQUU7UUFFN0MsT0FBTyxDQUFDLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFFRDs7O09BR0c7SUFDSCx3QkFBd0IsRUFBRSxVQUFTLE9BQU87UUFDeEMsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ2xCLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFO1lBQUUsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7U0FBRTtRQUMvRCxPQUFPLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUN2RCxJQUFJLENBQUMsS0FBSyxDQUFDLHFCQUFxQixHQUFHLE9BQU8sQ0FBQztZQUMzQyxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDM0IsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSCxXQUFXLEVBQUUsVUFBUyxVQUFVLEVBQUUsV0FBVyxFQUFFLFFBQVE7UUFDckQsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDLElBQUksQ0FBQztRQUNuQyxJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUM7UUFDakIsSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDO1FBRWQsSUFBSSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxFQUFFO1lBQ25DLE9BQU8sR0FBRyxHQUFHLEdBQUcsVUFBVSxHQUFHLDJEQUEyRDtnQkFDdEYsV0FBVyxHQUFHLG1CQUFtQixHQUFHLEtBQUssR0FBRyxHQUFHLENBQUM7WUFDbEQsRUFBRSxHQUFHLEtBQUssQ0FBQztTQUNaO1FBRUQsSUFBSSxDQUFDLEVBQUUsRUFBRTtZQUNQLElBQUksUUFBUSxFQUFFO2dCQUNaLEdBQUcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7YUFDbkI7aUJBQU07Z0JBQ0wsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLHNCQUFzQixFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQzthQUMvRDtTQUNGO1FBQ0QsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQzdCLENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILGlCQUFpQixFQUFFLFVBQVMsSUFBSSxFQUFFLFVBQVU7UUFDMUMsd0RBQXdEO1FBQ3hELE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQztRQUVsQixNQUFNLFdBQVcsR0FBRyxDQUFDLE9BQU8sRUFBRSxZQUFZLEVBQUUsZ0JBQWdCLEVBQUUsYUFBYSxDQUFDLENBQUM7UUFDN0UsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLDRCQUE0QixFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFFM0UsSUFBSSxVQUFVLEtBQUssSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsRUFBRTtnQkFDckQsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUNwQixtQkFBbUIsRUFDbkIsY0FBYyxHQUFHLElBQUksR0FBRyw4QkFBOEIsRUFDdEQsSUFBSSxDQUNMLENBQUM7YUFDSDtZQUVELHVDQUF1QztZQUN2QyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzVCLE1BQU0sZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLFlBQVksR0FBRyxDQUFDLEdBQUcsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDckUsTUFBTSxhQUFhLEdBQUcsVUFBVSxJQUFJLElBQUksQ0FBQyxZQUFZLEdBQUcsQ0FBQyxHQUFHLFlBQVksQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBRWpGLGdDQUFnQztZQUNoQyxNQUFNLFdBQVcsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUN6QixDQUFDLENBQUMsVUFBVSxDQUFDLGdCQUFnQixFQUFFLGFBQWEsQ0FBQyxFQUFFLFFBQVE7WUFDdkQsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQyxVQUFVO2FBQ3pELENBQUM7WUFFRiwwREFBMEQ7WUFDMUQsSUFBSSxXQUFXLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtnQkFDMUIsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDO2FBQy9CO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsb0JBQW9CLEVBQUUsVUFBUyxXQUFXLEVBQUUsYUFBYTtRQUN2RCxXQUFXLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUV2QyxJQUFJLENBQUMsV0FBVyxFQUFFO1lBQUUsT0FBTyxXQUFXLENBQUM7U0FBRTtRQUV6QyxNQUFNLE1BQU0sR0FBRyxhQUFhLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyx3QkFBd0IsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7UUFDcEUsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxFQUFFO1lBQzlCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxXQUFXLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO2dCQUMzQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQzthQUMzRDtTQUNGO2FBQU07WUFDTCxXQUFXLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQztTQUNyRDtRQUNELE9BQU8sV0FBVyxDQUFDO0lBQ3JCLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxvQkFBb0IsRUFBRSxVQUFTLFdBQVcsRUFBRSxhQUFhO1FBQ3ZELFdBQVcsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBRXZDLElBQUksQ0FBQyxXQUFXLEVBQUU7WUFBRSxPQUFPLFdBQVcsQ0FBQztTQUFFO1FBRXpDLE1BQU0sTUFBTSxHQUFHLGFBQWEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLHdCQUF3QixFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUNwRSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDOUIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7Z0JBQzNDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDO2FBQzNEO1NBQ0Y7YUFBTTtZQUNMLFdBQVcsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1NBQ3JEO1FBQ0QsT0FBTyxXQUFXLENBQUM7SUFDckIsQ0FBQztJQUVEOztPQUVHO0lBQ0gsYUFBYSxFQUFFO1FBQ2IsSUFBSSxJQUFJLENBQUMsS0FBSyxFQUFFO1lBQUUsT0FBTztTQUFFO1FBQzNCLElBQUk7WUFDRixJQUFJLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQyxzQkFBc0IsQ0FDMUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUMxQixJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FDcEIsQ0FBQztTQUNIO1FBQUMsT0FBTSxDQUFDLEVBQUU7WUFDVCxJQUFJLENBQUMsWUFBWSxNQUFNLENBQUMsT0FBTyxFQUFFO2dCQUMvQixHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDckIsSUFBSSxDQUFDLGlCQUFpQixHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUM7YUFDcEM7WUFDRCxNQUFNLENBQUMsQ0FBQztTQUNUO0lBQ0gsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxhQUFhLEVBQUU7UUFDYixJQUFJLElBQUksQ0FBQyxLQUFLLEVBQUU7WUFBRSxPQUFPO1NBQUU7UUFDM0IsSUFBSTtZQUNGLElBQUksQ0FBQyxLQUFLLEdBQUcsUUFBUSxDQUFDLHNCQUFzQixDQUMxQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQ3hCLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUNqQixJQUFJLENBQUMsS0FBSyxDQUNYLENBQUM7U0FDSDtRQUFDLE9BQU0sQ0FBQyxFQUFFO1lBQ1QsSUFBSSxDQUFDLFlBQVksTUFBTSxDQUFDLE9BQU8sRUFBRTtnQkFDL0IsSUFBSSxDQUFDLGlCQUFpQixHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUM7YUFDcEM7WUFDRCxNQUFNLENBQUMsQ0FBQztTQUNUO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0gsV0FBVyxFQUFFO1FBQ1gsSUFBSSxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsSUFBSSxLQUFLLE9BQU8sRUFBRTtZQUNwQyxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQ25CLHdCQUF3QixFQUN4QixlQUFlLEdBQUcsSUFBSSxDQUFDLFFBQVEsR0FBRyxnQkFBZ0IsQ0FDbkQsQ0FBQztTQUNIO0lBQ0gsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsY0FBYyxFQUFFO1FBQ2QsTUFBTSxRQUFRLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsT0FBTyxFQUFFLFNBQVMsQ0FBQyxDQUFDLENBQUM7UUFDM0QsTUFBTSxPQUFPLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQzNELE1BQU0sSUFBSSxHQUFHLEtBQUssQ0FBQyxVQUFVLENBQUMsUUFBUSxFQUFFLE9BQU8sRUFBRSxFQUFDLHNCQUFzQixFQUFFLElBQUksRUFBQyxDQUFDLENBQUM7UUFDakYsSUFBSSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtZQUNuQixHQUFHLENBQUMsSUFBSSxDQUFDLGdDQUFnQyxHQUFHLElBQUksQ0FBQyxRQUFRLEdBQUcsZUFBZSxDQUFDLENBQUM7U0FDOUU7UUFDRCxPQUFPLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO0lBQ3pCLENBQUM7SUFFRCxVQUFVLEVBQUU7UUFDVixPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQztJQUNoQyxDQUFDO0lBRUQ7Ozs7Ozs7OztPQVNHO0lBQ0gsWUFBWSxFQUFFLFVBQVMsWUFBWTtRQUNqQyxJQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUV6RCxJQUFJLENBQUMsZUFBZSxHQUFHLFNBQVMsQ0FBQztRQUNqQyxJQUFJLENBQUMsY0FBYyxHQUFHLFNBQVMsQ0FBQztRQUVoQyxJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztRQUV2QixlQUFlO1FBQ2YsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1FBQ3BDLElBQUksSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLEVBQUU7WUFDOUIsWUFBWSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDMUM7UUFDRCxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7UUFDcEMsSUFBSSxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssRUFBRTtZQUM5QixZQUFZLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUMxQztRQUVELGdDQUFnQztRQUNoQyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFFbEIseUJBQXlCO1FBQ3pCLElBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO1FBQzVCLElBQUksSUFBSSxDQUFDLG1CQUFtQixFQUFFO1lBQzVCLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUNsQyxJQUFJLENBQUMsbUJBQW1CLEdBQUcsSUFBSSxDQUFDO1NBQ2pDO1FBQ0QsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQztRQUU5QixJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQztRQUM1QixJQUFJLElBQUksQ0FBQyxtQkFBbUIsRUFBRTtZQUM1QixJQUFJLENBQUMsbUJBQW1CLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDbEMsSUFBSSxDQUFDLG1CQUFtQixHQUFHLElBQUksQ0FBQztTQUNqQztRQUNELElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUM7UUFFOUIsY0FBYztRQUNkLElBQUksQ0FBQyxLQUFLLEdBQUcsU0FBUyxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxLQUFLLEdBQUcsU0FBUyxDQUFDO1FBRXZCLHVCQUF1QjtRQUN2QixJQUFJLENBQUMsWUFBWSxHQUFHLFNBQVMsQ0FBQztRQUM5QixJQUFJLENBQUMsWUFBWSxHQUFHLFNBQVMsQ0FBQztRQUM5QixJQUFJLENBQUMsT0FBTyxHQUFHLFNBQVMsQ0FBQztRQUN6QixJQUFJLENBQUMsS0FBSyxHQUFHLFNBQVMsQ0FBQztRQUN2QixJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDO1FBQzdCLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO1FBRTFCLElBQUksWUFBWSxFQUFFO1lBQ2hCLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO1NBRXZCO2FBQU0sSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDdkIsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7WUFDdEIsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUNuQixtQkFBbUIsRUFDbkIsZUFBZSxHQUFHLElBQUksQ0FBQyxRQUFRLEdBQUcsbURBQW1ELENBQ3RGLENBQUM7U0FFSDtJQUNILENBQUM7SUFFRDs7T0FFRztJQUNILE9BQU8sRUFBRTtRQUNQLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDMUIsQ0FBQztJQUVEOzs7T0FHRztJQUNILFVBQVU7UUFDUixJQUFJLElBQUksQ0FBQyxLQUFLLEVBQUU7WUFDZCxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRSxDQUFDO1NBQ3pCO1FBQ0QsSUFBSSxJQUFJLENBQUMsS0FBSyxFQUFFO1lBQ2QsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUUsQ0FBQztTQUN6QjtJQUNILENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILE9BQU8sRUFBRSxVQUFTLFlBQVk7UUFDNUIsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBRWxCLE1BQU0sYUFBYSxHQUFHLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUM1QyxzRUFBc0U7UUFDdEUsTUFBTSxXQUFXLEdBQUcsYUFBYTtZQUMvQixDQUFDLENBQUMsQ0FBQyxTQUFTLEVBQUUsWUFBWSxFQUFFLFlBQVksRUFBRSxnQkFBZ0IsRUFBRSxhQUFhLEVBQUUsT0FBTyxDQUFDO1lBQ25GLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBRWhCLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLEVBQUUsV0FBVyxFQUFFLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRTtZQUNqRSxJQUFJLENBQUMsRUFBRSxFQUFFO2dCQUFFLE9BQU87YUFBRTtZQUVwQixJQUFJLGFBQWEsRUFBRTtnQkFDakIsMkNBQTJDO2dCQUMzQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7YUFDckI7WUFFRCxPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNqQyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQ3JCLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDO1lBQzFCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ1gsT0FBTyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDOUIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDWDs7OzttQkFJRztnQkFDSCxPQUFPLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUM1QixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNYLG9FQUFvRTtnQkFDcEUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxHQUFHLGFBQWEsR0FBRyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7Z0JBQ2xFLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztnQkFFckIsT0FBTyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDOUIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDWCxzRUFBc0U7Z0JBQ3RFLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUNwQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNYLE9BQU8sSUFBSSxDQUFDLHlCQUF5QixDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNwRCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNYLGdDQUFnQztnQkFDaEMsR0FBRyxDQUFDLElBQUksQ0FBQyxzRUFBc0UsRUFDN0UsSUFBSSxDQUFDLFFBQVEsRUFDYixJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLFlBQVksRUFDN0MsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxZQUFZLENBQzVDLENBQUM7WUFDSixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQ2YsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7Z0JBQ3RDLE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO2dCQUV4QywyQkFBMkI7Z0JBQzNCLE1BQU0sUUFBUSxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQztvQkFDL0MsQ0FBQyxDQUFDLE9BQU8sV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLE1BQU0sV0FBVyxDQUFDLElBQUksSUFBSSxXQUFXLENBQUMsSUFBSSxFQUFFO29CQUNqRixDQUFDLENBQUMsR0FBRyxDQUFDO2dCQUVSLE1BQU0sT0FBTyxHQUFHLEtBQUssWUFBWSxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztnQkFDakUsaURBQWlEO2dCQUNqRCxNQUFNLEtBQUssR0FBRyxLQUFLLFlBQVksT0FBTyxJQUFJLEtBQUssQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO2dCQUN4RixHQUFHLENBQUMsSUFBSSxDQUFDLHlEQUF5RCxFQUNoRSxJQUFJLENBQUMsUUFBUSxFQUNiLFdBQVcsQ0FBQyxNQUFNLEVBQUUsV0FBVyxDQUFDLEdBQUcsRUFDbkMsV0FBVyxDQUFDLE1BQU0sRUFBRSxRQUFRLEVBQzVCLE9BQU8sRUFDUCxLQUFLLENBQ04sQ0FBQztnQkFFRixHQUFHLENBQUMsS0FBSyxDQUFDLGdDQUFnQyxFQUFFLEtBQUssQ0FBQyxDQUFDO2dCQUVuRCxJQUFJLFlBQVksRUFBRTtvQkFBRSxPQUFPO2lCQUFFO2dCQUM3QixPQUFPLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDL0IsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRTtnQkFDZCxJQUFJLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQztZQUMzQixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7O09BYUc7SUFDSCxlQUFlLEVBQUU7UUFDZixNQUFNLGdCQUFnQixHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUM3RCxzRUFBc0U7UUFDdEUsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDLElBQUksQ0FBQztRQUV2QyxVQUFVO1FBQ1YsSUFBSSxTQUFTLEtBQUssVUFBVSxFQUFFO1lBQzVCLE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQztnQkFDckIsUUFBUSxFQUFFLFNBQVM7Z0JBQ25CLG1CQUFtQixFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLEVBQUU7Z0JBQ3ZELGlCQUFpQixFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLEVBQUU7Z0JBQ3BELFlBQVksRUFBRSxJQUFJLENBQUMsY0FBYztnQkFDakMsWUFBWSxFQUFFLElBQUksQ0FBQyxjQUFjO2dCQUNqQyxZQUFZLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLG9CQUFvQixFQUFFO2dCQUMxRCxnQkFBZ0IsRUFBRSxnQkFBZ0I7YUFDbkMsQ0FBQyxDQUFDO1NBQ0o7UUFFRCxTQUFTO1FBQ1QsSUFDRSxTQUFTLEtBQUssWUFBWSxJQUFJLFNBQVMsS0FBSyxnQkFBZ0IsSUFBSSxTQUFTLEtBQUssYUFBYSxFQUMzRjtZQUNBLE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQztnQkFDckIsUUFBUSxFQUFFLFFBQVE7Z0JBQ2xCLG1CQUFtQixFQUFFLElBQUk7Z0JBQ3pCLGlCQUFpQixFQUFFLG1DQUFtQztnQkFDdEQsWUFBWSxFQUFFLElBQUk7Z0JBQ2xCLFlBQVksRUFBRSxJQUFJO2dCQUNsQixZQUFZLEVBQUUsSUFBSTtnQkFDbEIsZ0JBQWdCLEVBQUUsZ0JBQWdCO2FBQ25DLENBQUMsQ0FBQztTQUNKO1FBRUQsT0FBTztRQUNQLElBQUksU0FBUyxLQUFLLE9BQU8sRUFBRTtZQUN6QixPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUM7Z0JBQ3JCLFFBQVEsRUFBRSxNQUFNO2dCQUNoQixtQkFBbUIsRUFBRSxJQUFJO2dCQUN6QixpQkFBaUIsRUFBRSxnQ0FBZ0M7Z0JBQ25ELFlBQVksRUFBRSxJQUFJO2dCQUNsQixZQUFZLEVBQUUsSUFBSTtnQkFDbEIsWUFBWSxFQUFFLElBQUk7Z0JBQ2xCLGdCQUFnQixFQUFFLGdCQUFnQjthQUNuQyxDQUFDLENBQUM7U0FDSjtRQUVELFVBQVU7UUFDVixPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUM7WUFDckIsUUFBUSxFQUFFLFNBQVM7WUFDbkIsbUJBQW1CLEVBQUUsSUFBSTtZQUN6QixpQkFBaUIsRUFBRSw0QkFBNEI7WUFDL0MsWUFBWSxFQUFFLElBQUk7WUFDbEIsWUFBWSxFQUFFLElBQUk7WUFDbEIsWUFBWSxFQUFFLElBQUk7WUFDbEIsZ0JBQWdCLEVBQUUsZ0JBQWdCO1NBQ25DLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNILElBQUksUUFBUTtRQUNWLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRTtZQUFFLE9BQU8sRUFBRSxDQUFDO1NBQUU7UUFFOUMsMkNBQTJDO1FBQzNDLE9BQU87WUFFTCxnRkFBZ0Y7WUFDaEYsY0FBYyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxjQUFjO1lBQ3BELHVCQUF1QixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyx1QkFBdUI7WUFDdEUsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsaUJBQWlCO1lBQ3hELFFBQVEsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxRQUFRO1lBQzFFLHdCQUF3QixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxRQUFRO1lBQ3hELE1BQU0sRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTTtZQUNwQyxRQUFRLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUTtZQUN0QyxhQUFhLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLFFBQVE7WUFDN0MsY0FBYyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxjQUFjO1lBQ3BELGFBQWEsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsYUFBYTtZQUNsRCxlQUFlLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsZUFBZTtZQUNwRCxTQUFTLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsU0FBUztZQUN4QyxpQkFBaUIsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxpQkFBaUI7U0FDekQsQ0FBQztJQUNKLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsVUFBVSxFQUFFO1FBQ1YsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ2xCLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztJQUNwQixDQUFDO0lBRUQ7Ozs7Ozs7OztPQVNHO0lBQ0gsVUFBVSxFQUFFLFVBQVMsY0FBYztRQUNqQyxNQUFNLElBQUksR0FBRyxJQUFJLENBQUM7UUFFbEIsZ0ZBQWdGO1FBQ2hGLElBQUksSUFBSSxDQUFDLG1CQUFtQixFQUFFO1lBQzVCLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO1NBQzFCO1FBRUQsSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRTtZQUNqQyxJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQztZQUM1QixPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQztTQUMxQjtRQUVELG1FQUFtRTtRQUNuRSxJQUFJLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxFQUFFO1lBQ2hDLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUM7U0FDckM7UUFFRCxpQ0FBaUM7UUFDakMsSUFBSSxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssRUFBRTtZQUM5QixZQUFZLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUMxQztRQUVELE1BQU0sVUFBVSxHQUFHLEdBQUcsRUFBRTtZQUN0QixJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssR0FBRyxVQUFVLENBQUMsR0FBRyxFQUFFO2dCQUMzQyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7WUFDcEIsQ0FBQyxFQUFFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO1FBQzlCLENBQUMsQ0FBQztRQUVGLDBEQUEwRDtRQUMxRCxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLGNBQWMsRUFBRTtZQUN4QyxVQUFVLEVBQUUsQ0FBQztZQUNiLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO1NBQzFCO1FBRUQsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ2xDLEdBQUcsQ0FBQyxLQUFLLENBQUMsMEJBQTBCLEdBQUcsSUFBSSxDQUFDLENBQUM7UUFDN0MsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQzVELFVBQVUsRUFBRSxDQUFDO1FBQ2YsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRTtZQUNaLElBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO1lBQzVCLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLHFDQUFxQyxJQUFJLEVBQUUsQ0FBQyxDQUFDO1lBRW5GLE9BQU8sSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ3BDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLEVBQUUsSUFBSSxFQUFFLHlDQUF5QyxJQUFJLEVBQUUsQ0FBQyxDQUFDO2dCQUN0RixVQUFVLEVBQUUsQ0FBQztZQUNmLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUU7Z0JBQ1osb0RBQW9EO1lBQ3RELENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRTtZQUNkLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztRQUN0QyxDQUFDLENBQUMsQ0FBQztRQUVILE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUM7SUFDdEMsQ0FBQztJQUVEOzs7Ozs7Ozs7T0FTRztJQUNILFVBQVUsRUFBRSxVQUFTLGNBQWM7UUFDakMsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBRWxCLGdGQUFnRjtRQUNoRixJQUFJLElBQUksQ0FBQyxtQkFBbUIsRUFBRTtZQUM1QixPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQztTQUMxQjtRQUVELElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUU7WUFDakMsSUFBSSxDQUFDLGNBQWMsR0FBRyxLQUFLLENBQUM7WUFDNUIsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7U0FDMUI7UUFFRCxtRUFBbUU7UUFDbkUsSUFBSSxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sRUFBRTtZQUNoQyxPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDO1NBQ3JDO1FBRUQsaUNBQWlDO1FBQ2pDLElBQUksSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLEVBQUU7WUFDOUIsWUFBWSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDMUM7UUFFRCxNQUFNLFVBQVUsR0FBRyxHQUFHLEVBQUU7WUFDdEIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLEdBQUcsVUFBVSxDQUFDLEdBQUcsRUFBRTtnQkFDM0MsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ3BCLENBQUMsRUFBRSxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQztRQUM5QixDQUFDLENBQUM7UUFFRixvREFBb0Q7UUFDcEQsSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxjQUFjLEVBQUU7WUFDeEMsVUFBVSxFQUFFLENBQUM7WUFDYixPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQztTQUMxQjtRQUVELE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNsQyxHQUFHLENBQUMsS0FBSyxDQUFDLHdCQUF3QixHQUFHLElBQUksQ0FBQyxDQUFDO1FBQzNDLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUM1RCxVQUFVLEVBQUUsQ0FBQztRQUNmLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUU7WUFDWixJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQztZQUM1QixJQUFJLENBQUMsa0JBQWtCLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxtQ0FBbUMsR0FBRyxJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUM7WUFFeEYsT0FBTyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDcEMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUUsdUNBQXVDLEdBQUcsSUFBSSxHQUFHLEdBQUcsQ0FBQyxDQUFDO2dCQUMzRixVQUFVLEVBQUUsQ0FBQztZQUNmLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUU7Z0JBQ1osb0RBQW9EO1lBQ3RELENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRTtZQUNkLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztRQUN0QyxDQUFDLENBQUMsQ0FBQztRQUVILE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUM7SUFDdEMsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxXQUFXLEVBQUU7UUFDWCxPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ2pDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUU7Z0JBQ2pDLE9BQU8sSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO2FBQzVCO2lCQUFNO2dCQUNMLE9BQU8sSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7YUFDcEM7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsZUFBZSxFQUFFLFVBQVMsUUFBUSxFQUFFLE1BQU07UUFDeEMsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLFFBQVEsR0FBRyxHQUFHLEdBQUcsTUFBTSxDQUFDLENBQUM7SUFDNUQsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILGtCQUFrQixFQUFFLFVBQVMsUUFBUSxFQUFFLE1BQU07UUFDM0MsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1FBQzlCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsUUFBUSxHQUFHLEdBQUcsR0FBRyxNQUFNLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFDL0QsT0FBTyxVQUFVLENBQUM7SUFDcEIsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILGlCQUFpQixFQUFFLFVBQVMsYUFBYSxFQUFFLGVBQWU7UUFDeEQsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxFQUFFO1lBQ2pDLG9CQUFvQixDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUUsYUFBYSxDQUFDLENBQUM7WUFDMUQsSUFBSSxDQUFDLEtBQUssQ0FBQyxhQUFhLEdBQUcsYUFBYSxDQUFDO1NBQzFDO1FBQ0QsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxFQUFFO1lBQ25DLG9CQUFvQixDQUFDLGFBQWEsQ0FBQyxVQUFVLEVBQUUsZUFBZSxDQUFDLENBQUM7WUFDaEUsSUFBSSxDQUFDLEtBQUssQ0FBQyxlQUFlLEdBQUcsZUFBZSxDQUFDO1NBQzlDO1FBQ0QsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLE1BQU0sRUFBRSxDQUFDO0lBQ3BDLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILG9CQUFvQixFQUFFO1FBQ3BCLE1BQU0sTUFBTSxHQUFHLENBQUMsZ0JBQWdCLEVBQUUsYUFBYSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQzFELE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLEVBQUUsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNwRCx3Q0FBd0M7WUFDeEMsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksUUFBUSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsYUFBYSxFQUFFLEdBQUcsR0FBRyxDQUFDLENBQUM7WUFFdEUsT0FBTyxJQUFJLENBQUMsdUJBQXVCLEVBQUUsQ0FBQztRQUN4QyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1gsZ0dBQWdHO1lBQ2hHLE1BQU0sU0FBUyxHQUNiLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLG9CQUFvQixFQUFFLEtBQUssQ0FBQztnQkFDakQsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsYUFBYSxLQUFLLEtBQUssQ0FBQztZQUU5QyxPQUFPLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0JBQ3JCLDJCQUEyQjtnQkFDekIsU0FBUyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLFFBQVE7b0JBQ3JDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUM7b0JBQy9CLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLHlCQUF5QixDQUFDO2dCQUU5QywyQkFBMkI7Z0JBQzNCLFNBQVMsRUFBRSxTQUFTO29CQUNsQixDQUFDLENBQUMsQ0FBQztvQkFDSCxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUTt3QkFDNUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQzt3QkFDL0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMseUJBQXlCLENBQUM7YUFDakQsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBQyxPQUFPLEVBQUMsRUFBRTtZQUN0QixJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxTQUFTLEdBQUcsT0FBTyxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUN6RSxJQUFJLENBQUMsY0FBYyxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUM7WUFDeEMsSUFBSSxDQUFDLGNBQWMsR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDO1lBRXhDLEdBQUcsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQztZQUM1QixNQUFNLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxFQUFFLGdCQUFnQixDQUFDLEVBQUU7Z0JBQ2pELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxxQkFBcUIsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1lBQ2hFLENBQUMsQ0FBQyxDQUFDO1lBRUgsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsRUFBRSxDQUFDO1lBRXBDLE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQyxZQUFZLENBQUM7WUFFOUMsTUFBTSxXQUFXLEdBQUc7Z0JBQ2xCLElBQUksRUFBRSxNQUFNLGtCQUFrQixDQUFDLG1CQUFtQixDQUNoRCxJQUFJLENBQUMsWUFBWSxFQUFFLEVBQUUsVUFBVSxDQUFDLElBQUksRUFBRSxNQUFNLENBQzdDO2dCQUNELElBQUksRUFBRSxNQUFNLGtCQUFrQixDQUFDLG1CQUFtQixDQUNoRCxJQUFJLENBQUMsWUFBWSxFQUFFLEVBQUUsVUFBVSxDQUFDLElBQUksRUFBRSxNQUFNLENBQzdDO2FBQ0YsQ0FBQztZQUVGLEdBQUcsQ0FBQyxJQUFJLENBQUMscUJBQXFCLElBQUksQ0FBQyxhQUFhLEVBQUUsK0JBQStCLENBQUMsQ0FBQztZQUNuRixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxXQUFXLENBQUMsQ0FBQztRQUNwRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1gsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsRUFBRSxDQUFDO1FBQzlCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCxnSEFBZ0g7WUFDaEgsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFDeEMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNYLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1FBQ3hDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCxtQ0FBbUM7WUFDbkMsT0FBTyxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQztRQUN0QyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDZiwrQkFBK0I7WUFDL0IsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDL0MsT0FBTyxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQy9CLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRTtZQUNkLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUM7UUFDL0IsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILFlBQVksRUFBRTtRQUNaLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQztRQUVsQixtQ0FBbUM7UUFDbkMsSUFBSSxTQUFTLENBQUM7UUFDZDs7V0FFRztRQUNILE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDekI7O1dBRUc7UUFDSCxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO1FBRXpCLE1BQU0saUJBQWlCLEdBQUcsSUFBSSxhQUFhLEVBQUUsQ0FBQztRQUM5QyxNQUFNLGlCQUFpQixHQUFHLElBQUksYUFBYSxFQUFFLENBQUM7UUFFOUMsZ0dBQWdHO1FBQ2hHLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLG9CQUFvQixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRXBFLE1BQU0sU0FBUyxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsOEJBQThCLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDbkUsTUFBTSxlQUFlLEdBQUcsR0FBRyxDQUFDLEVBQUU7WUFDNUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxDQUFDLEdBQUcsS0FBSyx1QkFBdUIsQ0FBQztRQUN4RixDQUFDLENBQUM7UUFFRixNQUFNLFdBQVcsR0FBRyxDQUFDLE9BQU8sRUFBRSxZQUFZLEVBQUUsZ0JBQWdCLEVBQUUsYUFBYSxDQUFDLENBQUM7UUFDN0UsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBRXpELHdDQUF3QztZQUN4QyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxRQUFRLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxhQUFhLEVBQUUsR0FBRyxHQUFHLENBQUMsQ0FBQztZQUV0RSxtQ0FBbUM7WUFDbkMsU0FBUyxHQUFHLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUVoQyxPQUFPLEtBQUssQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO1FBQ3RDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCxPQUFPLElBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO1FBQ3hDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCxPQUFPLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0JBQ25CLHFCQUFxQjtnQkFDckIsS0FBSyxFQUFFLEtBQUssQ0FBQyxLQUFLLEVBQUU7Z0JBRXBCLDJCQUEyQjtnQkFDM0IsU0FBUyxFQUFFLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUTtvQkFDaEMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDO29CQUMxQixDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyx5QkFBeUIsQ0FBQztnQkFFOUMsMkJBQTJCO2dCQUMzQixTQUFTLEVBQUUsU0FBUztvQkFDbEIsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUTt3QkFDdkIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDO3dCQUMxQixDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyx5QkFBeUIsQ0FBQzthQUNqRCxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDaEIsR0FBRyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsT0FBTyxDQUFDLFNBQVMsY0FBYyxPQUFPLENBQUMsU0FBUyxTQUFTLENBQUMsQ0FBQztZQUUzRixJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxTQUFTLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ25FLElBQUksQ0FBQyxjQUFjLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQztZQUN4QyxJQUFJLENBQUMsY0FBYyxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUM7WUFFeEMsY0FBYztZQUNkLElBQUksWUFBWSxHQUFHLENBQUMsQ0FBQztZQUVyQixNQUFNLGdCQUFnQixHQUFHLEtBQUssQ0FBQyxFQUFFO2dCQUMvQix3RUFBd0U7Z0JBQ3hFLEtBQUssR0FBRyxLQUFLLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFO29CQUN2QixpQkFBaUIsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQ3RELE9BQU8sSUFBSSxDQUFDLG9CQUFvQixDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDL0MsQ0FBQyxDQUFDLENBQUM7Z0JBQ0gsT0FBTyxLQUFLLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO29CQUMvQyxZQUFZLElBQUksS0FBSyxDQUFDLE1BQU0sQ0FBQztvQkFDN0IsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUM7Z0JBQzNDLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxDQUFDO1lBRUYsTUFBTSxVQUFVLEdBQUcsR0FBRyxFQUFFO2dCQUN0QixJQUFJLFlBQVksR0FBRyxDQUFDLEVBQUU7b0JBQ3BCLEdBQUcsQ0FBQyxJQUFJLENBQUMsOENBQThDLEdBQUcsWUFBWSxDQUFDLENBQUM7aUJBQ3pFO2dCQUNELDhDQUE4QztnQkFDOUMsT0FBTyxXQUFXLENBQUMsS0FBSyxFQUFFLGdCQUFnQixFQUFFLFNBQVMsRUFBRSxZQUFZLENBQUMsQ0FBQztZQUN2RSxDQUFDLENBQUM7WUFFRixPQUFPLEtBQUssQ0FBQyxZQUFZLENBQUMsYUFBYSxFQUFFLFVBQVUsRUFBRTtnQkFDbkQsS0FBSyxFQUFFLEVBQUUsR0FBRyxJQUFJO2dCQUNoQixPQUFPLEVBQUUsSUFBSSxDQUFDLGlCQUFpQjtnQkFDL0IsTUFBTSxFQUFFLGVBQWU7YUFDeEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ1gsd0JBQXdCO2dCQUN4QixPQUFPLGtCQUFrQixDQUFDLFlBQVksQ0FBQyxTQUFTLEVBQUUsVUFBVSxDQUFDLElBQUksRUFBRSxpQkFBaUIsQ0FBQyxDQUFDO1lBQ3hGLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNYLElBQUksU0FBUyxFQUFFO2dCQUNiLHVCQUF1QjtnQkFDdkIsT0FBTztnQkFDUCxzRkFBc0Y7YUFDdkY7WUFFRCxjQUFjO1lBQ2QsSUFBSSxZQUFZLEdBQUcsQ0FBQyxDQUFDO1lBRXJCLE1BQU0sZ0JBQWdCLEdBQUcsS0FBSyxDQUFDLEVBQUU7Z0JBQy9CLHdFQUF3RTtnQkFDeEUsS0FBSyxHQUFHLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUU7b0JBQ3ZCLHdCQUF3QjtvQkFDeEIsaUJBQWlCLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDbEQsT0FBTyxJQUFJLENBQUMsb0JBQW9CLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUMvQyxDQUFDLENBQUMsQ0FBQztnQkFDSCxPQUFPLEtBQUssQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7b0JBQy9DLFlBQVksSUFBSSxLQUFLLENBQUMsTUFBTSxDQUFDO29CQUM3QixJQUFJLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQztnQkFDM0MsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDLENBQUM7WUFFRixNQUFNLFVBQVUsR0FBRyxHQUFHLEVBQUU7Z0JBQ3RCLElBQUksWUFBWSxHQUFHLENBQUMsRUFBRTtvQkFDcEIsR0FBRyxDQUFDLElBQUksQ0FBQyw4Q0FBOEMsR0FBRyxZQUFZLENBQUMsQ0FBQztpQkFDekU7Z0JBQ0QsOENBQThDO2dCQUM5QyxPQUFPLFdBQVcsQ0FBQyxLQUFLLEVBQUUsZ0JBQWdCLEVBQUUsU0FBUyxFQUFFLFlBQVksQ0FBQyxDQUFDO1lBQ3ZFLENBQUMsQ0FBQztZQUVGLE9BQU8sS0FBSyxDQUFDLFlBQVksQ0FBQyxhQUFhLEVBQUUsVUFBVSxFQUFFO2dCQUNuRCxLQUFLLEVBQUUsRUFBRSxHQUFHLElBQUk7Z0JBQ2hCLE9BQU8sRUFBRSxJQUFJLENBQUMsaUJBQWlCO2dCQUMvQixNQUFNLEVBQUUsZUFBZTthQUN4QixDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDWCx3QkFBd0I7Z0JBQ3hCLE9BQU8sa0JBQWtCLENBQUMsWUFBWSxDQUFDLFNBQVMsRUFBRSxVQUFVLENBQUMsSUFBSSxFQUFFLGlCQUFpQixDQUFDLENBQUM7WUFDeEYsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1gsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsRUFBRSxDQUFDO1FBQzlCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCwyQkFBMkI7WUFDM0IsR0FBRyxDQUFDLElBQUksQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDO1lBQzVDLE9BQU8sS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ3hCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCwrRkFBK0Y7WUFDL0YsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFDeEMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNYLE9BQU8sSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7UUFDdEMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ2YsK0JBQStCO1lBQy9CLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQy9DLHFFQUFxRTtnQkFDckUsb0RBQW9EO2dCQUNwRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDL0IsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDWCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDL0IsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDWCxnRUFBZ0U7Z0JBQ2hFLE9BQU8sT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUMvQixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUU7WUFDZCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDO1FBQy9CLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGLENBQUM7QUFFRix5QkFBeUI7QUFFekI7Ozs7Ozs7OztHQVNHO0FBQ0gsU0FBUyxXQUFXLENBQUMsS0FBSyxFQUFFLFdBQVcsRUFBRSxTQUFTLEVBQUUsTUFBTTtJQUN4RCxPQUFPLEtBQUssQ0FBQyxhQUFhLENBQUMsRUFBQyxNQUFNLEVBQUUsTUFBTSxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRTtRQUNuRixPQUFPLElBQUksT0FBTyxDQUFDLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxFQUFFO1lBQ3JDLElBQUksV0FBVyxHQUFHLEVBQUUsQ0FBQztZQUVyQixNQUFNLG9CQUFvQixHQUFHLEdBQUcsRUFBRTtnQkFDaEMsV0FBVyxHQUFHLEVBQUUsQ0FBQztnQkFDakIsVUFBVSxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ3RCLENBQUMsQ0FBQztZQUVGLFVBQVUsQ0FBQyxFQUFFLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxFQUFFO2dCQUU3QixxQkFBcUI7Z0JBQ3JCLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBRXpCLGdEQUFnRDtnQkFDaEQsSUFBSSxXQUFXLENBQUMsTUFBTSxJQUFJLFNBQVMsRUFBRTtvQkFDbkMsVUFBVSxDQUFDLEtBQUssRUFBRSxDQUFDO29CQUNuQixXQUFXLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLG9CQUFvQixFQUFFLEtBQUssQ0FBQyxFQUFFO3dCQUMxRCxHQUFHLENBQUMsS0FBSyxDQUFDLGdDQUFnQyxFQUFFLEtBQUssQ0FBQyxDQUFDO3dCQUNuRCxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ2hCLENBQUMsQ0FBQyxDQUFDO2lCQUNKO1lBQ0gsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssRUFBRSxHQUFHLEVBQUU7Z0JBQ2hCLFdBQVcsQ0FBQyxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxFQUFFO29CQUM3QyxHQUFHLENBQUMsS0FBSyxDQUFDLHFDQUFxQyxFQUFFLEtBQUssQ0FBQyxDQUFDO29CQUN4RCxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ2hCLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsRUFBRTtnQkFDckIsR0FBRyxDQUFDLEtBQUssQ0FBQywrQkFBK0IsRUFBRSxLQUFLLENBQUMsQ0FBQztnQkFDbEQsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ2hCLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ2QsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUM7QUFFRDs7Ozs7Ozs7O0dBU0c7QUFDSCxTQUFTLFdBQVcsQ0FBQyxLQUFLLEVBQUUsV0FBVyxFQUFFLFNBQVMsRUFBRSxNQUFNO0lBQ3hELE9BQU8sS0FBSyxDQUFDLGFBQWEsQ0FBQyxFQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFO1FBQ25GLE9BQU8sSUFBSSxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDckMsSUFBSSxXQUFXLEdBQUcsRUFBRSxDQUFDO1lBRXJCLE1BQU0sb0JBQW9CLEdBQUcsR0FBRyxFQUFFO2dCQUNoQyxXQUFXLEdBQUcsRUFBRSxDQUFDO2dCQUNqQixVQUFVLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDdEIsQ0FBQyxDQUFDO1lBRUYsVUFBVSxDQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLEVBQUU7Z0JBRTdCLHFCQUFxQjtnQkFDckIsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFFekIsZ0RBQWdEO2dCQUNoRCxJQUFJLFdBQVcsQ0FBQyxNQUFNLElBQUksU0FBUyxFQUFFO29CQUNuQyxVQUFVLENBQUMsS0FBSyxFQUFFLENBQUM7b0JBQ25CLFdBQVcsQ0FBQyxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLEVBQUU7d0JBQzFELEdBQUcsQ0FBQyxLQUFLLENBQUMsZ0NBQWdDLEVBQUUsS0FBSyxDQUFDLENBQUM7d0JBQ25ELE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDaEIsQ0FBQyxDQUFDLENBQUM7aUJBQ0o7WUFDSCxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxFQUFFLEdBQUcsRUFBRTtnQkFDaEIsV0FBVyxDQUFDLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLEVBQUU7b0JBQzdDLEdBQUcsQ0FBQyxLQUFLLENBQUMscUNBQXFDLEVBQUUsS0FBSyxDQUFDLENBQUM7b0JBQ3hELE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDaEIsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxFQUFFO2dCQUNyQixHQUFHLENBQUMsS0FBSyxDQUFDLCtCQUErQixFQUFFLEtBQUssQ0FBQyxDQUFDO2dCQUNsRCxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDaEIsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDZCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQztBQUVELDJCQUEyQjtBQUUzQixNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3hCLE1BQU0sQ0FBQyxPQUFPLEdBQUcsVUFBVSxDQUFDIn0=