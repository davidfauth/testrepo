"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-11-05.
 */
// TODO TS2019
const rest_client_1 = require("@linkurious/rest-client");
const Bluebird = require("bluebird");
const umd_1 = require("linkurious-shared/umd");
const _ = require("lodash");
const Bug_1 = require("../../models/errors/Bug");
const GraphRequestTimeout_1 = require("../../models/errors/GraphRequestTimeout");
const IllegalSourceStateError_1 = require("../../models/errors/IllegalSourceStateError");
const MalformedQueryTemplate_1 = require("../../models/errors/MalformedQueryTemplate");
const graphQueryParams_1 = require("../../models/parameters/graphQueryParams");
const builder_1 = require("../graphSchema/builder");
const LKE = require("../index");
const DataSource = require('./dataSource');
const DesignUtils = require('../business/designUtils');
const Log = LKE.getLogger(__filename);
const DbModels = LKE.getSqlDb().models;
const Errors = LKE.getErrors();
const Config = LKE.getConfig();
const GraphSchemaService = LKE.getGraphSchema();
const Utils = LKE.getUtils();
const lkeIsReadOnly = !Config.get('access.dataEdition');
class DataService {
    constructor() {
        this.sources = [];
        // key of the currently indexed data-source (or null)
        this.indexedSource = null;
        // DataSources indexed by sourceKey
        this.sourceByKey = {};
        this.updateNodeMutex = Utils.semaphore(1);
        this.updateEdgeMutex = Utils.semaphore(1);
        this.removeDeletedSources();
        this.loadSources();
        this.templateParser = new umd_1.QueryTemplateParser((validationMessage, highlight) => {
            throw new MalformedQueryTemplate_1.MalformedQueryTemplate(validationMessage, highlight);
        }, bugMessage => {
            throw new Bug_1.Bug(bugMessage);
        });
    }
    /**
     * Remove all source configs where `deleted` is true.
     */
    removeDeletedSources() {
        const sourceConfigs = Config.get('dataSources');
        // sourceConfigs marked for deletion
        const filteredSourceConfigs = _.filter(sourceConfigs, sourceConfig => !sourceConfig.deleted);
        if (sourceConfigs.length === filteredSourceConfigs.length) {
            // nothing to delete
            return;
        }
        // we replace the dataSources configuration array with the filtered one
        Config.set('dataSources', filteredSourceConfigs);
    }
    loadSources() {
        const sources = [];
        Config.get('dataSources').forEach((config, sourceId) => {
            sources.push(new DataSource(sourceId, this));
        });
        if (sources.length === 0) {
            throw Errors.business('dataSource_unavailable', 'no data-source defined in configuration.');
        }
        this.sources = sources;
    }
    /**
     * @param sourceKeyOrConfigIndex The key or the config index of the data-source
     * @param willWrite              Whether the source will be written to
     * @param action
     */
    withSource(sourceKeyOrConfigIndex, willWrite, 
    // since the DataSource is connected it has the graph and index DAOs
    action) {
        const source = this.resolveSource(sourceKeyOrConfigIndex);
        if (willWrite && source.isReadOnly()) {
            return Errors.access('write_forbidden', 'The data-source is in read-only mode.', true);
        }
        if (willWrite && lkeIsReadOnly) {
            return Errors.access('readonly_right', 'Linkurious is in read-only mode.', true);
        }
        return Bluebird.resolve()
            .then(() => action(source))
            .catch(err => {
            if (err.key === 'dataSource_unavailable' && source.isConnected()) {
                Log.warn('Source failure: ' + JSON.stringify(err));
                source.indexConnected = false;
                source.graphConnected = false;
                source.connect(true);
            }
            return Bluebird.reject(err);
        });
    }
    /**
     * Resolve a data-source by source key or config index.
     *
     * Note that, if you need to resolve a source that may be offline, you must resolve by configIndex.
     * Throw if the data-source was not found or we were resolving by key and source was offline.
     *
     * @param sourceKeyOrConfigIndex The key or the config index of the data-source
     */
    resolveSource(sourceKeyOrConfigIndex) {
        // TODO Data.resolveSource should return a "ConnectedSource"
        if (Utils.noValue(sourceKeyOrConfigIndex)) {
            throw Errors.technical('dataSource_unavailable', 'Neither sourceKey nor configIndex provided.');
        }
        let i;
        let source;
        // resolve by configIndex (id)
        if (typeof sourceKeyOrConfigIndex === 'number') {
            for (i = 0; i < this.sources.length; ++i) {
                source = this.sources[i];
                if (source.sourceId === sourceKeyOrConfigIndex && !source.destroyed) {
                    return source;
                }
            }
            throw Errors.business('dataSource_unavailable', 'data-source #' + sourceKeyOrConfigIndex + ' was not found');
        }
        // resolve by sourceKey
        if (typeof sourceKeyOrConfigIndex !== 'string') {
            throw Errors.technical('bug', '"sourceKey" must be a string');
        }
        // from cache
        source = this.sourceByKey[sourceKeyOrConfigIndex];
        // we check for the `destroyed` flag (if deleteSourceConfig occurs we don't clean this cache)
        if (source && !source.destroyed) {
            if (!source.isConnected()) {
                throw Errors.business('dataSource_unavailable', 'data-source "' + sourceKeyOrConfigIndex + '" is not connected');
            }
            return source;
        }
        // slow version
        for (i = 0; i < this.sources.length; ++i) {
            if (!this.sources[i].isConnected()) {
                continue;
            }
            if (this.sources[i].getSourceKey() === sourceKeyOrConfigIndex) {
                source = this.sources[i];
                // add to cache
                this.sourceByKey[sourceKeyOrConfigIndex] = source;
                return source;
            }
        }
        throw Errors.business('dataSource_unavailable', 'data-source "' + sourceKeyOrConfigIndex + '" was not found or is not connected.');
    }
    /**
     * Get the current state of all configured data-sources.
     * The DataSourceState of a data-source is an information accessible to everyone using the data-source.
     *
     * @param [options]
     * @param [options.withStyles]   Whether to include the default styles of the data-sources
     * @param [options.withCaptions] Whether to include the default captions of the data-sources
     */
    getSourceStates(options = {}) {
        const { withStyles, withCaptions } = options;
        return Bluebird.resolve(this.sources.map(s => {
            const state = s.getState();
            const response = {
                configIndex: s.sourceId,
                connected: s.isConnected(),
                error: state.error,
                features: s.features,
                key: s.isConnected() ? s.getSourceKey() : null,
                name: s.getDisplayName(),
                reason: state.reason,
                settings: {
                    readOnly: !!s.isReadOnly()
                },
                state: state.code
            };
            if (s.isConnected()) {
                response.settings.strictSchema = s.getOptions().strictSchema;
                if (withStyles) {
                    response.defaultStyles = s.state.defaultStyles;
                }
                if (withCaptions) {
                    response.defaultCaptions = s.state.defaultCaptions;
                }
            }
            if (Utils.hasValue(s.graph)) {
                const graphDao = s.graph;
                response.settings.alternativeIds = {
                    edge: graphDao.options.alternativeEdgeId,
                    node: graphDao.options.alternativeNodeId
                };
                response.settings.latitudeProperty = graphDao.options.latitudeProperty;
                response.settings.longitudeProperty = graphDao.options.longitudeProperty;
                if (s.isConnected()) {
                    response.settings.specialProperties = graphDao.specialProperties;
                }
            }
            if (Utils.hasValue(s.index)) {
                const indexDao = s.index;
                response.settings.skipEdgeIndexation =
                    !!indexDao.options.skipEdgeIndexation || !indexDao.features.canIndexEdges;
            }
            return response;
        }));
    }
    /**
     * Get the DataSourceInfo of all data-sources, including:
     * - disconnected sources that have been seen in the past (source states).
     * - disconnected sources that have never been seen (source configs).
     * - connected sources (source configs with states).
     *
     * The DataSourceInfo of a data-source is an information accessible only to admins.
     */
    getAllSources() {
        const vizDAO = LKE.getVisualizationDAO();
        // copy the configured sources array
        const configuredSources = this.sources.slice(0);
        // fetch seen sources
        return DbModels.dataSourceState
            .findAll({ where: {} })
            .map((seenSourceInstance) => {
            const seenSource = _.pick(seenSourceInstance.get(), [
                'lastSeen',
                'info',
                'name',
                'lastIndexed',
                'lastSampled',
                'key'
            ]);
            // if the seen source matches a configured source, merge them
            const matches = _.remove(configuredSources, s => s.getSourceKey(true) === seenSource.key);
            if (matches.length) {
                seenSource.state = matches[0].getState().code;
                seenSource.configIndex = matches[0].sourceId;
            }
            else {
                seenSource.state = 'offline';
                seenSource.configIndex = null;
            }
            // host + port
            const hostPortStore = seenSource.info.split(':');
            seenSource.host = hostPortStore[0];
            seenSource.port = hostPortStore[1];
            seenSource.storeId = hostPortStore.slice(2).join(':');
            delete seenSource.info;
            return vizDAO.getVisualizationCount(seenSource.key, true).then(c => {
                seenSource.visualizationCount = c;
                return seenSource;
            });
        }, { concurrency: 1 })
            .then(seenSources => {
            // contains only sources that don't have a sourceKey (offline, connecting)
            const noKeySources = configuredSources.map(dataSource => {
                const hostPort = Utils.extractHostPort(dataSource.config.graphdb.url);
                return {
                    configIndex: dataSource.sourceId,
                    host: hostPort.host,
                    lastIndexed: null,
                    lastSampled: null,
                    key: null,
                    lastSeen: null,
                    name: Utils.hasValue(dataSource.config.name)
                        ? dataSource.config.name
                        : null,
                    port: hostPort.port,
                    state: dataSource.getState().code,
                    storeId: null,
                    visualizationCount: 0
                };
            });
            return seenSources.concat(noKeySources);
        });
    }
    /**
     * Create a new data-source.
     * Return the created source's configuration index.
     *
     * @param sourceConfig
     * @param [sourceConfig.name]         Name of the data-source
     * @param sourceConfig.graphdb        The configuration options of the graph database
     * @param sourceConfig.graphdb.vendor The vendor of the graph database ('neo4j', ...)
     * @param sourceConfig.index          The configuration options of the index
     * @param sourceConfig.index.vendor   The vendor of the index ('elasticSearch')
     */
    createSource(sourceConfig) {
        Utils.check.properties('config', sourceConfig, {
            graphdb: {
                required: true,
                properties: {
                    vendor: { required: true, type: 'string' }
                },
                policy: 'inclusive'
            },
            index: {
                required: true,
                properties: {
                    vendor: { required: true, type: 'string' }
                },
                policy: 'inclusive'
            },
            name: { type: 'string' }
        });
        return Config.add('dataSources', sourceConfig).then(configCount => {
            const configIndex = configCount - 1;
            const source = new DataSource(configIndex, this);
            this.sources.push(source);
            // don't wait for the connection to succeed (don't return this promise)
            source.connect(true);
            return configIndex;
        });
    }
    /**
     * Delete a data-source config.
     *
     * @param configIndex
     */
    deleteSourceConfig(configIndex) {
        const source = _.find(this.sources, { sourceId: configIndex });
        if (!source) {
            return Errors.business('not_found', `Data-source with configuration index ${configIndex} was not found.`, true);
        }
        if (source.getState().code !== 'offline') {
            return Errors.business('illegal_source_state', 'Data-source must be offline to be deleted.', true);
        }
        // the server cannot run with 0 sources
        if (this.sources.length === 1) {
            return Errors.business('not_implemented', 'Cannot delete the only configured data-source.', true);
        }
        // prevent the source from doing anything
        source.destroy();
        // remove the source from the source array
        _.remove(this.sources, { sourceId: configIndex });
        // mark the source for deletion in the configuration
        // this will allow the `configIndex` of other data-sources to be the same until the next boot
        return Config.set(`dataSources.${configIndex}.deleted`, true);
    }
    /**
     * Delete all data (visualizations, user-groups etc.) of a data-source
     * or, optionally, merge this data into another data-source.
     *
     * @param deletedSourceKey
     * @param [mergeTargetKey]
     */
    deleteSourceData(deletedSourceKey, mergeTargetKey) {
        const source = _.find(this.sources, s => s.getSourceKey(true) === deletedSourceKey);
        const deleteConfigPromise = source
            ? this.deleteSourceConfig(source.sourceId)
            : Bluebird.resolve();
        // 1) delete existing configuration, if any (checks that the source is disconnected)
        let deletedSourceState;
        return deleteConfigPromise
            .then(() => {
            // 2) get sourceStates (deleted and mergeTarget)
            const sourceKeys = [deletedSourceKey];
            if (mergeTargetKey !== undefined) {
                sourceKeys.push(mergeTargetKey);
            }
            return DbModels.dataSourceState.findAll({ where: { key: sourceKeys } });
        })
            .then(sourceStates => {
            // 3) check that the deleted sourceState exists
            const deletedSourceStateLookUp = _.find(sourceStates, { key: deletedSourceKey });
            if (!deletedSourceStateLookUp) {
                throw Errors.business('not_found', `Cannot delete data-source #${deletedSourceKey} (not found).`);
            }
            deletedSourceState = deletedSourceStateLookUp;
            // 4) if merging, check that the mergeTarget sourceState exists
            const mergeTargetSourceState = _.find(sourceStates, { key: mergeTargetKey });
            if (mergeTargetKey !== undefined) {
                if (mergeTargetSourceState === undefined) {
                    throw Errors.business('not_found', `Cannot merge data into data-source #${deletedSourceKey} (not found).`);
                }
                if (mergeTargetKey === deletedSourceKey) {
                    throw Errors.business('invalid_parameter', `Cannot merge data data-source #${deletedSourceKey} into itself.`);
                }
            }
            // 5) merge or delete (widgets, visualizations, visualizationFolders)
            let mergeOrDeletePromise = Bluebird.resolve();
            const affected = {
                visualizations: 0,
                folders: 0,
                groups: 0,
                alerts: 0,
                matches: 0,
                graphQueries: 0
            };
            let merging = false;
            const where = { sourceKey: deletedSourceKey };
            if (mergeTargetKey !== undefined) {
                // 5.a) merge
                merging = true;
                // update parameters
                const values = { sourceKey: mergeTargetKey };
                const options = {
                    // update only items from the deleted source
                    where: where,
                    // update only the sourceKey attribute
                    fields: ['sourceKey'],
                    // don't validate
                    validate: false,
                    // don't update the 'updatedAt' field
                    silent: true
                };
                const vizOptions = Utils.clone(options);
                vizOptions.where.sandbox = false;
                mergeOrDeletePromise = DbModels.visualization
                    .update(values, vizOptions)
                    // @ts-ignore this is correct, it's an error of sequelize or bluebird typing
                    .spread((count) => {
                    affected.visualizations = count;
                    return DbModels.visualizationFolder.update(values, options);
                })
                    .spread((count) => {
                    affected.folders = count;
                    // we only want to migrate non-builtin groups
                    const updateNonBuiltinGroupOptions = Utils.clone(options);
                    updateNonBuiltinGroupOptions.where.builtin = false;
                    return DbModels.group.update(values, updateNonBuiltinGroupOptions);
                })
                    .spread((count) => {
                    affected.groups = count;
                    // and we want to delete the builtin ones
                    const deleteBuiltinGroupWhere = Utils.clone(where);
                    deleteBuiltinGroupWhere.builtin = true;
                    return DbModels.group.destroy({ where: deleteBuiltinGroupWhere });
                })
                    .then(() => {
                    return DbModels.alert.update(values, options);
                })
                    .spread((count) => {
                    affected.alerts = count;
                    return DbModels.match.update(values, options);
                })
                    .spread((count) => {
                    affected.matches = count;
                    return DbModels.graphQuery.update(values, options);
                })
                    .spread((count) => {
                    affected.graphQueries = count;
                });
            }
            else {
                // 5.b) delete
                merging = false;
                mergeOrDeletePromise = DbModels.visualization
                    .destroy({ where: where })
                    .then(count => {
                    affected.visualizations = count;
                    return DbModels.visualizationFolder.destroy({ where: where });
                })
                    .then(count => {
                    affected.folders = count;
                    return DbModels.group.destroy({ where: where });
                })
                    .then(count => {
                    affected.groups = count;
                    return DbModels.alert.destroy({ where: where });
                })
                    .then(count => {
                    affected.alerts = count;
                    return DbModels.match.destroy({ where: where });
                })
                    .then(count => {
                    affected.matches = count;
                    return DbModels.graphQuery.destroy({ where: where });
                })
                    .then(count => {
                    affected.graphQueries = count;
                });
            }
            // 6) delete access rights
            // we don't migrate access rights because we don't want to mess up the access rights of the merge target
            return mergeOrDeletePromise
                .then(() => {
                // delete original access rights
                return DbModels.accessRight.destroy({ where: where });
            })
                .then(() => {
                // 7) delete the original source-state
                return deletedSourceState.destroy();
            })
                .then(() => {
                // 8) return a nice and clean result
                return { migrated: merging, affected: affected };
            });
        });
    }
    // TODO TS2019 refactor above here
    /**
     * Perform a search of nodes or edges based on a search query, a fuzziness value and filters.
     * The list of items that matched the search query is returned.
     */
    async searchIndex(params) {
        return this.withSource(params.sourceKey, false, async (source) => {
            // add filtered schema
            const schema = await GraphSchemaService.getSearchableSchema(params.sourceKey, params.type, source.getOptions().strictSchema, params.categoriesOrTypes);
            const searchResult = await source.index.search({
                type: params.type,
                q: params.q,
                schema: schema,
                fuzziness: params.fuzziness,
                size: params.size,
                from: params.from,
                filter: params.filter
            });
            let results;
            if (searchResult.type === 'node') {
                results = await this.getNodesByID({
                    ids: searchResult.results,
                    ignoreMissing: true,
                    sourceKey: params.sourceKey,
                    withDigest: params.withDigest,
                    withDegree: params.withDegree
                });
            }
            else {
                results = await this.getEdgesByID({
                    ids: searchResult.results,
                    ignoreMissing: true,
                    sourceKey: params.sourceKey
                });
            }
            const missingIds = Utils.checkMissing(searchResult.type, searchResult.results, results, undefined, undefined, false);
            // we create a fake entry for every missing id (item in the index but not in the graph)
            // the only purpose of these entries is to throw a frontend error if the user clicks on them
            if (searchResult.type === 'node') {
                results = results.concat(_.map(missingIds, id => ({ id: id, categories: [], data: {}, readAt: 0 })));
            }
            else {
                results = results.concat(_.map(missingIds, id => ({
                    id: id,
                    type: '',
                    source: '',
                    target: '',
                    data: {},
                    readAt: 0
                })));
            }
            return {
                type: searchResult.type,
                totalHits: searchResult.totalHits,
                moreResults: searchResult.moreResults,
                results: results
            };
        });
    }
    /**
     * Perform a search of nodes or edges based on a search query, a fuzziness value and filters.
     * A subgraph made of the items that matched the search query and the edges between them is returned.
     */
    async searchFull(params) {
        const searchResult = await this.searchIndex(params);
        // if type === 'edge' we need to fetch the extremities of the edges of the search response
        let nodes;
        if (params.type === 'edge') {
            // fetch the extremities of the edges in the search response
            const edges = searchResult.results;
            const nodeIdsSet = new Set();
            edges.forEach(edge => {
                nodeIdsSet.add(edge.source);
                nodeIdsSet.add(edge.target);
            });
            nodes = await this.getNodesByID(_.defaults({
                ids: Array.from(nodeIdsSet),
                sourceKey: params.sourceKey
            }, params));
        }
        else {
            nodes = searchResult.results;
        }
        // we need to fetch the edges between the nodes
        // plus the edges between these nodes and `edgesTo`
        const mutualEdges = await this.getMutualEdges(params.sourceKey, _.map(nodes, 'id'), {
            otherNodeIds: params.edgesTo,
            betweenFirstSet: true,
            edgeTypes: params.readableTypes
        });
        return {
            nodes: nodes,
            edges: mutualEdges
        };
    }
    /**
     * Start the schema sampling.
     */
    async startSchemaSampling(params) {
        const dataSource = this.resolveSource(params.sourceKey);
        return dataSource.asyncSampleSource(params.reset);
    }
    /**
     * Stop the schema sampling.
     */
    async stopSchemaSampling(params) {
        const dataSource = this.resolveSource(params.sourceKey);
        await dataSource.stopSampling();
    }
    /**
     * Get the schema sampling status.
     */
    async getSamplingStatus(params) {
        const dataSource = this.resolveSource(params.sourceKey);
        const schemaSampler = dataSource.schemaSampler;
        const lastSampled = Utils.hasValue(dataSource.state.lastSampled)
            ? dataSource.state.lastSampled.toISOString()
            : undefined;
        if (schemaSampler) {
            // we are currently sampling, we return the status from the sampler
            return {
                status: rest_client_1.SamplingStatus.ONGOING,
                message: schemaSampler.status,
                progress: schemaSampler.progress.toFixed(2),
                lastSampled: lastSampled
            };
        }
        const samplingError = dataSource.state.samplingError;
        if (Utils.hasValue(samplingError)) {
            // last sampling resulted in an error
            return {
                status: rest_client_1.SamplingStatus.ERROR,
                message: samplingError,
                lastSampled: lastSampled
            };
        }
        // last sampling was successful
        return {
            status: rest_client_1.SamplingStatus.DONE,
            lastSampled: lastSampled
        };
    }
    /**
     * Normalize nodes and edges against the schema, add the `readAt` attribute to each node and edge,
     * and notify if the nodes or the edges have been filtered out with the `isSchemaFiltered` property.
     */
    async normalizeNodesAndEdges(source, options, readAt) {
        const strict = source.getOptions().strictSchema;
        let isSchemaFiltered = false;
        const originalNodesLength = (options.nodes || []).length;
        const originalEdgesLength = (options.edges || []).length;
        const result = {
            nodes: _.map(await GraphSchemaService.normalizeNodes(source.getSourceKey(), options.nodes || [], strict), node => (Object.assign({ readAt: readAt }, node))),
            edges: _.map(await GraphSchemaService.normalizeEdges(source.getSourceKey(), options.edges || [], strict), edge => (Object.assign({ readAt: readAt }, edge)))
        };
        if (result.nodes.length !== originalNodesLength ||
            result.edges.length !== originalEdgesLength) {
            isSchemaFiltered = true;
        }
        return {
            isSchemaFiltered: isSchemaFiltered,
            nodes: result.nodes,
            edges: result.edges
        };
    }
    /**
     * Add a node to the graph.
     */
    async createNode(params) {
        return this.withSource(params.sourceKey, true, async (source) => {
            const currentDate = Date.now();
            const rawNodeAttributes = { categories: params.categories, data: params.properties };
            // 1) check the node against the schema
            const validNodeAttributes = await GraphSchemaService.checkNode(params.sourceKey, rawNodeAttributes, source.getOptions().strictSchema);
            // 2) decode validated data
            const nodeAttributes = await GraphSchemaService.decodeNode(params.sourceKey, validNodeAttributes);
            // 3) create node in the graph
            const newNode = await source.graph.createNode(nodeAttributes);
            // 4) update schema
            await this.updateSchema(params.sourceKey, rest_client_1.EntityType.NODE, newNode.categories, newNode.data);
            // 5) update index
            await Utils.neverReject(source.index.upsertEntry('node', source.filterNodeProperties(newNode, true)));
            // 6) normalize
            const normalizedResult = await this.normalizeNodesAndEdges(source, { nodes: [newNode] }, currentDate);
            return normalizedResult.nodes[0];
        });
    }
    /**
     * Update a subset of properties and categories of a node.
     * Keep every other property and category of the node unchanged.
     */
    async updateNode(params) {
        return this.withSource(params.sourceKey, true, async (source) => {
            return this.updateNodeMutex
                .acquire()
                .then(async () => {
                // 1) get the node (check if it exists)
                const originalNode = (await source.graph.getNodesByID({ ids: [params.id] }))[0];
                // 2) check for edit conflicts
                const lastChangeDate = source.getLastEditDate('node', originalNode.id);
                this.checkEditConflict('Node', lastChangeDate, params.readAt);
                // 3) check the node against the schema
                await GraphSchemaService.checkNodeUpdate(params.sourceKey, originalNode, params.properties, params.addedCategories, params.deletedCategories, params.deletedProperties, source.getOptions().strictSchema);
                // categories of the node after the update
                // updatedCategories = (addedCategories + originalCategories) - deletedCategories
                const updatedCategories = _.without(_.union(params.addedCategories || [], originalNode.categories), ...(params.deletedCategories || []));
                // 4) decode validated data
                // we know that node data is valid after the check
                const data = await GraphSchemaService.decodeData(params.sourceKey, rest_client_1.EntityType.NODE, updatedCategories, params.properties);
                // 5) update the node in the graph
                const updatedNode = await source.graph.updateNode({
                    id: params.id,
                    data: data,
                    addedCategories: params.addedCategories,
                    deletedCategories: params.deletedCategories,
                    deletedProperties: params.deletedProperties
                });
                // 6) update the last change date
                const updateDate = source.updateLastEditDate('node', originalNode.id);
                // 7) update the graph schema
                await this.updateSchema(params.sourceKey, rest_client_1.EntityType.NODE, updatedNode.categories, updatedNode.data);
                // 8) update index
                await Utils.neverReject(source.index.upsertEntry('node', source.filterNodeProperties(updatedNode, true)));
                // 9) normalize
                const normalizedResult = await this.normalizeNodesAndEdges(source, { nodes: [updatedNode] }, updateDate);
                return normalizedResult.nodes[0];
            })
                .finally(() => {
                this.updateNodeMutex.release();
            });
        });
    }
    /**
     * Add an edge to the graph.
     */
    async createEdge(params) {
        return this.withSource(params.sourceKey, true, async (source) => {
            const currentDate = Date.now();
            const rawEdgeAttributes = {
                type: params.type,
                data: params.properties,
                source: params.source,
                target: params.target
            };
            // 1) check the edge against the schema
            const validEdgeAttributes = await GraphSchemaService.checkEdge(params.sourceKey, rawEdgeAttributes, source.getOptions().strictSchema);
            // 2) decode validated data
            const edgeAttributes = await GraphSchemaService.decodeEdge(params.sourceKey, validEdgeAttributes);
            // 3) create edge in the graph
            const newEdge = await source.graph.createEdge(edgeAttributes);
            // 4) update schema
            await this.updateSchema(params.sourceKey, rest_client_1.EntityType.EDGE, [newEdge.type], newEdge.data);
            // 5) update index
            await Utils.neverReject(source.index.upsertEntry('edge', source.filterEdgeProperties(newEdge, true)));
            // 6) normalize
            const normalizedResult = await this.normalizeNodesAndEdges(source, { edges: [newEdge] }, currentDate);
            return normalizedResult.edges[0];
        });
    }
    /**
     * Update a subset of properties of an edge. Keep every other property of the edge unchanged.
     * It's not possible to update the type of an edge.
     */
    async updateEdge(params) {
        return this.withSource(params.sourceKey, true, async (source) => {
            return this.updateEdgeMutex
                .acquire()
                .then(async () => {
                // 1) get the edge (check if it exists)
                const originalEdge = (await source.graph.getEdgesByID({ ids: [params.id] }))[0];
                // 2) check for edit conflicts
                const lastChangeDate = source.getLastEditDate('edge', originalEdge.id);
                this.checkEditConflict('Edge', lastChangeDate, params.readAt);
                // 3) check the edge against the schema
                await GraphSchemaService.checkEdgeUpdate(params.sourceKey, originalEdge, params.properties, params.deletedProperties, source.getOptions().strictSchema);
                // 4) decode validated data
                // we know that edge data is valid after the check
                const data = await GraphSchemaService.decodeData(params.sourceKey, rest_client_1.EntityType.EDGE, [originalEdge.type], params.properties);
                // 5) update the edge in the graph
                const updatedEdge = await source.graph.updateEdge({
                    id: params.id,
                    data: data,
                    deletedProperties: params.deletedProperties
                });
                // 6) update the last change date
                const updateDate = source.updateLastEditDate('edge', originalEdge.id);
                // 7) update the schema
                await this.updateSchema(params.sourceKey, rest_client_1.EntityType.EDGE, [updatedEdge.type], updatedEdge.data);
                // 8) update the edge in the index
                await Utils.neverReject(source.index.upsertEntry('edge', source.filterEdgeProperties(updatedEdge, true)));
                // 9) normalize
                const normalizedResult = await this.normalizeNodesAndEdges(source, { edges: [updatedEdge] }, updateDate);
                return normalizedResult.edges[0];
            })
                .finally(() => {
                this.updateEdgeMutex.release();
            });
        });
    }
    /**
     * Reindex the graph database.
     * Don't wait for the indexation to finish.
     */
    async startIndexation(params) {
        const source = this.resolveSource(params.sourceKey);
        const indexedSource = this.getIndexedSource();
        if (indexedSource !== null) {
            if (indexedSource === params.sourceKey) {
                throw new IllegalSourceStateError_1.IllegalSourceStateError(`Data-source #${source.sourceId} is already indexing.`);
            }
            throw new IllegalSourceStateError_1.IllegalSourceStateError(`Cannot index data-source #${source.sourceId}: another data-source is indexing.`);
        }
        return this.indexSource(params.sourceKey);
    }
    async indexSource(sourceKey) {
        const source = this.resolveSource(sourceKey);
        // check that the source is connected
        if (!source.isConnected()) {
            return;
        }
        // if we are already indexing any data-source, do nothing
        if (LKE.getStateMachine().get('DataService').name === 'indexing') {
            return;
        }
        LKE.getStateMachine().set('DataService', 'indexing');
        // set currently indexing source
        this.indexedSource = sourceKey;
        // note: we don't wait for the indexation to finish, we don't return this promise on purpose
        source
            .indexSource()
            .finally(() => {
            this.indexedSource = null;
            LKE.getStateMachine().set('DataService', 'up');
        })
            .catch((e) => {
            Log.error('Indexation failed: ', e);
            // ignore the rejection in this non-returned promise
        });
    }
    async getIndexationStatus(params) {
        const source = this.resolveSource(params.sourceKey);
        return source.getSearchStatus();
    }
    /**
     * List all `edgeTypes`, `nodeCategories`, `edgeProperties`, `nodeProperties`
     * that exist in the graph database.
     */
    getSimpleSchema(params) {
        return this.withSource(params.sourceKey, false, source => {
            return source.graph.getSimpleSchema();
        });
    }
    async updateGraphSchemaSettings(params) {
        const source = await this.resolveSource(params.sourceKey);
        const options = source.getOptions();
        options.strictSchema = params.strictSchema;
        return source.updateOptions(options);
    }
    /**
     * List types on the schema (including property keys, types).
     */
    async getGraphSchema(params) {
        const source = await this.resolveSource(params.sourceKey);
        const strict = source.getOptions().strictSchema;
        const schema = await GraphSchemaService.getSchema(params.sourceKey, params.entityType, strict);
        return { results: Array.from(schema.values()) };
    }
    /**
     * Get a list of nodes and edges by ID.
     *
     * @param options.nodeIds              IDs of the nodes
     * @param options.edgeIds              IDs of the edges
     * @param options.sourceKey            Key of the data-source
     * @param [options.alternativeNodeId]  The property to match `options.nodeIds` on (instead of the actual IDs)
     * @param [options.alternativeEdgeId]  The property to match `options.edgeIds` on (instead of the actual IDs)
     * @param [options.ignoreMissing]      Whether to fail if there are missing nodes
     * @param [options.withDigest]         Whether to include the adjacency digest in the returned nodes
     * @param [options.withDegree]         Whether to include the degree in the returned nodes
     * @param [options.readableCategories] Exclusive list of node categories to restrict the result
     * @param [options.readableTypes]      Exclusive list of edge types to restrict the result
     */
    async getNodesAndEdgesByID(options) {
        return this.withSource(options.sourceKey, false, async (source) => {
            const currentDate = Date.now();
            const nodes = await source.graph.getNodesByID(Object.assign({}, options, { ids: options.nodeIds, alternativeId: options.alternativeNodeId }));
            const edges = await source.graph.getEdgesByID(Object.assign({}, options, { ids: options.edgeIds, alternativeId: options.alternativeEdgeId }));
            const { isSchemaFiltered, nodes: publicNodes, edges: publicEdges } = await this.normalizeNodesAndEdges(source, { nodes: nodes, edges: edges }, currentDate);
            return {
                isFiltered: isSchemaFiltered,
                result: {
                    nodes: publicNodes,
                    edges: publicEdges
                }
            };
        });
    }
    // TODO TS2019 refactor under here
    /**
     * Get the number of nodes in the graph.
     *
     * @param sourceKey Key of the data-source
     */
    getNodeCount(sourceKey) {
        return this.withSource(sourceKey, false, source => {
            const stateCode = source.getState().code;
            // if we are indexing, the count is cached, use it
            if (stateCode === 'indexing' && Utils.hasValue(source.nodeCountCache)) {
                return source.nodeCountCache;
            }
            // if the indexation is done (state=ready) and the index can count, use the index
            if (stateCode === 'ready' && source.index.features.canCount) {
                return source.index.getSize('node');
            }
            // if the graph can count, use the graph
            if (source.graph.features.canCount) {
                return source.graph.getNodeCount(
                // approximate if indexation is ongoing
                // don't approximate in test mode
                stateCode === 'indexing' && !LKE.isTestMode());
            }
            // if we can't count, we soft-fail with the value 0
            return Bluebird.resolve(0);
        });
    }
    /**
     * Get a node of the graph.
     * A subgraph made of the single node is returned.
     *
     * @param options
     * @param options.sourceKey            Key of the data-source
     * @param options.id                   ID of the node
     * @param [options.alternativeId]      The property to match `id` on (instead of the actual ID)
     * @param [options.edgesTo]            IDs of nodes that are already visible (they won't be included in the result, but their adjacent edges will be included in the `edges` field if the other nodes are in `nodes`)
     * @param [options.withDigest]         Whether to include the adjacency digest in the returned nodes
     * @param [options.withDegree]         Whether to include the degree in the returned nodes
     * @param [options.readableCategories] Exclusive list of node categories to restrict the result (used for the node degree)
     * @param [options.readableTypes]      Exclusive list of edge types to restrict the result (used for the node degree, the edge digest and the mutual edges)
     */
    getNode(options) {
        return this.withSource(options.sourceKey, false, source => {
            const currentDate = Date.now();
            return source.graph
                .getNodesByID(_.defaults({ ids: [options.id] }, options))
                .get(0)
                .then(async (node) => {
                const { nodes: publicNodes } = await this.normalizeNodesAndEdges(source, { nodes: [node] }, currentDate);
                if (Utils.noValue(options.edgesTo)) {
                    return {
                        nodes: publicNodes,
                        edges: []
                    };
                }
                return this.getMutualEdges(options.sourceKey, [node.id], {
                    otherNodeIds: options.edgesTo,
                    edgeTypes: options.readableTypes
                }).then(edges => {
                    return {
                        nodes: publicNodes,
                        edges: edges
                    };
                });
            });
        });
    }
    /**
     * Get a list of nodes by ID.
     *
     * @param options
     * @param options.ids                  IDs of the nodes
     * @param options.sourceKey            Key of the data-source
     * @param [options.alternativeId]      The property to match `options.ids` on (instead of the actual IDs)
     * @param [options.ignoreMissing]      Whether to fail if there are missing nodes
     * @param [options.withDigest]         Whether to include the adjacency digest in the returned nodes
     * @param [options.withDegree]         Whether to include the degree in the returned nodes
     * @param [options.readableCategories] Exclusive list of node categories to restrict the result (used for the node degree)
     * @param [options.readableTypes]      Exclusive list of edge types to restrict the result (used for the node degree and the edge digest)
     */
    getNodesByID(options) {
        return this.withSource(options.sourceKey, false, source => {
            const currentDate = Date.now();
            return source.graph.getNodesByID(options).then(async (nodes) => {
                const { nodes: publicNodes } = await this.normalizeNodesAndEdges(source, { nodes: nodes }, currentDate);
                // we ensure that the order on which nodes are returned is the same as they were asked
                return DataService.orderItems(options.ids, publicNodes, options.alternativeId);
            });
        });
    }
    /**
     * Get a list of edges by ID.
     *
     * @param options
     * @param options.ids             IDs of the nodes
     * @param options.sourceKey       Key of the data-source
     * @param [options.alternativeId] The property to match `options.ids` on (instead of the actual IDs)
     * @param [options.ignoreMissing] Whether to fail if there are missing nodes
     */
    getEdgesByID(options) {
        return this.withSource(options.sourceKey, false, source => {
            const currentDate = Date.now();
            return source.graph.getEdgesByID(options).then(async (edges) => {
                const { edges: publicEdges } = await this.normalizeNodesAndEdges(source, { edges: edges }, currentDate);
                // we ensure that the order on which edges are returned is the same as they were asked
                return DataService.orderItems(options.ids, publicEdges, options.alternativeId);
            });
        });
    }
    /**
     * Get all the adjacent nodes and edges to one or more source nodes (`nodeIds`).
     * A subgraph made of the items that matched the expand query and the edges between them is returned.
     *
     * @param nodeIds                      IDs of the nodes to retrieve the neighbors for
     * @param options
     * @param [options.limit]              Maximum number of returned nodes
     * @param [options.limitType]          Order direction used to limit the result ('id', 'lowestDegree' or 'highestDegree')
     * @param [options.nodeCategories]     Exclusive list of node categories to restrict the result (used for the expand)
     * @param [options.edgeTypes]          Exclusive list of edge types to restrict the result (used for the expand)
     * @param [options.edgesTo]            IDs of nodes that are already visible (they won't be included in the result, but their adjacent edges will be included in the `edges` field if the other nodes are in `nodes`)
     * @param [options.withDigest]         Whether to include the adjacency digest in the returned nodes
     * @param [options.withDegree]         Whether to include the degree in the returned nodes
     * @param [options.readableCategories] Exclusive list of node categories to restrict the result (used for the node degree and the expand)
     * @param [options.readableTypes]      Exclusive list of edge types to restrict the result (used for the node degree, the edge digest, the mutual edges and the expand)
     * @param sourceKey                    Key of the data-source
     */
    getAdjacentNodes(nodeIds, options, sourceKey) {
        return this.withSource(sourceKey, false, source => {
            const currentDate = Date.now();
            let ignoredNodeIds = nodeIds;
            if (Utils.hasValue(options.edgesTo)) {
                ignoredNodeIds = _.uniq(ignoredNodeIds.concat(options.edgesTo));
            }
            return source.graph
                .getAdjacentNodes(nodeIds, _.defaults({ ignoredNodeIds: ignoredNodeIds }, options))
                .then(async (nodes) => {
                const { nodes: publicNodes } = await this.normalizeNodesAndEdges(source, { nodes: nodes }, currentDate);
                // S := source nodes
                // N := neighbors nodes
                // V := visible nodes
                //
                // Our response will be made of every node in N
                // with edges of any type in: N-S, N-N, N-V
                // and with edges in: S-V and S-S
                //   - with type in `edgeTypes`
                //   - if S or V have category in `nodeCategories`
                //
                // The following query works by getting all the edges between S+N and S+N+V
                const neighborNodeIds = _.map(nodes, 'id');
                // TODO #1407 get edges in parallel
                // N-N, N-S, N-V
                return this.getMutualEdges(sourceKey, neighborNodeIds, {
                    otherNodeIds: ignoredNodeIds,
                    betweenFirstSet: true,
                    edgeTypes: options.readableTypes
                }).then(neighborsEdges => {
                    // S-V and S-S
                    return this.getMutualEdges(sourceKey, nodeIds, {
                        otherNodeIds: ignoredNodeIds,
                        edgeTypes: options.edgeTypes,
                        nodeCategories: options.nodeCategories
                    }).then(SSandSVEdges => {
                        return {
                            nodes: publicNodes,
                            edges: neighborsEdges.concat(SSandSVEdges)
                        };
                    });
                });
            });
        });
    }
    /**
     * Get the edges between two set of nodes.
     *
     * @param sourceKey                 Key of the data-source
     * @param nodeIds                   IDs of the first set of nodes
     * @param options
     * @param [options.otherNodeIds]    IDs of the second set of nodes
     * @param [options.betweenFirstSet] Whether to include also the edges between the nodes in the first set
     * @param [options.edgeTypes]       Exclusive list of edge types to restrict the result
     * @param [options.nodeCategories]  Exclusive list of node categories (of nodes in `otherNodeIds`) to restrict the result
     */
    getMutualEdges(sourceKey, nodeIds, options) {
        const currentDate = Date.now();
        let allOtherNodeIds = [];
        if (options.betweenFirstSet) {
            allOtherNodeIds = allOtherNodeIds.concat(nodeIds);
        }
        if (Utils.hasValue(options.otherNodeIds)) {
            allOtherNodeIds = _.union(allOtherNodeIds, options.otherNodeIds);
        }
        return this.withSource(sourceKey, false, source => {
            return source.graph
                .getMutualEdges(nodeIds, allOtherNodeIds, {
                edgeTypes: options.edgeTypes,
                nodeCategories: options.nodeCategories
            })
                .then(async (edges) => {
                const { edges: publicEdges } = await this.normalizeNodesAndEdges(source, { edges: edges }, currentDate);
                return publicEdges;
            });
        });
    }
    /**
     * Provide a neighborhood edge digest for a specific node.
     *
     * @param sourceKey Key of the data-source
     * @param nodeId    ID of the node
     */
    getEdgeDigest(sourceKey, nodeId) {
        return this.withSource(sourceKey, false, source => {
            return source.graph.getEdgeDigest(nodeId, {});
        });
    }
    /**
     * Get the digest (the number of adjacent nodes and edges grouped by node categories and edge types)
     * and/or the degree of a given subset of nodes (`ids`).
     * You can't get aggregated statistics of a subset of nodes containing one or more supernodes.
     * To get the statistics of a supernode invoke the API with only its node ID.
     *
     * @param ids                          IDs of the nodes to retrieve the statistics for
     * @param sourceKey                    Key of the data-source
     * @param options
     * @param [options.withDigest]         Whether to include the adjacency digest in the returned nodes
     * @param [options.withDegree]         Whether to include the degree in the returned nodes
     * @param [options.readableCategories] Exclusive list of node categories to restrict the result
     * @param [options.readableTypes]      Exclusive list of edge types to restrict the result
     */
    // TODO 2.6.0 getStatistics does not fail in node does not exists
    getStatistics(ids, sourceKey, options) {
        return this.withSource(sourceKey, false, source => {
            source.graph.checkNodeIds('ids', ids, 1);
            if (ids.length === 1) {
                const [id] = ids;
                return source.graph.getStatistics([id], options).then(statisticsResults => {
                    return statisticsResults.get(id);
                });
            }
            const result = {};
            return source.graph
                .isSuperNode(ids)
                .then(isSuperNodeResult => {
                const superNodes = ids.filter(id => isSuperNodeResult.get(id));
                if (superNodes.length > 0) {
                    throw Errors.business('invalid_parameter', "You can't get aggregated statistics of a subset of nodes " +
                        'containing one or more supernodes.');
                }
                if (options.withDigest) {
                    return source.graph.getAdjacencyDigest(ids).then(digest => {
                        result.digest = digest;
                    });
                }
                return;
            })
                .then(() => {
                if (options.withDegree) {
                    return source.graph
                        .getNodeDegree(ids, {
                        readableCategories: options.readableCategories,
                        readableTypes: options.readableTypes
                    })
                        .then(degree => {
                        result.degree = degree;
                    });
                }
                return;
            })
                .return(result);
        });
    }
    /**
     * Throw a business error if `lastChangedDate` is after `readDate`.
     */
    checkEditConflict(type, lastChangeDate, readDate) {
        if (Utils.noValue(lastChangeDate) || Utils.noValue(readDate)) {
            return;
        }
        if (lastChangeDate > readDate) {
            throw Errors.business('edit_conflict', `${type} edit conflict. Changed on ${new Date(lastChangeDate)}`);
        }
    }
    /**
     * Delete a node and its adjacent edges from the graph.
     *
     * @param nodeId    ID of the node to delete
     * @param sourceKey Key of the data-source
     */
    deleteNode(nodeId, sourceKey) {
        return this.withSource(sourceKey, true, source => {
            // 1) check that the node exists
            return source.graph
                .getNodesByID({ ids: [nodeId] })
                .then(nodes => {
                // 2) delete the node
                return source.graph.deleteNode(nodeId);
            })
                .then(() => source.index.deleteEntry(nodeId, 'node'))
                .return(undefined);
        });
    }
    /**
     * Get all the nodes and edges matching the given graph query.
     */
    async runGraphQueryByContent(params) {
        return this.runGraphQuery(params);
    }
    /**
     * Get all the nodes and edges matching the given graph query.
     *
     * Invoked by both runGraphQueryByContent and runGraphQueryById.
     */
    async runGraphQuery(params) {
        let timeout;
        const { nodeCategories } = await this.getSimpleSchema({ sourceKey: params.sourceKey });
        return this.withSource(params.sourceKey, false, source => {
            let queries = [params.query];
            if (Utils.hasValue(params.templateData)) {
                const templateFields = this.templateParser.parse(params.query, nodeCategories, true);
                const modifiedQueries = this.templateParser.generateRawQueries(params.query, params.templateData, templateFields, source.graph.quote.bind(source.graph));
                queries = _.map(modifiedQueries, 'query');
            }
            const maxLimit = Config.get('advanced.rawQueryLimit');
            // set the default value for limit and timeout
            const rawQueryOptions = {
                dialect: params.dialect,
                queries: queries,
                limit: params.limit || maxLimit,
                withDigest: params.withDigest,
                withDegree: params.withDegree,
                readableCategories: params.readableCategories,
                readableTypes: params.readableTypes
            };
            Utils.check.integer('options.limit', rawQueryOptions.limit, 1, maxLimit);
            const maxTimeout = Config.get('advanced.rawQueryTimeout');
            timeout = params.timeout || maxTimeout;
            Utils.check.integer('options.timeout', timeout, 1, maxTimeout);
            const currentDate = Date.now();
            return source.graph
                .rawQuery(rawQueryOptions, true)
                .then(readableStream => {
                return Utils.mergeReadable(readableStream, timeout);
            })
                .then(async (merged) => {
                if (merged.timeout) {
                    Log.warn(`Raw Query "${params.query}" timed out after ${timeout} ms.`);
                    throw new GraphRequestTimeout_1.GraphRequestTimeout(GraphRequestTimeout_1.Vendor.LINKURIOUS);
                }
                let truncatedByLimit = false;
                if (merged.result.length === rawQueryOptions.limit) {
                    truncatedByLimit = true;
                }
                let truncatedByAccess = false;
                // filter by access rights and by schema
                let normalizedResult = await Promise.all(merged.result.map(async (subGraph) => {
                    let filteredSubGraph;
                    if (Utils.hasValue(params.filterSubGraph)) {
                        filteredSubGraph = await params.filterSubGraph(subGraph);
                    }
                    else {
                        filteredSubGraph = subGraph;
                    }
                    if (Utils.noValue(filteredSubGraph)) {
                        // subgraph filtered out by access rights
                        return;
                    }
                    const normalizedSubGraph = await this.normalizeNodesAndEdges(source, { nodes: filteredSubGraph.nodes, edges: filteredSubGraph.edges }, currentDate);
                    if (normalizedSubGraph.isSchemaFiltered) {
                        // subgraph filtered out by schema
                        return;
                    }
                    return normalizedSubGraph;
                }));
                normalizedResult = _.filter(normalizedResult, r => Utils.hasValue(r));
                if (normalizedResult.length !== merged.result.length) {
                    // truncatedByAccess is set for both truncated by access right and truncated by schema
                    truncatedByAccess = true;
                }
                const publicNodes = _.uniqBy(_.flatMap(normalizedResult, 'nodes'), 'id');
                const publicEdges = _.uniqBy(_.flatMap(normalizedResult, 'edges'), 'id');
                const nodeIds = _.map(publicNodes, 'id');
                // we want the edges between the resulting nodes only if no edge was returned by the query itself
                let otherNodeIds = publicEdges.length > 0 ? [] : Utils.clone(nodeIds);
                if (Utils.hasValue(params.edgesTo)) {
                    // plus the edges between these nodes and `edgesTo`
                    otherNodeIds = otherNodeIds.concat(params.edgesTo);
                }
                return this.getMutualEdges(params.sourceKey, nodeIds, {
                    otherNodeIds: otherNodeIds,
                    edgeTypes: params.readableTypes,
                    nodeCategories: params.readableCategories
                }).then(mutualEdges => {
                    return {
                        truncatedByLimit: truncatedByLimit,
                        truncatedByAccess: truncatedByAccess,
                        nodes: publicNodes,
                        edges: _.unionBy(publicEdges, mutualEdges, 'id')
                    };
                });
            });
        });
    }
    /**
     * Get all the nodes and edges matching the given graph query.
     * An array of subgraphs, one for each subgraph matching the graph query, is returned.
     *
     * @param params
     * @param params.sourceKey           Key of the data-source
     * @param params.query               The graph query
     * @param [params.columns]           Columns among the returned values of the query to return as scalar values
     * @param params.columns.type        Type of the column
     * @param params.columns.columnName  Name of the column in the query
     * @param [params.dialect]           Dialect of the graph query (defaults to the first supported dialect of the data-source)
     * @param [params.limit]             Maximum number of matched subgraphs
     * @param [params.timeout]           Maximum execution time in milliseconds
     */
    alertPreview(params) {
        Utils.check.exist('options', params);
        let timeout;
        return this.withSource(params.sourceKey, false, source => {
            const maxLimit = Config.get('alerts.maxMatchesLimit');
            // set the default value for limit and timeout
            const rawQueryOptions = {
                dialect: params.dialect,
                queries: [params.query],
                limit: params.limit || maxLimit
            };
            Utils.check.integer('options.limit', rawQueryOptions.limit, 1, maxLimit);
            const maxTimeout = Config.get('alerts.maxRuntimeLimit');
            timeout = params.timeout || maxTimeout;
            Utils.check.integer('options.timeout', timeout, 1, maxTimeout);
            const currentDate = Date.now();
            return source.graph
                .rawQuery(rawQueryOptions, true)
                .then((readableStream) => {
                return Utils.mergeReadable(readableStream, timeout);
            })
                .then((mergedStream) => {
                if (mergedStream.timeout) {
                    Log.warn(`Query "${params.query}" timed out after ${timeout} ms.`);
                }
                const matchesToCreate = [];
                for (const match of mergedStream.result) {
                    const matchAttributes = {
                        nodes: match.nodes,
                        edges: match.edges,
                        columns: []
                    };
                    if (Utils.hasValue(params.columns)) {
                        params.columns.forEach(column => {
                            const scalarValue = match.properties[column.columnName];
                            // we apply the same rule as in createMatchesInBulk
                            if ((column.type === 'number' && typeof scalarValue === 'number') ||
                                (column.type === 'string' && Utils.isNEString(scalarValue))) {
                                matchAttributes.columns.push(scalarValue);
                            }
                            else {
                                // else we silently ignore that the scalar value is undefined or of an incorrect type
                                matchAttributes.columns.push(null);
                            }
                        });
                    }
                    matchesToCreate.push(matchAttributes);
                }
                return matchesToCreate;
            })
                .map(async (match) => {
                const { nodes, edges } = await this.normalizeNodesAndEdges(source, match, currentDate);
                return {
                    nodes: nodes,
                    edges: edges,
                    columns: _.compact(match.columns)
                };
            });
        }).then(results => ({ results: results }));
    }
    /**
     * Get all the nodes and edges matching the given graph query.
     * A stream of subgraphs, one for each subgraph matching the graph query, is returned.
     *
     * @param options
     * @param options.sourceKey Key of the data-source
     * @param options.query     The graph query
     * @param [options.dialect] Dialect of the graph query (defaults to the first supported dialect of the data-source)
     * @param [options.limit]   Maximum number of matched subgraphs
     */
    alertQuery(options) {
        Utils.check.exist('options', options);
        return this.withSource(options.sourceKey, false, source => {
            // TODO Configuration should return a default value for optional fields
            const maxLimit = Config.get('alerts.maxMatchesLimit', 5000);
            // set the default value for limit
            const rawQueryOptions = {
                dialect: options.dialect,
                queries: [options.query],
                limit: options.limit || maxLimit
            };
            Utils.check.integer('options.limit', rawQueryOptions.limit, 1, maxLimit);
            // set populated to false, we don't need the data to create matches
            return source.graph.rawQuery(rawQueryOptions, false);
        });
    }
    /**
     * Get the number of edges in the graph.
     *
     * @param sourceKey Key of the data-source
     */
    getEdgeCount(sourceKey) {
        return this.withSource(sourceKey, false, source => {
            const stateCode = source.getState().code;
            // if we are indexing, the count is cached, use it
            if (stateCode === 'indexing' && Utils.hasValue(source.edgeCountCache)) {
                return source.edgeCountCache;
            }
            // if the indexation is done (state=ready) and the index can count, use the index
            if (stateCode === 'ready' && source.index.features.canCount) {
                return source.index.getSize('edge');
            }
            // if the graph can count, use the graph
            if (source.graph.features.canCount) {
                return source.graph.getEdgeCount(
                // approximate if indexation is ongoing
                // don't approximate in test mode
                stateCode === 'indexing' && !LKE.isTestMode());
            }
            // if we can't count, we soft-fail with the value 0
            return Bluebird.resolve(0);
        });
    }
    /**
     * Get an edge of the graph.
     * A subgraph made of the edge and its extremities is returned.
     *
     * @param options
     * @param options.sourceKey            Key of the data-source
     * @param options.id                   ID of the edge
     * @param [options.alternativeId]      The property to match `id` on (instead of the actual ID)
     * @param [options.edgesTo]            IDs of nodes that are already visible (they won't be included in the result, but their adjacent edges will be included in the `edges` field if the other nodes are in `nodes`)
     * @param [options.withDigest]         Whether to include the adjacency digest in the returned nodes
     * @param [options.withDegree]         Whether to include the degree in the returned nodes
     * @param [options.readableCategories] Exclusive list of node categories to restrict the result (used for the node degree)
     * @param [options.readableTypes]      Exclusive list of edge types to restrict the result (used for the node degree, the edge digest and the mutual edges)
     */
    getEdge(options) {
        return this.withSource(options.sourceKey, false, source => {
            const currentDate = Date.now();
            return source.graph
                .getEdgesByID(_.defaults({ ids: [options.id] }, options))
                .get(0)
                .then(edge => {
                // retrieve the extremities of the edge
                return source.graph
                    .getNodesByID({
                    ids: [edge.source, edge.target],
                    withDigest: options.withDigest,
                    withDegree: options.withDegree,
                    readableCategories: options.readableCategories,
                    readableTypes: options.readableTypes
                })
                    .then(async (nodes) => {
                    // add the read timestamp to the edge and its extremities
                    const { nodes: publicNodes, edges: publicEdges } = await this.normalizeNodesAndEdges(source, { nodes: nodes, edges: [edge] }, currentDate);
                    return this.getMutualEdges(options.sourceKey, _.map(nodes, 'id'), {
                        otherNodeIds: options.edgesTo,
                        betweenFirstSet: true,
                        edgeTypes: options.readableTypes
                    }).then(edges => {
                        // return a subgraph made of the two extremities, the edge
                        // and all the edges between the extremities and `edgesTo`
                        return {
                            nodes: publicNodes,
                            // the edge with ID equal to `options.id` comes first
                            edges: _.uniqBy(publicEdges.concat(edges), 'id')
                        };
                    });
                });
            });
        });
    }
    async updateSchema(sourceKey, entityType, labels, data) {
        const builder = new builder_1.SchemaBuilder().addItem(labels, data);
        await GraphSchemaService.updateSchema(sourceKey, entityType, builder);
    }
    /**
     * Delete an edge from the graph.
     *
     * @param edgeId    ID of the edge to delete
     * @param sourceKey Key of the data-source
     */
    deleteEdge(edgeId, sourceKey) {
        return this.withSource(sourceKey, true, source => {
            // 1) check that the edge exists
            return source.graph
                .getEdgesByID({ ids: [edgeId] })
                .then(edges => {
                // 2) delete the edge
                return source.graph.deleteEdge(edgeId);
            })
                .then(() => source.index.deleteEntry(edgeId, 'edge'))
                .return(undefined);
        });
    }
    /**
     * Connect all data-sources.
     */
    connectSources() {
        let connectedDataSources = 0;
        return Bluebird.each(this.sources, source => {
            if (source.destroyed) {
                // skip the source if it was deleted concurrently (while iterating)
                return;
            }
            return source.connect(true).then(() => {
                if (source.isConnected()) {
                    connectedDataSources++;
                }
            });
        }).then(() => {
            LKE.getStateMachine().set('DataService', 'up', `${connectedDataSources}/${this.sources.length} data-sources connected.`);
        });
    }
    /**
     * Disconnect all data-sources.
     */
    disconnectAll() {
        this.sources.forEach(source => source.disconnect());
    }
    /**
     * @param [isStartup] Whether this is called at startup
     */
    indexSources(isStartup = false) {
        return Bluebird.each(this.sources, source => {
            if (source.destroyed) {
                // skip the source if it was deleted concurrently (while iterating)
                return;
            }
            if (!source.isConnected()) {
                return Bluebird.resolve();
            }
            // skip index if forceReindex is not true OR index is not configured
            if (isStartup && (source.needConfig() || source.config.index.forceReindex !== true)) {
                return Bluebird.resolve();
            }
            return this.indexSource(source.getSourceKey()).catch(error => {
                Log.error('Indexation of data-source #' + source.sourceId + ' failed.', error);
            });
        }).return();
    }
    /**
     * Get the source key of the currently indexed data-source.
     */
    getIndexedSource() {
        return this.indexedSource;
    }
    /**
     * Check that the given graph query is syntactically correct. Parse the query if it's a template.
     */
    async checkGraphQuery(params) {
        return this.withSource(params.sourceKey, false, async (source) => {
            let graphInput;
            let templateFields;
            let type = graphQueryParams_1.GraphQueryType.STATIC;
            let query = params.query;
            let correctionTable = [];
            if (umd_1.QueryTemplateParser.isTemplate(query)) {
                // 1) parse the query if it's a template
                type = graphQueryParams_1.GraphQueryType.TEMPLATE;
                const schema = await source.graph.getSimpleSchema();
                templateFields = this.templateParser.parse(query, schema.nodeCategories);
                graphInput = umd_1.QueryTemplateParser.getInputType(templateFields);
                const templateData = source.graph.getDummyTemplateData(templateFields);
                const quote = source.graph.quote.bind(source.graph);
                const queries = this.templateParser.generateRawQueries(query, templateData, templateFields, quote);
                // We check the syntax of only the first query
                // because the dummy template data will only generate one query
                query = queries[0].query;
                correctionTable = queries[0].correctionTable;
            }
            // 2) check if the query is syntactically correct and find out if it's a write query or not
            const write = source.graph.checkQuery(query);
            try {
                // 3) execute a dry run of the query
                await source.graph.dryRun(query);
            }
            catch (error) {
                if (error.data && error.data.offset) {
                    error.data.offset = umd_1.QueryTemplateParser.correctOffset(error.data.offset, correctionTable);
                }
                throw error;
            }
            return {
                write: write,
                graphInput: graphInput,
                templateFields: templateFields,
                type: type
            };
        });
    }
    /**
     * Add `defaultStyles` and `defaultCaptions` to all dataSourceStates.
     *
     * Since LKE v2.5.0, the styles format and palette have been changed and the default styles and
     * captions have been moved from the configuration file to the data-source states so that they
     * can be configured per data-source.
     *
     * The migration steps are:
     * - Save `palette` , `defaultStyles`, `defaultCaption` from the configuration to the source state
     * - Remove the `palette` from the configuration
     * - Remove the `defaultStyles` from the configuration
     * - Remove the `defaultCaptions` from the configuration
     */
    migrateStyles() {
        // legacy configuration: defaultStyles, defaultCaptions and palette are removed in LKE v2.5.0
        const defaultStyles = Config.get('defaultStyles');
        const defaultCaptions = Config.get('defaultCaptions');
        const palette = Config.get('palette');
        if (Utils.noValue(defaultStyles) || Utils.noValue(defaultCaptions) || Utils.noValue(palette)) {
            // we cannot perform the migration without defaultStyles, defaultCaptions, or the palette
            // from the old configuration so we skip the migration
            // but these fields can also be empty if the config file was deleted before migration
            // so we add defaultStyles and captions to the source states not migrated
            return DbModels.dataSourceState
                .update({
                defaultCaptions: DesignUtils.DEFAULT_CAPTIONS,
                defaultStyles: DesignUtils.DEFAULT_STYLES
            }, { where: { defaultStyles: { $eq: null } } })
                .return();
        }
        // 1) save `defaultStyles`, `defaultCaption`, `palette` in the source state
        // the migration will be completed when the source is connected
        return DbModels.dataSourceState
            .update({
            defaultStyles: {
                'PreV2.5.0Config': true,
                defaultStyles: defaultStyles,
                defaultCaptions: defaultCaptions,
                palette: palette
            }
        }, { where: { defaultStyles: { $eq: null } } })
            .then(() => {
            // 2) delete config.palette
            Config.set('palette', undefined);
            // 3) delete config.defaultStyles
            Config.set('defaultStyles', undefined);
            // 4) delete config.defaultCaptions
            Config.set('defaultCaptions', undefined);
        })
            .return();
    }
    /**
     * Move hidden properties from the data-source to the schema.
     *
     * @backward-compatibility Since LKE v2.8 all hidden properties are stored in the schema
     */
    async migrateHiddenProperties() {
        const everySource = await DbModels.dataSourceState.findAll();
        for (const source of everySource) {
            const nodeProperties = source.hiddenNodeProperties;
            if (Utils.hasValue(nodeProperties) && nodeProperties.length) {
                Log.info(`Moving ${nodeProperties.length} hidden node properties`, `from data-source "${source.key}" to the graph schema`, JSON.stringify(nodeProperties));
                await GraphSchemaService.saveHiddenProperties(source.key, rest_client_1.EntityType.NODE, nodeProperties);
                // remove hidden node properties from the data source
                source.hiddenNodeProperties = null;
                await source.save();
            }
            const edgeProperties = source.hiddenEdgeProperties;
            if (Utils.hasValue(edgeProperties) && edgeProperties.length) {
                Log.info(`Moving ${edgeProperties.length} hidden edge properties`, `from data-source "${source.key}" to the graph schema`, JSON.stringify(edgeProperties));
                await GraphSchemaService.saveHiddenProperties(source.key, rest_client_1.EntityType.EDGE, edgeProperties);
                // remove hidden edge properties from the data source
                source.hiddenEdgeProperties = null;
                await source.save();
            }
        }
    }
    /**
     * Sort nodes or edges in the required order.
     *
     * @param order         Sorted item IDs
     * @param items         Nodes or edges
     * @param alternativeId
     */
    static orderItems(order, items, alternativeId) {
        const byId = Utils.hasValue(alternativeId)
            ? item => [item.data[alternativeId], item]
            : item => [item.id, item];
        const index = new Map(items.map(byId));
        return _.compact(_.map(order, id => index.get(id)));
    }
}
module.exports = new DataService();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvZGF0YS9pbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7O0dBS0c7QUFFSCxjQUFjO0FBRWQseURBc0JpQztBQUNqQyxxQ0FBcUM7QUFDckMsK0NBQTJGO0FBQzNGLDRCQUE0QjtBQVU1QixpREFBNEM7QUFDNUMsaUZBQW9GO0FBQ3BGLHlGQUFvRjtBQUNwRix1RkFBa0Y7QUFRbEYsK0VBQXdFO0FBaUJ4RSxvREFBcUQ7QUFDckQsZ0NBQWlDO0FBRWpDLE1BQU0sVUFBVSxHQUFHLE9BQU8sQ0FBQyxjQUFjLENBQW9CLENBQUM7QUFFOUQsTUFBTSxXQUFXLEdBQUcsT0FBTyxDQUFDLHlCQUF5QixDQUFnQixDQUFDO0FBRXRFLE1BQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDdEMsTUFBTSxRQUFRLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDLE1BQU0sQ0FBQztBQUN2QyxNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sa0JBQWtCLEdBQUcsR0FBRyxDQUFDLGNBQWMsRUFBRSxDQUFDO0FBQ2hELE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUU3QixNQUFNLGFBQWEsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUMsQ0FBQztBQUV4RCxNQUFNLFdBQVc7SUFhZjtRQVpPLFlBQU8sR0FBaUIsRUFBRSxDQUFDO1FBRWxDLHFEQUFxRDtRQUM3QyxrQkFBYSxHQUFrQixJQUFJLENBQUM7UUFFNUMsbUNBQW1DO1FBQzNCLGdCQUFXLEdBQThCLEVBQUUsQ0FBQztRQUU1QyxvQkFBZSxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDckMsb0JBQWUsR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBSTNDLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO1FBQzVCLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUNuQixJQUFJLENBQUMsY0FBYyxHQUFHLElBQUkseUJBQW1CLENBQzNDLENBQUMsaUJBQWlCLEVBQUUsU0FBUyxFQUFFLEVBQUU7WUFDL0IsTUFBTSxJQUFJLCtDQUFzQixDQUFDLGlCQUFpQixFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBQ2pFLENBQUMsRUFDRCxVQUFVLENBQUMsRUFBRTtZQUNYLE1BQU0sSUFBSSxTQUFHLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDNUIsQ0FBQyxDQUNGLENBQUM7SUFDSixDQUFDO0lBRUQ7O09BRUc7SUFDSyxvQkFBb0I7UUFDMUIsTUFBTSxhQUFhLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQStCLENBQUM7UUFFOUUsb0NBQW9DO1FBQ3BDLE1BQU0scUJBQXFCLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxhQUFhLEVBQUUsWUFBWSxDQUFDLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUU3RixJQUFJLGFBQWEsQ0FBQyxNQUFNLEtBQUsscUJBQXFCLENBQUMsTUFBTSxFQUFFO1lBQ3pELG9CQUFvQjtZQUNwQixPQUFPO1NBQ1I7UUFFRCx1RUFBdUU7UUFDdkUsTUFBTSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUscUJBQXFCLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBRU8sV0FBVztRQUNqQixNQUFNLE9BQU8sR0FBaUIsRUFBRSxDQUFDO1FBQ2hDLE1BQU0sQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFlLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBZSxFQUFFLFFBQWdCLEVBQUUsRUFBRTtZQUNyRixPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksVUFBVSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQy9DLENBQUMsQ0FBQyxDQUFDO1FBQ0gsSUFBSSxPQUFPLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUN4QixNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQUMsd0JBQXdCLEVBQUUsMENBQTBDLENBQUMsQ0FBQztTQUM3RjtRQUNELElBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO0lBQ3pCLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ssVUFBVSxDQUNoQixzQkFBdUMsRUFDdkMsU0FBa0I7SUFDbEIsb0VBQW9FO0lBQ3BFLE1BS29CO1FBRXBCLE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsc0JBQXNCLENBQUMsQ0FBQztRQUMxRCxJQUFJLFNBQVMsSUFBSSxNQUFNLENBQUMsVUFBVSxFQUFFLEVBQUU7WUFDcEMsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDLGlCQUFpQixFQUFFLHVDQUF1QyxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQ3hGO1FBQ0QsSUFBSSxTQUFTLElBQUksYUFBYSxFQUFFO1lBQzlCLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsRUFBRSxrQ0FBa0MsRUFBRSxJQUFJLENBQUMsQ0FBQztTQUNsRjtRQUNELE9BQU8sUUFBUSxDQUFDLE9BQU8sRUFBRTthQUN0QixJQUFJLENBQUMsR0FBRyxFQUFFLENBQ1QsTUFBTSxDQUFDLE1BR04sQ0FBQyxDQUNIO2FBQ0EsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQ1gsSUFBSSxHQUFHLENBQUMsR0FBRyxLQUFLLHdCQUF3QixJQUFJLE1BQU0sQ0FBQyxXQUFXLEVBQUUsRUFBRTtnQkFDaEUsR0FBRyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0JBQ25ELE1BQU0sQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO2dCQUM5QixNQUFNLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQztnQkFDOUIsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN0QjtZQUNELE9BQU8sUUFBUSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUM5QixDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0ksYUFBYSxDQUFDLHNCQUF1QztRQUMxRCw0REFBNEQ7UUFDNUQsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLHNCQUFzQixDQUFDLEVBQUU7WUFDekMsTUFBTSxNQUFNLENBQUMsU0FBUyxDQUNwQix3QkFBd0IsRUFDeEIsNkNBQTZDLENBQzlDLENBQUM7U0FDSDtRQUNELElBQUksQ0FBQyxDQUFDO1FBQ04sSUFBSSxNQUFNLENBQUM7UUFFWCw4QkFBOEI7UUFDOUIsSUFBSSxPQUFPLHNCQUFzQixLQUFLLFFBQVEsRUFBRTtZQUM5QyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO2dCQUN4QyxNQUFNLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDekIsSUFBSSxNQUFNLENBQUMsUUFBUSxLQUFLLHNCQUFzQixJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRTtvQkFDbkUsT0FBTyxNQUE2QixDQUFDO2lCQUN0QzthQUNGO1lBQ0QsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUNuQix3QkFBd0IsRUFDeEIsZUFBZSxHQUFHLHNCQUFzQixHQUFHLGdCQUFnQixDQUM1RCxDQUFDO1NBQ0g7UUFFRCx1QkFBdUI7UUFDdkIsSUFBSSxPQUFPLHNCQUFzQixLQUFLLFFBQVEsRUFBRTtZQUM5QyxNQUFNLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLDhCQUE4QixDQUFDLENBQUM7U0FDL0Q7UUFFRCxhQUFhO1FBQ2IsTUFBTSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsc0JBQXNCLENBQUMsQ0FBQztRQUNsRCw2RkFBNkY7UUFDN0YsSUFBSSxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFO1lBQy9CLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFFLEVBQUU7Z0JBQ3pCLE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FDbkIsd0JBQXdCLEVBQ3hCLGVBQWUsR0FBRyxzQkFBc0IsR0FBRyxvQkFBb0IsQ0FDaEUsQ0FBQzthQUNIO1lBQ0QsT0FBTyxNQUE2QixDQUFDO1NBQ3RDO1FBRUQsZUFBZTtRQUNmLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDeEMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxFQUFFLEVBQUU7Z0JBQ2xDLFNBQVM7YUFDVjtZQUNELElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLEVBQUUsS0FBSyxzQkFBc0IsRUFBRTtnQkFDN0QsTUFBTSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3pCLGVBQWU7Z0JBQ2YsSUFBSSxDQUFDLFdBQVcsQ0FBQyxzQkFBc0IsQ0FBQyxHQUFHLE1BQU0sQ0FBQztnQkFDbEQsT0FBTyxNQUE2QixDQUFDO2FBQ3RDO1NBQ0Y7UUFFRCxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQ25CLHdCQUF3QixFQUN4QixlQUFlLEdBQUcsc0JBQXNCLEdBQUcsc0NBQXNDLENBQ2xGLENBQUM7SUFDSixDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNJLGVBQWUsQ0FDcEIsVUFBMEQsRUFBRTtRQUU1RCxNQUFNLEVBQUMsVUFBVSxFQUFFLFlBQVksRUFBQyxHQUFHLE9BQU8sQ0FBQztRQUMzQyxPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQ3JCLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFO1lBQ25CLE1BQU0sS0FBSyxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUMzQixNQUFNLFFBQVEsR0FBb0I7Z0JBQ2hDLFdBQVcsRUFBRSxDQUFDLENBQUMsUUFBUTtnQkFDdkIsU0FBUyxFQUFFLENBQUMsQ0FBQyxXQUFXLEVBQUU7Z0JBQzFCLEtBQUssRUFBRSxLQUFLLENBQUMsS0FBSztnQkFDbEIsUUFBUSxFQUFFLENBQUMsQ0FBQyxRQUFRO2dCQUNwQixHQUFHLEVBQUUsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUk7Z0JBQzlDLElBQUksRUFBRSxDQUFDLENBQUMsY0FBYyxFQUFFO2dCQUN4QixNQUFNLEVBQUUsS0FBSyxDQUFDLE1BQU07Z0JBQ3BCLFFBQVEsRUFBRTtvQkFDUixRQUFRLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLEVBQUU7aUJBQzNCO2dCQUNELEtBQUssRUFBRSxLQUFLLENBQUMsSUFBSTthQUNsQixDQUFDO1lBRUYsSUFBSSxDQUFDLENBQUMsV0FBVyxFQUFFLEVBQUU7Z0JBQ25CLFFBQVEsQ0FBQyxRQUFRLENBQUMsWUFBWSxHQUFHLENBQUMsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxZQUFZLENBQUM7Z0JBRTdELElBQUksVUFBVSxFQUFFO29CQUNkLFFBQVEsQ0FBQyxhQUFhLEdBQUksQ0FBQyxDQUFDLEtBQWlDLENBQUMsYUFBYSxDQUFDO2lCQUM3RTtnQkFDRCxJQUFJLFlBQVksRUFBRTtvQkFDaEIsUUFBUSxDQUFDLGVBQWUsR0FBSSxDQUFDLENBQUMsS0FBaUMsQ0FBQyxlQUFlLENBQUM7aUJBQ2pGO2FBQ0Y7WUFFRCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUMzQixNQUFNLFFBQVEsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDO2dCQUN6QixRQUFRLENBQUMsUUFBUSxDQUFDLGNBQWMsR0FBRztvQkFDakMsSUFBSSxFQUFFLFFBQVEsQ0FBQyxPQUFPLENBQUMsaUJBQXVDO29CQUM5RCxJQUFJLEVBQUUsUUFBUSxDQUFDLE9BQU8sQ0FBQyxpQkFBdUM7aUJBQy9ELENBQUM7Z0JBQ0YsUUFBUSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsR0FBRyxRQUFRLENBQUMsT0FBTyxDQUFDLGdCQUV6QyxDQUFDO2dCQUNkLFFBQVEsQ0FBQyxRQUFRLENBQUMsaUJBQWlCLEdBQUcsUUFBUSxDQUFDLE9BQU8sQ0FBQyxpQkFFMUMsQ0FBQztnQkFDZCxJQUFJLENBQUMsQ0FBQyxXQUFXLEVBQUUsRUFBRTtvQkFDbkIsUUFBUSxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsR0FBRyxRQUFRLENBQUMsaUJBQWlCLENBQUM7aUJBQ2xFO2FBQ0Y7WUFFRCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUMzQixNQUFNLFFBQVEsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDO2dCQUN6QixRQUFRLENBQUMsUUFBUSxDQUFDLGtCQUFrQjtvQkFDbEMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQzthQUM3RTtZQUVELE9BQU8sUUFBUSxDQUFDO1FBQ2xCLENBQUMsQ0FBQyxDQUNILENBQUM7SUFDSixDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNJLGFBQWE7UUFDbEIsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLG1CQUFtQixFQUFFLENBQUM7UUFFekMsb0NBQW9DO1FBQ3BDLE1BQU0saUJBQWlCLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFaEQscUJBQXFCO1FBQ3JCLE9BQU8sUUFBUSxDQUFDLGVBQWU7YUFDNUIsT0FBTyxDQUFDLEVBQUMsS0FBSyxFQUFFLEVBQUUsRUFBQyxDQUFDO2FBQ3BCLEdBQUcsQ0FDRixDQUFDLGtCQUEyQyxFQUFFLEVBQUU7WUFDOUMsTUFBTSxVQUFVLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLEVBQUUsRUFBRTtnQkFDbEQsVUFBVTtnQkFDVixNQUFNO2dCQUNOLE1BQU07Z0JBQ04sYUFBYTtnQkFDYixhQUFhO2dCQUNiLEtBQUs7YUFDTixDQUE2QyxDQUFDO1lBRS9DLDZEQUE2RDtZQUM3RCxNQUFNLE9BQU8sR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLGlCQUFpQixFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsS0FBSyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDMUYsSUFBSSxPQUFPLENBQUMsTUFBTSxFQUFFO2dCQUNsQixVQUFVLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxJQUFJLENBQUM7Z0JBQzlDLFVBQVUsQ0FBQyxXQUFXLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQzthQUM5QztpQkFBTTtnQkFDTCxVQUFVLENBQUMsS0FBSyxHQUFHLFNBQVMsQ0FBQztnQkFDN0IsVUFBVSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7YUFDL0I7WUFFRCxjQUFjO1lBQ2QsTUFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDakQsVUFBVSxDQUFDLElBQUksR0FBRyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDbkMsVUFBVSxDQUFDLElBQUksR0FBRyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDbkMsVUFBVSxDQUFDLE9BQU8sR0FBRyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUN0RCxPQUFPLFVBQVUsQ0FBQyxJQUFJLENBQUM7WUFFdkIsT0FBTyxNQUFNLENBQUMscUJBQXFCLENBQUMsVUFBVSxDQUFDLEdBQWEsRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0JBQzNFLFVBQVUsQ0FBQyxrQkFBa0IsR0FBRyxDQUFDLENBQUM7Z0JBQ2xDLE9BQU8sVUFBNEIsQ0FBQztZQUN0QyxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsRUFDRCxFQUFDLFdBQVcsRUFBRSxDQUFDLEVBQUMsQ0FDakI7YUFDQSxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDbEIsMEVBQTBFO1lBQzFFLE1BQU0sWUFBWSxHQUFxQixpQkFBaUIsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLEVBQUU7Z0JBQ3hFLE1BQU0sUUFBUSxHQUFHLEtBQUssQ0FBQyxlQUFlLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUluRSxDQUFDO2dCQUNGLE9BQU87b0JBQ0wsV0FBVyxFQUFFLFVBQVUsQ0FBQyxRQUFRO29CQUNoQyxJQUFJLEVBQUUsUUFBUSxDQUFDLElBQUk7b0JBQ25CLFdBQVcsRUFBRSxJQUFJO29CQUNqQixXQUFXLEVBQUUsSUFBSTtvQkFDakIsR0FBRyxFQUFFLElBQUk7b0JBQ1QsUUFBUSxFQUFFLElBQUk7b0JBQ2QsSUFBSSxFQUFFLEtBQUssQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7d0JBQzFDLENBQUMsQ0FBRSxVQUFVLENBQUMsTUFBTSxDQUFDLElBQWU7d0JBQ3BDLENBQUMsQ0FBQyxJQUFJO29CQUNSLElBQUksRUFBRSxRQUFRLENBQUMsSUFBSTtvQkFDbkIsS0FBSyxFQUFFLFVBQVUsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxJQUFJO29CQUNqQyxPQUFPLEVBQUUsSUFBSTtvQkFDYixrQkFBa0IsRUFBRSxDQUFDO2lCQUN0QixDQUFDO1lBQ0osQ0FBQyxDQUFDLENBQUM7WUFFSCxPQUFPLFdBQVcsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDMUMsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7T0FVRztJQUNJLFlBQVksQ0FBQyxZQUluQjtRQUNDLEtBQUssQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxZQUFZLEVBQUU7WUFDN0MsT0FBTyxFQUFFO2dCQUNQLFFBQVEsRUFBRSxJQUFJO2dCQUNkLFVBQVUsRUFBRTtvQkFDVixNQUFNLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUM7aUJBQ3pDO2dCQUNELE1BQU0sRUFBRSxXQUFXO2FBQ3BCO1lBQ0QsS0FBSyxFQUFFO2dCQUNMLFFBQVEsRUFBRSxJQUFJO2dCQUNkLFVBQVUsRUFBRTtvQkFDVixNQUFNLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUM7aUJBQ3pDO2dCQUNELE1BQU0sRUFBRSxXQUFXO2FBQ3BCO1lBQ0QsSUFBSSxFQUFFLEVBQUMsSUFBSSxFQUFFLFFBQVEsRUFBQztTQUN2QixDQUFDLENBQUM7UUFFSCxPQUFPLE1BQU0sQ0FBQyxHQUFHLENBQUMsYUFBYSxFQUFFLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUNoRSxNQUFNLFdBQVcsR0FBRyxXQUFXLEdBQUcsQ0FBQyxDQUFDO1lBQ3BDLE1BQU0sTUFBTSxHQUFHLElBQUksVUFBVSxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUNqRCxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUUxQix1RUFBdUU7WUFDdkUsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUVyQixPQUFPLFdBQVcsQ0FBQztRQUNyQixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ksa0JBQWtCLENBQUMsV0FBbUI7UUFDM0MsTUFBTSxNQUFNLEdBQTJCLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxFQUFDLFFBQVEsRUFBRSxXQUFXLEVBQUMsQ0FBQyxDQUFDO1FBRXJGLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDWCxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQ3BCLFdBQVcsRUFDWCx3Q0FBd0MsV0FBVyxpQkFBaUIsRUFDcEUsSUFBSSxDQUNMLENBQUM7U0FDSDtRQUVELElBQUksTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDLElBQUksS0FBSyxTQUFTLEVBQUU7WUFDeEMsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUNwQixzQkFBc0IsRUFDdEIsNENBQTRDLEVBQzVDLElBQUksQ0FDTCxDQUFDO1NBQ0g7UUFFRCx1Q0FBdUM7UUFDdkMsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFDN0IsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUNwQixpQkFBaUIsRUFDakIsZ0RBQWdELEVBQ2hELElBQUksQ0FDTCxDQUFDO1NBQ0g7UUFFRCx5Q0FBeUM7UUFDekMsTUFBTSxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBRWpCLDBDQUEwQztRQUMxQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsRUFBQyxRQUFRLEVBQUUsV0FBVyxFQUFDLENBQUMsQ0FBQztRQUVoRCxvREFBb0Q7UUFDcEQsNkZBQTZGO1FBQzdGLE9BQU8sTUFBTSxDQUFDLEdBQUcsQ0FBQyxlQUFlLFdBQVcsVUFBVSxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ2hFLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSSxnQkFBZ0IsQ0FDckIsZ0JBQXdCLEVBQ3hCLGNBQXVCO1FBWXZCLE1BQU0sTUFBTSxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLEtBQUssZ0JBQWdCLENBQUMsQ0FBQztRQUVwRixNQUFNLG1CQUFtQixHQUFHLE1BQU07WUFDaEMsQ0FBQyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDO1lBQzFDLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUM7UUFFdkIsb0ZBQW9GO1FBQ3BGLElBQUksa0JBQTJDLENBQUM7UUFFaEQsT0FBTyxtQkFBbUI7YUFDdkIsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNULGdEQUFnRDtZQUNoRCxNQUFNLFVBQVUsR0FBRyxDQUFDLGdCQUFnQixDQUFDLENBQUM7WUFDdEMsSUFBSSxjQUFjLEtBQUssU0FBUyxFQUFFO2dCQUNoQyxVQUFVLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO2FBQ2pDO1lBQ0QsT0FBTyxRQUFRLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxFQUFDLEtBQUssRUFBRSxFQUFDLEdBQUcsRUFBRSxVQUFVLEVBQUMsRUFBQyxDQUFDLENBQUM7UUFDdEUsQ0FBQyxDQUFDO2FBQ0QsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFO1lBQ25CLCtDQUErQztZQUMvQyxNQUFNLHdCQUF3QixHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLEVBQUMsR0FBRyxFQUFFLGdCQUFnQixFQUFDLENBQUMsQ0FBQztZQUMvRSxJQUFJLENBQUMsd0JBQXdCLEVBQUU7Z0JBQzdCLE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FDbkIsV0FBVyxFQUNYLDhCQUE4QixnQkFBZ0IsZUFBZSxDQUM5RCxDQUFDO2FBQ0g7WUFDRCxrQkFBa0IsR0FBRyx3QkFBd0IsQ0FBQztZQUU5QywrREFBK0Q7WUFDL0QsTUFBTSxzQkFBc0IsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxFQUFDLEdBQUcsRUFBRSxjQUFjLEVBQUMsQ0FBQyxDQUFDO1lBQzNFLElBQUksY0FBYyxLQUFLLFNBQVMsRUFBRTtnQkFDaEMsSUFBSSxzQkFBc0IsS0FBSyxTQUFTLEVBQUU7b0JBQ3hDLE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FDbkIsV0FBVyxFQUNYLHVDQUF1QyxnQkFBZ0IsZUFBZSxDQUN2RSxDQUFDO2lCQUNIO2dCQUNELElBQUksY0FBYyxLQUFLLGdCQUFnQixFQUFFO29CQUN2QyxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQ25CLG1CQUFtQixFQUNuQixrQ0FBa0MsZ0JBQWdCLGVBQWUsQ0FDbEUsQ0FBQztpQkFDSDthQUNGO1lBRUQscUVBQXFFO1lBQ3JFLElBQUksb0JBQW9CLEdBQUcsUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQzlDLE1BQU0sUUFBUSxHQUFHO2dCQUNmLGNBQWMsRUFBRSxDQUFDO2dCQUNqQixPQUFPLEVBQUUsQ0FBQztnQkFDVixNQUFNLEVBQUUsQ0FBQztnQkFDVCxNQUFNLEVBQUUsQ0FBQztnQkFDVCxPQUFPLEVBQUUsQ0FBQztnQkFDVixZQUFZLEVBQUUsQ0FBQzthQUNoQixDQUFDO1lBQ0YsSUFBSSxPQUFPLEdBQUcsS0FBSyxDQUFDO1lBQ3BCLE1BQU0sS0FBSyxHQUFHLEVBQUMsU0FBUyxFQUFFLGdCQUFnQixFQUFDLENBQUM7WUFFNUMsSUFBSSxjQUFjLEtBQUssU0FBUyxFQUFFO2dCQUNoQyxhQUFhO2dCQUNiLE9BQU8sR0FBRyxJQUFJLENBQUM7Z0JBRWYsb0JBQW9CO2dCQUNwQixNQUFNLE1BQU0sR0FBRyxFQUFDLFNBQVMsRUFBRSxjQUFjLEVBQUMsQ0FBQztnQkFDM0MsTUFBTSxPQUFPLEdBQTJCO29CQUN0Qyw0Q0FBNEM7b0JBQzVDLEtBQUssRUFBRSxLQUFLO29CQUNaLHNDQUFzQztvQkFDdEMsTUFBTSxFQUFFLENBQUMsV0FBVyxDQUFDO29CQUNyQixpQkFBaUI7b0JBQ2pCLFFBQVEsRUFBRSxLQUFLO29CQUNmLHFDQUFxQztvQkFDckMsTUFBTSxFQUFFLElBQUk7aUJBQ2IsQ0FBQztnQkFFRixNQUFNLFVBQVUsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUN4QyxVQUFVLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7Z0JBQ2pDLG9CQUFvQixHQUFHLFFBQVEsQ0FBQyxhQUFhO3FCQUMxQyxNQUFNLENBQUMsTUFBTSxFQUFFLFVBQVUsQ0FBQztvQkFDM0IsNEVBQTRFO3FCQUMzRSxNQUFNLENBQUMsQ0FBQyxLQUFhLEVBQUUsRUFBRTtvQkFDeEIsUUFBUSxDQUFDLGNBQWMsR0FBRyxLQUFLLENBQUM7b0JBQ2hDLE9BQU8sUUFBUSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUM7Z0JBQzlELENBQUMsQ0FBQztxQkFDRCxNQUFNLENBQUMsQ0FBQyxLQUFhLEVBQUUsRUFBRTtvQkFDeEIsUUFBUSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7b0JBRXpCLDZDQUE2QztvQkFDN0MsTUFBTSw0QkFBNEIsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO29CQUMxRCw0QkFBNEIsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztvQkFDbkQsT0FBTyxRQUFRLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsNEJBQTRCLENBQUMsQ0FBQztnQkFDckUsQ0FBQyxDQUFDO3FCQUNELE1BQU0sQ0FBQyxDQUFDLEtBQWEsRUFBRSxFQUFFO29CQUN4QixRQUFRLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztvQkFFeEIseUNBQXlDO29CQUN6QyxNQUFNLHVCQUF1QixHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUE2QixDQUFDO29CQUMvRSx1QkFBdUIsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO29CQUN2QyxPQUFPLFFBQVEsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEVBQUMsS0FBSyxFQUFFLHVCQUF1QixFQUFDLENBQUMsQ0FBQztnQkFDbEUsQ0FBQyxDQUFDO3FCQUNELElBQUksQ0FBQyxHQUFHLEVBQUU7b0JBQ1QsT0FBTyxRQUFRLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUM7Z0JBQ2hELENBQUMsQ0FBQztxQkFDRCxNQUFNLENBQUMsQ0FBQyxLQUFhLEVBQUUsRUFBRTtvQkFDeEIsUUFBUSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7b0JBQ3hCLE9BQU8sUUFBUSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxDQUFDO2dCQUNoRCxDQUFDLENBQUM7cUJBQ0QsTUFBTSxDQUFDLENBQUMsS0FBYSxFQUFFLEVBQUU7b0JBQ3hCLFFBQVEsQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDO29CQUN6QixPQUFPLFFBQVEsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsQ0FBQztnQkFDckQsQ0FBQyxDQUFDO3FCQUNELE1BQU0sQ0FBQyxDQUFDLEtBQWEsRUFBRSxFQUFFO29CQUN4QixRQUFRLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQztnQkFDaEMsQ0FBQyxDQUFDLENBQUM7YUFDTjtpQkFBTTtnQkFDTCxjQUFjO2dCQUNkLE9BQU8sR0FBRyxLQUFLLENBQUM7Z0JBRWhCLG9CQUFvQixHQUFHLFFBQVEsQ0FBQyxhQUFhO3FCQUMxQyxPQUFPLENBQUMsRUFBQyxLQUFLLEVBQUUsS0FBSyxFQUFDLENBQUM7cUJBQ3ZCLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtvQkFDWixRQUFRLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQztvQkFDaEMsT0FBTyxRQUFRLENBQUMsbUJBQW1CLENBQUMsT0FBTyxDQUFDLEVBQUMsS0FBSyxFQUFFLEtBQUssRUFBQyxDQUFDLENBQUM7Z0JBQzlELENBQUMsQ0FBQztxQkFDRCxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7b0JBQ1osUUFBUSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7b0JBQ3pCLE9BQU8sUUFBUSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsRUFBQyxLQUFLLEVBQUUsS0FBSyxFQUFDLENBQUMsQ0FBQztnQkFDaEQsQ0FBQyxDQUFDO3FCQUNELElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtvQkFDWixRQUFRLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztvQkFDeEIsT0FBTyxRQUFRLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxFQUFDLEtBQUssRUFBRSxLQUFLLEVBQUMsQ0FBQyxDQUFDO2dCQUNoRCxDQUFDLENBQUM7cUJBQ0QsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO29CQUNaLFFBQVEsQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO29CQUN4QixPQUFPLFFBQVEsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEVBQUMsS0FBSyxFQUFFLEtBQUssRUFBQyxDQUFDLENBQUM7Z0JBQ2hELENBQUMsQ0FBQztxQkFDRCxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7b0JBQ1osUUFBUSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7b0JBQ3pCLE9BQU8sUUFBUSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsRUFBQyxLQUFLLEVBQUUsS0FBSyxFQUFDLENBQUMsQ0FBQztnQkFDckQsQ0FBQyxDQUFDO3FCQUNELElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtvQkFDWixRQUFRLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQztnQkFDaEMsQ0FBQyxDQUFDLENBQUM7YUFDTjtZQUVELDBCQUEwQjtZQUMxQix3R0FBd0c7WUFDeEcsT0FBTyxvQkFBb0I7aUJBQ3hCLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ1QsZ0NBQWdDO2dCQUNoQyxPQUFPLFFBQVEsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLEVBQUMsS0FBSyxFQUFFLEtBQUssRUFBQyxDQUFDLENBQUM7WUFDdEQsQ0FBQyxDQUFDO2lCQUNELElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ1Qsc0NBQXNDO2dCQUN0QyxPQUFPLGtCQUFrQixDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ3RDLENBQUMsQ0FBQztpQkFDRCxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNULG9DQUFvQztnQkFDcEMsT0FBTyxFQUFDLFFBQVEsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBQyxDQUFDO1lBQ2pELENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQsa0NBQWtDO0lBRWxDOzs7T0FHRztJQUNJLEtBQUssQ0FBQyxXQUFXLENBQUMsTUFBb0I7UUFDM0MsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBQyxNQUFNLEVBQUMsRUFBRTtZQUM3RCxzQkFBc0I7WUFDdEIsTUFBTSxNQUFNLEdBQUcsTUFBTSxrQkFBa0IsQ0FBQyxtQkFBbUIsQ0FDekQsTUFBTSxDQUFDLFNBQVMsRUFDaEIsTUFBTSxDQUFDLElBQUksRUFDWCxNQUFNLENBQUMsVUFBVSxFQUFFLENBQUMsWUFBWSxFQUNoQyxNQUFNLENBQUMsaUJBQWlCLENBQ3pCLENBQUM7WUFFRixNQUFNLFlBQVksR0FBRyxNQUFNLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO2dCQUM3QyxJQUFJLEVBQUUsTUFBTSxDQUFDLElBQUk7Z0JBQ2pCLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQztnQkFDWCxNQUFNLEVBQUUsTUFBTTtnQkFDZCxTQUFTLEVBQUUsTUFBTSxDQUFDLFNBQVM7Z0JBQzNCLElBQUksRUFBRSxNQUFNLENBQUMsSUFBSTtnQkFDakIsSUFBSSxFQUFFLE1BQU0sQ0FBQyxJQUFJO2dCQUNqQixNQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07YUFDdEIsQ0FBQyxDQUFDO1lBRUgsSUFBSSxPQUFnRCxDQUFDO1lBQ3JELElBQUksWUFBWSxDQUFDLElBQUksS0FBSyxNQUFNLEVBQUU7Z0JBQ2hDLE9BQU8sR0FBRyxNQUFNLElBQUksQ0FBQyxZQUFZLENBQUM7b0JBQ2hDLEdBQUcsRUFBRSxZQUFZLENBQUMsT0FBTztvQkFDekIsYUFBYSxFQUFFLElBQUk7b0JBQ25CLFNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUztvQkFDM0IsVUFBVSxFQUFFLE1BQU0sQ0FBQyxVQUFVO29CQUM3QixVQUFVLEVBQUUsTUFBTSxDQUFDLFVBQVU7aUJBQzlCLENBQUMsQ0FBQzthQUNKO2lCQUFNO2dCQUNMLE9BQU8sR0FBRyxNQUFNLElBQUksQ0FBQyxZQUFZLENBQUM7b0JBQ2hDLEdBQUcsRUFBRSxZQUFZLENBQUMsT0FBTztvQkFDekIsYUFBYSxFQUFFLElBQUk7b0JBQ25CLFNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUztpQkFDNUIsQ0FBQyxDQUFDO2FBQ0o7WUFFRCxNQUFNLFVBQVUsR0FBYSxLQUFLLENBQUMsWUFBWSxDQUM3QyxZQUFZLENBQUMsSUFBSSxFQUNqQixZQUFZLENBQUMsT0FBTyxFQUNwQixPQUFPLEVBQ1AsU0FBUyxFQUNULFNBQVMsRUFDVCxLQUFLLENBQ04sQ0FBQztZQUVGLHVGQUF1RjtZQUN2Riw0RkFBNEY7WUFDNUYsSUFBSSxZQUFZLENBQUMsSUFBSSxLQUFLLE1BQU0sRUFBRTtnQkFDaEMsT0FBTyxHQUFJLE9BQThCLENBQUMsTUFBTSxDQUM5QyxDQUFDLENBQUMsR0FBRyxDQUFDLFVBQVUsRUFBRSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLFVBQVUsRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxNQUFNLEVBQUUsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUN6RSxDQUFDO2FBQ0g7aUJBQU07Z0JBQ0wsT0FBTyxHQUFJLE9BQThCLENBQUMsTUFBTSxDQUM5QyxDQUFDLENBQUMsR0FBRyxDQUFDLFVBQVUsRUFBRSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUM7b0JBQ3ZCLEVBQUUsRUFBRSxFQUFFO29CQUNOLElBQUksRUFBRSxFQUFFO29CQUNSLE1BQU0sRUFBRSxFQUFFO29CQUNWLE1BQU0sRUFBRSxFQUFFO29CQUNWLElBQUksRUFBRSxFQUFFO29CQUNSLE1BQU0sRUFBRSxDQUFDO2lCQUNWLENBQUMsQ0FBQyxDQUNKLENBQUM7YUFDSDtZQUVELE9BQU87Z0JBQ0wsSUFBSSxFQUFFLFlBQVksQ0FBQyxJQUFJO2dCQUN2QixTQUFTLEVBQUUsWUFBWSxDQUFDLFNBQVM7Z0JBQ2pDLFdBQVcsRUFBRSxZQUFZLENBQUMsV0FBVztnQkFDckMsT0FBTyxFQUFFLE9BQU87YUFDakIsQ0FBQztRQUNKLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7T0FHRztJQUNJLEtBQUssQ0FBQyxVQUFVLENBQ3JCLE1BQWtDO1FBRWxDLE1BQU0sWUFBWSxHQUFHLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUVwRCwwRkFBMEY7UUFDMUYsSUFBSSxLQUF5QixDQUFDO1FBQzlCLElBQUksTUFBTSxDQUFDLElBQUksS0FBSyxNQUFNLEVBQUU7WUFDMUIsNERBQTREO1lBQzVELE1BQU0sS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUE2QixDQUFDO1lBQ3pELE1BQU0sVUFBVSxHQUFnQixJQUFJLEdBQUcsRUFBRSxDQUFDO1lBQzFDLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQ25CLFVBQVUsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUM1QixVQUFVLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUM5QixDQUFDLENBQUMsQ0FBQztZQUVILEtBQUssR0FBRyxNQUFNLElBQUksQ0FBQyxZQUFZLENBQzdCLENBQUMsQ0FBQyxRQUFRLENBQ1I7Z0JBQ0UsR0FBRyxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDO2dCQUMzQixTQUFTLEVBQUUsTUFBTSxDQUFDLFNBQVM7YUFDNUIsRUFDRCxNQUFNLENBQ1AsQ0FDRixDQUFDO1NBQ0g7YUFBTTtZQUNMLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBNkIsQ0FBQztTQUNwRDtRQUVELCtDQUErQztRQUMvQyxtREFBbUQ7UUFDbkQsTUFBTSxXQUFXLEdBQUcsTUFBTSxJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLEVBQUU7WUFDbEYsWUFBWSxFQUFFLE1BQU0sQ0FBQyxPQUFPO1lBQzVCLGVBQWUsRUFBRSxJQUFJO1lBQ3JCLFNBQVMsRUFBRSxNQUFNLENBQUMsYUFBYTtTQUNoQyxDQUFDLENBQUM7UUFFSCxPQUFPO1lBQ0wsS0FBSyxFQUFFLEtBQUs7WUFDWixLQUFLLEVBQUUsV0FBVztTQUNuQixDQUFDO0lBQ0osQ0FBQztJQUVEOztPQUVHO0lBQ0ksS0FBSyxDQUFDLG1CQUFtQixDQUFDLE1BQWlDO1FBQ2hFLE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBRXhELE9BQU8sVUFBVSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNwRCxDQUFDO0lBRUQ7O09BRUc7SUFDSSxLQUFLLENBQUMsa0JBQWtCLENBQUMsTUFBZ0M7UUFDOUQsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7UUFFeEQsTUFBTSxVQUFVLENBQUMsWUFBWSxFQUFFLENBQUM7SUFDbEMsQ0FBQztJQUVEOztPQUVHO0lBQ0ksS0FBSyxDQUFDLGlCQUFpQixDQUM1QixNQUErQjtRQUUvQixNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUV4RCxNQUFNLGFBQWEsR0FBRyxVQUFVLENBQUMsYUFBYSxDQUFDO1FBQy9DLE1BQU0sV0FBVyxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUM7WUFDOUQsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLFdBQVcsRUFBRTtZQUM1QyxDQUFDLENBQUMsU0FBUyxDQUFDO1FBRWQsSUFBSSxhQUFhLEVBQUU7WUFDakIsbUVBQW1FO1lBQ25FLE9BQU87Z0JBQ0wsTUFBTSxFQUFFLDRCQUFjLENBQUMsT0FBTztnQkFDOUIsT0FBTyxFQUFFLGFBQWEsQ0FBQyxNQUFNO2dCQUM3QixRQUFRLEVBQUUsYUFBYSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO2dCQUMzQyxXQUFXLEVBQUUsV0FBVzthQUN6QixDQUFDO1NBQ0g7UUFFRCxNQUFNLGFBQWEsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQztRQUVyRCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLEVBQUU7WUFDakMscUNBQXFDO1lBQ3JDLE9BQU87Z0JBQ0wsTUFBTSxFQUFFLDRCQUFjLENBQUMsS0FBSztnQkFDNUIsT0FBTyxFQUFFLGFBQWE7Z0JBQ3RCLFdBQVcsRUFBRSxXQUFXO2FBQ3pCLENBQUM7U0FDSDtRQUVELCtCQUErQjtRQUMvQixPQUFPO1lBQ0wsTUFBTSxFQUFFLDRCQUFjLENBQUMsSUFBSTtZQUMzQixXQUFXLEVBQUUsV0FBVztTQUN6QixDQUFDO0lBQ0osQ0FBQztJQUVEOzs7T0FHRztJQUNLLEtBQUssQ0FBQyxzQkFBc0IsQ0FDbEMsTUFBa0IsRUFDbEIsT0FBNkMsRUFDN0MsTUFBYztRQU1kLE1BQU0sTUFBTSxHQUFHLE1BQU0sQ0FBQyxVQUFVLEVBQUUsQ0FBQyxZQUFZLENBQUM7UUFFaEQsSUFBSSxnQkFBZ0IsR0FBRyxLQUFLLENBQUM7UUFDN0IsTUFBTSxtQkFBbUIsR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLElBQUksRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDO1FBQ3pELE1BQU0sbUJBQW1CLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxJQUFJLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQztRQUV6RCxNQUFNLE1BQU0sR0FBeUI7WUFDbkMsS0FBSyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQ1YsTUFBTSxrQkFBa0IsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRSxFQUFFLE9BQU8sQ0FBQyxLQUFLLElBQUksRUFBRSxFQUFFLE1BQU0sQ0FBQyxFQUMzRixJQUFJLENBQUMsRUFBRSxDQUFDLGlCQUFFLE1BQU0sRUFBRSxNQUFNLElBQUssSUFBSSxFQUFFLENBQ3BDO1lBQ0QsS0FBSyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQ1YsTUFBTSxrQkFBa0IsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRSxFQUFFLE9BQU8sQ0FBQyxLQUFLLElBQUksRUFBRSxFQUFFLE1BQU0sQ0FBQyxFQUMzRixJQUFJLENBQUMsRUFBRSxDQUFDLGlCQUFFLE1BQU0sRUFBRSxNQUFNLElBQUssSUFBSSxFQUFFLENBQ3BDO1NBQ0YsQ0FBQztRQUVGLElBQ0UsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLEtBQUssbUJBQW1CO1lBQzNDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxLQUFLLG1CQUFtQixFQUMzQztZQUNBLGdCQUFnQixHQUFHLElBQUksQ0FBQztTQUN6QjtRQUVELE9BQU87WUFDTCxnQkFBZ0IsRUFBRSxnQkFBZ0I7WUFDbEMsS0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO1lBQ25CLEtBQUssRUFBRSxNQUFNLENBQUMsS0FBSztTQUNwQixDQUFDO0lBQ0osQ0FBQztJQUVEOztPQUVHO0lBQ0ksS0FBSyxDQUFDLFVBQVUsQ0FBQyxNQUF3QjtRQUM5QyxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFDLE1BQU0sRUFBQyxFQUFFO1lBQzVELE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUUvQixNQUFNLGlCQUFpQixHQUFHLEVBQUMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxVQUFVLEVBQUUsSUFBSSxFQUFFLE1BQU0sQ0FBQyxVQUFVLEVBQUMsQ0FBQztZQUVuRix1Q0FBdUM7WUFDdkMsTUFBTSxtQkFBbUIsR0FBRyxNQUFNLGtCQUFrQixDQUFDLFNBQVMsQ0FDNUQsTUFBTSxDQUFDLFNBQVMsRUFDaEIsaUJBQWlCLEVBQ2pCLE1BQU0sQ0FBQyxVQUFVLEVBQUUsQ0FBQyxZQUFZLENBQ2pDLENBQUM7WUFFRiwyQkFBMkI7WUFDM0IsTUFBTSxjQUFjLEdBQUcsTUFBTSxrQkFBa0IsQ0FBQyxVQUFVLENBQ3hELE1BQU0sQ0FBQyxTQUFTLEVBQ2hCLG1CQUFtQixDQUNwQixDQUFDO1lBRUYsOEJBQThCO1lBQzlCLE1BQU0sT0FBTyxHQUFHLE1BQU0sTUFBTSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUM7WUFFOUQsbUJBQW1CO1lBQ25CLE1BQU0sSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLHdCQUFVLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxVQUFVLEVBQUUsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBRTdGLGtCQUFrQjtZQUNsQixNQUFNLEtBQUssQ0FBQyxXQUFXLENBQ3JCLE1BQU0sQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsb0JBQW9CLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQzdFLENBQUM7WUFFRixlQUFlO1lBQ2YsTUFBTSxnQkFBZ0IsR0FBRyxNQUFNLElBQUksQ0FBQyxzQkFBc0IsQ0FDeEQsTUFBTSxFQUNOLEVBQUMsS0FBSyxFQUFFLENBQUMsT0FBTyxDQUFDLEVBQUMsRUFDbEIsV0FBVyxDQUNaLENBQUM7WUFFRixPQUFPLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNuQyxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7O09BR0c7SUFDSSxLQUFLLENBQUMsVUFBVSxDQUFDLE1BQXdCO1FBQzlDLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUMsTUFBTSxFQUFDLEVBQUU7WUFDNUQsT0FBTyxJQUFJLENBQUMsZUFBZTtpQkFDeEIsT0FBTyxFQUFFO2lCQUNULElBQUksQ0FBQyxLQUFLLElBQUksRUFBRTtnQkFDZix1Q0FBdUM7Z0JBQ3ZDLE1BQU0sWUFBWSxHQUFHLENBQUMsTUFBTSxNQUFNLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxFQUFDLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFOUUsOEJBQThCO2dCQUM5QixNQUFNLGNBQWMsR0FBRyxNQUFNLENBQUMsZUFBZSxDQUFDLE1BQU0sRUFBRSxZQUFZLENBQUMsRUFBRSxDQUFDLENBQUM7Z0JBQ3ZFLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLEVBQUUsY0FBYyxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFFOUQsdUNBQXVDO2dCQUN2QyxNQUFNLGtCQUFrQixDQUFDLGVBQWUsQ0FDdEMsTUFBTSxDQUFDLFNBQVMsRUFDaEIsWUFBWSxFQUNaLE1BQU0sQ0FBQyxVQUFVLEVBQ2pCLE1BQU0sQ0FBQyxlQUFlLEVBQ3RCLE1BQU0sQ0FBQyxpQkFBaUIsRUFDeEIsTUFBTSxDQUFDLGlCQUFpQixFQUN4QixNQUFNLENBQUMsVUFBVSxFQUFFLENBQUMsWUFBWSxDQUNqQyxDQUFDO2dCQUVGLDBDQUEwQztnQkFDMUMsaUZBQWlGO2dCQUNqRixNQUFNLGlCQUFpQixHQUFHLENBQUMsQ0FBQyxPQUFPLENBQ2pDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLGVBQWUsSUFBSSxFQUFFLEVBQUUsWUFBWSxDQUFDLFVBQVUsQ0FBQyxFQUM5RCxHQUFHLENBQUMsTUFBTSxDQUFDLGlCQUFpQixJQUFJLEVBQUUsQ0FBQyxDQUNwQyxDQUFDO2dCQUVGLDJCQUEyQjtnQkFDM0Isa0RBQWtEO2dCQUNsRCxNQUFNLElBQUksR0FBRyxNQUFNLGtCQUFrQixDQUFDLFVBQVUsQ0FDOUMsTUFBTSxDQUFDLFNBQVMsRUFDaEIsd0JBQVUsQ0FBQyxJQUFJLEVBQ2YsaUJBQWlCLEVBQ2pCLE1BQU0sQ0FBQyxVQUErQixDQUN2QyxDQUFDO2dCQUVGLGtDQUFrQztnQkFDbEMsTUFBTSxXQUFXLEdBQUcsTUFBTSxNQUFNLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQztvQkFDaEQsRUFBRSxFQUFFLE1BQU0sQ0FBQyxFQUFFO29CQUNiLElBQUksRUFBRSxJQUFJO29CQUNWLGVBQWUsRUFBRSxNQUFNLENBQUMsZUFBZTtvQkFDdkMsaUJBQWlCLEVBQUUsTUFBTSxDQUFDLGlCQUFpQjtvQkFDM0MsaUJBQWlCLEVBQUUsTUFBTSxDQUFDLGlCQUFpQjtpQkFDNUMsQ0FBQyxDQUFDO2dCQUVILGlDQUFpQztnQkFDakMsTUFBTSxVQUFVLEdBQUcsTUFBTSxDQUFDLGtCQUFrQixDQUFDLE1BQU0sRUFBRSxZQUFZLENBQUMsRUFBRSxDQUFDLENBQUM7Z0JBRXRFLDZCQUE2QjtnQkFDN0IsTUFBTSxJQUFJLENBQUMsWUFBWSxDQUNyQixNQUFNLENBQUMsU0FBUyxFQUNoQix3QkFBVSxDQUFDLElBQUksRUFDZixXQUFXLENBQUMsVUFBVSxFQUN0QixXQUFXLENBQUMsSUFBSSxDQUNqQixDQUFDO2dCQUVGLGtCQUFrQjtnQkFDbEIsTUFBTSxLQUFLLENBQUMsV0FBVyxDQUNyQixNQUFNLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLG9CQUFvQixDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUNqRixDQUFDO2dCQUVGLGVBQWU7Z0JBQ2YsTUFBTSxnQkFBZ0IsR0FBRyxNQUFNLElBQUksQ0FBQyxzQkFBc0IsQ0FDeEQsTUFBTSxFQUNOLEVBQUMsS0FBSyxFQUFFLENBQUMsV0FBVyxDQUFDLEVBQUMsRUFDdEIsVUFBVSxDQUNYLENBQUM7Z0JBRUYsT0FBTyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDbkMsQ0FBQyxDQUFDO2lCQUNELE9BQU8sQ0FBQyxHQUFHLEVBQUU7Z0JBQ1osSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUNqQyxDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0ksS0FBSyxDQUFDLFVBQVUsQ0FBQyxNQUF3QjtRQUM5QyxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFDLE1BQU0sRUFBQyxFQUFFO1lBQzVELE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUUvQixNQUFNLGlCQUFpQixHQUFHO2dCQUN4QixJQUFJLEVBQUUsTUFBTSxDQUFDLElBQUk7Z0JBQ2pCLElBQUksRUFBRSxNQUFNLENBQUMsVUFBVTtnQkFDdkIsTUFBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO2dCQUNyQixNQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07YUFDdEIsQ0FBQztZQUVGLHVDQUF1QztZQUN2QyxNQUFNLG1CQUFtQixHQUFHLE1BQU0sa0JBQWtCLENBQUMsU0FBUyxDQUM1RCxNQUFNLENBQUMsU0FBUyxFQUNoQixpQkFBaUIsRUFDakIsTUFBTSxDQUFDLFVBQVUsRUFBRSxDQUFDLFlBQVksQ0FDakMsQ0FBQztZQUVGLDJCQUEyQjtZQUMzQixNQUFNLGNBQWMsR0FBRyxNQUFNLGtCQUFrQixDQUFDLFVBQVUsQ0FDeEQsTUFBTSxDQUFDLFNBQVMsRUFDaEIsbUJBQW1CLENBQ3BCLENBQUM7WUFFRiw4QkFBOEI7WUFDOUIsTUFBTSxPQUFPLEdBQUcsTUFBTSxNQUFNLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsQ0FBQztZQUU5RCxtQkFBbUI7WUFDbkIsTUFBTSxJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsd0JBQVUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUUsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBRXpGLGtCQUFrQjtZQUNsQixNQUFNLEtBQUssQ0FBQyxXQUFXLENBQ3JCLE1BQU0sQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsb0JBQW9CLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQzdFLENBQUM7WUFFRixlQUFlO1lBQ2YsTUFBTSxnQkFBZ0IsR0FBRyxNQUFNLElBQUksQ0FBQyxzQkFBc0IsQ0FDeEQsTUFBTSxFQUNOLEVBQUMsS0FBSyxFQUFFLENBQUMsT0FBTyxDQUFDLEVBQUMsRUFDbEIsV0FBVyxDQUNaLENBQUM7WUFFRixPQUFPLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNuQyxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7O09BR0c7SUFDSSxLQUFLLENBQUMsVUFBVSxDQUFDLE1BQXdCO1FBQzlDLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUMsTUFBTSxFQUFDLEVBQUU7WUFDNUQsT0FBTyxJQUFJLENBQUMsZUFBZTtpQkFDeEIsT0FBTyxFQUFFO2lCQUNULElBQUksQ0FBQyxLQUFLLElBQUksRUFBRTtnQkFDZix1Q0FBdUM7Z0JBQ3ZDLE1BQU0sWUFBWSxHQUFHLENBQUMsTUFBTSxNQUFNLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxFQUFDLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFOUUsOEJBQThCO2dCQUM5QixNQUFNLGNBQWMsR0FBRyxNQUFNLENBQUMsZUFBZSxDQUFDLE1BQU0sRUFBRSxZQUFZLENBQUMsRUFBRSxDQUFDLENBQUM7Z0JBQ3ZFLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLEVBQUUsY0FBYyxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFFOUQsdUNBQXVDO2dCQUN2QyxNQUFNLGtCQUFrQixDQUFDLGVBQWUsQ0FDdEMsTUFBTSxDQUFDLFNBQVMsRUFDaEIsWUFBWSxFQUNaLE1BQU0sQ0FBQyxVQUFVLEVBQ2pCLE1BQU0sQ0FBQyxpQkFBaUIsRUFDeEIsTUFBTSxDQUFDLFVBQVUsRUFBRSxDQUFDLFlBQVksQ0FDakMsQ0FBQztnQkFFRiwyQkFBMkI7Z0JBQzNCLGtEQUFrRDtnQkFDbEQsTUFBTSxJQUFJLEdBQUcsTUFBTSxrQkFBa0IsQ0FBQyxVQUFVLENBQzlDLE1BQU0sQ0FBQyxTQUFTLEVBQ2hCLHdCQUFVLENBQUMsSUFBSSxFQUNmLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxFQUNuQixNQUFNLENBQUMsVUFBK0IsQ0FDdkMsQ0FBQztnQkFFRixrQ0FBa0M7Z0JBQ2xDLE1BQU0sV0FBVyxHQUFHLE1BQU0sTUFBTSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUM7b0JBQ2hELEVBQUUsRUFBRSxNQUFNLENBQUMsRUFBRTtvQkFDYixJQUFJLEVBQUUsSUFBSTtvQkFDVixpQkFBaUIsRUFBRSxNQUFNLENBQUMsaUJBQWlCO2lCQUM1QyxDQUFDLENBQUM7Z0JBRUgsaUNBQWlDO2dCQUNqQyxNQUFNLFVBQVUsR0FBRyxNQUFNLENBQUMsa0JBQWtCLENBQUMsTUFBTSxFQUFFLFlBQVksQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFFdEUsdUJBQXVCO2dCQUN2QixNQUFNLElBQUksQ0FBQyxZQUFZLENBQ3JCLE1BQU0sQ0FBQyxTQUFTLEVBQ2hCLHdCQUFVLENBQUMsSUFBSSxFQUNmLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxFQUNsQixXQUFXLENBQUMsSUFBSSxDQUNqQixDQUFDO2dCQUVGLGtDQUFrQztnQkFDbEMsTUFBTSxLQUFLLENBQUMsV0FBVyxDQUNyQixNQUFNLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLG9CQUFvQixDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUNqRixDQUFDO2dCQUVGLGVBQWU7Z0JBQ2YsTUFBTSxnQkFBZ0IsR0FBRyxNQUFNLElBQUksQ0FBQyxzQkFBc0IsQ0FDeEQsTUFBTSxFQUNOLEVBQUMsS0FBSyxFQUFFLENBQUMsV0FBVyxDQUFDLEVBQUMsRUFDdEIsVUFBVSxDQUNYLENBQUM7Z0JBRUYsT0FBTyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDbkMsQ0FBQyxDQUFDO2lCQUNELE9BQU8sQ0FBQyxHQUFHLEVBQUU7Z0JBQ1osSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUNqQyxDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7T0FHRztJQUNJLEtBQUssQ0FBQyxlQUFlLENBQUMsTUFBNkI7UUFDeEQsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7UUFFcEQsTUFBTSxhQUFhLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDOUMsSUFBSSxhQUFhLEtBQUssSUFBSSxFQUFFO1lBQzFCLElBQUksYUFBYSxLQUFLLE1BQU0sQ0FBQyxTQUFTLEVBQUU7Z0JBQ3RDLE1BQU0sSUFBSSxpREFBdUIsQ0FBQyxnQkFBZ0IsTUFBTSxDQUFDLFFBQVEsdUJBQXVCLENBQUMsQ0FBQzthQUMzRjtZQUNELE1BQU0sSUFBSSxpREFBdUIsQ0FDL0IsNkJBQTZCLE1BQU0sQ0FBQyxRQUFRLG9DQUFvQyxDQUNqRixDQUFDO1NBQ0g7UUFFRCxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFFTyxLQUFLLENBQUMsV0FBVyxDQUFDLFNBQWlCO1FBQ3pDLE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUM7UUFFN0MscUNBQXFDO1FBQ3JDLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFFLEVBQUU7WUFDekIsT0FBTztTQUNSO1FBRUQseURBQXlEO1FBQ3pELElBQUksR0FBRyxDQUFDLGVBQWUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsQ0FBQyxJQUFJLEtBQUssVUFBVSxFQUFFO1lBQ2hFLE9BQU87U0FDUjtRQUVELEdBQUcsQ0FBQyxlQUFlLEVBQUUsQ0FBQyxHQUFHLENBQUMsYUFBYSxFQUFFLFVBQVUsQ0FBQyxDQUFDO1FBRXJELGdDQUFnQztRQUNoQyxJQUFJLENBQUMsYUFBYSxHQUFHLFNBQVMsQ0FBQztRQUUvQiw0RkFBNEY7UUFDNUYsTUFBTTthQUNILFdBQVcsRUFBRTthQUNiLE9BQU8sQ0FBQyxHQUFHLEVBQUU7WUFDWixJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztZQUMxQixHQUFHLENBQUMsZUFBZSxFQUFFLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNqRCxDQUFDLENBQUM7YUFDRCxLQUFLLENBQUMsQ0FBQyxDQUFRLEVBQUUsRUFBRTtZQUNsQixHQUFHLENBQUMsS0FBSyxDQUFDLHFCQUFxQixFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQ3BDLG9EQUFvRDtRQUN0RCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFTSxLQUFLLENBQUMsbUJBQW1CLENBQzlCLE1BQWlDO1FBRWpDLE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBRXBELE9BQU8sTUFBTSxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQ2xDLENBQUM7SUFFRDs7O09BR0c7SUFDSSxlQUFlLENBQ3BCLE1BQTJEO1FBRTNELE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLEtBQUssRUFBRSxNQUFNLENBQUMsRUFBRTtZQUN2RCxPQUFPLE1BQU0sQ0FBQyxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7UUFDeEMsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRU0sS0FBSyxDQUFDLHlCQUF5QixDQUFDLE1BQWtDO1FBQ3ZFLE1BQU0sTUFBTSxHQUFHLE1BQU0sSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDMUQsTUFBTSxPQUFPLEdBQUcsTUFBTSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ3BDLE9BQU8sQ0FBQyxZQUFZLEdBQUcsTUFBTSxDQUFDLFlBQVksQ0FBQztRQUMzQyxPQUFPLE1BQU0sQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUVEOztPQUVHO0lBQ0ksS0FBSyxDQUFDLGNBQWMsQ0FBQyxNQUE0QjtRQUN0RCxNQUFNLE1BQU0sR0FBRyxNQUFNLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzFELE1BQU0sTUFBTSxHQUFHLE1BQU0sQ0FBQyxVQUFVLEVBQUUsQ0FBQyxZQUFZLENBQUM7UUFDaEQsTUFBTSxNQUFNLEdBQUcsTUFBTSxrQkFBa0IsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRSxNQUFNLENBQUMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQy9GLE9BQU8sRUFBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBQyxDQUFDO0lBQ2hELENBQUM7SUFFRDs7Ozs7Ozs7Ozs7OztPQWFHO0lBQ0ksS0FBSyxDQUFDLG9CQUFvQixDQUFDLE9BV2pDO1FBSUMsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBQyxNQUFNLEVBQUMsRUFBRTtZQUM5RCxNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7WUFFL0IsTUFBTSxLQUFLLEdBQUcsTUFBTSxNQUFNLENBQUMsS0FBSyxDQUFDLFlBQVksbUJBQ3hDLE9BQU8sSUFDVixHQUFHLEVBQUUsT0FBTyxDQUFDLE9BQU8sRUFDcEIsYUFBYSxFQUFFLE9BQU8sQ0FBQyxpQkFBaUIsSUFDeEMsQ0FBQztZQUVILE1BQU0sS0FBSyxHQUFHLE1BQU0sTUFBTSxDQUFDLEtBQUssQ0FBQyxZQUFZLG1CQUN4QyxPQUFPLElBQ1YsR0FBRyxFQUFFLE9BQU8sQ0FBQyxPQUFPLEVBQ3BCLGFBQWEsRUFBRSxPQUFPLENBQUMsaUJBQWlCLElBQ3hDLENBQUM7WUFFSCxNQUFNLEVBQ0osZ0JBQWdCLEVBQ2hCLEtBQUssRUFBRSxXQUFXLEVBQ2xCLEtBQUssRUFBRSxXQUFXLEVBQ25CLEdBQUcsTUFBTSxJQUFJLENBQUMsc0JBQXNCLENBQUMsTUFBTSxFQUFFLEVBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFDLEVBQUUsV0FBVyxDQUFDLENBQUM7WUFFekYsT0FBTztnQkFDTCxVQUFVLEVBQUUsZ0JBQWdCO2dCQUM1QixNQUFNLEVBQUU7b0JBQ04sS0FBSyxFQUFFLFdBQVc7b0JBQ2xCLEtBQUssRUFBRSxXQUFXO2lCQUNuQjthQUNGLENBQUM7UUFDSixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRCxrQ0FBa0M7SUFFbEM7Ozs7T0FJRztJQUNJLFlBQVksQ0FBQyxTQUFpQjtRQUNuQyxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLEtBQUssRUFBRSxNQUFNLENBQUMsRUFBRTtZQUNoRCxNQUFNLFNBQVMsR0FBRyxNQUFNLENBQUMsUUFBUSxFQUFFLENBQUMsSUFBSSxDQUFDO1lBRXpDLGtEQUFrRDtZQUNsRCxJQUFJLFNBQVMsS0FBSyxVQUFVLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLEVBQUU7Z0JBQ3JFLE9BQU8sTUFBTSxDQUFDLGNBQWMsQ0FBQzthQUM5QjtZQUVELGlGQUFpRjtZQUNqRixJQUFJLFNBQVMsS0FBSyxPQUFPLElBQUksTUFBTSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFO2dCQUMzRCxPQUFPLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO2FBQ3JDO1lBRUQsd0NBQXdDO1lBQ3hDLElBQUksTUFBTSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFO2dCQUNsQyxPQUFPLE1BQU0sQ0FBQyxLQUFLLENBQUMsWUFBWTtnQkFDOUIsdUNBQXVDO2dCQUN2QyxpQ0FBaUM7Z0JBQ2pDLFNBQVMsS0FBSyxVQUFVLElBQUksQ0FBQyxHQUFHLENBQUMsVUFBVSxFQUFFLENBQzlDLENBQUM7YUFDSDtZQUVELG1EQUFtRDtZQUNuRCxPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDN0IsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7Ozs7T0FhRztJQUNJLE9BQU8sQ0FBQyxPQVNkO1FBQ0MsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ3hELE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUUvQixPQUFPLE1BQU0sQ0FBQyxLQUFLO2lCQUNoQixZQUFZLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsRUFBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDO2lCQUN0RCxHQUFHLENBQUMsQ0FBQyxDQUFDO2lCQUNOLElBQUksQ0FBQyxLQUFLLEVBQUMsSUFBSSxFQUFDLEVBQUU7Z0JBQ2pCLE1BQU0sRUFBQyxLQUFLLEVBQUUsV0FBVyxFQUFDLEdBQUcsTUFBTSxJQUFJLENBQUMsc0JBQXNCLENBQzVELE1BQU0sRUFDTixFQUFDLEtBQUssRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFDLEVBQ2YsV0FBVyxDQUNaLENBQUM7Z0JBRUYsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsRUFBRTtvQkFDbEMsT0FBTzt3QkFDTCxLQUFLLEVBQUUsV0FBVzt3QkFDbEIsS0FBSyxFQUFFLEVBQUU7cUJBQ1YsQ0FBQztpQkFDSDtnQkFFRCxPQUFPLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRTtvQkFDdkQsWUFBWSxFQUFFLE9BQU8sQ0FBQyxPQUFPO29CQUM3QixTQUFTLEVBQUUsT0FBTyxDQUFDLGFBQWE7aUJBQ2pDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7b0JBQ2QsT0FBTzt3QkFDTCxLQUFLLEVBQUUsV0FBVzt3QkFDbEIsS0FBSyxFQUFFLEtBQUs7cUJBQ2IsQ0FBQztnQkFDSixDQUFDLENBQUMsQ0FBQztZQUNMLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7OztPQVlHO0lBQ0ksWUFBWSxDQUFDLE9BU25CO1FBQ0MsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ3hELE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUUvQixPQUFPLE1BQU0sQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUMsS0FBSyxFQUFDLEVBQUU7Z0JBQzNELE1BQU0sRUFBQyxLQUFLLEVBQUUsV0FBVyxFQUFDLEdBQUcsTUFBTSxJQUFJLENBQUMsc0JBQXNCLENBQzVELE1BQU0sRUFDTixFQUFDLEtBQUssRUFBRSxLQUFLLEVBQUMsRUFDZCxXQUFXLENBQ1osQ0FBQztnQkFDRixzRkFBc0Y7Z0JBQ3RGLE9BQU8sV0FBVyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLFdBQVcsRUFBRSxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUM7WUFDakYsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNJLFlBQVksQ0FBQyxPQUtuQjtRQUNDLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLEtBQUssRUFBRSxNQUFNLENBQUMsRUFBRTtZQUN4RCxNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7WUFFL0IsT0FBTyxNQUFNLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFDLEtBQUssRUFBQyxFQUFFO2dCQUMzRCxNQUFNLEVBQUMsS0FBSyxFQUFFLFdBQVcsRUFBQyxHQUFHLE1BQU0sSUFBSSxDQUFDLHNCQUFzQixDQUM1RCxNQUFNLEVBQ04sRUFBQyxLQUFLLEVBQUUsS0FBSyxFQUFDLEVBQ2QsV0FBVyxDQUNaLENBQUM7Z0JBQ0Ysc0ZBQXNGO2dCQUN0RixPQUFPLFdBQVcsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxXQUFXLEVBQUUsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBQ2pGLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7T0FnQkc7SUFDSSxnQkFBZ0IsQ0FDckIsT0FBaUIsRUFDakIsT0FVQyxFQUNELFNBQWlCO1FBRWpCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ2hELE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUUvQixJQUFJLGNBQWMsR0FBRyxPQUFPLENBQUM7WUFFN0IsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsRUFBRTtnQkFDbkMsY0FBYyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQzthQUNqRTtZQUVELE9BQU8sTUFBTSxDQUFDLEtBQUs7aUJBQ2hCLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLEVBQUMsY0FBYyxFQUFFLGNBQWMsRUFBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDO2lCQUNoRixJQUFJLENBQUMsS0FBSyxFQUFDLEtBQUssRUFBQyxFQUFFO2dCQUNsQixNQUFNLEVBQUMsS0FBSyxFQUFFLFdBQVcsRUFBQyxHQUFHLE1BQU0sSUFBSSxDQUFDLHNCQUFzQixDQUM1RCxNQUFNLEVBQ04sRUFBQyxLQUFLLEVBQUUsS0FBSyxFQUFDLEVBQ2QsV0FBVyxDQUNaLENBQUM7Z0JBRUYsb0JBQW9CO2dCQUNwQix1QkFBdUI7Z0JBQ3ZCLHFCQUFxQjtnQkFDckIsRUFBRTtnQkFDRiwrQ0FBK0M7Z0JBQy9DLDJDQUEyQztnQkFDM0MsaUNBQWlDO2dCQUNqQywrQkFBK0I7Z0JBQy9CLGtEQUFrRDtnQkFDbEQsRUFBRTtnQkFDRiwyRUFBMkU7Z0JBRTNFLE1BQU0sZUFBZSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUUzQyxtQ0FBbUM7Z0JBRW5DLGdCQUFnQjtnQkFDaEIsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDLFNBQVMsRUFBRSxlQUFlLEVBQUU7b0JBQ3JELFlBQVksRUFBRSxjQUFjO29CQUM1QixlQUFlLEVBQUUsSUFBSTtvQkFDckIsU0FBUyxFQUFFLE9BQU8sQ0FBQyxhQUFhO2lCQUNqQyxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFO29CQUN2QixjQUFjO29CQUNkLE9BQU8sSUFBSSxDQUFDLGNBQWMsQ0FBQyxTQUFTLEVBQUUsT0FBTyxFQUFFO3dCQUM3QyxZQUFZLEVBQUUsY0FBYzt3QkFDNUIsU0FBUyxFQUFFLE9BQU8sQ0FBQyxTQUFTO3dCQUM1QixjQUFjLEVBQUUsT0FBTyxDQUFDLGNBQWM7cUJBQ3ZDLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUU7d0JBQ3JCLE9BQU87NEJBQ0wsS0FBSyxFQUFFLFdBQVc7NEJBQ2xCLEtBQUssRUFBRSxjQUFjLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQzt5QkFDM0MsQ0FBQztvQkFDSixDQUFDLENBQUMsQ0FBQztnQkFDTCxDQUFDLENBQUMsQ0FBQztZQUNMLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7T0FVRztJQUNLLGNBQWMsQ0FDcEIsU0FBaUIsRUFDakIsT0FBaUIsRUFDakIsT0FLQztRQUVELE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUUvQixJQUFJLGVBQWUsR0FBYSxFQUFFLENBQUM7UUFFbkMsSUFBSSxPQUFPLENBQUMsZUFBZSxFQUFFO1lBQzNCLGVBQWUsR0FBRyxlQUFlLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1NBQ25EO1FBRUQsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsRUFBRTtZQUN4QyxlQUFlLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxlQUFlLEVBQUUsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDO1NBQ2xFO1FBRUQsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxLQUFLLEVBQUUsTUFBTSxDQUFDLEVBQUU7WUFDaEQsT0FBTyxNQUFNLENBQUMsS0FBSztpQkFDaEIsY0FBYyxDQUFDLE9BQU8sRUFBRSxlQUFlLEVBQUU7Z0JBQ3hDLFNBQVMsRUFBRSxPQUFPLENBQUMsU0FBUztnQkFDNUIsY0FBYyxFQUFFLE9BQU8sQ0FBQyxjQUFjO2FBQ3ZDLENBQUM7aUJBQ0QsSUFBSSxDQUFDLEtBQUssRUFBQyxLQUFLLEVBQUMsRUFBRTtnQkFDbEIsTUFBTSxFQUFDLEtBQUssRUFBRSxXQUFXLEVBQUMsR0FBRyxNQUFNLElBQUksQ0FBQyxzQkFBc0IsQ0FDNUQsTUFBTSxFQUNOLEVBQUMsS0FBSyxFQUFFLEtBQUssRUFBQyxFQUNkLFdBQVcsQ0FDWixDQUFDO2dCQUNGLE9BQU8sV0FBVyxDQUFDO1lBQ3JCLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxhQUFhLENBQUMsU0FBaUIsRUFBRSxNQUFjO1FBQ3BELE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ2hELE9BQU8sTUFBTSxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQ2hELENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7O09BYUc7SUFDSCxpRUFBaUU7SUFDMUQsYUFBYSxDQUNsQixHQUFhLEVBQ2IsU0FBaUIsRUFDakIsT0FLQztRQUVELE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ2hELE1BQU0sQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEtBQUssRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFFekMsSUFBSSxHQUFHLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtnQkFDcEIsTUFBTSxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsQ0FBQztnQkFDakIsT0FBTyxNQUFNLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFO29CQUN4RSxPQUFPLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQXFCLENBQUM7Z0JBQ3ZELENBQUMsQ0FBQyxDQUFDO2FBQ0o7WUFFRCxNQUFNLE1BQU0sR0FBcUIsRUFBRSxDQUFDO1lBQ3BDLE9BQU8sTUFBTSxDQUFDLEtBQUs7aUJBQ2hCLFdBQVcsQ0FBQyxHQUFHLENBQUM7aUJBQ2hCLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFO2dCQUN4QixNQUFNLFVBQVUsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBQy9ELElBQUksVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7b0JBQ3pCLE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FDbkIsbUJBQW1CLEVBQ25CLDJEQUEyRDt3QkFDekQsb0NBQW9DLENBQ3ZDLENBQUM7aUJBQ0g7Z0JBRUQsSUFBSSxPQUFPLENBQUMsVUFBVSxFQUFFO29CQUN0QixPQUFPLE1BQU0sQ0FBQyxLQUFLLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO3dCQUN4RCxNQUFNLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztvQkFDekIsQ0FBQyxDQUFDLENBQUM7aUJBQ0o7Z0JBRUQsT0FBTztZQUNULENBQUMsQ0FBQztpQkFDRCxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNULElBQUksT0FBTyxDQUFDLFVBQVUsRUFBRTtvQkFDdEIsT0FBTyxNQUFNLENBQUMsS0FBSzt5QkFDaEIsYUFBYSxDQUFDLEdBQUcsRUFBRTt3QkFDbEIsa0JBQWtCLEVBQUUsT0FBTyxDQUFDLGtCQUFrQjt3QkFDOUMsYUFBYSxFQUFFLE9BQU8sQ0FBQyxhQUFhO3FCQUNyQyxDQUFDO3lCQUNELElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTt3QkFDYixNQUFNLENBQUMsTUFBTSxHQUFHLE1BQWdCLENBQUM7b0JBQ25DLENBQUMsQ0FBQyxDQUFDO2lCQUNOO2dCQUVELE9BQU87WUFDVCxDQUFDLENBQUM7aUJBQ0QsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3BCLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0ssaUJBQWlCLENBQUMsSUFBWSxFQUFFLGNBQXVCLEVBQUUsUUFBaUI7UUFDaEYsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDNUQsT0FBTztTQUNSO1FBQ0QsSUFBSSxjQUFjLEdBQUcsUUFBUSxFQUFFO1lBQzdCLE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FDbkIsZUFBZSxFQUNmLEdBQUcsSUFBSSw4QkFBOEIsSUFBSSxJQUFJLENBQUMsY0FBYyxDQUFDLEVBQUUsQ0FDaEUsQ0FBQztTQUNIO0lBQ0gsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksVUFBVSxDQUFDLE1BQWMsRUFBRSxTQUFpQjtRQUNqRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRSxNQUFNLENBQUMsRUFBRTtZQUMvQyxnQ0FBZ0M7WUFDaEMsT0FBTyxNQUFNLENBQUMsS0FBSztpQkFDaEIsWUFBWSxDQUFDLEVBQUMsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLEVBQUMsQ0FBQztpQkFDN0IsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUNaLHFCQUFxQjtnQkFDckIsT0FBTyxNQUFNLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN6QyxDQUFDLENBQUM7aUJBQ0QsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQztpQkFDcEQsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ3ZCLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0ksS0FBSyxDQUFDLHNCQUFzQixDQUNqQyxNQUFvQztRQUVwQyxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxLQUFLLENBQUMsYUFBYSxDQUN4QixNQUFvQztRQUVwQyxJQUFJLE9BQWUsQ0FBQztRQUVwQixNQUFNLEVBQUMsY0FBYyxFQUFDLEdBQUcsTUFBTSxJQUFJLENBQUMsZUFBZSxDQUFDLEVBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxTQUFTLEVBQUMsQ0FBQyxDQUFDO1FBRW5GLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLEtBQUssRUFBRSxNQUFNLENBQUMsRUFBRTtZQUN2RCxJQUFJLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUM3QixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxFQUFFO2dCQUN2QyxNQUFNLGNBQWMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLGNBQWMsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDckYsTUFBTSxlQUFlLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxrQkFBa0IsQ0FDNUQsTUFBTSxDQUFDLEtBQUssRUFDWixNQUFNLENBQUMsWUFBWSxFQUNuQixjQUFjLEVBQ2QsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FDdEMsQ0FBQztnQkFFRixPQUFPLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxlQUFlLEVBQUUsT0FBTyxDQUFDLENBQUM7YUFDM0M7WUFFRCxNQUFNLFFBQVEsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLHdCQUF3QixDQUFXLENBQUM7WUFFaEUsOENBQThDO1lBQzlDLE1BQU0sZUFBZSxHQUFHO2dCQUN0QixPQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU87Z0JBQ3ZCLE9BQU8sRUFBRSxPQUFPO2dCQUNoQixLQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUssSUFBSSxRQUFRO2dCQUMvQixVQUFVLEVBQUUsTUFBTSxDQUFDLFVBQVU7Z0JBQzdCLFVBQVUsRUFBRSxNQUFNLENBQUMsVUFBVTtnQkFDN0Isa0JBQWtCLEVBQUUsTUFBTSxDQUFDLGtCQUFrQjtnQkFDN0MsYUFBYSxFQUFFLE1BQU0sQ0FBQyxhQUFhO2FBQ3BDLENBQUM7WUFDRixLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxlQUFlLEVBQUUsZUFBZSxDQUFDLEtBQUssRUFBRSxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFFekUsTUFBTSxVQUFVLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQywwQkFBMEIsQ0FBVyxDQUFDO1lBQ3BFLE9BQU8sR0FBRyxNQUFNLENBQUMsT0FBTyxJQUFJLFVBQVUsQ0FBQztZQUN2QyxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxDQUFDO1lBRS9ELE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUMvQixPQUFPLE1BQU0sQ0FBQyxLQUFLO2lCQUNoQixRQUFRLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztpQkFDL0IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFO2dCQUNyQixPQUFPLEtBQUssQ0FBQyxhQUFhLENBQUMsY0FBYyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1lBQ3RELENBQUMsQ0FBQztpQkFDRCxJQUFJLENBQUMsS0FBSyxFQUFDLE1BQU0sRUFBQyxFQUFFO2dCQUNuQixJQUFJLE1BQU0sQ0FBQyxPQUFPLEVBQUU7b0JBQ2xCLEdBQUcsQ0FBQyxJQUFJLENBQUMsY0FBYyxNQUFNLENBQUMsS0FBSyxxQkFBcUIsT0FBTyxNQUFNLENBQUMsQ0FBQztvQkFDdkUsTUFBTSxJQUFJLHlDQUFtQixDQUFDLDRCQUFNLENBQUMsVUFBVSxDQUFDLENBQUM7aUJBQ2xEO2dCQUVELElBQUksZ0JBQWdCLEdBQUcsS0FBSyxDQUFDO2dCQUM3QixJQUFJLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxLQUFLLGVBQWUsQ0FBQyxLQUFLLEVBQUU7b0JBQ2xELGdCQUFnQixHQUFHLElBQUksQ0FBQztpQkFDekI7Z0JBRUQsSUFBSSxpQkFBaUIsR0FBRyxLQUFLLENBQUM7Z0JBQzlCLHdDQUF3QztnQkFDeEMsSUFBSSxnQkFBZ0IsR0FBRyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQ3RDLE1BQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBQyxRQUFRLEVBQUMsRUFBRTtvQkFDakMsSUFBSSxnQkFBZ0IsQ0FBQztvQkFDckIsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsRUFBRTt3QkFDekMsZ0JBQWdCLEdBQUcsTUFBTSxNQUFNLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3FCQUMxRDt5QkFBTTt3QkFDTCxnQkFBZ0IsR0FBRyxRQUFRLENBQUM7cUJBQzdCO29CQUVELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFO3dCQUNuQyx5Q0FBeUM7d0JBQ3pDLE9BQU87cUJBQ1I7b0JBRUQsTUFBTSxrQkFBa0IsR0FBRyxNQUFNLElBQUksQ0FBQyxzQkFBc0IsQ0FDMUQsTUFBTSxFQUNOLEVBQUMsS0FBSyxFQUFFLGdCQUFnQixDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsZ0JBQWdCLENBQUMsS0FBSyxFQUFDLEVBQzlELFdBQVcsQ0FDWixDQUFDO29CQUVGLElBQUksa0JBQWtCLENBQUMsZ0JBQWdCLEVBQUU7d0JBQ3ZDLGtDQUFrQzt3QkFDbEMsT0FBTztxQkFDUjtvQkFFRCxPQUFPLGtCQUFrQixDQUFDO2dCQUM1QixDQUFDLENBQUMsQ0FDSCxDQUFDO2dCQUNGLGdCQUFnQixHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBRXRFLElBQUksZ0JBQWdCLENBQUMsTUFBTSxLQUFLLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFO29CQUNwRCxzRkFBc0Y7b0JBQ3RGLGlCQUFpQixHQUFHLElBQUksQ0FBQztpQkFDMUI7Z0JBRUQsTUFBTSxXQUFXLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGdCQUFnQixFQUFFLE9BQU8sQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUN6RSxNQUFNLFdBQVcsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLEVBQUUsT0FBTyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBRXpFLE1BQU0sT0FBTyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUV6QyxpR0FBaUc7Z0JBQ2pHLElBQUksWUFBWSxHQUFHLFdBQVcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBRXRFLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEVBQUU7b0JBQ2xDLG1EQUFtRDtvQkFDbkQsWUFBWSxHQUFHLFlBQVksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2lCQUNwRDtnQkFFRCxPQUFPLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRSxPQUFPLEVBQUU7b0JBQ3BELFlBQVksRUFBRSxZQUFZO29CQUMxQixTQUFTLEVBQUUsTUFBTSxDQUFDLGFBQWE7b0JBQy9CLGNBQWMsRUFBRSxNQUFNLENBQUMsa0JBQWtCO2lCQUMxQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFO29CQUNwQixPQUFPO3dCQUNMLGdCQUFnQixFQUFFLGdCQUFnQjt3QkFDbEMsaUJBQWlCLEVBQUUsaUJBQWlCO3dCQUNwQyxLQUFLLEVBQUUsV0FBVzt3QkFDbEIsS0FBSyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFLFdBQVcsRUFBRSxJQUFJLENBQUM7cUJBQ2pELENBQUM7Z0JBQ0osQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7O09BYUc7SUFDSSxZQUFZLENBQUMsTUFBMEI7UUFDNUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQ3JDLElBQUksT0FBZSxDQUFDO1FBRXBCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLEtBQUssRUFBRSxNQUFNLENBQUMsRUFBRTtZQUN2RCxNQUFNLFFBQVEsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLHdCQUF3QixDQUFXLENBQUM7WUFFaEUsOENBQThDO1lBQzlDLE1BQU0sZUFBZSxHQUFHO2dCQUN0QixPQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU87Z0JBQ3ZCLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7Z0JBQ3ZCLEtBQUssRUFBRSxNQUFNLENBQUMsS0FBSyxJQUFJLFFBQVE7YUFDaEMsQ0FBQztZQUNGLEtBQUssQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGVBQWUsRUFBRSxlQUFlLENBQUMsS0FBSyxFQUFFLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQztZQUV6RSxNQUFNLFVBQVUsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLHdCQUF3QixDQUFXLENBQUM7WUFDbEUsT0FBTyxHQUFHLE1BQU0sQ0FBQyxPQUFPLElBQUksVUFBVSxDQUFDO1lBQ3ZDLEtBQUssQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGlCQUFpQixFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUUsVUFBVSxDQUFDLENBQUM7WUFFL0QsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQy9CLE9BQU8sTUFBTSxDQUFDLEtBQUs7aUJBQ2hCLFFBQVEsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO2lCQUMvQixJQUFJLENBQUMsQ0FBQyxjQUE2QyxFQUFFLEVBQUU7Z0JBQ3RELE9BQU8sS0FBSyxDQUFDLGFBQWEsQ0FBQyxjQUFjLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFDdEQsQ0FBQyxDQUFDO2lCQUNELElBQUksQ0FBQyxDQUFDLFlBQStELEVBQUUsRUFBRTtnQkFDeEUsSUFBSSxZQUFZLENBQUMsT0FBTyxFQUFFO29CQUN4QixHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsTUFBTSxDQUFDLEtBQUsscUJBQXFCLE9BQU8sTUFBTSxDQUFDLENBQUM7aUJBQ3BFO2dCQUVELE1BQU0sZUFBZSxHQUFHLEVBQUUsQ0FBQztnQkFFM0IsS0FBSyxNQUFNLEtBQUssSUFBSSxZQUFZLENBQUMsTUFBTSxFQUFFO29CQUN2QyxNQUFNLGVBQWUsR0FJakI7d0JBQ0YsS0FBSyxFQUFFLEtBQUssQ0FBQyxLQUFLO3dCQUNsQixLQUFLLEVBQUUsS0FBSyxDQUFDLEtBQUs7d0JBQ2xCLE9BQU8sRUFBRSxFQUFFO3FCQUNaLENBQUM7b0JBRUYsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsRUFBRTt3QkFDbEMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUU7NEJBQzlCLE1BQU0sV0FBVyxHQUFZLEtBQUssQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDOzRCQUVqRSxtREFBbUQ7NEJBQ25ELElBQ0UsQ0FBQyxNQUFNLENBQUMsSUFBSSxLQUFLLFFBQVEsSUFBSSxPQUFPLFdBQVcsS0FBSyxRQUFRLENBQUM7Z0NBQzdELENBQUMsTUFBTSxDQUFDLElBQUksS0FBSyxRQUFRLElBQUksS0FBSyxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxFQUMzRDtnQ0FDQSxlQUFlLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQzs2QkFDM0M7aUNBQU07Z0NBQ0wscUZBQXFGO2dDQUNyRixlQUFlLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzs2QkFDcEM7d0JBQ0gsQ0FBQyxDQUFDLENBQUM7cUJBQ0o7b0JBRUQsZUFBZSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztpQkFDdkM7Z0JBRUQsT0FBTyxlQUFlLENBQUM7WUFDekIsQ0FBQyxDQUFDO2lCQUNELEdBQUcsQ0FBQyxLQUFLLEVBQUMsS0FBSyxFQUFDLEVBQUU7Z0JBQ2pCLE1BQU0sRUFBQyxLQUFLLEVBQUUsS0FBSyxFQUFDLEdBQUcsTUFBTSxJQUFJLENBQUMsc0JBQXNCLENBQUMsTUFBTSxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQztnQkFFckYsT0FBTztvQkFDTCxLQUFLLEVBQUUsS0FBSztvQkFDWixLQUFLLEVBQUUsS0FBSztvQkFDWixPQUFPLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO2lCQUNsQyxDQUFDO1lBQ0osQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUMsT0FBTyxFQUFFLE9BQU8sRUFBQyxDQUFDLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBRUQ7Ozs7Ozs7OztPQVNHO0lBQ0ksVUFBVSxDQUFDLE9BS2pCO1FBQ0MsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLEtBQUssRUFBRSxNQUFNLENBQUMsRUFBRTtZQUN4RCx1RUFBdUU7WUFDdkUsTUFBTSxRQUFRLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsRUFBRSxJQUFJLENBQVcsQ0FBQztZQUV0RSxrQ0FBa0M7WUFDbEMsTUFBTSxlQUFlLEdBQUc7Z0JBQ3RCLE9BQU8sRUFBRSxPQUFPLENBQUMsT0FBTztnQkFDeEIsT0FBTyxFQUFFLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztnQkFDeEIsS0FBSyxFQUFFLE9BQU8sQ0FBQyxLQUFLLElBQUksUUFBUTthQUNqQyxDQUFDO1lBQ0YsS0FBSyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsZUFBZSxFQUFFLGVBQWUsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDO1lBRXpFLG1FQUFtRTtZQUNuRSxPQUFPLE1BQU0sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLGVBQWUsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUN2RCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ksWUFBWSxDQUFDLFNBQWlCO1FBQ25DLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ2hELE1BQU0sU0FBUyxHQUFHLE1BQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQyxJQUFJLENBQUM7WUFFekMsa0RBQWtEO1lBQ2xELElBQUksU0FBUyxLQUFLLFVBQVUsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsRUFBRTtnQkFDckUsT0FBTyxNQUFNLENBQUMsY0FBYyxDQUFDO2FBQzlCO1lBRUQsaUZBQWlGO1lBQ2pGLElBQUksU0FBUyxLQUFLLE9BQU8sSUFBSSxNQUFNLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUU7Z0JBQzNELE9BQU8sTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7YUFDckM7WUFFRCx3Q0FBd0M7WUFDeEMsSUFBSSxNQUFNLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUU7Z0JBQ2xDLE9BQU8sTUFBTSxDQUFDLEtBQUssQ0FBQyxZQUFZO2dCQUM5Qix1Q0FBdUM7Z0JBQ3ZDLGlDQUFpQztnQkFDakMsU0FBUyxLQUFLLFVBQVUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxVQUFVLEVBQUUsQ0FDOUMsQ0FBQzthQUNIO1lBRUQsbURBQW1EO1lBQ25ELE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM3QixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7OztPQWFHO0lBQ0ksT0FBTyxDQUFDLE9BU2Q7UUFDQyxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxLQUFLLEVBQUUsTUFBTSxDQUFDLEVBQUU7WUFDeEQsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBRS9CLE9BQU8sTUFBTSxDQUFDLEtBQUs7aUJBQ2hCLFlBQVksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEVBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxFQUFDLEVBQUUsT0FBTyxDQUFDLENBQUM7aUJBQ3RELEdBQUcsQ0FBQyxDQUFDLENBQUM7aUJBQ04sSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUNYLHVDQUF1QztnQkFDdkMsT0FBTyxNQUFNLENBQUMsS0FBSztxQkFDaEIsWUFBWSxDQUFDO29CQUNaLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQztvQkFDL0IsVUFBVSxFQUFFLE9BQU8sQ0FBQyxVQUFVO29CQUM5QixVQUFVLEVBQUUsT0FBTyxDQUFDLFVBQVU7b0JBQzlCLGtCQUFrQixFQUFFLE9BQU8sQ0FBQyxrQkFBa0I7b0JBQzlDLGFBQWEsRUFBRSxPQUFPLENBQUMsYUFBYTtpQkFDckMsQ0FBQztxQkFDRCxJQUFJLENBQUMsS0FBSyxFQUFDLEtBQUssRUFBQyxFQUFFO29CQUNsQix5REFBeUQ7b0JBQ3pELE1BQU0sRUFBQyxLQUFLLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxXQUFXLEVBQUMsR0FBRyxNQUFNLElBQUksQ0FBQyxzQkFBc0IsQ0FDaEYsTUFBTSxFQUNOLEVBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBQyxFQUM3QixXQUFXLENBQ1osQ0FBQztvQkFDRixPQUFPLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsRUFBRTt3QkFDaEUsWUFBWSxFQUFFLE9BQU8sQ0FBQyxPQUFPO3dCQUM3QixlQUFlLEVBQUUsSUFBSTt3QkFDckIsU0FBUyxFQUFFLE9BQU8sQ0FBQyxhQUFhO3FCQUNqQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO3dCQUNkLDBEQUEwRDt3QkFDMUQsMERBQTBEO3dCQUMxRCxPQUFPOzRCQUNMLEtBQUssRUFBRSxXQUFXOzRCQUNsQixxREFBcUQ7NEJBQ3JELEtBQUssRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEVBQUUsSUFBSSxDQUFDO3lCQUNqRCxDQUFDO29CQUNKLENBQUMsQ0FBQyxDQUFDO2dCQUNMLENBQUMsQ0FBQyxDQUFDO1lBQ1AsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFTyxLQUFLLENBQUMsWUFBWSxDQUN4QixTQUFpQixFQUNqQixVQUFzQixFQUN0QixNQUFnQixFQUNoQixJQUE0QjtRQUU1QixNQUFNLE9BQU8sR0FBRyxJQUFJLHVCQUFhLEVBQUUsQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzFELE1BQU0sa0JBQWtCLENBQUMsWUFBWSxDQUFDLFNBQVMsRUFBRSxVQUFVLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFDeEUsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksVUFBVSxDQUFDLE1BQWMsRUFBRSxTQUFpQjtRQUNqRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRSxNQUFNLENBQUMsRUFBRTtZQUMvQyxnQ0FBZ0M7WUFDaEMsT0FBTyxNQUFNLENBQUMsS0FBSztpQkFDaEIsWUFBWSxDQUFDLEVBQUMsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLEVBQUMsQ0FBQztpQkFDN0IsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUNaLHFCQUFxQjtnQkFDckIsT0FBTyxNQUFNLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN6QyxDQUFDLENBQUM7aUJBQ0QsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQztpQkFDcEQsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ3ZCLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0ksY0FBYztRQUNuQixJQUFJLG9CQUFvQixHQUFHLENBQUMsQ0FBQztRQUM3QixPQUFPLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsRUFBRTtZQUMxQyxJQUFJLE1BQU0sQ0FBQyxTQUFTLEVBQUU7Z0JBQ3BCLG1FQUFtRTtnQkFDbkUsT0FBTzthQUNSO1lBRUQsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ3BDLElBQUksTUFBTSxDQUFDLFdBQVcsRUFBRSxFQUFFO29CQUN4QixvQkFBb0IsRUFBRSxDQUFDO2lCQUN4QjtZQUNILENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNYLEdBQUcsQ0FBQyxlQUFlLEVBQUUsQ0FBQyxHQUFHLENBQ3ZCLGFBQWEsRUFDYixJQUFJLEVBQ0osR0FBRyxvQkFBb0IsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sMEJBQTBCLENBQ3pFLENBQUM7UUFDSixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNJLGFBQWE7UUFDbEIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQztJQUN0RCxDQUFDO0lBRUQ7O09BRUc7SUFDSSxZQUFZLENBQUMsU0FBUyxHQUFHLEtBQUs7UUFDbkMsT0FBTyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLEVBQUU7WUFDMUMsSUFBSSxNQUFNLENBQUMsU0FBUyxFQUFFO2dCQUNwQixtRUFBbUU7Z0JBQ25FLE9BQU87YUFDUjtZQUVELElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFFLEVBQUU7Z0JBQ3pCLE9BQU8sUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDO2FBQzNCO1lBRUQsb0VBQW9FO1lBQ3BFLElBQUksU0FBUyxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBRSxJQUFJLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFlBQVksS0FBSyxJQUFJLENBQUMsRUFBRTtnQkFDbkYsT0FBTyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUM7YUFDM0I7WUFFRCxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUMzRCxHQUFHLENBQUMsS0FBSyxDQUFDLDZCQUE2QixHQUFHLE1BQU0sQ0FBQyxRQUFRLEdBQUcsVUFBVSxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQ2pGLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7SUFDZCxDQUFDO0lBRUQ7O09BRUc7SUFDSSxnQkFBZ0I7UUFDckIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDO0lBQzVCLENBQUM7SUFFRDs7T0FFRztJQUNJLEtBQUssQ0FBQyxlQUFlLENBQUMsTUFBNkI7UUFDeEQsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBQyxNQUFNLEVBQUMsRUFBRTtZQUM3RCxJQUFJLFVBQVUsQ0FBQztZQUNmLElBQUksY0FBMkMsQ0FBQztZQUNoRCxJQUFJLElBQUksR0FBRyxpQ0FBYyxDQUFDLE1BQU0sQ0FBQztZQUVqQyxJQUFJLEtBQUssR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDO1lBQ3pCLElBQUksZUFBZSxHQUF1QixFQUFFLENBQUM7WUFFN0MsSUFBSSx5QkFBbUIsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQ3pDLHdDQUF3QztnQkFDeEMsSUFBSSxHQUFHLGlDQUFjLENBQUMsUUFBUSxDQUFDO2dCQUMvQixNQUFNLE1BQU0sR0FBRyxNQUFNLE1BQU0sQ0FBQyxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7Z0JBQ3BELGNBQWMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUUsTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDO2dCQUN6RSxVQUFVLEdBQUcseUJBQW1CLENBQUMsWUFBWSxDQUFDLGNBQWMsQ0FBQyxDQUFDO2dCQUU5RCxNQUFNLFlBQVksR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLG9CQUFvQixDQUFDLGNBQWMsQ0FBQyxDQUFDO2dCQUN2RSxNQUFNLEtBQUssR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNwRCxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLGtCQUFrQixDQUNwRCxLQUFLLEVBQ0wsWUFBWSxFQUNaLGNBQWMsRUFDZCxLQUFLLENBQ04sQ0FBQztnQkFFRiw4Q0FBOEM7Z0JBQzlDLCtEQUErRDtnQkFDL0QsS0FBSyxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7Z0JBQ3pCLGVBQWUsR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDO2FBQzlDO1lBRUQsMkZBQTJGO1lBQzNGLE1BQU0sS0FBSyxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQzdDLElBQUk7Z0JBQ0Ysb0NBQW9DO2dCQUNwQyxNQUFNLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ2xDO1lBQUMsT0FBTyxLQUFLLEVBQUU7Z0JBQ2QsSUFBSSxLQUFLLENBQUMsSUFBSSxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO29CQUNuQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyx5QkFBbUIsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsZUFBZSxDQUFDLENBQUM7aUJBQzNGO2dCQUNELE1BQU0sS0FBSyxDQUFDO2FBQ2I7WUFFRCxPQUFPO2dCQUNMLEtBQUssRUFBRSxLQUFLO2dCQUNaLFVBQVUsRUFBRSxVQUFVO2dCQUN0QixjQUFjLEVBQUUsY0FBYztnQkFDOUIsSUFBSSxFQUFFLElBQUk7YUFDWCxDQUFDO1FBQ0osQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7OztPQVlHO0lBQ0ksYUFBYTtRQUNsQiw2RkFBNkY7UUFDN0YsTUFBTSxhQUFhLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQztRQUNsRCxNQUFNLGVBQWUsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLENBQUM7UUFDdEQsTUFBTSxPQUFPLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUV0QyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQzVGLHlGQUF5RjtZQUN6RixzREFBc0Q7WUFDdEQscUZBQXFGO1lBQ3JGLHlFQUF5RTtZQUN6RSxPQUFPLFFBQVEsQ0FBQyxlQUFlO2lCQUM1QixNQUFNLENBQ0w7Z0JBQ0UsZUFBZSxFQUFFLFdBQVcsQ0FBQyxnQkFBZ0I7Z0JBQzdDLGFBQWEsRUFBRSxXQUFXLENBQUMsY0FBYzthQUMxQyxFQUNELEVBQUMsS0FBSyxFQUFFLEVBQUMsYUFBYSxFQUFFLEVBQUMsR0FBRyxFQUFFLElBQUksRUFBQyxFQUFDLEVBQUMsQ0FDdEM7aUJBQ0EsTUFBTSxFQUFFLENBQUM7U0FDYjtRQUVELDJFQUEyRTtRQUMzRSwrREFBK0Q7UUFDL0QsT0FBTyxRQUFRLENBQUMsZUFBZTthQUM1QixNQUFNLENBQ0w7WUFDRSxhQUFhLEVBQUU7Z0JBQ2IsaUJBQWlCLEVBQUUsSUFBSTtnQkFDdkIsYUFBYSxFQUFFLGFBQWE7Z0JBQzVCLGVBQWUsRUFBRSxlQUFlO2dCQUNoQyxPQUFPLEVBQUUsT0FBTzthQUNqQjtTQUNGLEVBQ0QsRUFBQyxLQUFLLEVBQUUsRUFBQyxhQUFhLEVBQUUsRUFBQyxHQUFHLEVBQUUsSUFBSSxFQUFDLEVBQUMsRUFBQyxDQUN0QzthQUNBLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDVCwyQkFBMkI7WUFDM0IsTUFBTSxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsU0FBUyxDQUFDLENBQUM7WUFDakMsaUNBQWlDO1lBQ2pDLE1BQU0sQ0FBQyxHQUFHLENBQUMsZUFBZSxFQUFFLFNBQVMsQ0FBQyxDQUFDO1lBQ3ZDLG1DQUFtQztZQUNuQyxNQUFNLENBQUMsR0FBRyxDQUFDLGlCQUFpQixFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBQzNDLENBQUMsQ0FBQzthQUNELE1BQU0sRUFBRSxDQUFDO0lBQ2QsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxLQUFLLENBQUMsdUJBQXVCO1FBQ2xDLE1BQU0sV0FBVyxHQUFHLE1BQU0sUUFBUSxDQUFDLGVBQWUsQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUM3RCxLQUFLLE1BQU0sTUFBTSxJQUFJLFdBQVcsRUFBRTtZQUNoQyxNQUFNLGNBQWMsR0FBRyxNQUFNLENBQUMsb0JBQW9CLENBQUM7WUFDbkQsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxJQUFJLGNBQWMsQ0FBQyxNQUFNLEVBQUU7Z0JBQzNELEdBQUcsQ0FBQyxJQUFJLENBQ04sVUFBVSxjQUFjLENBQUMsTUFBTSx5QkFBeUIsRUFDeEQscUJBQXFCLE1BQU0sQ0FBQyxHQUFHLHVCQUF1QixFQUN0RCxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxDQUMvQixDQUFDO2dCQUVGLE1BQU0sa0JBQWtCLENBQUMsb0JBQW9CLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSx3QkFBVSxDQUFDLElBQUksRUFBRSxjQUFjLENBQUMsQ0FBQztnQkFFM0YscURBQXFEO2dCQUNyRCxNQUFNLENBQUMsb0JBQW9CLEdBQUcsSUFBSSxDQUFDO2dCQUNuQyxNQUFNLE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQzthQUNyQjtZQUVELE1BQU0sY0FBYyxHQUFHLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQztZQUVuRCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLElBQUksY0FBYyxDQUFDLE1BQU0sRUFBRTtnQkFDM0QsR0FBRyxDQUFDLElBQUksQ0FDTixVQUFVLGNBQWMsQ0FBQyxNQUFNLHlCQUF5QixFQUN4RCxxQkFBcUIsTUFBTSxDQUFDLEdBQUcsdUJBQXVCLEVBQ3RELElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLENBQy9CLENBQUM7Z0JBRUYsTUFBTSxrQkFBa0IsQ0FBQyxvQkFBb0IsQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFLHdCQUFVLENBQUMsSUFBSSxFQUFFLGNBQWMsQ0FBQyxDQUFDO2dCQUUzRixxREFBcUQ7Z0JBQ3JELE1BQU0sQ0FBQyxvQkFBb0IsR0FBRyxJQUFJLENBQUM7Z0JBQ25DLE1BQU0sTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDO2FBQ3JCO1NBQ0Y7SUFDSCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0ssTUFBTSxDQUFDLFVBQVUsQ0FDdkIsS0FBZSxFQUNmLEtBQVUsRUFDVixhQUFzQjtRQUV0QixNQUFNLElBQUksR0FBNkIsS0FBSyxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUM7WUFDbEUsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBVyxFQUFFLElBQUksQ0FBQztZQUNwRCxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDNUIsTUFBTSxLQUFLLEdBQW1CLElBQUksR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUN2RCxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUN0RCxDQUFDO0NBQ0Y7QUFFRCxpQkFBUyxJQUFJLFdBQVcsRUFBRSxDQUFDIn0=