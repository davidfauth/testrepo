/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2015-02-11.
 */
'use strict';
const LKE = require('../index');
const Utils = LKE.getUtils();
class Progress {
    /**
     * @param {CustomLogger} logger
     * @param {string}       [prefix='']        Used to prefix all log messages
     * @param {number}       [progressStep=0.5] Minimum progress difference (in percentage) between two log messages
     */
    constructor(logger, prefix, progressStep) {
        this._logger = logger;
        this._prefix = prefix || '';
        this._progressStep = progressStep || 0.5;
        // total number of items to index
        this._totalItems = 0;
        // indexation start time
        this._startTime = 0;
        // type of items at latest batch (for logging purpose)
        this._label = 'item';
        // initial number of items already indexed
        this._initialOffset = 0;
        // progress in percentage
        this._progress = 0;
        // estimated time left in milliseconds
        this._timeLeft = 0;
        // total number of indexed items
        this._totalDone = 0;
        // duration in milliseconds
        this._totalDuration = 0;
        // items indexed per milliseconds in average
        this._averageSpeed = 0;
        // total number of items left to be indexed
        this._itemsLeft = 0;
    }
    /**
     * Initialize a progress instance.
     *
     * @param {number} totalItems
     * @param {boolean} samplingStep
     */
    start(totalItems, samplingStep) {
        this._totalItems = totalItems;
        this._startTime = Date.now();
        this.samplingStep = samplingStep;
        this.isSampling = samplingStep;
        this._samplingPercentage = 0;
    }
    setSamplingPercentage(percentage) {
        this._samplingPercentage = percentage;
    }
    endSampling() {
        this.isSampling = false;
    }
    /**
     * @returns {string}
     */
    getStatus() {
        if (!this.isSampling) {
            return `Currently indexing ${this.getRate()}. ` +
                `Time left: ${this.getTimeLeft()}.`;
        }
        else {
            return 'Currently sampling the data-source.';
        }
    }
    /**
     * Return a string representing the average indexation speed.
     *
     * @returns {string}
     */
    getRate() {
        return (1000 * this._averageSpeed).toFixed(0) + ' ' + this._label + 's/s';
    }
    /**
     * Return a string representing the percentage of the indexation.
     *
     * @returns {string}
     */
    getPercent() {
        if (!this.samplingStep) {
            return this._progress.toFixed(2);
        }
        else if (this.isSampling) {
            return (this._samplingPercentage / 10).toFixed(2);
        }
        else {
            // sampling accounts for 10% of the progress bar
            return (10 + (this._progress * 10 / 9)).toFixed(2);
        }
    }
    /**
     * Return a string representing the time left for the indexation to finish.
     *
     * @returns {string}
     */
    getTimeLeft() {
        return Utils.humanDuration(this._timeLeft);
    }
    /**
     * Return the count of already indexed items.
     *
     * @returns {number}
     */
    getTotalIndexedItems() {
        return this._totalDone + this._initialOffset;
    }
    /**
     * Log an end message.
     */
    end() {
        this._log(`Done: ${this._totalDone} items in ${Utils.humanDuration(this._totalDuration)} ` +
            `(average speed: ${(1000 * this._averageSpeed).toFixed(0)} items/s)`);
    }
    /**
     * Add an array of items (or a value representing their cardinality) to the progress,
     * without counting them for the average speed.
     *
     * @param {string} label
     * @param {number | Array<any>} items
     */
    setInitialOffset(label, items) {
        let batchLength;
        if (Array.isArray(items)) {
            batchLength = items.length;
        }
        else {
            batchLength = /**@type {number}*/ (items);
        }
        this._totalDone += batchLength;
        this._initialOffset += batchLength;
    }
    /**
     * Add an array of items (or a value representing their cardinality) to the progress.
     *
     * @param {string} label
     * @param {number | Array<any>} items
     */
    add(label, items) {
        let batchLength;
        if (Array.isArray(items)) {
            batchLength = items.length;
        }
        else {
            batchLength = /**@type {number}*/ (items);
        }
        const prevProgress = this._progress;
        this._label = label;
        this._totalDone += batchLength;
        this._totalDuration = Date.now() - this._startTime;
        this._averageSpeed = (this._totalDone - this._initialOffset) / this._totalDuration;
        this._itemsLeft = Math.max(0, this._totalItems - this._totalDone);
        this._progress = 100 * this._totalDone / this._totalItems;
        this._timeLeft = this._itemsLeft / this._averageSpeed;
        if (this._progress + this._progressStep > prevProgress) {
            this._log(`[${this.getPercent()}%]` +
                ` Already indexed ${this._totalDone} items in ${Utils.humanDuration(this._totalDuration)}` +
                ` at ${this.getRate()} (average).` +
                ` Time left: ${this.getTimeLeft()}`);
        }
    }
    /**
     * @param {any} message
     * @private
     */
    _log(message) {
        this._logger.info(this._prefix + ' ' + message);
    }
}
module.exports = Progress;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJvZ3Jlc3MuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvZGF0YS9wcm9ncmVzcy5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7R0FLRztBQUNILFlBQVksQ0FBQztBQUNiLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNoQyxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFFN0IsTUFBTSxRQUFRO0lBQ1o7Ozs7T0FJRztJQUNILFlBQVksTUFBTSxFQUFFLE1BQU0sRUFBRSxZQUFZO1FBQ3RDLElBQUksQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDO1FBQ3RCLElBQUksQ0FBQyxPQUFPLEdBQUcsTUFBTSxJQUFJLEVBQUUsQ0FBQztRQUM1QixJQUFJLENBQUMsYUFBYSxHQUFHLFlBQVksSUFBSSxHQUFHLENBQUM7UUFFekMsaUNBQWlDO1FBQ2pDLElBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDO1FBQ3JCLHdCQUF3QjtRQUN4QixJQUFJLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQztRQUNwQixzREFBc0Q7UUFDdEQsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7UUFDckIsMENBQTBDO1FBQzFDLElBQUksQ0FBQyxjQUFjLEdBQUcsQ0FBQyxDQUFDO1FBQ3hCLHlCQUF5QjtRQUN6QixJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQztRQUNuQixzQ0FBc0M7UUFDdEMsSUFBSSxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUM7UUFDbkIsZ0NBQWdDO1FBQ2hDLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDO1FBQ3BCLDJCQUEyQjtRQUMzQixJQUFJLENBQUMsY0FBYyxHQUFHLENBQUMsQ0FBQztRQUN4Qiw0Q0FBNEM7UUFDNUMsSUFBSSxDQUFDLGFBQWEsR0FBRyxDQUFDLENBQUM7UUFDdkIsMkNBQTJDO1FBQzNDLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDO0lBQ3RCLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILEtBQUssQ0FBQyxVQUFVLEVBQUUsWUFBWTtRQUM1QixJQUFJLENBQUMsV0FBVyxHQUFHLFVBQVUsQ0FBQztRQUM5QixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUM3QixJQUFJLENBQUMsWUFBWSxHQUFHLFlBQVksQ0FBQztRQUNqQyxJQUFJLENBQUMsVUFBVSxHQUFHLFlBQVksQ0FBQztRQUMvQixJQUFJLENBQUMsbUJBQW1CLEdBQUcsQ0FBQyxDQUFDO0lBQy9CLENBQUM7SUFFRCxxQkFBcUIsQ0FBQyxVQUFVO1FBQzlCLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxVQUFVLENBQUM7SUFDeEMsQ0FBQztJQUVELFdBQVc7UUFDVCxJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztJQUMxQixDQUFDO0lBRUQ7O09BRUc7SUFDSCxTQUFTO1FBQ1AsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDcEIsT0FBTyxzQkFBc0IsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJO2dCQUM3QyxjQUFjLElBQUksQ0FBQyxXQUFXLEVBQUUsR0FBRyxDQUFDO1NBQ3ZDO2FBQU07WUFDTCxPQUFPLHFDQUFxQyxDQUFDO1NBQzlDO0lBQ0gsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxPQUFPO1FBQ0wsT0FBTyxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztJQUM1RSxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILFVBQVU7UUFDUixJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRTtZQUN0QixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ2xDO2FBQU0sSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFO1lBQzFCLE9BQU8sQ0FBQyxJQUFJLENBQUMsbUJBQW1CLEdBQUcsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ25EO2FBQU07WUFDTCxnREFBZ0Q7WUFDaEQsT0FBTyxDQUFDLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ3BEO0lBQ0gsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxXQUFXO1FBQ1QsT0FBTyxLQUFLLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILG9CQUFvQjtRQUNsQixPQUFPLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQztJQUMvQyxDQUFDO0lBRUQ7O09BRUc7SUFDSCxHQUFHO1FBQ0QsSUFBSSxDQUFDLElBQUksQ0FDUCxTQUFTLElBQUksQ0FBQyxVQUFVLGFBQWEsS0FBSyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLEdBQUc7WUFDaEYsbUJBQW1CLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FDckUsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxnQkFBZ0IsQ0FBQyxLQUFLLEVBQUUsS0FBSztRQUMzQixJQUFJLFdBQVcsQ0FBQztRQUNoQixJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDeEIsV0FBVyxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUM7U0FDNUI7YUFBTTtZQUNMLFdBQVcsR0FBRyxtQkFBbUIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQzNDO1FBRUQsSUFBSSxDQUFDLFVBQVUsSUFBSSxXQUFXLENBQUM7UUFDL0IsSUFBSSxDQUFDLGNBQWMsSUFBSSxXQUFXLENBQUM7SUFDckMsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsR0FBRyxDQUFDLEtBQUssRUFBRSxLQUFLO1FBQ2QsSUFBSSxXQUFXLENBQUM7UUFDaEIsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ3hCLFdBQVcsR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDO1NBQzVCO2FBQU07WUFDTCxXQUFXLEdBQUcsbUJBQW1CLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUMzQztRQUVELE1BQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUM7UUFFcEMsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7UUFFcEIsSUFBSSxDQUFDLFVBQVUsSUFBSSxXQUFXLENBQUM7UUFDL0IsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQztRQUNuRCxJQUFJLENBQUMsYUFBYSxHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQztRQUNuRixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ2xFLElBQUksQ0FBQyxTQUFTLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQztRQUMxRCxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztRQUV0RCxJQUFJLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLGFBQWEsR0FBRyxZQUFZLEVBQUU7WUFDdEQsSUFBSSxDQUFDLElBQUksQ0FDUCxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUUsSUFBSTtnQkFDekIsb0JBQW9CLElBQUksQ0FBQyxVQUFVLGFBQWEsS0FBSyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLEVBQUU7Z0JBQzFGLE9BQU8sSUFBSSxDQUFDLE9BQU8sRUFBRSxhQUFhO2dCQUNsQyxlQUFlLElBQUksQ0FBQyxXQUFXLEVBQUUsRUFBRSxDQUNwQyxDQUFDO1NBQ0g7SUFDSCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsSUFBSSxDQUFDLE9BQU87UUFDVixJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxHQUFHLEdBQUcsR0FBRyxPQUFPLENBQUMsQ0FBQztJQUNsRCxDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLFFBQVEsQ0FBQyJ9