"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-12-09.
 */
// TODO TS2019
const rest_client_1 = require("@linkurious/rest-client");
const Bluebird = require("bluebird");
const _ = require("lodash");
const proxy_1 = require("../../../lib/proxy");
const LKE = require("../index");
const Utils = LKE.getUtils();
const Data = LKE.getData();
const Access = LKE.getAccess();
const audit = LKE.getAuditTrail();
const Config = LKE.getConfig();
const Errors = LKE.getErrors();
const GraphSchema = LKE.getGraphSchema();
const lkeIsReadOnly = !Config.get('access.dataEdition');
class DataProxyFactory extends proxy_1.ProxyFactory {
    constructor() {
        super();
        this.check('createNode', async (user, params) => {
            await user.canEditCategories(params.sourceKey, params.categories);
        }, async (user, result, params) => {
            const filteredNode = await user.filterNodeContent(params.sourceKey, result);
            await audit.write(user, params.sourceKey, 'createNode', { createInfo: params }, { node: filteredNode });
            return filteredNode;
        });
        this.check('createEdge', async (user, params) => {
            await user.canEditType(params.sourceKey, params.type);
        }, async (user, result, params) => {
            const filteredEdge = user.filterEdgeProperties(params.sourceKey, result);
            await audit.write(user, params.sourceKey, 'createEdge', { createInfo: params }, { edge: filteredEdge });
            return filteredEdge;
        });
        this.check('updateNode', async (user, params) => {
            await user.canEditNode(params.sourceKey, params.id);
            const categoriesToEdit = params.addedCategories.concat(params.deletedCategories);
            await user.canEditCategories(params.sourceKey, categoriesToEdit);
        }, async (user, result, params) => {
            const filteredNode = await user.filterNodeContent(params.sourceKey, result);
            await audit.write(user, params.sourceKey, 'updateNode', {
                updateInfo: params
            }, { node: filteredNode });
            return filteredNode;
        });
        this.check('updateEdge', async (user, params) => {
            await user.canEditEdge(params.sourceKey, params.id);
        }, async (user, result, params) => {
            const filteredEdge = user.filterEdgeProperties(params.sourceKey, result);
            await audit.write(user, params.sourceKey, 'updateEdge', {
                updateInfo: params
            }, { edge: filteredEdge });
            return filteredEdge;
        });
        this.check('searchIndex', async (user, params) => {
            const readableLabels = await (params.type === rest_client_1.EntityType.NODE
                ? user.readableCategories(params.sourceKey)
                : user.readableTypes(params.sourceKey));
            // if all is readable, don't touch the filter in options
            if (readableLabels[0] === '*') {
                return;
            }
            if (Utils.noValue(params.categoriesOrTypes)) {
                params.categoriesOrTypes = readableLabels;
            }
            // if both filters (user input and access rights) are defined, we take the intersection
            params.categoriesOrTypes = _.intersection(params.categoriesOrTypes, readableLabels);
        }, async (user, result, params) => {
            if (params.type === rest_client_1.EntityType.NODE) {
                result.results = await user.filterNodesContent(params.sourceKey, result.results);
            }
            else {
                result.results = await user.filterEdgesContent(params.sourceKey, result.results);
            }
            return result;
        });
        this.check('searchFull', async (user, params) => {
            return addReadableCategoriesOrTypes(user, params.sourceKey, params);
        }, async (user, result, params) => {
            // we don't keep nodes with no edges if we are requesting edges
            const discardNodesWithNoEdges = params.type === 'edge';
            const filteredSubGraph = await user.filterSubGraph(params.sourceKey, result, {
                discardNodesWithNoEdges: discardNodesWithNoEdges
            });
            await audit.read(user, params.sourceKey, 'searchFull', { searchString: params.q }, filteredSubGraph);
            return filteredSubGraph;
        });
        // TODO TS2019 refactor under here
        this.proxy('resolveSource');
        this.check('getSourceStates', undefined, (user, result) => {
            return user.hasAction('admin.connect', undefined, false).then(canConnect => {
                return result.filter(source => {
                    // visible: (not connected AND user can connect sources) OR (connected AND visible to current user)
                    return ((!source.key && canConnect) || (source.key && user.canSeeDataSource(source.key, false)));
                });
            });
        });
        this.check('getNodeCount', (user, sourceKey) => {
            return Bluebird.resolve().then(() => {
                user.canSeeDataSource(sourceKey);
            });
        });
        this.check('getNode', (user, options) => {
            return addReadableCategoriesOrTypes(user, options.sourceKey, options);
        }, (user, result, options) => {
            return user.filterSubGraph(options.sourceKey, result, {}).then(filteredSubGraph => {
                return audit
                    .read(user, options.sourceKey, 'getNode', { id: options.id }, filteredSubGraph)
                    .return(filteredSubGraph);
            });
        });
        this.check('getNodesByID', (user, options) => {
            return addReadableCategoriesOrTypes(user, options.sourceKey, options);
        }, (user, result, options) => {
            return user.filterNodesContent(options.sourceKey, result).then(filteredNodes => {
                return filteredNodes;
            });
        });
        this.check('getEdgesByID', undefined, (user, result, options) => {
            return user.filterEdgesContent(options.sourceKey, result).then(filteredEdges => {
                return filteredEdges;
            });
        });
        this.check('getNodesAndEdgesByID', (user, options) => {
            return addReadableCategoriesOrTypes(user, options.sourceKey, options);
        }, (user, result, options) => {
            const originalNodesLength = result.result.nodes.length;
            const originalEdgesLength = result.result.edges.length;
            const isFilteredBySchema = result.isFiltered;
            return user.filterSubGraph(options.sourceKey, result.result, {}).then(filteredSubGraph => {
                let isFilteredByAccessRights = false;
                if (filteredSubGraph.nodes.length !== originalNodesLength ||
                    filteredSubGraph.edges.length !== originalEdgesLength) {
                    isFilteredByAccessRights = true;
                }
                return {
                    isFiltered: isFilteredBySchema || isFilteredByAccessRights,
                    result: filteredSubGraph
                };
            });
        });
        this.check(
        // TODO fail if the user cannot see data-source
        // TODO fail if I can't read the main node or edge in getNode getEdge
        'getAdjacentNodes', (user, nodeIds, options, sourceKey) => {
            return addReadableCategoriesOrTypes(user, sourceKey, options).then(() => {
                return user.canReadNodes(sourceKey, nodeIds);
            });
        }, (user, result, nodeIds, options, sourceKey) => {
            return user.filterSubGraph(sourceKey, result, {}).then(filteredSubGraph => {
                return audit
                    .read(user, sourceKey, 'getAdjacentNodes', { nodeIds: nodeIds }, filteredSubGraph)
                    .return(filteredSubGraph);
            });
        });
        this.check('getStatistics', (user, ids, sourceKey, options) => {
            return addReadableCategoriesOrTypes(user, sourceKey, options).then(() => {
                return user.canReadNodes(sourceKey, ids);
            });
        }, (user, result, ids, sourceKey, options) => {
            return Bluebird.props({
                supernode: result.supernode,
                supernodeDegree: result.supernodeDegree,
                supernodeDigest: result.supernodeDigest,
                degree: result.degree,
                digest: Bluebird.resolve().then(() => {
                    if (Utils.hasValue(result.digest)) {
                        return user.filterDigest(sourceKey, result.digest);
                    }
                    return;
                })
            });
        });
        this.check('deleteNode', (user, nodeId, sourceKey) => {
            return user.canDeleteNode(sourceKey, nodeId).return();
        }, (user, result, nodeId, sourceKey) => {
            return audit
                .write(user, sourceKey, 'deleteNode', {
                nodeId: nodeId
            })
                .return(result);
        });
        this.check('runGraphQuery', async (user, params) => {
            const source = Data.resolveSource(params.sourceKey);
            const isWrite = source.graph.checkQuery(params.query);
            if (isWrite) {
                if (source.isReadOnly()) {
                    return Errors.access('write_forbidden', 'The data-source is in read-only mode.', true);
                }
                if (lkeIsReadOnly) {
                    return Errors.access('readonly_right', 'Linkurious is in read-only mode.', true);
                }
            }
            params.filterSubGraph = filterSubGraphWholeOrNothing(user, params.sourceKey);
            return addReadableCategoriesOrTypes(user, params.sourceKey, params);
        }, async (user, result, params) => {
            return audit
                .readWrite(user, params.sourceKey, 'rawQuery', { query: params.query, dialect: params.dialect }, result)
                .return(result);
        });
        this.check('runGraphQueryByContent', async (user, params) => {
            const source = Data.resolveSource(params.sourceKey);
            const isWrite = source.graph.checkQuery(params.query);
            if (!isWrite) {
                const currentUser = await Access.checkAuth(user, 'graph.rawRead');
                await currentUser.hasAction('rawReadQuery', params.sourceKey);
            }
            else {
                const currentUser = await Access.checkAuth(user, 'graph.rawWrite');
                await currentUser.hasAction('rawWriteQuery', params.sourceKey);
                if (source.isReadOnly()) {
                    return Errors.access('write_forbidden', 'The data-source is in read-only mode.', true);
                }
                if (lkeIsReadOnly) {
                    // TODO remove this check from the proxy and use the data service as done for create/update
                    return Errors.access('readonly_right', 'Linkurious is in read-only mode.', true);
                }
            }
            params.filterSubGraph = filterSubGraphWholeOrNothing(user, params.sourceKey);
            return addReadableCategoriesOrTypes(user, params.sourceKey, params);
        }, async (user, result, params) => {
            return audit
                .readWrite(user, params.sourceKey, 'rawQuery', { query: params.query, dialect: params.dialect }, result)
                .return(result);
        });
        this.check('alertPreview', async (user, options) => {
            await user.hasAction('admin.alerts', options.sourceKey);
        }, (user, result, options) => {
            return Bluebird.reduce(result.results, (filteredMatches, match) => {
                return user.filterSubGraph(options.sourceKey, match, {}).then(filteredMatch => {
                    if (filteredMatch.nodes.length > 0) {
                        filteredMatch.columns = match.columns;
                        filteredMatches.push(filteredMatch);
                    }
                    return filteredMatches;
                });
            }, []).then(results => ({ results: results }));
        });
        this.check('getEdgeCount', (user, sourceKey) => {
            return Bluebird.resolve().then(() => {
                user.canSeeDataSource(sourceKey);
            });
        });
        this.check('getEdge', (user, options) => {
            return addReadableCategoriesOrTypes(user, options.sourceKey, options);
        }, (user, result, options) => {
            return user
                .filterSubGraph(options.sourceKey, result, {
                discardNodesWithNoEdges: true
            })
                .then(filteredSubGraph => {
                return audit
                    .read(user, options.sourceKey, 'getEdge', { id: options.id }, filteredSubGraph)
                    .return(filteredSubGraph);
            });
        });
        this.check('deleteEdge', (user, edgeId, sourceKey) => {
            return user.canDeleteEdge(sourceKey, edgeId).return();
        }, (user, result, edgeId, sourceKey) => {
            return audit.write(user, sourceKey, 'deleteEdge', { edgeId: edgeId }).return(result);
        });
        this.check('getGraphSchema', undefined, (user, result, options) => {
            return user.addAccessToSchema(options.sourceKey, options.entityType, result);
        });
        this.check('checkGraphQuery', async (user, params) => {
            await Access.checkAuth(user, 'graph.rawRead', true);
            await user.hasAction('rawReadQuery', params.sourceKey);
        });
    }
}
function filterSubGraphWholeOrNothing(user, sourceKey) {
    return async (subGraph) => {
        if (subGraph.nodes.length === 0 && subGraph.edges.length === 0) {
            return Promise.resolve(subGraph);
        }
        return user
            .filterSubGraph(sourceKey, subGraph, {
            allOrNothing: true
        })
            .then(filteredSubGraph => {
            if (filteredSubGraph.nodes.length === 0 && filteredSubGraph.edges.length === 0) {
                return null;
            }
            return filteredSubGraph;
        });
    };
}
/**
 * Add to the object `options` the keys `readableCategories` and `readableTypes`.
 */
async function addReadableCategoriesOrTypes(user, sourceKey, options) {
    const [readableCategories, readableTypes, nodeSchema, edgeSchema] = await Promise.all([
        user.readableCategories(sourceKey),
        user.readableTypes(sourceKey),
        GraphSchema.getSchema(sourceKey, rest_client_1.EntityType.NODE),
        GraphSchema.getSchema(sourceKey, rest_client_1.EntityType.EDGE)
    ]);
    let availableCategories = nodeSchema.labels.filter(label => nodeSchema.get(label).visibility !== rest_client_1.DataVisibility.NONE);
    let availableTypes = edgeSchema.labels.filter(label => edgeSchema.get(label).visibility !== rest_client_1.DataVisibility.NONE);
    if (readableCategories[0] !== '*') {
        availableCategories = _.intersection(readableCategories, availableCategories);
    }
    if (readableTypes[0] !== '*') {
        availableTypes = _.intersection(readableTypes, availableTypes);
    }
    options.readableCategories = availableCategories;
    options.readableTypes = availableTypes;
}
module.exports = new DataProxyFactory().proxify(Data);
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJveHkuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvZGF0YS9wcm94eS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7O0dBS0c7QUFFSCxjQUFjO0FBRWQseURBTWlDO0FBQ2pDLHFDQUFxQztBQUNyQyw0QkFBNEI7QUFFNUIsOENBQWdEO0FBRWhELGdDQUFpQztBQUNqQyxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxJQUFJLEdBQUcsR0FBRyxDQUFDLE9BQU8sRUFBRSxDQUFDO0FBQzNCLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsYUFBYSxFQUFFLENBQUM7QUFDbEMsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLFdBQVcsR0FBRyxHQUFHLENBQUMsY0FBYyxFQUFFLENBQUM7QUFFekMsTUFBTSxhQUFhLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLG9CQUFvQixDQUFDLENBQUM7QUFFeEQsTUFBTSxnQkFBaUIsU0FBUSxvQkFBc0M7SUFDbkU7UUFDRSxLQUFLLEVBQUUsQ0FBQztRQUVSLElBQUksQ0FBQyxLQUFLLENBQ1IsWUFBWSxFQUNaLEtBQUssRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDckIsTUFBTSxJQUFJLENBQUMsaUJBQWlCLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRSxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDcEUsQ0FBQyxFQUNELEtBQUssRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxFQUFFO1lBQzdCLE1BQU0sWUFBWSxHQUFHLE1BQU0sSUFBSSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDNUUsTUFBTSxLQUFLLENBQUMsS0FBSyxDQUNmLElBQUksRUFDSixNQUFNLENBQUMsU0FBUyxFQUNoQixZQUFZLEVBQ1osRUFBQyxVQUFVLEVBQUUsTUFBTSxFQUFDLEVBQ3BCLEVBQUMsSUFBSSxFQUFFLFlBQVksRUFBQyxDQUNyQixDQUFDO1lBQ0YsT0FBTyxZQUFZLENBQUM7UUFDdEIsQ0FBQyxDQUNGLENBQUM7UUFFRixJQUFJLENBQUMsS0FBSyxDQUNSLFlBQVksRUFDWixLQUFLLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxFQUFFO1lBQ3JCLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN4RCxDQUFDLEVBQ0QsS0FBSyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDN0IsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLG9CQUFvQixDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDekUsTUFBTSxLQUFLLENBQUMsS0FBSyxDQUNmLElBQUksRUFDSixNQUFNLENBQUMsU0FBUyxFQUNoQixZQUFZLEVBQ1osRUFBQyxVQUFVLEVBQUUsTUFBTSxFQUFDLEVBQ3BCLEVBQUMsSUFBSSxFQUFFLFlBQVksRUFBQyxDQUNyQixDQUFDO1lBQ0YsT0FBTyxZQUFZLENBQUM7UUFDdEIsQ0FBQyxDQUNGLENBQUM7UUFFRixJQUFJLENBQUMsS0FBSyxDQUNSLFlBQVksRUFDWixLQUFLLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxFQUFFO1lBQ3JCLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUNwRCxNQUFNLGdCQUFnQixHQUFHLE1BQU0sQ0FBQyxlQUFlLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1lBQ2pGLE1BQU0sSUFBSSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztRQUNuRSxDQUFDLEVBQ0QsS0FBSyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDN0IsTUFBTSxZQUFZLEdBQUcsTUFBTSxJQUFJLENBQUMsaUJBQWlCLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRSxNQUFNLENBQUMsQ0FBQztZQUM1RSxNQUFNLEtBQUssQ0FBQyxLQUFLLENBQ2YsSUFBSSxFQUNKLE1BQU0sQ0FBQyxTQUFTLEVBQ2hCLFlBQVksRUFDWjtnQkFDRSxVQUFVLEVBQUUsTUFBTTthQUNuQixFQUNELEVBQUMsSUFBSSxFQUFFLFlBQVksRUFBQyxDQUNyQixDQUFDO1lBQ0YsT0FBTyxZQUFZLENBQUM7UUFDdEIsQ0FBQyxDQUNGLENBQUM7UUFFRixJQUFJLENBQUMsS0FBSyxDQUNSLFlBQVksRUFDWixLQUFLLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxFQUFFO1lBQ3JCLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUN0RCxDQUFDLEVBQ0QsS0FBSyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDN0IsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLG9CQUFvQixDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDekUsTUFBTSxLQUFLLENBQUMsS0FBSyxDQUNmLElBQUksRUFDSixNQUFNLENBQUMsU0FBUyxFQUNoQixZQUFZLEVBQ1o7Z0JBQ0UsVUFBVSxFQUFFLE1BQU07YUFDbkIsRUFDRCxFQUFDLElBQUksRUFBRSxZQUFZLEVBQUMsQ0FDckIsQ0FBQztZQUNGLE9BQU8sWUFBWSxDQUFDO1FBQ3RCLENBQUMsQ0FDRixDQUFDO1FBRUYsSUFBSSxDQUFDLEtBQUssQ0FDUixhQUFhLEVBQ2IsS0FBSyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsRUFBRTtZQUNyQixNQUFNLGNBQWMsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksS0FBSyx3QkFBVSxDQUFDLElBQUk7Z0JBQzNELENBQUMsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQztnQkFDM0MsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7WUFDMUMsd0RBQXdEO1lBQ3hELElBQUksY0FBYyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRTtnQkFDN0IsT0FBTzthQUNSO1lBRUQsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFO2dCQUMzQyxNQUFNLENBQUMsaUJBQWlCLEdBQUcsY0FBYyxDQUFDO2FBQzNDO1lBRUQsdUZBQXVGO1lBQ3ZGLE1BQU0sQ0FBQyxpQkFBaUIsR0FBRyxDQUFDLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsRUFBRSxjQUFjLENBQUMsQ0FBQztRQUN0RixDQUFDLEVBQ0QsS0FBSyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDN0IsSUFBSSxNQUFNLENBQUMsSUFBSSxLQUFLLHdCQUFVLENBQUMsSUFBSSxFQUFFO2dCQUNuQyxNQUFNLENBQUMsT0FBTyxHQUFHLE1BQU0sSUFBSSxDQUFDLGtCQUFrQixDQUM1QyxNQUFNLENBQUMsU0FBUyxFQUNoQixNQUFNLENBQUMsT0FBNkIsQ0FDckMsQ0FBQzthQUNIO2lCQUFNO2dCQUNMLE1BQU0sQ0FBQyxPQUFPLEdBQUcsTUFBTSxJQUFJLENBQUMsa0JBQWtCLENBQzVDLE1BQU0sQ0FBQyxTQUFTLEVBQ2hCLE1BQU0sQ0FBQyxPQUE2QixDQUNyQyxDQUFDO2FBQ0g7WUFFRCxPQUFPLE1BQU0sQ0FBQztRQUNoQixDQUFDLENBQ0YsQ0FBQztRQUVGLElBQUksQ0FBQyxLQUFLLENBQ1IsWUFBWSxFQUNaLEtBQUssRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDckIsT0FBTyw0QkFBNEIsQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLFNBQVMsRUFBRSxNQUFNLENBQUMsQ0FBQztRQUN0RSxDQUFDLEVBQ0QsS0FBSyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDN0IsK0RBQStEO1lBQy9ELE1BQU0sdUJBQXVCLEdBQUcsTUFBTSxDQUFDLElBQUksS0FBSyxNQUFNLENBQUM7WUFFdkQsTUFBTSxnQkFBZ0IsR0FBRyxNQUFNLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRSxNQUFNLEVBQUU7Z0JBQzNFLHVCQUF1QixFQUFFLHVCQUF1QjthQUNqRCxDQUFDLENBQUM7WUFFSCxNQUFNLEtBQUssQ0FBQyxJQUFJLENBQ2QsSUFBSSxFQUNKLE1BQU0sQ0FBQyxTQUFTLEVBQ2hCLFlBQVksRUFDWixFQUFDLFlBQVksRUFBRSxNQUFNLENBQUMsQ0FBQyxFQUFDLEVBQ3hCLGdCQUFnQixDQUNqQixDQUFDO1lBRUYsT0FBTyxnQkFBZ0IsQ0FBQztRQUMxQixDQUFDLENBQ0YsQ0FBQztRQUVGLGtDQUFrQztRQUVsQyxJQUFJLENBQUMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxDQUFDO1FBRTVCLElBQUksQ0FBQyxLQUFLLENBQUMsaUJBQWlCLEVBQUUsU0FBUyxFQUFFLENBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxFQUFFO1lBQ3hELE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLEVBQUUsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRTtnQkFDekUsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFO29CQUM1QixtR0FBbUc7b0JBQ25HLE9BQU8sQ0FDTCxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsSUFBSSxVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLElBQUksSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FDeEYsQ0FBQztnQkFDSixDQUFDLENBQUMsQ0FBQztZQUNMLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsS0FBSyxDQUFDLGNBQWMsRUFBRSxDQUFDLElBQUksRUFBRSxTQUFTLEVBQUUsRUFBRTtZQUM3QyxPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNsQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDbkMsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxLQUFLLENBQ1IsU0FBUyxFQUNULENBQUMsSUFBSSxFQUFFLE9BQU8sRUFBRSxFQUFFO1lBQ2hCLE9BQU8sNEJBQTRCLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDeEUsQ0FBQyxFQUNELENBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsRUFBRTtZQUN4QixPQUFPLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxNQUFNLEVBQUUsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEVBQUU7Z0JBQ2hGLE9BQU8sS0FBSztxQkFDVCxJQUFJLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxTQUFTLEVBQUUsU0FBUyxFQUFFLEVBQUMsRUFBRSxFQUFFLE9BQU8sQ0FBQyxFQUFFLEVBQUMsRUFBRSxnQkFBZ0IsQ0FBQztxQkFDNUUsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUM7WUFDOUIsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQ0YsQ0FBQztRQUVGLElBQUksQ0FBQyxLQUFLLENBQ1IsY0FBYyxFQUNkLENBQUMsSUFBSSxFQUFFLE9BQU8sRUFBRSxFQUFFO1lBQ2hCLE9BQU8sNEJBQTRCLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDeEUsQ0FBQyxFQUNELENBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsRUFBRTtZQUN4QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRTtnQkFDN0UsT0FBTyxhQUFhLENBQUM7WUFDdkIsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQ0YsQ0FBQztRQUVGLElBQUksQ0FBQyxLQUFLLENBQUMsY0FBYyxFQUFFLFNBQVMsRUFBRSxDQUFDLElBQUksRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLEVBQUU7WUFDOUQsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUU7Z0JBQzdFLE9BQU8sYUFBYSxDQUFDO1lBQ3ZCLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsS0FBSyxDQUNSLHNCQUFzQixFQUN0QixDQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsRUFBRTtZQUNoQixPQUFPLDRCQUE0QixDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ3hFLENBQUMsRUFDRCxDQUFDLElBQUksRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLEVBQUU7WUFDeEIsTUFBTSxtQkFBbUIsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUM7WUFDdkQsTUFBTSxtQkFBbUIsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUM7WUFDdkQsTUFBTSxrQkFBa0IsR0FBRyxNQUFNLENBQUMsVUFBVSxDQUFDO1lBRTdDLE9BQU8sSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEVBQUU7Z0JBQ3ZGLElBQUksd0JBQXdCLEdBQUcsS0FBSyxDQUFDO2dCQUNyQyxJQUNFLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxNQUFNLEtBQUssbUJBQW1CO29CQUNyRCxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsTUFBTSxLQUFLLG1CQUFtQixFQUNyRDtvQkFDQSx3QkFBd0IsR0FBRyxJQUFJLENBQUM7aUJBQ2pDO2dCQUVELE9BQU87b0JBQ0wsVUFBVSxFQUFFLGtCQUFrQixJQUFJLHdCQUF3QjtvQkFDMUQsTUFBTSxFQUFFLGdCQUFnQjtpQkFDekIsQ0FBQztZQUNKLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUNGLENBQUM7UUFFRixJQUFJLENBQUMsS0FBSztRQUNSLCtDQUErQztRQUMvQyxxRUFBcUU7UUFDckUsa0JBQWtCLEVBQ2xCLENBQUMsSUFBSSxFQUFFLE9BQU8sRUFBRSxPQUFPLEVBQUUsU0FBUyxFQUFFLEVBQUU7WUFDcEMsT0FBTyw0QkFBNEIsQ0FBQyxJQUFJLEVBQUUsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ3RFLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFDL0MsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLEVBQ0QsQ0FBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxPQUFPLEVBQUUsU0FBUyxFQUFFLEVBQUU7WUFDNUMsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDLFNBQVMsRUFBRSxNQUFNLEVBQUUsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEVBQUU7Z0JBQ3hFLE9BQU8sS0FBSztxQkFDVCxJQUFJLENBQUMsSUFBSSxFQUFFLFNBQVMsRUFBRSxrQkFBa0IsRUFBRSxFQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUMsRUFBRSxnQkFBZ0IsQ0FBQztxQkFDL0UsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUM7WUFDOUIsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQ0YsQ0FBQztRQUVGLElBQUksQ0FBQyxLQUFLLENBQ1IsZUFBZSxFQUNmLENBQUMsSUFBSSxFQUFFLEdBQUcsRUFBRSxTQUFTLEVBQUUsT0FBTyxFQUFFLEVBQUU7WUFDaEMsT0FBTyw0QkFBNEIsQ0FBQyxJQUFJLEVBQUUsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ3RFLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLEVBQUUsR0FBRyxDQUFDLENBQUM7WUFDM0MsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLEVBQ0QsQ0FBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLEdBQUcsRUFBRSxTQUFTLEVBQUUsT0FBTyxFQUFFLEVBQUU7WUFDeEMsT0FBTyxRQUFRLENBQUMsS0FBSyxDQUFDO2dCQUNwQixTQUFTLEVBQUUsTUFBTSxDQUFDLFNBQVM7Z0JBQzNCLGVBQWUsRUFBRSxNQUFNLENBQUMsZUFBZTtnQkFDdkMsZUFBZSxFQUFFLE1BQU0sQ0FBQyxlQUFlO2dCQUN2QyxNQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07Z0JBQ3JCLE1BQU0sRUFBRSxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQXFELEVBQUU7b0JBQ3JGLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUU7d0JBQ2pDLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO3FCQUNwRDtvQkFDRCxPQUFPO2dCQUNULENBQUMsQ0FBQzthQUNILENBQUMsQ0FBQztRQUNMLENBQUMsQ0FDRixDQUFDO1FBRUYsSUFBSSxDQUFDLEtBQUssQ0FDUixZQUFZLEVBQ1osQ0FBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFO1lBQzFCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDeEQsQ0FBQyxFQUNELENBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsU0FBUyxFQUFFLEVBQUU7WUFDbEMsT0FBTyxLQUFLO2lCQUNULEtBQUssQ0FBQyxJQUFJLEVBQUUsU0FBUyxFQUFFLFlBQVksRUFBRTtnQkFDcEMsTUFBTSxFQUFFLE1BQU07YUFDZixDQUFDO2lCQUNELE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNwQixDQUFDLENBQ0YsQ0FBQztRQUVGLElBQUksQ0FBQyxLQUFLLENBQ1IsZUFBZSxFQUNmLEtBQUssRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDckIsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDcEQsTUFBTSxPQUFPLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBRXRELElBQUksT0FBTyxFQUFFO2dCQUNYLElBQUksTUFBTSxDQUFDLFVBQVUsRUFBRSxFQUFFO29CQUN2QixPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsaUJBQWlCLEVBQUUsdUNBQXVDLEVBQUUsSUFBSSxDQUFDLENBQUM7aUJBQ3hGO2dCQUVELElBQUksYUFBYSxFQUFFO29CQUNqQixPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsa0NBQWtDLEVBQUUsSUFBSSxDQUFDLENBQUM7aUJBQ2xGO2FBQ0Y7WUFFRCxNQUFNLENBQUMsY0FBYyxHQUFHLDRCQUE0QixDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7WUFFN0UsT0FBTyw0QkFBNEIsQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLFNBQVMsRUFBRSxNQUFNLENBQUMsQ0FBQztRQUN0RSxDQUFDLEVBQ0QsS0FBSyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDN0IsT0FBTyxLQUFLO2lCQUNULFNBQVMsQ0FDUixJQUFJLEVBQ0osTUFBTSxDQUFDLFNBQVMsRUFDaEIsVUFBVSxFQUNWLEVBQUMsS0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLLEVBQUUsT0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPLEVBQUMsRUFDOUMsTUFBTSxDQUNQO2lCQUNBLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNwQixDQUFDLENBQ0YsQ0FBQztRQUVGLElBQUksQ0FBQyxLQUFLLENBQ1Isd0JBQXdCLEVBQ3hCLEtBQUssRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDckIsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7WUFFcEQsTUFBTSxPQUFPLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBRXRELElBQUksQ0FBQyxPQUFPLEVBQUU7Z0JBQ1osTUFBTSxXQUFXLEdBQUcsTUFBTSxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxlQUFlLENBQUMsQ0FBQztnQkFDbEUsTUFBTSxXQUFXLENBQUMsU0FBUyxDQUFDLGNBQWMsRUFBRSxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7YUFDL0Q7aUJBQU07Z0JBQ0wsTUFBTSxXQUFXLEdBQUcsTUFBTSxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO2dCQUNuRSxNQUFNLFdBQVcsQ0FBQyxTQUFTLENBQUMsZUFBZSxFQUFFLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQztnQkFFL0QsSUFBSSxNQUFNLENBQUMsVUFBVSxFQUFFLEVBQUU7b0JBQ3ZCLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsRUFBRSx1Q0FBdUMsRUFBRSxJQUFJLENBQUMsQ0FBQztpQkFDeEY7Z0JBQ0QsSUFBSSxhQUFhLEVBQUU7b0JBQ2pCLDJGQUEyRjtvQkFDM0YsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDLGdCQUFnQixFQUFFLGtDQUFrQyxFQUFFLElBQUksQ0FBQyxDQUFDO2lCQUNsRjthQUNGO1lBRUQsTUFBTSxDQUFDLGNBQWMsR0FBRyw0QkFBNEIsQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBRTdFLE9BQU8sNEJBQTRCLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDdEUsQ0FBQyxFQUNELEtBQUssRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxFQUFFO1lBQzdCLE9BQU8sS0FBSztpQkFDVCxTQUFTLENBQ1IsSUFBSSxFQUNKLE1BQU0sQ0FBQyxTQUFTLEVBQ2hCLFVBQVUsRUFDVixFQUFDLEtBQUssRUFBRSxNQUFNLENBQUMsS0FBSyxFQUFFLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTyxFQUFDLEVBQzlDLE1BQU0sQ0FDUDtpQkFDQSxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDcEIsQ0FBQyxDQUNGLENBQUM7UUFFRixJQUFJLENBQUMsS0FBSyxDQUNSLGNBQWMsRUFDZCxLQUFLLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxFQUFFO1lBQ3RCLE1BQU0sSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLEVBQUUsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzFELENBQUMsRUFDRCxDQUFDLElBQUksRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLEVBQUU7WUFDeEIsT0FBTyxRQUFRLENBQUMsTUFBTSxDQUNwQixNQUFNLENBQUMsT0FBTyxFQUNkLENBQUMsZUFBZSxFQUFFLEtBQUssRUFBRSxFQUFFO2dCQUN6QixPQUFPLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFO29CQUM1RSxJQUFJLGFBQWEsQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTt3QkFDbEMsYUFBYSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUMsT0FBTyxDQUFDO3dCQUN0QyxlQUFlLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO3FCQUNyQztvQkFFRCxPQUFPLGVBQWUsQ0FBQztnQkFDekIsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDLEVBQ0QsRUFJRSxDQUNILENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUMsQ0FBQyxDQUFDLENBQUM7UUFDMUMsQ0FBQyxDQUNGLENBQUM7UUFFRixJQUFJLENBQUMsS0FBSyxDQUFDLGNBQWMsRUFBRSxDQUFDLElBQUksRUFBRSxTQUFTLEVBQUUsRUFBRTtZQUM3QyxPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNsQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDbkMsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxLQUFLLENBQ1IsU0FBUyxFQUNULENBQUMsSUFBSSxFQUFFLE9BQU8sRUFBRSxFQUFFO1lBQ2hCLE9BQU8sNEJBQTRCLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDeEUsQ0FBQyxFQUNELENBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsRUFBRTtZQUN4QixPQUFPLElBQUk7aUJBQ1IsY0FBYyxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsTUFBTSxFQUFFO2dCQUN6Qyx1QkFBdUIsRUFBRSxJQUFJO2FBQzlCLENBQUM7aUJBQ0QsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEVBQUU7Z0JBQ3ZCLE9BQU8sS0FBSztxQkFDVCxJQUFJLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxTQUFTLEVBQUUsU0FBUyxFQUFFLEVBQUMsRUFBRSxFQUFFLE9BQU8sQ0FBQyxFQUFFLEVBQUMsRUFBRSxnQkFBZ0IsQ0FBQztxQkFDNUUsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUM7WUFDOUIsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLENBQ0YsQ0FBQztRQUVGLElBQUksQ0FBQyxLQUFLLENBQ1IsWUFBWSxFQUNaLENBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsRUFBRTtZQUMxQixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ3hELENBQUMsRUFDRCxDQUFDLElBQUksRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFO1lBQ2xDLE9BQU8sS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsU0FBUyxFQUFFLFlBQVksRUFBRSxFQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNyRixDQUFDLENBQ0YsQ0FBQztRQUVGLElBQUksQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLEVBQUUsU0FBUyxFQUFFLENBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsRUFBRTtZQUNoRSxPQUFPLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxVQUFVLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDL0UsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsS0FBSyxDQUFDLGlCQUFpQixFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDbkQsTUFBTSxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxlQUFlLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDcEQsTUFBTSxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsRUFBRSxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDekQsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0NBQ0Y7QUFFRCxTQUFTLDRCQUE0QixDQUNuQyxJQUFpQixFQUNqQixTQUFpQjtJQUVqQixPQUFPLEtBQUssRUFBRSxRQUE2QixFQUF1QyxFQUFFO1FBQ2xGLElBQUksUUFBUSxDQUFDLEtBQUssQ0FBQyxNQUFNLEtBQUssQ0FBQyxJQUFJLFFBQVEsQ0FBQyxLQUFLLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUM5RCxPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7U0FDbEM7UUFFRCxPQUFPLElBQUk7YUFDUixjQUFjLENBQUMsU0FBUyxFQUFFLFFBQVEsRUFBRTtZQUNuQyxZQUFZLEVBQUUsSUFBSTtTQUNuQixDQUFDO2FBQ0QsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEVBQUU7WUFDdkIsSUFBSSxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsTUFBTSxLQUFLLENBQUMsSUFBSSxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtnQkFDOUUsT0FBTyxJQUFJLENBQUM7YUFDYjtZQUNELE9BQU8sZ0JBQWdCLENBQUM7UUFDMUIsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDLENBQUM7QUFDSixDQUFDO0FBRUQ7O0dBRUc7QUFDSCxLQUFLLFVBQVUsNEJBQTRCLENBQ3pDLElBQWlCLEVBQ2pCLFNBQWlCLEVBQ2pCLE9BQWtFO0lBRWxFLE1BQU0sQ0FBQyxrQkFBa0IsRUFBRSxhQUFhLEVBQUUsVUFBVSxFQUFFLFVBQVUsQ0FBQyxHQUFHLE1BQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQztRQUNwRixJQUFJLENBQUMsa0JBQWtCLENBQUMsU0FBUyxDQUFDO1FBQ2xDLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDO1FBQzdCLFdBQVcsQ0FBQyxTQUFTLENBQUMsU0FBUyxFQUFFLHdCQUFVLENBQUMsSUFBSSxDQUFDO1FBQ2pELFdBQVcsQ0FBQyxTQUFTLENBQUMsU0FBUyxFQUFFLHdCQUFVLENBQUMsSUFBSSxDQUFDO0tBQ2xELENBQUMsQ0FBQztJQUVILElBQUksbUJBQW1CLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQ2hELEtBQUssQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUUsQ0FBQyxVQUFVLEtBQUssNEJBQWMsQ0FBQyxJQUFJLENBQ25FLENBQUM7SUFFRixJQUFJLGNBQWMsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FDM0MsS0FBSyxDQUFDLEVBQUUsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBRSxDQUFDLFVBQVUsS0FBSyw0QkFBYyxDQUFDLElBQUksQ0FDbkUsQ0FBQztJQUVGLElBQUksa0JBQWtCLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxFQUFFO1FBQ2pDLG1CQUFtQixHQUFHLENBQUMsQ0FBQyxZQUFZLENBQUMsa0JBQWtCLEVBQUUsbUJBQW1CLENBQUMsQ0FBQztLQUMvRTtJQUVELElBQUksYUFBYSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRTtRQUM1QixjQUFjLEdBQUcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxhQUFhLEVBQUUsY0FBYyxDQUFDLENBQUM7S0FDaEU7SUFFRCxPQUFPLENBQUMsa0JBQWtCLEdBQUcsbUJBQW1CLENBQUM7SUFDakQsT0FBTyxDQUFDLGFBQWEsR0FBRyxjQUFjLENBQUM7QUFDekMsQ0FBQztBQUVELGlCQUFTLElBQUksZ0JBQWdCLEVBQUUsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMifQ==