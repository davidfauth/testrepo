"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-12-02.
 */
const Bluebird = require("bluebird");
const LkError_1 = require("../../models/errors/LkError");
class ErrorService {
    /**
     * To access the LkError constructor directly.
     */
    get LkError() {
        return LkError_1.LkError;
    }
    /**
     * @param error
     * @param [promise] Whether to return a rejected promise or just the error
     */
    wrap(error, promise) {
        // return a rejected promise
        if (promise === true) {
            return Bluebird.reject(error);
        }
        // or just the error
        return error;
    }
    access(key, message, promise) {
        return this.wrap(new LkError_1.LkError(LkError_1.LkError.Type.ACCESS, key, message), promise);
    }
    business(key, message, promise, data) {
        return this.wrap(new LkError_1.LkError(LkError_1.LkError.Type.BUSINESS, key, message, data), promise);
    }
    technical(key, message, promise) {
        return this.wrap(new LkError_1.LkError(LkError_1.LkError.Type.TECHNICAL, key, message), promise);
    }
}
module.exports = new ErrorService();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvZXJyb3JzL2luZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRztBQUNILHFDQUFxQztBQUVyQyx5REFBb0Q7QUFFcEQsTUFBTSxZQUFZO0lBQ2hCOztPQUVHO0lBQ0gsSUFBSSxPQUFPO1FBQ1QsT0FBTyxpQkFBTyxDQUFDO0lBQ2pCLENBQUM7SUFFRDs7O09BR0c7SUFDSyxJQUFJLENBQUMsS0FBYyxFQUFFLE9BQWlCO1FBQzVDLDRCQUE0QjtRQUM1QixJQUFJLE9BQU8sS0FBSyxJQUFJLEVBQUU7WUFDcEIsT0FBTyxRQUFRLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQy9CO1FBRUQsb0JBQW9CO1FBQ3BCLE9BQU8sS0FBSyxDQUFDO0lBQ2YsQ0FBQztJQVdNLE1BQU0sQ0FBQyxHQUFXLEVBQUUsT0FBZ0IsRUFBRSxPQUFpQjtRQUM1RCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxpQkFBTyxDQUFDLGlCQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLEVBQUUsT0FBTyxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFDNUUsQ0FBQztJQVlNLFFBQVEsQ0FDYixHQUFXLEVBQ1gsT0FBZ0IsRUFDaEIsT0FBaUIsRUFDakIsSUFBYztRQUVkLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLGlCQUFPLENBQUMsaUJBQU8sQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLEdBQUcsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFDcEYsQ0FBQztJQVdNLFNBQVMsQ0FBQyxHQUFXLEVBQUUsT0FBZ0IsRUFBRSxPQUFpQjtRQUMvRCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxpQkFBTyxDQUFDLGlCQUFPLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxHQUFHLEVBQUUsT0FBTyxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFDL0UsQ0FBQztDQUNGO0FBRUQsaUJBQVMsSUFBSSxZQUFZLEVBQUUsQ0FBQyJ9