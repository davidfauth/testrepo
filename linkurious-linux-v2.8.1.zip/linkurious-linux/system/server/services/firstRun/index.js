"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2015-05-05.
 */
const crypto = require("crypto");
const Bluebird = require("bluebird");
const LKE = require("../index");
const Config = LKE.getConfig();
const Log = LKE.getLogger(__filename);
class FirstRun {
    /**
     * Check if this is the first run. Run 'setup' in case of fist run.
     */
    check() {
        if (Config.get('firstRun', true)) {
            return this.setup().then(() => {
                return Config.set('firstRun', false);
            });
        }
        return Bluebird.resolve();
    }
    setup() {
        Log.info('First run, initialization ...');
        return Bluebird.all([
            // init steps (add new steps to array)
            this.initCookieSecret()
        ]).return();
    }
    initCookieSecret() {
        return new Bluebird((resolve, reject) => {
            crypto.randomBytes(32, (ex, buf) => {
                const token = buf.toString('hex');
                Config.set('server.cookieSecret', token).then(resolve, reject);
            });
        });
    }
}
module.exports = new FirstRun();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvZmlyc3RSdW4vaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7OztHQUtHO0FBQ0gsaUNBQWlDO0FBRWpDLHFDQUFxQztBQUNyQyxnQ0FBaUM7QUFDakMsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7QUFFdEMsTUFBTSxRQUFRO0lBQ1o7O09BRUc7SUFDSSxLQUFLO1FBQ1YsSUFBSSxNQUFNLENBQUMsR0FBRyxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsRUFBRTtZQUNoQyxPQUFPLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUM1QixPQUFPLE1BQU0sQ0FBQyxHQUFHLENBQUMsVUFBVSxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQ3ZDLENBQUMsQ0FBQyxDQUFDO1NBQ0o7UUFDRCxPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQztJQUM1QixDQUFDO0lBRU8sS0FBSztRQUNYLEdBQUcsQ0FBQyxJQUFJLENBQUMsK0JBQStCLENBQUMsQ0FBQztRQUMxQyxPQUFPLFFBQVEsQ0FBQyxHQUFHLENBQUM7WUFDbEIsc0NBQXNDO1lBQ3RDLElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtTQUN4QixDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7SUFDZCxDQUFDO0lBRU8sZ0JBQWdCO1FBQ3RCLE9BQU8sSUFBSSxRQUFRLENBQUMsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDdEMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLEVBQUUsR0FBRyxFQUFFLEVBQUU7Z0JBQ2pDLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ2xDLE1BQU0sQ0FBQyxHQUFHLENBQUMscUJBQXFCLEVBQUUsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsQ0FBQztZQUNqRSxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGO0FBRUQsaUJBQVMsSUFBSSxRQUFRLEVBQUUsQ0FBQyJ9