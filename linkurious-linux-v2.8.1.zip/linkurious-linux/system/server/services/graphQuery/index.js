"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-01-23.
 */
const Bluebird = require("bluebird");
const umd_1 = require("linkurious-shared/umd");
const _ = require("lodash");
const graphQueryDAO_1 = require("../../dao/sql/graphQueryDAO");
const groupDAO_1 = require("../../dao/sql/groupDAO");
const graphQueryResponses_1 = require("../../models/apiResponses/graphQueryResponses");
const Bug_1 = require("../../models/errors/Bug");
const CantReadError_1 = require("../../models/errors/CantReadError");
const MalformedQueryTemplate_1 = require("../../models/errors/MalformedQueryTemplate");
const NotFoundError_1 = require("../../models/errors/NotFoundError");
const NotOwnerError_1 = require("../../models/errors/NotOwnerError");
const graphQueryParams_1 = require("../../models/parameters/graphQueryParams");
const LKE = require("../index");
const builtinQueries_1 = require("./builtinQueries");
const Access = LKE.getAccess();
const Utils = LKE.getUtils();
const Log = LKE.getLogger(__filename);
const Data = LKE.getData();
const DataProxy = LKE.getDataProxy();
const Db = LKE.getSqlDb();
// TODO #1507 add tests for shared queries with groups
// TODO #1569 Add BuiltQueries unit tests
class GraphQueryService {
    constructor() {
        this.graphQueryDAO = new graphQueryDAO_1.GraphQueryDAO();
        this.groupDAO = new groupDAO_1.GroupDAO();
        this.queryTemplateParser = new umd_1.QueryTemplateParser((validationMessage, highlight) => {
            throw new MalformedQueryTemplate_1.MalformedQueryTemplate(validationMessage, highlight);
        }, (bugMessage) => {
            throw new Bug_1.Bug(bugMessage);
        });
        this.builtinQueryCache = new Map();
    }
    /**
     * Create a graph query for user.
     */
    async createGraphQuery(params, user) {
        const currentUser = await Access.checkAuth(user, 'savedGraphQuery.create');
        const source = Data.resolveSource(params.sourceKey);
        const dialect = _.get(source.graph.features, 'dialects.0');
        const isWrite = source.graph.isWrite(params.content);
        if (!isWrite) {
            await currentUser.hasAction('rawReadQuery', params.sourceKey);
        }
        else {
            await currentUser.hasAction('rawWriteQuery', params.sourceKey);
        }
        let queryType = graphQueryParams_1.GraphQueryType.STATIC;
        let templateFields;
        if (umd_1.QueryTemplateParser.isTemplate(params.content)) {
            queryType = graphQueryParams_1.GraphQueryType.TEMPLATE;
            templateFields = this.queryTemplateParser.parse(params.content);
        }
        const graphQueryInstance = await this.graphQueryDAO.createGraphQuery({
            sourceKey: params.sourceKey,
            name: params.name,
            content: params.content,
            dialect: dialect,
            description: params.description,
            sharing: params.sharing,
            type: queryType,
            templateFields: templateFields
        }, currentUser.id);
        let groupInstances;
        if (Utils.hasValue(params.sharedWithGroups)) {
            groupInstances = await this.groupDAO.getGroups(params.sourceKey, params.sharedWithGroups);
            Utils.checkMissing('group', params.sharedWithGroups, groupInstances);
            await this.graphQueryDAO.shareGraphQueryWithGroups(graphQueryInstance, groupInstances);
        }
        return graphQueryResponses_1.GraphQueryResponse.fromInstance(graphQueryInstance, true, isWrite, groupInstances);
    }
    /**
     * Get all the graph queries owned by user or shared with it.
     */
    async getAllGraphQueries(params, user) {
        const currentUser = await Access.checkAuth(user, 'savedGraphQuery.read', true);
        await currentUser.hasAction('runQuery', params.sourceKey);
        const source = Data.resolveSource(params.sourceKey);
        const graphQueriesFromSource = await this.graphQueryDAO.getGraphQueriesSharedWithSource(params.sourceKey);
        const graphQueriesOwned = await this.graphQueryDAO.getGraphQueriesOwnedByUser(params.sourceKey, currentUser.id);
        const graphQueriesFromGroups = await this.graphQueryDAO.getGraphQueriesSharedWithGroups(params.sourceKey, _.map(currentUser.groups, 'id'));
        let readableGraphQueries = _.unionBy(graphQueriesOwned, graphQueriesFromSource, graphQueriesFromGroups, 'id');
        let builtinGraphQueries = this.getBuiltinQueries(params.sourceKey);
        if (Utils.hasValue(params.type)) {
            readableGraphQueries = _.filter(readableGraphQueries, query => query.type === params.type);
            builtinGraphQueries = _.filter(builtinGraphQueries, query => query.type === params.type);
        }
        return Promise.all(_.map(readableGraphQueries, async (graphQueryInstance) => {
            const isOwner = this.graphQueryDAO.isOwner(graphQueryInstance, currentUser.id);
            let groupInstances;
            if (await this.graphQueryDAO.isSharedWithGroups(graphQueryInstance)) {
                groupInstances = await this.graphQueryDAO.getGraphQueryGroups(graphQueryInstance);
            }
            const isWrite = source.graph.isWrite(graphQueryInstance.content);
            return graphQueryResponses_1.GraphQueryResponse.fromInstance(graphQueryInstance, isOwner, isWrite, groupInstances);
        })).then(savedGraphQueries => _.concat(savedGraphQueries, builtinGraphQueries));
    }
    /**
     * Generate the negative hashCode of a string.
     */
    negativeHashCode(s) {
        let hash = 0;
        if (s.length === 0) {
            return hash;
        }
        for (let i = 0; i < s.length; i++) {
            const char = s.charCodeAt(i);
            hash = (hash << 5) - hash + char;
            // convert to 32bit integer
            hash = hash & hash;
        }
        return hash < 0 ? hash : -hash;
    }
    /**
     * Return true if `version` is between `minVersion` and `maxVersion`.
     * Returns true if `version` is `[unknown]`
     *
     * @param version    semVer
     * @param minVersion earliest semVer
     * @param maxVersion latest semVer
     */
    matchVersion(version, minVersion, maxVersion) {
        if (version === '[unknown]') {
            return true;
        }
        let matchMinVersion = true;
        if (minVersion) {
            matchMinVersion = Utils.compareSemVer(version, minVersion) >= 0;
        }
        let matchMaxVersion = true;
        if (maxVersion) {
            matchMaxVersion = Utils.compareSemVer(version, maxVersion) <= 0;
        }
        return matchMinVersion && matchMaxVersion;
    }
    /**
     * Get all builtin queries for a given source.
     */
    getBuiltinQueries(sourceKey) {
        const cachedQueries = this.builtinQueryCache.get(sourceKey);
        if (Utils.hasValue(cachedQueries)) {
            return cachedQueries;
        }
        const source = Data.resolveSource(sourceKey);
        const computedIds = new Set();
        const compatibleQueries = builtinQueries_1.default.all.filter(builtinQuery => {
            return _.some(builtinQuery.compatibleDAOs, ({ graphDAO, firstVersion, lastVersion }) => {
                return (graphDAO === source.graph.vendor &&
                    this.matchVersion(source.graphVersion, firstVersion, lastVersion));
            });
        });
        const builtinGraphQueries = compatibleQueries.map((query) => {
            const type = umd_1.QueryTemplateParser.isTemplate(query.content)
                ? graphQueryParams_1.GraphQueryType.TEMPLATE
                : graphQueryParams_1.GraphQueryType.STATIC;
            const builtinQuery = {
                // we compute negative ids from the key to avoid conflicts with regular queries that have positive ids.
                id: this.negativeHashCode(query.key),
                sourceKey: sourceKey,
                type: type,
                write: source.graph.isWrite(query.content),
                name: query.name,
                content: query.content,
                dialect: query.dialect,
                description: query.description
            };
            if (computedIds.has(builtinQuery.id)) {
                Log.warn(`A builtin query with id ${builtinQuery.id} was already added.`);
            }
            computedIds.add(builtinQuery.id);
            if (type === graphQueryParams_1.GraphQueryType.TEMPLATE) {
                builtinQuery.templateFields = this.queryTemplateParser.parse(query.content);
                builtinQuery.graphInput = umd_1.QueryTemplateParser.getInputType(builtinQuery.templateFields);
            }
            return graphQueryResponses_1.GraphQueryResponse.fromBuiltin(builtinQuery);
        });
        this.builtinQueryCache.set(sourceKey, builtinGraphQueries);
        return builtinGraphQueries;
    }
    /**
     * Find a builtin query by Id.
     */
    findBuiltinQueryById(sourceKey, id) {
        return _.find(this.getBuiltinQueries(sourceKey), ['id', id]);
    }
    /**
     * Get a graph query owned by user or shared with it.
     */
    async getGraphQuery(params, user) {
        const currentUser = await Access.checkAuth(user, 'savedGraphQuery.read', true);
        await currentUser.hasAction('runQuery', params.sourceKey);
        const source = Data.resolveSource(params.sourceKey);
        const builtinQuery = this.findBuiltinQueryById(params.sourceKey, params.id);
        if (Utils.hasValue(builtinQuery)) {
            return builtinQuery;
        }
        const graphQueryInstance = await this.graphQueryDAO.getGraphQuery(params.id);
        if (Utils.noValue(graphQueryInstance)) {
            throw new NotFoundError_1.NotFoundError('query', params.id);
        }
        const isOwner = this.graphQueryDAO.isOwner(graphQueryInstance, currentUser.id);
        const isSharedWithDataSource = this.graphQueryDAO.isSharedWithDataSource(graphQueryInstance, params.sourceKey);
        const isSharedWithGroups = await this.graphQueryDAO.isSharedWithGroups(graphQueryInstance, _.map(currentUser.groups, 'id'));
        if (!isOwner && !isSharedWithDataSource && !isSharedWithGroups) {
            throw new CantReadError_1.CantReadError('query', params.id, currentUser.id);
        }
        let groupInstances;
        if (await this.graphQueryDAO.isSharedWithGroups(graphQueryInstance)) {
            groupInstances = await this.graphQueryDAO.getGraphQueryGroups(graphQueryInstance);
        }
        const isWrite = source.graph.isWrite(graphQueryInstance.content);
        return graphQueryResponses_1.GraphQueryResponse.fromInstance(graphQueryInstance, isOwner, isWrite, groupInstances);
    }
    /**
     * Get all the nodes and edges matching the given saved graph query by ID.
     */
    async runGraphQueryById(params, user) {
        const currentUser = await Access.checkAuth(user, 'graph.runQuery', true);
        // TODO remove @ts-ignore once the interfaces IGetGraphQueryParams and IRunGraphQueryByContentParams are defined on the rest-client
        // @ts-ignore
        const query = await this.getGraphQuery(params, currentUser);
        // @ts-ignore
        return DataProxy.runGraphQuery(_.merge(params, { query: query.content }), currentUser);
    }
    /**
     * Delete a graph query owned by user.
     */
    async deleteGraphQuery(params, user) {
        const currentUser = await Access.checkAuth(user, 'savedGraphQuery.delete');
        const graphQueryInstance = await this.graphQueryDAO.getGraphQuery(params.id);
        if (Utils.noValue(graphQueryInstance)) {
            throw new NotFoundError_1.NotFoundError('query', params.id);
        }
        const isOwner = this.graphQueryDAO.isOwner(graphQueryInstance, currentUser.id);
        if (!isOwner) {
            throw new NotOwnerError_1.NotOwnerError('query', params.id, currentUser.id);
        }
        return this.graphQueryDAO.deleteGraphQuery(graphQueryInstance);
    }
    /**
     * Update a graph query owned by user.
     */
    async updateGraphQuery(params, user) {
        // 1) Check if the user is authenticated, and, if an application
        // acts on behalf of the user, if it has the correct API right
        const currentUser = await Access.checkAuth(user, 'savedGraphQuery.edit');
        const source = Data.resolveSource(params.sourceKey);
        // 2) Retrieve the query
        let graphQueryInstance = await this.graphQueryDAO.getGraphQuery(params.id);
        if (Utils.noValue(graphQueryInstance)) {
            throw new NotFoundError_1.NotFoundError('query', params.id);
        }
        const updatedFields = {
            name: params.name,
            content: params.content,
            dialect: params.dialect,
            description: params.description,
            sharing: params.sharing
        };
        // 3) If the content has changed, re-parse the query
        if (Utils.hasValue(params.content)) {
            const isNewWrite = source.graph.isWrite(params.content);
            if (!isNewWrite) {
                await currentUser.hasAction('rawReadQuery', params.sourceKey);
            }
            else {
                await currentUser.hasAction('rawWriteQuery', params.sourceKey);
            }
            let queryType = graphQueryParams_1.GraphQueryType.STATIC;
            let templateFields;
            if (umd_1.QueryTemplateParser.isTemplate(params.content)) {
                queryType = graphQueryParams_1.GraphQueryType.TEMPLATE;
                templateFields = this.queryTemplateParser.parse(params.content);
            }
            updatedFields.type = queryType;
            updatedFields.templateFields = templateFields;
        }
        // 4) Check if the user is the owner of the query
        const isOwner = this.graphQueryDAO.isOwner(graphQueryInstance, currentUser.id);
        if (!isOwner) {
            throw new NotOwnerError_1.NotOwnerError('query', params.id, currentUser.id);
        }
        // 5) Update the query <-> groups associations
        let groupInstances;
        if (Utils.hasValue(params.sharing)) {
            await this.graphQueryDAO.unshareGraphQueryWithAllGroups(graphQueryInstance);
            if (Utils.hasValue(params.sharedWithGroups)) {
                groupInstances = await this.groupDAO.getGroups(params.sourceKey, params.sharedWithGroups);
                Utils.checkMissing('group', params.sharedWithGroups, groupInstances);
                await this.graphQueryDAO.shareGraphQueryWithGroups(graphQueryInstance, groupInstances);
            }
        }
        // 6) Update the query attributes
        graphQueryInstance = await this.graphQueryDAO.updateGraphQuery(graphQueryInstance, updatedFields);
        // 7) Get the groups which the graph query is shared with
        if ((await this.graphQueryDAO.isSharedWithGroups(graphQueryInstance)) &&
            Utils.noValue(groupInstances)) {
            groupInstances = await this.graphQueryDAO.getGraphQueryGroups(graphQueryInstance);
        }
        const isWrite = source.graph.isWrite(graphQueryInstance.content);
        // 8) Return a GraphQueryResponse
        return graphQueryResponses_1.GraphQueryResponse.fromInstance(graphQueryInstance, true, isWrite, groupInstances);
    }
    /**
     * Duplicate legacy static queries to all the data-sources where the dialect matches.
     * A legacy static query is a query that, originally, was saved for multiple data-sources.
     */
    migrateRawQueries(dataSourceStates) {
        // TODO move this code in the migration service
        // 1) find all configured data-sources
        const sourceStates = dataSourceStates.filter(source => Utils.hasValue(source.key));
        // 2) find all graph queries with no source key (legacy static queries)
        return Promise.resolve().then(() => {
            return (Db.models.graphQuery
                .findAll({ where: { sourceKey: '*' } })
                .then(staticQueries => {
                // compute the list of source keys for every dialect
                // @ts-ignore
                const sourcesByDialect = _.groupBy(sourceStates, source => source.features.dialects[0]);
                // 3) duplicate the GraphQuery instance for each data-source that supports its dialect
                return Bluebird.map(staticQueries, query => {
                    const sourcesWithQueryDialect = sourcesByDialect[query.get('dialect')];
                    // if the list is empty, duplicate the GraphQuery for every known sourceKey
                    if (Utils.noValue(sourcesWithQueryDialect)) {
                        // @ts-ignore
                        return this._migrateQuery(query, sourceStates.map(source => source.key));
                    }
                    // duplicate the query for each sourceKey that supports it's dialect
                    // @ts-ignore
                    return this._migrateQuery(query, sourcesWithQueryDialect.map(source => source.key));
                }).then(duplicates => _.flatten(duplicates));
            })
                // @ts-ignore
                .then(duplicatedQueries => {
                if (duplicatedQueries.length > 0) {
                    return Db.models.graphQuery.bulkCreate(duplicatedQueries);
                }
            })
                .return());
        });
    }
    _migrateQuery(query, sourceKeys) {
        const newGraphQueries = sourceKeys.map(key => _.merge({
            sourceKey: key,
            name: '',
            type: graphQueryParams_1.GraphQueryType.STATIC,
            sharing: graphQueryParams_1.GraphQuerySharingMode.PRIVATE
        }, _.pick(query, ['name', 'content', 'dialect', 'userId'])));
        return query.destroy().return(newGraphQueries);
    }
    migrateQueriesToV2() {
        // TODO move this code in the migration service
        return Promise.resolve().then(() => {
            return Db.models.graphQuery
                .findAll({ where: { version: 1 } })
                .map((query) => {
                try {
                    let queryType = graphQueryParams_1.GraphQueryType.STATIC;
                    let templateFields;
                    if (umd_1.QueryTemplateParser.isTemplate(query.content)) {
                        queryType = graphQueryParams_1.GraphQueryType.TEMPLATE;
                        templateFields = this.queryTemplateParser.parse(query.content);
                    }
                    query.type = queryType;
                    query.templateFields = templateFields;
                    query.version = 2;
                    return query.save().return();
                }
                catch (e) {
                    Log.warn('Failed to migrate query #' +
                        query.id +
                        ': ' +
                        query.content +
                        ' . Reason: ' +
                        e.message);
                }
                return Bluebird.resolve();
            }, { concurrency: 1 })
                .return();
        });
    }
}
module.exports = new GraphQueryService();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvZ3JhcGhRdWVyeS9pbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7O0dBS0c7QUFDSCxxQ0FBcUM7QUFDckMsK0NBQTBEO0FBQzFELDRCQUE0QjtBQUU1QiwrREFBMEQ7QUFDMUQscURBQWdEO0FBQ2hELHVGQUd1RDtBQUV2RCxpREFBNEM7QUFDNUMscUVBQWdFO0FBQ2hFLHVGQUFrRjtBQUNsRixxRUFBZ0U7QUFDaEUscUVBQWdFO0FBRWhFLCtFQU9rRDtBQUlsRCxnQ0FBaUM7QUFDakMscURBQXNGO0FBQ3RGLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxHQUFHLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUN0QyxNQUFNLElBQUksR0FBRyxHQUFHLENBQUMsT0FBTyxFQUFFLENBQUM7QUFDM0IsTUFBTSxTQUFTLEdBQUcsR0FBRyxDQUFDLFlBQVksRUFBRSxDQUFDO0FBQ3JDLE1BQU0sRUFBRSxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUUxQixzREFBc0Q7QUFDdEQseUNBQXlDO0FBRXpDLE1BQU0saUJBQWlCO0lBTXJCO1FBQ0UsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLDZCQUFhLEVBQUUsQ0FBQztRQUN6QyxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksbUJBQVEsRUFBRSxDQUFDO1FBRS9CLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxJQUFJLHlCQUFtQixDQUNoRCxDQUFDLGlCQUF5QixFQUFFLFNBQTBCLEVBQUUsRUFBRTtZQUN4RCxNQUFNLElBQUksK0NBQXNCLENBQUMsaUJBQWlCLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFDakUsQ0FBQyxFQUNELENBQUMsVUFBa0IsRUFBRSxFQUFFO1lBQ3JCLE1BQU0sSUFBSSxTQUFHLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDNUIsQ0FBQyxDQUNGLENBQUM7UUFFRixJQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxHQUFHLEVBQWlDLENBQUM7SUFDcEUsQ0FBQztJQUVEOztPQUVHO0lBQ0ksS0FBSyxDQUFDLGdCQUFnQixDQUMzQixNQUE4QixFQUM5QixJQUFrQjtRQUVsQixNQUFNLFdBQVcsR0FBRyxNQUFNLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLHdCQUF3QixDQUFDLENBQUM7UUFFM0UsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7UUFFcEQsTUFBTSxPQUFPLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRSxZQUFZLENBQUMsQ0FBQztRQUMzRCxNQUFNLE9BQU8sR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFckQsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE1BQU0sV0FBVyxDQUFDLFNBQVMsQ0FBQyxjQUFjLEVBQUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1NBQy9EO2FBQU07WUFDTCxNQUFNLFdBQVcsQ0FBQyxTQUFTLENBQUMsZUFBZSxFQUFFLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQztTQUNoRTtRQUVELElBQUksU0FBUyxHQUFtQixpQ0FBYyxDQUFDLE1BQU0sQ0FBQztRQUN0RCxJQUFJLGNBQWMsQ0FBQztRQUNuQixJQUFJLHlCQUFtQixDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDbEQsU0FBUyxHQUFHLGlDQUFjLENBQUMsUUFBUSxDQUFDO1lBQ3BDLGNBQWMsR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztTQUNqRTtRQUVELE1BQU0sa0JBQWtCLEdBQUcsTUFBTSxJQUFJLENBQUMsYUFBYSxDQUFDLGdCQUFnQixDQUNsRTtZQUNFLFNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUztZQUMzQixJQUFJLEVBQUUsTUFBTSxDQUFDLElBQUk7WUFDakIsT0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPO1lBQ3ZCLE9BQU8sRUFBRSxPQUFPO1lBQ2hCLFdBQVcsRUFBRSxNQUFNLENBQUMsV0FBVztZQUMvQixPQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU87WUFDdkIsSUFBSSxFQUFFLFNBQVM7WUFDZixjQUFjLEVBQUUsY0FBYztTQUMvQixFQUNELFdBQVcsQ0FBQyxFQUFFLENBQ2YsQ0FBQztRQUVGLElBQUksY0FBYyxDQUFDO1FBQ25CLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsRUFBRTtZQUMzQyxjQUFjLEdBQUcsTUFBTSxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1lBQzFGLEtBQUssQ0FBQyxZQUFZLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxnQkFBZ0IsRUFBRSxjQUFjLENBQUMsQ0FBQztZQUVyRSxNQUFNLElBQUksQ0FBQyxhQUFhLENBQUMseUJBQXlCLENBQUMsa0JBQWtCLEVBQUUsY0FBYyxDQUFDLENBQUM7U0FDeEY7UUFFRCxPQUFPLHdDQUFrQixDQUFDLFlBQVksQ0FBQyxrQkFBa0IsRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLGNBQWMsQ0FBQyxDQUFDO0lBQzVGLENBQUM7SUFFRDs7T0FFRztJQUNJLEtBQUssQ0FBQyxrQkFBa0IsQ0FDN0IsTUFBZ0MsRUFDaEMsSUFBa0I7UUFFbEIsTUFBTSxXQUFXLEdBQUcsTUFBTSxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxzQkFBc0IsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUUvRSxNQUFNLFdBQVcsQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUUxRCxNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUVwRCxNQUFNLHNCQUFzQixHQUFHLE1BQU0sSUFBSSxDQUFDLGFBQWEsQ0FBQywrQkFBK0IsQ0FDckYsTUFBTSxDQUFDLFNBQVMsQ0FDakIsQ0FBQztRQUVGLE1BQU0saUJBQWlCLEdBQUcsTUFBTSxJQUFJLENBQUMsYUFBYSxDQUFDLDBCQUEwQixDQUMzRSxNQUFNLENBQUMsU0FBUyxFQUNoQixXQUFXLENBQUMsRUFBRSxDQUNmLENBQUM7UUFFRixNQUFNLHNCQUFzQixHQUFHLE1BQU0sSUFBSSxDQUFDLGFBQWEsQ0FBQywrQkFBK0IsQ0FDckYsTUFBTSxDQUFDLFNBQVMsRUFDaEIsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUNoQyxDQUFDO1FBRUYsSUFBSSxvQkFBb0IsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUNsQyxpQkFBaUIsRUFDakIsc0JBQXNCLEVBQ3RCLHNCQUFzQixFQUN0QixJQUFJLENBQ0wsQ0FBQztRQUVGLElBQUksbUJBQW1CLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUVuRSxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQy9CLG9CQUFvQixHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxLQUFLLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUMzRixtQkFBbUIsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLG1CQUFtQixFQUFFLEtBQUssQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksS0FBSyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDMUY7UUFFRCxPQUFPLE9BQU8sQ0FBQyxHQUFHLENBQ2hCLENBQUMsQ0FBQyxHQUFHLENBQUMsb0JBQW9CLEVBQUUsS0FBSyxFQUFDLGtCQUFrQixFQUFDLEVBQUU7WUFDckQsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLEVBQUUsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQy9FLElBQUksY0FBYyxDQUFDO1lBQ25CLElBQUksTUFBTSxJQUFJLENBQUMsYUFBYSxDQUFDLGtCQUFrQixDQUFDLGtCQUFrQixDQUFDLEVBQUU7Z0JBQ25FLGNBQWMsR0FBRyxNQUFNLElBQUksQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsa0JBQWtCLENBQUMsQ0FBQzthQUNuRjtZQUVELE1BQU0sT0FBTyxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ2pFLE9BQU8sd0NBQWtCLENBQUMsWUFBWSxDQUNwQyxrQkFBa0IsRUFDbEIsT0FBTyxFQUNQLE9BQU8sRUFDUCxjQUFjLENBQ2YsQ0FBQztRQUNKLENBQUMsQ0FBQyxDQUNILENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGlCQUFpQixFQUFFLG1CQUFtQixDQUFDLENBQUMsQ0FBQztJQUNoRixDQUFDO0lBRUQ7O09BRUc7SUFDSyxnQkFBZ0IsQ0FBQyxDQUFTO1FBQ2hDLElBQUksSUFBSSxHQUFHLENBQUMsQ0FBQztRQUViLElBQUksQ0FBQyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFDbEIsT0FBTyxJQUFJLENBQUM7U0FDYjtRQUVELEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ2pDLE1BQU0sSUFBSSxHQUFHLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDN0IsSUFBSSxHQUFHLENBQUMsSUFBSSxJQUFJLENBQUMsQ0FBQyxHQUFHLElBQUksR0FBRyxJQUFJLENBQUM7WUFDakMsMkJBQTJCO1lBQzNCLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDO1NBQ3BCO1FBRUQsT0FBTyxJQUFJLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0lBQ2pDLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0ssWUFBWSxDQUFDLE9BQWUsRUFBRSxVQUFtQixFQUFFLFVBQW1CO1FBQzVFLElBQUksT0FBTyxLQUFLLFdBQVcsRUFBRTtZQUMzQixPQUFPLElBQUksQ0FBQztTQUNiO1FBRUQsSUFBSSxlQUFlLEdBQUcsSUFBSSxDQUFDO1FBQzNCLElBQUksVUFBVSxFQUFFO1lBQ2QsZUFBZSxHQUFHLEtBQUssQ0FBQyxhQUFhLENBQUMsT0FBTyxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUNqRTtRQUVELElBQUksZUFBZSxHQUFHLElBQUksQ0FBQztRQUMzQixJQUFJLFVBQVUsRUFBRTtZQUNkLGVBQWUsR0FBRyxLQUFLLENBQUMsYUFBYSxDQUFDLE9BQU8sRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDakU7UUFFRCxPQUFPLGVBQWUsSUFBSSxlQUFlLENBQUM7SUFDNUMsQ0FBQztJQUVEOztPQUVHO0lBQ0ssaUJBQWlCLENBQUMsU0FBaUI7UUFDekMsTUFBTSxhQUFhLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUM1RCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLEVBQUU7WUFDakMsT0FBTyxhQUFhLENBQUM7U0FDdEI7UUFFRCxNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBRTdDLE1BQU0sV0FBVyxHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7UUFFOUIsTUFBTSxpQkFBaUIsR0FBRyx3QkFBYyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLEVBQUU7WUFDakUsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxjQUFjLEVBQUUsQ0FBQyxFQUFDLFFBQVEsRUFBRSxZQUFZLEVBQUUsV0FBVyxFQUFDLEVBQUUsRUFBRTtnQkFDbkYsT0FBTyxDQUNMLFFBQVEsS0FBSyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU07b0JBQ2hDLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRSxZQUFZLEVBQUUsV0FBVyxDQUFDLENBQ2xFLENBQUM7WUFDSixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO1FBRUgsTUFBTSxtQkFBbUIsR0FBRyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUE2QixFQUFFLEVBQUU7WUFDbEYsTUFBTSxJQUFJLEdBQUcseUJBQW1CLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7Z0JBQ3hELENBQUMsQ0FBQyxpQ0FBYyxDQUFDLFFBQVE7Z0JBQ3pCLENBQUMsQ0FBQyxpQ0FBYyxDQUFDLE1BQU0sQ0FBQztZQUMxQixNQUFNLFlBQVksR0FBaUI7Z0JBQ2pDLHVHQUF1RztnQkFDdkcsRUFBRSxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO2dCQUNwQyxTQUFTLEVBQUUsU0FBUztnQkFDcEIsSUFBSSxFQUFFLElBQUk7Z0JBQ1YsS0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7Z0JBQzFDLElBQUksRUFBRSxLQUFLLENBQUMsSUFBSTtnQkFDaEIsT0FBTyxFQUFFLEtBQUssQ0FBQyxPQUFPO2dCQUN0QixPQUFPLEVBQUUsS0FBSyxDQUFDLE9BQU87Z0JBQ3RCLFdBQVcsRUFBRSxLQUFLLENBQUMsV0FBVzthQUMvQixDQUFDO1lBRUYsSUFBSSxXQUFXLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsRUFBRTtnQkFDcEMsR0FBRyxDQUFDLElBQUksQ0FBQywyQkFBMkIsWUFBWSxDQUFDLEVBQUUscUJBQXFCLENBQUMsQ0FBQzthQUMzRTtZQUVELFdBQVcsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBRWpDLElBQUksSUFBSSxLQUFLLGlDQUFjLENBQUMsUUFBUSxFQUFFO2dCQUNwQyxZQUFZLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUM1RSxZQUFZLENBQUMsVUFBVSxHQUFHLHlCQUFtQixDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsY0FBYyxDQUFDLENBQUM7YUFDekY7WUFDRCxPQUFPLHdDQUFrQixDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUN0RCxDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLG1CQUFtQixDQUFDLENBQUM7UUFFM0QsT0FBTyxtQkFBbUIsQ0FBQztJQUM3QixDQUFDO0lBRUQ7O09BRUc7SUFDSyxvQkFBb0IsQ0FBQyxTQUFpQixFQUFFLEVBQVU7UUFDeEQsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQy9ELENBQUM7SUFFRDs7T0FFRztJQUNJLEtBQUssQ0FBQyxhQUFhLENBQ3hCLE1BQTJCLEVBQzNCLElBQWtCO1FBRWxCLE1BQU0sV0FBVyxHQUFHLE1BQU0sTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsc0JBQXNCLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFFL0UsTUFBTSxXQUFXLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7UUFFMUQsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7UUFFcEQsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLG9CQUFvQixDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBRTVFLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsRUFBRTtZQUNoQyxPQUFPLFlBQVksQ0FBQztTQUNyQjtRQUVELE1BQU0sa0JBQWtCLEdBQUcsTUFBTSxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDN0UsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLGtCQUFrQixDQUFDLEVBQUU7WUFDckMsTUFBTSxJQUFJLDZCQUFhLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQztTQUM3QztRQUVELE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLGtCQUFrQixFQUFFLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUMvRSxNQUFNLHNCQUFzQixHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsc0JBQXNCLENBQ3RFLGtCQUFrQixFQUNsQixNQUFNLENBQUMsU0FBUyxDQUNqQixDQUFDO1FBQ0YsTUFBTSxrQkFBa0IsR0FBRyxNQUFNLElBQUksQ0FBQyxhQUFhLENBQUMsa0JBQWtCLENBQ3BFLGtCQUFrQixFQUNsQixDQUFDLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQ2hDLENBQUM7UUFFRixJQUFJLENBQUMsT0FBTyxJQUFJLENBQUMsc0JBQXNCLElBQUksQ0FBQyxrQkFBa0IsRUFBRTtZQUM5RCxNQUFNLElBQUksNkJBQWEsQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLEVBQUUsRUFBRSxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUM7U0FDN0Q7UUFFRCxJQUFJLGNBQWMsQ0FBQztRQUNuQixJQUFJLE1BQU0sSUFBSSxDQUFDLGFBQWEsQ0FBQyxrQkFBa0IsQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFO1lBQ25FLGNBQWMsR0FBRyxNQUFNLElBQUksQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsa0JBQWtCLENBQUMsQ0FBQztTQUNuRjtRQUVELE1BQU0sT0FBTyxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ2pFLE9BQU8sd0NBQWtCLENBQUMsWUFBWSxDQUFDLGtCQUFrQixFQUFFLE9BQU8sRUFBRSxPQUFPLEVBQUUsY0FBYyxDQUFDLENBQUM7SUFDL0YsQ0FBQztJQUVEOztPQUVHO0lBQ0ksS0FBSyxDQUFDLGlCQUFpQixDQUM1QixNQUErQixFQUMvQixJQUFrQjtRQUVsQixNQUFNLFdBQVcsR0FBRyxNQUFNLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLGdCQUFnQixFQUFFLElBQUksQ0FBQyxDQUFDO1FBRXpFLG1JQUFtSTtRQUNuSSxhQUFhO1FBQ2IsTUFBTSxLQUFLLEdBQUcsTUFBTSxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sRUFBRSxXQUFXLENBQUMsQ0FBQztRQUM1RCxhQUFhO1FBQ2IsT0FBTyxTQUFTLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLEVBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQyxPQUFPLEVBQUMsQ0FBQyxFQUFFLFdBQVcsQ0FBQyxDQUFDO0lBQ3ZGLENBQUM7SUFFRDs7T0FFRztJQUNJLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxNQUEyQixFQUFFLElBQWtCO1FBQzNFLE1BQU0sV0FBVyxHQUFHLE1BQU0sTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsd0JBQXdCLENBQUMsQ0FBQztRQUUzRSxNQUFNLGtCQUFrQixHQUFHLE1BQU0sSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQzdFLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFO1lBQ3JDLE1BQU0sSUFBSSw2QkFBYSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7U0FDN0M7UUFFRCxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsRUFBRSxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDL0UsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE1BQU0sSUFBSSw2QkFBYSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsRUFBRSxFQUFFLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQztTQUM3RDtRQUVELE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0lBQ2pFLENBQUM7SUFFRDs7T0FFRztJQUNJLEtBQUssQ0FBQyxnQkFBZ0IsQ0FDM0IsTUFBOEIsRUFDOUIsSUFBa0I7UUFFbEIsZ0VBQWdFO1FBQ2hFLDhEQUE4RDtRQUM5RCxNQUFNLFdBQVcsR0FBRyxNQUFNLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLHNCQUFzQixDQUFDLENBQUM7UUFFekUsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7UUFFcEQsd0JBQXdCO1FBQ3hCLElBQUksa0JBQWtCLEdBQUcsTUFBTSxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDM0UsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLGtCQUFrQixDQUFDLEVBQUU7WUFDckMsTUFBTSxJQUFJLDZCQUFhLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQztTQUM3QztRQUVELE1BQU0sYUFBYSxHQUF5QjtZQUMxQyxJQUFJLEVBQUUsTUFBTSxDQUFDLElBQUk7WUFDakIsT0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPO1lBQ3ZCLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTztZQUN2QixXQUFXLEVBQUUsTUFBTSxDQUFDLFdBQVc7WUFDL0IsT0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPO1NBQ3hCLENBQUM7UUFFRixvREFBb0Q7UUFDcEQsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUNsQyxNQUFNLFVBQVUsR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7WUFFeEQsSUFBSSxDQUFDLFVBQVUsRUFBRTtnQkFDZixNQUFNLFdBQVcsQ0FBQyxTQUFTLENBQUMsY0FBYyxFQUFFLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQzthQUMvRDtpQkFBTTtnQkFDTCxNQUFNLFdBQVcsQ0FBQyxTQUFTLENBQUMsZUFBZSxFQUFFLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQzthQUNoRTtZQUVELElBQUksU0FBUyxHQUFtQixpQ0FBYyxDQUFDLE1BQU0sQ0FBQztZQUN0RCxJQUFJLGNBQWMsQ0FBQztZQUNuQixJQUFJLHlCQUFtQixDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEVBQUU7Z0JBQ2xELFNBQVMsR0FBRyxpQ0FBYyxDQUFDLFFBQVEsQ0FBQztnQkFDcEMsY0FBYyxHQUFHLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2FBQ2pFO1lBRUQsYUFBYSxDQUFDLElBQUksR0FBRyxTQUFTLENBQUM7WUFDL0IsYUFBYSxDQUFDLGNBQWMsR0FBRyxjQUFjLENBQUM7U0FDL0M7UUFFRCxpREFBaUQ7UUFDakQsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLEVBQUUsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQy9FLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixNQUFNLElBQUksNkJBQWEsQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLEVBQUUsRUFBRSxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUM7U0FDN0Q7UUFFRCw4Q0FBOEM7UUFDOUMsSUFBSSxjQUFjLENBQUM7UUFDbkIsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUNsQyxNQUFNLElBQUksQ0FBQyxhQUFhLENBQUMsOEJBQThCLENBQUMsa0JBQWtCLENBQUMsQ0FBQztZQUU1RSxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLEVBQUU7Z0JBQzNDLGNBQWMsR0FBRyxNQUFNLElBQUksQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUM7Z0JBRTFGLEtBQUssQ0FBQyxZQUFZLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxnQkFBZ0IsRUFBRSxjQUFjLENBQUMsQ0FBQztnQkFFckUsTUFBTSxJQUFJLENBQUMsYUFBYSxDQUFDLHlCQUF5QixDQUFDLGtCQUFrQixFQUFFLGNBQWMsQ0FBQyxDQUFDO2FBQ3hGO1NBQ0Y7UUFFRCxpQ0FBaUM7UUFDakMsa0JBQWtCLEdBQUcsTUFBTSxJQUFJLENBQUMsYUFBYSxDQUFDLGdCQUFnQixDQUM1RCxrQkFBa0IsRUFDbEIsYUFBYSxDQUNkLENBQUM7UUFFRix5REFBeUQ7UUFDekQsSUFDRSxDQUFDLE1BQU0sSUFBSSxDQUFDLGFBQWEsQ0FBQyxrQkFBa0IsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO1lBQ2pFLEtBQUssQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLEVBQzdCO1lBQ0EsY0FBYyxHQUFHLE1BQU0sSUFBSSxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO1NBQ25GO1FBRUQsTUFBTSxPQUFPLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDakUsaUNBQWlDO1FBQ2pDLE9BQU8sd0NBQWtCLENBQUMsWUFBWSxDQUFDLGtCQUFrQixFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsY0FBYyxDQUFDLENBQUM7SUFDNUYsQ0FBQztJQUVEOzs7T0FHRztJQUNJLGlCQUFpQixDQUFDLGdCQUFtQztRQUMxRCwrQ0FBK0M7UUFDL0Msc0NBQXNDO1FBQ3RDLE1BQU0sWUFBWSxHQUFHLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFFbkYsdUVBQXVFO1FBQ3ZFLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDakMsT0FBTyxDQUNMLEVBQUUsQ0FBQyxNQUFNLENBQUMsVUFBVTtpQkFDakIsT0FBTyxDQUFDLEVBQUMsS0FBSyxFQUFFLEVBQUMsU0FBUyxFQUFFLEdBQUcsRUFBQyxFQUFDLENBQUM7aUJBQ2xDLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRTtnQkFDcEIsb0RBQW9EO2dCQUNwRCxhQUFhO2dCQUNiLE1BQU0sZ0JBQWdCLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxZQUFZLEVBQUUsTUFBTSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUV4RixzRkFBc0Y7Z0JBQ3RGLE9BQU8sUUFBUSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsS0FBSyxDQUFDLEVBQUU7b0JBQ3pDLE1BQU0sdUJBQXVCLEdBQUcsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO29CQUV2RSwyRUFBMkU7b0JBQzNFLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyx1QkFBdUIsQ0FBQyxFQUFFO3dCQUMxQyxhQUFhO3dCQUNiLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLEVBQUUsWUFBWSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO3FCQUMxRTtvQkFFRCxvRUFBb0U7b0JBQ3BFLGFBQWE7b0JBQ2IsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssRUFBRSx1QkFBdUIsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztnQkFDdEYsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO1lBQy9DLENBQUMsQ0FBQztnQkFDRixhQUFhO2lCQUNaLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFO2dCQUN4QixJQUFJLGlCQUFpQixDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7b0JBQ2hDLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLENBQUM7aUJBQzNEO1lBQ0gsQ0FBQyxDQUFDO2lCQUNELE1BQU0sRUFBRSxDQUNaLENBQUM7UUFDSixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFTSxhQUFhLENBQUMsS0FBeUIsRUFBRSxVQUFvQjtRQUNsRSxNQUFNLGVBQWUsR0FBRyxVQUFVLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQzNDLENBQUMsQ0FBQyxLQUFLLENBQ0w7WUFDRSxTQUFTLEVBQUUsR0FBRztZQUNkLElBQUksRUFBRSxFQUFFO1lBQ1IsSUFBSSxFQUFFLGlDQUFjLENBQUMsTUFBTTtZQUMzQixPQUFPLEVBQUUsd0NBQXFCLENBQUMsT0FBTztTQUN2QyxFQUNELENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FDeEQsQ0FDRixDQUFDO1FBRUYsT0FBTyxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxDQUFDO0lBQ2pELENBQUM7SUFFTSxrQkFBa0I7UUFDdkIsK0NBQStDO1FBQy9DLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDakMsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLFVBQVU7aUJBQ3hCLE9BQU8sQ0FBQyxFQUFDLEtBQUssRUFBRSxFQUFDLE9BQU8sRUFBRSxDQUFDLEVBQUMsRUFBQyxDQUFDO2lCQUM5QixHQUFHLENBQ0YsQ0FBQyxLQUF5QixFQUFrQixFQUFFO2dCQUM1QyxJQUFJO29CQUNGLElBQUksU0FBUyxHQUFtQixpQ0FBYyxDQUFDLE1BQU0sQ0FBQztvQkFDdEQsSUFBSSxjQUFjLENBQUM7b0JBQ25CLElBQUkseUJBQW1CLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsRUFBRTt3QkFDakQsU0FBUyxHQUFHLGlDQUFjLENBQUMsUUFBUSxDQUFDO3dCQUNwQyxjQUFjLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7cUJBQ2hFO29CQUNELEtBQUssQ0FBQyxJQUFJLEdBQUcsU0FBUyxDQUFDO29CQUN2QixLQUFLLENBQUMsY0FBYyxHQUFHLGNBQWMsQ0FBQztvQkFDdEMsS0FBSyxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUM7b0JBQ2xCLE9BQU8sS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLE1BQU0sRUFBRSxDQUFDO2lCQUM5QjtnQkFBQyxPQUFPLENBQUMsRUFBRTtvQkFDVixHQUFHLENBQUMsSUFBSSxDQUNOLDJCQUEyQjt3QkFDekIsS0FBSyxDQUFDLEVBQUU7d0JBQ1IsSUFBSTt3QkFDSixLQUFLLENBQUMsT0FBTzt3QkFDYixhQUFhO3dCQUNiLENBQUMsQ0FBQyxPQUFPLENBQ1osQ0FBQztpQkFDSDtnQkFDRCxPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUM1QixDQUFDLEVBQ0QsRUFBQyxXQUFXLEVBQUUsQ0FBQyxFQUFDLENBQ2pCO2lCQUNBLE1BQU0sRUFBRSxDQUFDO1FBQ2QsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0NBQ0Y7QUFFRCxpQkFBUyxJQUFJLGlCQUFpQixFQUFFLENBQUMifQ==