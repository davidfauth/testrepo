"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-06-24.
 */
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Node or Edge Schema.
 */
class EntitySchema extends Map {
    get labels() {
        return Array.from(this.keys());
    }
}
exports.EntitySchema = EntitySchema;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiRW50aXR5U2NoZW1hLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL3NlcnZpY2VzL2dyYXBoU2NoZW1hL0VudGl0eVNjaGVtYS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7O0dBS0c7O0FBTUg7O0dBRUc7QUFDSCxNQUFhLFlBQWEsU0FBUSxHQUE2QjtJQUM3RCxJQUFJLE1BQU07UUFDUixPQUFPLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7SUFDakMsQ0FBQztDQUNGO0FBSkQsb0NBSUMifQ==