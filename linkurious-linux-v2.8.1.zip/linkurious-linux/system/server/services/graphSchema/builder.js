"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-05-21.
 */
Object.defineProperty(exports, "__esModule", { value: true });
// TS2019-DONE
const rest_client_1 = require("@linkurious/rest-client");
const LKE = require("../");
const EntitySchema_1 = require("./EntitySchema");
const Utils = LKE.getUtils();
/**
 * The graph schema builder is responsible for constructing a schema from graph items.
 * It creates a list of types and, for each of them, a list of properties based on the items it sees.
 */
class SchemaBuilder {
    constructor() {
        this.schema = new EntitySchema_1.EntitySchema();
    }
    get() {
        return this.schema;
    }
    addItem(labels, data) {
        for (const label of labels) {
            const existingType = this.schema.get(label);
            if (existingType) {
                SchemaBuilder.addProperties(existingType, Object.keys(data));
            }
            else {
                const newType = {
                    label: label,
                    visibility: rest_client_1.DataVisibility.SEARCHABLE,
                    properties: []
                };
                this.schema.set(label, newType);
                SchemaBuilder.addProperties(newType, Object.keys(data));
            }
        }
        return this;
    }
    static addProperties(target, properties) {
        const targetProperties = Utils.indexBy(target.properties, p => p.propertyKey);
        for (const propertyName of properties) {
            if (!targetProperties.has(propertyName)) {
                target.properties.push({
                    propertyKey: propertyName,
                    propertyType: { name: rest_client_1.LkPropertyType.AUTO },
                    required: false,
                    visibility: rest_client_1.DataVisibility.SEARCHABLE
                });
            }
        }
    }
}
exports.SchemaBuilder = SchemaBuilder;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYnVpbGRlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9zZXJ2aWNlcy9ncmFwaFNjaGVtYS9idWlsZGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRzs7QUFFSCxjQUFjO0FBRWQseURBQXlGO0FBRXpGLDJCQUE0QjtBQUc1QixpREFBNEM7QUFFNUMsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBRTdCOzs7R0FHRztBQUNILE1BQWEsYUFBYTtJQUExQjtRQUNtQixXQUFNLEdBQWlCLElBQUksMkJBQVksRUFBRSxDQUFDO0lBdUM3RCxDQUFDO0lBckNRLEdBQUc7UUFDUixPQUFPLElBQUksQ0FBQyxNQUFNLENBQUM7SUFDckIsQ0FBQztJQUVNLE9BQU8sQ0FBQyxNQUFnQixFQUFFLElBQTRCO1FBQzNELEtBQUssTUFBTSxLQUFLLElBQUksTUFBTSxFQUFFO1lBQzFCLE1BQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBRTVDLElBQUksWUFBWSxFQUFFO2dCQUNoQixhQUFhLENBQUMsYUFBYSxDQUFDLFlBQVksRUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7YUFDOUQ7aUJBQU07Z0JBQ0wsTUFBTSxPQUFPLEdBQUc7b0JBQ2QsS0FBSyxFQUFFLEtBQUs7b0JBQ1osVUFBVSxFQUFFLDRCQUFjLENBQUMsVUFBVTtvQkFDckMsVUFBVSxFQUFFLEVBQUU7aUJBQ2YsQ0FBQztnQkFDRixJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDLENBQUM7Z0JBQ2hDLGFBQWEsQ0FBQyxhQUFhLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQzthQUN6RDtTQUNGO1FBRUQsT0FBTyxJQUFJLENBQUM7SUFDZCxDQUFDO0lBRU8sTUFBTSxDQUFDLGFBQWEsQ0FBQyxNQUF3QixFQUFFLFVBQW9CO1FBQ3pFLE1BQU0sZ0JBQWdCLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQzlFLEtBQUssTUFBTSxZQUFZLElBQUksVUFBVSxFQUFFO1lBQ3JDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLEVBQUU7Z0JBQ3ZDLE1BQU0sQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDO29CQUNyQixXQUFXLEVBQUUsWUFBWTtvQkFDekIsWUFBWSxFQUFFLEVBQUMsSUFBSSxFQUFFLDRCQUFjLENBQUMsSUFBSSxFQUFDO29CQUN6QyxRQUFRLEVBQUUsS0FBSztvQkFDZixVQUFVLEVBQUUsNEJBQWMsQ0FBQyxVQUFVO2lCQUN0QyxDQUFDLENBQUM7YUFDSjtTQUNGO0lBQ0gsQ0FBQztDQUNGO0FBeENELHNDQXdDQyJ9