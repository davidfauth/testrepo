"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-06-19.
 */
Object.defineProperty(exports, "__esModule", { value: true });
// TS2019-DONE
const rest_client_1 = require("@linkurious/rest-client");
const umd_1 = require("linkurious-shared/umd");
const lodash_1 = require("lodash");
const InvalidParameter_1 = require("../../models/errors/InvalidParameter");
class SchemaChecker {
    constructor(schema, strict, check) {
        this.check = check;
        this.normalizer = new umd_1.SchemaNormalizer(schema, strict, 'Z');
        this.strict = strict;
    }
    toFieldDefinition(propertyType, required = false) {
        switch (propertyType.name) {
            case rest_client_1.LkPropertyType.DATE:
            case rest_client_1.LkPropertyType.DATETIME:
                return {
                    required: required,
                    properties: {
                        type: { required: true, values: [propertyType.name] },
                        value: { required: true, check: ['date', true] },
                        // we tolerate a `timezone` param here since it's present in the LkDate
                        // and LkDateTime interfaces that we return via API
                        timezone: { required: false, type: 'string' }
                    }
                };
            case rest_client_1.LkPropertyType.STRING:
                const values = propertyType.options && propertyType.options.values;
                if (values) {
                    return { required: required, type: 'string', values: values };
                }
                else {
                    return { required: required, check: ['string', true] };
                }
            case rest_client_1.LkPropertyType.AUTO:
                return {
                    required: required,
                    check: (key, value) => {
                        this.check.property(key, value, {
                            required: required,
                            type: ['string', 'number', 'boolean']
                        });
                        if (typeof value === 'string') {
                            this.check.string(key, value, true);
                        }
                    }
                };
            default:
                // number + boolean
                return { required: required, type: propertyType.name };
        }
    }
    getPropertyRule(schemaProperty) {
        if (schemaProperty === null) {
            throw new InvalidParameter_1.InvalidParameter('Please resolve the conflicts in the schema declaration.');
        }
        if (schemaProperty.visibility === rest_client_1.DataVisibility.NONE) {
            return undefined;
        }
        return this.toFieldDefinition(schemaProperty.propertyType, schemaProperty.required);
    }
    /**
     * Normalize data and keep original values if invalid, missing or in conflict.
     */
    normalizeValidValues(labels, data) {
        const normalizedData = this.normalizer.normalize(labels, data);
        const filteredValues = [];
        Object.keys(normalizedData).forEach(key => {
            const lkValue = normalizedData[key];
            if (typeof lkValue === 'object') {
                const status = lkValue.status;
                if (status === 'invalid' || status === 'missing' || status === 'conflict') {
                    filteredValues.push([key, data[key]]);
                    return;
                }
            }
            filteredValues.push([key, lkValue]);
        });
        return lodash_1.fromPairs(filteredValues);
    }
    /**
     * Check `data` compliance against the schema.
     *
     * @param labels The labels used to identify which checking rules to apply
     * @param data   The data to be validated
     */
    checkData(labels, data) {
        // 1) Merge declared properties from all labels and index them by name
        const propertiesByKey = this.normalizer.getProperties(labels);
        const schemaRules = [];
        // 2) Create a valcheck field definition for each schema property
        propertiesByKey.forEach((schemaProperty, propertyKey) => {
            const rule = this.getPropertyRule(schemaProperty);
            if (rule !== undefined) {
                schemaRules.push([propertyKey, rule]);
            }
            // the rule is undefined when the property is marked unavailable
        });
        // 3) Create a valcheck field definition for non schema properties when in non strict mode
        if (!this.strict) {
            // in strict mode, we forbid properties not declared in the schema
            // in non strict mode we allow them as long as the data type is supported
            Object.keys(data).forEach(key => {
                if (!propertiesByKey.has(key)) {
                    schemaRules.push([key, this.toFieldDefinition({ name: rest_client_1.LkPropertyType.AUTO })]);
                }
            });
        }
        // 4) Check compliance with the schema
        this.check.properties('data', data, lodash_1.fromPairs(schemaRules));
        return true;
    }
}
exports.SchemaChecker = SchemaChecker;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2hlY2tlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9zZXJ2aWNlcy9ncmFwaFNjaGVtYS9jaGVja2VyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRzs7QUFFSCxjQUFjO0FBRWQseURBTWlDO0FBQ2pDLCtDQUErRDtBQUMvRCxtQ0FBaUM7QUFHakMsMkVBQXNFO0FBS3RFLE1BQWEsYUFBYTtJQUt4QixZQUFZLE1BQW9CLEVBQUUsTUFBZSxFQUFFLEtBQWtCO1FBQ25FLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO1FBQ25CLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxzQkFBZ0IsQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQzVELElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO0lBQ3ZCLENBQUM7SUFFTyxpQkFBaUIsQ0FBQyxZQUFvQixFQUFFLFFBQVEsR0FBRyxLQUFLO1FBQzlELFFBQVEsWUFBWSxDQUFDLElBQUksRUFBRTtZQUN6QixLQUFLLDRCQUFjLENBQUMsSUFBSSxDQUFDO1lBQ3pCLEtBQUssNEJBQWMsQ0FBQyxRQUFRO2dCQUMxQixPQUFPO29CQUNMLFFBQVEsRUFBRSxRQUFRO29CQUNsQixVQUFVLEVBQUU7d0JBQ1YsSUFBSSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLEVBQUM7d0JBQ25ELEtBQUssRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxFQUFDO3dCQUM5Qyx1RUFBdUU7d0JBQ3ZFLG1EQUFtRDt3QkFDbkQsUUFBUSxFQUFFLEVBQUMsUUFBUSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFDO3FCQUM1QztpQkFDRixDQUFDO1lBQ0osS0FBSyw0QkFBYyxDQUFDLE1BQU07Z0JBQ3hCLE1BQU0sTUFBTSxHQUFHLFlBQVksQ0FBQyxPQUFPLElBQUksWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUM7Z0JBQ25FLElBQUksTUFBTSxFQUFFO29CQUNWLE9BQU8sRUFBQyxRQUFRLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBQyxDQUFDO2lCQUM3RDtxQkFBTTtvQkFDTCxPQUFPLEVBQUMsUUFBUSxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLEVBQUMsQ0FBQztpQkFDdEQ7WUFDSCxLQUFLLDRCQUFjLENBQUMsSUFBSTtnQkFDdEIsT0FBTztvQkFDTCxRQUFRLEVBQUUsUUFBUTtvQkFDbEIsS0FBSyxFQUFFLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRSxFQUFFO3dCQUNwQixJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFOzRCQUM5QixRQUFRLEVBQUUsUUFBUTs0QkFDbEIsSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUM7eUJBQ3RDLENBQUMsQ0FBQzt3QkFDSCxJQUFJLE9BQU8sS0FBSyxLQUFLLFFBQVEsRUFBRTs0QkFDN0IsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRSxJQUFJLENBQUMsQ0FBQzt5QkFDckM7b0JBQ0gsQ0FBQztpQkFDRixDQUFDO1lBQ0o7Z0JBQ0UsbUJBQW1CO2dCQUNuQixPQUFPLEVBQUMsUUFBUSxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsWUFBWSxDQUFDLElBQUksRUFBQyxDQUFDO1NBQ3hEO0lBQ0gsQ0FBQztJQUVPLGVBQWUsQ0FDckIsY0FBMkM7UUFFM0MsSUFBSSxjQUFjLEtBQUssSUFBSSxFQUFFO1lBQzNCLE1BQU0sSUFBSSxtQ0FBZ0IsQ0FBQyx5REFBeUQsQ0FBQyxDQUFDO1NBQ3ZGO1FBRUQsSUFBSSxjQUFjLENBQUMsVUFBVSxLQUFLLDRCQUFjLENBQUMsSUFBSSxFQUFFO1lBQ3JELE9BQU8sU0FBUyxDQUFDO1NBQ2xCO1FBRUQsT0FBTyxJQUFJLENBQUMsaUJBQWlCLENBQUMsY0FBYyxDQUFDLFlBQVksRUFBRSxjQUFjLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDdEYsQ0FBQztJQUVEOztPQUVHO0lBQ0ksb0JBQW9CLENBQ3pCLE1BQWdCLEVBQ2hCLElBQTRCO1FBRTVCLE1BQU0sY0FBYyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztRQUUvRCxNQUFNLGNBQWMsR0FBNkIsRUFBRSxDQUFDO1FBRXBELE1BQU0sQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQ3hDLE1BQU0sT0FBTyxHQUFHLGNBQWMsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNwQyxJQUFJLE9BQU8sT0FBTyxLQUFLLFFBQVEsRUFBRTtnQkFDL0IsTUFBTSxNQUFNLEdBQUksT0FBNkIsQ0FBQyxNQUFNLENBQUM7Z0JBQ3JELElBQUksTUFBTSxLQUFLLFNBQVMsSUFBSSxNQUFNLEtBQUssU0FBUyxJQUFJLE1BQU0sS0FBSyxVQUFVLEVBQUU7b0JBQ3pFLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDdEMsT0FBTztpQkFDUjthQUNGO1lBQ0QsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDO1FBQ3RDLENBQUMsQ0FBQyxDQUFDO1FBRUgsT0FBTyxrQkFBUyxDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBQ25DLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLFNBQVMsQ0FDZCxNQUFnQixFQUNoQixJQUE0QjtRQUU1QixzRUFBc0U7UUFDdEUsTUFBTSxlQUFlLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUM7UUFFOUQsTUFBTSxXQUFXLEdBQXdDLEVBQUUsQ0FBQztRQUU1RCxpRUFBaUU7UUFDakUsZUFBZSxDQUFDLE9BQU8sQ0FBQyxDQUFDLGNBQWMsRUFBRSxXQUFXLEVBQUUsRUFBRTtZQUN0RCxNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1lBQ2xELElBQUksSUFBSSxLQUFLLFNBQVMsRUFBRTtnQkFDdEIsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDO2FBQ3ZDO1lBQ0QsZ0VBQWdFO1FBQ2xFLENBQUMsQ0FBQyxDQUFDO1FBRUgsMEZBQTBGO1FBQzFGLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQ2hCLGtFQUFrRTtZQUNsRSx5RUFBeUU7WUFDekUsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQzlCLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFO29CQUM3QixXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxFQUFDLElBQUksRUFBRSw0QkFBYyxDQUFDLElBQUksRUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUM5RTtZQUNILENBQUMsQ0FBQyxDQUFDO1NBQ0o7UUFFRCxzQ0FBc0M7UUFDdEMsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxrQkFBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7UUFFNUQsT0FBTyxJQUFJLENBQUM7SUFDZCxDQUFDO0NBQ0Y7QUFuSUQsc0NBbUlDIn0=