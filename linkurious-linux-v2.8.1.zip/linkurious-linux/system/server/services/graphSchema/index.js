"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-05-20.
 */
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
// TS2019-DONE
const rest_client_1 = require("@linkurious/rest-client");
const umd_1 = require("linkurious-shared/umd");
const _ = require("lodash");
const LKE = require("../");
const graphSchemaDAO_1 = require("../../dao/sql/graphSchemaDAO");
const AlreadyExistsError_1 = require("../../models/errors/AlreadyExistsError");
const Bug_1 = require("../../models/errors/Bug");
const BusinessError_1 = require("../../models/errors/BusinessError");
const InvalidParameter_1 = require("../../models/errors/InvalidParameter");
const checker_1 = require("./checker");
const EntitySchema_1 = require("./EntitySchema");
const updater_1 = require("./updater");
const Utils = LKE.getUtils();
const Config = LKE.getConfig();
class GraphSchemaService {
    constructor() {
        this.schemaCache = {
            node: new Map(),
            edge: new Map()
        };
    }
    emptyCache() {
        this.schemaCache[rest_client_1.EntityType.NODE].clear();
        this.schemaCache[rest_client_1.EntityType.EDGE].clear();
    }
    invalidateCache(entityType, sourceKey) {
        this.schemaCache[entityType].delete(sourceKey);
    }
    async createType(params) {
        await GraphSchemaService.checkTypeNotExists(params.sourceKey, params.entityType, params.label);
        const newType = {
            sourceKey: params.sourceKey,
            label: params.label,
            visibility: params.visibility
        };
        const persistedType = await graphSchemaDAO_1.GraphSchemaDAO.createType(params.entityType, newType);
        this.invalidateCache(params.entityType, params.sourceKey);
        return {
            label: persistedType.label,
            visibility: persistedType.visibility,
            properties: []
        };
    }
    async updateType(params) {
        const existingType = await GraphSchemaService.checkTypeExists(params.sourceKey, params.entityType, params.label);
        await graphSchemaDAO_1.GraphSchemaDAO.updateType(existingType, { visibility: params.visibility });
        this.invalidateCache(params.entityType, params.sourceKey);
    }
    toGraphSchemaProperty(instance) {
        return {
            propertyKey: instance.propertyKey,
            propertyType: instance.propertyType,
            visibility: instance.visibility,
            required: instance.required
        };
    }
    async createProperty(params) {
        const existingType = await GraphSchemaService.checkTypeExists(params.sourceKey, params.entityType, params.label);
        await GraphSchemaService.checkPropertyNotExists(params.sourceKey, params.entityType, existingType.id, existingType.label, params.propertyKey);
        const newProperty = {
            sourceKey: params.sourceKey,
            propertyKey: params.propertyKey,
            propertyType: params.propertyType,
            required: params.required || false,
            visibility: params.visibility
        };
        const property = await graphSchemaDAO_1.GraphSchemaDAO.createProperty(params.entityType, existingType.id, newProperty);
        this.invalidateCache(params.entityType, params.sourceKey);
        return this.toGraphSchemaProperty(property);
    }
    async updateProperty(params) {
        const existingType = await GraphSchemaService.checkTypeExists(params.sourceKey, params.entityType, params.label);
        const existingProperty = await GraphSchemaService.checkPropertyExists(params.sourceKey, params.entityType, existingType.id, existingType.label, params.propertyKey);
        const updateValues = {
            propertyType: params.propertyType,
            required: params.required,
            visibility: params.visibility
        };
        await graphSchemaDAO_1.GraphSchemaDAO.updateProperty(existingProperty, updateValues);
        this.invalidateCache(params.entityType, params.sourceKey);
    }
    /**
     * Get a subset of the schema with only readableTypes and searchable types/properties.
     */
    async getSearchableSchema(sourceKey, entityType, strict, readableTypes) {
        const schema = await this.getSchema(sourceKey, entityType, strict);
        const searchableSchema = new EntitySchema_1.EntitySchema();
        for (const label of schema.keys()) {
            const schemaType = schema.get(label);
            if (Utils.hasValue(readableTypes) && !readableTypes.includes(label)) {
                continue;
            }
            if (schemaType.visibility === rest_client_1.DataVisibility.SEARCHABLE) {
                searchableSchema.set(label, _.defaults({
                    properties: schemaType.properties.filter(p => p.visibility === rest_client_1.DataVisibility.SEARCHABLE)
                }, schemaType));
            }
        }
        return searchableSchema;
    }
    /**
     * Get the node or edge schema for a given data-source.
     * When `strict` is true any property with type `AUTO` will have `visibility` set to `none`.
     */
    async getSchema(sourceKey, entityType, strict = false) {
        let schema;
        if (this.schemaCache[entityType].has(sourceKey)) {
            schema = this.schemaCache[entityType].get(sourceKey);
        }
        else {
            const types = await graphSchemaDAO_1.GraphSchemaDAO.getTypes(sourceKey, entityType);
            schema = new EntitySchema_1.EntitySchema();
            for (const type of types) {
                const properties = await graphSchemaDAO_1.GraphSchemaDAO.getProperties(sourceKey, entityType, type.id);
                schema.set(type.label, {
                    label: type.label,
                    visibility: type.visibility,
                    properties: properties.map(p => this.toGraphSchemaProperty(p))
                });
            }
            this.schemaCache[entityType].set(sourceKey, schema);
        }
        schema = Utils.clone(schema);
        if (strict) {
            // In strict mode turn off properties with undeclared type
            for (const [, schemaType] of schema) {
                schemaType.properties.forEach(property => {
                    if (property.propertyType.name === rest_client_1.LkPropertyType.AUTO) {
                        property.visibility = rest_client_1.DataVisibility.NONE;
                    }
                });
            }
        }
        return schema;
    }
    async updateSchema(sourceKey, entityType, builder, reset = false) {
        if (reset) {
            await graphSchemaDAO_1.GraphSchemaDAO.clearSchema(sourceKey, entityType);
            this.invalidateCache(entityType, sourceKey);
        }
        const currentSchema = await this.getSchema(sourceKey, entityType);
        const updater = new updater_1.SchemaUpdater(sourceKey, currentSchema);
        for (const [, newType] of builder.get()) {
            updater.addType(newType);
        }
        let currentCacheIsInvalid = false;
        if (updater.typesToCreate.length) {
            await graphSchemaDAO_1.GraphSchemaDAO.createTypes(entityType, updater.typesToCreate);
            currentCacheIsInvalid = true;
        }
        for (const [name, properties] of updater.propertiesToCreate) {
            const schemaType = await graphSchemaDAO_1.GraphSchemaDAO.findTypeByName(sourceKey, entityType, name);
            if (schemaType) {
                await graphSchemaDAO_1.GraphSchemaDAO.createProperties(entityType, schemaType.id, properties);
                currentCacheIsInvalid = true;
            }
            else {
                throw new Bug_1.Bug(`The ${entityType} type ${name} was never created.`);
            }
        }
        if (currentCacheIsInvalid) {
            // invalidate the cache
            this.invalidateCache(entityType, sourceKey);
        }
    }
    async checkNodeUpdate(sourceKey, originalNode, updateData, addedCategories, deletedCategories, deletedProperties, strict) {
        const schema = await this.getSchema(sourceKey, rest_client_1.EntityType.NODE, strict);
        const normalizer = new umd_1.SchemaNormalizer(schema, strict, Config.get('advanced.defaultTimezone'));
        // 1) check that all added categories are available
        for (const addedCategory of addedCategories) {
            if (!normalizer.isAvailable(addedCategory)) {
                throw new InvalidParameter_1.InvalidParameter(`The node category "${addedCategory}" is unavailable.`);
            }
        }
        // 2) simulate the categories update
        // updatedCategories = (addedCategories + originalCategories) - deletedCategories
        const updatedCategories = _.without(_.union(addedCategories, originalNode.categories), ...deletedCategories);
        const checker = new checker_1.SchemaChecker(schema, strict, Utils.check);
        // 3) Check that updatedCategories & (updateData + originalData - deletedProperties) is allowed
        this.checkUpdate(checker, updatedCategories, updateData, originalNode.data, deletedProperties);
    }
    async checkEdgeUpdate(sourceKey, originalEdge, updateData, deletedProperties, strict) {
        const schema = await this.getSchema(sourceKey, rest_client_1.EntityType.EDGE, strict);
        const normalizer = new umd_1.SchemaNormalizer(schema, strict, Config.get('advanced.defaultTimezone'));
        // 1) check that the edge type is available
        if (!normalizer.isAvailable(originalEdge.type)) {
            throw new InvalidParameter_1.InvalidParameter(`The node category "${originalEdge.type}" is unavailable.`);
        }
        const checker = new checker_1.SchemaChecker(schema, strict, Utils.check);
        // 2) Check that originalType & (updateData + originalData - deletedProperties) is allowed
        this.checkUpdate(checker, [originalEdge.type], updateData, originalEdge.data, deletedProperties);
    }
    /**
     * Simulate a data update and check the result against the schema.
     */
    checkUpdate(checker, labels, updateData, originalData, deletedData) {
        // 1) Normalize original data for the following reasons
        // a: we should not allow updating a non available property (excluded by the normalizer)
        // b: if a non available property already exist we don't want to fail the update
        // c: we want to check that the data update + available original data is schema compliant
        // d: the original data is schema compliant only after it is normalized
        const normalizedOriginalData = checker.normalizeValidValues(labels, originalData);
        // 2) simulate the data update
        // updatedData = (updateData + filteredOriginalData) - deletedData
        const updatedData = _.omit(_.defaults({}, updateData, normalizedOriginalData), deletedData);
        // 3) check simulated update against the schema
        checker.checkData(labels, updatedData);
    }
    async checkNode(sourceKey, node, strict) {
        const schema = await this.getSchema(sourceKey, rest_client_1.EntityType.NODE, strict);
        const normalizer = new umd_1.SchemaNormalizer(schema, strict, Config.get('advanced.defaultTimezone'));
        // 1) check that all categories are available
        node.categories.forEach(category => {
            if (!normalizer.isAvailable(category)) {
                throw new InvalidParameter_1.InvalidParameter(`The node category "${category}" is unavailable.`);
            }
        });
        const checker = new checker_1.SchemaChecker(schema, strict, Utils.check);
        // 2) check node against the schema
        checker.checkData(node.categories, node.data);
        return node;
    }
    async checkEdge(sourceKey, edge, strict) {
        const schema = await this.getSchema(sourceKey, rest_client_1.EntityType.EDGE, strict);
        const normalizer = new umd_1.SchemaNormalizer(schema, strict, Config.get('advanced.defaultTimezone'));
        // 1) check that the type is available
        if (!normalizer.isAvailable(edge.type)) {
            throw new InvalidParameter_1.InvalidParameter(`The edge type "${edge.type}" is not available.`);
        }
        const checker = new checker_1.SchemaChecker(schema, strict, Utils.check);
        // 2) check edge against the schema
        checker.checkData([edge.type], edge.data);
        return edge;
    }
    async decodeNode(sourceKey, node) {
        const result = Utils.clone(node);
        result.data = await this.decodeData(sourceKey, rest_client_1.EntityType.NODE, node.categories, node.data);
        return result;
    }
    async decodeEdge(sourceKey, edge) {
        const result = Utils.clone(edge);
        result.data = await this.decodeData(sourceKey, rest_client_1.EntityType.EDGE, [edge.type], edge.data);
        return result;
    }
    /**
     * Decode temporal values defined in the schema.
     *
     * The method should only be called on `data` already validated against the schema.
     */
    async decodeData(sourceKey, entityType, labels, data) {
        const schema = await this.getSchema(sourceKey, entityType);
        const normalizer = new umd_1.SchemaNormalizer(schema, false, 'Z');
        return normalizer.decodeTemporalValues(labels, data);
    }
    /**
     * Transform all nodes to be schema compliant.
     *
     * A node will be filtered out if none of node.categories is available.
     */
    async normalizeNodes(sourceKey, nodes, strict) {
        const normalizedNodes = [];
        const schema = await this.getSchema(sourceKey, rest_client_1.EntityType.NODE, strict);
        const normalizer = new umd_1.SchemaNormalizer(schema, strict, Config.get('advanced.defaultTimezone'));
        for (const node of nodes) {
            const { tolerateIsoStringAsNativeDate, data, categories } = node, otherNodeAttributes = __rest(node, ["tolerateIsoStringAsNativeDate", "data", "categories"]);
            const availableCategories = node.categories.filter(c => normalizer.isAvailable(c));
            if (availableCategories.length > 0) {
                // remove iso strings from the object and convert to NativeDate/NativeDateTime
                // when declared as date/datetime in the schema
                const noIsoStringData = tolerateIsoStringAsNativeDate
                    ? this.isoStringToNativeDate(normalizer.getProperties(availableCategories), data)
                    : data;
                normalizedNodes.push(Object.assign({
                    categories: availableCategories,
                    data: normalizer.normalize(availableCategories, noIsoStringData)
                }, otherNodeAttributes));
            }
        }
        return normalizedNodes;
    }
    /**
     * Transform all edges to be schema compliant.
     *
     * An edge will be filtered out if edge.type is not available.
     */
    async normalizeEdges(sourceKey, edges, strict) {
        const normalizedEdges = [];
        const schema = await this.getSchema(sourceKey, rest_client_1.EntityType.EDGE, strict);
        const normalizer = new umd_1.SchemaNormalizer(schema, strict, Config.get('advanced.defaultTimezone'));
        for (const edge of edges) {
            const { tolerateIsoStringAsNativeDate, data, type } = edge, otherEdgeAttributes = __rest(edge, ["tolerateIsoStringAsNativeDate", "data", "type"]);
            if (normalizer.isAvailable(edge.type)) {
                // remove iso strings from the object and convert to NativeDate/NativeDateTime
                // when declared as date/datetime in the schema
                const noIsoStringData = tolerateIsoStringAsNativeDate
                    ? this.isoStringToNativeDate(normalizer.getProperties([type]), data)
                    : data;
                normalizedEdges.push(Object.assign({
                    type: type,
                    data: normalizer.normalize([type], noIsoStringData)
                }, otherEdgeAttributes));
            }
        }
        return normalizedEdges;
    }
    static async checkTypeNotExists(sourceKey, entityType, label) {
        const existingType = await graphSchemaDAO_1.GraphSchemaDAO.findTypeByName(sourceKey, entityType, label);
        if (existingType) {
            throw new AlreadyExistsError_1.AlreadyExistsError(`The ${entityType} type`, label);
        }
    }
    static async checkTypeExists(sourceKey, entityType, label) {
        const existingType = await graphSchemaDAO_1.GraphSchemaDAO.findTypeByName(sourceKey, entityType, label);
        if (!existingType) {
            throw new BusinessError_1.BusinessError(entityType + '_type_not_found', `The ${entityType} type ${label} does not exist.`);
        }
        return existingType;
    }
    static async checkPropertyNotExists(sourceKey, entityType, typeId, label, propertyKey) {
        const existingProperty = await graphSchemaDAO_1.GraphSchemaDAO.findPropertyByName(sourceKey, entityType, typeId, propertyKey);
        if (existingProperty) {
            throw new AlreadyExistsError_1.AlreadyExistsError(`The ${entityType} type "${label}" with property`, propertyKey);
        }
    }
    static async checkPropertyExists(sourceKey, entityType, typeId, label, propertyKey) {
        const existingProperty = await graphSchemaDAO_1.GraphSchemaDAO.findPropertyByName(sourceKey, entityType, typeId, propertyKey);
        if (!existingProperty) {
            throw new BusinessError_1.BusinessError(entityType + '_property_not_found', `The ${entityType} type "${label}" with property "${propertyKey}" does not exist.`);
        }
        return existingProperty;
    }
    /**
     * Save the hidden properties of the data-source as hidden properties in the schema.
     *
     * @backward-compatibility Since LKE v2.8 all hidden properties are stored in the schema
     */
    async saveHiddenProperties(sourceKey, entityType, hiddenProperties) {
        if (hiddenProperties.length === 0) {
            return;
        }
        for (const hiddenProperty of hiddenProperties) {
            // we update the visibility of every known property in the schema
            // among the ones in `hiddenProperties` to `DataVisibility.NONE`
            await graphSchemaDAO_1.GraphSchemaDAO.updateAllProperties(sourceKey, entityType, hiddenProperty, {
                visibility: rest_client_1.DataVisibility.NONE
            });
        }
        const schema = await this.getSchema(sourceKey, entityType);
        const declaredTypes = await graphSchemaDAO_1.GraphSchemaDAO.getAllTypes(sourceKey, entityType);
        for (const declaredType of declaredTypes) {
            const graphSchemaType = schema.get(declaredType.label);
            if (graphSchemaType) {
                const knownProperties = Utils.indexBy(graphSchemaType.properties, p => p.propertyKey);
                for (const hiddenProperty of hiddenProperties) {
                    if (!knownProperties.has(hiddenProperty)) {
                        // if the hidden property is not in the schema for a given label
                        // we create it with `DataVisibility.NONE`
                        await graphSchemaDAO_1.GraphSchemaDAO.createProperty(entityType, declaredType.id, {
                            sourceKey: sourceKey,
                            propertyKey: hiddenProperty,
                            visibility: rest_client_1.DataVisibility.NONE,
                            propertyType: {
                                name: rest_client_1.LkPropertyType.AUTO
                            },
                            required: false
                        });
                    }
                }
            }
        }
        this.invalidateCache(entityType, sourceKey);
    }
    /**
     * Convert ISO string to native date only when a property is declared as native date in the schema.
     */
    isoStringToNativeDate(declaredProperties, data) {
        declaredProperties.forEach((schemaProperty, propertyKey) => {
            if (schemaProperty === null) {
                return;
            }
            const propertyType = schemaProperty.propertyType;
            const propertyValue = data[propertyKey];
            const isNativeDate = propertyType.name === rest_client_1.LkPropertyType.DATE &&
                propertyType.options.format === rest_client_1.LkDateFormat.NATIVE;
            const isNativeDateTime = propertyType.name === rest_client_1.LkPropertyType.DATETIME &&
                propertyType.options.format === rest_client_1.LkDateTimeFormat.NATIVE;
            if (isNativeDate || isNativeDateTime) {
                // We expect the date/datetime to be one of:
                // date => 2019-07-04
                // datetime => 2015-06-24T12:50:35.556+01:00
                // localdatetime => 2015-07-04T19:32:24
                // source: Neo4j (https://neo4j.com/docs/cypher-manual/current/syntax/temporal/)
                const parsedDate = isNativeDate
                    ? umd_1.SchemaNormalizer.parseISODate(propertyValue)
                    : umd_1.SchemaNormalizer.parseISODateTime(propertyValue);
                if (Utils.hasValue(parsedDate)) {
                    data[propertyKey] = parsedDate;
                }
            }
        });
        return data;
    }
}
module.exports = new GraphSchemaService();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvZ3JhcGhTY2hlbWEvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7OztHQUtHOzs7Ozs7Ozs7Ozs7QUFFSCxjQUFjO0FBRWQseURBcUJpQztBQUNqQywrQ0FBMkU7QUFDM0UsNEJBQTRCO0FBRTVCLDJCQUE0QjtBQUM1QixpRUFBNEQ7QUFDNUQsK0VBQTBFO0FBQzFFLGlEQUE0QztBQUM1QyxxRUFBZ0U7QUFDaEUsMkVBQXNFO0FBZ0J0RSx1Q0FBd0M7QUFDeEMsaURBQTRDO0FBQzVDLHVDQUF3QztBQUV4QyxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBUy9CLE1BQU0sa0JBQWtCO0lBQXhCO1FBQ21CLGdCQUFXLEdBQWdCO1lBQzFDLElBQUksRUFBRSxJQUFJLEdBQUcsRUFBRTtZQUNmLElBQUksRUFBRSxJQUFJLEdBQUcsRUFBRTtTQUNoQixDQUFDO0lBcW9CSixDQUFDO0lBbm9CUSxVQUFVO1FBQ2YsSUFBSSxDQUFDLFdBQVcsQ0FBQyx3QkFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQzFDLElBQUksQ0FBQyxXQUFXLENBQUMsd0JBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQztJQUM1QyxDQUFDO0lBRU8sZUFBZSxDQUFDLFVBQXNCLEVBQUUsU0FBaUI7UUFDL0QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDakQsQ0FBQztJQUVNLEtBQUssQ0FBQyxVQUFVLENBQUMsTUFBd0I7UUFDOUMsTUFBTSxrQkFBa0IsQ0FBQyxrQkFBa0IsQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxVQUFVLEVBQUUsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRS9GLE1BQU0sT0FBTyxHQUF5QjtZQUNwQyxTQUFTLEVBQUUsTUFBTSxDQUFDLFNBQVM7WUFDM0IsS0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO1lBQ25CLFVBQVUsRUFBRSxNQUFNLENBQUMsVUFBVTtTQUM5QixDQUFDO1FBRUYsTUFBTSxhQUFhLEdBQUcsTUFBTSwrQkFBYyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ2xGLElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBRSxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDMUQsT0FBTztZQUNMLEtBQUssRUFBRSxhQUFhLENBQUMsS0FBSztZQUMxQixVQUFVLEVBQUUsYUFBYSxDQUFDLFVBQVU7WUFDcEMsVUFBVSxFQUFFLEVBQUU7U0FDZixDQUFDO0lBQ0osQ0FBQztJQUVNLEtBQUssQ0FBQyxVQUFVLENBQUMsTUFBd0I7UUFDOUMsTUFBTSxZQUFZLEdBQUcsTUFBTSxrQkFBa0IsQ0FBQyxlQUFlLENBQzNELE1BQU0sQ0FBQyxTQUFTLEVBQ2hCLE1BQU0sQ0FBQyxVQUFVLEVBQ2pCLE1BQU0sQ0FBQyxLQUFLLENBQ2IsQ0FBQztRQUVGLE1BQU0sK0JBQWMsQ0FBQyxVQUFVLENBQUMsWUFBWSxFQUFFLEVBQUMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxVQUFVLEVBQUMsQ0FBQyxDQUFDO1FBQy9FLElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBRSxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDNUQsQ0FBQztJQUVPLHFCQUFxQixDQUFDLFFBQWdDO1FBQzVELE9BQU87WUFDTCxXQUFXLEVBQUUsUUFBUSxDQUFDLFdBQVc7WUFDakMsWUFBWSxFQUFFLFFBQVEsQ0FBQyxZQUFZO1lBQ25DLFVBQVUsRUFBRSxRQUFRLENBQUMsVUFBVTtZQUMvQixRQUFRLEVBQUUsUUFBUSxDQUFDLFFBQVE7U0FDNUIsQ0FBQztJQUNKLENBQUM7SUFFTSxLQUFLLENBQUMsY0FBYyxDQUFDLE1BQTRCO1FBQ3RELE1BQU0sWUFBWSxHQUFHLE1BQU0sa0JBQWtCLENBQUMsZUFBZSxDQUMzRCxNQUFNLENBQUMsU0FBUyxFQUNoQixNQUFNLENBQUMsVUFBVSxFQUNqQixNQUFNLENBQUMsS0FBSyxDQUNiLENBQUM7UUFFRixNQUFNLGtCQUFrQixDQUFDLHNCQUFzQixDQUM3QyxNQUFNLENBQUMsU0FBUyxFQUNoQixNQUFNLENBQUMsVUFBVSxFQUNqQixZQUFZLENBQUMsRUFBRSxFQUNmLFlBQVksQ0FBQyxLQUFLLEVBQ2xCLE1BQU0sQ0FBQyxXQUFXLENBQ25CLENBQUM7UUFFRixNQUFNLFdBQVcsR0FBNkI7WUFDNUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxTQUFTO1lBQzNCLFdBQVcsRUFBRSxNQUFNLENBQUMsV0FBVztZQUMvQixZQUFZLEVBQUUsTUFBTSxDQUFDLFlBQVk7WUFDakMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxRQUFRLElBQUksS0FBSztZQUNsQyxVQUFVLEVBQUUsTUFBTSxDQUFDLFVBQVU7U0FDOUIsQ0FBQztRQUVGLE1BQU0sUUFBUSxHQUFHLE1BQU0sK0JBQWMsQ0FBQyxjQUFjLENBQ2xELE1BQU0sQ0FBQyxVQUFVLEVBQ2pCLFlBQVksQ0FBQyxFQUFFLEVBQ2YsV0FBVyxDQUNaLENBQUM7UUFDRixJQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzFELE9BQU8sSUFBSSxDQUFDLHFCQUFxQixDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQzlDLENBQUM7SUFFTSxLQUFLLENBQUMsY0FBYyxDQUFDLE1BQTRCO1FBQ3RELE1BQU0sWUFBWSxHQUFHLE1BQU0sa0JBQWtCLENBQUMsZUFBZSxDQUMzRCxNQUFNLENBQUMsU0FBUyxFQUNoQixNQUFNLENBQUMsVUFBVSxFQUNqQixNQUFNLENBQUMsS0FBSyxDQUNiLENBQUM7UUFFRixNQUFNLGdCQUFnQixHQUFHLE1BQU0sa0JBQWtCLENBQUMsbUJBQW1CLENBQ25FLE1BQU0sQ0FBQyxTQUFTLEVBQ2hCLE1BQU0sQ0FBQyxVQUFVLEVBQ2pCLFlBQVksQ0FBQyxFQUFFLEVBQ2YsWUFBWSxDQUFDLEtBQUssRUFDbEIsTUFBTSxDQUFDLFdBQVcsQ0FDbkIsQ0FBQztRQUVGLE1BQU0sWUFBWSxHQUFzQztZQUN0RCxZQUFZLEVBQUUsTUFBTSxDQUFDLFlBQVk7WUFDakMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxRQUFRO1lBQ3pCLFVBQVUsRUFBRSxNQUFNLENBQUMsVUFBVTtTQUM5QixDQUFDO1FBRUYsTUFBTSwrQkFBYyxDQUFDLGNBQWMsQ0FBQyxnQkFBZ0IsRUFBRSxZQUFZLENBQUMsQ0FBQztRQUNwRSxJQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQzVELENBQUM7SUFFRDs7T0FFRztJQUNJLEtBQUssQ0FBQyxtQkFBbUIsQ0FDOUIsU0FBaUIsRUFDakIsVUFBc0IsRUFDdEIsTUFBZSxFQUNmLGFBQXdCO1FBRXhCLE1BQU0sTUFBTSxHQUFHLE1BQU0sSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLEVBQUUsVUFBVSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBRW5FLE1BQU0sZ0JBQWdCLEdBQUcsSUFBSSwyQkFBWSxFQUFFLENBQUM7UUFFNUMsS0FBSyxNQUFNLEtBQUssSUFBSSxNQUFNLENBQUMsSUFBSSxFQUFFLEVBQUU7WUFDakMsTUFBTSxVQUFVLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUUsQ0FBQztZQUN0QyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUNuRSxTQUFTO2FBQ1Y7WUFFRCxJQUFJLFVBQVUsQ0FBQyxVQUFVLEtBQUssNEJBQWMsQ0FBQyxVQUFVLEVBQUU7Z0JBQ3ZELGdCQUFnQixDQUFDLEdBQUcsQ0FDbEIsS0FBSyxFQUNMLENBQUMsQ0FBQyxRQUFRLENBQ1I7b0JBQ0UsVUFBVSxFQUFFLFVBQVUsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUN0QyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxVQUFVLEtBQUssNEJBQWMsQ0FBQyxVQUFVLENBQ2hEO2lCQUNGLEVBQ0QsVUFBVSxDQUNYLENBQ0YsQ0FBQzthQUNIO1NBQ0Y7UUFDRCxPQUFPLGdCQUFnQixDQUFDO0lBQzFCLENBQUM7SUFFRDs7O09BR0c7SUFDSSxLQUFLLENBQUMsU0FBUyxDQUNwQixTQUFpQixFQUNqQixVQUFzQixFQUN0QixNQUFNLEdBQUcsS0FBSztRQUVkLElBQUksTUFBb0IsQ0FBQztRQUV6QixJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQy9DLE1BQU0sR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUUsQ0FBQztTQUN2RDthQUFNO1lBQ0wsTUFBTSxLQUFLLEdBQUcsTUFBTSwrQkFBYyxDQUFDLFFBQVEsQ0FBQyxTQUFTLEVBQUUsVUFBVSxDQUFDLENBQUM7WUFDbkUsTUFBTSxHQUFHLElBQUksMkJBQVksRUFBRSxDQUFDO1lBRTVCLEtBQUssTUFBTSxJQUFJLElBQUksS0FBSyxFQUFFO2dCQUN4QixNQUFNLFVBQVUsR0FBRyxNQUFNLCtCQUFjLENBQUMsYUFBYSxDQUFDLFNBQVMsRUFBRSxVQUFVLEVBQUUsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUN0RixNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUU7b0JBQ3JCLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSztvQkFDakIsVUFBVSxFQUFFLElBQUksQ0FBQyxVQUFVO29CQUMzQixVQUFVLEVBQUUsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDL0QsQ0FBQyxDQUFDO2FBQ0o7WUFDRCxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUM7U0FDckQ7UUFFRCxNQUFNLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUU3QixJQUFJLE1BQU0sRUFBRTtZQUNWLDBEQUEwRDtZQUMxRCxLQUFLLE1BQU0sQ0FBQyxFQUFFLFVBQVUsQ0FBQyxJQUFJLE1BQU0sRUFBRTtnQkFDbkMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEVBQUU7b0JBQ3ZDLElBQUksUUFBUSxDQUFDLFlBQVksQ0FBQyxJQUFJLEtBQUssNEJBQWMsQ0FBQyxJQUFJLEVBQUU7d0JBQ3RELFFBQVEsQ0FBQyxVQUFVLEdBQUcsNEJBQWMsQ0FBQyxJQUFJLENBQUM7cUJBQzNDO2dCQUNILENBQUMsQ0FBQyxDQUFDO2FBQ0o7U0FDRjtRQUVELE9BQU8sTUFBTSxDQUFDO0lBQ2hCLENBQUM7SUFFTSxLQUFLLENBQUMsWUFBWSxDQUN2QixTQUFpQixFQUNqQixVQUFzQixFQUN0QixPQUFzQixFQUN0QixLQUFLLEdBQUcsS0FBSztRQUViLElBQUksS0FBSyxFQUFFO1lBQ1QsTUFBTSwrQkFBYyxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsVUFBVSxDQUFDLENBQUM7WUFDeEQsSUFBSSxDQUFDLGVBQWUsQ0FBQyxVQUFVLEVBQUUsU0FBUyxDQUFDLENBQUM7U0FDN0M7UUFFRCxNQUFNLGFBQWEsR0FBRyxNQUFNLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxFQUFFLFVBQVUsQ0FBQyxDQUFDO1FBQ2xFLE1BQU0sT0FBTyxHQUFHLElBQUksdUJBQWEsQ0FBQyxTQUFTLEVBQUUsYUFBYSxDQUFDLENBQUM7UUFFNUQsS0FBSyxNQUFNLENBQUMsRUFBRSxPQUFPLENBQUMsSUFBSSxPQUFPLENBQUMsR0FBRyxFQUFFLEVBQUU7WUFDdkMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQztTQUMxQjtRQUVELElBQUkscUJBQXFCLEdBQUcsS0FBSyxDQUFDO1FBRWxDLElBQUksT0FBTyxDQUFDLGFBQWEsQ0FBQyxNQUFNLEVBQUU7WUFDaEMsTUFBTSwrQkFBYyxDQUFDLFdBQVcsQ0FBQyxVQUFVLEVBQUUsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBQ3BFLHFCQUFxQixHQUFHLElBQUksQ0FBQztTQUM5QjtRQUVELEtBQUssTUFBTSxDQUFDLElBQUksRUFBRSxVQUFVLENBQUMsSUFBSSxPQUFPLENBQUMsa0JBQWtCLEVBQUU7WUFDM0QsTUFBTSxVQUFVLEdBQUcsTUFBTSwrQkFBYyxDQUFDLGNBQWMsQ0FBQyxTQUFTLEVBQUUsVUFBVSxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQ3BGLElBQUksVUFBVSxFQUFFO2dCQUNkLE1BQU0sK0JBQWMsQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLEVBQUUsVUFBVSxDQUFDLEVBQUUsRUFBRSxVQUFVLENBQUMsQ0FBQztnQkFDN0UscUJBQXFCLEdBQUcsSUFBSSxDQUFDO2FBQzlCO2lCQUFNO2dCQUNMLE1BQU0sSUFBSSxTQUFHLENBQUMsT0FBTyxVQUFVLFNBQVMsSUFBSSxxQkFBcUIsQ0FBQyxDQUFDO2FBQ3BFO1NBQ0Y7UUFFRCxJQUFJLHFCQUFxQixFQUFFO1lBQ3pCLHVCQUF1QjtZQUN2QixJQUFJLENBQUMsZUFBZSxDQUFDLFVBQVUsRUFBRSxTQUFTLENBQUMsQ0FBQztTQUM3QztJQUNILENBQUM7SUFFTSxLQUFLLENBQUMsZUFBZSxDQUMxQixTQUFpQixFQUNqQixZQUFvQixFQUNwQixVQUFrQyxFQUNsQyxlQUF5QixFQUN6QixpQkFBMkIsRUFDM0IsaUJBQTJCLEVBQzNCLE1BQWU7UUFFZixNQUFNLE1BQU0sR0FBRyxNQUFNLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxFQUFFLHdCQUFVLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQ3hFLE1BQU0sVUFBVSxHQUFHLElBQUksc0JBQWdCLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLENBQUMsR0FBRyxDQUNoRSwwQkFBMEIsQ0FDakIsQ0FBQyxDQUFDO1FBRWIsbURBQW1EO1FBQ25ELEtBQUssTUFBTSxhQUFhLElBQUksZUFBZSxFQUFFO1lBQzNDLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxFQUFFO2dCQUMxQyxNQUFNLElBQUksbUNBQWdCLENBQUMsc0JBQXNCLGFBQWEsbUJBQW1CLENBQUMsQ0FBQzthQUNwRjtTQUNGO1FBRUQsb0NBQW9DO1FBQ3BDLGlGQUFpRjtRQUNqRixNQUFNLGlCQUFpQixHQUFHLENBQUMsQ0FBQyxPQUFPLENBQ2pDLENBQUMsQ0FBQyxLQUFLLENBQUMsZUFBZSxFQUFFLFlBQVksQ0FBQyxVQUFVLENBQUMsRUFDakQsR0FBRyxpQkFBaUIsQ0FDckIsQ0FBQztRQUVGLE1BQU0sT0FBTyxHQUFHLElBQUksdUJBQWEsQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFFLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUUvRCwrRkFBK0Y7UUFDL0YsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsVUFBVSxFQUFFLFlBQVksQ0FBQyxJQUFJLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztJQUNqRyxDQUFDO0lBRU0sS0FBSyxDQUFDLGVBQWUsQ0FDMUIsU0FBaUIsRUFDakIsWUFBb0IsRUFDcEIsVUFBa0MsRUFDbEMsaUJBQTJCLEVBQzNCLE1BQWU7UUFFZixNQUFNLE1BQU0sR0FBRyxNQUFNLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxFQUFFLHdCQUFVLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQ3hFLE1BQU0sVUFBVSxHQUFHLElBQUksc0JBQWdCLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLENBQUMsR0FBRyxDQUNoRSwwQkFBMEIsQ0FDakIsQ0FBQyxDQUFDO1FBRWIsMkNBQTJDO1FBQzNDLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUM5QyxNQUFNLElBQUksbUNBQWdCLENBQUMsc0JBQXNCLFlBQVksQ0FBQyxJQUFJLG1CQUFtQixDQUFDLENBQUM7U0FDeEY7UUFFRCxNQUFNLE9BQU8sR0FBRyxJQUFJLHVCQUFhLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFL0QsMEZBQTBGO1FBQzFGLElBQUksQ0FBQyxXQUFXLENBQ2QsT0FBTyxFQUNQLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxFQUNuQixVQUFVLEVBQ1YsWUFBWSxDQUFDLElBQUksRUFDakIsaUJBQWlCLENBQ2xCLENBQUM7SUFDSixDQUFDO0lBRUQ7O09BRUc7SUFDSSxXQUFXLENBQ2hCLE9BQXlCLEVBQ3pCLE1BQWdCLEVBQ2hCLFVBQWtDLEVBQ2xDLFlBQW9DLEVBQ3BDLFdBQXFCO1FBRXJCLHVEQUF1RDtRQUN2RCx3RkFBd0Y7UUFDeEYsZ0ZBQWdGO1FBQ2hGLHlGQUF5RjtRQUN6Rix1RUFBdUU7UUFDdkUsTUFBTSxzQkFBc0IsR0FBRyxPQUFPLENBQUMsb0JBQW9CLENBQUMsTUFBTSxFQUFFLFlBQVksQ0FBQyxDQUFDO1FBRWxGLDhCQUE4QjtRQUM5QixrRUFBa0U7UUFDbEUsTUFBTSxXQUFXLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxVQUFVLEVBQUUsc0JBQXNCLENBQUMsRUFBRSxXQUFXLENBQUMsQ0FBQztRQUU1RiwrQ0FBK0M7UUFDL0MsT0FBTyxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsV0FBVyxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUVNLEtBQUssQ0FBQyxTQUFTLENBQ3BCLFNBQWlCLEVBQ2pCLElBQXlCLEVBQ3pCLE1BQWU7UUFFZixNQUFNLE1BQU0sR0FBRyxNQUFNLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxFQUFFLHdCQUFVLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQ3hFLE1BQU0sVUFBVSxHQUFHLElBQUksc0JBQWdCLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLENBQUMsR0FBRyxDQUNoRSwwQkFBMEIsQ0FDakIsQ0FBQyxDQUFDO1FBRWIsNkNBQTZDO1FBQzdDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ2pDLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxFQUFFO2dCQUNyQyxNQUFNLElBQUksbUNBQWdCLENBQUMsc0JBQXNCLFFBQVEsbUJBQW1CLENBQUMsQ0FBQzthQUMvRTtRQUNILENBQUMsQ0FBQyxDQUFDO1FBRUgsTUFBTSxPQUFPLEdBQUcsSUFBSSx1QkFBYSxDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUUsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRS9ELG1DQUFtQztRQUNuQyxPQUFPLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBRTlDLE9BQU8sSUFBNkIsQ0FBQztJQUN2QyxDQUFDO0lBRU0sS0FBSyxDQUFDLFNBQVMsQ0FDcEIsU0FBaUIsRUFDakIsSUFBeUIsRUFDekIsTUFBZTtRQUVmLE1BQU0sTUFBTSxHQUFHLE1BQU0sSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLEVBQUUsd0JBQVUsQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDeEUsTUFBTSxVQUFVLEdBQUcsSUFBSSxzQkFBZ0IsQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU0sQ0FBQyxHQUFHLENBQ2hFLDBCQUEwQixDQUNqQixDQUFDLENBQUM7UUFFYixzQ0FBc0M7UUFDdEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ3RDLE1BQU0sSUFBSSxtQ0FBZ0IsQ0FBQyxrQkFBa0IsSUFBSSxDQUFDLElBQUkscUJBQXFCLENBQUMsQ0FBQztTQUM5RTtRQUVELE1BQU0sT0FBTyxHQUFHLElBQUksdUJBQWEsQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFFLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUUvRCxtQ0FBbUM7UUFDbkMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFMUMsT0FBTyxJQUE2QixDQUFDO0lBQ3ZDLENBQUM7SUFFTSxLQUFLLENBQUMsVUFBVSxDQUNyQixTQUFpQixFQUNqQixJQUEyQjtRQUUzQixNQUFNLE1BQU0sR0FBd0IsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUV0RCxNQUFNLENBQUMsSUFBSSxHQUFHLE1BQU0sSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsd0JBQVUsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFNUYsT0FBTyxNQUEwQixDQUFDO0lBQ3BDLENBQUM7SUFFTSxLQUFLLENBQUMsVUFBVSxDQUNyQixTQUFpQixFQUNqQixJQUEyQjtRQUUzQixNQUFNLE1BQU0sR0FBd0IsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUV0RCxNQUFNLENBQUMsSUFBSSxHQUFHLE1BQU0sSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsd0JBQVUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBRXhGLE9BQU8sTUFBMEIsQ0FBQztJQUNwQyxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNJLEtBQUssQ0FBQyxVQUFVLENBQ3JCLFNBQWlCLEVBQ2pCLFVBQXNCLEVBQ3RCLE1BQWdCLEVBQ2hCLElBQXVCO1FBRXZCLE1BQU0sTUFBTSxHQUFHLE1BQU0sSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFDM0QsTUFBTSxVQUFVLEdBQUcsSUFBSSxzQkFBZ0IsQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBRTVELE9BQU8sVUFBVSxDQUFDLG9CQUFvQixDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztJQUN2RCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNJLEtBQUssQ0FBQyxjQUFjLENBQ3pCLFNBQWlCLEVBQ2pCLEtBQWUsRUFDZixNQUFlO1FBRWYsTUFBTSxlQUFlLEdBQTRDLEVBQUUsQ0FBQztRQUNwRSxNQUFNLE1BQU0sR0FBRyxNQUFNLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxFQUFFLHdCQUFVLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQ3hFLE1BQU0sVUFBVSxHQUFHLElBQUksc0JBQWdCLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLENBQUMsR0FBRyxDQUNoRSwwQkFBMEIsQ0FDakIsQ0FBQyxDQUFDO1FBRWIsS0FBSyxNQUFNLElBQUksSUFBSSxLQUFLLEVBQUU7WUFDeEIsTUFBTSxFQUFDLDZCQUE2QixFQUFFLElBQUksRUFBRSxVQUFVLEtBQTRCLElBQUksRUFBOUIsMkZBQThCLENBQUM7WUFDdkYsTUFBTSxtQkFBbUIsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNuRixJQUFJLG1CQUFtQixDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7Z0JBQ2xDLDhFQUE4RTtnQkFDOUUsK0NBQStDO2dCQUMvQyxNQUFNLGVBQWUsR0FBRyw2QkFBNkI7b0JBQ25ELENBQUMsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxFQUFFLElBQUksQ0FBQztvQkFDakYsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDVCxlQUFlLENBQUMsSUFBSSxDQUNsQixNQUFNLENBQUMsTUFBTSxDQUNYO29CQUNFLFVBQVUsRUFBRSxtQkFBbUI7b0JBQy9CLElBQUksRUFBRSxVQUFVLENBQUMsU0FBUyxDQUFDLG1CQUFtQixFQUFFLGVBQWUsQ0FBQztpQkFDakUsRUFDRCxtQkFBbUIsQ0FDcEIsQ0FDRixDQUFDO2FBQ0g7U0FDRjtRQUVELE9BQU8sZUFBZSxDQUFDO0lBQ3pCLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ksS0FBSyxDQUFDLGNBQWMsQ0FDekIsU0FBaUIsRUFDakIsS0FBZSxFQUNmLE1BQWU7UUFFZixNQUFNLGVBQWUsR0FBNEMsRUFBRSxDQUFDO1FBQ3BFLE1BQU0sTUFBTSxHQUFHLE1BQU0sSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLEVBQUUsd0JBQVUsQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDeEUsTUFBTSxVQUFVLEdBQUcsSUFBSSxzQkFBZ0IsQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU0sQ0FBQyxHQUFHLENBQ2hFLDBCQUEwQixDQUNqQixDQUFDLENBQUM7UUFFYixLQUFLLE1BQU0sSUFBSSxJQUFJLEtBQUssRUFBRTtZQUN4QixNQUFNLEVBQUMsNkJBQTZCLEVBQUUsSUFBSSxFQUFFLElBQUksS0FBNEIsSUFBSSxFQUE5QixxRkFBOEIsQ0FBQztZQUNqRixJQUFJLFVBQVUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUNyQyw4RUFBOEU7Z0JBQzlFLCtDQUErQztnQkFDL0MsTUFBTSxlQUFlLEdBQUcsNkJBQTZCO29CQUNuRCxDQUFDLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQztvQkFDcEUsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDVCxlQUFlLENBQUMsSUFBSSxDQUNsQixNQUFNLENBQUMsTUFBTSxDQUNYO29CQUNFLElBQUksRUFBRSxJQUFJO29CQUNWLElBQUksRUFBRSxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsZUFBZSxDQUFDO2lCQUNwRCxFQUNELG1CQUFtQixDQUNwQixDQUNGLENBQUM7YUFDSDtTQUNGO1FBRUQsT0FBTyxlQUFlLENBQUM7SUFDekIsQ0FBQztJQUVPLE1BQU0sQ0FBQyxLQUFLLENBQUMsa0JBQWtCLENBQ3JDLFNBQWlCLEVBQ2pCLFVBQXNCLEVBQ3RCLEtBQWE7UUFFYixNQUFNLFlBQVksR0FBRyxNQUFNLCtCQUFjLENBQUMsY0FBYyxDQUFDLFNBQVMsRUFBRSxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFdkYsSUFBSSxZQUFZLEVBQUU7WUFDaEIsTUFBTSxJQUFJLHVDQUFrQixDQUFDLE9BQU8sVUFBVSxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7U0FDL0Q7SUFDSCxDQUFDO0lBRU8sTUFBTSxDQUFDLEtBQUssQ0FBQyxlQUFlLENBQ2xDLFNBQWlCLEVBQ2pCLFVBQXNCLEVBQ3RCLEtBQWE7UUFFYixNQUFNLFlBQVksR0FBRyxNQUFNLCtCQUFjLENBQUMsY0FBYyxDQUFDLFNBQVMsRUFBRSxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFdkYsSUFBSSxDQUFDLFlBQVksRUFBRTtZQUNqQixNQUFNLElBQUksNkJBQWEsQ0FDckIsVUFBVSxHQUFHLGlCQUFpQixFQUM5QixPQUFPLFVBQVUsU0FBUyxLQUFLLGtCQUFrQixDQUNsRCxDQUFDO1NBQ0g7UUFFRCxPQUFPLFlBQVksQ0FBQztJQUN0QixDQUFDO0lBRU8sTUFBTSxDQUFDLEtBQUssQ0FBQyxzQkFBc0IsQ0FDekMsU0FBaUIsRUFDakIsVUFBc0IsRUFDdEIsTUFBYyxFQUNkLEtBQWEsRUFDYixXQUFtQjtRQUVuQixNQUFNLGdCQUFnQixHQUFHLE1BQU0sK0JBQWMsQ0FBQyxrQkFBa0IsQ0FDOUQsU0FBUyxFQUNULFVBQVUsRUFDVixNQUFNLEVBQ04sV0FBVyxDQUNaLENBQUM7UUFFRixJQUFJLGdCQUFnQixFQUFFO1lBQ3BCLE1BQU0sSUFBSSx1Q0FBa0IsQ0FBQyxPQUFPLFVBQVUsVUFBVSxLQUFLLGlCQUFpQixFQUFFLFdBQVcsQ0FBQyxDQUFDO1NBQzlGO0lBQ0gsQ0FBQztJQUVPLE1BQU0sQ0FBQyxLQUFLLENBQUMsbUJBQW1CLENBQ3RDLFNBQWlCLEVBQ2pCLFVBQXNCLEVBQ3RCLE1BQWMsRUFDZCxLQUFhLEVBQ2IsV0FBbUI7UUFFbkIsTUFBTSxnQkFBZ0IsR0FBRyxNQUFNLCtCQUFjLENBQUMsa0JBQWtCLENBQzlELFNBQVMsRUFDVCxVQUFVLEVBQ1YsTUFBTSxFQUNOLFdBQVcsQ0FDWixDQUFDO1FBRUYsSUFBSSxDQUFDLGdCQUFnQixFQUFFO1lBQ3JCLE1BQU0sSUFBSSw2QkFBYSxDQUNyQixVQUFVLEdBQUcscUJBQXFCLEVBQ2xDLE9BQU8sVUFBVSxVQUFVLEtBQUssb0JBQW9CLFdBQVcsbUJBQW1CLENBQ25GLENBQUM7U0FDSDtRQUVELE9BQU8sZ0JBQWdCLENBQUM7SUFDMUIsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxLQUFLLENBQUMsb0JBQW9CLENBQy9CLFNBQWlCLEVBQ2pCLFVBQXNCLEVBQ3RCLGdCQUEwQjtRQUUxQixJQUFJLGdCQUFnQixDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFDakMsT0FBTztTQUNSO1FBRUQsS0FBSyxNQUFNLGNBQWMsSUFBSSxnQkFBZ0IsRUFBRTtZQUM3QyxpRUFBaUU7WUFDakUsZ0VBQWdFO1lBQ2hFLE1BQU0sK0JBQWMsQ0FBQyxtQkFBbUIsQ0FBQyxTQUFTLEVBQUUsVUFBVSxFQUFFLGNBQWMsRUFBRTtnQkFDOUUsVUFBVSxFQUFFLDRCQUFjLENBQUMsSUFBSTthQUNoQyxDQUFDLENBQUM7U0FDSjtRQUVELE1BQU0sTUFBTSxHQUFHLE1BQU0sSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFDM0QsTUFBTSxhQUFhLEdBQUcsTUFBTSwrQkFBYyxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFFOUUsS0FBSyxNQUFNLFlBQVksSUFBSSxhQUFhLEVBQUU7WUFDeEMsTUFBTSxlQUFlLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUM7WUFFdkQsSUFBSSxlQUFlLEVBQUU7Z0JBQ25CLE1BQU0sZUFBZSxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQztnQkFDdEYsS0FBSyxNQUFNLGNBQWMsSUFBSSxnQkFBZ0IsRUFBRTtvQkFDN0MsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLEVBQUU7d0JBQ3hDLGdFQUFnRTt3QkFDaEUsMENBQTBDO3dCQUMxQyxNQUFNLCtCQUFjLENBQUMsY0FBYyxDQUFDLFVBQVUsRUFBRSxZQUFZLENBQUMsRUFBRSxFQUFFOzRCQUMvRCxTQUFTLEVBQUUsU0FBUzs0QkFDcEIsV0FBVyxFQUFFLGNBQWM7NEJBQzNCLFVBQVUsRUFBRSw0QkFBYyxDQUFDLElBQUk7NEJBQy9CLFlBQVksRUFBRTtnQ0FDWixJQUFJLEVBQUUsNEJBQWMsQ0FBQyxJQUFJOzZCQUMxQjs0QkFDRCxRQUFRLEVBQUUsS0FBSzt5QkFDaEIsQ0FBQyxDQUFDO3FCQUNKO2lCQUNGO2FBQ0Y7U0FDRjtRQUVELElBQUksQ0FBQyxlQUFlLENBQUMsVUFBVSxFQUFFLFNBQVMsQ0FBQyxDQUFDO0lBQzlDLENBQUM7SUFFRDs7T0FFRztJQUNLLHFCQUFxQixDQUMzQixrQkFBc0MsRUFDdEMsSUFBNEI7UUFFNUIsa0JBQWtCLENBQUMsT0FBTyxDQUFDLENBQUMsY0FBYyxFQUFFLFdBQVcsRUFBRSxFQUFFO1lBQ3pELElBQUksY0FBYyxLQUFLLElBQUksRUFBRTtnQkFDM0IsT0FBTzthQUNSO1lBRUQsTUFBTSxZQUFZLEdBQUcsY0FBYyxDQUFDLFlBQVksQ0FBQztZQUNqRCxNQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7WUFFeEMsTUFBTSxZQUFZLEdBQ2hCLFlBQVksQ0FBQyxJQUFJLEtBQUssNEJBQWMsQ0FBQyxJQUFJO2dCQUN6QyxZQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sS0FBSywwQkFBWSxDQUFDLE1BQU0sQ0FBQztZQUV0RCxNQUFNLGdCQUFnQixHQUNwQixZQUFZLENBQUMsSUFBSSxLQUFLLDRCQUFjLENBQUMsUUFBUTtnQkFDN0MsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEtBQUssOEJBQWdCLENBQUMsTUFBTSxDQUFDO1lBRTFELElBQUksWUFBWSxJQUFJLGdCQUFnQixFQUFFO2dCQUNwQyw0Q0FBNEM7Z0JBQzVDLHFCQUFxQjtnQkFDckIsNENBQTRDO2dCQUM1Qyx1Q0FBdUM7Z0JBQ3ZDLGdGQUFnRjtnQkFDaEYsTUFBTSxVQUFVLEdBQUcsWUFBWTtvQkFDN0IsQ0FBQyxDQUFDLHNCQUFnQixDQUFDLFlBQVksQ0FBQyxhQUFhLENBQUM7b0JBQzlDLENBQUMsQ0FBQyxzQkFBZ0IsQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLENBQUMsQ0FBQztnQkFFckQsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxFQUFFO29CQUM5QixJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsVUFBVSxDQUFDO2lCQUNoQzthQUNGO1FBQ0gsQ0FBQyxDQUFDLENBQUM7UUFFSCxPQUFPLElBQUksQ0FBQztJQUNkLENBQUM7Q0FDRjtBQUVELGlCQUFTLElBQUksa0JBQWtCLEVBQUUsQ0FBQyJ9