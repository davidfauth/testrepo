"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-06-22.
 */
Object.defineProperty(exports, "__esModule", { value: true });
// TS2019-DONE
const rest_client_1 = require("@linkurious/rest-client");
const _ = require("lodash");
const LKE = require("../");
const visualizationDAO_1 = require("../../dao/sql/visualizationDAO");
const builder_1 = require("./builder");
const Utils = LKE.getUtils();
const Config = LKE.getConfig();
const Log = LKE.getLogger(__filename);
class SchemaSampler {
    constructor(sourceKey, graph, onProgressChange) {
        this.totalTypesSampled = 0;
        this.addedItemsFromVizs = 0;
        this.isStopped = false;
        this.sourceKey = sourceKey;
        this.graph = graph;
        this.sampledItemsPerType = Config.get('advanced.sampledItemsPerType');
        this.sampledVisualizationItems = Config.get('advanced.sampledVisualizationItems');
        this.onProgressChange = onProgressChange;
    }
    /**
     * A human readable description of the status of the sampling.
     */
    get status() {
        if (Utils.hasValue(this.currentTypeSampled) && Utils.hasValue(this.currentEntityTypeSampled)) {
            return `Sampling ${this.currentEntityTypeSampled}s with type: ${this.currentTypeSampled}`;
        }
        return `Starting sampling of the data-source`;
    }
    /**
     * Ratio between the types that are sampled and all the types in general.
     */
    get progress() {
        let progress = 0;
        if (Utils.hasValue(this.totalTypesToSample)) {
            // progress is 50% from data-source sampling and 50% from visualization sampling
            progress =
                (this.totalTypesSampled / this.totalTypesToSample) * 50 +
                    (this.addedItemsFromVizs / this.sampledVisualizationItems) * 50;
        }
        return progress;
    }
    async sampleType(entityType, types) {
        this.currentEntityTypeSampled = entityType;
        const schemaBuilder = new builder_1.SchemaBuilder();
        if (this.sampledItemsPerType === 0) {
            return schemaBuilder;
        }
        for (const type of types) {
            this.currentTypeSampled = type;
            Log.info(this.status);
            if (this.isStopped) {
                break;
            }
            const getStream = entityType === rest_client_1.EntityType.NODE
                ? this.graph.getNodeStream.bind(this.graph)
                : this.graph.getEdgeStream.bind(this.graph);
            const stream = await getStream({
                type: type,
                limit: this.sampledItemsPerType
            });
            await new Promise((resolve, reject) => {
                stream
                    .on('data', (lkItem) => {
                    if (entityType === rest_client_1.EntityType.NODE) {
                        schemaBuilder.addItem(lkItem.categories, lkItem.data);
                    }
                    else {
                        schemaBuilder.addItem([lkItem.type], lkItem.data);
                    }
                })
                    .on('end', () => {
                    resolve();
                })
                    .on('error', (error) => {
                    Log.error(`Sampling ${entityType} type "${type}" resulted in an error`, error);
                    reject(error);
                })
                    .resume();
            });
            this.totalTypesSampled++;
            if (Utils.hasValue(this.onProgressChange)) {
                this.onProgressChange(this.progress);
            }
        }
        return schemaBuilder;
    }
    async sampleVisualizations(nodeSchemaBuilder, edgeSchemaBuilder) {
        let visualizationOffset = 0;
        while (this.addedItemsFromVizs < this.sampledVisualizationItems && !this.isStopped) {
            // 1) we retrieve one visualization at the time
            const visualizations = await visualizationDAO_1.VisualizationDAO.getVisualizations(this.sourceKey, 1, visualizationOffset++);
            // 2) if no visualization is returned, no more visualizations to sample are available
            if (visualizations.length === 0) {
                break;
            }
            const visualization = visualizations[0];
            // 3) we collect all ids from the the visualization
            let nodeIds = _.map(visualization.nodes, 'id');
            let edgeIds = _.map(visualization.edges, 'id');
            // 4) we avoid to fetch too many items by slicing the list of ids
            nodeIds = nodeIds.slice(0, this.sampledVisualizationItems - this.addedItemsFromVizs);
            edgeIds = edgeIds.slice(0, this.sampledVisualizationItems - this.addedItemsFromVizs);
            // 5) we retrieve the items
            const nodes = await this.graph.getNodesByID({
                ids: nodeIds,
                ignoreMissing: true,
                alternativeId: visualization.alternativeIds.node
            });
            const edges = await this.graph.getEdgesByID({
                ids: edgeIds,
                ignoreMissing: true,
                alternativeId: visualization.alternativeIds.edge
            });
            // 6) we add the items to the schema builders
            nodes.forEach(node => {
                nodeSchemaBuilder.addItem(node.categories, node.data);
            });
            edges.forEach(edge => {
                edgeSchemaBuilder.addItem([edge.type], edge.data);
            });
            this.addedItemsFromVizs += nodes.length + edges.length;
        }
    }
    async sample() {
        // 1) we get the list of node categories and edge types
        const simpleSchema = await this.graph.getSimpleSchema();
        this.totalTypesToSample = simpleSchema.nodeCategories.length + simpleSchema.edgeTypes.length;
        Log.info(`Start sampling for ${simpleSchema.nodeCategories.length} node categories.`);
        const nodeSchemaBuilder = await this.sampleType(rest_client_1.EntityType.NODE, simpleSchema.nodeCategories);
        Log.info(`Start sampling for ${simpleSchema.edgeTypes.length} edge types.`);
        const edgeSchemaBuilder = await this.sampleType(rest_client_1.EntityType.EDGE, simpleSchema.edgeTypes);
        Log.info('Start sampling for ' +
            this.sampledVisualizationItems +
            ' nodes and edges from existing visualizations.');
        await this.sampleVisualizations(nodeSchemaBuilder, edgeSchemaBuilder);
        Log.info(`Sampling done.`);
        return {
            nodeSchemaBuilder: nodeSchemaBuilder,
            edgeSchemaBuilder: edgeSchemaBuilder
        };
    }
    stop() {
        Log.info('Schema sampler was stopped.');
        this.isStopped = true;
    }
}
exports.SchemaSampler = SchemaSampler;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2FtcGxlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9zZXJ2aWNlcy9ncmFwaFNjaGVtYS9zYW1wbGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRzs7QUFFSCxjQUFjO0FBRWQseURBQW1FO0FBQ25FLDRCQUE0QjtBQUU1QiwyQkFBNEI7QUFJNUIscUVBQWdFO0FBR2hFLHVDQUF3QztBQUV4QyxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7QUFFdEMsTUFBYSxhQUFhO0lBYXhCLFlBQ0UsU0FBaUIsRUFDakIsS0FBa0QsRUFDbEQsZ0JBQTZDO1FBVnZDLHNCQUFpQixHQUFHLENBQUMsQ0FBQztRQUV0Qix1QkFBa0IsR0FBRyxDQUFDLENBQUM7UUFHeEIsY0FBUyxHQUFHLEtBQUssQ0FBQztRQU92QixJQUFJLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQztRQUMzQixJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztRQUNuQixJQUFJLENBQUMsbUJBQW1CLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyw4QkFBOEIsQ0FBVyxDQUFDO1FBQ2hGLElBQUksQ0FBQyx5QkFBeUIsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLG9DQUFvQyxDQUFXLENBQUM7UUFDNUYsSUFBSSxDQUFDLGdCQUFnQixHQUFHLGdCQUFnQixDQUFDO0lBQzNDLENBQUM7SUFFRDs7T0FFRztJQUNILElBQVcsTUFBTTtRQUNmLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxFQUFFO1lBQzVGLE9BQU8sWUFBWSxJQUFJLENBQUMsd0JBQXdCLGdCQUFnQixJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztTQUMzRjtRQUNELE9BQU8sc0NBQXNDLENBQUM7SUFDaEQsQ0FBQztJQUVEOztPQUVHO0lBQ0gsSUFBVyxRQUFRO1FBQ2pCLElBQUksUUFBUSxHQUFHLENBQUMsQ0FBQztRQUNqQixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEVBQUU7WUFDM0MsZ0ZBQWdGO1lBQ2hGLFFBQVE7Z0JBQ04sQ0FBQyxJQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEdBQUcsRUFBRTtvQkFDdkQsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDLHlCQUF5QixDQUFDLEdBQUcsRUFBRSxDQUFDO1NBQ25FO1FBQ0QsT0FBTyxRQUFRLENBQUM7SUFDbEIsQ0FBQztJQUVPLEtBQUssQ0FBQyxVQUFVLENBQUMsVUFBc0IsRUFBRSxLQUFlO1FBQzlELElBQUksQ0FBQyx3QkFBd0IsR0FBRyxVQUFVLENBQUM7UUFDM0MsTUFBTSxhQUFhLEdBQUcsSUFBSSx1QkFBYSxFQUFFLENBQUM7UUFFMUMsSUFBSSxJQUFJLENBQUMsbUJBQW1CLEtBQUssQ0FBQyxFQUFFO1lBQ2xDLE9BQU8sYUFBYSxDQUFDO1NBQ3RCO1FBRUQsS0FBSyxNQUFNLElBQUksSUFBSSxLQUFLLEVBQUU7WUFDeEIsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQztZQUMvQixHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUV0QixJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7Z0JBQ2xCLE1BQU07YUFDUDtZQUVELE1BQU0sU0FBUyxHQUNiLFVBQVUsS0FBSyx3QkFBVSxDQUFDLElBQUk7Z0JBQzVCLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztnQkFDM0MsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7WUFFaEQsTUFBTSxNQUFNLEdBQThCLE1BQU0sU0FBUyxDQUFDO2dCQUN4RCxJQUFJLEVBQUUsSUFBSTtnQkFDVixLQUFLLEVBQUUsSUFBSSxDQUFDLG1CQUFtQjthQUNoQyxDQUFDLENBQUM7WUFFSCxNQUFNLElBQUksT0FBTyxDQUFDLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxFQUFFO2dCQUNwQyxNQUFNO3FCQUNILEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxNQUF1QixFQUFFLEVBQUU7b0JBQ3RDLElBQUksVUFBVSxLQUFLLHdCQUFVLENBQUMsSUFBSSxFQUFFO3dCQUNsQyxhQUFhLENBQUMsT0FBTyxDQUFFLE1BQWlCLENBQUMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztxQkFDbkU7eUJBQU07d0JBQ0wsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFFLE1BQWlCLENBQUMsSUFBSSxDQUFDLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUMvRDtnQkFDSCxDQUFDLENBQUM7cUJBQ0QsRUFBRSxDQUFDLEtBQUssRUFBRSxHQUFHLEVBQUU7b0JBQ2QsT0FBTyxFQUFFLENBQUM7Z0JBQ1osQ0FBQyxDQUFDO3FCQUNELEVBQUUsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxLQUFZLEVBQUUsRUFBRTtvQkFDNUIsR0FBRyxDQUFDLEtBQUssQ0FBQyxZQUFZLFVBQVUsVUFBVSxJQUFJLHdCQUF3QixFQUFFLEtBQUssQ0FBQyxDQUFDO29CQUMvRSxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ2hCLENBQUMsQ0FBQztxQkFDRCxNQUFNLEVBQUUsQ0FBQztZQUNkLENBQUMsQ0FBQyxDQUFDO1lBRUgsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7WUFDekIsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFO2dCQUN6QyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2FBQ3RDO1NBQ0Y7UUFFRCxPQUFPLGFBQWEsQ0FBQztJQUN2QixDQUFDO0lBRU8sS0FBSyxDQUFDLG9CQUFvQixDQUNoQyxpQkFBZ0MsRUFDaEMsaUJBQWdDO1FBRWhDLElBQUksbUJBQW1CLEdBQUcsQ0FBQyxDQUFDO1FBQzVCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyx5QkFBeUIsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUU7WUFDbEYsK0NBQStDO1lBQy9DLE1BQU0sY0FBYyxHQUFHLE1BQU0sbUNBQWdCLENBQUMsaUJBQWlCLENBQzdELElBQUksQ0FBQyxTQUFTLEVBQ2QsQ0FBQyxFQUNELG1CQUFtQixFQUFFLENBQ3RCLENBQUM7WUFFRixxRkFBcUY7WUFDckYsSUFBSSxjQUFjLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtnQkFDL0IsTUFBTTthQUNQO1lBRUQsTUFBTSxhQUFhLEdBQUcsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRXhDLG1EQUFtRDtZQUNuRCxJQUFJLE9BQU8sR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDL0MsSUFBSSxPQUFPLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDO1lBRS9DLGlFQUFpRTtZQUNqRSxPQUFPLEdBQUcsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLHlCQUF5QixHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO1lBQ3JGLE9BQU8sR0FBRyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMseUJBQXlCLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUM7WUFFckYsMkJBQTJCO1lBQzNCLE1BQU0sS0FBSyxHQUFHLE1BQU0sSUFBSSxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUM7Z0JBQzFDLEdBQUcsRUFBRSxPQUFPO2dCQUNaLGFBQWEsRUFBRSxJQUFJO2dCQUNuQixhQUFhLEVBQUUsYUFBYSxDQUFDLGNBQWMsQ0FBQyxJQUFJO2FBQ2pELENBQUMsQ0FBQztZQUVILE1BQU0sS0FBSyxHQUFHLE1BQU0sSUFBSSxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUM7Z0JBQzFDLEdBQUcsRUFBRSxPQUFPO2dCQUNaLGFBQWEsRUFBRSxJQUFJO2dCQUNuQixhQUFhLEVBQUUsYUFBYSxDQUFDLGNBQWMsQ0FBQyxJQUFJO2FBQ2pELENBQUMsQ0FBQztZQUVILDZDQUE2QztZQUM3QyxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUNuQixpQkFBaUIsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDeEQsQ0FBQyxDQUFDLENBQUM7WUFFSCxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUNuQixpQkFBaUIsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ3BELENBQUMsQ0FBQyxDQUFDO1lBRUgsSUFBSSxDQUFDLGtCQUFrQixJQUFJLEtBQUssQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQztTQUN4RDtJQUNILENBQUM7SUFFTSxLQUFLLENBQUMsTUFBTTtRQUlqQix1REFBdUQ7UUFDdkQsTUFBTSxZQUFZLEdBQUcsTUFBTSxJQUFJLENBQUMsS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBRXhELElBQUksQ0FBQyxrQkFBa0IsR0FBRyxZQUFZLENBQUMsY0FBYyxDQUFDLE1BQU0sR0FBRyxZQUFZLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQztRQUU3RixHQUFHLENBQUMsSUFBSSxDQUFDLHNCQUFzQixZQUFZLENBQUMsY0FBYyxDQUFDLE1BQU0sbUJBQW1CLENBQUMsQ0FBQztRQUN0RixNQUFNLGlCQUFpQixHQUFHLE1BQU0sSUFBSSxDQUFDLFVBQVUsQ0FBQyx3QkFBVSxDQUFDLElBQUksRUFBRSxZQUFZLENBQUMsY0FBYyxDQUFDLENBQUM7UUFFOUYsR0FBRyxDQUFDLElBQUksQ0FBQyxzQkFBc0IsWUFBWSxDQUFDLFNBQVMsQ0FBQyxNQUFNLGNBQWMsQ0FBQyxDQUFDO1FBQzVFLE1BQU0saUJBQWlCLEdBQUcsTUFBTSxJQUFJLENBQUMsVUFBVSxDQUFDLHdCQUFVLENBQUMsSUFBSSxFQUFFLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUV6RixHQUFHLENBQUMsSUFBSSxDQUNOLHFCQUFxQjtZQUNuQixJQUFJLENBQUMseUJBQXlCO1lBQzlCLGdEQUFnRCxDQUNuRCxDQUFDO1FBQ0YsTUFBTSxJQUFJLENBQUMsb0JBQW9CLENBQUMsaUJBQWlCLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztRQUV0RSxHQUFHLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7UUFFM0IsT0FBTztZQUNMLGlCQUFpQixFQUFFLGlCQUFpQjtZQUNwQyxpQkFBaUIsRUFBRSxpQkFBaUI7U0FDckMsQ0FBQztJQUNKLENBQUM7SUFFTSxJQUFJO1FBQ1QsR0FBRyxDQUFDLElBQUksQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO1FBQ3hDLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO0lBQ3hCLENBQUM7Q0FDRjtBQS9MRCxzQ0ErTEMifQ==