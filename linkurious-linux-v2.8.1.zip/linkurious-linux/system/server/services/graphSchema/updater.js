"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-05-21.
 */
Object.defineProperty(exports, "__esModule", { value: true });
const LKE = require("../");
const Utils = LKE.getUtils();
/**
 * The schema updater is responsible for identifying the missing types and properties of the schema.
 * For each type added with the addType method, it performs a diff with the original schema and collects the
 * types and properties to create.
 */
class SchemaUpdater {
    constructor(sourceKey, schema) {
        this.newTypes = new Map();
        this.newProperties = new Map();
        this.sourceKey = sourceKey;
        this.schema = schema;
    }
    get typesToCreate() {
        return Array.from(this.newTypes.values());
    }
    get propertiesToCreate() {
        return this.newProperties;
    }
    addType(type) {
        let existingProperties = [];
        const schemaTypes = this.schema.get(type.label);
        if (schemaTypes) {
            // 1.a) Type already exist in the schema, collect existing properties
            existingProperties = schemaTypes.properties;
        }
        else if (!this.newTypes.has(type.label)) {
            // 1.b) Type was never seen before, add it
            this.newTypes.set(type.label, {
                sourceKey: this.sourceKey,
                label: type.label,
                visibility: type.visibility
            });
        }
        // Merge the properties if addType is called multiple times with the same type
        const newProperties = this.newProperties.get(type.label) || [];
        // 2) Merge schema properties and update properties
        existingProperties = existingProperties.concat(...newProperties);
        // 3) Add missing properties to the update
        const missingProperties = this.getMissingProperties(type.properties, existingProperties);
        this.newProperties.set(type.label, newProperties.concat(...missingProperties));
    }
    getMissingProperties(newProperties, existingProperties) {
        const missingProperties = [];
        const existingPropertiesIndex = Utils.indexBy(existingProperties, t => t.propertyKey);
        newProperties.forEach(p => {
            if (!existingPropertiesIndex.has(p.propertyKey)) {
                const missingProperty = Object.assign({ sourceKey: this.sourceKey }, p);
                missingProperties.push(missingProperty);
            }
        });
        return missingProperties;
    }
}
exports.SchemaUpdater = SchemaUpdater;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXBkYXRlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9zZXJ2aWNlcy9ncmFwaFNjaGVtYS91cGRhdGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRzs7QUFNSCwyQkFBNEI7QUFLNUIsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBRTdCOzs7O0dBSUc7QUFDSCxNQUFhLGFBQWE7SUFNeEIsWUFBWSxTQUFpQixFQUFFLE1BQW9CO1FBSGxDLGFBQVEsR0FBc0MsSUFBSSxHQUFHLEVBQUUsQ0FBQztRQUN4RCxrQkFBYSxHQUE0QyxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBR2xGLElBQUksQ0FBQyxTQUFTLEdBQUcsU0FBUyxDQUFDO1FBQzNCLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO0lBQ3ZCLENBQUM7SUFFRCxJQUFJLGFBQWE7UUFDZixPQUFPLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFFRCxJQUFJLGtCQUFrQjtRQUNwQixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUM7SUFDNUIsQ0FBQztJQUVNLE9BQU8sQ0FBQyxJQUFzQjtRQUNuQyxJQUFJLGtCQUFrQixHQUEyQixFQUFFLENBQUM7UUFFcEQsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRWhELElBQUksV0FBVyxFQUFFO1lBQ2YscUVBQXFFO1lBQ3JFLGtCQUFrQixHQUFHLFdBQVcsQ0FBQyxVQUFVLENBQUM7U0FDN0M7YUFBTSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ3pDLDBDQUEwQztZQUMxQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFO2dCQUM1QixTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7Z0JBQ3pCLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSztnQkFDakIsVUFBVSxFQUFFLElBQUksQ0FBQyxVQUFVO2FBQzVCLENBQUMsQ0FBQztTQUNKO1FBRUQsOEVBQThFO1FBQzlFLE1BQU0sYUFBYSxHQUErQixJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO1FBRTNGLG1EQUFtRDtRQUNuRCxrQkFBa0IsR0FBRyxrQkFBa0IsQ0FBQyxNQUFNLENBQUMsR0FBRyxhQUFhLENBQUMsQ0FBQztRQUVqRSwwQ0FBMEM7UUFDMUMsTUFBTSxpQkFBaUIsR0FBRyxJQUFJLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxrQkFBa0IsQ0FBQyxDQUFDO1FBRXpGLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsYUFBYSxDQUFDLE1BQU0sQ0FBQyxHQUFHLGlCQUFpQixDQUFDLENBQUMsQ0FBQztJQUNqRixDQUFDO0lBRU8sb0JBQW9CLENBQzFCLGFBQXFDLEVBQ3JDLGtCQUEwQztRQUUxQyxNQUFNLGlCQUFpQixHQUErQixFQUFFLENBQUM7UUFDekQsTUFBTSx1QkFBdUIsR0FBRyxLQUFLLENBQUMsT0FBTyxDQUFDLGtCQUFrQixFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBRXRGLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7WUFDeEIsSUFBSSxDQUFDLHVCQUF1QixDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEVBQUU7Z0JBQy9DLE1BQU0sZUFBZSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVMsRUFBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUN0RSxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7YUFDekM7UUFDSCxDQUFDLENBQUMsQ0FBQztRQUVILE9BQU8saUJBQWlCLENBQUM7SUFDM0IsQ0FBQztDQUNGO0FBaEVELHNDQWdFQyJ9