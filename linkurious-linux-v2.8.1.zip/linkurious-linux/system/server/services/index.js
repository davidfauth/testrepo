"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-11-04.
 */
const fs = require("fs");
const path = require("path");
class ServiceManager {
    constructor() {
        this.MODE_DEV = 'development';
        this.MODE_TEST = 'test';
        this.MODE_PRE_PROD = 'preprod';
        this.MODE_PROD = 'production';
        this.services = {};
        this.currentlyCreating = [];
        this.initDone = false;
        this.mode = this.DEFAULT_MODE;
        this.resetConfig = false;
    }
    /**
     * Must be called before anything LKE related.
     *
     * @param options
     * @param [options.mode='production'] Runtime mode ('production','preprod','development','test')
     * @param [options.resetConfig]       Whether to request a configuration reset
     */
    init(options) {
        if (this.initDone) {
            this.logger.warn('LKE: ignoring additional init');
            return;
        }
        if (options.resetConfig === true) {
            this.resetConfig = true;
        }
        this.initDone = true;
        this.logger = this.getLogger(__filename);
        const Utils = this.getUtils();
        if (Utils.hasValue(options.mode)) {
            Utils.check.values('mode', options.mode, this.MODES);
            this.mode = options.mode;
        }
    }
    get options() {
        return {
            mode: this.mode,
            resetConfig: this.resetConfig
        };
    }
    get DEFAULT_MODE() {
        return this.MODE_PROD;
    }
    /**
     * While parsing CLA, modes are parsed in this order (so the latter overrides the former).
     */
    get MODES() {
        return [this.MODE_DEV, this.MODE_TEST, this.MODE_PROD, this.MODE_PRE_PROD];
    }
    /**
     * Return true if we are in 'development' mode.
     */
    isDevMode() {
        return this.options.mode === this.MODE_DEV;
    }
    /**
     * Return true if we are in 'test' mode.
     */
    isTestMode() {
        return this.options.mode === this.MODE_TEST;
    }
    /**
     * Return true if we are in 'preprod' mode.
     */
    isPreProdMode() {
        return this.options.mode === this.MODE_PRE_PROD;
    }
    /**
     * Return true if we are in 'production' mode.
     */
    isProdMode() {
        return this.options.mode === this.MODE_PROD;
    }
    /**
     * Resolve a file path relative to Linkurious system directory.
     * Return an absolute file path.
     *
     * @param filePath a file path relative to the linkurious system root
     */
    systemFile(filePath) {
        return path.resolve(__dirname, '..', '..', filePath);
    }
    /**
     * Resolve a file path relative to Linkurious data directory.
     * Return an absolute file path.
     *
     * @param filePath a file path relative to the linkurious data root
     */
    dataFile(filePath) {
        if (filePath && path.isAbsolute(filePath)) {
            return filePath;
        }
        return this.systemFile('../data/' + filePath);
    }
    getRelease() {
        if (!this.releaseCache) {
            const release = JSON.parse(fs.readFileSync(this.systemFile('release.json')).toString());
            delete release.bodyFile;
            this.releaseCache = release;
        }
        return this.releaseCache;
    }
    /**
     * Get the current SemVer.
     */
    getVersion() {
        return this.getRelease().tag_name.substr(1);
    }
    /**
     * Get the version string (e.g.: 'Enterprise v0.9.4 (Snappy Squid)').
     */
    getVersionString() {
        return 'Enterprise ' + this.getRelease().tag_name + ' (' + this.getRelease().name + ')';
    }
    getAccess() {
        return this.get('access');
    }
    getAccessRightDAO() {
        return this.get('access/AccessRightDAO');
    }
    getOldGroupDAO() {
        return this.get('access/OldGroupDAO');
    }
    getUserDAO() {
        return this.get('access/UserDAO');
    }
    getAlert() {
        return this.get('alert');
    }
    getAnalytics() {
        return this.get('analytics');
    }
    getApplication() {
        return this.get('application');
    }
    getAuditTrail() {
        return this.get('auditTrail');
    }
    getGraphQuery() {
        return this.get('graphQuery');
    }
    getGraphSchema() {
        return this.get('graphSchema');
    }
    getVisualizationDAO() {
        return this.get('business/VisualizationDAO');
    }
    getVisualizationShareDAO() {
        return this.get('business/VisualizationShareDAO');
    }
    getWidget() {
        return this.get('widget');
    }
    getConfig() {
        return this.get('configuration');
    }
    getCustomFile() {
        return this.get('customFile');
    }
    getDataProxy() {
        return this.get('data/proxy');
    }
    getData() {
        return this.get('data');
    }
    getErrors() {
        return this.get('errors');
    }
    getFirstRun() {
        return this.get('firstRun');
    }
    getLayout() {
        return this.get('layout');
    }
    /**
     * @param targetFilePath Caller `__filename`
     * @param [subPackage]   An additional package to append to the chain generated by `targetFile`
     */
    getLogger(targetFilePath, subPackage) {
        return this.get('logger').createCustomLogger(targetFilePath, subPackage);
    }
    getScheduler() {
        return this.get('scheduler');
    }
    getSqlDb() {
        return this.get('sqlDb');
    }
    getStateMachine() {
        return this.get('stateMachine');
    }
    getUtils() {
        return this.get('utils');
    }
    getWebServer() {
        return this.get('webServer');
    }
    /**
     * Generate the url of Linkurious from the configuration file.
     *
     * @param [pathSuffix]
     */
    getBaseURL(pathSuffix = '') {
        const Config = this.getConfig();
        let url = '';
        // 1) scheme
        const scheme = Config.get('server.useHttps') ? 'https' : 'http';
        url += scheme + '://';
        // 2) domain
        url += Config.get('server.domain', '127.0.0.1');
        // 3) port
        const urlPort = '' +
            (Config.get('server.useHttps')
                ? Config.get('server.publicPortHttps', Config.get('server.listenPortHttps'))
                : Config.get('server.publicPortHttp', Config.get('server.listenPort')));
        if (scheme === 'http' ? urlPort !== '80' : urlPort !== '443') {
            // only add the port if it is not the default port for the scheme
            url += ':' + urlPort;
        }
        // 4) base path
        const baseFolder = Config.get('server.baseFolder');
        url += baseFolder !== null && baseFolder !== undefined ? `/${baseFolder}/` : '/';
        // 5) path suffix
        if (pathSuffix.startsWith('/')) {
            pathSuffix = pathSuffix.substring(1);
        }
        url += pathSuffix;
        return url;
    }
    /**
     * Create a new service instance for a given service key.
     *
     * @param key Key of the service
     */
    createService(key) {
        // track circular dependencies
        if (this.currentlyCreating.includes(key)) {
            this.currentlyCreating.push(key);
            throw new Error('Circular dependency detected while loading service (' +
                this.currentlyCreating.join(' -> ') +
                ').');
        }
        this.currentlyCreating.push(key);
        // find service folder/file and create service instance
        const servicePath = path.resolve(__dirname, key);
        if (fs.existsSync(servicePath + '.js') || fs.existsSync(servicePath + '/index.js')) {
            if (key !== 'logger') {
                this.logger.debug('Creating service instance: "' + key + '"');
            }
            const service = require('./' + key);
            this.currentlyCreating.pop();
            return service;
        }
        else {
            const m = 'Service does not exist: "' + key + '"';
            if (key !== 'logger') {
                this.logger.error(m);
                return;
            }
            else {
                throw m;
            }
        }
    }
    /**
     * Get a service singleton for a given service key.
     *
     * @param key Key of the service
     */
    get(key) {
        if (!this.initDone) {
            throw new Error('LKE.init must be called before any LKE.get calls (key: ' + key + ').');
        }
        // resolve the service
        let s = this.services[key];
        // if the service was not yet initialized, initialize the service
        if (s === undefined || s === null) {
            s = this.services[key] = this.createService(key);
        }
        return s;
    }
}
module.exports = new ServiceManager();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7OztHQUtHO0FBQ0gseUJBQXlCO0FBQ3pCLDZCQUE2QjtBQVc3QixNQUFNLGNBQWM7SUFBcEI7UUFDa0IsYUFBUSxHQUFHLGFBQWEsQ0FBQztRQUN6QixjQUFTLEdBQUcsTUFBTSxDQUFDO1FBQ25CLGtCQUFhLEdBQUcsU0FBUyxDQUFDO1FBQzFCLGNBQVMsR0FBRyxZQUFZLENBQUM7UUFFakMsYUFBUSxHQUEyQixFQUFFLENBQUM7UUFDdEMsc0JBQWlCLEdBQWEsRUFBRSxDQUFDO1FBRWpDLGFBQVEsR0FBRyxLQUFLLENBQUM7UUFFakIsU0FBSSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUM7UUFDekIsZ0JBQVcsR0FBRyxLQUFLLENBQUM7SUFnVjlCLENBQUM7SUE1VUM7Ozs7OztPQU1HO0lBQ0ksSUFBSSxDQUFDLE9BQStDO1FBQ3pELElBQUksSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNoQixJQUFJLENBQUMsTUFBdUIsQ0FBQyxJQUFJLENBQUMsK0JBQStCLENBQUMsQ0FBQztZQUNwRSxPQUFPO1NBQ1I7UUFFRCxJQUFJLE9BQU8sQ0FBQyxXQUFXLEtBQUssSUFBSSxFQUFFO1lBQ2hDLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDO1NBQ3pCO1FBRUQsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7UUFFckIsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3pDLE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUU5QixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ2hDLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNyRCxJQUFJLENBQUMsSUFBSSxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUM7U0FDMUI7SUFDSCxDQUFDO0lBRUQsSUFBVyxPQUFPO1FBQ2hCLE9BQU87WUFDTCxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUk7WUFDZixXQUFXLEVBQUUsSUFBSSxDQUFDLFdBQVc7U0FDOUIsQ0FBQztJQUNKLENBQUM7SUFFRCxJQUFXLFlBQVk7UUFDckIsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDO0lBQ3hCLENBQUM7SUFFRDs7T0FFRztJQUNILElBQVcsS0FBSztRQUNkLE9BQU8sQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDN0UsQ0FBQztJQUVEOztPQUVHO0lBQ0ksU0FBUztRQUNkLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEtBQUssSUFBSSxDQUFDLFFBQVEsQ0FBQztJQUM3QyxDQUFDO0lBRUQ7O09BRUc7SUFDSSxVQUFVO1FBQ2YsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksS0FBSyxJQUFJLENBQUMsU0FBUyxDQUFDO0lBQzlDLENBQUM7SUFFRDs7T0FFRztJQUNJLGFBQWE7UUFDbEIsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksS0FBSyxJQUFJLENBQUMsYUFBYSxDQUFDO0lBQ2xELENBQUM7SUFFRDs7T0FFRztJQUNJLFVBQVU7UUFDZixPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxLQUFLLElBQUksQ0FBQyxTQUFTLENBQUM7SUFDOUMsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksVUFBVSxDQUFDLFFBQWdCO1FBQ2hDLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxRQUFRLENBQUMsQ0FBQztJQUN2RCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxRQUFRLENBQUMsUUFBZ0I7UUFDOUIsSUFBSSxRQUFRLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUN6QyxPQUFPLFFBQVEsQ0FBQztTQUNqQjtRQUNELE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUVNLFVBQVU7UUFDZixJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRTtZQUN0QixNQUFNLE9BQU8sR0FLVCxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7WUFDNUUsT0FBTyxPQUFPLENBQUMsUUFBUSxDQUFDO1lBRXhCLElBQUksQ0FBQyxZQUFZLEdBQUcsT0FBTyxDQUFDO1NBQzdCO1FBRUQsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDO0lBQzNCLENBQUM7SUFFRDs7T0FFRztJQUNJLFVBQVU7UUFDZixPQUFPLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQzlDLENBQUM7SUFFRDs7T0FFRztJQUNJLGdCQUFnQjtRQUNyQixPQUFPLGFBQWEsR0FBRyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUMsUUFBUSxHQUFHLElBQUksR0FBRyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztJQUMxRixDQUFDO0lBRU0sU0FBUztRQUNkLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQWtCLENBQUM7SUFDN0MsQ0FBQztJQUVNLGlCQUFpQjtRQUN0QixPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsdUJBQXVCLENBQW1CLENBQUM7SUFDN0QsQ0FBQztJQUVNLGNBQWM7UUFDbkIsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLG9CQUFvQixDQUFnQixDQUFDO0lBQ3ZELENBQUM7SUFFTSxVQUFVO1FBQ2YsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFZLENBQUM7SUFDL0MsQ0FBQztJQUVNLFFBQVE7UUFDYixPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFpQixDQUFDO0lBQzNDLENBQUM7SUFFTSxZQUFZO1FBQ2pCLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQXFCLENBQUM7SUFDbkQsQ0FBQztJQUVNLGNBQWM7UUFDbkIsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBdUIsQ0FBQztJQUN2RCxDQUFDO0lBRU0sYUFBYTtRQUNsQixPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFzQixDQUFDO0lBQ3JELENBQUM7SUFFTSxhQUFhO1FBQ2xCLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQXNCLENBQUM7SUFDckQsQ0FBQztJQUVNLGNBQWM7UUFDbkIsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBdUIsQ0FBQztJQUN2RCxDQUFDO0lBRU0sbUJBQW1CO1FBQ3hCLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQywyQkFBMkIsQ0FBcUIsQ0FBQztJQUNuRSxDQUFDO0lBRU0sd0JBQXdCO1FBQzdCLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxnQ0FBZ0MsQ0FBMEIsQ0FBQztJQUM3RSxDQUFDO0lBRU0sU0FBUztRQUNkLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQWtCLENBQUM7SUFDN0MsQ0FBQztJQUVNLFNBQVM7UUFDZCxPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUF5QixDQUFDO0lBQzNELENBQUM7SUFFTSxhQUFhO1FBQ2xCLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQXNCLENBQUM7SUFDckQsQ0FBQztJQUVNLFlBQVk7UUFDakIsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBYyxDQUFDO0lBQzdDLENBQUM7SUFFTSxPQUFPO1FBQ1osT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBZ0IsQ0FBQztJQUN6QyxDQUFDO0lBRU0sU0FBUztRQUNkLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQWlCLENBQUM7SUFDNUMsQ0FBQztJQUVNLFdBQVc7UUFDaEIsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBb0IsQ0FBQztJQUNqRCxDQUFDO0lBRU0sU0FBUztRQUNkLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQWtCLENBQUM7SUFDN0MsQ0FBQztJQUVEOzs7T0FHRztJQUNJLFNBQVMsQ0FBQyxjQUFzQixFQUFFLFVBQW1CO1FBQzFELE9BQVEsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQW1CLENBQUMsa0JBQWtCLENBQUMsY0FBYyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0lBQzlGLENBQUM7SUFFTSxZQUFZO1FBQ2pCLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQXFCLENBQUM7SUFDbkQsQ0FBQztJQUVNLFFBQVE7UUFDYixPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFpQixDQUFDO0lBQzNDLENBQUM7SUFFTSxlQUFlO1FBQ3BCLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQXdCLENBQUM7SUFDekQsQ0FBQztJQUVNLFFBQVE7UUFDYixPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFpQixDQUFDO0lBQzNDLENBQUM7SUFFTSxZQUFZO1FBQ2pCLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQXFCLENBQUM7SUFDbkQsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxVQUFVLENBQUMsVUFBVSxHQUFHLEVBQUU7UUFDL0IsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ2hDLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQztRQUViLFlBQVk7UUFDWixNQUFNLE1BQU0sR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO1FBQ2hFLEdBQUcsSUFBSSxNQUFNLEdBQUcsS0FBSyxDQUFDO1FBRXRCLFlBQVk7UUFDWixHQUFHLElBQUksTUFBTSxDQUFDLEdBQUcsQ0FBQyxlQUFlLEVBQUUsV0FBVyxDQUFDLENBQUM7UUFFaEQsVUFBVTtRQUNWLE1BQU0sT0FBTyxHQUNYLEVBQUU7WUFDRixDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUM7Z0JBQzVCLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLHdCQUF3QixFQUFFLE1BQU0sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLENBQUMsQ0FBQztnQkFDNUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsdUJBQXVCLEVBQUUsTUFBTSxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM1RSxJQUFJLE1BQU0sS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sS0FBSyxLQUFLLEVBQUU7WUFDNUQsaUVBQWlFO1lBQ2pFLEdBQUcsSUFBSSxHQUFHLEdBQUcsT0FBTyxDQUFDO1NBQ3RCO1FBRUQsZUFBZTtRQUNmLE1BQU0sVUFBVSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLENBQUMsQ0FBQztRQUNuRCxHQUFHLElBQUksVUFBVSxLQUFLLElBQUksSUFBSSxVQUFVLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7UUFFakYsaUJBQWlCO1FBQ2pCLElBQUksVUFBVSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUM5QixVQUFVLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUN0QztRQUNELEdBQUcsSUFBSSxVQUFVLENBQUM7UUFFbEIsT0FBTyxHQUFHLENBQUM7SUFDYixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNLLGFBQWEsQ0FBQyxHQUFXO1FBQy9CLDhCQUE4QjtRQUM5QixJQUFJLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDeEMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNqQyxNQUFNLElBQUksS0FBSyxDQUNiLHNEQUFzRDtnQkFDcEQsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7Z0JBQ25DLElBQUksQ0FDUCxDQUFDO1NBQ0g7UUFDRCxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBRWpDLHVEQUF1RDtRQUN2RCxNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNqRCxJQUFJLEVBQUUsQ0FBQyxVQUFVLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxVQUFVLENBQUMsV0FBVyxHQUFHLFdBQVcsQ0FBQyxFQUFFO1lBQ2xGLElBQUksR0FBRyxLQUFLLFFBQVEsRUFBRTtnQkFDbkIsSUFBSSxDQUFDLE1BQXVCLENBQUMsS0FBSyxDQUFDLDhCQUE4QixHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQzthQUNqRjtZQUNELE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUM7WUFDcEMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQzdCLE9BQU8sT0FBTyxDQUFDO1NBQ2hCO2FBQU07WUFDTCxNQUFNLENBQUMsR0FBRywyQkFBMkIsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDO1lBQ2xELElBQUksR0FBRyxLQUFLLFFBQVEsRUFBRTtnQkFDbkIsSUFBSSxDQUFDLE1BQXVCLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUN2QyxPQUFPO2FBQ1I7aUJBQU07Z0JBQ0wsTUFBTSxDQUFDLENBQUM7YUFDVDtTQUNGO0lBQ0gsQ0FBQztJQUVEOzs7O09BSUc7SUFDSyxHQUFHLENBQUMsR0FBVztRQUNyQixJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNsQixNQUFNLElBQUksS0FBSyxDQUFDLHlEQUF5RCxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsQ0FBQztTQUN6RjtRQUVELHNCQUFzQjtRQUN0QixJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBRTNCLGlFQUFpRTtRQUNqRSxJQUFJLENBQUMsS0FBSyxTQUFTLElBQUksQ0FBQyxLQUFLLElBQUksRUFBRTtZQUNqQyxDQUFDLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ2xEO1FBRUQsT0FBTyxDQUFDLENBQUM7SUFDWCxDQUFDO0NBQ0Y7QUFFRCxpQkFBUyxJQUFJLGNBQWMsRUFBRSxDQUFDIn0=