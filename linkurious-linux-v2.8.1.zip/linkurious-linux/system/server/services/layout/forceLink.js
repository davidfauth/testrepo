/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-03-03.
 */
'use strict';
/**
 * Force link layout. Parameters:
 * @property {boolean} linLogMode                      (default: false)
 * @property {boolean} outboundAttractionDistribution  (default: false)
 * @property {boolean} adjustSizes                     (default: false)
 * @property {number}  edgeWeightInfluence             (default: 0)
 * @property {number}  scalingRatio                    (default: 1)
 * @property {boolean} strongGravityMode               (default: false)
 * @property {number}  gravity                         (default: 1)
 * @property {number}  slowDown                        (default: 1)
 * @property {boolean} barnesHutOptimize               (default: false)
 * @property {number}  barnesHutTheta                  (default: 0.5)
 * @property {number}  startingIterations              (default: 1)
 * @property {number}  iterationsPerRender             (default: 1)
 * @property {number}  maxIterations                   (default: 1000)
 * @property {number}  avgDistanceThreshold            (default: 0.01)
 * @property {boolean} autoStop                        (default: false)
 * @property {boolean} alignNodeSiblings               (default: false)
 * @property {number}  nodeSiblingsScale               (default: 1)
 * @property {number}  nodeSiblingsAngleMin            (default: 0)
 * @var forceLink
 */
/**
 * @param {object[]} nodes
 * @param {object[]} edges
 * @param {object} config
 */
function forceLinkLayout(nodes, edges, config) {
    var firstIteration = true;
    /**
     * Worker settings and properties
     */
    var W = {
        // Properties
        ppn: 10,
        ppe: 3,
        ppr: 9,
        maxForce: 10,
        iterations: 0,
        converged: false,
        // Possible to change through config
        settings: {
            // force atlas 2:
            linLogMode: false,
            outboundAttractionDistribution: false,
            adjustSizes: false,
            edgeWeightInfluence: 0,
            scalingRatio: 1,
            strongGravityMode: false,
            gravity: 1,
            slowDown: 1,
            barnesHutOptimize: false,
            barnesHutTheta: 0.5,
            startingIterations: 1,
            iterationsPerRender: 1,
            // stopping condition:
            maxIterations: 1000,
            avgDistanceThreshold: 0.01,
            autoStop: true,
            // node siblings:
            alignNodeSiblings: false,
            nodeSiblingsScale: 1,
            nodeSiblingsAngleMin: 0
        }
    };
    var NodeMatrix, EdgeMatrix, RegionMtx;
    /**
     * Return the euclidian distance between two points of a plane
     * with an orthonormal basis.
     *
     * @param  {number} x0  The X coordinate of the first point.
     * @param  {number} y0  The Y coordinate of the first point.
     * @param  {number} x1  The X coordinate of the second point.
     * @param  {number} y1  The Y coordinate of the second point.
     * @returns {number}     The euclidian distance.
     */
    function getDistance(x0, y0, x1, y1) {
        return Math.sqrt((x1 - x0) * (x1 - x0) + (y1 - y0) * (y1 - y0));
    }
    /**
     * Scale a value from the range [baseMin, baseMax] to the range
     * [limitMin, limitMax].
     *
     * @param  {number} value    The value to rescale.
     * @param  {number} baseMin  The min value of the range of origin.
     * @param  {number} baseMax  The max value of the range of origin.
     * @param  {number} limitMin The min value of the range of destination.
     * @param  {number} limitMax The max value of the range of destination.
     * @returns {number}          The scaled value.
     */
    function scaleRange(value, baseMin, baseMax, limitMin, limitMax) {
        return ((limitMax - limitMin) * (value - baseMin) / (baseMax - baseMin)) + limitMin;
    }
    /**
     * Get the angle of the vector (in radian).
     *
     * @param  {object} v  The 2d vector with x,y coordinates.
     * @returns {number}    The angle of the vector  (in radian).
     */
    function getVectorAngle(v) {
        return Math.acos(v.x / Math.sqrt(v.x * v.x + v.y * v.y));
    }
    /**
     * Get the normal vector of the line segment, i.e. the vector
     * orthogonal to the line.
     * http://stackoverflow.com/a/1243614/
     *
     * @param  {number} aX The x coorinates of the start point.
     * @param  {number} aY The y coorinates of the start point.
     * @param  {number} bX The x coorinates of the end point.
     * @param  {number} bY The y coorinates of the end point.
     * @returns {object}    The 2d vector with (xi,yi), (xi_prime,yi_prime) coordinates.
     */
    function getNormalVector(aX, aY, bX, bY) {
        return {
            xi: -(bY - aY),
            yi: bX - aX,
            'xi_prime': bY - aY,
            'yi_prime': -(bX - aX)
        };
    }
    /**
     * Get the normalized vector.
     *
     * @param  {object} v      The 2d vector with (xi,yi), (xi_prime,yi_prime) coordinates.
     * @param  {number} length The vector length.
     * @returns {object}        The normalized vector
     */
    function getNormalizedVector(v, length) {
        return {
            x: (v['xi_prime'] - v.xi) / length,
            y: (v['yi_prime'] - v.yi) / length
        };
    }
    /**
     * Get the a point the line segment [A,B] at a specified distance percentage
     * from the start point.
     *
     * @param  {number} aX The x coorinates of the start point.
     * @param  {number} aY The y coorinates of the start point.
     * @param  {number} bX The x coorinates of the end point.
     * @param  {number} bY The y coorinates of the end point.
     * @param  {number} t  The distance percentage from the start point.
     * @returns {object}    The (x,y) coordinates of the point.
     */
    function getPointOnLineSegment(aX, aY, bX, bY, t) {
        return {
            x: aX + (bX - aX) * t,
            y: aY + (bY - aY) * t
        };
    }
    /**
     * Matrices properties accessors
     */
    var nodeProperties = {
        x: 0,
        y: 1,
        dx: 2,
        dy: 3,
        'old_dx': 4,
        'old_dy': 5,
        mass: 6,
        convergence: 7,
        size: 8,
        pinned: 9
    };
    var edgeProperties = {
        source: 0,
        target: 1,
        weight: 2
    };
    var regionProperties = {
        node: 0,
        centerX: 1,
        centerY: 2,
        size: 3,
        nextSibling: 4,
        firstChild: 5,
        mass: 6,
        massCenterX: 7,
        massCenterY: 8
    };
    function np(i, p) {
        // DEBUG: safeguards
        if ((i % W.ppn) !== 0) {
            throw new Error('Invalid argument in np: "i" is not correct (' + i + ').');
        }
        if (i !== parseInt(i)) {
            throw new TypeError('Invalid argument in np: "i" is not an integer.');
        }
        if (p in nodeProperties) {
            return i + nodeProperties[p];
        }
        else {
            throw new Error('ForceLink.Worker - Inexistant node property given (' + p + ').');
        }
    }
    function ep(i, p) {
        // DEBUG: safeguards
        if ((i % W.ppe) !== 0) {
            throw new Error('Invalid argument in ep: "i" is not correct (' + i + ').');
        }
        if (i !== parseInt(i)) {
            throw new TypeError('Invalid argument in ep: "i" is not an integer.');
        }
        if (p in edgeProperties) {
            return i + edgeProperties[p];
        }
        else {
            throw new Error('ForceLink.Worker - Inexistant edge property given (' + p + ').');
        }
    }
    function rp(i, p) {
        // DEBUG: safeguards
        if ((i % W.ppr) !== 0) {
            throw new Error('Invalid argument in rp: "i" is not correct (' + i + ').');
        }
        if (i !== parseInt(i)) {
            throw new TypeError('Invalid argument in rp: "i" is not an integer.');
        }
        if (p in regionProperties) {
            return i + regionProperties[p];
        }
        else {
            throw new Error('ForceLink.Worker - Inexistant region property given (' + p + ').');
        }
    }
    function randomize(n, config) {
        switch (config.randomize) {
            case 'globally':
                return Math.random() * (config.randomizeFactor || 1);
            case 'locally':
                return n + (Math.random() * (config.randomizeFactor || 1));
            default:
                return n;
        }
    }
    /**
     * Algorithm pass
     */
    // MATH: get distances stuff and power 2 issues
    function pass() {
        var l, r, n, n1, n2, e, w, g;
        var outboundAttCompensation, coefficient, xDist, yDist, oldxDist, oldyDist, ewc, mass, distance, size, factor;
        // 1) Initializing layout data
        //-----------------------------
        // Resetting positions & computing max values
        for (n = 0; n < W.nodesLength; n += W.ppn) {
            NodeMatrix[np(n, 'old_dx')] = NodeMatrix[np(n, 'dx')];
            NodeMatrix[np(n, 'old_dy')] = NodeMatrix[np(n, 'dy')];
            NodeMatrix[np(n, 'dx')] = 0;
            NodeMatrix[np(n, 'dy')] = 0;
        }
        // If outbound attraction distribution, compensate
        if (W.settings.outboundAttractionDistribution) {
            outboundAttCompensation = 0;
            for (n = 0; n < W.nodesLength; n += W.ppn) {
                outboundAttCompensation += NodeMatrix[np(n, 'mass')];
            }
            outboundAttCompensation /= W.nodesLength;
        }
        // 1.bis) Barnes-Hut computation
        //------------------------------
        if (W.settings.barnesHutOptimize) {
            var minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity, q, q2;
            // Setting up
            // RegionMtx = new Float32Array(W.nodesLength / W.ppn * 4 * W.ppr);
            RegionMtx = [];
            // Computing min and max values
            for (n = 0; n < W.nodesLength; n += W.ppn) {
                minX = Math.min(minX, NodeMatrix[np(n, 'x')]);
                maxX = Math.max(maxX, NodeMatrix[np(n, 'x')]);
                minY = Math.min(minY, NodeMatrix[np(n, 'y')]);
                maxY = Math.max(maxY, NodeMatrix[np(n, 'y')]);
            }
            // Build the Barnes Hut root region
            RegionMtx[rp(0, 'node')] = -1;
            RegionMtx[rp(0, 'centerX')] = (minX + maxX) / 2;
            RegionMtx[rp(0, 'centerY')] = (minY + maxY) / 2;
            RegionMtx[rp(0, 'size')] = Math.max(maxX - minX, maxY - minY);
            RegionMtx[rp(0, 'nextSibling')] = -1;
            RegionMtx[rp(0, 'firstChild')] = -1;
            RegionMtx[rp(0, 'mass')] = 0;
            RegionMtx[rp(0, 'massCenterX')] = 0;
            RegionMtx[rp(0, 'massCenterY')] = 0;
            // Add each node in the tree
            l = 1;
            for (n = 0; n < W.nodesLength; n += W.ppn) {
                // Current region, starting with root
                r = 0;
                while (true) {
                    // Are there sub-regions?
                    // We look at first child index
                    if (RegionMtx[rp(r, 'firstChild')] >= 0) {
                        // There are sub-regions
                        // We just iterate to find a "leave" of the tree
                        // that is an empty region or a region with a single node
                        // (see next case)
                        // Find the quadrant of n
                        if (NodeMatrix[np(n, 'x')] < RegionMtx[rp(r, 'centerX')]) {
                            if (NodeMatrix[np(n, 'y')] < RegionMtx[rp(r, 'centerY')]) {
                                // Top Left quarter
                                q = RegionMtx[rp(r, 'firstChild')];
                            }
                            else {
                                // Bottom Left quarter
                                q = RegionMtx[rp(r, 'firstChild')] + W.ppr;
                            }
                        }
                        else {
                            if (NodeMatrix[np(n, 'y')] < RegionMtx[rp(r, 'centerY')]) {
                                // Top Right quarter
                                q = RegionMtx[rp(r, 'firstChild')] + W.ppr * 2;
                            }
                            else {
                                // Bottom Right quarter
                                q = RegionMtx[rp(r, 'firstChild')] + W.ppr * 3;
                            }
                        }
                        // Update center of mass and mass (we only do it for non-leave regions)
                        RegionMtx[rp(r, 'massCenterX')] =
                            (RegionMtx[rp(r, 'massCenterX')] * RegionMtx[rp(r, 'mass')] +
                                NodeMatrix[np(n, 'x')] * NodeMatrix[np(n, 'mass')]) /
                                (RegionMtx[rp(r, 'mass')] + NodeMatrix[np(n, 'mass')]);
                        RegionMtx[rp(r, 'massCenterY')] =
                            (RegionMtx[rp(r, 'massCenterY')] * RegionMtx[rp(r, 'mass')] +
                                NodeMatrix[np(n, 'y')] * NodeMatrix[np(n, 'mass')]) /
                                (RegionMtx[rp(r, 'mass')] + NodeMatrix[np(n, 'mass')]);
                        RegionMtx[rp(r, 'mass')] += NodeMatrix[np(n, 'mass')];
                        // Iterate on the right quadrant
                        r = q;
                        continue;
                    }
                    else {
                        // There are no sub-regions: we are in a "leave"
                        // Is there a node in this leave?
                        if (RegionMtx[rp(r, 'node')] < 0) {
                            // There is no node in region:
                            // we record node n and go on
                            RegionMtx[rp(r, 'node')] = n;
                            break;
                        }
                        else {
                            // There is a node in this region
                            // We will need to create sub-regions, stick the two
                            // nodes (the old one r[0] and the new one n) in two
                            // subregions. If they fall in the same quadrant,
                            // we will iterate.
                            // Create sub-regions
                            RegionMtx[rp(r, 'firstChild')] = l * W.ppr;
                            w = RegionMtx[rp(r, 'size')] / 2; // new size (half)
                            // NOTE: we use screen coordinates
                            // from Top Left to Bottom Right
                            // Top Left sub-region
                            g = RegionMtx[rp(r, 'firstChild')];
                            RegionMtx[rp(g, 'node')] = -1;
                            RegionMtx[rp(g, 'centerX')] = RegionMtx[rp(r, 'centerX')] - w;
                            RegionMtx[rp(g, 'centerY')] = RegionMtx[rp(r, 'centerY')] - w;
                            RegionMtx[rp(g, 'size')] = w;
                            RegionMtx[rp(g, 'nextSibling')] = g + W.ppr;
                            RegionMtx[rp(g, 'firstChild')] = -1;
                            RegionMtx[rp(g, 'mass')] = 0;
                            RegionMtx[rp(g, 'massCenterX')] = 0;
                            RegionMtx[rp(g, 'massCenterY')] = 0;
                            // Bottom Left sub-region
                            g += W.ppr;
                            RegionMtx[rp(g, 'node')] = -1;
                            RegionMtx[rp(g, 'centerX')] = RegionMtx[rp(r, 'centerX')] - w;
                            RegionMtx[rp(g, 'centerY')] = RegionMtx[rp(r, 'centerY')] + w;
                            RegionMtx[rp(g, 'size')] = w;
                            RegionMtx[rp(g, 'nextSibling')] = g + W.ppr;
                            RegionMtx[rp(g, 'firstChild')] = -1;
                            RegionMtx[rp(g, 'mass')] = 0;
                            RegionMtx[rp(g, 'massCenterX')] = 0;
                            RegionMtx[rp(g, 'massCenterY')] = 0;
                            // Top Right sub-region
                            g += W.ppr;
                            RegionMtx[rp(g, 'node')] = -1;
                            RegionMtx[rp(g, 'centerX')] = RegionMtx[rp(r, 'centerX')] + w;
                            RegionMtx[rp(g, 'centerY')] = RegionMtx[rp(r, 'centerY')] - w;
                            RegionMtx[rp(g, 'size')] = w;
                            RegionMtx[rp(g, 'nextSibling')] = g + W.ppr;
                            RegionMtx[rp(g, 'firstChild')] = -1;
                            RegionMtx[rp(g, 'mass')] = 0;
                            RegionMtx[rp(g, 'massCenterX')] = 0;
                            RegionMtx[rp(g, 'massCenterY')] = 0;
                            // Bottom Right sub-region
                            g += W.ppr;
                            RegionMtx[rp(g, 'node')] = -1;
                            RegionMtx[rp(g, 'centerX')] = RegionMtx[rp(r, 'centerX')] + w;
                            RegionMtx[rp(g, 'centerY')] = RegionMtx[rp(r, 'centerY')] + w;
                            RegionMtx[rp(g, 'size')] = w;
                            RegionMtx[rp(g, 'nextSibling')] = RegionMtx[rp(r, 'nextSibling')];
                            RegionMtx[rp(g, 'firstChild')] = -1;
                            RegionMtx[rp(g, 'mass')] = 0;
                            RegionMtx[rp(g, 'massCenterX')] = 0;
                            RegionMtx[rp(g, 'massCenterY')] = 0;
                            l += 4;
                            // Now the goal is to find two different sub-regions
                            // for the two nodes: the one previously recorded (r[0])
                            // and the one we want to add (n)
                            // Find the quadrant of the old node
                            if (NodeMatrix[np(RegionMtx[rp(r, 'node')], 'x')] < RegionMtx[rp(r, 'centerX')]) {
                                if (NodeMatrix[np(RegionMtx[rp(r, 'node')], 'y')] < RegionMtx[rp(r, 'centerY')]) {
                                    // Top Left quarter
                                    q = RegionMtx[rp(r, 'firstChild')];
                                }
                                else {
                                    // Bottom Left quarter
                                    q = RegionMtx[rp(r, 'firstChild')] + W.ppr;
                                }
                            }
                            else {
                                if (NodeMatrix[np(RegionMtx[rp(r, 'node')], 'y')] < RegionMtx[rp(r, 'centerY')]) {
                                    // Top Right quarter
                                    q = RegionMtx[rp(r, 'firstChild')] + W.ppr * 2;
                                }
                                else {
                                    // Bottom Right quarter
                                    q = RegionMtx[rp(r, 'firstChild')] + W.ppr * 3;
                                }
                            }
                            // We remove r[0] from the region r, add its mass to r and record it in q
                            RegionMtx[rp(r, 'mass')] = NodeMatrix[np(RegionMtx[rp(r, 'node')], 'mass')];
                            RegionMtx[rp(r, 'massCenterX')] = NodeMatrix[np(RegionMtx[rp(r, 'node')], 'x')];
                            RegionMtx[rp(r, 'massCenterY')] = NodeMatrix[np(RegionMtx[rp(r, 'node')], 'y')];
                            RegionMtx[rp(q, 'node')] = RegionMtx[rp(r, 'node')];
                            RegionMtx[rp(r, 'node')] = -1;
                            // Find the quadrant of n
                            if (NodeMatrix[np(n, 'x')] < RegionMtx[rp(r, 'centerX')]) {
                                if (NodeMatrix[np(n, 'y')] < RegionMtx[rp(r, 'centerY')]) {
                                    // Top Left quarter
                                    q2 = RegionMtx[rp(r, 'firstChild')];
                                }
                                else {
                                    // Bottom Left quarter
                                    q2 = RegionMtx[rp(r, 'firstChild')] + W.ppr;
                                }
                            }
                            else {
                                if (NodeMatrix[np(n, 'y')] < RegionMtx[rp(r, 'centerY')]) {
                                    // Top Right quarter
                                    q2 = RegionMtx[rp(r, 'firstChild')] + W.ppr * 2;
                                }
                                else {
                                    // Bottom Right quarter
                                    q2 = RegionMtx[rp(r, 'firstChild')] + W.ppr * 3;
                                }
                            }
                            if (q === q2) {
                                // If both nodes are in the same quadrant,
                                // we have to try it again on this quadrant
                                r = q;
                                continue;
                            }
                            // If both quadrants are different, we record n
                            // in its quadrant
                            RegionMtx[rp(q2, 'node')] = n;
                            break;
                        }
                    }
                }
            }
        }
        // 2) Repulsion
        //--------------
        // NOTES: adjustSizes = antiCollision & scalingRatio = coefficient
        if (W.settings.barnesHutOptimize) {
            coefficient = W.settings.scalingRatio;
            // Applying repulsion through regions
            for (n = 0; n < W.nodesLength; n += W.ppn) {
                // Computing leaf quad nodes iteration
                r = 0; // Starting with root region
                while (true) {
                    if (RegionMtx[rp(r, 'firstChild')] >= 0) {
                        // The region has sub-regions
                        // We run the Barnes Hut test to see if we are at the right distance
                        distance = Math.sqrt((NodeMatrix[np(n, 'x')] - RegionMtx[rp(r, 'massCenterX')]) *
                            (NodeMatrix[np(n, 'x')] - RegionMtx[rp(r, 'massCenterX')]) +
                            (NodeMatrix[np(n, 'y')] - RegionMtx[rp(r, 'massCenterY')]) *
                                (NodeMatrix[np(n, 'y')] - RegionMtx[rp(r, 'massCenterY')]));
                        if (2 * RegionMtx[rp(r, 'size')] / distance < W.settings.barnesHutTheta) {
                            // We treat the region as a single body, and we repulse
                            xDist = NodeMatrix[np(n, 'x')] - RegionMtx[rp(r, 'massCenterX')];
                            yDist = NodeMatrix[np(n, 'y')] - RegionMtx[rp(r, 'massCenterY')];
                            if (W.settings.adjustSizes) {
                                //-- Linear Anti-collision Repulsion
                                if (distance > 0) {
                                    factor = coefficient * NodeMatrix[np(n, 'mass')] *
                                        RegionMtx[rp(r, 'mass')] / distance / distance;
                                    NodeMatrix[np(n, 'dx')] += xDist * factor;
                                    NodeMatrix[np(n, 'dy')] += yDist * factor;
                                }
                                else if (distance < 0) {
                                    factor = -coefficient * NodeMatrix[np(n, 'mass')] *
                                        RegionMtx[rp(r, 'mass')] / distance;
                                    NodeMatrix[np(n, 'dx')] += xDist * factor;
                                    NodeMatrix[np(n, 'dy')] += yDist * factor;
                                }
                            }
                            else {
                                //-- Linear Repulsion
                                if (distance > 0) {
                                    factor = coefficient * NodeMatrix[np(n, 'mass')] *
                                        RegionMtx[rp(r, 'mass')] / distance / distance;
                                    NodeMatrix[np(n, 'dx')] += xDist * factor;
                                    NodeMatrix[np(n, 'dy')] += yDist * factor;
                                }
                            }
                            // When this is done, we iterate. We have to look at the next sibling.
                            if (RegionMtx[rp(r, 'nextSibling')] < 0) {
                                break; // No next sibling: we have finished the tree
                            }
                            r = RegionMtx[rp(r, 'nextSibling')];
                            continue;
                        }
                        else {
                            // The region is too close and we have to look at sub-regions
                            r = RegionMtx[rp(r, 'firstChild')];
                            continue;
                        }
                    }
                    else {
                        // The region has no sub-region
                        // If there is a node r[0] and it is not n, then repulse
                        if (RegionMtx[rp(r, 'node')] >= 0 && RegionMtx[rp(r, 'node')] !== n) {
                            xDist = NodeMatrix[np(n, 'x')] - NodeMatrix[np(RegionMtx[rp(r, 'node')], 'x')];
                            yDist = NodeMatrix[np(n, 'y')] - NodeMatrix[np(RegionMtx[rp(r, 'node')], 'y')];
                            distance = Math.sqrt(xDist * xDist + yDist * yDist);
                            if (W.settings.adjustSizes) {
                                //-- Linear Anti-collision Repulsion
                                if (distance > 0) {
                                    factor = coefficient * NodeMatrix[np(n, 'mass')] *
                                        NodeMatrix[np(RegionMtx[rp(r, 'node')], 'mass')] / distance / distance;
                                    NodeMatrix[np(n, 'dx')] += xDist * factor;
                                    NodeMatrix[np(n, 'dy')] += yDist * factor;
                                }
                                else if (distance < 0) {
                                    factor = -coefficient * NodeMatrix[np(n, 'mass')] *
                                        NodeMatrix[np(RegionMtx[rp(r, 'node')], 'mass')] / distance;
                                    NodeMatrix[np(n, 'dx')] += xDist * factor;
                                    NodeMatrix[np(n, 'dy')] += yDist * factor;
                                }
                            }
                            else {
                                //-- Linear Repulsion
                                if (distance > 0) {
                                    factor = coefficient * NodeMatrix[np(n, 'mass')] *
                                        NodeMatrix[np(RegionMtx[rp(r, 'node')], 'mass')] / distance / distance;
                                    NodeMatrix[np(n, 'dx')] += xDist * factor;
                                    NodeMatrix[np(n, 'dy')] += yDist * factor;
                                }
                            }
                        }
                        // When this is done, we iterate. We have to look at the next sibling.
                        if (RegionMtx[rp(r, 'nextSibling')] < 0) {
                            break; // No next sibling: we have finished the tree
                        }
                        r = RegionMtx[rp(r, 'nextSibling')];
                        continue;
                    }
                }
            }
        }
        else {
            coefficient = W.settings.scalingRatio;
            // Square iteration
            for (n1 = 0; n1 < W.nodesLength; n1 += W.ppn) {
                for (n2 = 0; n2 < n1; n2 += W.ppn) {
                    // Common to both methods
                    xDist = NodeMatrix[np(n1, 'x')] - NodeMatrix[np(n2, 'x')];
                    yDist = NodeMatrix[np(n1, 'y')] - NodeMatrix[np(n2, 'y')];
                    if (W.settings.adjustSizes) {
                        //-- Anticollision Linear Repulsion
                        distance = Math.sqrt(xDist * xDist + yDist * yDist) -
                            NodeMatrix[np(n1, 'size')] -
                            NodeMatrix[np(n2, 'size')];
                        if (distance > 0) {
                            factor = coefficient *
                                NodeMatrix[np(n1, 'mass')] *
                                NodeMatrix[np(n2, 'mass')] /
                                distance / distance;
                            // Updating nodes' dx and dy
                            NodeMatrix[np(n1, 'dx')] += xDist * factor;
                            NodeMatrix[np(n1, 'dy')] += yDist * factor;
                            NodeMatrix[np(n2, 'dx')] += xDist * factor;
                            NodeMatrix[np(n2, 'dy')] += yDist * factor;
                        }
                        else if (distance < 0) {
                            factor = 100 * coefficient *
                                NodeMatrix[np(n1, 'mass')] *
                                NodeMatrix[np(n2, 'mass')];
                            // Updating nodes' dx and dy
                            NodeMatrix[np(n1, 'dx')] += xDist * factor;
                            NodeMatrix[np(n1, 'dy')] += yDist * factor;
                            NodeMatrix[np(n2, 'dx')] -= xDist * factor;
                            NodeMatrix[np(n2, 'dy')] -= yDist * factor;
                        }
                    }
                    else {
                        //-- Linear Repulsion
                        distance = Math.sqrt(xDist * xDist + yDist * yDist);
                        if (distance > 0) {
                            factor = coefficient *
                                NodeMatrix[np(n1, 'mass')] *
                                NodeMatrix[np(n2, 'mass')] /
                                distance / distance;
                            // Updating nodes' dx and dy
                            NodeMatrix[np(n1, 'dx')] += xDist * factor;
                            NodeMatrix[np(n1, 'dy')] += yDist * factor;
                            NodeMatrix[np(n2, 'dx')] -= xDist * factor;
                            NodeMatrix[np(n2, 'dy')] -= yDist * factor;
                        }
                    }
                }
            }
        }
        // 3) Gravity
        //------------
        g = W.settings.gravity / W.settings.scalingRatio;
        coefficient = W.settings.scalingRatio;
        for (n = 0; n < W.nodesLength; n += W.ppn) {
            factor = 0;
            // Common to both methods
            xDist = NodeMatrix[np(n, 'x')];
            yDist = NodeMatrix[np(n, 'y')];
            distance = Math.sqrt(xDist * xDist + yDist * yDist);
            if (W.settings.strongGravityMode) {
                //-- Strong gravity
                if (distance > 0) {
                    factor = coefficient * NodeMatrix[np(n, 'mass')] * g;
                }
            }
            else {
                //-- Linear Anti-collision Repulsion n
                if (distance > 0) {
                    factor = coefficient * NodeMatrix[np(n, 'mass')] * g / distance;
                }
            }
            // Updating node's dx and dy
            NodeMatrix[np(n, 'dx')] -= xDist * factor;
            NodeMatrix[np(n, 'dy')] -= yDist * factor;
        }
        // 4) Attraction
        //---------------
        coefficient = 1 * (W.settings.outboundAttractionDistribution ? outboundAttCompensation : 1);
        // TODO: simplify distance
        // TODO: coefficient is always used as -c --> optimize?
        for (e = 0; e < W.edgesLength; e += W.ppe) {
            n1 = EdgeMatrix[ep(e, 'source')];
            n2 = EdgeMatrix[ep(e, 'target')];
            w = EdgeMatrix[ep(e, 'weight')];
            // Edge weight influence
            ewc = Math.pow(w, W.settings.edgeWeightInfluence);
            // Common measures
            xDist = NodeMatrix[np(n1, 'x')] - NodeMatrix[np(n2, 'x')];
            yDist = NodeMatrix[np(n1, 'y')] - NodeMatrix[np(n2, 'y')];
            // Applying attraction to nodes
            if (W.settings.adjustSizes) {
                distance = Math.sqrt((xDist * xDist + yDist * yDist) -
                    NodeMatrix[np(n1, 'size')] -
                    NodeMatrix[np(n2, 'size')]);
                if (W.settings.linLogMode) {
                    if (W.settings.outboundAttractionDistribution) {
                        //-- LinLog Degree Distributed Anti-collision Attraction
                        if (distance > 0) {
                            factor = -coefficient * ewc * Math.log(1 + distance) /
                                distance /
                                NodeMatrix[np(n1, 'mass')];
                        }
                    }
                    else {
                        //-- LinLog Anti-collision Attraction
                        if (distance > 0) {
                            factor = -coefficient * ewc * Math.log(1 + distance) / distance;
                        }
                    }
                }
                else {
                    if (W.settings.outboundAttractionDistribution) {
                        //-- Linear Degree Distributed Anti-collision Attraction
                        if (distance > 0) {
                            factor = -coefficient * ewc / NodeMatrix[np(n1, 'mass')];
                        }
                    }
                    else {
                        //-- Linear Anti-collision Attraction
                        if (distance > 0) {
                            factor = -coefficient * ewc;
                        }
                    }
                }
            }
            else {
                distance = Math.sqrt(xDist * xDist + yDist * yDist);
                if (W.settings.linLogMode) {
                    if (W.settings.outboundAttractionDistribution) {
                        //-- LinLog Degree Distributed Attraction
                        if (distance > 0) {
                            factor = -coefficient * ewc * Math.log(1 + distance) /
                                distance /
                                NodeMatrix[np(n1, 'mass')];
                        }
                    }
                    else {
                        //-- LinLog Attraction
                        if (distance > 0) {
                            factor = -coefficient * ewc * Math.log(1 + distance) / distance;
                        }
                    }
                }
                else {
                    if (W.settings.outboundAttractionDistribution) {
                        //-- Linear Attraction Mass Distributed
                        // NOTE: Distance is set to 1 to override next condition
                        distance = 1;
                        factor = -coefficient * ewc / NodeMatrix[np(n1, 'mass')];
                    }
                    else {
                        //-- Linear Attraction
                        // NOTE: Distance is set to 1 to override next condition
                        distance = 1;
                        factor = -coefficient * ewc;
                    }
                }
            }
            // Updating nodes' dx and dy
            // TODO: if condition or factor = 1?
            if (distance > 0) {
                // Updating nodes' dx and dy
                NodeMatrix[np(n1, 'dx')] += xDist * factor;
                NodeMatrix[np(n1, 'dy')] += yDist * factor;
                NodeMatrix[np(n2, 'dx')] -= xDist * factor;
                NodeMatrix[np(n2, 'dy')] -= yDist * factor;
            }
        }
        // 5) Apply Forces
        //-----------------
        var force, swinging, traction, nodespeed, alldistance = 0;
        // MATH: sqrt and square distances
        if (W.settings.adjustSizes) {
            for (n = 0; n < W.nodesLength; n += W.ppn) {
                if (!NodeMatrix[np(n, 'pinned')]) {
                    force = Math.sqrt(NodeMatrix[np(n, 'dx')] * NodeMatrix[np(n, 'dx')] +
                        NodeMatrix[np(n, 'dy')] * NodeMatrix[np(n, 'dy')]);
                    if (force > W.maxForce) {
                        NodeMatrix[np(n, 'dx')] =
                            NodeMatrix[np(n, 'dx')] * W.maxForce / force;
                        NodeMatrix[np(n, 'dy')] =
                            NodeMatrix[np(n, 'dy')] * W.maxForce / force;
                    }
                    swinging = NodeMatrix[np(n, 'mass')] *
                        Math.sqrt((NodeMatrix[np(n, 'old_dx')] - NodeMatrix[np(n, 'dx')]) *
                            (NodeMatrix[np(n, 'old_dx')] - NodeMatrix[np(n, 'dx')]) +
                            (NodeMatrix[np(n, 'old_dy')] - NodeMatrix[np(n, 'dy')]) *
                                (NodeMatrix[np(n, 'old_dy')] - NodeMatrix[np(n, 'dy')]));
                    traction = Math.sqrt((NodeMatrix[np(n, 'old_dx')] + NodeMatrix[np(n, 'dx')]) *
                        (NodeMatrix[np(n, 'old_dx')] + NodeMatrix[np(n, 'dx')]) +
                        (NodeMatrix[np(n, 'old_dy')] + NodeMatrix[np(n, 'dy')]) *
                            (NodeMatrix[np(n, 'old_dy')] + NodeMatrix[np(n, 'dy')])) / 2;
                    nodespeed =
                        0.1 * Math.log(1 + traction) / (1 + Math.sqrt(swinging));
                    oldxDist = NodeMatrix[np(n, 'x')];
                    oldyDist = NodeMatrix[np(n, 'y')];
                    // Updating node's positon
                    NodeMatrix[np(n, 'x')] =
                        NodeMatrix[np(n, 'x')] + NodeMatrix[np(n, 'dx')] *
                            (nodespeed / W.settings.slowDown);
                    NodeMatrix[np(n, 'y')] =
                        NodeMatrix[np(n, 'y')] + NodeMatrix[np(n, 'dy')] *
                            (nodespeed / W.settings.slowDown);
                    xDist = NodeMatrix[np(n, 'x')];
                    yDist = NodeMatrix[np(n, 'y')];
                    distance = Math.sqrt((xDist - oldxDist) * (xDist - oldxDist) +
                        (yDist - oldyDist) * (yDist - oldyDist));
                    alldistance += distance;
                }
            }
        }
        else {
            for (n = 0; n < W.nodesLength; n += W.ppn) {
                if (!NodeMatrix[np(n, 'pinned')]) {
                    swinging = NodeMatrix[np(n, 'mass')] *
                        Math.sqrt((NodeMatrix[np(n, 'old_dx')] - NodeMatrix[np(n, 'dx')]) *
                            (NodeMatrix[np(n, 'old_dx')] - NodeMatrix[np(n, 'dx')]) +
                            (NodeMatrix[np(n, 'old_dy')] - NodeMatrix[np(n, 'dy')]) *
                                (NodeMatrix[np(n, 'old_dy')] - NodeMatrix[np(n, 'dy')]));
                    traction = Math.sqrt((NodeMatrix[np(n, 'old_dx')] + NodeMatrix[np(n, 'dx')]) *
                        (NodeMatrix[np(n, 'old_dx')] + NodeMatrix[np(n, 'dx')]) +
                        (NodeMatrix[np(n, 'old_dy')] + NodeMatrix[np(n, 'dy')]) *
                            (NodeMatrix[np(n, 'old_dy')] + NodeMatrix[np(n, 'dy')])) / 2;
                    nodespeed = NodeMatrix[np(n, 'convergence')] *
                        Math.log(1 + traction) / (1 + Math.sqrt(swinging));
                    // Updating node convergence
                    NodeMatrix[np(n, 'convergence')] =
                        Math.min(1, Math.sqrt(nodespeed *
                            (NodeMatrix[np(n, 'dx')] * NodeMatrix[np(n, 'dx')] +
                                NodeMatrix[np(n, 'dy')] * NodeMatrix[np(n, 'dy')]) /
                            (1 + Math.sqrt(swinging))));
                    oldxDist = NodeMatrix[np(n, 'x')];
                    oldyDist = NodeMatrix[np(n, 'y')];
                    // Updating node's positon
                    NodeMatrix[np(n, 'x')] =
                        NodeMatrix[np(n, 'x')] + NodeMatrix[np(n, 'dx')] *
                            (nodespeed / W.settings.slowDown);
                    NodeMatrix[np(n, 'y')] =
                        NodeMatrix[np(n, 'y')] + NodeMatrix[np(n, 'dy')] *
                            (nodespeed / W.settings.slowDown);
                    xDist = NodeMatrix[np(n, 'x')];
                    yDist = NodeMatrix[np(n, 'y')];
                    distance = Math.sqrt((xDist - oldxDist) * (xDist - oldxDist) +
                        (yDist - oldyDist) * (yDist - oldyDist));
                    alldistance += distance;
                }
            }
        }
        // Counting one more iteration
        W.iterations++;
        // Auto stop.
        // The greater the ratio nb nodes / nb edges,
        // the greater the number of iterations needed to converge.
        if (W.settings.autoStop) {
            W.converged = (W.iterations > W.settings.maxIterations ||
                alldistance / W.nodesLength < W.settings.avgDistanceThreshold);
            // align nodes that are linked to the same two nodes only:
            if (W.converged && W.settings.alignNodeSiblings) {
                // console.time("alignment");
                var neighbors = {}, // index of neighbors
                parallelNodes = {}, // set of parallel nodes indexed by same <source;target>
                setKey, // tmp
                keysN; // tmp
                // build index of neighbors:
                for (e = 0; e < W.edgesLength; e += W.ppe) {
                    n1 = EdgeMatrix[ep(e, 'source')];
                    n2 = EdgeMatrix[ep(e, 'target')];
                    if (n1 === n2) {
                        continue;
                    }
                    neighbors[n1] = neighbors[n1] || {};
                    neighbors[n2] = neighbors[n2] || {};
                    neighbors[n1][n2] = true;
                    neighbors[n2][n1] = true;
                }
                // group triplets by same <source, target> (resp. target, source):
                Object.keys(neighbors).forEach(function (n) {
                    n = ~~n; // string to int
                    keysN = Object.keys(neighbors[n]);
                    if (keysN.length == 2) {
                        setKey = keysN[0] + ';' + keysN[1];
                        if (setKey in parallelNodes) {
                            parallelNodes[setKey].push(n);
                        }
                        else {
                            setKey = keysN[1] + ';' + keysN[0];
                            if (!parallelNodes[setKey]) {
                                parallelNodes[setKey] = [~~keysN[1], ~~keysN[0]];
                            }
                            parallelNodes[setKey].push(n);
                        }
                    }
                });
                var setNodes, setSource, setTarget, degSource, degTarget, sX, sY, tX, tY, t, distSourceTarget, intersectionPoint, normalVector, nNormaleVector, angle, angleMin = W.settings.nodeSiblingsAngleMin;
                Object.keys(parallelNodes).forEach(function (key) {
                    setSource = parallelNodes[key].shift();
                    setTarget = parallelNodes[key].shift();
                    setNodes = parallelNodes[key].filter(function (setNode) {
                        return !NodeMatrix[np(setNode, 'pinned')];
                    });
                    if (setNodes.length == 1) {
                        return;
                    }
                    sX = NodeMatrix[np(setSource, 'x')];
                    sY = NodeMatrix[np(setSource, 'y')];
                    tX = NodeMatrix[np(setTarget, 'x')];
                    tY = NodeMatrix[np(setTarget, 'y')];
                    // the extremity of lowest degree attracts the nodes
                    // up to 1/4 of the distance:
                    degSource = Object.keys(neighbors[setSource]).length;
                    degTarget = Object.keys(neighbors[setTarget]).length;
                    t = scaleRange(degSource / (degSource + degTarget), 0, 1, 1 / 4, 3 / 4);
                    intersectionPoint = getPointOnLineSegment(sX, sY, tX, tY, t);
                    // vector normal to the segment [source, target]:
                    normalVector = getNormalVector(sX, sY, tX, tY);
                    distSourceTarget = getDistance(sX, sY, tX, tY);
                    // normalized normal vector:
                    nNormaleVector = getNormalizedVector(normalVector, distSourceTarget);
                    angle = getVectorAngle(nNormaleVector);
                    // avoid horizontal vector because node labels overlap:
                    if (2 * angleMin > Math.PI) {
                        throw new Error('ForceLink.Worker - Invalid parameter: angleMin must be smaller than 2 PI.');
                    }
                    if (angleMin > 0) {
                        // TODO layout parameter
                        if (angle < angleMin || (angle > Math.PI - angleMin) && angle <= Math.PI) {
                            // New vector of angle PI - angleMin
                            nNormaleVector = {
                                x: Math.cos(Math.PI - angleMin) * 2,
                                y: Math.sin(Math.PI - angleMin) * 2
                            };
                        }
                        else if ((angle > 2 * Math.PI - angleMin) ||
                            angle >= Math.PI && (angle < Math.PI + angleMin)) {
                            // New vector of angle angleMin
                            nNormaleVector = {
                                x: Math.cos(angleMin) * 2,
                                y: Math.sin(angleMin) * 2
                            };
                        }
                    }
                    // evenly distribute nodes along the perpendicular line to
                    // [source, target] at the computed intersection point:
                    var start = 0, sign = 1, steps = 1;
                    if (setNodes.length % 2 == 1) {
                        steps = 0;
                        start = 1;
                    }
                    for (var i = 0; i < setNodes.length; i++) {
                        NodeMatrix[np(setNodes[i], 'x')] =
                            intersectionPoint.x + (sign * nNormaleVector.x * steps) *
                                ((start || i >= 2)
                                    ? W.settings.nodeSiblingsScale
                                    : W.settings.nodeSiblingsScale * 2 / 3);
                        NodeMatrix[np(setNodes[i], 'y')] =
                            intersectionPoint.y + (sign * nNormaleVector.y * steps) *
                                ((start || i >= 2)
                                    ? W.settings.nodeSiblingsScale
                                    : W.settings.nodeSiblingsScale * 2 / 3);
                        sign = -sign;
                        steps += (i + start) % 2;
                    }
                });
            }
        }
    }
    // Algorithm run
    function compute(nodes, edges, config) {
        var graph = { nodes: nodes, edges: edges };
        init(graph, config);
        firstIteration = false;
        while (!W.converged) {
            pass();
        }
        updateGraphNodes(graph);
        return true;
    }
    /**
     * Algorithm initialization
     */
    function init(graph, config) {
        config = config || {};
        var byteArrays = graphToByteArrays(graph, config);
        // Matrices
        NodeMatrix = byteArrays.nodes;
        EdgeMatrix = byteArrays.edges;
        // Length
        W.nodesLength = NodeMatrix.length;
        W.edgesLength = EdgeMatrix.length;
        // Merging configuration
        configure(config);
    }
    function configure(o) {
        W.settings = extend(o, W.settings);
    }
    function extend() {
        var i, k, res = {}, l = arguments.length;
        for (i = l - 1; i >= 0; i--) {
            for (k in arguments[i]) {
                res[k] = arguments[i][k];
            }
        }
        return res;
    }
    /**
     *
     * @param {object} graph
     * @param {object[]} graph.nodes
     * @param {string|number} graph.nodes.id
     * @param {number} [graph.nodes.size]
     * @param {object[]} graph.edges
     * @param {string|number} [graph.edges.id]
     * @param {string|number} graph.edges.source
     * @param {string|number} graph.edges.target
     * @param {object} config
     * @returns {{nodes: Float32Array, edges: Float32Array}}
     */
    function graphToByteArrays(graph, config) {
        var nodes = graph.nodes, edges = graph.edges, nodeIndex = {}, i, j, l, node, edge;
        // Allocating Byte arrays with correct nb of bytes
        var nodesByteArray = new Float32Array(nodes.length * W.ppn);
        var edgesByteArray = new Float32Array(edges.length * W.ppe);
        // Iterate through nodes
        for (i = j = 0, l = nodes.length; i < l; i++, j += W.ppn) {
            node = nodes[i];
            // Populating index
            nodeIndex[node.id] = j;
            // Populating byte array
            nodesByteArray[j] = randomize(node.x, config);
            nodesByteArray[j + 1] = randomize(node.y, config);
            nodesByteArray[j + 2] = 0;
            nodesByteArray[j + 3] = 0;
            nodesByteArray[j + 4] = 0;
            nodesByteArray[j + 5] = 0;
            nodesByteArray[j + 6] = 1 + (node.degree || 0);
            nodesByteArray[j + 7] = 1;
            nodesByteArray[j + 8] = node.size || config.defaultSize || 1;
            nodesByteArray[j + 9] = node.pinned || 0;
        }
        // Iterate through edges
        for (i = j = 0, l = edges.length; i < l; i++, j += W.ppe) {
            edge = edges[i];
            edgesByteArray[j] = nodeIndex[edge.source];
            edgesByteArray[j + 1] = nodeIndex[edge.target];
            edgesByteArray[j + 2] = edge.weight || 0;
        }
        return { nodes: nodesByteArray, edges: edgesByteArray };
    }
    function updateGraphNodes(graph) {
        for (var i = 0, j = 0, l = NodeMatrix.length; i < l; i += W.ppn, ++j) {
            var node = graph.nodes[j];
            if (!node.pinned) {
                node.x = NodeMatrix[i];
                node.y = NodeMatrix[i + 1];
            }
        }
    }
    compute(nodes, edges, config);
}
module.exports = forceLinkLayout;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZm9yY2VMaW5rLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL3NlcnZpY2VzL2xheW91dC9mb3JjZUxpbmsuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFFYjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBcUJHO0FBRUg7Ozs7R0FJRztBQUNILFNBQVMsZUFBZSxDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsTUFBTTtJQUUzQyxJQUFJLGNBQWMsR0FBRyxJQUFJLENBQUM7SUFFMUI7O09BRUc7SUFDSCxJQUFJLENBQUMsR0FBRztRQUNOLGFBQWE7UUFDYixHQUFHLEVBQUUsRUFBRTtRQUNQLEdBQUcsRUFBRSxDQUFDO1FBQ04sR0FBRyxFQUFFLENBQUM7UUFDTixRQUFRLEVBQUUsRUFBRTtRQUNaLFVBQVUsRUFBRSxDQUFDO1FBQ2IsU0FBUyxFQUFFLEtBQUs7UUFFaEIsb0NBQW9DO1FBQ3BDLFFBQVEsRUFBRTtZQUNSLGlCQUFpQjtZQUNqQixVQUFVLEVBQUUsS0FBSztZQUNqQiw4QkFBOEIsRUFBRSxLQUFLO1lBQ3JDLFdBQVcsRUFBRSxLQUFLO1lBQ2xCLG1CQUFtQixFQUFFLENBQUM7WUFDdEIsWUFBWSxFQUFFLENBQUM7WUFDZixpQkFBaUIsRUFBRSxLQUFLO1lBQ3hCLE9BQU8sRUFBRSxDQUFDO1lBQ1YsUUFBUSxFQUFFLENBQUM7WUFDWCxpQkFBaUIsRUFBRSxLQUFLO1lBQ3hCLGNBQWMsRUFBRSxHQUFHO1lBQ25CLGtCQUFrQixFQUFFLENBQUM7WUFDckIsbUJBQW1CLEVBQUUsQ0FBQztZQUN0QixzQkFBc0I7WUFDdEIsYUFBYSxFQUFFLElBQUk7WUFDbkIsb0JBQW9CLEVBQUUsSUFBSTtZQUMxQixRQUFRLEVBQUUsSUFBSTtZQUNkLGlCQUFpQjtZQUNqQixpQkFBaUIsRUFBRSxLQUFLO1lBQ3hCLGlCQUFpQixFQUFFLENBQUM7WUFDcEIsb0JBQW9CLEVBQUUsQ0FBQztTQUN4QjtLQUNGLENBQUM7SUFFRixJQUFJLFVBQVUsRUFBRSxVQUFVLEVBQUUsU0FBUyxDQUFDO0lBRXRDOzs7Ozs7Ozs7T0FTRztJQUNILFNBQVMsV0FBVyxDQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUU7UUFDakMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxHQUFHLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxHQUFHLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxHQUFHLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFDbEUsQ0FBQztJQUVEOzs7Ozs7Ozs7O09BVUc7SUFDSCxTQUFTLFVBQVUsQ0FBQyxLQUFLLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsUUFBUTtRQUM3RCxPQUFPLENBQUMsQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDLENBQUMsR0FBRyxRQUFRLENBQUM7SUFDdEYsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsU0FBUyxjQUFjLENBQUMsQ0FBQztRQUN2QixPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQzNELENBQUM7SUFFRDs7Ozs7Ozs7OztPQVVHO0lBQ0gsU0FBUyxlQUFlLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRTtRQUNyQyxPQUFPO1lBQ0wsRUFBRSxFQUFFLENBQUMsQ0FBQyxFQUFFLEdBQUcsRUFBRSxDQUFDO1lBQ2QsRUFBRSxFQUFFLEVBQUUsR0FBRyxFQUFFO1lBQ1gsVUFBVSxFQUFFLEVBQUUsR0FBRyxFQUFFO1lBQ25CLFVBQVUsRUFBRSxDQUFDLENBQUMsRUFBRSxHQUFHLEVBQUUsQ0FBQztTQUN2QixDQUFDO0lBQ0osQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILFNBQVMsbUJBQW1CLENBQUMsQ0FBQyxFQUFFLE1BQU07UUFDcEMsT0FBTztZQUNMLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsTUFBTTtZQUNsQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE1BQU07U0FDbkMsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7Ozs7OztPQVVHO0lBQ0gsU0FBUyxxQkFBcUIsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsQ0FBQztRQUM5QyxPQUFPO1lBQ0wsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLEVBQUUsR0FBRyxFQUFFLENBQUMsR0FBRyxDQUFDO1lBQ3JCLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxFQUFFLEdBQUcsRUFBRSxDQUFDLEdBQUcsQ0FBQztTQUN0QixDQUFDO0lBQ0osQ0FBQztJQUVEOztPQUVHO0lBQ0gsSUFBSSxjQUFjLEdBQUc7UUFDbkIsQ0FBQyxFQUFFLENBQUM7UUFDSixDQUFDLEVBQUUsQ0FBQztRQUNKLEVBQUUsRUFBRSxDQUFDO1FBQ0wsRUFBRSxFQUFFLENBQUM7UUFDTCxRQUFRLEVBQUUsQ0FBQztRQUNYLFFBQVEsRUFBRSxDQUFDO1FBQ1gsSUFBSSxFQUFFLENBQUM7UUFDUCxXQUFXLEVBQUUsQ0FBQztRQUNkLElBQUksRUFBRSxDQUFDO1FBQ1AsTUFBTSxFQUFFLENBQUM7S0FDVixDQUFDO0lBRUYsSUFBSSxjQUFjLEdBQUc7UUFDbkIsTUFBTSxFQUFFLENBQUM7UUFDVCxNQUFNLEVBQUUsQ0FBQztRQUNULE1BQU0sRUFBRSxDQUFDO0tBQ1YsQ0FBQztJQUVGLElBQUksZ0JBQWdCLEdBQUc7UUFDckIsSUFBSSxFQUFFLENBQUM7UUFDUCxPQUFPLEVBQUUsQ0FBQztRQUNWLE9BQU8sRUFBRSxDQUFDO1FBQ1YsSUFBSSxFQUFFLENBQUM7UUFDUCxXQUFXLEVBQUUsQ0FBQztRQUNkLFVBQVUsRUFBRSxDQUFDO1FBQ2IsSUFBSSxFQUFFLENBQUM7UUFDUCxXQUFXLEVBQUUsQ0FBQztRQUNkLFdBQVcsRUFBRSxDQUFDO0tBQ2YsQ0FBQztJQUVGLFNBQVMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDO1FBRWQsb0JBQW9CO1FBQ3BCLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUNyQixNQUFNLElBQUksS0FBSyxDQUFDLDhDQUE4QyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQztTQUM1RTtRQUNELElBQUksQ0FBQyxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUNyQixNQUFNLElBQUksU0FBUyxDQUFDLGdEQUFnRCxDQUFDLENBQUM7U0FDdkU7UUFDRCxJQUFJLENBQUMsSUFBSSxjQUFjLEVBQUU7WUFDdkIsT0FBTyxDQUFDLEdBQUcsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQzlCO2FBQU07WUFDTCxNQUFNLElBQUksS0FBSyxDQUFDLHFEQUFxRCxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQztTQUNuRjtJQUNILENBQUM7SUFFRCxTQUFTLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUNkLG9CQUFvQjtRQUNwQixJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDckIsTUFBTSxJQUFJLEtBQUssQ0FBQyw4Q0FBOEMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUM7U0FDNUU7UUFDRCxJQUFJLENBQUMsS0FBSyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUU7WUFDckIsTUFBTSxJQUFJLFNBQVMsQ0FBQyxnREFBZ0QsQ0FBQyxDQUFDO1NBQ3ZFO1FBQ0QsSUFBSSxDQUFDLElBQUksY0FBYyxFQUFFO1lBQ3ZCLE9BQU8sQ0FBQyxHQUFHLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUM5QjthQUFNO1lBQ0wsTUFBTSxJQUFJLEtBQUssQ0FBQyxxREFBcUQsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUM7U0FDbkY7SUFDSCxDQUFDO0lBRUQsU0FBUyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUM7UUFDZCxvQkFBb0I7UUFDcEIsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ3JCLE1BQU0sSUFBSSxLQUFLLENBQUMsOENBQThDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDO1NBQzVFO1FBQ0QsSUFBSSxDQUFDLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFFO1lBQ3JCLE1BQU0sSUFBSSxTQUFTLENBQUMsZ0RBQWdELENBQUMsQ0FBQztTQUN2RTtRQUNELElBQUksQ0FBQyxJQUFJLGdCQUFnQixFQUFFO1lBQ3pCLE9BQU8sQ0FBQyxHQUFHLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ2hDO2FBQU07WUFDTCxNQUFNLElBQUksS0FBSyxDQUFDLHVEQUF1RCxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQztTQUNyRjtJQUNILENBQUM7SUFFRCxTQUFTLFNBQVMsQ0FBQyxDQUFDLEVBQUUsTUFBTTtRQUMxQixRQUFRLE1BQU0sQ0FBQyxTQUFTLEVBQUU7WUFDeEIsS0FBSyxVQUFVO2dCQUNiLE9BQU8sSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsTUFBTSxDQUFDLGVBQWUsSUFBSSxDQUFDLENBQUMsQ0FBQztZQUN2RCxLQUFLLFNBQVM7Z0JBQ1osT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxNQUFNLENBQUMsZUFBZSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDN0Q7Z0JBQ0UsT0FBTyxDQUFDLENBQUM7U0FDWjtJQUNILENBQUM7SUFFRDs7T0FFRztJQUNILCtDQUErQztJQUMvQyxTQUFTLElBQUk7UUFDWCxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUM7UUFFN0IsSUFBSSx1QkFBdUIsRUFDekIsV0FBVyxFQUNYLEtBQUssRUFDTCxLQUFLLEVBQ0wsUUFBUSxFQUNSLFFBQVEsRUFDUixHQUFHLEVBQ0gsSUFBSSxFQUNKLFFBQVEsRUFDUixJQUFJLEVBQ0osTUFBTSxDQUFDO1FBRVQsOEJBQThCO1FBQzlCLCtCQUErQjtRQUUvQiw2Q0FBNkM7UUFDN0MsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFO1lBQ3pDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDLEdBQUcsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQztZQUN0RCxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7WUFDdEQsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDNUIsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDN0I7UUFFRCxrREFBa0Q7UUFDbEQsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLDhCQUE4QixFQUFFO1lBQzdDLHVCQUF1QixHQUFHLENBQUMsQ0FBQztZQUM1QixLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUU7Z0JBQ3pDLHVCQUF1QixJQUFJLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUM7YUFDdEQ7WUFFRCx1QkFBdUIsSUFBSSxDQUFDLENBQUMsV0FBVyxDQUFDO1NBQzFDO1FBRUQsZ0NBQWdDO1FBQ2hDLGdDQUFnQztRQUVoQyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsaUJBQWlCLEVBQUU7WUFFaEMsSUFBSSxJQUFJLEdBQUcsUUFBUSxFQUNqQixJQUFJLEdBQUcsQ0FBQyxRQUFRLEVBQ2hCLElBQUksR0FBRyxRQUFRLEVBQ2YsSUFBSSxHQUFHLENBQUMsUUFBUSxFQUNoQixDQUFDLEVBQUUsRUFBRSxDQUFDO1lBRVIsYUFBYTtZQUNiLG1FQUFtRTtZQUNuRSxTQUFTLEdBQUcsRUFBRSxDQUFDO1lBRWYsK0JBQStCO1lBQy9CLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRTtnQkFDekMsSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDOUMsSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDOUMsSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDOUMsSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUMvQztZQUVELG1DQUFtQztZQUNuQyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1lBQzlCLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ2hELFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ2hELFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLEdBQUcsSUFBSSxFQUFFLElBQUksR0FBRyxJQUFJLENBQUMsQ0FBQztZQUM5RCxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxhQUFhLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1lBQ3JDLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLFlBQVksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDcEMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDN0IsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsYUFBYSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDcEMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsYUFBYSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7WUFFcEMsNEJBQTRCO1lBQzVCLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDTixLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUU7Z0JBRXpDLHFDQUFxQztnQkFDckMsQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFFTixPQUFPLElBQUksRUFBRTtvQkFDWCx5QkFBeUI7b0JBRXpCLCtCQUErQjtvQkFDL0IsSUFBSSxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRTt3QkFFdkMsd0JBQXdCO3dCQUV4QixnREFBZ0Q7d0JBQ2hELHlEQUF5RDt3QkFDekQsa0JBQWtCO3dCQUVsQix5QkFBeUI7d0JBQ3pCLElBQUksVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxTQUFTLENBQUMsQ0FBQyxFQUFFOzRCQUV4RCxJQUFJLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsU0FBUyxDQUFDLENBQUMsRUFBRTtnQ0FFeEQsbUJBQW1CO2dDQUNuQixDQUFDLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsWUFBWSxDQUFDLENBQUMsQ0FBQzs2QkFDcEM7aUNBQU07Z0NBRUwsc0JBQXNCO2dDQUN0QixDQUFDLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsWUFBWSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDOzZCQUM1Qzt5QkFDRjs2QkFBTTs0QkFDTCxJQUFJLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsU0FBUyxDQUFDLENBQUMsRUFBRTtnQ0FFeEQsb0JBQW9CO2dDQUNwQixDQUFDLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsWUFBWSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQzs2QkFDaEQ7aUNBQU07Z0NBRUwsdUJBQXVCO2dDQUN2QixDQUFDLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsWUFBWSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQzs2QkFDaEQ7eUJBQ0Y7d0JBRUQsdUVBQXVFO3dCQUN2RSxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxhQUFhLENBQUMsQ0FBQzs0QkFDN0IsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxhQUFhLENBQUMsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO2dDQUN6RCxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUM7Z0NBQ3JELENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBRXpELFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLGFBQWEsQ0FBQyxDQUFDOzRCQUM3QixDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLGFBQWEsQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUM7Z0NBQ3pELFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQztnQ0FDckQsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFFekQsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUMsSUFBSSxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDO3dCQUV0RCxnQ0FBZ0M7d0JBQ2hDLENBQUMsR0FBRyxDQUFDLENBQUM7d0JBQ04sU0FBUztxQkFDVjt5QkFBTTt3QkFFTCxnREFBZ0Q7d0JBRWhELGlDQUFpQzt3QkFDakMsSUFBSSxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRTs0QkFFaEMsOEJBQThCOzRCQUM5Qiw2QkFBNkI7NEJBQzdCLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDOzRCQUM3QixNQUFNO3lCQUNQOzZCQUFNOzRCQUVMLGlDQUFpQzs0QkFFakMsb0RBQW9EOzRCQUNwRCxvREFBb0Q7NEJBQ3BELGlEQUFpRDs0QkFDakQsbUJBQW1COzRCQUVuQixxQkFBcUI7NEJBQ3JCLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLFlBQVksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUM7NEJBQzNDLENBQUMsR0FBRyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFFLGtCQUFrQjs0QkFFckQsa0NBQWtDOzRCQUNsQyxnQ0FBZ0M7NEJBRWhDLHNCQUFzQjs0QkFDdEIsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLFlBQVksQ0FBQyxDQUFDLENBQUM7NEJBRW5DLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7NEJBQzlCLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsU0FBUyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7NEJBQzlELFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsU0FBUyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7NEJBQzlELFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDOzRCQUM3QixTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxhQUFhLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDOzRCQUM1QyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxZQUFZLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDOzRCQUNwQyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQzs0QkFDN0IsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsYUFBYSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7NEJBQ3BDLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLGFBQWEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDOzRCQUVwQyx5QkFBeUI7NEJBQ3pCLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDOzRCQUNYLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7NEJBQzlCLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsU0FBUyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7NEJBQzlELFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsU0FBUyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7NEJBQzlELFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDOzRCQUM3QixTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxhQUFhLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDOzRCQUM1QyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxZQUFZLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDOzRCQUNwQyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQzs0QkFDN0IsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsYUFBYSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7NEJBQ3BDLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLGFBQWEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDOzRCQUVwQyx1QkFBdUI7NEJBQ3ZCLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDOzRCQUNYLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7NEJBQzlCLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsU0FBUyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7NEJBQzlELFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsU0FBUyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7NEJBQzlELFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDOzRCQUM3QixTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxhQUFhLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDOzRCQUM1QyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxZQUFZLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDOzRCQUNwQyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQzs0QkFDN0IsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsYUFBYSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7NEJBQ3BDLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLGFBQWEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDOzRCQUVwQywwQkFBMEI7NEJBQzFCLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDOzRCQUNYLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7NEJBQzlCLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsU0FBUyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7NEJBQzlELFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsU0FBUyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7NEJBQzlELFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDOzRCQUM3QixTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxhQUFhLENBQUMsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLGFBQWEsQ0FBQyxDQUFDLENBQUM7NEJBQ2xFLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLFlBQVksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7NEJBQ3BDLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDOzRCQUM3QixTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxhQUFhLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQzs0QkFDcEMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsYUFBYSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7NEJBRXBDLENBQUMsSUFBSSxDQUFDLENBQUM7NEJBRVAsb0RBQW9EOzRCQUNwRCx3REFBd0Q7NEJBQ3hELGlDQUFpQzs0QkFFakMsb0NBQW9DOzRCQUNwQyxJQUFJLFVBQVUsQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDLEVBQUU7Z0NBQy9FLElBQUksVUFBVSxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsU0FBUyxDQUFDLENBQUMsRUFBRTtvQ0FFL0UsbUJBQW1CO29DQUNuQixDQUFDLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsWUFBWSxDQUFDLENBQUMsQ0FBQztpQ0FDcEM7cUNBQU07b0NBRUwsc0JBQXNCO29DQUN0QixDQUFDLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsWUFBWSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDO2lDQUM1Qzs2QkFDRjtpQ0FBTTtnQ0FDTCxJQUFJLFVBQVUsQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDLEVBQUU7b0NBRS9FLG9CQUFvQjtvQ0FDcEIsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLFlBQVksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUM7aUNBQ2hEO3FDQUFNO29DQUVMLHVCQUF1QjtvQ0FDdkIsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLFlBQVksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUM7aUNBQ2hEOzZCQUNGOzRCQUVELHlFQUF5RTs0QkFDekUsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQzs0QkFDNUUsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsYUFBYSxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQzs0QkFDaEYsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsYUFBYSxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQzs0QkFFaEYsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUMsR0FBRyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDOzRCQUNwRCxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDOzRCQUU5Qix5QkFBeUI7NEJBQ3pCLElBQUksVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxTQUFTLENBQUMsQ0FBQyxFQUFFO2dDQUN4RCxJQUFJLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsU0FBUyxDQUFDLENBQUMsRUFBRTtvQ0FFeEQsbUJBQW1CO29DQUNuQixFQUFFLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsWUFBWSxDQUFDLENBQUMsQ0FBQztpQ0FDckM7cUNBQU07b0NBQ0wsc0JBQXNCO29DQUN0QixFQUFFLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsWUFBWSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDO2lDQUM3Qzs2QkFDRjtpQ0FBTTtnQ0FDTCxJQUFJLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsU0FBUyxDQUFDLENBQUMsRUFBRTtvQ0FFeEQsb0JBQW9CO29DQUNwQixFQUFFLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsWUFBWSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQztpQ0FDakQ7cUNBQU07b0NBRUwsdUJBQXVCO29DQUN2QixFQUFFLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsWUFBWSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQztpQ0FDakQ7NkJBQ0Y7NEJBRUQsSUFBSSxDQUFDLEtBQUssRUFBRSxFQUFFO2dDQUVaLDBDQUEwQztnQ0FDMUMsMkNBQTJDO2dDQUMzQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dDQUNOLFNBQVM7NkJBQ1Y7NEJBRUQsK0NBQStDOzRCQUMvQyxrQkFBa0I7NEJBQ2xCLFNBQVMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDOzRCQUM5QixNQUFNO3lCQUNQO3FCQUNGO2lCQUNGO2FBQ0Y7U0FDRjtRQUVELGVBQWU7UUFDZixnQkFBZ0I7UUFDaEIsa0VBQWtFO1FBRWxFLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsRUFBRTtZQUNoQyxXQUFXLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUM7WUFFdEMscUNBQXFDO1lBQ3JDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRTtnQkFFekMsc0NBQXNDO2dCQUV0QyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsNEJBQTRCO2dCQUNuQyxPQUFPLElBQUksRUFBRTtvQkFFWCxJQUFJLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFO3dCQUV2Qyw2QkFBNkI7d0JBRTdCLG9FQUFvRTt3QkFDcEUsUUFBUSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQ2xCLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxhQUFhLENBQUMsQ0FBQyxDQUFDOzRCQUMxRCxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsYUFBYSxDQUFDLENBQUMsQ0FBQzs0QkFDMUQsQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLGFBQWEsQ0FBQyxDQUFDLENBQUM7Z0NBQzFELENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQzNELENBQUM7d0JBRUYsSUFBSSxDQUFDLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUMsR0FBRyxRQUFRLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxjQUFjLEVBQUU7NEJBRXZFLHVEQUF1RDs0QkFFdkQsS0FBSyxHQUFHLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsYUFBYSxDQUFDLENBQUMsQ0FBQzs0QkFDakUsS0FBSyxHQUFHLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsYUFBYSxDQUFDLENBQUMsQ0FBQzs0QkFFakUsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRTtnQ0FFMUIsb0NBQW9DO2dDQUNwQyxJQUFJLFFBQVEsR0FBRyxDQUFDLEVBQUU7b0NBQ2hCLE1BQU0sR0FBRyxXQUFXLEdBQUcsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUM7d0NBQzlDLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLEdBQUcsUUFBUSxHQUFHLFFBQVEsQ0FBQztvQ0FFakQsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsSUFBSSxLQUFLLEdBQUcsTUFBTSxDQUFDO29DQUMxQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLEtBQUssR0FBRyxNQUFNLENBQUM7aUNBQzNDO3FDQUFNLElBQUksUUFBUSxHQUFHLENBQUMsRUFBRTtvQ0FDdkIsTUFBTSxHQUFHLENBQUMsV0FBVyxHQUFHLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO3dDQUMvQyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxHQUFHLFFBQVEsQ0FBQztvQ0FFdEMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsSUFBSSxLQUFLLEdBQUcsTUFBTSxDQUFDO29DQUMxQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLEtBQUssR0FBRyxNQUFNLENBQUM7aUNBQzNDOzZCQUNGO2lDQUFNO2dDQUVMLHFCQUFxQjtnQ0FDckIsSUFBSSxRQUFRLEdBQUcsQ0FBQyxFQUFFO29DQUNoQixNQUFNLEdBQUcsV0FBVyxHQUFHLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO3dDQUM5QyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxHQUFHLFFBQVEsR0FBRyxRQUFRLENBQUM7b0NBRWpELFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLElBQUksS0FBSyxHQUFHLE1BQU0sQ0FBQztvQ0FDMUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsSUFBSSxLQUFLLEdBQUcsTUFBTSxDQUFDO2lDQUMzQzs2QkFDRjs0QkFFRCxzRUFBc0U7NEJBQ3RFLElBQUksU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsYUFBYSxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0NBQ3ZDLE1BQU0sQ0FBRSw2Q0FBNkM7NkJBQ3REOzRCQUNELENBQUMsR0FBRyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxhQUFhLENBQUMsQ0FBQyxDQUFDOzRCQUNwQyxTQUFTO3lCQUVWOzZCQUFNOzRCQUVMLDZEQUE2RDs0QkFDN0QsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLFlBQVksQ0FBQyxDQUFDLENBQUM7NEJBQ25DLFNBQVM7eUJBQ1Y7cUJBRUY7eUJBQU07d0JBRUwsK0JBQStCO3dCQUMvQix3REFBd0Q7d0JBRXhELElBQUksU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUU7NEJBQ25FLEtBQUssR0FBRyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDOzRCQUMvRSxLQUFLLEdBQUcsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQzs0QkFFL0UsUUFBUSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxDQUFDLENBQUM7NEJBRXBELElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUU7Z0NBRTFCLG9DQUFvQztnQ0FDcEMsSUFBSSxRQUFRLEdBQUcsQ0FBQyxFQUFFO29DQUNoQixNQUFNLEdBQUcsV0FBVyxHQUFHLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO3dDQUM5QyxVQUFVLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUMsR0FBRyxRQUFRLEdBQUcsUUFBUSxDQUFDO29DQUV6RSxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLEtBQUssR0FBRyxNQUFNLENBQUM7b0NBQzFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLElBQUksS0FBSyxHQUFHLE1BQU0sQ0FBQztpQ0FDM0M7cUNBQU0sSUFBSSxRQUFRLEdBQUcsQ0FBQyxFQUFFO29DQUN2QixNQUFNLEdBQUcsQ0FBQyxXQUFXLEdBQUcsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUM7d0NBQy9DLFVBQVUsQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxHQUFHLFFBQVEsQ0FBQztvQ0FFOUQsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsSUFBSSxLQUFLLEdBQUcsTUFBTSxDQUFDO29DQUMxQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLEtBQUssR0FBRyxNQUFNLENBQUM7aUNBQzNDOzZCQUNGO2lDQUFNO2dDQUVMLHFCQUFxQjtnQ0FDckIsSUFBSSxRQUFRLEdBQUcsQ0FBQyxFQUFFO29DQUNoQixNQUFNLEdBQUcsV0FBVyxHQUFHLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO3dDQUM5QyxVQUFVLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUMsR0FBRyxRQUFRLEdBQUcsUUFBUSxDQUFDO29DQUV6RSxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLEtBQUssR0FBRyxNQUFNLENBQUM7b0NBQzFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLElBQUksS0FBSyxHQUFHLE1BQU0sQ0FBQztpQ0FDM0M7NkJBQ0Y7eUJBRUY7d0JBRUQsc0VBQXNFO3dCQUN0RSxJQUFJLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLGFBQWEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFOzRCQUN2QyxNQUFNLENBQUUsNkNBQTZDO3lCQUN0RDt3QkFDRCxDQUFDLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsYUFBYSxDQUFDLENBQUMsQ0FBQzt3QkFDcEMsU0FBUztxQkFDVjtpQkFDRjthQUNGO1NBQ0Y7YUFBTTtZQUNMLFdBQVcsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQztZQUV0QyxtQkFBbUI7WUFDbkIsS0FBSyxFQUFFLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsV0FBVyxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFO2dCQUM1QyxLQUFLLEVBQUUsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRTtvQkFFakMseUJBQXlCO29CQUN6QixLQUFLLEdBQUcsVUFBVSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO29CQUMxRCxLQUFLLEdBQUcsVUFBVSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO29CQUUxRCxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFO3dCQUUxQixtQ0FBbUM7d0JBQ25DLFFBQVEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssQ0FBQzs0QkFDakQsVUFBVSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsTUFBTSxDQUFDLENBQUM7NEJBQzFCLFVBQVUsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUM7d0JBRTdCLElBQUksUUFBUSxHQUFHLENBQUMsRUFBRTs0QkFDaEIsTUFBTSxHQUFHLFdBQVc7Z0NBQ2xCLFVBQVUsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxDQUFDO2dDQUMxQixVQUFVLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxNQUFNLENBQUMsQ0FBQztnQ0FDMUIsUUFBUSxHQUFHLFFBQVEsQ0FBQzs0QkFFdEIsNEJBQTRCOzRCQUM1QixVQUFVLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLEtBQUssR0FBRyxNQUFNLENBQUM7NEJBQzNDLFVBQVUsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDLElBQUksS0FBSyxHQUFHLE1BQU0sQ0FBQzs0QkFFM0MsVUFBVSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUMsSUFBSSxLQUFLLEdBQUcsTUFBTSxDQUFDOzRCQUMzQyxVQUFVLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLEtBQUssR0FBRyxNQUFNLENBQUM7eUJBQzVDOzZCQUFNLElBQUksUUFBUSxHQUFHLENBQUMsRUFBRTs0QkFDdkIsTUFBTSxHQUFHLEdBQUcsR0FBRyxXQUFXO2dDQUN4QixVQUFVLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxNQUFNLENBQUMsQ0FBQztnQ0FDMUIsVUFBVSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQzs0QkFFN0IsNEJBQTRCOzRCQUM1QixVQUFVLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLEtBQUssR0FBRyxNQUFNLENBQUM7NEJBQzNDLFVBQVUsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDLElBQUksS0FBSyxHQUFHLE1BQU0sQ0FBQzs0QkFFM0MsVUFBVSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUMsSUFBSSxLQUFLLEdBQUcsTUFBTSxDQUFDOzRCQUMzQyxVQUFVLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLEtBQUssR0FBRyxNQUFNLENBQUM7eUJBQzVDO3FCQUNGO3lCQUFNO3dCQUVMLHFCQUFxQjt3QkFDckIsUUFBUSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxDQUFDLENBQUM7d0JBRXBELElBQUksUUFBUSxHQUFHLENBQUMsRUFBRTs0QkFDaEIsTUFBTSxHQUFHLFdBQVc7Z0NBQ2xCLFVBQVUsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxDQUFDO2dDQUMxQixVQUFVLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxNQUFNLENBQUMsQ0FBQztnQ0FDMUIsUUFBUSxHQUFHLFFBQVEsQ0FBQzs0QkFFdEIsNEJBQTRCOzRCQUM1QixVQUFVLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLEtBQUssR0FBRyxNQUFNLENBQUM7NEJBQzNDLFVBQVUsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDLElBQUksS0FBSyxHQUFHLE1BQU0sQ0FBQzs0QkFFM0MsVUFBVSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUMsSUFBSSxLQUFLLEdBQUcsTUFBTSxDQUFDOzRCQUMzQyxVQUFVLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLEtBQUssR0FBRyxNQUFNLENBQUM7eUJBQzVDO3FCQUNGO2lCQUNGO2FBQ0Y7U0FDRjtRQUVELGFBQWE7UUFDYixjQUFjO1FBQ2QsQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDO1FBQ2pELFdBQVcsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQztRQUN0QyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUU7WUFDekMsTUFBTSxHQUFHLENBQUMsQ0FBQztZQUVYLHlCQUF5QjtZQUN6QixLQUFLLEdBQUcsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUMvQixLQUFLLEdBQUcsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUMvQixRQUFRLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssR0FBRyxLQUFLLENBQUMsQ0FBQztZQUVwRCxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsaUJBQWlCLEVBQUU7Z0JBRWhDLG1CQUFtQjtnQkFDbkIsSUFBSSxRQUFRLEdBQUcsQ0FBQyxFQUFFO29CQUNoQixNQUFNLEdBQUcsV0FBVyxHQUFHLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2lCQUN0RDthQUNGO2lCQUFNO2dCQUVMLHNDQUFzQztnQkFDdEMsSUFBSSxRQUFRLEdBQUcsQ0FBQyxFQUFFO29CQUNoQixNQUFNLEdBQUcsV0FBVyxHQUFHLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLFFBQVEsQ0FBQztpQkFDakU7YUFDRjtZQUVELDRCQUE0QjtZQUM1QixVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLEtBQUssR0FBRyxNQUFNLENBQUM7WUFDMUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsSUFBSSxLQUFLLEdBQUcsTUFBTSxDQUFDO1NBQzNDO1FBRUQsZ0JBQWdCO1FBQ2hCLGlCQUFpQjtRQUNqQixXQUFXLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRTVGLDBCQUEwQjtRQUMxQix1REFBdUQ7UUFDdkQsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFO1lBQ3pDLEVBQUUsR0FBRyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDO1lBQ2pDLEVBQUUsR0FBRyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDO1lBQ2pDLENBQUMsR0FBRyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDO1lBRWhDLHdCQUF3QjtZQUN4QixHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1lBRWxELGtCQUFrQjtZQUNsQixLQUFLLEdBQUcsVUFBVSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO1lBQzFELEtBQUssR0FBRyxVQUFVLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFFMUQsK0JBQStCO1lBQy9CLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUU7Z0JBRTFCLFFBQVEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUNsQixDQUFDLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssQ0FBQztvQkFDL0IsVUFBVSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsTUFBTSxDQUFDLENBQUM7b0JBQzFCLFVBQVUsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQzNCLENBQUM7Z0JBRUYsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLFVBQVUsRUFBRTtvQkFDekIsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLDhCQUE4QixFQUFFO3dCQUU3Qyx3REFBd0Q7d0JBQ3hELElBQUksUUFBUSxHQUFHLENBQUMsRUFBRTs0QkFDaEIsTUFBTSxHQUFHLENBQUMsV0FBVyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxRQUFRLENBQUM7Z0NBQ2xELFFBQVE7Z0NBQ1IsVUFBVSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQzt5QkFDOUI7cUJBQ0Y7eUJBQU07d0JBRUwscUNBQXFDO3dCQUNyQyxJQUFJLFFBQVEsR0FBRyxDQUFDLEVBQUU7NEJBQ2hCLE1BQU0sR0FBRyxDQUFDLFdBQVcsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsUUFBUSxDQUFDLEdBQUcsUUFBUSxDQUFDO3lCQUNqRTtxQkFDRjtpQkFDRjtxQkFBTTtvQkFDTCxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsOEJBQThCLEVBQUU7d0JBRTdDLHdEQUF3RDt3QkFDeEQsSUFBSSxRQUFRLEdBQUcsQ0FBQyxFQUFFOzRCQUNoQixNQUFNLEdBQUcsQ0FBQyxXQUFXLEdBQUcsR0FBRyxHQUFHLFVBQVUsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUM7eUJBQzFEO3FCQUNGO3lCQUFNO3dCQUVMLHFDQUFxQzt3QkFDckMsSUFBSSxRQUFRLEdBQUcsQ0FBQyxFQUFFOzRCQUNoQixNQUFNLEdBQUcsQ0FBQyxXQUFXLEdBQUcsR0FBRyxDQUFDO3lCQUM3QjtxQkFDRjtpQkFDRjthQUNGO2lCQUFNO2dCQUVMLFFBQVEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssQ0FBQyxDQUFDO2dCQUVwRCxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsVUFBVSxFQUFFO29CQUN6QixJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsOEJBQThCLEVBQUU7d0JBRTdDLHlDQUF5Qzt3QkFDekMsSUFBSSxRQUFRLEdBQUcsQ0FBQyxFQUFFOzRCQUNoQixNQUFNLEdBQUcsQ0FBQyxXQUFXLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLFFBQVEsQ0FBQztnQ0FDbEQsUUFBUTtnQ0FDUixVQUFVLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDO3lCQUM5QjtxQkFDRjt5QkFBTTt3QkFFTCxzQkFBc0I7d0JBQ3RCLElBQUksUUFBUSxHQUFHLENBQUMsRUFBRTs0QkFDaEIsTUFBTSxHQUFHLENBQUMsV0FBVyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxRQUFRLENBQUMsR0FBRyxRQUFRLENBQUM7eUJBQ2pFO3FCQUNGO2lCQUNGO3FCQUFNO29CQUNMLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyw4QkFBOEIsRUFBRTt3QkFFN0MsdUNBQXVDO3dCQUN2Qyx3REFBd0Q7d0JBQ3hELFFBQVEsR0FBRyxDQUFDLENBQUM7d0JBQ2IsTUFBTSxHQUFHLENBQUMsV0FBVyxHQUFHLEdBQUcsR0FBRyxVQUFVLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDO3FCQUMxRDt5QkFBTTt3QkFFTCxzQkFBc0I7d0JBQ3RCLHdEQUF3RDt3QkFDeEQsUUFBUSxHQUFHLENBQUMsQ0FBQzt3QkFDYixNQUFNLEdBQUcsQ0FBQyxXQUFXLEdBQUcsR0FBRyxDQUFDO3FCQUM3QjtpQkFDRjthQUNGO1lBRUQsNEJBQTRCO1lBQzVCLG9DQUFvQztZQUNwQyxJQUFJLFFBQVEsR0FBRyxDQUFDLEVBQUU7Z0JBQ2hCLDRCQUE0QjtnQkFDNUIsVUFBVSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUMsSUFBSSxLQUFLLEdBQUcsTUFBTSxDQUFDO2dCQUMzQyxVQUFVLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLEtBQUssR0FBRyxNQUFNLENBQUM7Z0JBRTNDLFVBQVUsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDLElBQUksS0FBSyxHQUFHLE1BQU0sQ0FBQztnQkFDM0MsVUFBVSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUMsSUFBSSxLQUFLLEdBQUcsTUFBTSxDQUFDO2FBQzVDO1NBQ0Y7UUFFRCxrQkFBa0I7UUFDbEIsbUJBQW1CO1FBQ25CLElBQUksS0FBSyxFQUNQLFFBQVEsRUFDUixRQUFRLEVBQ1IsU0FBUyxFQUNULFdBQVcsR0FBRyxDQUFDLENBQUM7UUFFbEIsa0NBQWtDO1FBQ2xDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUU7WUFFMUIsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFO2dCQUN6QyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUMsRUFBRTtvQkFDaEMsS0FBSyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQ2YsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQzt3QkFDakQsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUNsRCxDQUFDO29CQUVGLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUU7d0JBQ3RCLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDOzRCQUNyQixVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO3dCQUMvQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQzs0QkFDckIsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztxQkFDaEQ7b0JBRUQsUUFBUSxHQUFHLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO3dCQUNsQyxJQUFJLENBQUMsSUFBSSxDQUNQLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUN2RCxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDLEdBQUcsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDdkQsQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7Z0NBQ3ZELENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQ3hELENBQUM7b0JBRUosUUFBUSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQ2xCLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDO3dCQUN2RCxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDLEdBQUcsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQzt3QkFDdkQsQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQ3ZELENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQ3hELEdBQUcsQ0FBQyxDQUFDO29CQUVOLFNBQVM7d0JBQ1AsR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztvQkFFM0QsUUFBUSxHQUFHLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7b0JBQ2xDLFFBQVEsR0FBRyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO29CQUVsQywwQkFBMEI7b0JBQzFCLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO3dCQUNwQixVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDOzRCQUNoRCxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDO29CQUNwQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQzt3QkFDcEIsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQzs0QkFDaEQsQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFFcEMsS0FBSyxHQUFHLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7b0JBQy9CLEtBQUssR0FBRyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO29CQUMvQixRQUFRLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FDbEIsQ0FBQyxLQUFLLEdBQUcsUUFBUSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEdBQUcsUUFBUSxDQUFDO3dCQUN2QyxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsR0FBRyxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsQ0FDeEMsQ0FBQztvQkFDRixXQUFXLElBQUksUUFBUSxDQUFDO2lCQUN6QjthQUNGO1NBQ0Y7YUFBTTtZQUVMLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRTtnQkFDekMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDLEVBQUU7b0JBRWhDLFFBQVEsR0FBRyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQzt3QkFDbEMsSUFBSSxDQUFDLElBQUksQ0FDUCxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDLEdBQUcsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDdkQsQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7NEJBQ3ZELENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dDQUN2RCxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDLEdBQUcsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUN4RCxDQUFDO29CQUVKLFFBQVEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUNsQixDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDLEdBQUcsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQzt3QkFDdkQsQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQ3ZELENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUN2RCxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDLEdBQUcsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUN4RCxHQUFHLENBQUMsQ0FBQztvQkFFTixTQUFTLEdBQUcsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsYUFBYSxDQUFDLENBQUM7d0JBQzFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztvQkFFckQsNEJBQTRCO29CQUM1QixVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxhQUFhLENBQUMsQ0FBQzt3QkFDOUIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FDbkIsU0FBUzs0QkFDVCxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLEdBQUcsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0NBQ2hELFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLEdBQUcsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDcEQsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUMxQixDQUFDLENBQUM7b0JBRUwsUUFBUSxHQUFHLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7b0JBQ2xDLFFBQVEsR0FBRyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO29CQUVsQywwQkFBMEI7b0JBQzFCLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO3dCQUNwQixVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDOzRCQUNoRCxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDO29CQUNwQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQzt3QkFDcEIsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQzs0QkFDaEQsQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFFcEMsS0FBSyxHQUFHLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7b0JBQy9CLEtBQUssR0FBRyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO29CQUMvQixRQUFRLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FDbEIsQ0FBQyxLQUFLLEdBQUcsUUFBUSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEdBQUcsUUFBUSxDQUFDO3dCQUN2QyxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsR0FBRyxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsQ0FDeEMsQ0FBQztvQkFDRixXQUFXLElBQUksUUFBUSxDQUFDO2lCQUN6QjthQUNGO1NBQ0Y7UUFFRCw4QkFBOEI7UUFDOUIsQ0FBQyxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBRWYsYUFBYTtRQUNiLDZDQUE2QztRQUM3QywyREFBMkQ7UUFDM0QsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRTtZQUN2QixDQUFDLENBQUMsU0FBUyxHQUFHLENBQ1osQ0FBQyxDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLGFBQWE7Z0JBQ3ZDLFdBQVcsR0FBRyxDQUFDLENBQUMsV0FBVyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsb0JBQW9CLENBQzlELENBQUM7WUFFRiwwREFBMEQ7WUFDMUQsSUFBSSxDQUFDLENBQUMsU0FBUyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsaUJBQWlCLEVBQUU7Z0JBQy9DLDZCQUE2QjtnQkFFN0IsSUFDRSxTQUFTLEdBQUcsRUFBRSxFQUFFLHFCQUFxQjtnQkFDckMsYUFBYSxHQUFHLEVBQUUsRUFBRSx3REFBd0Q7Z0JBQzVFLE1BQU0sRUFBRSxNQUFNO2dCQUNkLEtBQUssQ0FBQyxDQUFFLE1BQU07Z0JBRWhCLDRCQUE0QjtnQkFDNUIsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFO29CQUN6QyxFQUFFLEdBQUcsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQztvQkFDakMsRUFBRSxHQUFHLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUM7b0JBRWpDLElBQUksRUFBRSxLQUFLLEVBQUUsRUFBRTt3QkFBRSxTQUFTO3FCQUFFO29CQUU1QixTQUFTLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDcEMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxFQUFFLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ3BDLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUM7b0JBQ3pCLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUM7aUJBQzFCO2dCQUVELGtFQUFrRTtnQkFDbEUsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBUyxDQUFDO29CQUN2QyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFFLGdCQUFnQjtvQkFDMUIsS0FBSyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ2xDLElBQUksS0FBSyxDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUU7d0JBQ3JCLE1BQU0sR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDbkMsSUFBSSxNQUFNLElBQUksYUFBYSxFQUFFOzRCQUMzQixhQUFhLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO3lCQUMvQjs2QkFBTTs0QkFDTCxNQUFNLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQ25DLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLEVBQUU7Z0NBQzFCLGFBQWEsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOzZCQUNsRDs0QkFDRCxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO3lCQUMvQjtxQkFDRjtnQkFDSCxDQUFDLENBQUMsQ0FBQztnQkFFSCxJQUNFLFFBQVEsRUFDUixTQUFTLEVBQ1QsU0FBUyxFQUNULFNBQVMsRUFDVCxTQUFTLEVBQ1QsRUFBRSxFQUNGLEVBQUUsRUFDRixFQUFFLEVBQ0YsRUFBRSxFQUNGLENBQUMsRUFDRCxnQkFBZ0IsRUFDaEIsaUJBQWlCLEVBQ2pCLFlBQVksRUFDWixjQUFjLEVBQ2QsS0FBSyxFQUNMLFFBQVEsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLG9CQUFvQixDQUFDO2dCQUU3QyxNQUFNLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFTLEdBQUc7b0JBQzdDLFNBQVMsR0FBRyxhQUFhLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUM7b0JBQ3ZDLFNBQVMsR0FBRyxhQUFhLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUM7b0JBQ3ZDLFFBQVEsR0FBRyxhQUFhLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVMsT0FBTzt3QkFDbkQsT0FBTyxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUM7b0JBQzVDLENBQUMsQ0FBQyxDQUFDO29CQUVILElBQUksUUFBUSxDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUU7d0JBQUUsT0FBTztxQkFBRTtvQkFFckMsRUFBRSxHQUFHLFVBQVUsQ0FBQyxFQUFFLENBQUMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7b0JBQ3BDLEVBQUUsR0FBRyxVQUFVLENBQUMsRUFBRSxDQUFDLFNBQVMsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO29CQUNwQyxFQUFFLEdBQUcsVUFBVSxDQUFDLEVBQUUsQ0FBQyxTQUFTLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQztvQkFDcEMsRUFBRSxHQUFHLFVBQVUsQ0FBQyxFQUFFLENBQUMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7b0JBRXBDLG9EQUFvRDtvQkFDcEQsNkJBQTZCO29CQUM3QixTQUFTLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7b0JBQ3JELFNBQVMsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztvQkFDckQsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxTQUFTLEdBQUcsQ0FBQyxTQUFTLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztvQkFDeEUsaUJBQWlCLEdBQUcscUJBQXFCLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDO29CQUU3RCxpREFBaUQ7b0JBQ2pELFlBQVksR0FBRyxlQUFlLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7b0JBRS9DLGdCQUFnQixHQUFHLFdBQVcsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztvQkFFL0MsNEJBQTRCO29CQUM1QixjQUFjLEdBQUcsbUJBQW1CLENBQUMsWUFBWSxFQUFFLGdCQUFnQixDQUFDLENBQUM7b0JBRXJFLEtBQUssR0FBRyxjQUFjLENBQUMsY0FBYyxDQUFDLENBQUM7b0JBRXZDLHVEQUF1RDtvQkFDdkQsSUFBSSxDQUFDLEdBQUcsUUFBUSxHQUFHLElBQUksQ0FBQyxFQUFFLEVBQUU7d0JBQzFCLE1BQU0sSUFBSSxLQUFLLENBQ2IsMkVBQTJFLENBQzVFLENBQUM7cUJBQ0g7b0JBRUQsSUFBSSxRQUFRLEdBQUcsQ0FBQyxFQUFFO3dCQUNoQix3QkFBd0I7d0JBQ3hCLElBQUksS0FBSyxHQUFHLFFBQVEsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsRUFBRSxHQUFHLFFBQVEsQ0FBQyxJQUFJLEtBQUssSUFBSSxJQUFJLENBQUMsRUFBRSxFQUFFOzRCQUV4RSxvQ0FBb0M7NEJBQ3BDLGNBQWMsR0FBRztnQ0FDZixDQUFDLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxHQUFHLFFBQVEsQ0FBQyxHQUFHLENBQUM7Z0NBQ25DLENBQUMsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLEdBQUcsUUFBUSxDQUFDLEdBQUcsQ0FBQzs2QkFDcEMsQ0FBQzt5QkFDSDs2QkFBTSxJQUFJLENBQUMsS0FBSyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsRUFBRSxHQUFHLFFBQVEsQ0FBQzs0QkFDekMsS0FBSyxJQUFJLElBQUksQ0FBQyxFQUFFLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLEVBQUUsR0FBRyxRQUFRLENBQUMsRUFBRTs0QkFFbEQsK0JBQStCOzRCQUMvQixjQUFjLEdBQUc7Z0NBQ2YsQ0FBQyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQztnQ0FDekIsQ0FBQyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQzs2QkFDMUIsQ0FBQzt5QkFDSDtxQkFDRjtvQkFFRCwwREFBMEQ7b0JBQzFELHVEQUF1RDtvQkFDdkQsSUFBSSxLQUFLLEdBQUcsQ0FBQyxFQUFFLElBQUksR0FBRyxDQUFDLEVBQUUsS0FBSyxHQUFHLENBQUMsQ0FBQztvQkFFbkMsSUFBSSxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUU7d0JBQzVCLEtBQUssR0FBRyxDQUFDLENBQUM7d0JBQ1YsS0FBSyxHQUFHLENBQUMsQ0FBQztxQkFDWDtvQkFFRCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTt3QkFDeEMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7NEJBQzlCLGlCQUFpQixDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksR0FBRyxjQUFjLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQztnQ0FDdkQsQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO29DQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLGlCQUFpQjtvQ0FDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsaUJBQWlCLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FDekMsQ0FBQzt3QkFFSixVQUFVLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQzs0QkFDOUIsaUJBQWlCLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxHQUFHLGNBQWMsQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDO2dDQUN2RCxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7b0NBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsaUJBQWlCO29DQUM5QixDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUN6QyxDQUFDO3dCQUVKLElBQUksR0FBRyxDQUFDLElBQUksQ0FBQzt3QkFDYixLQUFLLElBQUksQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO3FCQUMxQjtnQkFDSCxDQUFDLENBQUMsQ0FBQzthQUNKO1NBQ0Y7SUFDSCxDQUFDO0lBRUQsZ0JBQWdCO0lBQ2hCLFNBQVMsT0FBTyxDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsTUFBTTtRQUNuQyxJQUFJLEtBQUssR0FBRyxFQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBQyxDQUFDO1FBQ3pDLElBQUksQ0FBQyxLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFFcEIsY0FBYyxHQUFHLEtBQUssQ0FBQztRQUN2QixPQUFPLENBQUMsQ0FBQyxDQUFDLFNBQVMsRUFBRTtZQUNuQixJQUFJLEVBQUUsQ0FBQztTQUNSO1FBQ0QsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDeEIsT0FBTyxJQUFJLENBQUM7SUFDZCxDQUFDO0lBRUQ7O09BRUc7SUFFSCxTQUFTLElBQUksQ0FBQyxLQUFLLEVBQUUsTUFBTTtRQUN6QixNQUFNLEdBQUcsTUFBTSxJQUFJLEVBQUUsQ0FBQztRQUN0QixJQUFJLFVBQVUsR0FBRyxpQkFBaUIsQ0FBQyxLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFFbEQsV0FBVztRQUNYLFVBQVUsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDO1FBQzlCLFVBQVUsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDO1FBRTlCLFNBQVM7UUFDVCxDQUFDLENBQUMsV0FBVyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUM7UUFDbEMsQ0FBQyxDQUFDLFdBQVcsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDO1FBRWxDLHdCQUF3QjtRQUN4QixTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDcEIsQ0FBQztJQUVELFNBQVMsU0FBUyxDQUFDLENBQUM7UUFDbEIsQ0FBQyxDQUFDLFFBQVEsR0FBRyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBRUQsU0FBUyxNQUFNO1FBQ2IsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEdBQUcsR0FBRyxFQUFFLEVBQUUsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxNQUFNLENBQUM7UUFDekMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzNCLEtBQUssQ0FBQyxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDdEIsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUMxQjtTQUNGO1FBQ0QsT0FBTyxHQUFHLENBQUM7SUFDYixDQUFDO0lBRUQ7Ozs7Ozs7Ozs7OztPQVlHO0lBQ0gsU0FBUyxpQkFBaUIsQ0FBQyxLQUFLLEVBQUUsTUFBTTtRQUN0QyxJQUFJLEtBQUssR0FBRyxLQUFLLENBQUMsS0FBSyxFQUNyQixLQUFLLEdBQUcsS0FBSyxDQUFDLEtBQUssRUFDbkIsU0FBUyxHQUFHLEVBQUUsRUFDZCxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDO1FBRXRCLGtEQUFrRDtRQUNsRCxJQUFJLGNBQWMsR0FBRyxJQUFJLFlBQVksQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUM1RCxJQUFJLGNBQWMsR0FBRyxJQUFJLFlBQVksQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUU1RCx3QkFBd0I7UUFDeEIsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFO1lBQ3hELElBQUksR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFaEIsbUJBQW1CO1lBQ25CLFNBQVMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBRXZCLHdCQUF3QjtZQUN4QixjQUFjLENBQUMsQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDOUMsY0FBYyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQztZQUNsRCxjQUFjLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUMxQixjQUFjLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUMxQixjQUFjLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUMxQixjQUFjLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUMxQixjQUFjLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUM7WUFDL0MsY0FBYyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDMUIsY0FBYyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxJQUFJLE1BQU0sQ0FBQyxXQUFXLElBQUksQ0FBQyxDQUFDO1lBQzdELGNBQWMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUM7U0FDMUM7UUFFRCx3QkFBd0I7UUFDeEIsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFO1lBQ3hELElBQUksR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDaEIsY0FBYyxDQUFDLENBQUMsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDM0MsY0FBYyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxTQUFTLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQy9DLGNBQWMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUM7U0FDMUM7UUFFRCxPQUFPLEVBQUMsS0FBSyxFQUFFLGNBQWMsRUFBRSxLQUFLLEVBQUUsY0FBYyxFQUFDLENBQUM7SUFDeEQsQ0FBQztJQUVELFNBQVMsZ0JBQWdCLENBQUMsS0FBSztRQUM3QixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxVQUFVLENBQUMsTUFBTSxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDcEUsSUFBSSxJQUFJLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMxQixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtnQkFDaEIsSUFBSSxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3ZCLElBQUksQ0FBQyxDQUFDLEdBQUcsVUFBVSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQzthQUM1QjtTQUNGO0lBQ0gsQ0FBQztJQUVELE9BQU8sQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDO0FBQ2hDLENBQUM7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLGVBQWUsQ0FBQyJ9