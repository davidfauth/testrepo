/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-03-03.
 */
'use strict';
// external libs
const _ = require('lodash');
// our libs
const ClusterManager = require('../../../lib/cluster-manager');
// services
const LKE = require('../index');
const Log = LKE.getLogger(__filename);
const Config = LKE.getConfig();
class LayoutCluster {
    constructor() {
        // get layout
        let forceLink;
        try {
            // try to get the minified/fast version
            forceLink = require('./forceLink.min');
        }
        catch (e) {
            Log.warn('Falling back to slow layout (minified version not found)');
            // fallback to development version
            forceLink = require('./forceLink');
        }
        this.cluster = new ClusterManager([
            new ClusterManager.Task('layout', ['nodes', 'edges', 'config'], p => {
                forceLink(p.nodes, p.edges, p.config);
                return p.nodes;
            })
        ], {
            info: message => Log.info(message),
            warn: message => Log.warn(message),
            error: message => Log.error(message)
        });
    }
    /**
     * Start the cluster
     */
    startCluster() {
        const workers = Config.get('advanced.layoutWorkers', 0);
        this.cluster.startMaster(workers);
    }
    startWorker() {
        this.cluster.startWorker();
    }
    /**
     * @returns {boolean}
     */
    get isMaster() {
        return this.cluster.isMaster;
    }
    /**
     * @param {object} visualization
     * @param {object[]} visualization.nodes
     * @param {string|number} visualization.nodes.id
     * @param {object[]} visualization.edges
     * @param {string|number} visualization.edges.source
     * @param {string|number} visualization.edges.target
     * @returns {Promise.<object>} The original graph object given as parameter, with layout applied.
     */
    layout(visualization) {
        const params = {
            nodes: _.map(visualization.nodes, node => {
                node = _.pick(node, ['id']);
                node.degree = _.reduce(visualization.edges, (degree, e) => degree + (e.source === node.id ? 1 : 0) + (e.target === node.id ? 1 : 0), 0);
                return node;
            }),
            edges: _.map(visualization.edges, edge => _.pick(edge, ['source', 'target'])),
            config: {
                randomize: 'globally',
                defaultSize: 10,
                scalingRatio: 25
            }
        };
        //console.log(JSON.stringify(params));
        return this.cluster.startJob('layout', params).then(nodes => {
            for (let i = 0, l = nodes.length; i < l; ++i) {
                visualization.nodes[i].nodelink.x = nodes[i].x;
                visualization.nodes[i].nodelink.y = nodes[i].y;
            }
        }).return(visualization);
    }
}
module.exports = new LayoutCluster();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvbGF5b3V0L2luZGV4LmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUU1QixXQUFXO0FBQ1gsTUFBTSxjQUFjLEdBQUcsT0FBTyxDQUFDLDhCQUE4QixDQUFDLENBQUM7QUFFL0QsV0FBVztBQUNYLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNoQyxNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3RDLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUUvQixNQUFNLGFBQWE7SUFDakI7UUFDRSxhQUFhO1FBQ2IsSUFBSSxTQUFTLENBQUM7UUFDZCxJQUFJO1lBQ0YsdUNBQXVDO1lBQ3ZDLFNBQVMsR0FBRyxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQztTQUN4QztRQUFDLE9BQU0sQ0FBQyxFQUFFO1lBQ1QsR0FBRyxDQUFDLElBQUksQ0FBQywwREFBMEQsQ0FBQyxDQUFDO1lBQ3JFLGtDQUFrQztZQUNsQyxTQUFTLEdBQUcsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDO1NBQ3BDO1FBRUQsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLGNBQWMsQ0FBQztZQUNoQyxJQUFJLGNBQWMsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRTtnQkFDbEUsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQ3RDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQztZQUNqQixDQUFDLENBQUM7U0FDSCxFQUFFO1lBQ0QsSUFBSSxFQUFFLE9BQU8sQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7WUFDbEMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7WUFDbEMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7U0FDckMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0gsWUFBWTtRQUNWLE1BQU0sT0FBTyxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDeEQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUVELFdBQVc7UUFDVCxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxDQUFDO0lBQzdCLENBQUM7SUFFRDs7T0FFRztJQUNILElBQUksUUFBUTtRQUNWLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUM7SUFDL0IsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsTUFBTSxDQUFDLGFBQWE7UUFDbEIsTUFBTSxNQUFNLEdBQUc7WUFDYixLQUFLLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxFQUFFO2dCQUN2QyxJQUFJLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUM1QixJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQ3BCLGFBQWEsQ0FBQyxLQUFLLEVBQ25CLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sS0FBSyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sS0FBSyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUN2RixDQUFDLENBQ0YsQ0FBQztnQkFDRixPQUFPLElBQUksQ0FBQztZQUNkLENBQUMsQ0FBQztZQUNGLEtBQUssRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDO1lBQzdFLE1BQU0sRUFBRTtnQkFDTixTQUFTLEVBQUUsVUFBVTtnQkFDckIsV0FBVyxFQUFFLEVBQUU7Z0JBQ2YsWUFBWSxFQUFFLEVBQUU7YUFDakI7U0FDRixDQUFDO1FBQ0Ysc0NBQXNDO1FBQ3RDLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUMxRCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFO2dCQUM1QyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDL0MsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDaEQ7UUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDM0IsQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxJQUFJLGFBQWEsRUFBRSxDQUFDIn0=