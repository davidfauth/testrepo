/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 */
'use strict';
const fs = require('fs-extra');
const Log4JS = require('../../../lib/log4js');
const LKE = require('../index');
const { LkError } = require('../../models/errors/LkError');
class LoggerService extends Log4JS {
    constructor() {
        // read logger configuration
        let config = {};
        try {
            config = fs.readJsonSync(LKE.dataFile('config/logger.json'));
        }
        catch (e) {
            console.log('Using default logger configuration');
            config = require('./logger.json');
        }
        super({
            projectRoot: LKE.systemFile(''),
            logDirPath: LKE.dataFile('logs'),
            logFileName: 'linkurious',
            logLevel: config.logLevel,
            customLevels: config.customLevels,
            addPrefix: config.addPrefix
        });
    }
    error() {
        const newArgs = [];
        for (let i = 0; i < arguments.length; ++i) {
            let arg = arguments[i];
            /**
             * for each argument that is an error with a stack,
             * we add the stack trace as a string array along
             * the error in the logged object
             */
            if (arg && arg instanceof LkError && !arg.isTechnical()) {
                // non technical LkError
                arg = arg.message;
            }
            else if (typeof arg === 'object' && arg instanceof Error && arg.stack) {
                // raw error or technical LkError
                // clone the error so we don't modify the original argument
                arg = {
                    key: arg instanceof LkError ? arg.key : 'critical',
                    message: arg.message,
                    trace: arg.stack.split(/\s*\n\s*/)
                };
                // remove the first line of the stack trace: it repeats the error name etc.
                if (arg.trace.length > 0) {
                    arg.trace = arg.trace.splice(1);
                }
            }
            newArgs.push(arg);
        }
        super.error.apply(this, newArgs);
    }
}
module.exports = new LoggerService();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvbG9nZ2VyL2luZGV4LmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7R0FHRztBQUNILFlBQVksQ0FBQztBQUNiLE1BQU0sRUFBRSxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUMvQixNQUFNLE1BQU0sR0FBRyxPQUFPLENBQUMscUJBQXFCLENBQUMsQ0FBQztBQUM5QyxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDaEMsTUFBTSxFQUFDLE9BQU8sRUFBQyxHQUFHLE9BQU8sQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO0FBRXpELE1BQU0sYUFBYyxTQUFRLE1BQU07SUFDaEM7UUFDRSw0QkFBNEI7UUFDNUIsSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFDO1FBQ2hCLElBQUk7WUFDRixNQUFNLEdBQUcsRUFBRSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQztTQUM5RDtRQUFDLE9BQU0sQ0FBQyxFQUFFO1lBQ1QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQ0FBb0MsQ0FBQyxDQUFDO1lBQ2xELE1BQU0sR0FBRyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUM7U0FDbkM7UUFFRCxLQUFLLENBQUM7WUFDSixXQUFXLEVBQUUsR0FBRyxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUM7WUFDL0IsVUFBVSxFQUFFLEdBQUcsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDO1lBQ2hDLFdBQVcsRUFBRSxZQUFZO1lBQ3pCLFFBQVEsRUFBRSxNQUFNLENBQUMsUUFBUTtZQUN6QixZQUFZLEVBQUUsTUFBTSxDQUFDLFlBQVk7WUFDakMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxTQUFTO1NBQzVCLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRCxLQUFLO1FBQ0gsTUFBTSxPQUFPLEdBQUcsRUFBRSxDQUFDO1FBQ25CLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxTQUFTLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQ3pDLElBQUksR0FBRyxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN2Qjs7OztlQUlHO1lBQ0gsSUFBSSxHQUFHLElBQUksR0FBRyxZQUFZLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsRUFBRTtnQkFDdkQsd0JBQXdCO2dCQUN4QixHQUFHLEdBQUcsR0FBRyxDQUFDLE9BQU8sQ0FBQzthQUNuQjtpQkFBTSxJQUFJLE9BQU8sR0FBRyxLQUFLLFFBQVEsSUFBSSxHQUFHLFlBQVksS0FBSyxJQUFJLEdBQUcsQ0FBQyxLQUFLLEVBQUU7Z0JBQ3ZFLGlDQUFpQztnQkFFakMsMkRBQTJEO2dCQUMzRCxHQUFHLEdBQUc7b0JBQ0osR0FBRyxFQUFFLEdBQUcsWUFBWSxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLFVBQVU7b0JBQ2xELE9BQU8sRUFBRSxHQUFHLENBQUMsT0FBTztvQkFDcEIsS0FBSyxFQUFFLEdBQUcsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQztpQkFDbkMsQ0FBQztnQkFDRiwyRUFBMkU7Z0JBQzNFLElBQUksR0FBRyxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO29CQUN4QixHQUFHLENBQUMsS0FBSyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUNqQzthQUNGO1lBQ0QsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUNuQjtRQUNELEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQztJQUNuQyxDQUFDO0NBRUY7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLElBQUksYUFBYSxFQUFFLENBQUMifQ==