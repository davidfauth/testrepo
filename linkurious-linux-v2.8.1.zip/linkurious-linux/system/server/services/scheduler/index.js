/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-05-18.
 */
'use strict';
const _ = require('lodash');
const Promise = require('bluebird');
const LKE = require('../index');
const Log = LKE.getLogger(__filename);
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
// We can't sleep for more than 24 days (setTimeout() use a 32 bit int to store the delay)
const MAX_MILLISEC_TIMEOUT = 7 * 24 * 60 * 60 * 1000; // A week
class Task {
    /**
     * @param {number}        id
     * @param {Bluebird<any>} promise
     * @param {string}        timeToSchedule Date of next run in ISO-8601 format
     * @param {string}        status         ("waiting", "running", "cancelled")
     */
    constructor(id, promise, timeToSchedule, status) {
        this.id = id;
        this.promise = promise;
        this.timeToSchedule = timeToSchedule;
        this.status = status;
    }
}
class SchedulerService {
    constructor() {
        /**
         * @type {Map<string, Semaphore>}
         */
        this._semaphores = new Map();
        /**
         * @type {Map<number, Task>}
         */
        this._tasks = new Map();
        this._nextId = 0;
    }
    /**
     * Set the concurrency for task group with name `groupName` to `maxGroupConcurrency`.
     * All the functions scheduled with this key will run accordingly to the group max concurrency.
     *
     * @param {string} groupName
     * @param {number} [maxGroupConcurrency] Concurrency limit
     *
     * @throws {LkError} if `groupName` is not valid
     */
    setGroupConcurrency(groupName, maxGroupConcurrency) {
        Utils.check.string('groupName', groupName, true);
        this._semaphores.set(groupName, maxGroupConcurrency ? Utils.semaphore(maxGroupConcurrency) : undefined);
    }
    /**
     * Cancel the execution of a given task by id.
     *
     * @param {number}  taskId
     * @returns {boolean} True, if cancelled
     */
    cancel(taskId) {
        const task = this._tasks.get(taskId);
        if (task) {
            if (task.status !== 'running') {
                Log.debug(`Scheduler: Task #${taskId} was cancelled (wasn't running).`);
                task.promise.cancel();
            }
            else {
                Log.debug(`Scheduler: Task #${taskId} was cancelled (interrupting running task).`);
                task.promise.cancel();
            }
            task.status = 'cancelled';
            return true;
        }
        return false;
    }
    /**
     * Get the date of the next execution of a given task by id.
     *
     * @param {number} taskId
     *
     * @returns {string} Date of next run in ISO-8601 format
     */
    getTimeToSchedule(taskId) {
        const task = this._tasks.get(taskId);
        if (task) {
            return task.timeToSchedule;
        }
        else if (taskId > 0 && taskId < this._nextId) {
            throw Errors.technical('invalid_parameter', 'This task is not available anymore (the task was deleted).');
        }
        throw Errors.technical('invalid_parameter', '"taskId" is not valid.');
    }
    /**
     * Get the promise of the next execution of a given task by id.
     * If the task was deleted, it will return a rejected promise.
     *
     * @param {number} taskId
     *
     * @returns {Bluebird<any>} Promise of the task fulfilment
     */
    getPromise(taskId) {
        const task = this._tasks.get(taskId);
        if (task) {
            return task.promise;
        }
        else if (taskId > 0 && taskId < this._nextId) {
            return Errors.technical('invalid_parameter', 'This task is not available anymore (the task was deleted).', true);
        }
        return Errors.technical('invalid_parameter', '"taskId" is not valid.', true);
    }
    /**
     * Get the status of a given task by id.
     * Possible status are: "waiting", "running", "cancelled", "unavailable".
     *
     * @param {number} taskId
     *
     * @returns {string | null} null (if invalid ID), "waiting", "running", "cancelled",
     *                               "unavailable"
     */
    getStatus(taskId) {
        const task = this._tasks.get(taskId);
        if (task) {
            return task.status;
        }
        else if (taskId > 0 && taskId < this._nextId) {
            return 'unavailable';
        }
        else {
            return null;
        }
    }
    /**
     * Return a resolved promise when Date.now() equals `epoch`.
     *
     * @param {number} epoch
     * @returns {Bluebird<any>}
     * @private
     */
    _delay(epoch) {
        const loop = () => {
            const millisToWait = epoch - Date.now();
            if (millisToWait <= 0) {
                // if epoch is minor or equal to Date.now() we resolve immediately
                return Promise.resolve();
            }
            const timeToWaitThisLoop = Math.min(millisToWait, MAX_MILLISEC_TIMEOUT);
            return Promise.delay(timeToWaitThisLoop).then(loop);
        };
        return loop();
    }
    /**
     * Look at scheduleTaskOnce.
     *
     * @param {function(): Bluebird<any>} f
     * @param {string} cronExpression    A CRON expression
     * @param {object} options
     * @param {Date}   [options.lastRun=new Date()] Date of the last run
     * @param {string} [options.group]   Group of this task (used for concurrency control)
     * @param {number} taskId            ID of the scheduled task
     * @private
     */
    _scheduleTaskOnce(f, cronExpression, options, taskId) {
        const semaphore = this._semaphores.get(options.group);
        try {
            const timeToSchedule = Utils.nextTimeToSchedule(cronExpression, options.lastRun);
            const promise = this._delay(timeToSchedule.getTime()).then(() => {
                if (semaphore) {
                    return semaphore.acquire();
                }
            }).then(() => {
                if (this.getStatus(taskId) === 'cancelled') {
                    return;
                }
                this._tasks.get(taskId).status = 'running';
                Log.debug(`Scheduler: Task #${taskId} is now running.`);
                return f().finally(() => {
                    Log.debug(`Scheduler: Task #${taskId} is no longer running.`);
                });
            }).catch(Promise.CancellationError, () => {
                // ignore cancellation rejections
            });
            promise.catch(err => {
                Log.error(`Scheduler: Task ${taskId} threw an error while running.`, err);
            }).finally(() => {
                if (semaphore) {
                    semaphore.release();
                }
            });
            this._tasks.set(taskId, new Task(taskId, promise, timeToSchedule.toISOString(), 'waiting'));
        }
        catch (e) {
            Log.error('We should never be here since we assumed that both cron and lastRun were valid', cronExpression, options.lastRun.toISOString());
        }
    }
    /**
     * @param {function(): Bluebird<any>} f
     * @param {string} cron            A CRON expression
     * @param {object} options
     * @param {Date}   [options.lastRun=new Date()] Date of the last run
     * @param {string} [options.group] Within a group the functions will run accordingly to the group max
     *                                 concurrency. If the function returns a promise, the semaphore will
     *                                 be released only after the returned promise is resolved.
     * @throws {LkError} if `f`, `cron`, `options.group` or `options.lastRun` are not valid.
     * @private
     */
    static _checkArgs(f, cron, options) {
        Utils.check.function('function', f);
        Utils.check.cronExpression('cron', cron);
        if (options.group) {
            Utils.check.string('group', options.group);
        }
        Utils.check.date('lastRun', options.lastRun);
    }
    /**
     * Schedule a task to run only once at the first time after a given date (lastRun) that match
     * the CRON expression.
     *
     * @param {function(): Bluebird<any>} f
     * @param {string} cronExpression  A CRON expression
     * @param {object} [options]
     * @param {Date}   [options.lastRun=new Date()] Date of the last run
     * @param {string} [options.group] Within a group the functions will run accordingly to the group max
     *                                 concurrency. If the function returns a promise, the semaphore will
     *                                 be released only after the returned promise is resolved.
     *
     * @returns {number} id
     * @throws {LkError} if `f`, `cron`, `options.group` or `options.lastRun` are not valid.
     */
    scheduleTaskOnce(f, cronExpression, options) {
        options = Utils.hasValue(options) ? _.cloneDeep(options) : {};
        if (Utils.noValue(options.lastRun)) {
            options.lastRun = new Date();
        }
        SchedulerService._checkArgs(f, cronExpression, options);
        const id = this._nextId++;
        this._scheduleTaskOnce(f, cronExpression, options, id);
        this.getPromise(id).catch(() => {
            // We have already logged the error on _scheduleTaskOnce
        }).finally(() => {
            this._tasks.delete(id);
        });
        return id;
    }
    /**
     * Schedule a task to run periodically according to a given CRON expression.
     * if options.lastRun is defined, it checks if it should have been executed between lastRun and
     * currentDate. If yes, it will also execute the function immediately.
     *
     * @param {function(): Bluebird<any>} f
     * @param {string}  cronExpression  A CRON expression
     * @param {object}  [options]
     * @param {Date}    [options.lastRun=new Date()] Date of the last run
     * @param {string}  [options.group] Within a group the functions will run accordingly to the group max
     *                                  concurrency. If the function returns a promise, the semaphore will
     *                                  be released only after the returned promise is resolved.
     * @param {boolean} [options.cancelOnError=false]
     *
     * @returns {number} id
     * @throws {LkError} if `f`, `cron`, `options.group` or `options.lastRun` are not valid.
     */
    scheduleTask(f, cronExpression, options) {
        options = Utils.hasValue(options) ? _.cloneDeep(options) : {};
        if (Utils.noValue(options.lastRun)) {
            options.lastRun = new Date();
        }
        SchedulerService._checkArgs(f, cronExpression, options);
        const id = this._nextId++;
        /**
         * @returns {Bluebird<any>}
         */
        const loop = () => {
            if (this.getStatus(id) === 'cancelled') {
                return Promise.resolve();
            }
            this._scheduleTaskOnce(f, cronExpression, options, id);
            if (options.lastRun) {
                options.lastRun = undefined;
            }
            return this.getPromise(id)
                .then(loop)
                .catch(() => {
                if (options.cancelOnError) {
                    return;
                }
                return loop();
            }).finally(() => {
                this._tasks.delete(id);
            });
        };
        loop();
        return id;
    }
}
module.exports = new SchedulerService();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvc2NoZWR1bGVyL2luZGV4LmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBQ2IsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNwQyxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDaEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUN0QyxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBRS9CLDBGQUEwRjtBQUMxRixNQUFNLG9CQUFvQixHQUFHLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUMsQ0FBQyxTQUFTO0FBRS9ELE1BQU0sSUFBSTtJQUNSOzs7OztPQUtHO0lBQ0gsWUFBWSxFQUFFLEVBQUUsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNO1FBQzdDLElBQUksQ0FBQyxFQUFFLEdBQUcsRUFBRSxDQUFDO1FBQ2IsSUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7UUFDdkIsSUFBSSxDQUFDLGNBQWMsR0FBRyxjQUFjLENBQUM7UUFDckMsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7SUFDdkIsQ0FBQztDQUNGO0FBRUQsTUFBTSxnQkFBZ0I7SUFFcEI7UUFDRTs7V0FFRztRQUNILElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQztRQUU3Qjs7V0FFRztRQUNILElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQztRQUV4QixJQUFJLENBQUMsT0FBTyxHQUFHLENBQUMsQ0FBQztJQUNuQixDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSCxtQkFBbUIsQ0FBQyxTQUFTLEVBQUUsbUJBQW1CO1FBQ2hELEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFFakQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQ2xCLFNBQVMsRUFDVCxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQ3ZFLENBQUM7SUFDSixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxNQUFNLENBQUMsTUFBTTtRQUNYLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3JDLElBQUksSUFBSSxFQUFFO1lBQ1IsSUFBSSxJQUFJLENBQUMsTUFBTSxLQUFLLFNBQVMsRUFBRTtnQkFDN0IsR0FBRyxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsTUFBTSxrQ0FBa0MsQ0FBQyxDQUFDO2dCQUN4RSxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDO2FBRXZCO2lCQUFNO2dCQUNMLEdBQUcsQ0FBQyxLQUFLLENBQUMsb0JBQW9CLE1BQU0sNkNBQTZDLENBQUMsQ0FBQztnQkFDbkYsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQzthQUN2QjtZQUVELElBQUksQ0FBQyxNQUFNLEdBQUcsV0FBVyxDQUFDO1lBRTFCLE9BQU8sSUFBSSxDQUFDO1NBQ2I7UUFDRCxPQUFPLEtBQUssQ0FBQztJQUNmLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxpQkFBaUIsQ0FBQyxNQUFNO1FBQ3RCLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3JDLElBQUksSUFBSSxFQUFFO1lBQ1IsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDO1NBQzVCO2FBQU0sSUFBSSxNQUFNLEdBQUcsQ0FBQyxJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsT0FBTyxFQUFFO1lBQzlDLE1BQU0sTUFBTSxDQUFDLFNBQVMsQ0FDcEIsbUJBQW1CLEVBQUUsNERBQTRELENBQUMsQ0FBQztTQUN0RjtRQUNELE1BQU0sTUFBTSxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsRUFBRSx3QkFBd0IsQ0FBQyxDQUFDO0lBQ3hFLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsVUFBVSxDQUFDLE1BQU07UUFDZixNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNyQyxJQUFJLElBQUksRUFBRTtZQUNSLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQztTQUNyQjthQUFNLElBQUksTUFBTSxHQUFHLENBQUMsSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUM5QyxPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQ3JCLG1CQUFtQixFQUFFLDREQUE0RCxFQUFFLElBQUksQ0FDeEYsQ0FBQztTQUNIO1FBQ0QsT0FBTyxNQUFNLENBQUMsU0FBUyxDQUFDLG1CQUFtQixFQUFFLHdCQUF3QixFQUFFLElBQUksQ0FBQyxDQUFDO0lBQy9FLENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILFNBQVMsQ0FBQyxNQUFNO1FBQ2QsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDckMsSUFBSSxJQUFJLEVBQUU7WUFDUixPQUFPLElBQUksQ0FBQyxNQUFNLENBQUM7U0FDcEI7YUFBTSxJQUFJLE1BQU0sR0FBRyxDQUFDLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDOUMsT0FBTyxhQUFhLENBQUM7U0FDdEI7YUFBTTtZQUNMLE9BQU8sSUFBSSxDQUFDO1NBQ2I7SUFDSCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsTUFBTSxDQUFDLEtBQUs7UUFDVixNQUFNLElBQUksR0FBRyxHQUFHLEVBQUU7WUFDaEIsTUFBTSxZQUFZLEdBQUcsS0FBSyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUV4QyxJQUFJLFlBQVksSUFBSSxDQUFDLEVBQUU7Z0JBQ3JCLGtFQUFrRTtnQkFDbEUsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7YUFDMUI7WUFFRCxNQUFNLGtCQUFrQixHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsWUFBWSxFQUFFLG9CQUFvQixDQUFDLENBQUM7WUFFeEUsT0FBTyxPQUFPLENBQUMsS0FBSyxDQUFDLGtCQUFrQixDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3RELENBQUMsQ0FBQztRQUVGLE9BQU8sSUFBSSxFQUFFLENBQUM7SUFDaEIsQ0FBQztJQUVEOzs7Ozs7Ozs7O09BVUc7SUFDSCxpQkFBaUIsQ0FBQyxDQUFDLEVBQUUsY0FBYyxFQUFFLE9BQU8sRUFBRSxNQUFNO1FBQ2xELE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUV0RCxJQUFJO1lBQ0YsTUFBTSxjQUFjLEdBQUcsS0FBSyxDQUFDLGtCQUFrQixDQUFDLGNBQWMsRUFBRSxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDakYsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUM5RCxJQUFJLFNBQVMsRUFBRTtvQkFDYixPQUFPLFNBQVMsQ0FBQyxPQUFPLEVBQUUsQ0FBQztpQkFDNUI7WUFDSCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNYLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsS0FBSyxXQUFXLEVBQUU7b0JBQzFDLE9BQU87aUJBQ1I7Z0JBRUQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxHQUFHLFNBQVMsQ0FBQztnQkFFM0MsR0FBRyxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsTUFBTSxrQkFBa0IsQ0FBQyxDQUFDO2dCQUN4RCxPQUFPLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUU7b0JBQ3RCLEdBQUcsQ0FBQyxLQUFLLENBQUMsb0JBQW9CLE1BQU0sd0JBQXdCLENBQUMsQ0FBQztnQkFDaEUsQ0FBQyxDQUFDLENBQUM7WUFFTCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGlCQUFpQixFQUFFLEdBQUcsRUFBRTtnQkFDdkMsaUNBQWlDO1lBQ25DLENBQUMsQ0FBQyxDQUFDO1lBRUgsT0FBTyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRTtnQkFDbEIsR0FBRyxDQUFDLEtBQUssQ0FBQyxtQkFBbUIsTUFBTSxnQ0FBZ0MsRUFBRSxHQUFHLENBQUMsQ0FBQztZQUM1RSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFO2dCQUNkLElBQUksU0FBUyxFQUFFO29CQUNiLFNBQVMsQ0FBQyxPQUFPLEVBQUUsQ0FBQztpQkFDckI7WUFDSCxDQUFDLENBQUMsQ0FBQztZQUVILElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFLGNBQWMsQ0FBQyxXQUFXLEVBQUUsRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDO1NBRTdGO1FBQUMsT0FBTSxDQUFDLEVBQUU7WUFDVCxHQUFHLENBQUMsS0FBSyxDQUFDLGdGQUFnRixFQUN4RixjQUFjLEVBQUUsT0FBTyxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDO1NBQ2xEO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7Ozs7O09BVUc7SUFDSCxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsT0FBTztRQUNoQyxLQUFLLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDcEMsS0FBSyxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBRXpDLElBQUksT0FBTyxDQUFDLEtBQUssRUFBRTtZQUNqQixLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQzVDO1FBRUQsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7Ozs7O09BY0c7SUFDSCxnQkFBZ0IsQ0FBQyxDQUFDLEVBQUUsY0FBYyxFQUFFLE9BQU87UUFDekMsT0FBTyxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUU5RCxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQ2xDLE9BQU8sQ0FBQyxPQUFPLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQztTQUM5QjtRQUVELGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxDQUFDLEVBQUUsY0FBYyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBRXhELE1BQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUMxQixJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxFQUFFLGNBQWMsRUFBRSxPQUFPLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFFdkQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFO1lBQzdCLHdEQUF3RDtRQUMxRCxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFO1lBQ2QsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDekIsQ0FBQyxDQUFDLENBQUM7UUFFSCxPQUFPLEVBQUUsQ0FBQztJQUNaLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7OztPQWdCRztJQUNILFlBQVksQ0FBQyxDQUFDLEVBQUUsY0FBYyxFQUFFLE9BQU87UUFDckMsT0FBTyxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUU5RCxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQ2xDLE9BQU8sQ0FBQyxPQUFPLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQztTQUM5QjtRQUVELGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxDQUFDLEVBQUUsY0FBYyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBRXhELE1BQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUUxQjs7V0FFRztRQUNILE1BQU0sSUFBSSxHQUFHLEdBQUcsRUFBRTtZQUNoQixJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLEtBQUssV0FBVyxFQUFFO2dCQUFFLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO2FBQUU7WUFFckUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUMsRUFBRSxjQUFjLEVBQUUsT0FBTyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1lBQ3ZELElBQUksT0FBTyxDQUFDLE9BQU8sRUFBRTtnQkFDbkIsT0FBTyxDQUFDLE9BQU8sR0FBRyxTQUFTLENBQUM7YUFDN0I7WUFFRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDO2lCQUN2QixJQUFJLENBQUMsSUFBSSxDQUFDO2lCQUNWLEtBQUssQ0FBQyxHQUFHLEVBQUU7Z0JBQ1YsSUFBSSxPQUFPLENBQUMsYUFBYSxFQUFFO29CQUFFLE9BQU87aUJBQUU7Z0JBQ3RDLE9BQU8sSUFBSSxFQUFFLENBQUM7WUFDaEIsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRTtnQkFDZCxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUN6QixDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQztRQUVGLElBQUksRUFBRSxDQUFDO1FBRVAsT0FBTyxFQUFFLENBQUM7SUFDWixDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLElBQUksZ0JBQWdCLEVBQUUsQ0FBQyJ9