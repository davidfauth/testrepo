/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-10-08.
 */
'use strict';
const path = require('path');
const fs = require('fs-extra');
const Promise = require('bluebird');
const _ = require('lodash');
const Sequelize = require('sequelize');
const SequelizeUpdater = require('./../../../lib/SequelizeUpdater');
const LKE = require('../index');
const Utils = LKE.getUtils();
const Log = LKE.getLogger(__filename);
const Errors = LKE.getErrors();
const Config = LKE.getConfig();
class SqlDbService {
    /**
     * @param {object} dbConfig SQL configuration
     * @param {string} dbConfig.name
     * @param {string} dbConfig.username
     * @param {string} dbConfig.password
     * @param {number} [dbConfig.connectionRetries=5]
     * @param {object} dbConfig.options
     * @param {string} dbConfig.options.dialect ("sqlite", "mariadb", "mysql")
     */
    constructor(dbConfig) {
        /**
         * @type {SqlDbModels}
         */
        this.models = {};
        this.connected = false;
        /** @type {Sequelize} */
        this.sequelize = undefined;
        this.dbName = dbConfig.name;
        this.dbUsername = dbConfig.username;
        this.dbPassword = dbConfig.password;
        this.connectionRetries = dbConfig.connectionRetries || 5;
        this.dbOptions = _.omitBy(dbConfig.options, optionValue => optionValue === null);
        // change to Log.info to log all SQL queries done by Sequelize
        this.dbOptions.logging = Log.debug;
    }
    /**
     * Adds all the containing .js files fo the directory to the Database model. It explores all the
     * subdirectories except fo the lib directory and skips index.js files.
     *
     * @param {string} directory containing the different models
     */
    _addModelsToDb(directory) {
        fs.readdirSync(directory).filter(file => {
            return (file.indexOf('.') !== 0) && file !== 'lib';
        }).forEach(file => {
            const filePath = path.resolve(directory, file);
            if (fs.statSync(filePath).isDirectory()) {
                this._addModelsToDb(filePath);
            }
            else {
                Log.debug('SQL : adding model "' + file + '"');
                const model = this.sequelize.import(filePath);
                this.models[model.name] = model;
            }
        });
    }
    /**
     * Synchronise the database state
     *
     * @returns {Promise}
     */
    sync() {
        return this.sequelize.sync();
    }
    /**
     * Close the database connection
     */
    close() {
        if (!this.sequelize) {
            return;
        }
        this.sequelize.close();
        // currently sequelize.close() does nothing for sqlite, see https://github.com/sequelize/sequelize/issues/6798
        if (this.dbOptions.dialect === 'sqlite' &&
            this.sequelize.connectionManager.connections &&
            this.sequelize.connectionManager.connections.default) {
            this.sequelize.connectionManager.connections.default.close();
        }
    }
    /**
     * Destroy all data in the database
     *
     * @returns {Bluebird<void>}
     */
    destroyAll() {
        return Promise.each(_.values(this.models), model => {
            return model.destroy({ where: {} });
        }).then(() => this.sync());
    }
    /**
     * Authenticate, Add models and Sync
     * Will retry 5 times with 1000ms delay if connection is refused for network reasons.
     *
     * @returns {Bluebird<Sequelize>}
     */
    _getAuthenticatedSequelize() {
        return Utils.retryPromise('Connecting to SQL DB', () => {
            const sequelize = new Sequelize(this.dbName, this.dbUsername, this.dbPassword, this.dbOptions);
            return sequelize.authenticate().then(() => sequelize);
        }, {
            delay: 1000,
            retries: this.connectionRetries,
            giveUp: e => (
            // SQLite can't "timeout"
            (this.dbOptions.dialect === 'sqlite') ||
                // credential errors should not be retried
                (e && e.name && e.name === 'SequelizeAccessDeniedError'))
        });
    }
    /**
     * @returns {Bluebird<void>}
     */
    connect() {
        // if the DB is already connected, resolve right away
        if (this.connected === true) {
            return Promise.resolve();
        }
        // else: authenticate, add models and sync state
        const isSqlite = this.dbOptions.dialect === 'sqlite';
        if (isSqlite) {
            // database file: build its absolute path and make sure it exists (creates the needed dirs)
            this.dbOptions.storage = LKE.dataFile(this.dbOptions.storage);
            fs.ensureFileSync(this.dbOptions.storage);
        }
        // 1) connect to DB
        return this._getAuthenticatedSequelize().then(sequelize => {
            this.sequelize = sequelize;
            LKE.getStateMachine().set('SqlDB', 'up');
        }).catch(error => {
            return Errors.technical('critical', 'SQL connection error: ' + error, true);
        }).then(() => {
            // 2) migrate the schema if necessary
            const schemaUpdater = new SequelizeUpdater(this.dbName, // same options as sqlDb.sequelize
            this.dbUsername, this.dbPassword, this.dbOptions, 'lk_version');
            return schemaUpdater.run(fs.readJsonSync(path.resolve(__dirname, 'databaseUpdates.json')), LKE.getVersion());
        }).then(appliedUpdates => {
            if (appliedUpdates.length > 0) {
                Log.info(`Applied ${appliedUpdates.length} database update` +
                    `${appliedUpdates.length > 1 ? 's' : ''} to version ${LKE.getVersion()}.`);
            }
            // 3) load models and associations
            this._addModelsToDb(path.resolve(__dirname, 'models'));
            this._addModelsToDb(path.resolve(__dirname, '../../models/sql'));
            _.forEach(this.models, model => {
                if ('associate' in model) {
                    model.associate(this.models);
                }
            });
            // 4) sync models (create tables etc.)
            return this.sequelize.sync().then(() => {
                // 4.1) create initial values for each model
                return Promise.each(_.values(this.models), model => {
                    if (!model.initialValues) {
                        return;
                    }
                    return model.initialValues();
                });
            });
        }).then(() => {
            // 5) enable write-ahead-log for sqlite
            if (!isSqlite) {
                return;
            }
            // SQLITE: turn on Write-Ahead-Log optimization (https://www.sqlite.org/wal.html)
            const pragmaList = ['busy_timeout = 5000', 'journal_mode = WAL', 'synchronous = NORMAL'];
            return Promise.each(pragmaList, pragma => this.sequelize.query('PRAGMA ' + pragma));
        }).catch(err => {
            LKE.getStateMachine().set('SqlDB', 'sync_error');
            Log.error('SQL Sync error', err);
            return Errors.technical('critical', 'SQL synchronisation failure' + err, true);
        }).then(() => {
            // 6) set connected+synced state
            this.connected = true;
            LKE.getStateMachine().set('SqlDB', 'synced');
        }).catch(error => {
            LKE.getStateMachine().set('SqlDB', 'down');
            return Promise.reject(error);
        });
    }
}
module.exports = new SqlDbService(Config.get('db'));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvc3FsRGIvaW5kZXguanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFDYixNQUFNLElBQUksR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDN0IsTUFBTSxFQUFFLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQy9CLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNwQyxNQUFNLENBQUMsR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDNUIsTUFBTSxTQUFTLEdBQUcsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQ3ZDLE1BQU0sZ0JBQWdCLEdBQUcsT0FBTyxDQUFDLGlDQUFpQyxDQUFDLENBQUM7QUFDcEUsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ2hDLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3RDLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFFL0IsTUFBTSxZQUFZO0lBRWhCOzs7Ozs7OztPQVFHO0lBQ0gsWUFBWSxRQUFRO1FBRWxCOztXQUVHO1FBQ0gsSUFBSSxDQUFDLE1BQU0sR0FBRyxFQUFFLENBQUM7UUFFakIsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7UUFDdkIsd0JBQXdCO1FBQ3hCLElBQUksQ0FBQyxTQUFTLEdBQUcsU0FBUyxDQUFDO1FBRTNCLElBQUksQ0FBQyxNQUFNLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQztRQUM1QixJQUFJLENBQUMsVUFBVSxHQUFHLFFBQVEsQ0FBQyxRQUFRLENBQUM7UUFDcEMsSUFBSSxDQUFDLFVBQVUsR0FBRyxRQUFRLENBQUMsUUFBUSxDQUFDO1FBQ3BDLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxRQUFRLENBQUMsaUJBQWlCLElBQUksQ0FBQyxDQUFDO1FBRXpELElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLFdBQVcsQ0FBQyxFQUFFLENBQUMsV0FBVyxLQUFLLElBQUksQ0FBQyxDQUFDO1FBQ2pGLDhEQUE4RDtRQUM5RCxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDO0lBQ3JDLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILGNBQWMsQ0FBQyxTQUFTO1FBQ3RCLEVBQUUsQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ3RDLE9BQU8sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLElBQUksS0FBSyxLQUFLLENBQUM7UUFDckQsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ2hCLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO1lBRS9DLElBQUksRUFBRSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxXQUFXLEVBQUUsRUFBRTtnQkFDdkMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQzthQUMvQjtpQkFBTTtnQkFDTCxHQUFHLENBQUMsS0FBSyxDQUFDLHNCQUFzQixHQUFHLElBQUksR0FBRyxHQUFHLENBQUMsQ0FBQztnQkFDL0MsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQzlDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLEtBQUssQ0FBQzthQUNqQztRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxJQUFJO1FBQ0YsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxDQUFDO0lBQy9CLENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUs7UUFDSCxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUFFLE9BQU87U0FBRTtRQUVoQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxDQUFDO1FBRXZCLDhHQUE4RztRQUM5RyxJQUNFLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxLQUFLLFFBQVE7WUFDbkMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxpQkFBaUIsQ0FBQyxXQUFXO1lBQzVDLElBQUksQ0FBQyxTQUFTLENBQUMsaUJBQWlCLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFDcEQ7WUFDQSxJQUFJLENBQUMsU0FBUyxDQUFDLGlCQUFpQixDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7U0FDOUQ7SUFDSCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILFVBQVU7UUFDUixPQUFPLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsS0FBSyxDQUFDLEVBQUU7WUFDakQsT0FBTyxLQUFLLENBQUMsT0FBTyxDQUFDLEVBQUMsS0FBSyxFQUFFLEVBQUUsRUFBQyxDQUFDLENBQUM7UUFDcEMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDO0lBQzdCLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILDBCQUEwQjtRQUN4QixPQUFPLEtBQUssQ0FBQyxZQUFZLENBQ3ZCLHNCQUFzQixFQUN0QixHQUFHLEVBQUU7WUFDSCxNQUFNLFNBQVMsR0FBRyxJQUFJLFNBQVMsQ0FDN0IsSUFBSSxDQUFDLE1BQU0sRUFDWCxJQUFJLENBQUMsVUFBVSxFQUNmLElBQUksQ0FBQyxVQUFVLEVBQ2YsSUFBSSxDQUFDLFNBQVMsQ0FDZixDQUFDO1lBQ0YsT0FBTyxTQUFTLENBQUMsWUFBWSxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ3hELENBQUMsRUFDRDtZQUNFLEtBQUssRUFBRSxJQUFJO1lBQ1gsT0FBTyxFQUFFLElBQUksQ0FBQyxpQkFBaUI7WUFDL0IsTUFBTSxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUM7WUFDWCx5QkFBeUI7WUFDekIsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sS0FBSyxRQUFRLENBQUM7Z0JBRXJDLDBDQUEwQztnQkFDMUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLENBQUMsSUFBSSxLQUFLLDRCQUE0QixDQUFDLENBQ3pEO1NBQ0YsQ0FDRixDQUFDO0lBQ0osQ0FBQztJQUVEOztPQUVHO0lBQ0gsT0FBTztRQUNMLHFEQUFxRDtRQUNyRCxJQUFJLElBQUksQ0FBQyxTQUFTLEtBQUssSUFBSSxFQUFFO1lBQzNCLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO1NBQzFCO1FBRUQsZ0RBQWdEO1FBQ2hELE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxLQUFLLFFBQVEsQ0FBQztRQUNyRCxJQUFJLFFBQVEsRUFBRTtZQUNaLDJGQUEyRjtZQUMzRixJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sR0FBRyxHQUFHLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDOUQsRUFBRSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1NBQzNDO1FBRUQsbUJBQW1CO1FBQ25CLE9BQU8sSUFBSSxDQUFDLDBCQUEwQixFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQ3hELElBQUksQ0FBQyxTQUFTLEdBQUcsU0FBUyxDQUFDO1lBRTNCLEdBQUcsQ0FBQyxlQUFlLEVBQUUsQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzNDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUNmLE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUUsd0JBQXdCLEdBQUcsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzlFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFFWCxxQ0FBcUM7WUFDckMsTUFBTSxhQUFhLEdBQUcsSUFBSSxnQkFBZ0IsQ0FDeEMsSUFBSSxDQUFDLE1BQU0sRUFBRSxrQ0FBa0M7WUFDL0MsSUFBSSxDQUFDLFVBQVUsRUFDZixJQUFJLENBQUMsVUFBVSxFQUNmLElBQUksQ0FBQyxTQUFTLEVBQ2QsWUFBWSxDQUNiLENBQUM7WUFDRixPQUFPLGFBQWEsQ0FBQyxHQUFHLENBQ3RCLEVBQUUsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsc0JBQXNCLENBQUMsQ0FBQyxFQUNoRSxHQUFHLENBQUMsVUFBVSxFQUFFLENBQ2pCLENBQUM7UUFDSixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLEVBQUU7WUFDdkIsSUFBSSxjQUFjLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtnQkFDN0IsR0FBRyxDQUFDLElBQUksQ0FDTixXQUFXLGNBQWMsQ0FBQyxNQUFNLGtCQUFrQjtvQkFDbEQsR0FBRyxjQUFjLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLGVBQWUsR0FBRyxDQUFDLFVBQVUsRUFBRSxHQUFHLENBQzFFLENBQUM7YUFDSDtZQUVELGtDQUFrQztZQUNsQyxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUM7WUFDdkQsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxrQkFBa0IsQ0FBQyxDQUFDLENBQUM7WUFDakUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxFQUFFO2dCQUM3QixJQUFJLFdBQVcsSUFBSSxLQUFLLEVBQUU7b0JBQ3hCLEtBQUssQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2lCQUM5QjtZQUNILENBQUMsQ0FBQyxDQUFDO1lBQ0gsc0NBQXNDO1lBQ3RDLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNyQyw0Q0FBNEM7Z0JBQzVDLE9BQU8sT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxLQUFLLENBQUMsRUFBRTtvQkFDakQsSUFBSSxDQUFDLEtBQUssQ0FBQyxhQUFhLEVBQUU7d0JBQUUsT0FBTztxQkFBRTtvQkFDckMsT0FBTyxLQUFLLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQy9CLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1gsdUNBQXVDO1lBQ3ZDLElBQUksQ0FBQyxRQUFRLEVBQUU7Z0JBQUUsT0FBTzthQUFFO1lBQzFCLGlGQUFpRjtZQUNqRixNQUFNLFVBQVUsR0FBRyxDQUFDLHFCQUFxQixFQUFFLG9CQUFvQixFQUFFLHNCQUFzQixDQUFDLENBQUM7WUFDekYsT0FBTyxPQUFPLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxNQUFNLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLFNBQVMsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBRXRGLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUNiLEdBQUcsQ0FBQyxlQUFlLEVBQUUsQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFLFlBQVksQ0FBQyxDQUFDO1lBQ2pELEdBQUcsQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLEVBQUUsR0FBRyxDQUFDLENBQUM7WUFDakMsT0FBTyxNQUFNLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSw2QkFBNkIsR0FBRyxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDakYsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNYLGdDQUFnQztZQUNoQyxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztZQUN0QixHQUFHLENBQUMsZUFBZSxFQUFFLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxRQUFRLENBQUMsQ0FBQztRQUMvQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDZixHQUFHLENBQUMsZUFBZSxFQUFFLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsQ0FBQztZQUMzQyxPQUFPLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDL0IsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLElBQUksWUFBWSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyJ9