/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-05-11.
 */
'use strict';
const _ = require('lodash');
const DBFields = require('../../../lib/DBFields');
const PUBLIC_FIELDS = ['id', 'title', 'sourceKey', 'query',
    'dialect', 'enabled', 'columns', 'cron', 'matchTTL',
    'lastRun', 'lastRunProblem', 'maxMatches',
    'userId', 'createdAt', 'updatedAt', 'folder'
];
/**
 * Alert
 *
 * @property {number}   id                     Id of the alert (added by sequelize)
 * @property {string}   title                  Title of the alert
 * @property {string}   sourceKey              Key of the data-source containing the nodes and edges
 * @property {string}   query                  The query that will periodically run
 * @property {string}   dialect                The dialect of the query
 * @property {boolean}  enabled                Boolean that indicates if the query will run periodically or not
 * @property {object[]} [columns]              Columns among the returned values of the query to save in a match as scalar values
 * @property {string}   columns.type           Type of the column ("number", "string")
 * @property {string}   columns.columnName     Name of the column
 * @property {string}   cron                   CRON expression representing the frequency with which the query runs
 * @property {number}   matchTTL               Time (in days) after which the matches of this alert are going to be deleted
 * @property {number}   userId                 ID of the user that created the alert
 * @property {string}   lastRun                Last time the query was executed
 * @property {{error?:  string, partial?: boolean} | undefined} lastRunProblem
 * @property {string}   lastRunProblem.error   Error that identifies the last run problem
 * @property {boolean}  lastRunProblem.partial Boolean that represents if the last run was at least partially executed
 * @property {number}   maxMatches             Maximum number of matches after which new matches are discarded
 * @property {string}   createdAt              Creation date (added by sequelize)
 * @property {string}   updatedAt              Update date (added by sequelize)
 * @property {string}   nextRun                Date of the future scheduled run (added by the alert service)
 */
module.exports = function (sequelize, DataTypes) {
    const alert = sequelize.define('alert', {
        title: {
            allowNull: false,
            type: DataTypes.STRING(200)
        },
        sourceKey: {
            allowNull: false,
            type: DataTypes.STRING(8)
        },
        query: {
            allowNull: false,
            type: DataTypes.TEXT
        },
        dialect: {
            allowNull: false,
            type: DataTypes.STRING(20)
        },
        enabled: {
            allowNull: false,
            type: DataTypes.BOOLEAN
        },
        columns: DBFields.generateJsonField('columns'),
        cron: {
            allowNull: false,
            type: DataTypes.STRING(50)
        },
        // time to live of a match (in days)
        matchTTL: {
            allowNull: false,
            type: DataTypes.INTEGER
        },
        // @backward-compatibility scoreColumn field was deprecated by allowing more columns
        scoreColumn: {
            allowNull: true,
            type: DataTypes.STRING(200)
        },
        // @backward-compatibility sortDirection field was deprecated by allowing more columns
        sortDirection: {
            allowNull: false,
            type: DataTypes.STRING(20),
            defaultValue: '' // null is not allowed, so we leave a default value
        },
        lastRun: DBFields.generateIntegerDateField('lastRun', true),
        lastRunProblem: DBFields.generateJsonField('lastRunProblem'),
        maxMatches: {
            allowNull: false,
            type: DataTypes.INTEGER
        },
        // @backward-compatibility maxRuntime field was deprecated, global alerts.maxRuntimeLimit is used
        maxRuntime: {
            allowNull: false,
            type: DataTypes.INTEGER,
            defaultValue: 0 // null is not allowed, so we leave a default value
        }
    }, {
        charset: 'utf8',
        classMethods: {
            associate: models => {
                models.alert.hasMany(models.match, { foreignKey: 'alertId', onDelete: 'cascade' });
                models.alert.belongsTo(models.user, { foreignKey: 'userId' });
                // no constrains: -1 is legal for root folder
                models.alert.belongsTo(models.alertFolder, {
                    foreignKey: 'folder', constraints: false
                });
            },
            instanceToPublicAttributes: instanceToPublicAttributes
        }
    });
    return alert;
};
/**
 * @param {AlertInstance} alertInstance
 * @returns {PublicAlert}
 */
function instanceToPublicAttributes(alertInstance) {
    return /**@type {PublicAlert}*/ (_.pick(alertInstance, PUBLIC_FIELDS));
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQWxlcnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvc3FsRGIvbW9kZWxzL0FsZXJ0LmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBQ2IsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVCLE1BQU0sUUFBUSxHQUFHLE9BQU8sQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO0FBRWxELE1BQU0sYUFBYSxHQUFHLENBQUMsSUFBSSxFQUFFLE9BQU8sRUFBRSxXQUFXLEVBQUUsT0FBTztJQUN4RCxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsVUFBVTtJQUNuRCxTQUFTLEVBQUUsZ0JBQWdCLEVBQUUsWUFBWTtJQUN6QyxRQUFRLEVBQUUsV0FBVyxFQUFFLFdBQVcsRUFBRSxRQUFRO0NBQzdDLENBQUM7QUFFRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0F1Qkc7QUFFSCxNQUFNLENBQUMsT0FBTyxHQUFHLFVBQVMsU0FBUyxFQUFFLFNBQVM7SUFFNUMsTUFBTSxLQUFLLEdBQUcsU0FBUyxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7UUFDdEMsS0FBSyxFQUFFO1lBQ0wsU0FBUyxFQUFFLEtBQUs7WUFDaEIsSUFBSSxFQUFFLFNBQVMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO1NBQzVCO1FBQ0QsU0FBUyxFQUFFO1lBQ1QsU0FBUyxFQUFFLEtBQUs7WUFDaEIsSUFBSSxFQUFFLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1NBQzFCO1FBQ0QsS0FBSyxFQUFFO1lBQ0wsU0FBUyxFQUFFLEtBQUs7WUFDaEIsSUFBSSxFQUFFLFNBQVMsQ0FBQyxJQUFJO1NBQ3JCO1FBQ0QsT0FBTyxFQUFFO1lBQ1AsU0FBUyxFQUFFLEtBQUs7WUFDaEIsSUFBSSxFQUFFLFNBQVMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1NBQzNCO1FBQ0QsT0FBTyxFQUFFO1lBQ1AsU0FBUyxFQUFFLEtBQUs7WUFDaEIsSUFBSSxFQUFFLFNBQVMsQ0FBQyxPQUFPO1NBQ3hCO1FBQ0QsT0FBTyxFQUFFLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLENBQUM7UUFDOUMsSUFBSSxFQUFFO1lBQ0osU0FBUyxFQUFFLEtBQUs7WUFDaEIsSUFBSSxFQUFFLFNBQVMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1NBQzNCO1FBQ0Qsb0NBQW9DO1FBQ3BDLFFBQVEsRUFBRTtZQUNSLFNBQVMsRUFBRSxLQUFLO1lBQ2hCLElBQUksRUFBRSxTQUFTLENBQUMsT0FBTztTQUN4QjtRQUNELG9GQUFvRjtRQUNwRixXQUFXLEVBQUU7WUFDWCxTQUFTLEVBQUUsSUFBSTtZQUNmLElBQUksRUFBRSxTQUFTLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztTQUM1QjtRQUNELHNGQUFzRjtRQUN0RixhQUFhLEVBQUU7WUFDYixTQUFTLEVBQUUsS0FBSztZQUNoQixJQUFJLEVBQUUsU0FBUyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7WUFDMUIsWUFBWSxFQUFFLEVBQUUsQ0FBQyxtREFBbUQ7U0FDckU7UUFDRCxPQUFPLEVBQUUsUUFBUSxDQUFDLHdCQUF3QixDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUM7UUFDM0QsY0FBYyxFQUFFLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxnQkFBZ0IsQ0FBQztRQUM1RCxVQUFVLEVBQUU7WUFDVixTQUFTLEVBQUUsS0FBSztZQUNoQixJQUFJLEVBQUUsU0FBUyxDQUFDLE9BQU87U0FDeEI7UUFDRCxpR0FBaUc7UUFDakcsVUFBVSxFQUFFO1lBQ1YsU0FBUyxFQUFFLEtBQUs7WUFDaEIsSUFBSSxFQUFFLFNBQVMsQ0FBQyxPQUFPO1lBQ3ZCLFlBQVksRUFBRSxDQUFDLENBQUMsbURBQW1EO1NBQ3BFO0tBQ0YsRUFBRTtRQUNELE9BQU8sRUFBRSxNQUFNO1FBQ2YsWUFBWSxFQUFFO1lBQ1osU0FBUyxFQUFFLE1BQU0sQ0FBQyxFQUFFO2dCQUNsQixNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLEVBQUMsVUFBVSxFQUFFLFNBQVMsRUFBRSxRQUFRLEVBQUUsU0FBUyxFQUFDLENBQUMsQ0FBQztnQkFDakYsTUFBTSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxFQUFDLFVBQVUsRUFBRSxRQUFRLEVBQUMsQ0FBQyxDQUFDO2dCQUM1RCw2Q0FBNkM7Z0JBQzdDLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUU7b0JBQ3pDLFVBQVUsRUFBRSxRQUFRLEVBQUUsV0FBVyxFQUFFLEtBQUs7aUJBQ3pDLENBQUMsQ0FBQztZQUNMLENBQUM7WUFDRCwwQkFBMEIsRUFBRSwwQkFBMEI7U0FDdkQ7S0FDRixDQUFDLENBQUM7SUFFSCxPQUFPLEtBQUssQ0FBQztBQUNmLENBQUMsQ0FBQztBQUVGOzs7R0FHRztBQUNILFNBQVMsMEJBQTBCLENBQUMsYUFBYTtJQUMvQyxPQUFPLHdCQUF3QixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUUsYUFBYSxDQUFDLENBQUMsQ0FBQztBQUN6RSxDQUFDIn0=