/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-11-02.
 */
'use strict';
const _ = require('lodash');
const DBFields = require('../../../lib/DBFields');
const PUBLIC_FIELDS = [
    'id', 'enabled', 'apiKey', 'name', 'rights', 'createdAt', 'updatedAt'
];
const APP_ACTIONS = [
    // visualization actions
    'visualization.read',
    'visualization.create',
    'visualization.edit',
    'visualization.delete',
    'visualization.list',
    // visualization folder actions
    'visualizationFolder.create',
    'visualizationFolder.edit',
    'visualizationFolder.delete',
    // visualization share actions
    'visualizationShare.read',
    'visualizationShare.create',
    'visualizationShare.delete',
    // search action
    'sandbox',
    // widget actions
    'widget.read',
    'widget.create',
    'widget.edit',
    'widget.delete',
    // graph item actions
    'graphItem.read',
    'graphItem.create',
    'graphItem.edit',
    'graphItem.delete',
    // search action
    'graphItem.search',
    // saved graph query actions
    'savedGraphQuery.read',
    'savedGraphQuery.create',
    'savedGraphQuery.edit',
    'savedGraphQuery.delete',
    // graph query actions
    'graph.rawRead',
    'graph.rawWrite',
    'graph.runQuery',
    // alert actions
    'alert.read',
    'alert.doAction',
    'admin.alerts',
    // schema action
    'schema',
    // reindex action
    'admin.index'
];
module.exports = function (sequelize, DataTypes) {
    const application = sequelize.define('application', {
        // application name
        name: {
            type: DataTypes.STRING(),
            allowNull: false
        },
        // whether this app is allowed to authenticate
        enabled: {
            type: DataTypes.BOOLEAN(),
            allowNull: false
        },
        // access token to authenticate the application
        apiKey: {
            type: DataTypes.STRING(40),
            allowNull: false
        },
        // array of allowed APP_ACTIONS
        rights: DBFields.generateJsonField('rights', [], false, sequelize.options.dialect)
    }, {
        charset: 'utf8',
        classMethods: {
            associate: models => {
                application.belongsToMany(models.group, { through: 'applicationGroups' });
            },
            instanceToPublicAttributes: instanceToPublicAttributes
        }
    });
    application.APP_ACTIONS = APP_ACTIONS;
    application.PUBLIC_FIELDS = PUBLIC_FIELDS;
    return application;
};
/**
 * @param {ApplicationInstance} applicationInstance
 * @returns {PublicApplication}
 */
function instanceToPublicAttributes(applicationInstance) {
    return /**@type {PublicApplication}*/ (_.pick(applicationInstance, PUBLIC_FIELDS));
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQXBwbGljYXRpb24uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvc3FsRGIvbW9kZWxzL0FwcGxpY2F0aW9uLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBQ2IsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVCLE1BQU0sUUFBUSxHQUFHLE9BQU8sQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO0FBRWxELE1BQU0sYUFBYSxHQUFHO0lBQ3BCLElBQUksRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxRQUFRLEVBQUUsV0FBVyxFQUFFLFdBQVc7Q0FDdEUsQ0FBQztBQUVGLE1BQU0sV0FBVyxHQUFHO0lBQ2xCLHdCQUF3QjtJQUN4QixvQkFBb0I7SUFDcEIsc0JBQXNCO0lBQ3RCLG9CQUFvQjtJQUNwQixzQkFBc0I7SUFDdEIsb0JBQW9CO0lBRXBCLCtCQUErQjtJQUMvQiw0QkFBNEI7SUFDNUIsMEJBQTBCO0lBQzFCLDRCQUE0QjtJQUU1Qiw4QkFBOEI7SUFDOUIseUJBQXlCO0lBQ3pCLDJCQUEyQjtJQUMzQiwyQkFBMkI7SUFFM0IsZ0JBQWdCO0lBQ2hCLFNBQVM7SUFFVCxpQkFBaUI7SUFDakIsYUFBYTtJQUNiLGVBQWU7SUFDZixhQUFhO0lBQ2IsZUFBZTtJQUVmLHFCQUFxQjtJQUNyQixnQkFBZ0I7SUFDaEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixrQkFBa0I7SUFFbEIsZ0JBQWdCO0lBQ2hCLGtCQUFrQjtJQUVsQiw0QkFBNEI7SUFDNUIsc0JBQXNCO0lBQ3RCLHdCQUF3QjtJQUN4QixzQkFBc0I7SUFDdEIsd0JBQXdCO0lBRXhCLHNCQUFzQjtJQUN0QixlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLGdCQUFnQjtJQUVoQixnQkFBZ0I7SUFDaEIsWUFBWTtJQUNaLGdCQUFnQjtJQUNoQixjQUFjO0lBRWQsZ0JBQWdCO0lBQ2hCLFFBQVE7SUFFUixpQkFBaUI7SUFDakIsYUFBYTtDQUNkLENBQUM7QUFFRixNQUFNLENBQUMsT0FBTyxHQUFHLFVBQVMsU0FBUyxFQUFFLFNBQVM7SUFFNUMsTUFBTSxXQUFXLEdBQUcsU0FBUyxDQUFDLE1BQU0sQ0FBQyxhQUFhLEVBQUU7UUFDbEQsbUJBQW1CO1FBQ25CLElBQUksRUFBRTtZQUNKLElBQUksRUFBRSxTQUFTLENBQUMsTUFBTSxFQUFFO1lBQ3hCLFNBQVMsRUFBRSxLQUFLO1NBQ2pCO1FBQ0QsOENBQThDO1FBQzlDLE9BQU8sRUFBRTtZQUNQLElBQUksRUFBRSxTQUFTLENBQUMsT0FBTyxFQUFFO1lBQ3pCLFNBQVMsRUFBRSxLQUFLO1NBQ2pCO1FBQ0QsK0NBQStDO1FBQy9DLE1BQU0sRUFBRTtZQUNOLElBQUksRUFBRSxTQUFTLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztZQUMxQixTQUFTLEVBQUUsS0FBSztTQUNqQjtRQUNELCtCQUErQjtRQUMvQixNQUFNLEVBQUUsUUFBUSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLFNBQVMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDO0tBQ25GLEVBQUU7UUFDRCxPQUFPLEVBQUUsTUFBTTtRQUNmLFlBQVksRUFBRTtZQUNaLFNBQVMsRUFBRSxNQUFNLENBQUMsRUFBRTtnQkFDbEIsV0FBVyxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLEVBQUMsT0FBTyxFQUFFLG1CQUFtQixFQUFDLENBQUMsQ0FBQztZQUMxRSxDQUFDO1lBQ0QsMEJBQTBCLEVBQUUsMEJBQTBCO1NBQ3ZEO0tBQ0YsQ0FBQyxDQUFDO0lBRUgsV0FBVyxDQUFDLFdBQVcsR0FBRyxXQUFXLENBQUM7SUFDdEMsV0FBVyxDQUFDLGFBQWEsR0FBRyxhQUFhLENBQUM7SUFFMUMsT0FBTyxXQUFXLENBQUM7QUFDckIsQ0FBQyxDQUFDO0FBRUY7OztHQUdHO0FBQ0gsU0FBUywwQkFBMEIsQ0FBQyxtQkFBbUI7SUFDckQsT0FBTyw4QkFBOEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLEVBQUUsYUFBYSxDQUFDLENBQUMsQ0FBQztBQUNyRixDQUFDIn0=