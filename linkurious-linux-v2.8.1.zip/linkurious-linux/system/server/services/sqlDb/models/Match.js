/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-05-18.
 */
'use strict';
const _ = require('lodash');
const LKE = require('../../index');
const Utils = LKE.getUtils();
const DBFields = require('../../../lib/DBFields');
const PUBLIC_FIELDS = ['id', 'sourceKey', 'alertId', 'hash',
    'status', 'expirationDate', 'nodes', 'edges', 'createdAt', 'updatedAt']; // 'columns' as well as virtual field
/**
 * Match
 *
 * @property {number}                 id             Id of the match (added by sequelize)
 * @property {string}                 sourceKey      Key of the data-source that contains this match (copied from its alert)
 * @property {number}                 alertId        Alert that created the match
 * @property {string}                 hash           Hash used to remove duplicate matches
 * @property {string}                 status         Status of the match according to the action that were performed on it
 * @property {object}                 user           User that changed the status last
 * @property {object[]}               viewers        Users that viewed the match
 * @property {string}                 expirationDate Date when the match is going to be deleted
 * @property {string[]}               nodes          IDs of the nodes of the match encoded as a JSON
 * @property {string[]}               edges          IDs of the edges of the match encoded as a JSON
 * @property {Array<string | number>} columns        Scalar value for a given column by index defined in the alert
 * @property {number}                 version        Version of the match (a match is updated lazily on retrieval to the latest version)
 * @property {string}                 createdAt      Creation date (added by sequelize)
 * @property {string}                 updatedAt      Update date (added by sequelize)
 */
module.exports = function (sequelize, DataTypes) {
    const STATUS_VALUES = ['unconfirmed', 'confirmed', 'dismissed'];
    const match = sequelize.define('match', {
        sourceKey: {
            allowNull: false,
            type: DataTypes.STRING(8)
        },
        hash: {
            allowNull: false,
            type: DataTypes.STRING(200),
            unique: true
        },
        // @backward-compatibility score field was deprecated by allowing more columns
        score: {
            allowNull: true,
            type: DataTypes.INTEGER
        },
        status: {
            allowNull: false,
            type: DataTypes.STRING(20)
        },
        expirationDate: DBFields.generateIntegerDateField('expirationDate', false),
        nodes: DBFields.generateJsonField('nodes'),
        edges: DBFields.generateJsonField('edges'),
        columnString0: {
            allowNull: true,
            type: DataTypes.STRING
        },
        columnNumber0: {
            allowNull: true,
            type: DataTypes.DOUBLE
        },
        columnString1: {
            allowNull: true,
            type: DataTypes.STRING
        },
        columnNumber1: {
            allowNull: true,
            type: DataTypes.DOUBLE
        },
        columnString2: {
            allowNull: true,
            type: DataTypes.STRING
        },
        columnNumber2: {
            allowNull: true,
            type: DataTypes.DOUBLE
        },
        columnString3: {
            allowNull: true,
            type: DataTypes.STRING
        },
        columnNumber3: {
            allowNull: true,
            type: DataTypes.DOUBLE
        },
        columnString4: {
            allowNull: true,
            type: DataTypes.STRING
        },
        columnNumber4: {
            allowNull: true,
            type: DataTypes.DOUBLE
        },
        version: {
            allowNull: false,
            type: DataTypes.INTEGER
        }
    }, {
        charset: 'utf8',
        classMethods: {
            associate: models => {
                models.match.hasMany(models.matchAction, { foreignKey: 'matchId', onDelete: 'cascade' });
                models.match.belongsTo(models.alert, { foreignKey: 'alertId' });
                models.match.belongsTo(models.user, { foreignKey: 'statusUserId' });
            },
            instanceToPublicAttributes: instanceToPublicAttributes
        }
    });
    match.STATUS_VALUES = STATUS_VALUES;
    return match;
};
/**
 * Configure a virtual `columns` field based on the `columnsDescription` of its alert.
 *
 * @param {MatchInstance} matchInstance
 * @param {Array<{type: string, columnName: string, columnTitle: string}>} [columnsDescription]
 * @returns {Partial<PublicMatch>} only missing viewers
 */
function instanceToPublicAttributes(matchInstance, columnsDescription) {
    const publicMatch = /**@type {Partial<PublicMatch>}*/ (_.pick(matchInstance, PUBLIC_FIELDS));
    if (Utils.noValue(columnsDescription)) {
        return publicMatch;
    }
    publicMatch.columns = [];
    columnsDescription.forEach((column, idx) => {
        let rawFieldName;
        if (column.type === 'number') {
            rawFieldName = 'columnNumber' + idx;
        }
        else { // string
            rawFieldName = 'columnString' + idx;
        }
        publicMatch.columns.push(matchInstance[rawFieldName]);
    });
    return publicMatch;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTWF0Y2guanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvc3FsRGIvbW9kZWxzL01hdGNoLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBQ2IsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVCLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUNuQyxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxRQUFRLEdBQUcsT0FBTyxDQUFDLHVCQUF1QixDQUFDLENBQUM7QUFFbEQsTUFBTSxhQUFhLEdBQUcsQ0FBQyxJQUFJLEVBQUUsV0FBVyxFQUFFLFNBQVMsRUFBRSxNQUFNO0lBQ3pELFFBQVEsRUFBRSxnQkFBZ0IsRUFBRSxPQUFPLEVBQUUsT0FBTyxFQUFFLFdBQVcsRUFBRSxXQUFXLENBQUMsQ0FBQyxDQUFDLHFDQUFxQztBQUVoSDs7Ozs7Ozs7Ozs7Ozs7Ozs7R0FpQkc7QUFFSCxNQUFNLENBQUMsT0FBTyxHQUFHLFVBQVMsU0FBUyxFQUFFLFNBQVM7SUFDNUMsTUFBTSxhQUFhLEdBQUcsQ0FBQyxhQUFhLEVBQUUsV0FBVyxFQUFFLFdBQVcsQ0FBQyxDQUFDO0lBRWhFLE1BQU0sS0FBSyxHQUFHLFNBQVMsQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO1FBQ3RDLFNBQVMsRUFBRTtZQUNULFNBQVMsRUFBRSxLQUFLO1lBQ2hCLElBQUksRUFBRSxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztTQUMxQjtRQUNELElBQUksRUFBRTtZQUNKLFNBQVMsRUFBRSxLQUFLO1lBQ2hCLElBQUksRUFBRSxTQUFTLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztZQUMzQixNQUFNLEVBQUUsSUFBSTtTQUNiO1FBRUQsOEVBQThFO1FBQzlFLEtBQUssRUFBRTtZQUNMLFNBQVMsRUFBRSxJQUFJO1lBQ2YsSUFBSSxFQUFFLFNBQVMsQ0FBQyxPQUFPO1NBQ3hCO1FBQ0QsTUFBTSxFQUFFO1lBQ04sU0FBUyxFQUFFLEtBQUs7WUFDaEIsSUFBSSxFQUFFLFNBQVMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1NBQzNCO1FBQ0QsY0FBYyxFQUFFLFFBQVEsQ0FBQyx3QkFBd0IsQ0FBQyxnQkFBZ0IsRUFBRSxLQUFLLENBQUM7UUFDMUUsS0FBSyxFQUFFLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUM7UUFDMUMsS0FBSyxFQUFFLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUM7UUFFMUMsYUFBYSxFQUFFO1lBQ2IsU0FBUyxFQUFFLElBQUk7WUFDZixJQUFJLEVBQUUsU0FBUyxDQUFDLE1BQU07U0FDdkI7UUFDRCxhQUFhLEVBQUU7WUFDYixTQUFTLEVBQUUsSUFBSTtZQUNmLElBQUksRUFBRSxTQUFTLENBQUMsTUFBTTtTQUN2QjtRQUNELGFBQWEsRUFBRTtZQUNiLFNBQVMsRUFBRSxJQUFJO1lBQ2YsSUFBSSxFQUFFLFNBQVMsQ0FBQyxNQUFNO1NBQ3ZCO1FBQ0QsYUFBYSxFQUFFO1lBQ2IsU0FBUyxFQUFFLElBQUk7WUFDZixJQUFJLEVBQUUsU0FBUyxDQUFDLE1BQU07U0FDdkI7UUFDRCxhQUFhLEVBQUU7WUFDYixTQUFTLEVBQUUsSUFBSTtZQUNmLElBQUksRUFBRSxTQUFTLENBQUMsTUFBTTtTQUN2QjtRQUNELGFBQWEsRUFBRTtZQUNiLFNBQVMsRUFBRSxJQUFJO1lBQ2YsSUFBSSxFQUFFLFNBQVMsQ0FBQyxNQUFNO1NBQ3ZCO1FBQ0QsYUFBYSxFQUFFO1lBQ2IsU0FBUyxFQUFFLElBQUk7WUFDZixJQUFJLEVBQUUsU0FBUyxDQUFDLE1BQU07U0FDdkI7UUFDRCxhQUFhLEVBQUU7WUFDYixTQUFTLEVBQUUsSUFBSTtZQUNmLElBQUksRUFBRSxTQUFTLENBQUMsTUFBTTtTQUN2QjtRQUNELGFBQWEsRUFBRTtZQUNiLFNBQVMsRUFBRSxJQUFJO1lBQ2YsSUFBSSxFQUFFLFNBQVMsQ0FBQyxNQUFNO1NBQ3ZCO1FBQ0QsYUFBYSxFQUFFO1lBQ2IsU0FBUyxFQUFFLElBQUk7WUFDZixJQUFJLEVBQUUsU0FBUyxDQUFDLE1BQU07U0FDdkI7UUFDRCxPQUFPLEVBQUU7WUFDUCxTQUFTLEVBQUUsS0FBSztZQUNoQixJQUFJLEVBQUUsU0FBUyxDQUFDLE9BQU87U0FDeEI7S0FDRixFQUFFO1FBQ0QsT0FBTyxFQUFFLE1BQU07UUFDZixZQUFZLEVBQUU7WUFDWixTQUFTLEVBQUUsTUFBTSxDQUFDLEVBQUU7Z0JBQ2xCLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUUsRUFBQyxVQUFVLEVBQUUsU0FBUyxFQUFFLFFBQVEsRUFBRSxTQUFTLEVBQUMsQ0FBQyxDQUFDO2dCQUN2RixNQUFNLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLEVBQUMsVUFBVSxFQUFFLFNBQVMsRUFBQyxDQUFDLENBQUM7Z0JBQzlELE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsRUFBQyxVQUFVLEVBQUUsY0FBYyxFQUFDLENBQUMsQ0FBQztZQUNwRSxDQUFDO1lBQ0QsMEJBQTBCLEVBQUUsMEJBQTBCO1NBQ3ZEO0tBQ0YsQ0FBQyxDQUFDO0lBRUgsS0FBSyxDQUFDLGFBQWEsR0FBRyxhQUFhLENBQUM7SUFFcEMsT0FBTyxLQUFLLENBQUM7QUFDZixDQUFDLENBQUM7QUFFRjs7Ozs7O0dBTUc7QUFDSCxTQUFTLDBCQUEwQixDQUFDLGFBQWEsRUFBRSxrQkFBa0I7SUFDbkUsTUFBTSxXQUFXLEdBQUcsaUNBQWlDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxhQUFhLENBQUMsQ0FBQyxDQUFDO0lBRTdGLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFO1FBQ3JDLE9BQU8sV0FBVyxDQUFDO0tBQ3BCO0lBRUQsV0FBVyxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7SUFDekIsa0JBQWtCLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxFQUFFLEdBQUcsRUFBRSxFQUFFO1FBQ3pDLElBQUksWUFBWSxDQUFDO1FBQ2pCLElBQUksTUFBTSxDQUFDLElBQUksS0FBSyxRQUFRLEVBQUU7WUFDNUIsWUFBWSxHQUFHLGNBQWMsR0FBRyxHQUFHLENBQUM7U0FDckM7YUFBTSxFQUFFLFNBQVM7WUFDaEIsWUFBWSxHQUFHLGNBQWMsR0FBRyxHQUFHLENBQUM7U0FDckM7UUFFRCxXQUFXLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztJQUN4RCxDQUFDLENBQUMsQ0FBQztJQUVILE9BQU8sV0FBVyxDQUFDO0FBQ3JCLENBQUMifQ==