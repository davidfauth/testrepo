/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-05-23.
 */
'use strict';
const _ = require('lodash');
const PUBLIC_FIELDS = ['id', 'matchId', 'action', 'createdAt', 'updatedAt'];
/**
 * MatchAction
 *
 * @property {number} id        Id of the match (added by sequelize)
 * @property {number} matchId   Match on which the action is performed
 * @property {object} user      The user that did the action
 * @property {string} action    The action name ("open", "confirm", "dismiss")
 * @property {string} createdAt Creation date (added by sequelize)
 * @property {string} updatedAt Update date (added by sequelize)
 */
module.exports = function (sequelize, DataTypes) {
    const ACTION_VALUES = ['open', 'confirm', 'unconfirm', 'dismiss'];
    const matchAction = sequelize.define('matchAction', {
        action: {
            allowNull: false,
            type: DataTypes.STRING(20)
        }
    }, {
        charset: 'utf8',
        classMethods: {
            associate: models => {
                models.matchAction.belongsTo(models.match, { foreignKey: 'matchId' });
                models.matchAction.belongsTo(models.user, { foreignKey: 'userId' });
            },
            instanceToPublicAttributes: instanceToPublicAttributes
        }
    });
    matchAction.ACTION_VALUES = ACTION_VALUES;
    return matchAction;
};
/**
 * @param {MatchActionInstance} matchActionInstance
 * @returns {PublicMatchAction}
 */
function instanceToPublicAttributes(matchActionInstance) {
    return /**@type {PublicMatchAction}*/ (_.pick(matchActionInstance, PUBLIC_FIELDS));
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTWF0Y2hBY3Rpb24uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvc3FsRGIvbW9kZWxzL01hdGNoQWN0aW9uLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBQ2IsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBRTVCLE1BQU0sYUFBYSxHQUFHLENBQUMsSUFBSSxFQUFFLFNBQVMsRUFBRSxRQUFRLEVBQUUsV0FBVyxFQUFFLFdBQVcsQ0FBQyxDQUFDO0FBRTVFOzs7Ozs7Ozs7R0FTRztBQUVILE1BQU0sQ0FBQyxPQUFPLEdBQUcsVUFBUyxTQUFTLEVBQUUsU0FBUztJQUM1QyxNQUFNLGFBQWEsR0FBRyxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsV0FBVyxFQUFFLFNBQVMsQ0FBQyxDQUFDO0lBRWxFLE1BQU0sV0FBVyxHQUFHLFNBQVMsQ0FBQyxNQUFNLENBQUMsYUFBYSxFQUFFO1FBQ2xELE1BQU0sRUFBRTtZQUNOLFNBQVMsRUFBRSxLQUFLO1lBQ2hCLElBQUksRUFBRSxTQUFTLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztTQUMzQjtLQUNGLEVBQUU7UUFDRCxPQUFPLEVBQUUsTUFBTTtRQUNmLFlBQVksRUFBRTtZQUNaLFNBQVMsRUFBRSxNQUFNLENBQUMsRUFBRTtnQkFDbEIsTUFBTSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxFQUFDLFVBQVUsRUFBRSxTQUFTLEVBQUMsQ0FBQyxDQUFDO2dCQUNwRSxNQUFNLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLEVBQUMsVUFBVSxFQUFFLFFBQVEsRUFBQyxDQUFDLENBQUM7WUFDcEUsQ0FBQztZQUNELDBCQUEwQixFQUFFLDBCQUEwQjtTQUN2RDtLQUNGLENBQUMsQ0FBQztJQUVILFdBQVcsQ0FBQyxhQUFhLEdBQUcsYUFBYSxDQUFDO0lBRTFDLE9BQU8sV0FBVyxDQUFDO0FBQ3JCLENBQUMsQ0FBQztBQUVGOzs7R0FHRztBQUNILFNBQVMsMEJBQTBCLENBQUMsbUJBQW1CO0lBQ3JELE9BQU8sOEJBQThCLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLG1CQUFtQixFQUFFLGFBQWEsQ0FBQyxDQUFDLENBQUM7QUFDckYsQ0FBQyJ9