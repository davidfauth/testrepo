/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-10-08.
 */
'use strict';
const DBFields = require('../../../lib/DBFields');
module.exports = function (sequelize, DataTypes) {
    const visualization = sequelize.define('visualization', {
        title: {
            type: DataTypes.STRING(200),
            allowNull: false
        },
        sourceKey: {
            type: DataTypes.STRING(8),
            allowNull: false
        },
        sandbox: {
            type: DataTypes.BOOLEAN(),
            allowNull: false
        },
        nodes: DBFields.generateJsonField('nodes', [], true, sequelize.options.dialect),
        edges: DBFields.generateJsonField('edges', [], true, sequelize.options.dialect),
        nodeFields: DBFields.generateJsonField('nodeFields'),
        edgeFields: DBFields.generateJsonField('edgeFields'),
        design: DBFields.generateJsonField('design'),
        filters: DBFields.generateJsonField('filters'),
        alternativeIds: DBFields.generateJsonField('alternativeIds', {}),
        mode: {
            type: DataTypes.STRING(15),
            allowNull: false,
            defaultValue: 'nodelink'
        },
        layout: DBFields.generateJsonField('layout'),
        geo: DBFields.generateJsonField('geo'),
        timeline: DBFields.generateJsonField('timeline', { node: {}, edge: {} }),
        version: {
            allowNull: false,
            type: DataTypes.INTEGER
        }
    }, {
        charset: 'utf8',
        classMethods: {
            associate: models => {
                // no constrains: -1 is legal for root folder
                visualization.belongsTo(models.visualizationFolder, {
                    foreignKey: 'folder', constraints: false
                });
                visualization.belongsTo(models.user, { foreignKey: 'userId' });
                visualization.hasMany(models.visualizationShare, { foreignKey: 'visualizationId' });
            }
        }
    });
    return visualization;
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiVmlzdWFsaXphdGlvbi5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NlcnZlci9zZXJ2aWNlcy9zcWxEYi9tb2RlbHMvVmlzdWFsaXphdGlvbi5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7R0FLRztBQUNILFlBQVksQ0FBQztBQUViLE1BQU0sUUFBUSxHQUFHLE9BQU8sQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO0FBRWxELE1BQU0sQ0FBQyxPQUFPLEdBQUcsVUFBUyxTQUFTLEVBQUUsU0FBUztJQUM1QyxNQUFNLGFBQWEsR0FBRyxTQUFTLENBQUMsTUFBTSxDQUFDLGVBQWUsRUFBRTtRQUV0RCxLQUFLLEVBQUU7WUFDTCxJQUFJLEVBQUUsU0FBUyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7WUFDM0IsU0FBUyxFQUFFLEtBQUs7U0FDakI7UUFFRCxTQUFTLEVBQUU7WUFDVCxJQUFJLEVBQUUsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7WUFDekIsU0FBUyxFQUFFLEtBQUs7U0FDakI7UUFFRCxPQUFPLEVBQUU7WUFDUCxJQUFJLEVBQUUsU0FBUyxDQUFDLE9BQU8sRUFBRTtZQUN6QixTQUFTLEVBQUUsS0FBSztTQUNqQjtRQUVELEtBQUssRUFBRSxRQUFRLENBQUMsaUJBQWlCLENBQUMsT0FBTyxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsU0FBUyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUM7UUFDL0UsS0FBSyxFQUFFLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxTQUFTLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQztRQUUvRSxVQUFVLEVBQUUsUUFBUSxDQUFDLGlCQUFpQixDQUFDLFlBQVksQ0FBQztRQUNwRCxVQUFVLEVBQUUsUUFBUSxDQUFDLGlCQUFpQixDQUFDLFlBQVksQ0FBQztRQUVwRCxNQUFNLEVBQUUsUUFBUSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQztRQUM1QyxPQUFPLEVBQUUsUUFBUSxDQUFDLGlCQUFpQixDQUFDLFNBQVMsQ0FBQztRQUU5QyxjQUFjLEVBQUUsUUFBUSxDQUFDLGlCQUFpQixDQUFDLGdCQUFnQixFQUFFLEVBQUUsQ0FBQztRQUVoRSxJQUFJLEVBQUU7WUFDSixJQUFJLEVBQUUsU0FBUyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7WUFDMUIsU0FBUyxFQUFFLEtBQUs7WUFDaEIsWUFBWSxFQUFFLFVBQVU7U0FDekI7UUFFRCxNQUFNLEVBQUUsUUFBUSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQztRQUU1QyxHQUFHLEVBQUUsUUFBUSxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQztRQUV0QyxRQUFRLEVBQUUsUUFBUSxDQUFDLGlCQUFpQixDQUFDLFVBQVUsRUFBRSxFQUFDLElBQUksRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBQyxDQUFDO1FBRXRFLE9BQU8sRUFBRTtZQUNQLFNBQVMsRUFBRSxLQUFLO1lBQ2hCLElBQUksRUFBRSxTQUFTLENBQUMsT0FBTztTQUN4QjtLQUNGLEVBQUU7UUFDRCxPQUFPLEVBQUUsTUFBTTtRQUNmLFlBQVksRUFBRTtZQUNaLFNBQVMsRUFBRSxNQUFNLENBQUMsRUFBRTtnQkFDbEIsNkNBQTZDO2dCQUM3QyxhQUFhLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsRUFBRTtvQkFDbEQsVUFBVSxFQUFFLFFBQVEsRUFBRSxXQUFXLEVBQUUsS0FBSztpQkFDekMsQ0FBQyxDQUFDO2dCQUNILGFBQWEsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxFQUFDLFVBQVUsRUFBRSxRQUFRLEVBQUMsQ0FBQyxDQUFDO2dCQUM3RCxhQUFhLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsRUFBRSxFQUFDLFVBQVUsRUFBRSxpQkFBaUIsRUFBQyxDQUFDLENBQUM7WUFDcEYsQ0FBQztTQUNGO0tBQ0YsQ0FBQyxDQUFDO0lBRUgsT0FBTyxhQUFhLENBQUM7QUFDdkIsQ0FBQyxDQUFDIn0=