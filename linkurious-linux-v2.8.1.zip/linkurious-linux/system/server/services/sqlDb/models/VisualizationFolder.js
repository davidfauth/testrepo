/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-10-08.
 */
'use strict';
module.exports = function (sequelize, DataTypes) {
    const visualizationFolder = sequelize.define('visualizationFolder', {
        // name of this folder
        title: {
            type: DataTypes.STRING,
            allowNull: false
        },
        // key of the data-sources containing this folder
        sourceKey: {
            type: DataTypes.STRING(8),
            allowNull: false
        },
        // user id (can be negative IDs for specials users), no integrity check
        userId: {
            type: DataTypes.INTEGER,
            allowNull: false
        }
    }, {
        charset: 'utf8',
        classMethods: {
            associate: () => {
                // no constrains: -1 is legal for root folder
                visualizationFolder.belongsTo(visualizationFolder, {
                    foreignKey: 'parent', constraints: false
                });
            }
        }
    });
    return visualizationFolder;
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiVmlzdWFsaXphdGlvbkZvbGRlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NlcnZlci9zZXJ2aWNlcy9zcWxEYi9tb2RlbHMvVmlzdWFsaXphdGlvbkZvbGRlci5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7R0FLRztBQUNILFlBQVksQ0FBQztBQUViLE1BQU0sQ0FBQyxPQUFPLEdBQUcsVUFBUyxTQUFTLEVBQUUsU0FBUztJQUU1QyxNQUFNLG1CQUFtQixHQUFHLFNBQVMsQ0FBQyxNQUFNLENBQUMscUJBQXFCLEVBQUU7UUFDbEUsc0JBQXNCO1FBQ3RCLEtBQUssRUFBRTtZQUNMLElBQUksRUFBRSxTQUFTLENBQUMsTUFBTTtZQUN0QixTQUFTLEVBQUUsS0FBSztTQUNqQjtRQUNELGlEQUFpRDtRQUNqRCxTQUFTLEVBQUU7WUFDVCxJQUFJLEVBQUUsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7WUFDekIsU0FBUyxFQUFFLEtBQUs7U0FDakI7UUFDRCx1RUFBdUU7UUFDdkUsTUFBTSxFQUFFO1lBQ04sSUFBSSxFQUFFLFNBQVMsQ0FBQyxPQUFPO1lBQ3ZCLFNBQVMsRUFBRSxLQUFLO1NBQ2pCO0tBQ0YsRUFBRTtRQUNELE9BQU8sRUFBRSxNQUFNO1FBQ2YsWUFBWSxFQUFFO1lBQ1osU0FBUyxFQUFFLEdBQUcsRUFBRTtnQkFDZCw2Q0FBNkM7Z0JBQzdDLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsRUFBRTtvQkFDakQsVUFBVSxFQUFFLFFBQVEsRUFBRSxXQUFXLEVBQUUsS0FBSztpQkFDekMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQztTQUNGO0tBQ0YsQ0FBQyxDQUFDO0lBRUgsT0FBTyxtQkFBbUIsQ0FBQztBQUM3QixDQUFDLENBQUMifQ==