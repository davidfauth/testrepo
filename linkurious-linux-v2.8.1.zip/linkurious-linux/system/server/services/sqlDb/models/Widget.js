/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2015-02-23.
 */
'use strict';
// externals
const _ = require('lodash');
const LKE = require('../../../services');
const Utils = LKE.getUtils();
const DBFields = require('../../../lib/DBFields');
const PUBLIC_FIELDS = [
    'title', 'key', 'content', 'url', 'userId', 'visualizationId', 'updatedAt', 'createdAt'
];
module.exports = function (sequelize, DataTypes) {
    const widget = sequelize.define('widget', {
        title: {
            type: DataTypes.STRING(),
            allowNull: false
        },
        key: {
            type: DataTypes.STRING(8),
            allowNull: false
        },
        salt: {
            type: DataTypes.STRING(24),
            allowNull: true
        },
        password: {
            type: DataTypes.STRING(512),
            allowNull: true,
            set: function (password) {
                DBFields.storePassword(this, password);
            }
        },
        content: DBFields.generateJsonField('content', {}, true, sequelize.options.dialect),
        version: {
            type: DataTypes.INTEGER,
            allowNull: false
        }
    }, {
        charset: 'utf8',
        classMethods: {
            associate: function (models) {
                models.visualization.hasOne(widget, {
                    foreignKey: 'visualizationId',
                    onDelete: 'cascade'
                });
                widget.belongsTo(models.user, { foreignKey: 'userId' });
            },
            instanceToPublicAttributes: instanceToPublicAttributes
        },
        instanceMethods: {
            /**
             * @param {string} password
             * @returns {boolean}
             */
            checkPassword: function (password) {
                return DBFields.checkPassword(this, password);
            }
        }
    });
    return widget;
};
/**
 * @param {WidgetInstance} widget
 * @returns {PublicWidget}
 */
function instanceToPublicAttributes(widget) {
    /**@type {object}**/
    const publicWidget = _.pick(widget.get(), PUBLIC_FIELDS);
    publicWidget.password = Utils.hasValue(widget.password);
    publicWidget.url = LKE.getBaseURL('/widget/' + publicWidget.key);
    return /**@type {PublicWidget}**/ (publicWidget);
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiV2lkZ2V0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc2VydmVyL3NlcnZpY2VzL3NxbERiL21vZGVscy9XaWRnZXQuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFFYixZQUFZO0FBQ1osTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVCLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0FBQ3pDLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUU3QixNQUFNLFFBQVEsR0FBRyxPQUFPLENBQUMsdUJBQXVCLENBQUMsQ0FBQztBQUVsRCxNQUFNLGFBQWEsR0FBRztJQUNwQixPQUFPLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLGlCQUFpQixFQUFFLFdBQVcsRUFBRSxXQUFXO0NBQ3hGLENBQUM7QUFFRixNQUFNLENBQUMsT0FBTyxHQUFHLFVBQVMsU0FBUyxFQUFFLFNBQVM7SUFFNUMsTUFBTSxNQUFNLEdBQUcsU0FBUyxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUU7UUFFeEMsS0FBSyxFQUFFO1lBQ0wsSUFBSSxFQUFFLFNBQVMsQ0FBQyxNQUFNLEVBQUU7WUFDeEIsU0FBUyxFQUFFLEtBQUs7U0FDakI7UUFFRCxHQUFHLEVBQUU7WUFDSCxJQUFJLEVBQUUsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7WUFDekIsU0FBUyxFQUFFLEtBQUs7U0FDakI7UUFFRCxJQUFJLEVBQUU7WUFDSixJQUFJLEVBQUUsU0FBUyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7WUFDMUIsU0FBUyxFQUFFLElBQUk7U0FDaEI7UUFDRCxRQUFRLEVBQUU7WUFDUixJQUFJLEVBQUUsU0FBUyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7WUFDM0IsU0FBUyxFQUFFLElBQUk7WUFDZixHQUFHLEVBQUUsVUFBUyxRQUFRO2dCQUNwQixRQUFRLENBQUMsYUFBYSxDQUFDLElBQUksRUFBRSxRQUFRLENBQUMsQ0FBQztZQUN6QyxDQUFDO1NBQ0Y7UUFFRCxPQUFPLEVBQUUsUUFBUSxDQUFDLGlCQUFpQixDQUFDLFNBQVMsRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLFNBQVMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDO1FBRW5GLE9BQU8sRUFBRTtZQUNQLElBQUksRUFBRSxTQUFTLENBQUMsT0FBTztZQUN2QixTQUFTLEVBQUUsS0FBSztTQUNqQjtLQUVGLEVBQUU7UUFDRCxPQUFPLEVBQUUsTUFBTTtRQUNmLFlBQVksRUFBRTtZQUNaLFNBQVMsRUFBRSxVQUFTLE1BQU07Z0JBQ3hCLE1BQU0sQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRTtvQkFDbEMsVUFBVSxFQUFFLGlCQUFpQjtvQkFDN0IsUUFBUSxFQUFFLFNBQVM7aUJBQ3BCLENBQUMsQ0FBQztnQkFDSCxNQUFNLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsRUFBQyxVQUFVLEVBQUUsUUFBUSxFQUFDLENBQUMsQ0FBQztZQUN4RCxDQUFDO1lBQ0QsMEJBQTBCLEVBQUUsMEJBQTBCO1NBQ3ZEO1FBRUQsZUFBZSxFQUFFO1lBQ2Y7OztlQUdHO1lBQ0gsYUFBYSxFQUFFLFVBQVMsUUFBUTtnQkFDOUIsT0FBTyxRQUFRLENBQUMsYUFBYSxDQUFDLElBQUksRUFBRSxRQUFRLENBQUMsQ0FBQztZQUNoRCxDQUFDO1NBQ0Y7S0FDRixDQUFDLENBQUM7SUFFSCxPQUFPLE1BQU0sQ0FBQztBQUNoQixDQUFDLENBQUM7QUFFRjs7O0dBR0c7QUFDSCxTQUFTLDBCQUEwQixDQUFDLE1BQU07SUFDeEMsb0JBQW9CO0lBQ3BCLE1BQU0sWUFBWSxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxFQUFFLGFBQWEsQ0FBQyxDQUFDO0lBQ3pELFlBQVksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDeEQsWUFBWSxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDakUsT0FBTywwQkFBMEIsQ0FBQSxDQUFDLFlBQVksQ0FBQyxDQUFDO0FBQ2xELENBQUMifQ==