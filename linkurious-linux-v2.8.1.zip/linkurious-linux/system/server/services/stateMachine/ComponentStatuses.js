/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-11-26.
 */
'use strict';
// Codes and/or names should identify any status unically
// Codes are inspired from http codes:
// - 1** : Processing / information
// - 2** : Ok
// - 4** : backend external error
// - 5** : backend related error
const LKE = require('../index');
const Config = LKE.getConfig();
const STATUSES = {
    Linkurious: [
        {
            code: 100,
            name: 'starting',
            message: 'Starting Linkurious in ' + Config.mode + ' mode...'
        },
        {
            code: 200,
            name: 'initialized',
            message: 'Linkurious ready to go :)'
        },
        {
            code: 400,
            name: 'error',
            message: 'Some components of Linkurious are not working properly.'
        },
        {
            code: 500,
            name: 'unknown_error',
            message: 'Linkurious encountered an unexpected error.'
        }
    ],
    SqlDB: [
        {
            code: 100,
            name: 'starting',
            message: 'Starting SQL database'
        },
        {
            code: 101,
            name: 'up',
            message: 'The SQL database is up.'
        },
        {
            code: 200,
            name: 'synced',
            message: 'The SQL database is synced.'
        },
        {
            code: 401,
            name: 'down',
            message: 'Could not connect to the SQL database.'
        },
        {
            code: 402,
            name: 'sync_error',
            message: 'We could not write to the SQL database, please check its status and configuration'
        }
    ],
    DataService: [
        {
            code: 100,
            name: 'starting',
            message: 'Starting data service.'
        },
        {
            code: 200,
            name: 'up',
            message: 'Data-sources ready.'
        },
        {
            code: 201,
            name: 'indexing',
            message: 'A data-source is currently indexing.'
        },
        {
            code: 401,
            name: 'down',
            message: 'Could not connect to any data-source.'
        }
    ],
    WebServer: [
        {
            code: 100,
            name: 'starting',
            message: 'Starting Web Server'
        },
        {
            code: 200,
            name: 'ready',
            message: 'The Web Server ready.'
        },
        {
            code: 400,
            name: 'error',
            message: 'The Web Server could not start.'
        },
        {
            code: 401,
            name: 'port_busy',
            message: 'The Web Server could not start: the port is busy.'
        },
        {
            code: 403,
            name: 'port_restricted',
            message: 'The Web Server could not start: root access is required to listen to ports under 1024'
        }
    ]
};
module.exports = STATUSES;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQ29tcG9uZW50U3RhdHVzZXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvc3RhdGVNYWNoaW5lL0NvbXBvbmVudFN0YXR1c2VzLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIseURBQXlEO0FBQ3pELHNDQUFzQztBQUN0QyxtQ0FBbUM7QUFDbkMsYUFBYTtBQUNiLGlDQUFpQztBQUNqQyxnQ0FBZ0M7QUFDaEMsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ2hDLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUUvQixNQUFNLFFBQVEsR0FBRztJQUVmLFVBQVUsRUFBRTtRQUNWO1lBQ0UsSUFBSSxFQUFFLEdBQUc7WUFDVCxJQUFJLEVBQUUsVUFBVTtZQUNoQixPQUFPLEVBQUUseUJBQXlCLEdBQUcsTUFBTSxDQUFDLElBQUksR0FBRyxVQUFVO1NBQzlEO1FBQ0Q7WUFDRSxJQUFJLEVBQUUsR0FBRztZQUNULElBQUksRUFBRSxhQUFhO1lBQ25CLE9BQU8sRUFBRSwyQkFBMkI7U0FDckM7UUFDRDtZQUNFLElBQUksRUFBRSxHQUFHO1lBQ1QsSUFBSSxFQUFFLE9BQU87WUFDYixPQUFPLEVBQUUseURBQXlEO1NBQ25FO1FBQ0Q7WUFDRSxJQUFJLEVBQUUsR0FBRztZQUNULElBQUksRUFBRSxlQUFlO1lBQ3JCLE9BQU8sRUFBRSw2Q0FBNkM7U0FDdkQ7S0FDRjtJQUVELEtBQUssRUFBRTtRQUNMO1lBQ0UsSUFBSSxFQUFFLEdBQUc7WUFDVCxJQUFJLEVBQUUsVUFBVTtZQUNoQixPQUFPLEVBQUUsdUJBQXVCO1NBQ2pDO1FBQ0Q7WUFDRSxJQUFJLEVBQUUsR0FBRztZQUNULElBQUksRUFBRSxJQUFJO1lBQ1YsT0FBTyxFQUFFLHlCQUF5QjtTQUNuQztRQUNEO1lBQ0UsSUFBSSxFQUFFLEdBQUc7WUFDVCxJQUFJLEVBQUUsUUFBUTtZQUNkLE9BQU8sRUFBRSw2QkFBNkI7U0FDdkM7UUFDRDtZQUNFLElBQUksRUFBRSxHQUFHO1lBQ1QsSUFBSSxFQUFFLE1BQU07WUFDWixPQUFPLEVBQUUsd0NBQXdDO1NBQ2xEO1FBQ0Q7WUFDRSxJQUFJLEVBQUUsR0FBRztZQUNULElBQUksRUFBRSxZQUFZO1lBQ2xCLE9BQU8sRUFBRSxtRkFBbUY7U0FDN0Y7S0FDRjtJQUVELFdBQVcsRUFBRTtRQUNYO1lBQ0UsSUFBSSxFQUFFLEdBQUc7WUFDVCxJQUFJLEVBQUUsVUFBVTtZQUNoQixPQUFPLEVBQUUsd0JBQXdCO1NBQ2xDO1FBQ0Q7WUFDRSxJQUFJLEVBQUUsR0FBRztZQUNULElBQUksRUFBRSxJQUFJO1lBQ1YsT0FBTyxFQUFFLHFCQUFxQjtTQUMvQjtRQUNEO1lBQ0UsSUFBSSxFQUFFLEdBQUc7WUFDVCxJQUFJLEVBQUUsVUFBVTtZQUNoQixPQUFPLEVBQUUsc0NBQXNDO1NBQ2hEO1FBQ0Q7WUFDRSxJQUFJLEVBQUUsR0FBRztZQUNULElBQUksRUFBRSxNQUFNO1lBQ1osT0FBTyxFQUFFLHVDQUF1QztTQUNqRDtLQUNGO0lBRUQsU0FBUyxFQUFFO1FBQ1Q7WUFDRSxJQUFJLEVBQUUsR0FBRztZQUNULElBQUksRUFBRSxVQUFVO1lBQ2hCLE9BQU8sRUFBRSxxQkFBcUI7U0FDL0I7UUFDRDtZQUNFLElBQUksRUFBRSxHQUFHO1lBQ1QsSUFBSSxFQUFFLE9BQU87WUFDYixPQUFPLEVBQUUsdUJBQXVCO1NBQ2pDO1FBQ0Q7WUFDRSxJQUFJLEVBQUUsR0FBRztZQUNULElBQUksRUFBRSxPQUFPO1lBQ2IsT0FBTyxFQUFFLGlDQUFpQztTQUMzQztRQUNEO1lBQ0UsSUFBSSxFQUFFLEdBQUc7WUFDVCxJQUFJLEVBQUUsV0FBVztZQUNqQixPQUFPLEVBQUUsbURBQW1EO1NBQzdEO1FBQ0Q7WUFDRSxJQUFJLEVBQUUsR0FBRztZQUNULElBQUksRUFBRSxpQkFBaUI7WUFDdkIsT0FBTyxFQUNMLHVGQUF1RjtTQUMxRjtLQUNGO0NBQ0YsQ0FBQztBQUVGLE1BQU0sQ0FBQyxPQUFPLEdBQUcsUUFBUSxDQUFDIn0=