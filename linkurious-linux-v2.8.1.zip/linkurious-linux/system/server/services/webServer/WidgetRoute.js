"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-11-23.
 */
Object.defineProperty(exports, "__esModule", { value: true });
// TS2019-DONE
const basicAuth = require("basic-auth");
const fs = require("fs-extra");
const path = require("path");
const MiniTemplate = require("../../../lib/MiniTemplate");
const LkError_1 = require("../../models/errors/LkError");
const LKE = require("../index");
const Config = LKE.getConfig();
const Utils = LKE.getUtils();
const Widget = LKE.getWidget();
const WIDGET_MAX_AGE_SECONDS = 30;
class WidgetRoute {
    /**
     * @param clientRoot File system path where `widget.html` is located
     * @param basePath   URL base path to patch frontend routing
     */
    constructor(clientRoot, basePath) {
        this.widgetPath = path.resolve(clientRoot, 'widget.html');
        this.basePath = basePath;
    }
    /**
     * Populate the widget template with widget data.
     */
    getWidgetPage(widgetData) {
        if (!this.template || !LKE.isProdMode()) {
            this.template = WidgetRoute.makeTemplate(this.widgetPath);
        }
        return this.template.compile({ tracker: '', data: widgetData });
    }
    /**
     * @param {string} filePath path of the file to make a template with
     */
    static makeTemplate(filePath) {
        const fileContent = fs.readFileSync(filePath, { encoding: 'utf8' });
        return new MiniTemplate(fileContent, {
            data: "'WIDGET_DATA'"
        });
    }
    load(router) {
        // serve widget routes if widgets are enabled (default: true)
        const widget = Config.get('access.widget', true);
        if (!widget) {
            return;
        }
        router.get('/widget/:key', async (req, res) => {
            let responseBody = '';
            let status = 200;
            const auth = basicAuth(req) || { pass: undefined };
            try {
                const widgetData = await Widget.getWidgetByKey(req.param('key'), { password: auth.pass });
                responseBody = this.getWidgetPage(JSON.stringify({
                    widget: widgetData,
                    ogmaOptions: Config.get('ogma')
                }));
            }
            catch (error) {
                if (error instanceof LkError_1.LkError) {
                    if (error.isAccess()) {
                        // respond with the basic-auth challenge in case of access error
                        status = 401;
                        res.setHeader('WWW-Authenticate', 'Basic realm="Linkurious Widget (user field is ignored)"');
                        responseBody = '<h1>' + error.message + '</h1>';
                    }
                    else {
                        // generic case of other errors
                        status = 400;
                        responseBody = '<h1>' + error.message + '</h1>';
                    }
                }
                else {
                    // handler for non-linkurious errors
                    status = 500;
                    responseBody =
                        '<h1>Internal server error</h1>' +
                            '<pre>' +
                            (error && error.stack ? error.stack : error) +
                            '</pre>';
                }
            }
            finally {
                res.setHeader('Cache-control', 'must-revalidate, max-age=' + WIDGET_MAX_AGE_SECONDS);
                // patch "<base>" element (needed for the Angular router)
                responseBody = responseBody.replace('<base href="/">', `<base href="${this.basePath}">`);
                res.status(status).send(responseBody);
            }
        });
        router.get('/widget', (req, res) => {
            // first pass OR not in prod
            if (Utils.noValue(this.widgetHtmlContent) || !LKE.isProdMode()) {
                // we try to load widget.html from disk
                if (!fs.existsSync(this.widgetPath)) {
                    // widget.html not found: respond with 404
                    res.status(404).send();
                    return;
                }
                this.widgetHtmlContent = fs.readFileSync(this.widgetPath, { encoding: 'utf8' });
                // patch "<base>" element (needed for the Angular router)
                this.widgetHtmlContent = this.widgetHtmlContent.replace('<base href="/">', `<base href="${this.basePath}">`);
            }
            res
                .status(200)
                .header('Cache-control', 'public, must-revalidate, max-age=' + WIDGET_MAX_AGE_SECONDS)
                .send(this.widgetHtmlContent);
        });
    }
}
exports.WidgetRoute = WidgetRoute;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiV2lkZ2V0Um91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvd2ViU2VydmVyL1dpZGdldFJvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRzs7QUFFSCxjQUFjO0FBRWQsd0NBQXlDO0FBR3pDLCtCQUFnQztBQUNoQyw2QkFBOEI7QUFDOUIsMERBQTJEO0FBQzNELHlEQUFvRDtBQUNwRCxnQ0FBaUM7QUFFakMsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFFL0IsTUFBTSxzQkFBc0IsR0FBRyxFQUFFLENBQUM7QUFFbEMsTUFBYSxXQUFXO0lBTXRCOzs7T0FHRztJQUNILFlBQVksVUFBa0IsRUFBRSxRQUFnQjtRQUM5QyxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1FBQzFELElBQUksQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDO0lBQzNCLENBQUM7SUFFRDs7T0FFRztJQUNLLGFBQWEsQ0FBQyxVQUFrQjtRQUN0QyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsSUFBSSxDQUFDLEdBQUcsQ0FBQyxVQUFVLEVBQUUsRUFBRTtZQUN2QyxJQUFJLENBQUMsUUFBUSxHQUFHLFdBQVcsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1NBQzNEO1FBQ0QsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFDLE9BQU8sRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLFVBQVUsRUFBQyxDQUFDLENBQUM7SUFDaEUsQ0FBQztJQUVEOztPQUVHO0lBQ0ssTUFBTSxDQUFDLFlBQVksQ0FBQyxRQUFnQjtRQUMxQyxNQUFNLFdBQVcsR0FBRyxFQUFFLENBQUMsWUFBWSxDQUFDLFFBQVEsRUFBRSxFQUFDLFFBQVEsRUFBRSxNQUFNLEVBQUMsQ0FBQyxDQUFDO1FBRWxFLE9BQU8sSUFBSSxZQUFZLENBQUMsV0FBVyxFQUFFO1lBQ25DLElBQUksRUFBRSxlQUFlO1NBQ3RCLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFTSxJQUFJLENBQUMsTUFBc0I7UUFDaEMsNkRBQTZEO1FBQzdELE1BQU0sTUFBTSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ2pELElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDWCxPQUFPO1NBQ1I7UUFFRCxNQUFNLENBQUMsR0FBRyxDQUFDLGNBQWMsRUFBRSxLQUFLLEVBQUUsR0FBb0IsRUFBRSxHQUFxQixFQUFFLEVBQUU7WUFDL0UsSUFBSSxZQUFZLEdBQUcsRUFBRSxDQUFDO1lBQ3RCLElBQUksTUFBTSxHQUFHLEdBQUcsQ0FBQztZQUVqQixNQUFNLElBQUksR0FBRyxTQUFTLENBQUMsR0FBRyxDQUFDLElBQUksRUFBQyxJQUFJLEVBQUUsU0FBUyxFQUFDLENBQUM7WUFFakQsSUFBSTtnQkFDRixNQUFNLFVBQVUsR0FBRyxNQUFNLE1BQU0sQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsSUFBSSxFQUFDLENBQUMsQ0FBQztnQkFDeEYsWUFBWSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQy9CLElBQUksQ0FBQyxTQUFTLENBQUM7b0JBQ2IsTUFBTSxFQUFFLFVBQVU7b0JBQ2xCLFdBQVcsRUFBRSxNQUFNLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQztpQkFDaEMsQ0FBQyxDQUNILENBQUM7YUFDSDtZQUFDLE9BQU8sS0FBSyxFQUFFO2dCQUNkLElBQUksS0FBSyxZQUFZLGlCQUFPLEVBQUU7b0JBQzVCLElBQUksS0FBSyxDQUFDLFFBQVEsRUFBRSxFQUFFO3dCQUNwQixnRUFBZ0U7d0JBQ2hFLE1BQU0sR0FBRyxHQUFHLENBQUM7d0JBQ2IsR0FBRyxDQUFDLFNBQVMsQ0FDWCxrQkFBa0IsRUFDbEIseURBQXlELENBQzFELENBQUM7d0JBQ0YsWUFBWSxHQUFHLE1BQU0sR0FBRyxLQUFLLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztxQkFDakQ7eUJBQU07d0JBQ0wsK0JBQStCO3dCQUMvQixNQUFNLEdBQUcsR0FBRyxDQUFDO3dCQUNiLFlBQVksR0FBRyxNQUFNLEdBQUcsS0FBSyxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7cUJBQ2pEO2lCQUNGO3FCQUFNO29CQUNMLG9DQUFvQztvQkFDcEMsTUFBTSxHQUFHLEdBQUcsQ0FBQztvQkFDYixZQUFZO3dCQUNWLGdDQUFnQzs0QkFDaEMsT0FBTzs0QkFDUCxDQUFDLEtBQUssSUFBSSxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7NEJBQzVDLFFBQVEsQ0FBQztpQkFDWjthQUNGO29CQUFTO2dCQUNSLEdBQUcsQ0FBQyxTQUFTLENBQUMsZUFBZSxFQUFFLDJCQUEyQixHQUFHLHNCQUFzQixDQUFDLENBQUM7Z0JBRXJGLHlEQUF5RDtnQkFDekQsWUFBWSxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsaUJBQWlCLEVBQUUsZUFBZSxJQUFJLENBQUMsUUFBUSxJQUFJLENBQUMsQ0FBQztnQkFDekYsR0FBRyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7YUFDdkM7UUFDSCxDQUFDLENBQUMsQ0FBQztRQUVILE1BQU0sQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUMsR0FBb0IsRUFBRSxHQUFxQixFQUFFLEVBQUU7WUFDcEUsNEJBQTRCO1lBQzVCLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxVQUFVLEVBQUUsRUFBRTtnQkFDOUQsdUNBQXVDO2dCQUV2QyxJQUFJLENBQUMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUU7b0JBQ25DLDBDQUEwQztvQkFDMUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDdkIsT0FBTztpQkFDUjtnQkFFRCxJQUFJLENBQUMsaUJBQWlCLEdBQUcsRUFBRSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLEVBQUMsUUFBUSxFQUFFLE1BQU0sRUFBQyxDQUFDLENBQUM7Z0JBRTlFLHlEQUF5RDtnQkFDekQsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQ3JELGlCQUFpQixFQUNqQixlQUFlLElBQUksQ0FBQyxRQUFRLElBQUksQ0FDakMsQ0FBQzthQUNIO1lBRUQsR0FBRztpQkFDQSxNQUFNLENBQUMsR0FBRyxDQUFDO2lCQUNYLE1BQU0sQ0FBQyxlQUFlLEVBQUUsbUNBQW1DLEdBQUcsc0JBQXNCLENBQUM7aUJBQ3JGLElBQUksQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQztRQUNsQyxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7Q0FDRjtBQXBIRCxrQ0FvSEMifQ==