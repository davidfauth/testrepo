"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-12-05.
 */
const Bluebird = require("bluebird");
const LKE = require("../index");
const apiError = require("./apiError");
const Errors = LKE.getErrors();
const Log = LKE.getLogger(__filename);
const Utils = LKE.getUtils();
class API {
    /**
     * @param timing Whether to include request/response timing information in response headers
     */
    constructor(timing) {
        this.timing = timing;
    }
    /**
     * Set some additional header (response-time, caching).
     *
     * @param response
     * @param requestStart
     */
    setResponseHeaders(response, requestStart) {
        // response timing
        if (this.timing) {
            response.setHeader('X-Response-Time', Date.now() - requestStart + 'ms');
        }
        // prevent HTTP caching
        // see https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Cache-Control
        // see https://www.fastly.com/blog/headers-we-dont-want
        response.setHeader('Cache-control', 'private, no-store');
    }
    /**
     * @param response
     * @param lkError
     */
    respondToLkError(response, lkError) {
        if (lkError.isTechnical()) {
            Log.error(lkError.type + ':' + lkError.key + ' ' + lkError.message);
            Log.error(lkError.stack);
        }
        else {
            Log.debug(lkError.type + ':' + lkError.key + ' ' + lkError.message);
        }
        const errorPayload = API.error(lkError);
        response.status(errorPayload.code).json({
            key: errorPayload.key,
            message: errorPayload.message,
            data: lkError.data
        });
    }
    /**
     * @param error
     */
    static error(error) {
        return apiError(error.key, error.message, error.type);
    }
    /**
     * @param res
     * @param err
     */
    respondToGenericError(res, err) {
        Log.error(err);
        res.status(500).json({ key: 'critical', message: err + '' });
    }
    respond(promiseFunction, successCode = 200, isProxy, wantResponse) {
        return (request, response, next) => {
            // @ts-ignore we won't use anymore request.param
            request.param = API.getParam.bind(undefined, request);
            // use response timing if required
            const requestStart = this.timing ? Date.now() : 0;
            Bluebird.resolve()
                .then(() => {
                // check promiseFunction
                if (typeof promiseFunction !== 'function') {
                    throw Errors.technical('bug', 'promiseFunction is not a function');
                }
                // run promiseFunction (can throw an exception)
                const promise = wantResponse === true
                    ? promiseFunction.call(null, request, response)
                    : // TODO find a way to overload function with callback params with variable arguments
                        promiseFunction.call(null, request, undefined);
                // check the result of promiseFunction
                if (isProxy && promise === null) {
                    // if isProxy=true and null is returned, consider that the response was sent manually
                }
                else if (promise === null || promise === undefined) {
                    throw Errors.technical('bug', 'promiseFunction returned null or undefined');
                }
                else if (typeof promise.then !== 'function') {
                    throw Errors.technical('bug', 'promiseFunction did not return a promise');
                }
                // return the promise for the next step
                return promise;
            })
                .then(data => {
                // success
                if (isProxy && data === null) {
                    // if isProxy=true and null is returned, consider that the response was sent manually
                }
                else if (isProxy && next) {
                    // call the next matching handler
                    next();
                }
                else {
                    // send a JSON response
                    this.setResponseHeaders(response, requestStart);
                    if (successCode === 204) {
                        // 204 response code allows no response body
                        response.setHeader('Content-Length', 0);
                        response.setHeader('Content-Type', 'application/json');
                        response.status(successCode).end();
                    }
                    else if (successCode === 302 || successCode === 301) {
                        // never do 301 redirects (see https://jacquesmattheij.com/301-redirects-a-dangerous-one-way-street)
                        successCode = 302;
                        // data is url redirection string when successCode is a 302 or 301
                        response.setHeader('Location', data);
                        response.status(successCode).send('Redirecting ...');
                    }
                    else {
                        response.status(successCode).json(data);
                    }
                }
            })
                .catch(Errors.LkError, error => {
                // Linkurious custom errors
                this.setResponseHeaders(response, requestStart);
                this.respondToLkError(response, error);
            })
                .catch(error => {
                // generic errors (critical)
                this.setResponseHeaders(response, requestStart);
                this.respondToGenericError(response, error);
            });
        };
    }
    proxy(promiseFunction, wantResponse) {
        return this.respond(
        // @ts-ignore
        promiseFunction, undefined, true, wantResponse);
    }
    /**
     * Read a param from an http request (from params, body or query)
     * Must be bound to an `http.IncomingMessage`.
     *
     * @param request
     * @param key
     * @param [defaultValue]
     */
    static getParam(request, key, defaultValue) {
        const urlParams = request.params || {};
        const body = request.body || {};
        const query = request.query || {};
        const snakeCaseKey = key
            .split(/(?=[A-Z])/)
            .join('_')
            .toLowerCase();
        if (Utils.hasValue(urlParams[key]) && urlParams.hasOwnProperty(key)) {
            return urlParams[key];
        }
        if (Utils.hasValue(body[key])) {
            return body[key];
        }
        if (Utils.hasValue(query[key])) {
            return query[key];
        }
        if (Utils.hasValue(query[snakeCaseKey])) {
            return query[snakeCaseKey];
        }
        return defaultValue;
    }
}
module.exports = new API(LKE.isTestMode() || LKE.isDevMode());
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBpLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL3NlcnZpY2VzL3dlYlNlcnZlci9hcGkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7OztHQUtHO0FBQ0gscUNBQXFDO0FBS3JDLGdDQUFpQztBQUNqQyx1Q0FBd0M7QUFHeEMsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDdEMsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBSTdCLE1BQU0sR0FBRztJQUdQOztPQUVHO0lBQ0gsWUFBWSxNQUFlO1FBQ3pCLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO0lBQ3ZCLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNLLGtCQUFrQixDQUFDLFFBQTBCLEVBQUUsWUFBb0I7UUFDekUsa0JBQWtCO1FBQ2xCLElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUNmLFFBQVEsQ0FBQyxTQUFTLENBQUMsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLEdBQUcsRUFBRSxHQUFHLFlBQVksR0FBRyxJQUFJLENBQUMsQ0FBQztTQUN6RTtRQUNELHVCQUF1QjtRQUN2Qiw4RUFBOEU7UUFDOUUsdURBQXVEO1FBQ3ZELFFBQVEsQ0FBQyxTQUFTLENBQUMsZUFBZSxFQUFFLG1CQUFtQixDQUFDLENBQUM7SUFDM0QsQ0FBQztJQUVEOzs7T0FHRztJQUNJLGdCQUFnQixDQUFDLFFBQTBCLEVBQUUsT0FBZ0I7UUFDbEUsSUFBSSxPQUFPLENBQUMsV0FBVyxFQUFFLEVBQUU7WUFDekIsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxHQUFHLEdBQUcsR0FBRyxPQUFPLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDcEUsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDMUI7YUFBTTtZQUNMLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksR0FBRyxHQUFHLEdBQUcsT0FBTyxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1NBQ3JFO1FBQ0QsTUFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN4QyxRQUFRLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDdEMsR0FBRyxFQUFFLFlBQVksQ0FBQyxHQUFHO1lBQ3JCLE9BQU8sRUFBRSxZQUFZLENBQUMsT0FBTztZQUM3QixJQUFJLEVBQUUsT0FBTyxDQUFDLElBQUk7U0FDbkIsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0ksTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFjO1FBQ2hDLE9BQU8sUUFBUSxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDeEQsQ0FBQztJQUVEOzs7T0FHRztJQUNJLHFCQUFxQixDQUFDLEdBQXFCLEVBQUUsR0FBVTtRQUM1RCxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ2YsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBQyxHQUFHLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBRSxHQUFHLEdBQUcsRUFBRSxFQUFDLENBQUMsQ0FBQztJQUM3RCxDQUFDO0lBNkRNLE9BQU8sQ0FDWixlQUdzQyxFQUN0QyxXQUFXLEdBQUcsR0FBRyxFQUNqQixPQUFpQixFQUNqQixZQUFzQjtRQUV0QixPQUFPLENBQUMsT0FBTyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsRUFBRTtZQUNqQyxnREFBZ0Q7WUFDaEQsT0FBTyxDQUFDLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFFdEQsa0NBQWtDO1lBQ2xDLE1BQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRWxELFFBQVEsQ0FBQyxPQUFPLEVBQUU7aUJBQ2YsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDVCx3QkFBd0I7Z0JBQ3hCLElBQUksT0FBTyxlQUFlLEtBQUssVUFBVSxFQUFFO29CQUN6QyxNQUFNLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLG1DQUFtQyxDQUFDLENBQUM7aUJBQ3BFO2dCQUVELCtDQUErQztnQkFFL0MsTUFBTSxPQUFPLEdBQ1gsWUFBWSxLQUFLLElBQUk7b0JBQ25CLENBQUMsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsUUFBUSxDQUFDO29CQUMvQyxDQUFDLENBQUMsb0ZBQW9GO3dCQUNwRixlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxPQUFPLEVBQUcsU0FBeUMsQ0FBQyxDQUFDO2dCQUV0RixzQ0FBc0M7Z0JBQ3RDLElBQUksT0FBTyxJQUFJLE9BQU8sS0FBSyxJQUFJLEVBQUU7b0JBQy9CLHFGQUFxRjtpQkFDdEY7cUJBQU0sSUFBSSxPQUFPLEtBQUssSUFBSSxJQUFJLE9BQU8sS0FBSyxTQUFTLEVBQUU7b0JBQ3BELE1BQU0sTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsNENBQTRDLENBQUMsQ0FBQztpQkFDN0U7cUJBQU0sSUFBSSxPQUFPLE9BQU8sQ0FBQyxJQUFJLEtBQUssVUFBVSxFQUFFO29CQUM3QyxNQUFNLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLDBDQUEwQyxDQUFDLENBQUM7aUJBQzNFO2dCQUVELHVDQUF1QztnQkFDdkMsT0FBTyxPQUFPLENBQUM7WUFDakIsQ0FBQyxDQUFDO2lCQUNELElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtnQkFDWCxVQUFVO2dCQUVWLElBQUksT0FBTyxJQUFJLElBQUksS0FBSyxJQUFJLEVBQUU7b0JBQzVCLHFGQUFxRjtpQkFDdEY7cUJBQU0sSUFBSSxPQUFPLElBQUksSUFBSSxFQUFFO29CQUMxQixpQ0FBaUM7b0JBQ2pDLElBQUksRUFBRSxDQUFDO2lCQUNSO3FCQUFNO29CQUNMLHVCQUF1QjtvQkFDdkIsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFFBQVEsRUFBRSxZQUFZLENBQUMsQ0FBQztvQkFDaEQsSUFBSSxXQUFXLEtBQUssR0FBRyxFQUFFO3dCQUN2Qiw0Q0FBNEM7d0JBQzVDLFFBQVEsQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxDQUFDLENBQUM7d0JBQ3hDLFFBQVEsQ0FBQyxTQUFTLENBQUMsY0FBYyxFQUFFLGtCQUFrQixDQUFDLENBQUM7d0JBQ3ZELFFBQVEsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7cUJBQ3BDO3lCQUFNLElBQUksV0FBVyxLQUFLLEdBQUcsSUFBSSxXQUFXLEtBQUssR0FBRyxFQUFFO3dCQUNyRCxvR0FBb0c7d0JBQ3BHLFdBQVcsR0FBRyxHQUFHLENBQUM7d0JBQ2xCLGtFQUFrRTt3QkFDbEUsUUFBUSxDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUUsSUFBYyxDQUFDLENBQUM7d0JBQy9DLFFBQVEsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7cUJBQ3REO3lCQUFNO3dCQUNMLFFBQVEsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUN6QztpQkFDRjtZQUNILENBQUMsQ0FBQztpQkFDRCxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsRUFBRTtnQkFDN0IsMkJBQTJCO2dCQUMzQixJQUFJLENBQUMsa0JBQWtCLENBQUMsUUFBUSxFQUFFLFlBQVksQ0FBQyxDQUFDO2dCQUNoRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQ3pDLENBQUMsQ0FBQztpQkFDRCxLQUFLLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQ2IsNEJBQTRCO2dCQUM1QixJQUFJLENBQUMsa0JBQWtCLENBQUMsUUFBUSxFQUFFLFlBQVksQ0FBQyxDQUFDO2dCQUNoRCxJQUFJLENBQUMscUJBQXFCLENBQUMsUUFBUSxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQzlDLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDO0lBQ0osQ0FBQztJQWlCTSxLQUFLLENBQ1YsZUFHbUMsRUFDbkMsWUFBc0I7UUFFdEIsT0FBTyxJQUFJLENBQUMsT0FBTztRQUNqQixhQUFhO1FBQ2IsZUFBdUQsRUFDdkQsU0FBUyxFQUNULElBQUksRUFDSixZQUFZLENBQ2IsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0ssTUFBTSxDQUFDLFFBQVEsQ0FBQyxPQUF3QixFQUFFLEdBQVcsRUFBRSxZQUFzQjtRQUNuRixNQUFNLFNBQVMsR0FBRyxPQUFPLENBQUMsTUFBTSxJQUFJLEVBQUUsQ0FBQztRQUN2QyxNQUFNLElBQUksR0FBRyxPQUFPLENBQUMsSUFBSSxJQUFJLEVBQUUsQ0FBQztRQUNoQyxNQUFNLEtBQUssR0FBRyxPQUFPLENBQUMsS0FBSyxJQUFJLEVBQUUsQ0FBQztRQUVsQyxNQUFNLFlBQVksR0FBRyxHQUFHO2FBQ3JCLEtBQUssQ0FBQyxXQUFXLENBQUM7YUFDbEIsSUFBSSxDQUFDLEdBQUcsQ0FBQzthQUNULFdBQVcsRUFBRSxDQUFDO1FBRWpCLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxTQUFTLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQ25FLE9BQU8sU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ3ZCO1FBQ0QsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFO1lBQzdCLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ2xCO1FBQ0QsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFO1lBQzlCLE9BQU8sS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ25CO1FBQ0QsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxFQUFFO1lBQ3ZDLE9BQU8sS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDO1NBQzVCO1FBRUQsT0FBTyxZQUFZLENBQUM7SUFDdEIsQ0FBQztDQUNGO0FBRUQsaUJBQVMsSUFBSSxHQUFHLENBQUMsR0FBRyxDQUFDLFVBQVUsRUFBRSxJQUFJLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDIn0=