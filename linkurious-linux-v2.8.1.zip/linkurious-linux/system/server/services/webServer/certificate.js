/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2015-05-07.
 */
'use strict';
const Promise = require('bluebird');
const fs = require('fs-extra');
const LKE = require('../index');
const Config = LKE.getConfig();
const Errors = LKE.getErrors();
class Certificate {
    /**
     * @returns {Bluebird<{cert: string, key: string, passphrase: string}>}
     */
    getKeyPair() {
        const certFile = LKE.dataFile(Config.get('server.certificateFile', undefined, true));
        const keyFile = LKE.dataFile(Config.get('server.certificateKeyFile', undefined, true));
        const passphrase = Config.get('server.certificatePassphrase');
        if (!fs.existsSync(certFile)) {
            return Errors.business('invalid_parameter', 'Configuration key "server.certificateFile" refers to an invalid file (' + certFile + ')', true);
        }
        if (!fs.existsSync(keyFile)) {
            return Errors.business('invalid_parameter', 'Configuration key "server.certificateKeyFile" refers to an invalid file (' + keyFile + ')', true);
        }
        return Promise.resolve({
            cert: fs.readFileSync(certFile, { encoding: 'utf8' }),
            key: fs.readFileSync(keyFile, { encoding: 'utf8' }),
            passphrase: passphrase
        });
    }
}
module.exports = new Certificate();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2VydGlmaWNhdGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvd2ViU2VydmVyL2NlcnRpZmljYXRlLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBQ2IsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3BDLE1BQU0sRUFBRSxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUMvQixNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDaEMsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUUvQixNQUFNLFdBQVc7SUFDZjs7T0FFRztJQUNILFVBQVU7UUFDUixNQUFNLFFBQVEsR0FBRyxHQUFHLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDckYsTUFBTSxPQUFPLEdBQUcsR0FBRyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLDJCQUEyQixFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQ3ZGLE1BQU0sVUFBVSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsOEJBQThCLENBQUMsQ0FBQztRQUU5RCxJQUFJLENBQUMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUM1QixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsbUJBQW1CLEVBQ3hDLHdFQUF3RSxHQUFHLFFBQVEsR0FBRyxHQUFHLEVBQ3pGLElBQUksQ0FDTCxDQUFDO1NBQ0g7UUFFRCxJQUFJLENBQUMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUMzQixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsbUJBQW1CLEVBQ3hDLDJFQUEyRSxHQUFHLE9BQU8sR0FBRyxHQUFHLEVBQzNGLElBQUksQ0FDTCxDQUFDO1NBQ0g7UUFFRCxPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUM7WUFDckIsSUFBSSxFQUFFLEVBQUUsQ0FBQyxZQUFZLENBQUMsUUFBUSxFQUFFLEVBQUMsUUFBUSxFQUFFLE1BQU0sRUFBQyxDQUFDO1lBQ25ELEdBQUcsRUFBRSxFQUFFLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRSxFQUFDLFFBQVEsRUFBRSxNQUFNLEVBQUMsQ0FBQztZQUNqRCxVQUFVLEVBQUUsVUFBVTtTQUN2QixDQUFDLENBQUM7SUFDTCxDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLElBQUksV0FBVyxFQUFFLENBQUMifQ==