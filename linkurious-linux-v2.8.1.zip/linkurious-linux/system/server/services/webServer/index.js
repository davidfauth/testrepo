/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-11-04.
 */
'use strict';
const http = require('http');
const https = require('https');
const Express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const sessionStore = require('express-session');
const compression = require('compression');
const cookieParser = require('../../../lib/CookieParser');
const morgan = require('morgan');
const Promise = require('bluebird');
const onHeaders = require('on-headers');
const LKE = require('../index');
const Config = LKE.getConfig();
const Errors = LKE.getErrors();
const Utils = LKE.getUtils();
const Access = LKE.getAccess();
const Log = LKE.getLogger(__filename);
const certificate = require('./certificate');
// constants
const DOMAIN_PATTERN = '[a-z][a-z0-9\\-]*[a-z0-9]';
const ALLOW_ORIGIN_WILDCARD_RE = new RegExp('^(https?://)?(\\*\\.)((?:' + DOMAIN_PATTERN + '\\.)+[a-z0-9]+(?::[0-9]+)?)$');
const REQUEST_TIMEOUT_MS = 10 * 60 * 1000; // 10 minutes
const GLOBAL_HEADERS = {
    // Tell client to only send a Referer header in same-origin requests
    'Referrer-Policy': 'same-origin'
};
class WebServerService {
    /**
     */
    constructor() {
        /** @type {Express} */
        this.app = undefined;
        /** @type {http.Server} */
        this.httpServer = undefined;
        /** @type {https.Server} */
        this.httpsServer = undefined;
    }
    /**
     * @param {Express.Router} router
     * @param {string} basePath
     * @returns {Express} app
     */
    createApp(router, basePath) {
        const app = Express();
        app.disable('x-powered-by');
        app.set('env', LKE.options.mode);
        app.use(basePath, router);
        return app;
    }
    /**
     * @returns {Express.Router}
     */
    createRouter() {
        const router = Express.Router();
        // enable compression
        router.use(compression());
        // every request will fail if no response is sent after REQUEST_TIMEOUT_MS
        router.use((req, res, next) => {
            req.setTimeout(REQUEST_TIMEOUT_MS);
            next();
        });
        // logging: use morgan for formatting and forward to our logger
        router.use(morgan('common', {
            stream: { write: message => Log.debug(message.slice(0, -1)) },
            skip: (req, _res) => req.originalUrl.indexOf('/api/') < 0
        }));
        // Key used to store the cookie in the browser
        const cookieName = 'linkurious.session';
        // sessions : set cookie parser
        router.use(cookieParser(Config.get('server.cookieSecret'), cookieName, (cookies, cb) => {
            // Here we decide which cookie to use if more than one is defined. Issue #804
            Promise.map(cookies, cookie => {
                return new Promise(resolve => {
                    Access.sessionStore.get(cookie, (err, res) => { resolve(res); });
                });
            }).then(sessions => {
                // return the first cookie for which a session is defined
                for (const s of sessions) {
                    if (s && s.id) {
                        return cb(s.id);
                    }
                }
                cb();
            });
        }));
        // sessions : use memory store
        const sessionOptions = {
            secret: Config.get('server.cookieSecret'),
            resave: false,
            saveUninitialized: true,
            name: cookieName,
            rolling: false,
            store: Access.sessionStore,
            cookie: {
                // cookies are set https and http
                secure: false,
                // cookies can be set via javascript
                httpOnly: false,
                // cookies are set for all paths
                path: '/',
                // cookies are wiped when the browser is closed (session cookie)
                maxAge: null
            }
        };
        const cookieDomain = Config.get('server.cookieDomain');
        if (cookieDomain && cookieDomain !== 'localhost' && cookieDomain !== '127.0.0.1') {
            sessionOptions.cookie.domain = cookieDomain;
        }
        router.use((req, res, next) => {
            // Headers for all requests
            res.set(GLOBAL_HEADERS);
            onHeaders(res, function () {
                // avoid to do a set-cookie if the session is invalid on the server
                if (Utils.noValue(this.req.session) ||
                    Utils.noValue(this.req.session.userId) && Utils.noValue(this.req.session.twoStageAuth)) {
                    this.removeHeader('set-cookie');
                }
            });
            next();
        });
        router.use(sessionStore(sessionOptions));
        router.use('/api', Access.checkUserSession.bind(Access));
        router.use('/api', Access.checkApplication.bind(Access));
        // parse JSON body (limit POST/PUT size to 2MB)
        router.use(bodyParser.json({
            // deflated (compressed) bodies will be inflated
            inflate: true,
            //  maximum request body size (2MB)
            limit: '2000kb',
            // will only accept arrays and objects;
            strict: true
        }));
        // parse x-www-form-urlencoded body
        router.use(bodyParser.urlencoded({ extended: true }));
        router.use((req, res, nextRoute) => {
            if (req.path.match(/\/api/)) {
                if (LKE.isTestMode() || LKE.isDevMode()) {
                    const requestStart = Date.now();
                    /**
                     * Respond to an API call.
                     * Legacy method, use `api.respond` instead.
                     *
                     * @param {number} code the HTTP response code
                     * @param {object} data the data to send as HTTP response
                     * @deprecated
                     */
                    res.apiReturn = function (code, data) {
                        res.setHeader('X-Response-Time', (Date.now() - requestStart) + 'ms');
                        if (typeof code === 'object' && code.code && code.key) {
                            res.status(code.code).json({
                                key: code.key,
                                message: code.message
                            });
                        }
                        else {
                            res.status(code).json(data);
                        }
                    };
                }
            }
            else {
                // allow any origin for non-API resources
                res.setHeader('Access-Control-Allow-Origin', '*');
            }
            nextRoute();
        });
        return router;
    }
    /**
     * @returns {Promise}
     */
    start() {
        const portHttp = Config.get('server.listenPort', 3000);
        const useHttps = Config.get('server.useHttps', false);
        const portHttps = Config.get('server.listenPortHttps', 3443);
        const baseFolder = Config.get('server.baseFolder');
        const basePath = Utils.hasValue(baseFolder) ? `/${baseFolder}/` : '/';
        // listen for clients
        return Promise.resolve().then(() => {
            this.router = this.createRouter();
            this.app = this.createApp(this.router, basePath);
            // load CORS module
            this._configureCORS();
            // load API routes
            require('./routesLoader')(this.router, basePath);
            if (!useHttps) {
                return;
            }
            // read or generate SSL certificate
            return certificate.getKeyPair().then(certificate => {
                // create + start HTTPS server
                this.httpsServer = https.createServer(certificate, this.app);
                return this._listen(this.httpsServer, portHttps, true);
            });
        }).then(() => {
            // create + start HTTP server
            this.httpServer = http.createServer(this.app);
            return this._listen(this.httpServer, portHttp, false);
        }).then(() => {
            return LKE.getStateMachine().set('WebServer', 'ready', `The Web server is listening on port ${portHttp} (HTTP)` +
                (useHttps ? ` and port ${portHttps} (HTTPS)` : ''));
        });
    }
    _configureCORS() {
        // see https://github.com/expressjs/cors
        const corsOptions = {
            methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS', 'HEAD'],
            allowHeaders: [
                'X-Requested-With', 'Content-Type', 'Content-Length', 'Accept', 'Authorization'
            ],
            credentials: true
        };
        // fix parameter
        let allowOrigin = Config.get('server.allowOrigin');
        if (Utils.noValue(allowOrigin)) {
            corsOptions.origin = false;
            Log.info('WebServer CORS: disabled.');
        }
        else if (allowOrigin === '*') {
            corsOptions.origin = true;
            Log.info('WebServer CORS: allowing all origins (*).');
        }
        else {
            if (typeof allowOrigin === 'string') {
                allowOrigin = [allowOrigin];
            }
            if (Array.isArray(allowOrigin)) {
                corsOptions.origin = [];
                allowOrigin.forEach(origin => {
                    let m;
                    if ((m = origin.match(ALLOW_ORIGIN_WILDCARD_RE)) !== null) {
                        const scheme = m[1] || 'https?://';
                        if (m[2] === '*.') {
                            const pattern = `^${scheme}(${DOMAIN_PATTERN}\\.)*${m[3].replace(/\./g, '\\.')}$`;
                            corsOptions.origin.push(new RegExp(pattern));
                        }
                    }
                    else if (origin.match(/^https?:\/\//)) {
                        corsOptions.origin.push(origin);
                    }
                    else {
                        corsOptions.origin.push('http://' + origin);
                        corsOptions.origin.push('https://' + origin);
                    }
                });
                corsOptions.origin.forEach(o => {
                    Log.info('WebServer CORS: allowing origin ' +
                        (o instanceof RegExp ? '[pattern] ' + o.toString() : '"' + o + '"'));
                });
            }
            else {
                throw Errors.business('invalid_configuration', 'Configuration key "server.allowOrigin" must be "*", a domain or an array of domains.');
            }
        }
        this.router.use(cors(corsOptions));
    }
    /**
     * @param {HttpServer} server
     * @param {number} port
     * @param {boolean} https
     * @returns {Promise}
     * @private
     */
    _listen(server, port, https) {
        Utils.check.integer('server.listenPort' + (https ? 'Https' : ''), port, 1, 65535);
        return new Promise((resolve, reject) => {
            server.listen(port, () => {
                resolve();
            }).on('error', e => {
                // error handler for ALL uncaught server exceptions
                if (e && e.errno && e.errno === 'EADDRINUSE') {
                    LKE.getStateMachine().set('WebServer', 'port_busy');
                    reject(Errors.technical('port_busy', 'The WebServer HTTP' + (https ? 'S' : '') + ' port (' + port + ') is already used.'));
                }
                else if (e && e.errno && e.errno === 'EACCES') {
                    LKE.getStateMachine().set('WebServer', 'port_restricted');
                    reject(Errors.technical('port_restricted', 'The WebServer HTTP' + (https ? 'S' : '') + ' port (' + port + ') needs root access. ' +
                        'You could use a higher port and redirect it to ' + port + ' using "iptables".'));
                }
                else {
                    LKE.getStateMachine().set('WebServer', 'error');
                    reject(e);
                }
            });
        });
    }
}
module.exports = new WebServerService();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvd2ViU2VydmVyL2luZGV4LmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBQ2IsTUFBTSxJQUFJLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQzdCLE1BQU0sS0FBSyxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUMvQixNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDbkMsTUFBTSxJQUFJLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQzdCLE1BQU0sVUFBVSxHQUFHLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUMxQyxNQUFNLFlBQVksR0FBRyxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQztBQUNoRCxNQUFNLFdBQVcsR0FBRyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUM7QUFDM0MsTUFBTSxZQUFZLEdBQUcsT0FBTyxDQUFDLDJCQUEyQixDQUFDLENBQUM7QUFDMUQsTUFBTSxNQUFNLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ2pDLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNwQyxNQUFNLFNBQVMsR0FBRyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDeEMsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ2hDLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzdCLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3RDLE1BQU0sV0FBVyxHQUFHLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQztBQUU3QyxZQUFZO0FBQ1osTUFBTSxjQUFjLEdBQUcsMkJBQTJCLENBQUM7QUFDbkQsTUFBTSx3QkFBd0IsR0FBRyxJQUFJLE1BQU0sQ0FDekMsMkJBQTJCLEdBQUcsY0FBYyxHQUFHLDhCQUE4QixDQUM5RSxDQUFDO0FBQ0YsTUFBTSxrQkFBa0IsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQyxDQUFDLGFBQWE7QUFDeEQsTUFBTSxjQUFjLEdBQUc7SUFDckIsb0VBQW9FO0lBQ3BFLGlCQUFpQixFQUFFLGFBQWE7Q0FDakMsQ0FBQztBQUVGLE1BQU0sZ0JBQWdCO0lBRXBCO09BQ0c7SUFDSDtRQUNFLHNCQUFzQjtRQUN0QixJQUFJLENBQUMsR0FBRyxHQUFHLFNBQVMsQ0FBQztRQUVyQiwwQkFBMEI7UUFDMUIsSUFBSSxDQUFDLFVBQVUsR0FBRyxTQUFTLENBQUM7UUFFNUIsMkJBQTJCO1FBQzNCLElBQUksQ0FBQyxXQUFXLEdBQUcsU0FBUyxDQUFDO0lBQy9CLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsU0FBUyxDQUFDLE1BQU0sRUFBRSxRQUFRO1FBQ3hCLE1BQU0sR0FBRyxHQUFHLE9BQU8sRUFBRSxDQUFDO1FBRXRCLEdBQUcsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLENBQUM7UUFDNUIsR0FBRyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUVqQyxHQUFHLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxNQUFNLENBQUMsQ0FBQztRQUUxQixPQUFPLEdBQUcsQ0FBQztJQUNiLENBQUM7SUFFRDs7T0FFRztJQUNILFlBQVk7UUFDVixNQUFNLE1BQU0sR0FBRyxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUM7UUFFaEMscUJBQXFCO1FBQ3JCLE1BQU0sQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQztRQUUxQiwwRUFBMEU7UUFDMUUsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLEVBQUU7WUFDNUIsR0FBRyxDQUFDLFVBQVUsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO1lBQ25DLElBQUksRUFBRSxDQUFDO1FBQ1QsQ0FBQyxDQUFDLENBQUM7UUFFSCwrREFBK0Q7UUFDL0QsTUFBTSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFO1lBQzFCLE1BQU0sRUFBRSxFQUFDLEtBQUssRUFBRSxPQUFPLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDO1lBQzNELElBQUksRUFBRSxDQUFDLEdBQUcsRUFBRSxJQUFJLEVBQUUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUM7U0FDMUQsQ0FBQyxDQUFDLENBQUM7UUFFSiw4Q0FBOEM7UUFDOUMsTUFBTSxVQUFVLEdBQUcsb0JBQW9CLENBQUM7UUFFeEMsK0JBQStCO1FBQy9CLE1BQU0sQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMscUJBQXFCLENBQUMsRUFBRSxVQUFVLEVBQUUsQ0FBQyxPQUFPLEVBQUUsRUFBRSxFQUFFLEVBQUU7WUFDckYsNkVBQTZFO1lBQzdFLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxFQUFFO2dCQUM1QixPQUFPLElBQUksT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFFO29CQUMzQixNQUFNLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEVBQUUsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDbkUsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7Z0JBQ2pCLHlEQUF5RDtnQkFDekQsS0FBSyxNQUFNLENBQUMsSUFBSSxRQUFRLEVBQUU7b0JBQ3hCLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLEVBQUU7d0JBQ2IsT0FBTyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO3FCQUNqQjtpQkFDRjtnQkFDRCxFQUFFLEVBQUUsQ0FBQztZQUNQLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVKLDhCQUE4QjtRQUM5QixNQUFNLGNBQWMsR0FBRztZQUNyQixNQUFNLEVBQUUsTUFBTSxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsQ0FBQztZQUN6QyxNQUFNLEVBQUUsS0FBSztZQUNiLGlCQUFpQixFQUFFLElBQUk7WUFDdkIsSUFBSSxFQUFFLFVBQVU7WUFDaEIsT0FBTyxFQUFFLEtBQUs7WUFDZCxLQUFLLEVBQUUsTUFBTSxDQUFDLFlBQVk7WUFDMUIsTUFBTSxFQUFFO2dCQUNOLGlDQUFpQztnQkFDakMsTUFBTSxFQUFFLEtBQUs7Z0JBQ2Isb0NBQW9DO2dCQUNwQyxRQUFRLEVBQUUsS0FBSztnQkFDZixnQ0FBZ0M7Z0JBQ2hDLElBQUksRUFBRSxHQUFHO2dCQUNULGdFQUFnRTtnQkFDaEUsTUFBTSxFQUFFLElBQUk7YUFDYjtTQUNGLENBQUM7UUFDRixNQUFNLFlBQVksR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLHFCQUFxQixDQUFDLENBQUM7UUFDdkQsSUFBSSxZQUFZLElBQUksWUFBWSxLQUFLLFdBQVcsSUFBSSxZQUFZLEtBQUssV0FBVyxFQUFFO1lBQ2hGLGNBQWMsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLFlBQVksQ0FBQztTQUM3QztRQUVELE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxFQUFFO1lBQzVCLDJCQUEyQjtZQUMzQixHQUFHLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxDQUFDO1lBRXhCLFNBQVMsQ0FBQyxHQUFHLEVBQUU7Z0JBQ2IsbUVBQW1FO2dCQUNuRSxJQUNFLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUM7b0JBQy9CLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsRUFDdEY7b0JBQ0EsSUFBSSxDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsQ0FBQztpQkFDakM7WUFDSCxDQUFDLENBQUMsQ0FBQztZQUVILElBQUksRUFBRSxDQUFDO1FBQ1QsQ0FBQyxDQUFDLENBQUM7UUFFSCxNQUFNLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDO1FBQ3pDLE1BQU0sQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUN6RCxNQUFNLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFFekQsK0NBQStDO1FBQy9DLE1BQU0sQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQztZQUN6QixnREFBZ0Q7WUFDaEQsT0FBTyxFQUFFLElBQUk7WUFDYixtQ0FBbUM7WUFDbkMsS0FBSyxFQUFFLFFBQVE7WUFDZix1Q0FBdUM7WUFDdkMsTUFBTSxFQUFFLElBQUk7U0FDYixDQUFDLENBQUMsQ0FBQztRQUVKLG1DQUFtQztRQUNuQyxNQUFNLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFDLENBQUMsQ0FBQyxDQUFDO1FBRXBELE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLFNBQVMsRUFBRSxFQUFFO1lBQ2pDLElBQUksR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEVBQUU7Z0JBQzNCLElBQUksR0FBRyxDQUFDLFVBQVUsRUFBRSxJQUFJLEdBQUcsQ0FBQyxTQUFTLEVBQUUsRUFBRTtvQkFDdkMsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO29CQUVoQzs7Ozs7Ozt1QkFPRztvQkFDSCxHQUFHLENBQUMsU0FBUyxHQUFHLFVBQVMsSUFBSSxFQUFFLElBQUk7d0JBQ2pDLEdBQUcsQ0FBQyxTQUFTLENBQUMsaUJBQWlCLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsWUFBWSxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUM7d0JBRXJFLElBQUksT0FBTyxJQUFJLEtBQUssUUFBUSxJQUFJLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLEdBQUcsRUFBRTs0QkFDckQsR0FBRyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDO2dDQUN6QixHQUFHLEVBQUUsSUFBSSxDQUFDLEdBQUc7Z0NBQ2IsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPOzZCQUN0QixDQUFDLENBQUM7eUJBQ0o7NkJBQU07NEJBQ0wsR0FBRyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7eUJBQzdCO29CQUNILENBQUMsQ0FBQztpQkFDSDthQUNGO2lCQUFNO2dCQUNMLHlDQUF5QztnQkFDekMsR0FBRyxDQUFDLFNBQVMsQ0FBQyw2QkFBNkIsRUFBRSxHQUFHLENBQUMsQ0FBQzthQUNuRDtZQUVELFNBQVMsRUFBRSxDQUFDO1FBQ2QsQ0FBQyxDQUFDLENBQUM7UUFFSCxPQUFPLE1BQU0sQ0FBQztJQUNoQixDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLO1FBQ0gsTUFBTSxRQUFRLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUN2RCxNQUFNLFFBQVEsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLGlCQUFpQixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQ3RELE1BQU0sU0FBUyxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDN0QsTUFBTSxVQUFVLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1FBQ25ELE1BQU0sUUFBUSxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztRQUV0RSxxQkFBcUI7UUFDckIsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNqQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUNsQyxJQUFJLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxRQUFRLENBQUMsQ0FBQztZQUVqRCxtQkFBbUI7WUFDbkIsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1lBRXRCLGtCQUFrQjtZQUNsQixPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1lBRWpELElBQUksQ0FBQyxRQUFRLEVBQUU7Z0JBQ2IsT0FBTzthQUNSO1lBQ0QsbUNBQW1DO1lBQ25DLE9BQU8sV0FBVyxDQUFDLFVBQVUsRUFBRSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTtnQkFDakQsOEJBQThCO2dCQUM5QixJQUFJLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQyxZQUFZLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDN0QsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQ3pELENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNYLDZCQUE2QjtZQUM3QixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQzlDLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUN4RCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1gsT0FBTyxHQUFHLENBQUMsZUFBZSxFQUFFLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxPQUFPLEVBQ25ELHVDQUF1QyxRQUFRLFNBQVM7Z0JBQ3hELENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxhQUFhLFNBQVMsVUFBVSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FDbkQsQ0FBQztRQUNKLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVELGNBQWM7UUFDWix3Q0FBd0M7UUFDeEMsTUFBTSxXQUFXLEdBQUc7WUFDbEIsT0FBTyxFQUFFLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxTQUFTLEVBQUUsTUFBTSxDQUFDO1lBQ3JFLFlBQVksRUFBRTtnQkFDWixrQkFBa0IsRUFBRSxjQUFjLEVBQUUsZ0JBQWdCLEVBQUUsUUFBUSxFQUFFLGVBQWU7YUFDaEY7WUFDRCxXQUFXLEVBQUUsSUFBSTtTQUNsQixDQUFDO1FBRUYsZ0JBQWdCO1FBQ2hCLElBQUksV0FBVyxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUMsQ0FBQztRQUNuRCxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDOUIsV0FBVyxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7WUFDM0IsR0FBRyxDQUFDLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxDQUFDO1NBQ3ZDO2FBQU0sSUFBSSxXQUFXLEtBQUssR0FBRyxFQUFFO1lBQzlCLFdBQVcsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO1lBQzFCLEdBQUcsQ0FBQyxJQUFJLENBQUMsMkNBQTJDLENBQUMsQ0FBQztTQUN2RDthQUFNO1lBQ0wsSUFBSSxPQUFPLFdBQVcsS0FBSyxRQUFRLEVBQUU7Z0JBQ25DLFdBQVcsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDO2FBQzdCO1lBQ0QsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxFQUFFO2dCQUM5QixXQUFXLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztnQkFDeEIsV0FBVyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRTtvQkFDM0IsSUFBSSxDQUFDLENBQUM7b0JBQ04sSUFBSSxDQUFDLENBQUMsR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLHdCQUF3QixDQUFDLENBQUMsS0FBSyxJQUFJLEVBQUU7d0JBQ3pELE1BQU0sTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxXQUFXLENBQUM7d0JBQ25DLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLElBQUksRUFBRTs0QkFDakIsTUFBTSxPQUFPLEdBQUcsSUFBSSxNQUFNLElBQUksY0FBYyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQyxHQUFHLENBQUM7NEJBQ2xGLFdBQVcsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7eUJBQzlDO3FCQUNGO3lCQUFNLElBQUksTUFBTSxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsRUFBRTt3QkFDdkMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7cUJBRWpDO3lCQUFNO3dCQUNMLFdBQVcsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsR0FBRyxNQUFNLENBQUMsQ0FBQzt3QkFDNUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQyxDQUFDO3FCQUM5QztnQkFDSCxDQUFDLENBQUMsQ0FBQztnQkFFSCxXQUFXLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTtvQkFDN0IsR0FBRyxDQUFDLElBQUksQ0FBQyxrQ0FBa0M7d0JBQ3pDLENBQUMsQ0FBQyxZQUFZLE1BQU0sQ0FBQyxDQUFDLENBQUMsWUFBWSxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FDcEUsQ0FBQztnQkFDSixDQUFDLENBQUMsQ0FBQzthQUNKO2lCQUFNO2dCQUNMLE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FDbkIsdUJBQXVCLEVBQ3ZCLHNGQUFzRixDQUN2RixDQUFDO2FBQ0g7U0FDRjtRQUNELElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxPQUFPLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxLQUFLO1FBQ3pCLEtBQUssQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLG1CQUFtQixHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDbEYsT0FBTyxJQUFJLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsRUFBRTtZQUNyQyxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxHQUFHLEVBQUU7Z0JBQ3ZCLE9BQU8sRUFBRSxDQUFDO1lBQ1osQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsRUFBRTtnQkFDakIsbURBQW1EO2dCQUNuRCxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxLQUFLLEtBQUssWUFBWSxFQUFFO29CQUM1QyxHQUFHLENBQUMsZUFBZSxFQUFFLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxXQUFXLENBQUMsQ0FBQztvQkFDcEQsTUFBTSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsV0FBVyxFQUNqQyxvQkFBb0IsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxTQUFTLEdBQUcsSUFBSSxHQUFHLG9CQUFvQixDQUNwRixDQUFDLENBQUM7aUJBQ0o7cUJBQU0sSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLENBQUMsS0FBSyxLQUFLLFFBQVEsRUFBRTtvQkFDL0MsR0FBRyxDQUFDLGVBQWUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztvQkFDMUQsTUFBTSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsaUJBQWlCLEVBQ3ZDLG9CQUFvQixHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFNBQVMsR0FBRyxJQUFJLEdBQUcsdUJBQXVCO3dCQUN0RixpREFBaUQsR0FBRyxJQUFJLEdBQUcsb0JBQW9CLENBQ2hGLENBQUMsQ0FBQztpQkFDSjtxQkFBTTtvQkFDTCxHQUFHLENBQUMsZUFBZSxFQUFFLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxPQUFPLENBQUMsQ0FBQztvQkFDaEQsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUNYO1lBQ0gsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsSUFBSSxnQkFBZ0IsRUFBRSxDQUFDIn0=