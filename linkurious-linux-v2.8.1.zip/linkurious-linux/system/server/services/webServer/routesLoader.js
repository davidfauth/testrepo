/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-10-15.
 */
'use strict';
const fs = require('fs-extra');
const path = require('path');
const urlParser = require('url');
const Promise = require('bluebird');
const serveStatic = require('serve-static');
const express = require('express');
const LKE = require('../index');
const Config = LKE.getConfig();
const Errors = LKE.getErrors();
const Utils = LKE.getUtils();
const Log = LKE.getLogger(__filename);
const { WidgetRoute } = require('./WidgetRoute');
// constants
// Tells any cache that it does not need to send a HEAD request to re-validate the response
// during 30 seconds. After that a HEAD request if sent to check the etag.
const STATIC_MAX_AGE_SECONDS = 30;
function loadPlugins(app) {
    try {
        // create base router for plugins
        const basePluginsRouter = express.Router({ caseSensitive: false });
        const pluginsRoute = '/api/plugin';
        app.use(pluginsRoute, basePluginsRouter);
        // check root folder for plugin files
        const pluginRoot = LKE.dataFile('plugins');
        if (!fs.existsSync(pluginRoot)) {
            // plugin root does not exist
            return;
        }
        if (!fs.statSync(pluginRoot).isDirectory()) {
            // plugin root is not a directory
            return;
        }
        // read all JS files in plugin root
        fs.readdirSync(pluginRoot).filter(file => file.endsWith('.js')).forEach(filename => {
            const pluginName = filename.slice(0, -3);
            // load plugin
            try {
                Log.info(`Loading plugin "${pluginName}"...`);
                const pluginPath = path.join(pluginRoot, filename);
                const plugin = require(pluginPath);
                if (plugin && typeof plugin.load === 'function') {
                    const pluginRouter = express.Router({});
                    basePluginsRouter.use('/' + pluginName, pluginRouter);
                    plugin.load(LKE, pluginRouter);
                }
                Log.info(`Successfully loaded plugin "${pluginName}" in route "${pluginsRoute}/${pluginName}".`);
            }
            catch (error) {
                Log.error(`Could not load plugin "${pluginName}"`, error);
            }
        });
    }
    catch (error) {
        Log.error('Error while loading Linkurious plugins', error);
    }
}
/**
 * @param {Express.Router} router
 * @param {string} basePath (must start and end with a "/")
 */
module.exports = function routesLoader(router, basePath) {
    const api = require('./api');
    // 1) force HTTPS
    const forceHttps = Config.get('server.forceHttps');
    const httpsPort = Config.get('server.publicPortHttps', Config.get('server.listenPortHttps'));
    router.all('*', api.proxy((req, res) => {
        const isHttps = Utils.isRequestHTTPS(req);
        if (!isHttps && forceHttps) {
            if (req.method === 'GET') {
                // redirect to https version
                const targetUrl = `https://${req.hostname.split(':')[0]}:${httpsPort}${req.originalUrl}`;
                res.redirect(302, targetUrl);
                return null;
            }
            else {
                // fail
                return Errors.business('https_required', null, true);
            }
        }
        return Promise.resolve();
    }, true));
    // 2) client CUSTOM static files
    const customFilesPath = LKE.dataFile('server/customFiles');
    const defaultCustomFilesPath = path.resolve(__dirname, 'customFiles');
    const previousCustomCSS = LKE.systemFile('server.old/public/assets/css/override.css');
    if (!fs.existsSync(customFilesPath)) {
        // custom files dir does not exist in "data/" yet : create it from default files
        Log.debug('Creating "customFiles" from default files');
        fs.copySync(defaultCustomFilesPath, customFilesPath);
        if (fs.existsSync(previousCustomCSS)) {
            Log.debug('Copying override.css from "server.old" to "data"');
            // a previous custom CSS file exists: move it to the custom files dir
            fs.copySync(previousCustomCSS, path.resolve(customFilesPath, 'assets', 'css', 'override.css'));
        }
    }
    // 2.1) create icons folder under customFiles
    const iconsFolderPath = path.resolve(customFilesPath, 'icons');
    fs.ensureDirSync(iconsFolderPath);
    // see https://github.com/expressjs/serve-static#servestaticroot-options
    const serveStaticOptions = {
        fallthrough: true,
        extensions: false,
        dotfiles: 'ignore',
        etag: true,
        cacheControl: false,
        setHeaders: res => {
            res.setHeader('Cache-Control', 'public, must-revalidate, max-age=' + STATIC_MAX_AGE_SECONDS);
        }
    };
    router.use(serveStatic(customFilesPath, serveStaticOptions));
    const clientRoot = LKE.systemFile(Config.get('server.clientFolder'));
    // 3.1) index.html
    const indexPath = path.resolve(clientRoot, 'index.html');
    let indexHtml = null;
    const serveIndex = (req, res) => {
        if (indexHtml === null || !LKE.isProdMode()) {
            // first pass OR not in prod: load index.html from disk
            if (!fs.existsSync(indexPath)) {
                // index not found: respond with 404
                return res.status(404).send();
            }
            // read index.html from disk
            indexHtml = fs.readFileSync(indexPath, { encoding: 'utf8' });
        }
        // patch "<base>" element (needed for the Angular router)
        const indexBody = indexHtml.replace('<base href="/">', `<base href="${basePath}">`);
        res
            .status(200)
            .header('Cache-control', catchAllSendOptions.headers['Cache-control'])
            .send(indexBody);
    };
    router.get('/', serveIndex);
    // 3.2) client BUILTIN static files
    router.use(serveStatic(clientRoot, serveStaticOptions));
    // 4.1) Builtin API routes
    function requireRoutesFiles(directory) {
        fs.readdirSync(directory).filter(file => {
            return (file.indexOf('.') !== 0); // skip files starting with a '.'
        }).forEach(file => {
            const filePath = path.join(directory, file);
            if (fs.statSync(filePath).isDirectory()) {
                requireRoutesFiles(filePath);
            }
            else {
                require(filePath)(router);
            }
        });
    }
    requireRoutesFiles(path.resolve(__dirname, '..', '..', 'routes'));
    // 4.2) Plugin API routes
    loadPlugins(router);
    // 5) fail correctly on bad API calls
    router.all('/api/*', api.respond(() => {
        throw Errors.business('api_not_found');
    }));
    // 6) Widget
    new WidgetRoute(clientRoot, basePath).load(router);
    // 7) serve 'index.html' for all the rest
    // see https://expressjs.com/en/api.html#res.sendFile
    const catchAllSendOptions = {
        cacheControl: false,
        lastModified: false,
        root: clientRoot,
        headers: {
            'Cache-control': 'public, must-revalidate, max-age=' + STATIC_MAX_AGE_SECONDS
        }
    };
    const extensionsWith404 = ['ico', 'js', 'map', 'css', 'jpg', 'png', 'gif'].reduce((acc, ext) => {
        acc[ext] = true;
        return acc;
    }, {});
    router.get('/*', (req, res) => {
        // If URL ends in extensionsWith404 (which should have been served at step #2 or #3),
        // send an actual 404
        let actual404 = false;
        const pathname = urlParser.parse(req.url).pathname;
        const dotIndex = pathname.lastIndexOf('.');
        if (dotIndex > 0) {
            const extension = pathname.substr(dotIndex + 1);
            actual404 = (extensionsWith404[extension] === true);
        }
        if (actual404) {
            // cache 404s for 60 seconds
            res.status(404).send('Not found.');
            return;
        }
        // For all other URLs, send index.html
        serveIndex(req, res);
    });
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGVzTG9hZGVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL3NlcnZpY2VzL3dlYlNlcnZlci9yb3V0ZXNMb2FkZXIuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFDYixNQUFNLEVBQUUsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDL0IsTUFBTSxJQUFJLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQzdCLE1BQU0sU0FBUyxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNqQyxNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDcEMsTUFBTSxXQUFXLEdBQUcsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDO0FBQzVDLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUNuQyxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDaEMsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxHQUFHLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUN0QyxNQUFNLEVBQUMsV0FBVyxFQUFDLEdBQUcsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDO0FBRS9DLFlBQVk7QUFDWiwyRkFBMkY7QUFDM0YsMEVBQTBFO0FBQzFFLE1BQU0sc0JBQXNCLEdBQUcsRUFBRSxDQUFDO0FBRWxDLFNBQVMsV0FBVyxDQUFDLEdBQUc7SUFDdEIsSUFBSTtRQUNGLGlDQUFpQztRQUNqQyxNQUFNLGlCQUFpQixHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBQyxhQUFhLEVBQUUsS0FBSyxFQUFDLENBQUMsQ0FBQztRQUNqRSxNQUFNLFlBQVksR0FBRyxhQUFhLENBQUM7UUFDbkMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxZQUFZLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztRQUV6QyxxQ0FBcUM7UUFDckMsTUFBTSxVQUFVLEdBQUcsR0FBRyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUMzQyxJQUFJLENBQUMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsRUFBRTtZQUM5Qiw2QkFBNkI7WUFDN0IsT0FBTztTQUNSO1FBQ0QsSUFBSSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsV0FBVyxFQUFFLEVBQUU7WUFDMUMsaUNBQWlDO1lBQ2pDLE9BQU87U0FDUjtRQUVELG1DQUFtQztRQUNuQyxFQUFFLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDakYsTUFBTSxVQUFVLEdBQUcsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUV6QyxjQUFjO1lBQ2QsSUFBSTtnQkFDRixHQUFHLENBQUMsSUFBSSxDQUFDLG1CQUFtQixVQUFVLE1BQU0sQ0FBQyxDQUFDO2dCQUM5QyxNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxRQUFRLENBQUMsQ0FBQztnQkFDbkQsTUFBTSxNQUFNLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO2dCQUVuQyxJQUFJLE1BQU0sSUFBSSxPQUFPLE1BQU0sQ0FBQyxJQUFJLEtBQUssVUFBVSxFQUFFO29CQUMvQyxNQUFNLFlBQVksR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO29CQUN4QyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsR0FBRyxHQUFHLFVBQVUsRUFBRSxZQUFZLENBQUMsQ0FBQztvQkFDdEQsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsWUFBWSxDQUFDLENBQUM7aUJBQ2hDO2dCQUNELEdBQUcsQ0FBQyxJQUFJLENBQ04sK0JBQStCLFVBQVUsZUFBZSxZQUFZLElBQUksVUFBVSxJQUFJLENBQ3ZGLENBQUM7YUFDSDtZQUFDLE9BQU0sS0FBSyxFQUFFO2dCQUNiLEdBQUcsQ0FBQyxLQUFLLENBQUMsMEJBQTBCLFVBQVUsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDO2FBQzNEO1FBQ0gsQ0FBQyxDQUFDLENBQUM7S0FFSjtJQUFDLE9BQU0sS0FBSyxFQUFFO1FBQ2IsR0FBRyxDQUFDLEtBQUssQ0FBQyx3Q0FBd0MsRUFBRSxLQUFLLENBQUMsQ0FBQztLQUM1RDtBQUNILENBQUM7QUFFRDs7O0dBR0c7QUFDSCxNQUFNLENBQUMsT0FBTyxHQUFHLFNBQVMsWUFBWSxDQUFDLE1BQU0sRUFBRSxRQUFRO0lBQ3JELE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUU3QixpQkFBaUI7SUFDakIsTUFBTSxVQUFVLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0lBQ25ELE1BQU0sU0FBUyxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLEVBQUUsTUFBTSxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDLENBQUM7SUFDN0YsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsRUFBRTtRQUVyQyxNQUFNLE9BQU8sR0FBRyxLQUFLLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQzFDLElBQUksQ0FBQyxPQUFPLElBQUksVUFBVSxFQUFFO1lBQzFCLElBQUksR0FBRyxDQUFDLE1BQU0sS0FBSyxLQUFLLEVBQUU7Z0JBQ3hCLDRCQUE0QjtnQkFDNUIsTUFBTSxTQUFTLEdBQUcsV0FBVyxHQUFHLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxTQUFTLEdBQUcsR0FBRyxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUN6RixHQUFHLENBQUMsUUFBUSxDQUFDLEdBQUcsRUFBRSxTQUFTLENBQUMsQ0FBQztnQkFDN0IsT0FBTyxJQUFJLENBQUM7YUFDYjtpQkFBTTtnQkFDTCxPQUFPO2dCQUNQLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDdEQ7U0FDRjtRQUNELE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO0lBRTNCLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBRVYsZ0NBQWdDO0lBQ2hDLE1BQU0sZUFBZSxHQUFHLEdBQUcsQ0FBQyxRQUFRLENBQUMsb0JBQW9CLENBQUMsQ0FBQztJQUMzRCxNQUFNLHNCQUFzQixHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLGFBQWEsQ0FBQyxDQUFDO0lBQ3RFLE1BQU0saUJBQWlCLEdBQUcsR0FBRyxDQUFDLFVBQVUsQ0FBQywyQ0FBMkMsQ0FBQyxDQUFDO0lBQ3RGLElBQUksQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDLGVBQWUsQ0FBQyxFQUFFO1FBQ25DLGdGQUFnRjtRQUNoRixHQUFHLENBQUMsS0FBSyxDQUFDLDJDQUEyQyxDQUFDLENBQUM7UUFDdkQsRUFBRSxDQUFDLFFBQVEsQ0FBQyxzQkFBc0IsRUFBRSxlQUFlLENBQUMsQ0FBQztRQUVyRCxJQUFJLEVBQUUsQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsRUFBRTtZQUNwQyxHQUFHLENBQUMsS0FBSyxDQUFDLGtEQUFrRCxDQUFDLENBQUM7WUFDOUQscUVBQXFFO1lBQ3JFLEVBQUUsQ0FBQyxRQUFRLENBQ1QsaUJBQWlCLEVBQ2pCLElBQUksQ0FBQyxPQUFPLENBQUMsZUFBZSxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsY0FBYyxDQUFDLENBQy9ELENBQUM7U0FDSDtLQUNGO0lBRUQsNkNBQTZDO0lBQzdDLE1BQU0sZUFBZSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsZUFBZSxFQUFFLE9BQU8sQ0FBQyxDQUFDO0lBQy9ELEVBQUUsQ0FBQyxhQUFhLENBQUMsZUFBZSxDQUFDLENBQUM7SUFFbEMsd0VBQXdFO0lBQ3hFLE1BQU0sa0JBQWtCLEdBQUc7UUFDekIsV0FBVyxFQUFFLElBQUk7UUFDakIsVUFBVSxFQUFFLEtBQUs7UUFDakIsUUFBUSxFQUFFLFFBQVE7UUFDbEIsSUFBSSxFQUFFLElBQUk7UUFDVixZQUFZLEVBQUUsS0FBSztRQUNuQixVQUFVLEVBQUUsR0FBRyxDQUFDLEVBQUU7WUFDaEIsR0FBRyxDQUFDLFNBQVMsQ0FBQyxlQUFlLEVBQUUsbUNBQW1DLEdBQUcsc0JBQXNCLENBQUMsQ0FBQztRQUMvRixDQUFDO0tBQ0YsQ0FBQztJQUNGLE1BQU0sQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLGVBQWUsRUFBRSxrQkFBa0IsQ0FBQyxDQUFDLENBQUM7SUFFN0QsTUFBTSxVQUFVLEdBQUcsR0FBRyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQztJQUVyRSxrQkFBa0I7SUFDbEIsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsWUFBWSxDQUFDLENBQUM7SUFDekQsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDO0lBQ3JCLE1BQU0sVUFBVSxHQUFHLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxFQUFFO1FBQzlCLElBQUksU0FBUyxLQUFLLElBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxVQUFVLEVBQUUsRUFBRTtZQUMzQyx1REFBdUQ7WUFDdkQsSUFBSSxDQUFDLEVBQUUsQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLEVBQUU7Z0JBQzdCLG9DQUFvQztnQkFDcEMsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO2FBQy9CO1lBQ0QsNEJBQTRCO1lBQzVCLFNBQVMsR0FBRyxFQUFFLENBQUMsWUFBWSxDQUFDLFNBQVMsRUFBRSxFQUFDLFFBQVEsRUFBRSxNQUFNLEVBQUMsQ0FBQyxDQUFDO1NBQzVEO1FBRUQseURBQXlEO1FBQ3pELE1BQU0sU0FBUyxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLEVBQUUsZUFBZSxRQUFRLElBQUksQ0FBQyxDQUFDO1FBQ3BGLEdBQUc7YUFDQSxNQUFNLENBQUMsR0FBRyxDQUFDO2FBQ1gsTUFBTSxDQUFDLGVBQWUsRUFBRSxtQkFBbUIsQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUM7YUFDckUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ3JCLENBQUMsQ0FBQztJQUNGLE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0lBRTVCLG1DQUFtQztJQUNuQyxNQUFNLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxVQUFVLEVBQUUsa0JBQWtCLENBQUMsQ0FBQyxDQUFDO0lBRXhELDBCQUEwQjtJQUMxQixTQUFTLGtCQUFrQixDQUFDLFNBQVM7UUFDbkMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDdEMsT0FBTyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxpQ0FBaUM7UUFDckUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ2hCLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO1lBRTVDLElBQUksRUFBRSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxXQUFXLEVBQUUsRUFBRTtnQkFDdkMsa0JBQWtCLENBQUMsUUFBUSxDQUFDLENBQUM7YUFDOUI7aUJBQU07Z0JBQ0wsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO2FBQzNCO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBQ0Qsa0JBQWtCLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDO0lBRWxFLHlCQUF5QjtJQUN6QixXQUFXLENBQUMsTUFBTSxDQUFDLENBQUM7SUFFcEIscUNBQXFDO0lBQ3JDLE1BQU0sQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLEdBQUcsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFO1FBQ3BDLE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FBQyxlQUFlLENBQUMsQ0FBQztJQUN6QyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBRUosWUFBWTtJQUNaLElBQUksV0FBVyxDQUFDLFVBQVUsRUFBRSxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7SUFFbkQseUNBQXlDO0lBQ3pDLHFEQUFxRDtJQUNyRCxNQUFNLG1CQUFtQixHQUFHO1FBQzFCLFlBQVksRUFBRSxLQUFLO1FBQ25CLFlBQVksRUFBRSxLQUFLO1FBQ25CLElBQUksRUFBRSxVQUFVO1FBQ2hCLE9BQU8sRUFBRTtZQUNQLGVBQWUsRUFBRSxtQ0FBbUMsR0FBRyxzQkFBc0I7U0FDOUU7S0FDRixDQUFDO0lBQ0YsTUFBTSxpQkFBaUIsR0FBRyxDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsRUFBRTtRQUM3RixHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDO1FBQ2hCLE9BQU8sR0FBRyxDQUFDO0lBQ2IsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0lBQ1AsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEVBQUU7UUFFNUIscUZBQXFGO1FBQ3JGLHFCQUFxQjtRQUNyQixJQUFJLFNBQVMsR0FBRyxLQUFLLENBQUM7UUFDdEIsTUFBTSxRQUFRLEdBQUcsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDO1FBQ25ELE1BQU0sUUFBUSxHQUFHLFFBQVEsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDM0MsSUFBSSxRQUFRLEdBQUcsQ0FBQyxFQUFFO1lBQ2hCLE1BQU0sU0FBUyxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUMsUUFBUSxHQUFHLENBQUMsQ0FBQyxDQUFDO1lBQ2hELFNBQVMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLFNBQVMsQ0FBQyxLQUFLLElBQUksQ0FBQyxDQUFDO1NBQ3JEO1FBQ0QsSUFBSSxTQUFTLEVBQUU7WUFDYiw0QkFBNEI7WUFDNUIsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDbkMsT0FBTztTQUNSO1FBRUQsc0NBQXNDO1FBQ3RDLFVBQVUsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDdkIsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMifQ==