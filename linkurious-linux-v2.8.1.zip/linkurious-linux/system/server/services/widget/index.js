/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2018-05-23.
 */
'use strict';
const Promise = require('bluebird');
const _ = require('lodash');
const { StyleRules, NodeAttributes, EdgeAttributes, Tools, Filters, Captions } = require('linkurious-shared/umd');
const LKE = require('../index');
const Db = LKE.getSqlDb();
const Config = LKE.getConfig();
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
const Logger = LKE.getLogger(__filename);
const DesignUtils = require('../business/designUtils');
const VisualizationShareDAO = require('../business/VisualizationShareDAO');
class WidgetService {
    /**
     * Create or updates a widget from visualization.
     *
     * @param {number}        visualizationId Id of the visualization used to create this widget
     * @param {WrappedUser}   currentUser     Current connected user (will be owner of the widget)
     * @param {WidgetOptions} [options]       Toolbar options of the widget
     * @returns {Bluebird<string>} the key of the created widget
     */
    createWidget(visualizationId, currentUser, options = {}) {
        this._checkWidgetCreation(currentUser, visualizationId, options);
        // Check if a widget already exists for that visualization
        return Db.models.widget.find({ where: { visualizationId: visualizationId } })
            .then(existingWidget => {
            if (Utils.hasValue(existingWidget)) {
                return Errors.business('widget_exists', undefined, true);
            }
            // Check that the current user owns the visualization
            return this._getOwnVisualization(visualizationId, currentUser, 'You must be the owner of the visualization to create a widget')
                .then(visualization => {
                const uiOptions = _.omit(options, ['password']);
                const widget = this._generateWidget(visualization, {
                    key: Utils.randomHex8(),
                    userId: currentUser.id,
                    password: options.password
                }, uiOptions);
                return Db.models.widget.create(widget).return(widget.key);
            });
        });
    }
    /**
     * Updates a widget from a visualization preserving the existing key.
     *
     * @param {number}        visualizationId Id of the visualization used to create this widget
     * @param {WrappedUser}   currentUser     Current connected user
     * @param {WidgetOptions} [options]       Toolbar options of the widget
     * @returns {Bluebird<string>} the key of the updated widget
     */
    updateWidget(visualizationId, currentUser, options = {}) {
        this._checkWidgetCreation(currentUser, visualizationId, options);
        // Check if a widget already exists for that visualization
        return Db.models.widget.find({ where: { visualizationId: visualizationId } })
            .then(existingWidget => {
            if (Utils.noValue(existingWidget)) {
                return Errors.business('not_found', `Cannot find widget from visualization #${visualizationId}`, true);
            }
            // Check that the current user owns the visualization
            return this._getOwnVisualization(visualizationId, currentUser, 'You must be the owner of the visualization to update the widget')
                .then(visualization => {
                const uiOptions = _.omit(options, ['password']);
                const widget = this._generateWidget(visualization, {
                    key: existingWidget.key,
                    userId: currentUser.id,
                    password: options.password
                }, _.defaults(uiOptions, existingWidget.content.ui));
                for (const key in widget) {
                    existingWidget[key] = widget[key];
                }
                // null means explicitly: "remove the password"
                if (options.password === null) {
                    existingWidget.password = null;
                }
                return existingWidget.save().return(widget.key);
            });
        });
    }
    /**
     * Find a widget by key.
     *
     * @param {string} key   Key of a widget
     * @param {object}      [credentials]
     * @param {WrappedUser} [credentials.user]
     * @param {string}      [credentials.password]
     * @returns {Bluebird<PublicWidget>}
     */
    getWidgetByKey(key, credentials = {}) {
        Utils.check.nonEmpty('key', key);
        return this._findWidgetByKey(key)
            .then(widget => this._checkCredentials(widget, credentials)
            .then(() => Db.models.widget.instanceToPublicAttributes(widget)));
    }
    /**
     * Return the widget key from the visualization id.
     * If the widget does not exist, return undefined.
     *
     * @param {number} visualizationId
     * @returns {Bluebird<string>}
     */
    getWidgetKeyFromVisualizationId(visualizationId) {
        Utils.check.posInt('visualizationId', visualizationId);
        return Db.models.widget.find({ where: { visualizationId: visualizationId } })
            .then(widget => {
            if (Utils.noValue(widget)) {
                return undefined;
            }
            return widget.key;
        });
    }
    /**
     * Delete a widget by key.
     *
     * @param {string}      key         Key of a widget
     * @param {WrappedUser} currentUser
     * @returns {Bluebird<void>}
     */
    deleteByKey(key, currentUser) {
        return this._findWidgetByKey(key)
            .then(widget => this._getOwnVisualization(widget.visualizationId, currentUser, 'You must be the owner of a widget to delete it.')
            .then(() => widget.destroy()))
            .return();
    }
    /**
     * Migrate all existing widgets
     *
     * @returns {Bluebird<void>}
     * @backward-compatibility
     */
    migrateWidgets() {
        return Db.models.widget.findAll().map(widget => {
            this._updateWidgetToVersion2(widget).catch(error => {
                // In some legacy version of LKE widget content was unchecked. The midget migration might fail due to some unexpected data structure.
                // The broken widgets can be fixed by an update from the original visualization see https://github.com/Linkurious/linkurious-server/issues/1655
                Logger.error(`Failed to migrate widget ${JSON.stringify(widget)}`, error);
            });
        }).return();
    }
    /**
     * @param {WrappedUser}   currentUser
     * @param {number}        visualizationId
     * @param {WidgetOptions} [options]
     * @private
     * @throws {LkError}
     */
    _checkWidgetCreation(currentUser, visualizationId, options) {
        Utils.check.exist('currentUser', currentUser);
        Utils.check.posInt('visualizationId', visualizationId);
        Utils.check.properties('options', options, {
            search: { type: 'boolean' },
            share: { type: 'boolean' },
            layout: { type: 'boolean' },
            fullscreen: { type: 'boolean' },
            zoom: { type: 'boolean' },
            legend: { type: 'boolean' },
            geo: { type: 'boolean' },
            password: { check: 'nonEmpty' }
        });
    }
    /**
     * Find a visualization created by the `currentUser`.
     *
     * @param {number}      id          Visualization ID
     * @param {WrappedUser} currentUser
     * @param {string}      [errorMessage] Error message to shown when `currentUser` does not own the visualization
     * @returns {Bluebird<PublicVisualization>}
     * @private
     * @throws {LkError} If `currentUser` does not own the visualization
     */
    _getOwnVisualization(id, currentUser, errorMessage) {
        const VisualizationDAO = LKE.getVisualizationDAO();
        return VisualizationDAO.getById(id, true, currentUser).then(visualization => {
            if (Utils.noValue(visualization)) {
                return Errors.business('not_found', 'Visualization does not exists', true);
            }
            return VisualizationShareDAO
                .getRight({ id: visualization.id, userId: visualization.userId }, currentUser.id)
                .then(right => {
                if (right !== 'owner') {
                    return Errors.access('forbidden', errorMessage, true);
                }
            }).return(visualization);
        });
    }
    /**
     * Find a widget instance by key.
     *
     * @param {string} key
     * @returns {Bluebird<WidgetInstance>}
     * @private
     * @throws {LkError} If the widget does not exist
     */
    _findWidgetByKey(key) {
        return Db.models.widget.find({ where: { key: key } }).then(widget => {
            if (Utils.noValue(widget)) {
                return Errors.business('not_found', `Cannot find widget with key ${key}`, true);
            }
            return widget;
        });
    }
    /**
     * Generate a widget for a `visualization`
     *
     * @param {PublicVisualization} visualization
     * @param {WidgetConfiguration} configuration
     * @param {WidgetUiOptions}     [uiOptions]
     * @returns {WidgetAttributes}
     * @private
     */
    _generateWidget(visualization, configuration, uiOptions = {}) {
        const { key, userId, password } = configuration;
        const nodeStyleRules = new StyleRules(
        /**@type {SharedNodeStyleRule[]}**/ (visualization.design.styles.node));
        const widgetNodes = this._generateWidgetNodes(visualization, nodeStyleRules);
        const widgetNodeIds = _.map(widgetNodes, 'id');
        const edgeStyleRules = new StyleRules(
        /**@type {SharedEdgeStyleRule[]}**/ (visualization.design.styles.edge));
        const widgetEdges = this._generateWidgetEdges(visualization, edgeStyleRules)
            .filter(edge => {
            // Include only edges with both ends in the widget
            return _.includes(widgetNodeIds, edge.source) && _.includes(widgetNodeIds, edge.target);
        });
        const legend = {
            nodes: nodeStyleRules.generateLegend(widgetNodes, DesignUtils.PALETTE),
            edges: edgeStyleRules.generateLegend(widgetEdges, DesignUtils.PALETTE)
        };
        const defaultUiOptions = {
            search: false,
            share: false,
            fullscreen: false,
            layout: false,
            zoom: false,
            legend: false,
            geo: false
        };
        const widgetContent = {
            graph: { nodes: widgetNodes, edges: widgetEdges },
            legend: legend,
            mapLayers: this._getMapLayersAttributes(visualization.geo.layers),
            mode: visualization.mode,
            ui: _.defaults(uiOptions, defaultUiOptions)
        };
        const widgetAttributes = {
            title: visualization.title,
            key: key,
            content: widgetContent,
            visualizationId: visualization.id,
            userId: userId,
            version: 2
        };
        if (Utils.hasValue(password)) {
            // Set the password only when defined to avoid to clear the password unintentionally
            widgetAttributes.password = password;
        }
        return widgetAttributes;
    }
    /**
     * @param {any}        visualization
     * @param {StyleRules} nodeStyleRules
     * @returns {OgmaNode[]}
     * @private
     */
    _generateWidgetNodes(visualization, nodeStyleRules) {
        // list visible node/edge properties (from visualization Tooltips) to filter content
        return visualization.nodes
            .filter(node => !Filters.isFiltered(visualization.filters.node, node))
            .map(node => ({
            id: node.id,
            attributes: this._generateNodeAttributes(node, nodeStyleRules, this._getNodeCaption(node, visualization.nodeFields.captions)),
            data: {
                categories: node.categories,
                properties: node.data,
                _geo: Tools.getOgmaCoordinates(node.geo)
            }
        }));
    }
    /**
     * @param {any}        visualization
     * @param {StyleRules} edgeStyleRules
     * @returns {OgmaEdge[]}
     * @private
     */
    _generateWidgetEdges(visualization, edgeStyleRules) {
        return visualization.edges
            .filter(edge => !Filters.isFiltered(visualization.filters.edge, edge))
            .map(edge => ({
            id: edge.id,
            source: edge.source,
            target: edge.target,
            attributes: this._generateEdgeAttributes(edge, edgeStyleRules, this._getEdgeCaption(edge, visualization.edgeFields.captions)),
            data: {
                type: edge.type,
                properties: edge.data
            }
        }));
    }
    /**
     * @param {VisualizationNode} node
     * @param {StyleRules}        styleRules
     * @param {string}            label
     * @returns {{color: OgmaColor | OgmaColor[], radius: number, shape: NodeShape, x: number, y: number, icon: Icon, image: Image, text: {content: string}}}
     * @private
     */
    _generateNodeAttributes(node, styleRules, label) {
        const ogmaSettings = Config.get('ogma');
        const defaultRadius = _.get(ogmaSettings, ['options', 'styles', 'nodeRadius'], 5);
        const defaultShape = _.get(ogmaSettings, ['options', 'styles', 'shapes', 'nodes'], 'circle');
        const attributes = new NodeAttributes(styleRules.nodeRules).all(node, DesignUtils.PALETTE);
        return {
            color: attributes.color,
            radius: attributes.radius || defaultRadius,
            shape: attributes.shape || defaultShape,
            x: node.nodelink.x,
            y: node.nodelink.y,
            icon: attributes.icon,
            image: attributes.image,
            text: { content: label }
        };
    }
    /**
     * @param {LkEdge}     edge
     * @param {StyleRules} styleRules
     * @param {string}     label
     * @returns {{color: OgmaColor, shape: EdgeShape, width: number, text: {content: string}}}
     * @private
     */
    _generateEdgeAttributes(edge, styleRules, label) {
        const ogmaSettings = Config.get('ogma');
        const defaultWidth = _.get(ogmaSettings, ['options', 'styles', 'edgeWidth'], 1);
        const defaultShape = _.get(ogmaSettings, ['options', 'styles', 'shapes', 'edges'], 'arrow');
        const attributes = new EdgeAttributes(styleRules.edgeRules).all(edge, DesignUtils.PALETTE);
        return {
            color: attributes.color,
            shape: attributes.shape || defaultShape,
            width: attributes.width || defaultWidth,
            text: { content: label }
        };
    }
    /**
     * @param {string[]} layersNames
     * @returns {object[]}
     * @private
     */
    _getMapLayersAttributes(layersNames) {
        const leafletLayers = Config.get('leaflet', []);
        // If layersNames is empty
        // return the first layer with overlay != true
        if (layersNames.length === 0) {
            const [layer] = _.filter(leafletLayers, leaflet => !leaflet.overlay);
            return Utils.hasValue(layer) ? [layer] : [];
        }
        const layers = new Map();
        _.forEach(leafletLayers, leaflet => {
            layers.set(leaflet.name, leaflet);
        });
        return _.map(layersNames, layerName => layers.get(layerName));
    }
    /**
     * @param {WidgetInstance} widgetInstance
     * @param {object}         [credentials]
     * @param {WrappedUser}    [credentials.user]
     * @param {string}         [credentials.password]
     * @returns {Bluebird<void>}
     * @private
     * @throws {LkError} If the user cannot access the widget
     */
    _checkCredentials(widgetInstance, credentials) {
        return Promise.resolve().then(() => {
            if (Utils.noValue(widgetInstance.password)) {
                // widget without password, pass along
                return;
            }
            if (Utils.hasValue(credentials.user)) {
                // User own the visualization, allow to read the widget.
                return this._getOwnVisualization(widgetInstance.visualizationId, credentials.user, 'You do not have access to this widget').return();
            }
            if (!widgetInstance.checkPassword(credentials.password)) {
                // incorrect password
                return Errors.access('forbidden', 'Invalid widget password.', true);
            }
        });
    }
    /**
     * Resolve the node caption.
     *
     * @private
     */
    _getNodeCaption(node, nodeCaptions) {
        return Captions.generateNodeCaption({
            data: {
                categories: node.categories,
                properties: node.data
            }
        }, nodeCaptions);
    }
    /**
     * Resolve the edge caption.
     *
     * @private
     */
    _getEdgeCaption(edge, edgeCaptions) {
        return Captions.generateEdgeCaption({
            data: {
                type: edge.type,
                properties: edge.data
            }
        }, edgeCaptions);
    }
    /**
     * Update the widget to be compatible with Ogma if widget is version 1.
     *
     * @param {WidgetInstance} widget
     * @returns {Bluebird<WidgetInstance>}
     * @private
     * @backward-compatibility
     */
    _updateWidgetToVersion2(widget) {
        return Promise.resolve().then(() => {
            if (widget.version > 1) {
                return widget;
            }
            widget.content = this._migrateWidgetContentToOgma(widget.content);
            widget.version = 2;
            return widget.save();
        });
    }
    /**
     * Extract schema from `nodes` and `edges` (format: Widget v1)
     *
     * @param {Array<{data: {categories: string[]}}>} nodes
     * @param {Array<{data: {type: string}}>}         edges
     * @returns {{node: {labels: string[]}, edge: {labels: string[]}}}
     * @private
     */
    _getTypesSchema(nodes, edges) {
        const nodeCategories = new Set();
        const edgeTypes = new Set();
        _.forEach(nodes, node => {
            _.forEach(node.data.categories, category => {
                nodeCategories.add(category);
            });
        });
        _.forEach(edges, edge => {
            edgeTypes.add(edge.data.type);
        });
        return {
            node: { labels: Array.from(nodeCategories) },
            edge: { labels: Array.from(edgeTypes) }
        };
    }
    /**
     * Update the widget content to be compatible with Ogma.
     *
     * @param {object} content Widget content v1
     * @returns {WidgetContent}
     * @backward-compatibility
     * @private
     */
    _migrateWidgetContentToOgma(content) {
        // We don't need the schema Api here, all the required categories/types are already in the widget
        const schema = this._getTypesSchema(content.graph.nodes, content.graph.edges);
        // 1) Build Style Rules
        const widgetStyleRules = DesignUtils.migrateStyles(schema, content.styles, content.palette);
        // 2) Migrate Nodes format
        const nodeStyleRules = new StyleRules(
        /**@type {SharedNodeStyleRule[]}**/ (widgetStyleRules.node));
        const widgetNodes = content.graph.nodes
            .map(node => ({
            id: node.id,
            attributes: this._generateNodeAttributes(node, nodeStyleRules, node.label),
            data: {
                properties: node.data.properties,
                categories: node.data.categories,
                _geo: Tools.getOgmaCoordinates(node.geo)
            }
        }));
        // 3) Migrate Edges format
        const edgeStyleRules = new StyleRules(
        /**@type {SharedEdgeStyleRule[]}**/ (widgetStyleRules.edge));
        const widgetEdges = content.graph.edges
            .map(edge => ({
            id: edge.id,
            source: edge.source,
            target: edge.target,
            attributes: this._generateEdgeAttributes(edge, edgeStyleRules, edge.label),
            data: edge.data
        }));
        return {
            graph: {
                nodes: widgetNodes,
                edges: widgetEdges
            },
            legend: {
                nodes: nodeStyleRules.generateLegend(widgetNodes, DesignUtils.PALETTE),
                edges: edgeStyleRules.generateLegend(widgetEdges, DesignUtils.PALETTE)
            },
            mapLayers: content.mapLayers,
            mode: content.mode,
            ui: content.ui
        };
    }
}
module.exports = new WidgetService();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvd2lkZ2V0L2luZGV4LmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBQ2IsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3BDLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM1QixNQUFNLEVBQ0osVUFBVSxFQUNWLGNBQWMsRUFDZCxjQUFjLEVBQ2QsS0FBSyxFQUNMLE9BQU8sRUFDUCxRQUFRLEVBQ1QsR0FBRyxPQUFPLENBQUMsdUJBQXVCLENBQUMsQ0FBQztBQUNyQyxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDaEMsTUFBTSxFQUFFLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzFCLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDekMsTUFBTSxXQUFXLEdBQUcsT0FBTyxDQUFDLHlCQUF5QixDQUFDLENBQUM7QUFDdkQsTUFBTSxxQkFBcUIsR0FBRyxPQUFPLENBQUMsbUNBQW1DLENBQUMsQ0FBQztBQUUzRSxNQUFNLGFBQWE7SUFDakI7Ozs7Ozs7T0FPRztJQUNILFlBQVksQ0FBQyxlQUFlLEVBQUUsV0FBVyxFQUFFLE9BQU8sR0FBRyxFQUFFO1FBQ3JELElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxXQUFXLEVBQUUsZUFBZSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBRWpFLDBEQUEwRDtRQUMxRCxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFDLEtBQUssRUFBRSxFQUFDLGVBQWUsRUFBRSxlQUFlLEVBQUMsRUFBQyxDQUFDO2FBQ3RFLElBQUksQ0FBQyxjQUFjLENBQUMsRUFBRTtZQUNyQixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLEVBQUU7Z0JBQ2xDLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxlQUFlLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQzFEO1lBQ0QscURBQXFEO1lBQ3JELE9BQU8sSUFBSSxDQUFDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxXQUFXLEVBQzNELCtEQUErRCxDQUFDO2lCQUMvRCxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUU7Z0JBQ3BCLE1BQU0sU0FBUyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztnQkFDaEQsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxhQUFhLEVBQUU7b0JBQ2pELEdBQUcsRUFBRSxLQUFLLENBQUMsVUFBVSxFQUFFO29CQUN2QixNQUFNLEVBQUUsV0FBVyxDQUFDLEVBQUU7b0JBQ3RCLFFBQVEsRUFBRSxPQUFPLENBQUMsUUFBUTtpQkFDM0IsRUFBRSxTQUFTLENBQUMsQ0FBQztnQkFDZCxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQzVELENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILFlBQVksQ0FBQyxlQUFlLEVBQUUsV0FBVyxFQUFFLE9BQU8sR0FBRyxFQUFFO1FBQ3JELElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxXQUFXLEVBQUUsZUFBZSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ2pFLDBEQUEwRDtRQUMxRCxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFDLEtBQUssRUFBRSxFQUFDLGVBQWUsRUFBRSxlQUFlLEVBQUMsRUFBQyxDQUFDO2FBQ3RFLElBQUksQ0FBQyxjQUFjLENBQUMsRUFBRTtZQUNyQixJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLEVBQUU7Z0JBQ2pDLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQ2hDLDBDQUEwQyxlQUFlLEVBQUUsRUFBRSxJQUFJLENBQUMsQ0FBQzthQUN0RTtZQUNELHFEQUFxRDtZQUNyRCxPQUFPLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxlQUFlLEVBQUUsV0FBVyxFQUMzRCxpRUFBaUUsQ0FBQztpQkFDakUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFO2dCQUNwQixNQUFNLFNBQVMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7Z0JBQ2hELE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsYUFBYSxFQUFFO29CQUNqRCxHQUFHLEVBQUUsY0FBYyxDQUFDLEdBQUc7b0JBQ3ZCLE1BQU0sRUFBRSxXQUFXLENBQUMsRUFBRTtvQkFDdEIsUUFBUSxFQUFFLE9BQU8sQ0FBQyxRQUFRO2lCQUMzQixFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsU0FBUyxFQUFFLGNBQWMsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFDckQsS0FBSyxNQUFNLEdBQUcsSUFBSSxNQUFNLEVBQUU7b0JBQ3hCLGNBQWMsQ0FBQyxHQUFHLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7aUJBQ25DO2dCQUVELCtDQUErQztnQkFDL0MsSUFBSSxPQUFPLENBQUMsUUFBUSxLQUFLLElBQUksRUFBRTtvQkFDN0IsY0FBYyxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7aUJBQ2hDO2dCQUVELE9BQU8sY0FBYyxDQUFDLElBQUksRUFBRSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDbEQsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILGNBQWMsQ0FBQyxHQUFHLEVBQUUsV0FBVyxHQUFHLEVBQUU7UUFDbEMsS0FBSyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQ2pDLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQzthQUM5QixJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsTUFBTSxFQUFFLFdBQVcsQ0FBQzthQUN4RCxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsMEJBQTBCLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3hFLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCwrQkFBK0IsQ0FBQyxlQUFlO1FBQzdDLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLGlCQUFpQixFQUFFLGVBQWUsQ0FBQyxDQUFDO1FBQ3ZELE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUMsS0FBSyxFQUFFLEVBQUMsZUFBZSxFQUFFLGVBQWUsRUFBQyxFQUFDLENBQUM7YUFDdEUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQ2IsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFO2dCQUN6QixPQUFPLFNBQVMsQ0FBQzthQUNsQjtZQUNELE9BQU8sTUFBTSxDQUFDLEdBQUcsQ0FBQztRQUNwQixDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxXQUFXLENBQUMsR0FBRyxFQUFFLFdBQVc7UUFDMUIsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDO2FBQzlCLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxNQUFNLENBQUMsZUFBZSxFQUFFLFdBQVcsRUFDM0UsaURBQWlELENBQUM7YUFDakQsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO2FBQy9CLE1BQU0sRUFBRSxDQUFDO0lBQ2QsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsY0FBYztRQUNaLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQzdDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQ2pELHFJQUFxSTtnQkFDckksK0lBQStJO2dCQUMvSSxNQUFNLENBQUMsS0FBSyxDQUFDLDRCQUE0QixJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDNUUsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztJQUNkLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxvQkFBb0IsQ0FBQyxXQUFXLEVBQUUsZUFBZSxFQUFFLE9BQU87UUFDeEQsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsYUFBYSxFQUFFLFdBQVcsQ0FBQyxDQUFDO1FBQzlDLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLGlCQUFpQixFQUFFLGVBQWUsQ0FBQyxDQUFDO1FBQ3ZELEtBQUssQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxPQUFPLEVBQUU7WUFDekMsTUFBTSxFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQztZQUN6QixLQUFLLEVBQUUsRUFBQyxJQUFJLEVBQUUsU0FBUyxFQUFDO1lBQ3hCLE1BQU0sRUFBRSxFQUFDLElBQUksRUFBRSxTQUFTLEVBQUM7WUFDekIsVUFBVSxFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQztZQUM3QixJQUFJLEVBQUUsRUFBQyxJQUFJLEVBQUUsU0FBUyxFQUFDO1lBQ3ZCLE1BQU0sRUFBRSxFQUFDLElBQUksRUFBRSxTQUFTLEVBQUM7WUFDekIsR0FBRyxFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQztZQUN0QixRQUFRLEVBQUUsRUFBQyxLQUFLLEVBQUUsVUFBVSxFQUFDO1NBQzlCLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7O09BU0c7SUFDSCxvQkFBb0IsQ0FBQyxFQUFFLEVBQUUsV0FBVyxFQUFFLFlBQVk7UUFDaEQsTUFBTSxnQkFBZ0IsR0FBRyxHQUFHLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztRQUNuRCxPQUFPLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxFQUFFLEVBQUUsSUFBSSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRTtZQUMxRSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLEVBQUU7Z0JBQ2hDLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsK0JBQStCLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDNUU7WUFDRCxPQUFPLHFCQUFxQjtpQkFDekIsUUFBUSxDQUFDLEVBQUMsRUFBRSxFQUFFLGFBQWEsQ0FBQyxFQUFFLEVBQUUsTUFBTSxFQUFFLGFBQWEsQ0FBQyxNQUFNLEVBQUMsRUFBRSxXQUFXLENBQUMsRUFBRSxDQUFDO2lCQUM5RSxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQ1osSUFBSSxLQUFLLEtBQUssT0FBTyxFQUFFO29CQUNyQixPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFFLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQztpQkFDdkQ7WUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLENBQUM7UUFDN0IsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILGdCQUFnQixDQUFDLEdBQUc7UUFDbEIsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBQyxLQUFLLEVBQUUsRUFBQyxHQUFHLEVBQUUsR0FBRyxFQUFDLEVBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUM5RCxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUU7Z0JBQ3pCLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsK0JBQStCLEdBQUcsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQ2pGO1lBQ0QsT0FBTyxNQUFNLENBQUM7UUFDaEIsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSCxlQUFlLENBQUMsYUFBYSxFQUFFLGFBQWEsRUFBRSxTQUFTLEdBQUcsRUFBRTtRQUMxRCxNQUFNLEVBQUMsR0FBRyxFQUFFLE1BQU0sRUFBRSxRQUFRLEVBQUMsR0FBRyxhQUFhLENBQUM7UUFDOUMsTUFBTSxjQUFjLEdBQUcsSUFBSSxVQUFVO1FBQ25DLG1DQUFtQyxDQUFBLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUN6RSxNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsb0JBQW9CLENBQUMsYUFBYSxFQUFFLGNBQWMsQ0FBQyxDQUFDO1FBQzdFLE1BQU0sYUFBYSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBRS9DLE1BQU0sY0FBYyxHQUFHLElBQUksVUFBVTtRQUNuQyxtQ0FBbUMsQ0FBQSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDekUsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLG9CQUFvQixDQUFDLGFBQWEsRUFBRSxjQUFjLENBQUM7YUFDekUsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ2Isa0RBQWtEO1lBQ2xELE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUMxRixDQUFDLENBQUMsQ0FBQztRQUVMLE1BQU0sTUFBTSxHQUFHO1lBQ2IsS0FBSyxFQUFFLGNBQWMsQ0FBQyxjQUFjLENBQUMsV0FBVyxFQUFFLFdBQVcsQ0FBQyxPQUFPLENBQUM7WUFDdEUsS0FBSyxFQUFFLGNBQWMsQ0FBQyxjQUFjLENBQUMsV0FBVyxFQUFFLFdBQVcsQ0FBQyxPQUFPLENBQUM7U0FDdkUsQ0FBQztRQUVGLE1BQU0sZ0JBQWdCLEdBQUc7WUFDdkIsTUFBTSxFQUFFLEtBQUs7WUFDYixLQUFLLEVBQUUsS0FBSztZQUNaLFVBQVUsRUFBRSxLQUFLO1lBQ2pCLE1BQU0sRUFBRSxLQUFLO1lBQ2IsSUFBSSxFQUFFLEtBQUs7WUFDWCxNQUFNLEVBQUUsS0FBSztZQUNiLEdBQUcsRUFBRSxLQUFLO1NBQ1gsQ0FBQztRQUVGLE1BQU0sYUFBYSxHQUFHO1lBQ3BCLEtBQUssRUFBRSxFQUFDLEtBQUssRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBQztZQUMvQyxNQUFNLEVBQUUsTUFBTTtZQUNkLFNBQVMsRUFBRSxJQUFJLENBQUMsdUJBQXVCLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUM7WUFDakUsSUFBSSxFQUFFLGFBQWEsQ0FBQyxJQUFJO1lBQ3hCLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLFNBQVMsRUFBRSxnQkFBZ0IsQ0FBQztTQUM1QyxDQUFDO1FBRUYsTUFBTSxnQkFBZ0IsR0FBRztZQUN2QixLQUFLLEVBQUUsYUFBYSxDQUFDLEtBQUs7WUFDMUIsR0FBRyxFQUFFLEdBQUc7WUFDUixPQUFPLEVBQUUsYUFBYTtZQUN0QixlQUFlLEVBQUUsYUFBYSxDQUFDLEVBQUU7WUFDakMsTUFBTSxFQUFFLE1BQU07WUFDZCxPQUFPLEVBQUUsQ0FBQztTQUNYLENBQUM7UUFFRixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDNUIsb0ZBQW9GO1lBQ3BGLGdCQUFnQixDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUM7U0FDdEM7UUFFRCxPQUFPLGdCQUFnQixDQUFDO0lBQzFCLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILG9CQUFvQixDQUFDLGFBQWEsRUFBRSxjQUFjO1FBQ2hELG9GQUFvRjtRQUNwRixPQUFPLGFBQWEsQ0FBQyxLQUFLO2FBQ3ZCLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQzthQUNyRSxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQ1osRUFBRSxFQUFFLElBQUksQ0FBQyxFQUFFO1lBQ1gsVUFBVSxFQUFFLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLEVBQUUsY0FBYyxFQUMzRCxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksRUFBRSxhQUFhLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ2hFLElBQUksRUFBRTtnQkFDSixVQUFVLEVBQUUsSUFBSSxDQUFDLFVBQVU7Z0JBQzNCLFVBQVUsRUFBRSxJQUFJLENBQUMsSUFBSTtnQkFDckIsSUFBSSxFQUFFLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO2FBQ3pDO1NBQ0YsQ0FBQyxDQUFDLENBQUM7SUFDUixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxvQkFBb0IsQ0FBQyxhQUFhLEVBQUUsY0FBYztRQUNoRCxPQUFPLGFBQWEsQ0FBQyxLQUFLO2FBQ3ZCLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQzthQUNyRSxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQ1osRUFBRSxFQUFFLElBQUksQ0FBQyxFQUFFO1lBQ1gsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNO1lBQ25CLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTTtZQUNuQixVQUFVLEVBQUUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLElBQUksRUFBRSxjQUFjLEVBQzNELElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxFQUFFLGFBQWEsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDaEUsSUFBSSxFQUFFO2dCQUNKLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSTtnQkFDZixVQUFVLEVBQUUsSUFBSSxDQUFDLElBQUk7YUFDdEI7U0FDRixDQUFDLENBQUMsQ0FBQztJQUNSLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCx1QkFBdUIsQ0FBQyxJQUFJLEVBQUUsVUFBVSxFQUFFLEtBQUs7UUFDN0MsTUFBTSxZQUFZLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUN4QyxNQUFNLGFBQWEsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLFlBQVksRUFBRSxDQUFDLFNBQVMsRUFBRSxRQUFRLEVBQUUsWUFBWSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDbEYsTUFBTSxZQUFZLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxTQUFTLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxPQUFPLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQztRQUM3RixNQUFNLFVBQVUsR0FBRyxJQUFJLGNBQWMsQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDM0YsT0FBTztZQUNMLEtBQUssRUFBRSxVQUFVLENBQUMsS0FBSztZQUN2QixNQUFNLEVBQUUsVUFBVSxDQUFDLE1BQU0sSUFBSSxhQUFhO1lBQzFDLEtBQUssRUFBRSxVQUFVLENBQUMsS0FBSyxJQUFJLFlBQVk7WUFDdkMsQ0FBQyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUNsQixDQUFDLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ2xCLElBQUksRUFBRSxVQUFVLENBQUMsSUFBSTtZQUNyQixLQUFLLEVBQUUsVUFBVSxDQUFDLEtBQUs7WUFDdkIsSUFBSSxFQUFFLEVBQUMsT0FBTyxFQUFFLEtBQUssRUFBQztTQUN2QixDQUFDO0lBQ0osQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILHVCQUF1QixDQUFDLElBQUksRUFBRSxVQUFVLEVBQUUsS0FBSztRQUM3QyxNQUFNLFlBQVksR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3hDLE1BQU0sWUFBWSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsWUFBWSxFQUFFLENBQUMsU0FBUyxFQUFFLFFBQVEsRUFBRSxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUNoRixNQUFNLFlBQVksR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLFlBQVksRUFBRSxDQUFDLFNBQVMsRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLE9BQU8sQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQzVGLE1BQU0sVUFBVSxHQUFHLElBQUksY0FBYyxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUMzRixPQUFPO1lBQ0wsS0FBSyxFQUFFLFVBQVUsQ0FBQyxLQUFLO1lBQ3ZCLEtBQUssRUFBRSxVQUFVLENBQUMsS0FBSyxJQUFJLFlBQVk7WUFDdkMsS0FBSyxFQUFFLFVBQVUsQ0FBQyxLQUFLLElBQUksWUFBWTtZQUN2QyxJQUFJLEVBQUUsRUFBQyxPQUFPLEVBQUUsS0FBSyxFQUFDO1NBQ3ZCLENBQUM7SUFDSixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILHVCQUF1QixDQUFDLFdBQVc7UUFDakMsTUFBTSxhQUFhLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDaEQsMEJBQTBCO1FBQzFCLDhDQUE4QztRQUM5QyxJQUFJLFdBQVcsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1lBQzVCLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLGFBQWEsRUFBRSxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ3JFLE9BQU8sS0FBSyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1NBQzdDO1FBQ0QsTUFBTSxNQUFNLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQztRQUN6QixDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxPQUFPLENBQUMsRUFBRTtZQUNqQyxNQUFNLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDcEMsQ0FBQyxDQUFDLENBQUM7UUFDSCxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLFNBQVMsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO0lBQ2hFLENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILGlCQUFpQixDQUFDLGNBQWMsRUFBRSxXQUFXO1FBQzNDLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDakMsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsRUFBRTtnQkFDMUMsc0NBQXNDO2dCQUN0QyxPQUFPO2FBQ1I7WUFFRCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUNwQyx3REFBd0Q7Z0JBQ3hELE9BQU8sSUFBSSxDQUFDLG9CQUFvQixDQUFDLGNBQWMsQ0FBQyxlQUFlLEVBQUUsV0FBVyxDQUFDLElBQUksRUFDL0UsdUNBQXVDLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQzthQUNyRDtZQUVELElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsRUFBRTtnQkFDdkQscUJBQXFCO2dCQUNyQixPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFFLDBCQUEwQixFQUFFLElBQUksQ0FBQyxDQUFDO2FBQ3JFO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILGVBQWUsQ0FBQyxJQUFJLEVBQUUsWUFBWTtRQUNoQyxPQUFPLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQztZQUNsQyxJQUFJLEVBQUU7Z0JBQ0osVUFBVSxFQUFFLElBQUksQ0FBQyxVQUFVO2dCQUMzQixVQUFVLEVBQUUsSUFBSSxDQUFDLElBQUk7YUFDdEI7U0FDRixFQUFFLFlBQVksQ0FBQyxDQUFDO0lBQ25CLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsZUFBZSxDQUFDLElBQUksRUFBRSxZQUFZO1FBQ2hDLE9BQU8sUUFBUSxDQUFDLG1CQUFtQixDQUFDO1lBQ2xDLElBQUksRUFBRTtnQkFDSixJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUk7Z0JBQ2YsVUFBVSxFQUFFLElBQUksQ0FBQyxJQUFJO2FBQ3RCO1NBQ0YsRUFBRSxZQUFZLENBQUMsQ0FBQztJQUNuQixDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILHVCQUF1QixDQUFDLE1BQU07UUFDNUIsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNqQyxJQUFJLE1BQU0sQ0FBQyxPQUFPLEdBQUcsQ0FBQyxFQUFFO2dCQUN0QixPQUFPLE1BQU0sQ0FBQzthQUNmO1lBQ0QsTUFBTSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsMkJBQTJCLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ2xFLE1BQU0sQ0FBQyxPQUFPLEdBQUcsQ0FBQyxDQUFDO1lBQ25CLE9BQU8sTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDO1FBQ3ZCLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxlQUFlLENBQUMsS0FBSyxFQUFFLEtBQUs7UUFDMUIsTUFBTSxjQUFjLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQztRQUNqQyxNQUFNLFNBQVMsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBRTVCLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxFQUFFO1lBQ3RCLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsUUFBUSxDQUFDLEVBQUU7Z0JBQ3pDLGNBQWMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDL0IsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUVILENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxFQUFFO1lBQ3RCLFNBQVMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNoQyxDQUFDLENBQUMsQ0FBQztRQUVILE9BQU87WUFDTCxJQUFJLEVBQUUsRUFBRSxNQUFNLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsRUFBRTtZQUM1QyxJQUFJLEVBQUUsRUFBRSxNQUFNLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRTtTQUN4QyxDQUFDO0lBQ0osQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCwyQkFBMkIsQ0FBQyxPQUFPO1FBQ2pDLGlHQUFpRztRQUNqRyxNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDOUUsdUJBQXVCO1FBQ3ZCLE1BQU0sZ0JBQWdCLEdBQUcsV0FBVyxDQUFDLGFBQWEsQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFNUYsMEJBQTBCO1FBQzFCLE1BQU0sY0FBYyxHQUFHLElBQUksVUFBVTtRQUNuQyxtQ0FBbUMsQ0FBQSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDOUQsTUFBTSxXQUFXLEdBQUcsT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLO2FBQ3BDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDWixFQUFFLEVBQUUsSUFBSSxDQUFDLEVBQUU7WUFDWCxVQUFVLEVBQUUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLElBQUksRUFBRSxjQUFjLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQztZQUMxRSxJQUFJLEVBQUU7Z0JBQ0osVUFBVSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVTtnQkFDaEMsVUFBVSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVTtnQkFDaEMsSUFBSSxFQUFFLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO2FBQ3pDO1NBQ0YsQ0FBQyxDQUFDLENBQUM7UUFFTiwwQkFBMEI7UUFDMUIsTUFBTSxjQUFjLEdBQUcsSUFBSSxVQUFVO1FBQ25DLG1DQUFtQyxDQUFBLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUM5RCxNQUFNLFdBQVcsR0FBRyxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUs7YUFDcEMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUNaLEVBQUUsRUFBRSxJQUFJLENBQUMsRUFBRTtZQUNYLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTTtZQUNuQixNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU07WUFDbkIsVUFBVSxFQUFFLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLEVBQUUsY0FBYyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7WUFDMUUsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO1NBQ2hCLENBQUMsQ0FBQyxDQUFDO1FBRU4sT0FBTztZQUNMLEtBQUssRUFBRTtnQkFDTCxLQUFLLEVBQUUsV0FBVztnQkFDbEIsS0FBSyxFQUFFLFdBQVc7YUFDbkI7WUFDRCxNQUFNLEVBQUU7Z0JBQ04sS0FBSyxFQUFFLGNBQWMsQ0FBQyxjQUFjLENBQUMsV0FBVyxFQUFFLFdBQVcsQ0FBQyxPQUFPLENBQUM7Z0JBQ3RFLEtBQUssRUFBRSxjQUFjLENBQUMsY0FBYyxDQUFDLFdBQVcsRUFBRSxXQUFXLENBQUMsT0FBTyxDQUFDO2FBQ3ZFO1lBQ0QsU0FBUyxFQUFFLE9BQU8sQ0FBQyxTQUFTO1lBQzVCLElBQUksRUFBRSxPQUFPLENBQUMsSUFBSTtZQUNsQixFQUFFLEVBQUUsT0FBTyxDQUFDLEVBQUU7U0FDZixDQUFDO0lBQ0osQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxJQUFJLGFBQWEsRUFBRSxDQUFDIn0=